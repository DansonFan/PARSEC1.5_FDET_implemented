# PARSEC 1.5 FDET-based AFM Extension

Modified by Dingxin Fan

Date: 2026-07-15

Updated: 2026-10-18

## Added Functionality

This PARSEC 1.5 source tree has been extended to support FDET-based AFM
simulation workflows migrated from the previous PARSEC 1.4 implementation.
The added functionality includes:

- Reading an external frozen-sample potential field from `pot.dat`.
- Writing `pot.dat` from a sample calculation for later AFM/FDET tip
  calculations.
- Carrying frozen-sample quantities in the PARSEC 1.5 potential data structure,
  including sample ionic potential, sample Hartree potential, frozen density,
  non-additive kinetic potential, and non-additive kinetic energy.
- Supporting FDET input keywords:
  - `potential_field`
  - `potential_field_name`
  - `kinetic_energy_functional`
  - `pbe_m`
  - `pbe_k`
- Computing non-additive kinetic-energy contributions using PW91K, PBE-like,
  Thomas-Fermi, Thomas-Fermi plus gradient expansion, or no kinetic correction.
- Adding FDET corrections to the SCF potential, Hartree/XC density handling,
  total-energy expression, and force calculations.
- Supporting slab-periodic FDET calculations with external point charges through
  a slab-specific Ewald branch.
- Updating the PARSEC 1.5 build system so the added FDET/AFM source files are
  compiled with the rest of the code.

## Updates 2026-10-18

These changes were found while adding HR-AFM simulations to PARSEC Tools and
comparing this tree with the PARSEC 1.4 FDET code (Y. Sakai).

- Point charges no longer enter the electronic ionic potential when
  `potential_field` is on. The sample ions already act through `pot.dat`, so the
  -q/r term was counted twice (this block is commented out in PARSEC 1.4).
  The point charges still enter the ion-ion energy and the forces.
- The non-additive kinetic energy is now summed over processors and multiplied
  by h^3, as in the PARSEC 1.4 `exc_nspn`. Only the reported total energy was
  affected, not the potential.
- Warm start for AFM scans (serial runs, clusters, no symmetry): when every tip
  atom moves by the same whole number of grid steps between two
  `minimization manual` steps, the converged density, orbitals and Hartree
  potential are translated with the tip before the next SCF cycle. Energies
  agree with a cold start to 5e-7 Ry and the SCF steps per scan point drop from
  about 19 to 5 or 6. Keep the lateral scan step a multiple of the grid spacing.
- New keyword `hartree_cg_tolerance` (default 1.d-13, unchanged behaviour):
  relative tolerance of the CG Poisson solver.
- New keyword `hartree_cg_criterion` (default 1): 1 stops relative to the
  initial residual, 2 relative to the right-hand side. For AFM tip runs,
  `hartree_cg_tolerance 1.d-9` with `hartree_cg_criterion 2` gave energies within
  3e-7 Ry of the default and about 35% fewer Laplacian calls per solve.
- gfortran portability fixes (pot.dat grid index I/O list, intent attributes,
  build-info format widths) and a Windows (MSYS2 UCRT64) build configuration,
  `src/build/config/make.windows_ucrt`.
- The prebuilt Stampede3 binary from 2024 was removed from `src/`; build from
  source.

Notes for FDET-AFM inputs:

- Use `local_component s` for every atom of the sample and the tip. The sample
  acts on the tip only through its local potential, and a p local component
  (deep well at C, N, O cores) lets the tip charge leak into the sample, so the
  SCF diverges.
- Tip runs converge well with `mixing_param 0.2` and `restart_mixing 200`.
- For the finite-difference height step, use a whole number of grid spacings so
  the egg-box error is the same in every tip plane.

## Current Status and Risk Notice

Preliminary tests have passed for the migrated PARSEC 1.5 FDET-based AFM code.
However, this extension is still under development. Users should validate the
code carefully for their own systems and use cases. Users use it at their own
risk.

## Stability Updates

The following stability-oriented updates were added after reviewing occasional
SCF hangs and MPI-layout-dependent behavior:

- The FDET `pot.dat` reader now checks unformatted-file read errors with
  `iostat` and broadcasts the error code, so missing, empty, corrupt, or
  incompatible external field files should exit cleanly instead of leaving
  non-master MPI ranks waiting.
- The FDET external field filename is now broadcast together with the other FDET
  settings.
- The non-additive kinetic-energy interface no longer passes the whole
  `potential` object while also writing components of the same object. This
  avoids compiler- and optimization-sensitive aliasing/intent behavior.
- The SCF loop now prints and flushes progress markers before and after
  `eigval()`, making it easier to identify whether a run is hanging inside the
  eigensolver/MatVec path.
- `eigval()` now rounds the internal `mxstate` work size up to a multiple of
  `npcol` instead of failing immediately when the requested work size is not
  divisible by the column-group count.
- The input parser now stops immediately if the total MPI process count is not
  divisible by `npcol`, preventing invalid processor-group layouts from reaching
  the SCF/eigensolver stage.
- With ScaLAPACK enabled, `states_num` is rounded up to a valid
  `npcol*scalapack_block_size` multiple instead of requiring manual edits for
  every MPI layout.
- The Stampede3 Intel build configuration now enables `STABLE_ALLTOALLV`.
  This keeps the existing packed neighbor buffers but sends them through
  rank-indexed `MPI_Ialltoallv` on the normal column-group communicator, avoiding
  MPI distributed-graph neighborhood collectives in the SCF/MatVec path.
- The folded/block MatVec buffer now packs data using the folded communication
  neighbor list (`c_sources`) instead of the regular-grid neighbor list
  (`sources`), avoiding a source-list mismatch when the two communication graphs
  differ.
- Memory allocation failures now print resource guidance through the common
  `alccheck` path. On Stampede3 this reports the failed array size, current MPI
  ranks, Slurm node/task layout, rank RSS, node memory, and an estimated retry
  size in MPI tasks and nodes when the failed array is likely domain-decomposed.
  This estimate is a practical starting point, not a guaranteed resource model.

## Detailed Changes

### Main SCF Workflow

File: `src/parsec.F90`

- Added calls to the migrated FDET field reader and AFM potential writer.
- Broadcast FDET input settings and kinetic-functional parameters.
- Read external sample potential and density data when `potential_field` is
  enabled.
- Added sample ionic and Hartree potentials to the working ionic potential.
- Added the non-additive kinetic potential to the SCF potential update.
- Removed and restored external-field terms around `pot.dat` output so the
  saved file has the expected AFM/FDET format.
- Routed slab-periodic FDET calculations with point charges through the new
  `ewald_slab_pt` routine.
- Passed the potential data structure into nonlocal-force routines so FDET force
  logic can be applied.

Purpose: connect the FDET external field, non-additive kinetic potential, AFM
field output, slab Ewald treatment, and force corrections to the PARSEC 1.5
main calculation flow.

### Data Structures

File: `src/scf/structures.F90`

- Added FDET-related fields to `type potential`, including `vshart`, `vsion`,
  `rho0`, `vnadd`, `fex_is`, `fex_name`, `tnadd`, `kin_name`, `vum`, `vuk`,
  `newke`, and `oldke`.
- Added initialization, allocation, zeroing, and deallocation logic for these
  fields.

Purpose: provide PARSEC 1.5 with persistent storage for frozen-sample fields and
FDET energy/potential terms.

### Input Keywords

Files:

- `src/io/esdf_key_mod.f90`
- `src/io/usrinputfile.F90`

Changes:

- Registered and parsed FDET/AFM input keywords.
- Mapped `kinetic_energy_functional` values to internal kinetic-functional
  choices.
- Added support for PBE-like kinetic-functional parameters `pbe_m` and `pbe_k`.
- Wrote FDET settings into the backup input record.

Purpose: preserve the older AFM/FDET input-file interface while integrating it
with the PARSEC 1.5 input system.

### External Potential I/O

Files:

- `src/potential/potfield.F90`
- `src/io/potsave.F90`

Changes:

- Added `potfield_module` to read external unformatted `pot.dat` files.
- Added `potsave_module` to write AFM/FDET `pot.dat` files.
- Stored and restored sample kinetic energy, atomic coordinates, system flags,
  grid and lattice metadata, symmetry data, ionic potential, Hartree potential,
  XC potential, density, and core density.
- Kept the `stype(10)` record compatible between reader and writer.

Purpose: allow one PARSEC calculation to generate the frozen sample field and a
later FDET tip calculation to consume it.

### Non-additive Kinetic Functional

File: `src/potential/kinetic.f90`

- Added `kinetic_module`.
- Implemented non-additive kinetic-energy and kinetic-potential terms.
- Supported PW91K, PBE-like, Thomas-Fermi, Thomas-Fermi plus gradient expansion,
  and no kinetic correction.
- Adapted gradient and Laplacian use to PARSEC 1.5 interfaces.
- Added safeguards around near-zero or negative density values to reduce the
  risk of invalid GGA denominator calculations.

Purpose: compute `tnadd` and `vnadd`, which are central to the FDET embedding
correction.

### Hartree, XC, and Total Energy

Files:

- `src/potential/hartree.F90`
- `src/potential/exc.f90`
- `src/scf/totnrg.f90`

Changes:

- Added the frozen sample density to the density passed into the XC calculation
  in FDET mode.
- Called the non-additive kinetic-functional routine during XC-potential
  construction.
- Added FDET total-energy correction terms, including non-additive kinetic
  energy and sample/tip interaction components.
- Printed the added FDET energy components in the output.

Purpose: make the energy and potential expressions consistent with the embedded
FDET system rather than a standalone tip-only calculation.

### Forces

Files:

- `src/force/forcloc.f90`
- `src/force/forcnloc.F90`

Changes:

- Added FDET contributions to local-force calculations.
- Used total embedded density where required by FDET local-force expressions.
- Included sample Hartree-potential contributions in slab and wire force paths.
- Passed `pot` into nonlocal-force routines.
- Avoided forcing the total nonlocal force to zero in FDET mode while retaining
  the original behavior for ordinary PARSEC calculations.

Purpose: preserve the FDET AFM force behavior from the older implementation
without changing non-FDET force behavior.

### Slab-periodic Point-charge Ewald Support

File: `src/scf/ewald_slab.f90`

- Added `ewald_slab_pt`.
- Combined real atoms and external point charges in the slab Ewald summation.
- Stored point-charge fractional coordinates locally instead of relying on old
  PARSEC 1.4 data fields that do not exist in PARSEC 1.5.
- Wrote forces back only to real atoms.
- Fell back to ordinary `ewald_slab` behavior when point-charge data is absent.

Purpose: migrate the slab-periodic FDET point-charge branch needed by AFM
simulations.

### Build System

Files:

- `src/Makefile`
- `src/build/module_dependencies.mk`
- `src/build/config/make.stampede3_skx_intel`

Changes:

- Added `kinetic.f90`, `potfield.F90`, and `potsave.F90` to the build.
- Added Fortran module dependency rules for the new modules.
- Updated the Stampede3 Intel configuration with the required FFTW3, MPI,
  ScaLAPACK, HDF5, and collective-communication preprocessor definitions.

Purpose: ensure the migrated FDET/AFM source files are compiled in the correct
order and can be built on Stampede3 with the intended configuration.

## Notes for Users

- A typical FDET tip calculation should provide a valid external `pot.dat` file
  through `potential_field_name`.
- The external `pot.dat` file must be non-empty and compatible with the current
  calculation grid and lattice settings.
- This code path is intended for development and validation work. Users should
  compare against known PARSEC 1.4 FDET/AFM results before using the output for
  production conclusions.
