# PARSEC 1.5 FDET-based AFM Extension

Modified by Dingxin Fan

Date: 2026-07-15

## Added Functionality

This PARSEC 1.5 source tree has been extended to support FDET-based AFM
simulation workflows migrated from the previous PARSEC 1.4 implementation.
The added functionality includes:

- Reading an external frozen-sample potential field from `pot.dat`.
- Writing `pot.dat` from a sample calculation for later AFM/FDET tip
  calculations.
- Carrying frozen-sample quantities in the PARSEC 1.5 potential data structure,
  including sample ionic potential, sample Hartree potential, frozen density,
  non-additive kinetic potential, and non-additive kinetic energy.
- Supporting FDET input keywords:
  - `potential_field`
  - `potential_field_name`
  - `kinetic_energy_functional`
  - `pbe_m`
  - `pbe_k`
- Computing non-additive kinetic-energy contributions using PW91K, PBE-like,
  Thomas-Fermi, Thomas-Fermi plus gradient expansion, or no kinetic correction.
- Adding FDET corrections to the SCF potential, Hartree/XC density handling,
  total-energy expression, and force calculations.
- Supporting slab-periodic FDET calculations with external point charges through
  a slab-specific Ewald branch.
- Updating the PARSEC 1.5 build system so the added FDET/AFM source files are
  compiled with the rest of the code.

## Current Status and Risk Notice

Preliminary tests have passed for the migrated PARSEC 1.5 FDET-based AFM code.
However, this extension is still under development. Users should validate the
code carefully for their own systems and use cases. The user assumes all risks
associated with compiling, running, modifying, or relying on this development
version.

## Detailed Changes

### Main SCF Workflow

File: `src/parsec.F90`

- Added calls to the migrated FDET field reader and AFM potential writer.
- Broadcast FDET input settings and kinetic-functional parameters.
- Read external sample potential and density data when `potential_field` is
  enabled.
- Added sample ionic and Hartree potentials to the working ionic potential.
- Added the non-additive kinetic potential to the SCF potential update.
- Removed and restored external-field terms around `pot.dat` output so the
  saved file has the expected AFM/FDET format.
- Routed slab-periodic FDET calculations with point charges through the new
  `ewald_slab_pt` routine.
- Passed the potential data structure into nonlocal-force routines so FDET force
  logic can be applied.

Purpose: connect the FDET external field, non-additive kinetic potential, AFM
field output, slab Ewald treatment, and force corrections to the PARSEC 1.5
main calculation flow.

### Data Structures

File: `src/scf/structures.F90`

- Added FDET-related fields to `type potential`, including `vshart`, `vsion`,
  `rho0`, `vnadd`, `fex_is`, `fex_name`, `tnadd`, `kin_name`, `vum`, `vuk`,
  `newke`, and `oldke`.
- Added initialization, allocation, zeroing, and deallocation logic for these
  fields.

Purpose: provide PARSEC 1.5 with persistent storage for frozen-sample fields and
FDET energy/potential terms.

### Input Keywords

Files:

- `src/io/esdf_key_mod.f90`
- `src/io/usrinputfile.F90`

Changes:

- Registered and parsed FDET/AFM input keywords.
- Mapped `kinetic_energy_functional` values to internal kinetic-functional
  choices.
- Added support for PBE-like kinetic-functional parameters `pbe_m` and `pbe_k`.
- Wrote FDET settings into the backup input record.

Purpose: preserve the older AFM/FDET input-file interface while integrating it
with the PARSEC 1.5 input system.

### External Potential I/O

Files:

- `src/potential/potfield.F90`
- `src/io/potsave.F90`

Changes:

- Added `potfield_module` to read external unformatted `pot.dat` files.
- Added `potsave_module` to write AFM/FDET `pot.dat` files.
- Stored and restored sample kinetic energy, atomic coordinates, system flags,
  grid and lattice metadata, symmetry data, ionic potential, Hartree potential,
  XC potential, density, and core density.
- Kept the `stype(10)` record compatible between reader and writer.

Purpose: allow one PARSEC calculation to generate the frozen sample field and a
later FDET tip calculation to consume it.

### Non-additive Kinetic Functional

File: `src/potential/kinetic.f90`

- Added `kinetic_module`.
- Implemented non-additive kinetic-energy and kinetic-potential terms.
- Supported PW91K, PBE-like, Thomas-Fermi, Thomas-Fermi plus gradient expansion,
  and no kinetic correction.
- Adapted gradient and Laplacian use to PARSEC 1.5 interfaces.
- Added safeguards around near-zero or negative density values to reduce the
  risk of invalid GGA denominator calculations.

Purpose: compute `tnadd` and `vnadd`, which are central to the FDET embedding
correction.

### Hartree, XC, and Total Energy

Files:

- `src/potential/hartree.F90`
- `src/potential/exc.f90`
- `src/scf/totnrg.f90`

Changes:

- Added the frozen sample density to the density passed into the XC calculation
  in FDET mode.
- Called the non-additive kinetic-functional routine during XC-potential
  construction.
- Added FDET total-energy correction terms, including non-additive kinetic
  energy and sample/tip interaction components.
- Printed the added FDET energy components in the output.

Purpose: make the energy and potential expressions consistent with the embedded
FDET system rather than a standalone tip-only calculation.

### Forces

Files:

- `src/force/forcloc.f90`
- `src/force/forcnloc.F90`

Changes:

- Added FDET contributions to local-force calculations.
- Used total embedded density where required by FDET local-force expressions.
- Included sample Hartree-potential contributions in slab and wire force paths.
- Passed `pot` into nonlocal-force routines.
- Avoided forcing the total nonlocal force to zero in FDET mode while retaining
  the original behavior for ordinary PARSEC calculations.

Purpose: preserve the FDET AFM force behavior from the older implementation
without changing non-FDET force behavior.

### Slab-periodic Point-charge Ewald Support

File: `src/scf/ewald_slab.f90`

- Added `ewald_slab_pt`.
- Combined real atoms and external point charges in the slab Ewald summation.
- Stored point-charge fractional coordinates locally instead of relying on old
  PARSEC 1.4 data fields that do not exist in PARSEC 1.5.
- Wrote forces back only to real atoms.
- Fell back to ordinary `ewald_slab` behavior when point-charge data is absent.

Purpose: migrate the slab-periodic FDET point-charge branch needed by AFM
simulations.

### Build System

Files:

- `src/Makefile`
- `src/build/module_dependencies.mk`
- `src/build/config/make.stampede3_skx_intel`

Changes:

- Added `kinetic.f90`, `potfield.F90`, and `potsave.F90` to the build.
- Added Fortran module dependency rules for the new modules.
- Updated the Stampede3 Intel configuration with the required FFTW3, MPI,
  ScaLAPACK, HDF5, and collective-communication preprocessor definitions.

Purpose: ensure the migrated FDET/AFM source files are compiled in the correct
order and can be built on Stampede3 with the intended configuration.

## Notes for Users

- A typical FDET tip calculation should provide a valid external `pot.dat` file
  through `potential_field_name`.
- The external `pot.dat` file must be non-empty and compatible with the current
  calculation grid and lattice settings.
- This code path is intended for development and validation work. Users should
  compare against known PARSEC 1.4 FDET/AFM results before using the output for
  production conclusions.
