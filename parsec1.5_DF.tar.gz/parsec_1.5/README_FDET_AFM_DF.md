# PARSEC 1.5 FDET-based AFM Extension

Modified by Dingxin Fan

Date: 2026-07-15

Updated: 2026-07-19

## Added Functionality

This PARSEC 1.5 source tree has been extended to support FDET-based AFM
simulation workflows migrated from the previous PARSEC 1.4 implementation.
The added functionality includes:

- Reading an external frozen-sample potential field from `pot.dat`.
- Writing `pot.dat` from a sample calculation for later AFM/FDET tip
  calculations.
- Carrying frozen-sample quantities in the PARSEC 1.5 potential data structure,
  including sample ionic potential, sample Hartree potential, frozen density,
  non-additive kinetic potential, and non-additive kinetic energy.
- Supporting FDET input keywords:
  - `potential_field`
  - `potential_field_name`
  - `kinetic_energy_functional`
  - `pbe_m`
  - `pbe_k`
- Computing non-additive kinetic-energy contributions using PW91K, PBE-like,
  Thomas-Fermi, Thomas-Fermi plus gradient expansion, or no kinetic correction.
- Adding FDET corrections to the SCF potential, Hartree/XC density handling,
  total-energy expression, and force calculations.
- Supporting slab-periodic FDET calculations with external point charges through
  a slab-specific Ewald branch.
- Updating the PARSEC 1.5 build system so the added FDET/AFM source files are
  compiled with the rest of the code.

## Current Status and Risk Notice

Preliminary tests have passed for the migrated PARSEC 1.5 FDET-based AFM code.
However, this extension is still under development. Users should validate the
code carefully for their own systems and use cases. Users use it at their own
risk.

## Stability Updates

The following stability-oriented updates were added after reviewing occasional
SCF hangs and MPI-layout-dependent behavior:

- The FDET `pot.dat` reader now checks unformatted-file read errors with
  `iostat` and broadcasts the error code, so missing, empty, corrupt, or
  incompatible external field files should exit cleanly instead of leaving
  non-master MPI ranks waiting.
- The FDET external field filename is now broadcast together with the other FDET
  settings.
- The non-additive kinetic-energy interface no longer passes the whole
  `potential` object while also writing components of the same object. This
  avoids compiler- and optimization-sensitive aliasing/intent behavior.
- The SCF loop now prints and flushes progress markers before and after
  `eigval()`, making it easier to identify whether a run is hanging inside the
  eigensolver/MatVec path.
- `eigval()` now rounds the internal `mxstate` work size up to a multiple of
  `npcol` instead of failing immediately when the requested work size is not
  divisible by the column-group count.
- The input parser now stops immediately if the total MPI process count is not
  divisible by `npcol`, preventing invalid processor-group layouts from reaching
  the SCF/eigensolver stage.
- With ScaLAPACK enabled, `states_num` is rounded up to a valid
  `npcol*scalapack_block_size` multiple instead of requiring manual edits for
  every MPI layout.
- The Stampede3 Intel build configuration now enables `STABLE_ALLTOALLV`.
  This keeps the existing packed neighbor buffers but sends them through
  rank-indexed `MPI_Ialltoallv` on the normal column-group communicator, avoiding
  MPI distributed-graph neighborhood collectives in the SCF/MatVec path.
- The folded/block MatVec buffer now packs data using the folded communication
  neighbor list (`c_sources`) instead of the regular-grid neighbor list
  (`sources`), avoiding a source-list mismatch when the two communication graphs
  differ.
- Memory allocation failures now print resource guidance through the common
  `alccheck` path. On Stampede3 this reports the failed array size, current MPI
  ranks, Slurm node/task layout, rank RSS, node memory, and an estimated retry
  size in MPI tasks and nodes when the failed array is likely domain-decomposed.
  This estimate is a practical starting point, not a guaranteed resource model.

## Detailed Changes

### Main SCF Workflow

File: `src/parsec.F90`

- Added calls to the migrated FDET field reader and AFM potential writer.
- Broadcast FDET input settings and kinetic-functional parameters.
- Read external sample potential and density data when `potential_field` is
  enabled.
- Added sample ionic and Hartree potentials to the working ionic potential.
- Added the non-additive kinetic potential to the SCF potential update.
- Removed and restored external-field terms around `pot.dat` output so the
  saved file has the expected AFM/FDET format.
- Routed slab-periodic FDET calculations with point charges through the new
  `ewald_slab_pt` routine.
- Passed the potential data structure into nonlocal-force routines so FDET force
  logic can be applied.

Purpose: connect the FDET external field, non-additive kinetic potential, AFM
field output, slab Ewald treatment, and force corrections to the PARSEC 1.5
main calculation flow.

### Data Structures

File: `src/scf/structures.F90`

- Added FDET-related fields to `type potential`, including `vshart`, `vsion`,
  `rho0`, `vnadd`, `fex_is`, `fex_name`, `tnadd`, `kin_name`, `vum`, `vuk`,
  `newke`, and `oldke`.
- Added initialization, allocation, zeroing, and deallocation logic for these
  fields.

Purpose: provide PARSEC 1.5 with persistent storage for frozen-sample fields and
FDET energy/potential terms.

### Input Keywords

Files:

- `src/io/esdf_key_mod.f90`
- `src/io/usrinputfile.F90`

Changes:

- Registered and parsed FDET/AFM input keywords.
- Mapped `kinetic_energy_functional` values to internal kinetic-functional
  choices.
- Added support for PBE-like kinetic-functional parameters `pbe_m` and `pbe_k`.
- Wrote FDET settings into the backup input record.

Purpose: preserve the older AFM/FDET input-file interface while integrating it
with the PARSEC 1.5 input system.

### External Potential I/O

Files:

- `src/potential/potfield.F90`
- `src/io/potsave.F90`

Changes:

- Added `potfield_module` to read external unformatted `pot.dat` files.
- Added `potsave_module` to write AFM/FDET `pot.dat` files.
- Stored and restored sample kinetic energy, atomic coordinates, system flags,
  grid and lattice metadata, symmetry data, ionic potential, Hartree potential,
  XC potential, density, and core density.
- Kept the `stype(10)` record compatible between reader and writer.

Purpose: allow one PARSEC calculation to generate the frozen sample field and a
later FDET tip calculation to consume it.

### Non-additive Kinetic Functional

File: `src/potential/kinetic.f90`

- Added `kinetic_module`.
- Implemented non-additive kinetic-energy and kinetic-potential terms.
- Supported PW91K, PBE-like, Thomas-Fermi, Thomas-Fermi plus gradient expansion,
  and no kinetic correction.
- Adapted gradient and Laplacian use to PARSEC 1.5 interfaces.
- Added safeguards around near-zero or negative density values to reduce the
  risk of invalid GGA denominator calculations.

Purpose: compute `tnadd` and `vnadd`, which are central to the FDET embedding
correction.

### Hartree, XC, and Total Energy

Files:

- `src/potential/hartree.F90`
- `src/potential/exc.f90`
- `src/scf/totnrg.f90`

Changes:

- Added the frozen sample density to the density passed into the XC calculation
  in FDET mode.
- Called the non-additive kinetic-functional routine during XC-potential
  construction.
- Added FDET total-energy correction terms, including non-additive kinetic
  energy and sample/tip interaction components.
- Printed the added FDET energy components in the output.

Purpose: make the energy and potential expressions consistent with the embedded
FDET system rather than a standalone tip-only calculation.

### Forces

Files:

- `src/force/forcloc.f90`
- `src/force/forcnloc.F90`

Changes:

- Added FDET contributions to local-force calculations.
- Used total embedded density where required by FDET local-force expressions.
- Included sample Hartree-potential contributions in slab and wire force paths.
- Passed `pot` into nonlocal-force routines.
- Avoided forcing the total nonlocal force to zero in FDET mode while retaining
  the original behavior for ordinary PARSEC calculations.

Purpose: preserve the FDET AFM force behavior from the older implementation
without changing non-FDET force behavior.

### Slab-periodic Point-charge Ewald Support

File: `src/scf/ewald_slab.f90`

- Added `ewald_slab_pt`.
- Combined real atoms and external point charges in the slab Ewald summation.
- Stored point-charge fractional coordinates locally instead of relying on old
  PARSEC 1.4 data fields that do not exist in PARSEC 1.5.
- Wrote forces back only to real atoms.
- Fell back to ordinary `ewald_slab` behavior when point-charge data is absent.

Purpose: migrate the slab-periodic FDET point-charge branch needed by AFM
simulations.

### Build System

Files:

- `src/Makefile`
- `src/build/module_dependencies.mk`
- `src/build/config/make.stampede3_skx_intel`

Changes:

- Added `kinetic.f90`, `potfield.F90`, and `potsave.F90` to the build.
- Added Fortran module dependency rules for the new modules.
- Updated the Stampede3 Intel configuration with the required FFTW3, MPI,
  ScaLAPACK, HDF5, and collective-communication preprocessor definitions.

Purpose: ensure the migrated FDET/AFM source files are compiled in the correct
order and can be built on Stampede3 with the intended configuration.

## Notes for Users

- A typical FDET tip calculation should provide a valid external `pot.dat` file
  through `potential_field_name`.
- The external `pot.dat` file must be non-empty and compatible with the current
  calculation grid and lattice settings.
- This code path is intended for development and validation work. Users should
  compare against known PARSEC 1.4 FDET/AFM results before using the output for
  production conclusions.

## Optional: tip sphere (`boundary_sphere_around_tip`, 2026-10-19)

PARSEC default `false`: nothing changes. PARSEC Tools turns it on by default for
HR-AFM (System Builder option, can be switched off). With `true` in a tip input that also has
`potential_field true`, the tip is computed in its own small cluster sphere
(`boundary_sphere_radius` of the tip input, e.g. 8.95 bohr = 7.5 bohr of vacuum
around the CO tip) instead of the large sphere of the sample run. Code:
`src/potential/fdet_tipsphere.F90` plus small hooks in `parsec.F90`, `totnrg.f90`,
`usrinputfile.F90` and `esdf_key_mod.f90`, all inside `if (tipsphere_on)`.

How it works
- The tip atoms and the sample point charges are moved by a whole number of grid
  steps S so that the tip centre is within half a step of the origin. When the
  tip moves (`minimization manual`, coordinates still in the sample frame), S is
  updated instead, so the tip stays on the same grid points and its density and
  orbitals are reused without translation.
- `pot.dat` (same grid spacing, no grid shift, no symmetry) is read once. Tip grid
  point k gets the sample potential and density of sample grid point k + S
  (exact copy). Points outside the sample sphere get zero.
- Total energy: E_xc[rho_sample] on the tip grid is subtracted (only the
  non-additive xc energy remains), the sample-only terms (sample Hartree, sample
  electron-ion, sample kinetic energy) are left out, and the attraction between
  the tip ions and the sample electrons outside the tip sphere is added from the
  whole sample grid with point ions (-2Z/r). T_nad is unchanged.

Errors this introduces (compared with the large sphere)
1. The total energy differs from the large-sphere value by a constant (the
   sample-only terms). Only energy differences are meaningful.
2. Every scan point has only the tip-sphere vacuum around the tip. The large
   sphere gives more vacuum near the scan centre. For benzene the energy shift
   from 8.95 to 10.5 bohr is 7.5e-5 Ry and the same at all heights (k_ts changes
   by less than 3e-4 eV/A^2, within SCF noise).
3. E_xc^nad and T_nad are integrated over the tip sphere only. Exact where the
   tip density is zero, so the error scales with the tip density at the sphere
   surface (T_nad changed by 1e-5 Ry between 8.95 bohr and the large sphere).
4. Outside the tip sphere the tip ions act on the sample electrons as point ions.
   Exact beyond the pseudopotential cut-off (those points are more than 7 bohr
   from the tip atoms).
5. The tip Hartree boundary values come from the multipole expansion on the small
   sphere.
6. Sample potential and density beyond the sample sphere are set to zero (only if
   the tip sphere reaches outside the sample sphere; the output reports the count).
   PARSEC Tools makes the sample sphere large enough that this never happens.
7. The local forces miss the sample electrons outside the tip sphere. Forces are
   not used by the HR-AFM workflow.

Benzene test (PBE, grid 0.4, line of 12 points x 3 heights, SRE 5e-5): energy
profiles agree with the large sphere to 4e-6 Ry, k_ts to 3e-4 eV/A^2 (0.2% of the
k_ts range). Tip grid 46,897 instead of 397,079 points. Cold start 7.7 s instead of
112 s, warm-started points 5-6 s instead of 43-60 s. Files: Claude outputs/tipsphere-test.

Full 2D benzene image (12 x 13 points x 3 heights, SRE 2e-4, 3 processes at once):
large sphere 88 min, tip sphere 7.7 min. k_ts differs by at most 0.94 meV/A^2
(rms 0.26) on an image range of 19 to 280 meV/A^2, largest at the scan edges.
The app workflow (sample sphere 18.96 bohr, no missing points, 6 processes) took
6.9 min in total and gives the same differences. Figures: PARSEC Tools User Guide,
Benchmarks section.

## Tip sphere with slab samples (2026-10-20)

The tip sphere now also accepts a `pot.dat` from a slab spot run
(`boundary_conditions slab`). Only `src/potential/fdet_tipsphere.F90` changed.
Cluster runs give the same energies as before (benzene tip point
-43.41194930 Ry). PARSEC Tools 0.1.29 and later use this for HR-AFM of slabs.

Requirements (the run stops with the error code in brackets otherwise)
- The cell is orthogonal with the lattice vectors along x and y (627).
- The grid spacing is the same in x, y and z (626), and the cell length is a
  whole number of grid steps (628). Choose the grid spacing as the cell length
  divided by an even number and write it with enough digits (12 decimals), since
  PARSEC fits the in-plane spacing to the cell.
- The tip input keeps the sample point charges (630). They give the positions
  and charges of the sample ions.
- The `pot.dat` grid covers exactly one cell in x and y (629).
- Keep the tip sphere inside the z range of `pot.dat`. Tip grid points beyond
  it get zero sample potential and density, as for clusters.
- The tip runs themselves stay `boundary_conditions cluster`.

Periodic boundary conditions
- Tip grid point k reads the sample potential and density of spot grid point
  k + S, with x and y taken modulo the cell (k -> lo + mod(k - lo, N)). The tip
  sphere may therefore cross the cell edge. There is no periodicity in z.

Long-range term (2D Ewald sum)
- Outside the tip sphere the tip ions feel the sample through
  E_long = sum_t Z_t V'(R_t). V' is the periodic potential of all sample ions
  (point charges) and of the sample valence density of `pot.dat` (a charge
  -rho h^3 on every grid point), less the density inside the tip sphere, which
  already acts on the tip through the true pseudopotential.
- 1/r = erfc(alpha r)/r + erf(alpha r)/r with alpha = 5/L. The first part is
  summed in real space over the cell and its neighbours (5 x 5 cells, cut at
  r = 6/alpha). The second part is summed in reciprocal space over
  G = 2 pi (m1, m2)/L with |m| <= 12, plus the G = 0 sheet term. The density
  enters plane by plane through S_z(G) = sum rho h^3 exp(-i G.r), computed once
  from `pot.dat`.
- The cell is neutral, so the sum is well defined. Two values of alpha are used
  and both printed. They agree to 10 digits. A plain sum over images is still
  about 14 Ry off after 6 shells.
- tipsphere_eout = E_long - E_ii(one cell), because PARSEC already adds the
  one-cell tip-ion / sample-ion energy for the point charges.

NaCl(100) test (4-layer slab, 2 x 2 surface cell, a = 5.78 A, PBE, grid
0.405 bohr, CO tip with 8.95 bohr sphere)
- Against the same tip computed in the full slab cell (legacy slab FDET, line
  Cl - Na - Cl, O at 2.92, 3.13 and 3.35 A): energy profiles agree within
  0.05 meV and k_ts within 0.3% of the image range. A 9.95 bohr tip sphere
  changes k_ts by less than 0.07% of the range.
- Time per tip point about 4.6 s instead of about 4 min in the full slab cell.
- Full image in PARSEC Tools (3 heights x 27 x 27 = 2187 points, 6 processes on
  an 8-core laptop): tip scan 30 min, no point without `pot.dat` data.
