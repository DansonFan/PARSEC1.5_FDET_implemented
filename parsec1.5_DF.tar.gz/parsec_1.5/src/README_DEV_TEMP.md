# PARSEC KNL INTERNAL VERSION #

Date: June 01 2016
Developer in charge: AJB

    WARNING: This version is strictly for development purposes and is not
    to be used for any production calculation!

    WARNING 2: Interface to matvec subject to change. Consult with me if adding on to this.

## Contents ##

 * COMPILING
 * RUNNING
 * WHAT IS THIS VERSION
 * WHAT DOES NOT WORK
 * WHAT WAS NOT TESTED YET
 * NEXT FEW CHANGES TO COME

## COMPILING ##
    

    config files are placed in config/ and have the filename format make.config_name
    compile using - 

    make MACH=config_name -j8 
    
    If compiling on a KNL node you might want to use make.knl_trace_mpi3

    make MACH=knl_trace_mpi3 -j8

    There are optimization flags missing but I've added xHost which should be
    okay if you are compiling on a knl.

## RUNNING  ##

    TBD. openMP settings that I use are found on FLAGS_OMP.sh in the tools folder.

## WHAT IS THIS VERSION ##

    This version contains my new designs to PARSEC's grid partition, stencil
    operations, matvec, and thread-level low-overhead trace-analyzer instrumentation.

### 1. Grid partitioning  ####
   
    The computational domain is mapped to an approximation of a
    space-filling-curve (SFC) Rather than mapping each grid point to a point on
    the SFC, we map each block of points, thus we are already complacent with
    vector-folding. This actually quite well for load balancing and almost x2
    better in terms of communication avoidance for large systems than the
    alternatives that I tried. There is a separate branch that has just the SFC which works
    also with most symmetries.

### 2. Stencil operations ####

    The old stencils were simply not using the L2 cache, so there was much to
    be done.  In this version we break away from the common "stencil pattern"
    and use a pure graph method, where the operation Psi(R0)+=C_n*Psi(R0+n*h)
    (which is a stencil element) is treated as the base operation, but
    to actually use cache lines and the vector lanes, we take a hint from the
    vector folding book and treat whole SFC blocks (see 1 above) at a time.
    Each such operation is an edge on the graph, and we treat all edges that
    originate from the same vertex (block of grid point to be written to) using
    the same thread. This way we do not have to use mutex/locking at all!
    The graph edges that are external to the MPI process are labled with their
    point of origin as well (block of grid point to be written to). Owing to
    the high locality of the SFC, there are very few cases where there is more
    than a couple of external edges per grid block. 

    Right now, the edge traversal itself is not done using the cool
    vector-folding-blending, but using a simple mkl matrix-vector product
    (BLAS2). This incurs roughly x4 floating point operations than we actually need
    because of explicit multiplications by zero.

### 3. MATVEC ####

    Matvec (PARSEC's main kernel) is now task based, and uses tasks with
    dependencies instead of "parallel do", which enables us to remove k-1
    openmp barriers, where k is the number of vectors processed at a single
    matvec call (the block size).  There is still tuning work to be done with
    respect to the task grain size, we specifically do not use the new taskloop
    openmp construct because it is uncertain when gfortran is going to get
    support for that...

### 4. Trace-analyzer  ####
 
    If you have not used intel trace-analyzer yet, go ahead and use it - it is amazing.
    Using the special API you can access thread-level information about
    execution of parsec and understand which thread is doing what, and when.


## WHAT (definitely) DOES NOT WORK ##

    1. Symmetry. I have plans to add this on in the next few months, but first I
       need to finalize the stencil operations. PARSEC will try to complain, but it will most probably just crash.

    2. Non cubic grids (extra lap directions). I think I know how to add these, but
       prefer to first finalize the stencil operations. I think here I made sure PARSEC will complain

    3. Arbitrary grid fold sizes - I do not know if we ever will allow this.

    4. DFT+U, Spin-orbit - New matvec operator does not support these yet

## WHAT WAS NOT TESTED YET ##

    5. PBC in less than 3d
    6. MPI2 - isend/irecv ghost-exchange, and regular allreduce in matvec.
    7. Other stuff maybe?

## NEXT FEW CHANGES NEEDED ##

    2. Several fold/block sizes to choose from (complex/real should have different fold size)
    3. non cubic grids (because I want to do fcc silicon :P )

