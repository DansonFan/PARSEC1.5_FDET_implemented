module grid_partition_module

implicit none
contains

!==================================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  \todo AJB: rewrite explanation here
!  Define the distribution of grid points among processors so
!  that each one receives the same number of points (or the
!  difference in number of points held by all processors is at
!  most one).
!
!-------------------------------------------------------------------
subroutine grid_partition(grid, pbc, rsymm, parallel, ierr)

use constants
use grid_module
use sfc_module
use pbc_module
use symmetry_module
use symmetry_routines, only : symop
use parallel_data_module
use psum_module, only : pisum

implicit none

!
!  Input/Output variables:
!

!  grid related data
type(grid_data), intent(inout) :: grid

!  periodic boundary conditions data
type(pbc_data), intent(inout) :: pbc

!  symmetry operations in reduced (Abelian) group
type(symmetry), intent(in) :: rsymm

!  parallel computation related data
type(parallel_data), intent(inout) :: parallel

!  error flag, 270 < ierr < 281
integer, intent(out) :: ierr

!
!  Work variables:
!

integer, dimension(1) :: ierrvec

!  cutoff radius used in the determination of grid points
real(dp) :: rcutsqr

!  number of neighbors used for derivation (on one side)
integer :: sten_depth

!  actual size of hamiltonian, dimension of grid arrays
integer :: ndim
integer :: ldn

!  bounds of grid along each direction
integer :: nxmin, nxmax, nymin, nymax, nzmin, nzmax

!  variable for distance between points, maximum distance
real(dp) :: dist, distsqr, dmax

!  temporary 1-d index of each point
integer :: nef

!  counters
integer ii,jj,i,j,k,j00,k00,ny1,ny2,nz1,nz2,iold

!  variables for the irreducible wedge
integer itrans, ir(3), nwedge,nwedge_new,nwedge_c
integer, dimension (:), allocatable :: itest

!  Cartesian coordinates of a grid point and its equivalent one
real(dp) :: rr(3), rw(3)

!  arrays for irreducible wedge
integer, allocatable :: ninv(:),rinv(:,:)

!  number of procs available
integer nnodes

!  processor rank
integer inode

!  Indexing of distributed blocks
integer irows(0:parallel%group_size), cirows(0:parallel%group_size)

!  maximum number of FFT grid points (to be stored in pbc structure)
integer maxdfft

!  allocation check
integer alcstat

! grid limits - defines lower and upper limits of the grid for
! calculation of wrap around values
integer :: grid_limits(3,6)
!
! gwrap holds values of wrap around offset for the grid
integer :: gwrap(3), gwrap2(3)

! idx1 is a temporary array that holds calculated grid_limits
integer :: idx1(3,2), idx2(3,2)

!
! General purpose index:
integer ::  IND

! extra padding:
integer :: boxsides_x, boxsides_y, boxsides_z,box_vol
integer :: xtraPADx,xtraPADy,xtraPADz

! temporary 1d->3d conversion arrays, sfc,coarse and fine
integer, dimension(:), allocatable :: fx_sfc, fy_sfc, fz_sfc
integer, dimension (:), allocatable :: fx_tmp,fy_tmp,fz_tmp
integer, dimension (:), allocatable :: kx_tmp,ky_tmp,kz_tmp
integer, dimension (:), allocatable :: cx_tmp,cy_tmp,cz_tmp
integer, dimension (:), allocatable :: kcx_tmp,kcy_tmp,kcz_tmp

! helper arrays for mapping in block_sfc 
integer, dimension (:), allocatable :: coarse_map,indmapx,indmapy,indmapz
integer, dimension (:), allocatable :: fx_cxp,fy_cxp,fz_cxp

! map between actual conversion arrays and original space-filling-curve
integer, dimension (:), allocatable :: f2sfc_tmp
integer, dimension (:), allocatable :: c2sfc_tmp

!map between coarse and fine conversion arrays
integer, dimension (:), allocatable :: c2f_tmp 

! map between the irreducble wedge and the coarse grid
integer, dimension (:), allocatable :: c2k_tmp 

! various temporary vectors
integer, dimension (:), allocatable :: iblock,jblock,kblock

! temporary indexes
integer :: f_sfc, f_tmp, c_tmp, fold_ind
logical :: any_inside 

! helper
integer :: num_new_points !for symmetry checking inside folds

! keep a local copy of the fold
type(foldblock) :: fold

! Partitioning temporaries:
integer :: remainder_parts, average_part_dim

! space filling curve stuff:
integer :: sfc_order
integer, dimension(3) :: bottom_shift
real(dp) :: sfc_order_temp
integer, parameter :: sfc_MAX = 10


! -------------------------------------------------------------------

ierr = 0
nnodes = parallel%nprow
sten_depth = grid%norder !problem here, see below




!
!  NEW PART I - GRID SETUP AND CREATION
!
!  \todo AJB: rewrite the following, it was outdated already 10 years ago
!  determine minimal number of mesh points (per each axis, per
!  each side of origin) that would encompass a sphere of size rmax
!  (confined system), or a box of side rmax (periodic system)
!  inside which is a grid with a spacing of h. Note that for a
!  periodic system rmax is the WHOLE side of the box, not half of
!  it, so it's really comparable to the diameter of the sphere!

! \todo AJB:
! I have a local copy of the fold as well for clarity, but since 
! I am not a strong fortran programmer
! so the assignment does not copy everything cleanly. 
call fold%initalize()
call fold%duplicate(grid%fold)

write(9,*) "grid partition development messages::"
write(9,*) "The fold vectors:"
write(9,'("foldvec:",I5,I5,I5)') &
        (fold%foldx(IND),fold%foldy(IND),fold%foldz(IND),IND=1,fold%volume)

write(9,*) "rmax=", grid%rmax
write(9,*) "rmax/step(1)", (grid%rmax/grid%step(1))
write(9,*) "rmax/max(step)", (grid%rmax/maxval(grid%step(:)))
write(9,*) "nint(rmax/step)", nint(grid%rmax/grid%step(1))
write(9,*) "nint(rmax/max(step))", nint(grid%rmax/maxval(grid%step(:)))


!\todo AJB: note, integer math. This should be tranfsered to the new bbox type
nxmin = -grid%n1/2
nxmax =  grid%n1 + nxmin - 1
nymin = -grid%n2/2
nymax =  grid%n2 + nymin - 1
nzmin = -grid%n3/2
nzmax =  grid%n3 + nzmin - 1
write(9,*) "initial grid size based on grid spacing and domain input: "
write(9,*) "nxmin nymin nzmin", nxmin, nymin, nzmin
write(9,*) "nxmax nymax nzmax", nxmax, nymax, nzmax

! We will be creating indexg and indexw with padding (2*sten_depth):
nxmax = nxmax + sten_depth
nxmin = nxmin - sten_depth
nymax = nymax + sten_depth
nymin = nymin - sten_depth
nzmax = nzmax + sten_depth
nzmin = nzmin - sten_depth
write(9,*) "just padded for stencil depth", sten_depth
write(9,*) "nxmin nymin nzmin", nxmin, nymin, nzmin
write(9,*) "nxmax nymax nzmax", nxmax, nymax, nzmax

! NEW: We also add padding so that there is integer amount of fold blocks
! For PBC we actually have to change adjust_step so that the domain itself
! has an integer amount of fold blocks inside
boxsides_x = nxmax - nxmin + 1
boxsides_y = nymax - nymin + 1
boxsides_z = nzmax - nzmin + 1

if (sum(fold%blocksize(:)) /= 3) then
        write(9,*) "Adding padding for the fold/block size!"
        ! if pbc is on for the direction, we will not be
        ! using symmetry to reduce grid, so padding will
        ! be added to top*. This way we can make sure the
        ! computational domain is exactly the unit cell.
        ! if pbc is off, we need to make sure that the
        ! 0,0,0 is the bottom left point of its block
        ! otherwise we can't use symmetry

        ! *note - we can do it in some other way, but
        ! there are already conventions within the code
        ! regarding n[xyz]{min,max} in pbc

        if (pbc%per >= 1) then
                if (mod(boxsides_x,fold%blocksize(1)) /= 0) then
                        xtraPADx = fold%blocksize(1) - &
                                mod(boxsides_x,fold%blocksize(1))

                        write(9,*) "xtraPADx:", xtraPADx
                else
                        xtraPADx = 0
                endif

                nxmax = nxmax + xtraPADx
        else
                xtraPADx = fold%blocksize(1) - &
                        mod(boxsides_x,fold%blocksize(1))

                write(9,*) "xtraPADx:", xtraPADx

                nxmin = nxmin - xtraPADx

                if (mod(nxmin,2) /= 0) then
                        nxmin = nxmin + 1
                        nxmax = nxmax + 1
                endif
        endif

        if (pbc%per >= 2) then
                if (mod(boxsides_y,fold%blocksize(2)) /= 0) then
                        xtraPADy = fold%blocksize(2) - &
                                mod(boxsides_y,fold%blocksize(2))

                        write(9,*) "xtraPADy:", xtraPADy
                else
                        xtraPADy = 0
                endif

                nymax = nymax + xtraPADy
        else
                xtraPADy = fold%blocksize(2) - &
                        mod(boxsides_y,fold%blocksize(2))

                write(9,*) "xtraPADy:", xtraPADy

                nymin = nymin - xtraPADy

                if (mod(nymin,2) /= 0) then
                        nymin = nymin + 1
                        nymax = nymax + 1
                endif
        endif

        if (pbc%per == 3) then
                if (mod(boxsides_z,fold%blocksize(3)) /= 0) then
                        xtraPADz = fold%blocksize(3) - &
                                mod(boxsides_z,fold%blocksize(3))

                        write(9,*) "xtraPADz:", xtraPADz
                else
                        xtraPADz = 0
                endif

                nzmax = nzmax + xtraPADz
        else
                xtraPADz = fold%blocksize(3) - &
                        mod(boxsides_z,fold%blocksize(3))

                write(9,*) "xtraPADz:", xtraPADz

                nzmin = nzmin - xtraPADz

                if (mod(nzmin,2) /= 0) then
                        nzmin = nzmin + 1
                        nzmax = nzmax + 1
                endif
        endif
endif

write(9,*) "setting the padded domain bounding box"
call grid%bbox_pad%set(nxmin, nymin, nzmin, nxmax, nymax, nzmax)

write(9,*) "bbox_pad details:"
write(9,*) "bbox_pad%box_min::", grid%bbox_pad%box_min
write(9,*) "bbox_pad%box_max::", grid%bbox_pad%box_max
write(9,*) ""

!!! SFC stuff !!!
if (fold%volume == 1) then
        if (sum(grid%bbox_pad%box_sides) /= 3*grid%bbox_pad%box_sides(1)) then
                write(9,*) "SFC:: cannot use SFC if padded bounding box &
                        &is not cubic"
                sfc_order = 999
        else
                sfc_order_temp = real(grid%bbox_pad%box_sides(1)**3,dp)
                write(9,*) "sfc tmp stage 1 - sides^3", sfc_order_temp
                sfc_order_temp = ceiling(log(sfc_order_temp)/log(eight))
                write(9,*) "sfc tmp stage 2 - ceil(log8)", sfc_order_temp
                sfc_order = nint(sfc_order_temp)
                write(9,*) "sfc tmp stage 3 - integer", sfc_order
        endif
else
        !using block_sfc
        sfc_order_temp = ceiling(maxval(log(real( &
                grid%bbox_pad%box_sides(:)/fold%blocksize(:),dp))/log(two)))
        sfc_order = nint(sfc_order_temp)
endif

if (grid%use_sfc) then
        write(9,*) "use_sfc is on"

        if (sfc_order <= sfc_MAX) then
                write(9,*) "SFC:: sfc order is", sfc_order
                grid%use_sfc = .TRUE.
        else
                write(9,*) "SFC :: cannot use SFC, order= ", sfc_order
                grid%use_sfc = .FALSE.
        endif
else
        write(9,*) "use_sfc is off"
endif



call grid_set_index(nxmin, nxmax, nymin, nymax, nzmin, nzmax, grid)






! Deal with the FFT box for pbc calculations:

! \note NOTE, This adds a different padding of 1*sten_depth (see above).
! Makes you wonder if sten_depth was once norder/2. This should be checked. 
!
! KHL: need to check the parallel%iammaster here
if (pbc%is_on .and. parallel%iammaster) then
        !maxdfft = (pbc%n1 + grid%norder)*(pbc%n2 + grid%norder)*(pbc%n3 + grid%norder)
        !then what happens if I do this instead?
        maxdfft = (pbc%n1 + 0*grid%norder) * &
                  (pbc%n2 + 0*grid%norder)* &
                  (pbc%n3 + 0*grid%norder)
        call pbc_set_maxdfft(maxdfft, pbc)
endif








! KHL: After we get fx_sfc(:) contains the indices of 
!      the grid points (the order we got from the above is the order
!      of the coarse grid, so (order+1) is the order of the real grid). 
!      For example, if order is 6, the indices of the intermediate grid 
!      along x spans [-63, 64], and the final grid, fx_sfx(:), is 
!      perhaps [-32, 33], depending on the size of the padded box.
call generate_grid_point_index_v1()
!call generate_grid_point_index_v2()








call grid%bbox_sfc%from_3vec(fx_sfc(:), fy_sfc(:), fz_sfc(:), &
        from=1, to=box_vol)

write(9,*) "bbox_sfc details:"
write(9,*) "bbox_sfc%box_min::", grid%bbox_sfc%box_min
write(9,*) "bbox_sfc%box_max::", grid%bbox_sfc%box_max
write(9,*) ""
  

! write(9,*) "The sfc 3vec:"
! write(9,'(I5,I5,I5)') (fx_sfc(IND),fy_sfc(IND),fz_sfc(IND),IND=1,box_vol)

! Resort to the orignal number without padding, this is important for later
nxmin = -grid%n1/2
nxmax =  grid%n1 + nxmin - 1
nymin = -grid%n2/2
nymax =  grid%n2 + nymin - 1
nzmin = -grid%n3/2
nzmax =  grid%n3 + nzmin - 1

! and also recalculate - this is without padding:
write(9,*) "setting the non-padded domain bounding box"
call grid%bbox_domain%set(nxmin, nymin, nzmin, nxmax, nymax, nzmax)
write(9,*) "Compare sides in bboxes:"
write(9,*) "bbox_domain sides:", grid%bbox_domain%box_sides
write(9,*) "bbox_pad sides:", grid%bbox_pad%box_sides
write(9,*) "bbox_sfc sides:", grid%bbox_sfc%box_sides





! \todo AJB: update this
!  Assign spatial coordinates (x,y,z) to each array point (i,j,k).
!  To each point, assign a 1d index (the counter is
!  nef). Build the 3d->1d conversion arrays, kx, ky, kz. The
!  actual position (atomic units, cartesian coordinates, relative
!  to the origin) of each grid point is: xx=h*(kx+shift),
!  yy=h*(ky+shift), zz=h*(kz+shift).
!
!  start by initializing the 3d -> 1d conversion index

! Now we go over the sfc curve index by index and do the following
! 1) Fill in the actual precursors to the fx,fy,fz arrays
! 2) Create a shorter/coarser 'skip' list of only the first point in each fold, cx,cy,cz
! 3) Afterwards we update indexg
! We need some temporary arrays
box_vol = grid%bbox_domain%box_vol
allocate(fx_tmp(box_vol), stat=alcstat)
call alccheck('fx_tmp', box_vol, alcstat) 
allocate(fy_tmp(box_vol), stat=alcstat)
call alccheck('fy_tmp', box_vol, alcstat) 
allocate(fz_tmp(box_vol), stat=alcstat)
call alccheck('fz_tmp', box_vol, alcstat) 
fx_tmp(:) = 0
fy_tmp(:) = 0
fz_tmp(:) = 0



box_vol = grid%bbox_pad%box_vol
allocate(cx_tmp(box_vol/fold%volume), stat=alcstat)
call alccheck('cx_tmp', box_vol/fold%volume, alcstat) 
allocate(cy_tmp(box_vol/fold%volume), stat=alcstat)
call alccheck('cy_tmp', box_vol/fold%volume, alcstat) 
allocate(cz_tmp(box_vol/fold%volume), stat=alcstat)
call alccheck('cz_tmp', box_vol/fold%volume, alcstat) 
cx_tmp(:) = 0
cy_tmp(:) = 0
cz_tmp(:) = 0

allocate(f2sfc_tmp(box_vol), stat=alcstat)
call alccheck('f2sfc_tmp', box_vol, alcstat) 
allocate(c2sfc_tmp(box_vol/fold%volume), stat=alcstat)
call alccheck('c2sfc_tmp', box_vol/fold%volume, alcstat) 
allocate(c2f_tmp(box_vol/fold%volume+1), stat=alcstat)
call alccheck('c2f_tmp', box_vol/fold%volume+1, alcstat) 
f2sfc_tmp(:) = 0
c2sfc_tmp(:) = 0
c2f_tmp(:) = 0



! \todo AJB: The following is done because we want to do everything blockwise
! There is probably a better way of doing this but right now I am
! just copying from my matlab prototype 
allocate(iblock(fold%volume))
allocate(jblock(fold%volume))
allocate(kblock(fold%volume))

!  \todo AJB: update this
!  FOR CONFINED SYSTEM ONLY: must drop grid points outside a
!  sphere of radius grid%rmax. For periodic system, use a cut-off
!  radius (rcut) that certainly encompasses the periodic cell.
!

if (pbc%is_on) then
        ! AJB - too simplistic, we can't get away with this.
        rcutsqr = grid%rmax * grid%rmax

        if (fold%volume > 1) then
                write(9,*) "Warning: PBC in folds is incomplete, &
                        &recompile with fold volume = 1"
        endif
else
        rcutsqr = zero
endif




! we need only the domain bbox, but use the original sfc
! so we have bounds checks all the way
box_vol = grid%bbox_sfc%box_vol

nef = 0
f_tmp = 0
c_tmp = 0
do IND = 1, box_vol, fold%volume
        iblock(:) = fx_sfc(IND:IND+fold%volume-1)

        if (any(iblock(:) >= nxmin) .and. any(iblock(:) <= nxmax)) then
                jblock(:) = fy_sfc(IND:IND+fold%volume-1)

        if (any(jblock(:) >= nymin) .and. any(jblock(:) <= nymax)) then
                kblock(:) = fz_sfc(IND:IND+fold%volume-1)

        if (any(kblock(:) >= nzmin) .and. any(kblock(:) <= nzmax)) then
                !If a single point in this block is inside domain,
                !all the block is inside domain. There are no "gray" blocks
                !with only some points inside the domain in PARSEC
                any_inside = .false.

                do fold_ind = 1, fold%volume
                        i = iblock(fold_ind)
                        j = jblock(fold_ind)
                        k = kblock(fold_ind)
                        rr(1) = (grid%shift(1) + i)*grid%step(1)
                        rr(2) = (grid%shift(2) + j)*grid%step(2)
                        rr(3) = (grid%shift(3) + k)*grid%step(3)

                        if (pbc%is_on) then
                                ! Use sphere type criteria for periodic boundary conditions
                                rr(1:pbc%per) = zero
                                !rcut = rmax^2
                                distsqr = dot_product(rr,rr)

                                if (distsqr <= rcutsqr) then
                                        any_inside = .true.
                                        exit !no need to check other points in fold
                                endif
                        else !pbc is not on
                                ! cluster calculation, check the point against the domain
                                if (.not.outside_domain(grid, rr)) then
                                        !write(9,*) "inside domain", rr
                                        any_inside = .true.
                                        exit !no need to check other points in fold
                                endif
                        endif
                enddo !fold_ind

                if (.not. any_inside) cycle !next block


                ! if we arrived here then this block is inside domain
                c_tmp = c_tmp + 1
                !write(9,*) "assigning cx arrays for point | c/f",iblock(1),jblock(1),kblock(1)
                !1d->3d coarse
                cx_tmp(c_tmp) = iblock(1)
                cy_tmp(c_tmp) = jblock(1)
                cz_tmp(c_tmp) = kblock(1)
                !coarse to original sfc map
                !              write(9,*) "assigning coarse mapping for IND",IND
                c2sfc_tmp(c_tmp) = IND
                c2f_tmp(c_tmp) = f_tmp + 1
                !write(9,*) "assigning conversion arrays for points c/f",c_tmp,f_tmp+1

                do fold_ind = 1, fold%volume
                        f_tmp = f_tmp + 1

                        !3d->1d conversion
                        grid%indexg(iblock(fold_ind),jblock(fold_ind),kblock(fold_ind)) = f_tmp

                        !1d->3d conversion
                        fx_tmp(f_tmp) = iblock(fold_ind)
                        fy_tmp(f_tmp) = jblock(fold_ind)
                        fz_tmp(f_tmp) = kblock(fold_ind)

                        !fine to original sfthis is the hack for symmetry to work
                        f2sfc_tmp(f_tmp) = IND
                enddo ! assigment fine of conversion arrays
        endif !ANY kblock - Z dir
        endif !ANY jblock - Y dir
        endif !ANY iblock - X dir
enddo !IND
write(9,*) "done conversion arrays and domain IND,f_tmp", IND,f_tmp





!we want the last element of the c2f conversion to be the number f points actually
!one way to do it is like so:
c2f_tmp(c_tmp+1) = c2f_tmp(c_tmp) + fold%volume


!
!  The total number of points inside the domain is the size of the
!  Hamiltonian of the system, ndim. Allocate arrays accordingly.
!
ndim = f_tmp
call grid_set_ndim(grid, ndim=ndim, ndim_c=c_tmp)
call grid_set_conversion(grid)
write(9,*) 'allocated conversion arrays on grid object'
!now copy the arrays to the grid object:



grid%fx(1:grid%ndim) = fx_tmp(1:grid%ndim)
grid%fy(1:grid%ndim) = fy_tmp(1:grid%ndim)
grid%fz(1:grid%ndim) = fz_tmp(1:grid%ndim)
grid%cx(1:grid%ndim_c) = cx_tmp(1:grid%ndim_c)
grid%cy(1:grid%ndim_c) = cy_tmp(1:grid%ndim_c)
grid%cz(1:grid%ndim_c) = cz_tmp(1:grid%ndim_c)
grid%c2f(1:grid%ndim_c+1) = c2f_tmp(1:grid%ndim_c+1)
! and deallocate all these temopraries
! write(9,*) "The c_tmp 3vec: (length)",c_tmp
! write(9,'("c3vec: ",I5,x,I5,x,I5)') (cx_tmp(IND),cy_tmp(IND),cz_tmp(IND),IND=1,c_tmp)
! write(9,*) "The f_tmp 3vec: (length)",f_tmp
! write(9,'("f3vec: ",I5,x,I5,x,I5)') (fx_tmp(IND),fy_tmp(IND),fz_tmp(IND),IND=1,f_tmp)
! manual deallocation
!  write(9,*) "DEBUG:: Manually deallocating temp arrays"
deallocate(fx_sfc)
deallocate(fy_sfc)
deallocate(fz_sfc)
deallocate(fx_tmp)
deallocate(fy_tmp)
deallocate(fz_tmp)
deallocate(cx_tmp)
deallocate(cy_tmp)
deallocate(cz_tmp)
deallocate(c2f_tmp)
deallocate(f2sfc_tmp)
deallocate(c2sfc_tmp)
deallocate(iblock)
deallocate(jblock)
deallocate(kblock)
!  write(9,*) "...done deallocate I"


!!! (part 1.5) Symmetry - connect points that are equivalent based on symops - experimental with folds!
! probably needs to force grid_shift to be 0,0,0
if (fold%volume > 1 .and. rsymm%ntrans > 1) then
        write(9,*) "Warning: symmetry in folds is incomplete, try compiling with fold volume = 1"
endif




!
!
!  Define the set of grid points in the irreducible wedge, IW.
!  The IW contains all grid points that can reconstruct the
!  original grid by the application of symmetry operations, and it
!  is such that no two points in the IW are equivalent to each
!  other by the application of any symmetry operation.
!
!  Information about the wedge is contained in arrays indexw,
!  rindex, rtrans:
!  the n-th point in the IW has coordinates i,j,k so that
!  indexw(i,j,k)=n. If indexw(i,j,k)=0, this point is not in the IW
!
!  if rindex(n)=m and rtrans(n)=i, the n-th point in original grid
!  is equivalent to the m-th point in IW upon symmetry operation i.
!
!  dmax stores the maximum distance between a grid point and its
!  equivalent in the wedge after a symmetry operation. Ideally,
!  these two point should coincide, but numerical roundoff or the
!  fractional translation symm%tnp (see subroutine symop) may interfere.
dmax = zero
nwedge = 0
nwedge_c = 0

allocate(itest(fold%volume))
allocate(c2k_tmp(grid%ndim_c+1))
c2k_tmp=0

allocate(kx_tmp(grid%ndim),stat=alcstat)
call alccheck('kx_tmp',grid%ndim,alcstat) 
allocate(ky_tmp(grid%ndim),stat=alcstat)
call alccheck('ky_tmp',grid%ndim,alcstat) 
allocate(kz_tmp(grid%ndim),stat=alcstat)
call alccheck('kz_tmp',grid%ndim,alcstat) 
kx_tmp=0
ky_tmp=0
kz_tmp=0
allocate(kcx_tmp(grid%ndim_c),stat=alcstat)
call alccheck('kcx_tmp',grid%ndim_c,alcstat) 
allocate(kcy_tmp(grid%ndim_c),stat=alcstat)
call alccheck('kcy_tmp',grid%ndim_c,alcstat) 
allocate(kcz_tmp(grid%ndim_c),stat=alcstat)
call alccheck('kcz_tmp',grid%ndim_c,alcstat) 
kcx_tmp=0
kcy_tmp=0
kcz_tmp=0

! do fold_ind=1,fold%volume
! write(9,*) "TEST:: I am going to be looping over fold index:",fold_ind
! enddo

do IND = 1, grid%ndim_c
        num_new_points=0
        itest=0

        ! loop over all the points in the fold and test each one to find
        ! equivalent points on the grid
        do fold_ind=1,fold%volume 
                i=grid%fx(grid%c2f(IND)+fold_ind-1)
                j=grid%fy(grid%c2f(IND)+fold_ind-1)
                k=grid%fz(grid%c2f(IND)+fold_ind-1)

                if (grid%indexg(i,j,k) == 0) cycle !outside domain test before symmetry

                rr(1) = (grid%shift(1) + i)*grid%step(1)
                rr(2) = (grid%shift(2) + j)*grid%step(2)
                rr(3) = (grid%shift(3) + k)*grid%step(3)

                do itrans = 1, rsymm%ntrans
                        call symop(rsymm,itrans,rr,rw)

                        do ii = 1, 3
                                ir(ii)=nint(rw(ii)/grid%step(ii)-grid%shift(ii))
                                rw(ii)=rw(ii) - (ir(ii) + grid%shift(ii))*grid%step(ii)
                        enddo

                        dist = sqrt(dot_product(rw,rw))
                        dmax = max(dist,dmax)

                        if (dist > 1.d-4) then  !AJB: \note this looks to be a very expensive test.
                                write(9,*) ' ERROR: grid point displaced from ', &
                                        'image. Irreducible wedge may be wrong!'
                                write(9,*) ' Must ignore symmetry operations!'
                                write(9,'(I4,1x,I4,1x,I4)') i,j,k
                                write(9,*) grid%shift
                                write(9,*) grid%step
                                write(9,*) rr
                                write(9,*) rw
                                write(9,*) ir
                                write(9,*) itrans
                                ierr = 271
                                return
                        endif

                        itest(fold_ind) = grid%indexw(ir(1),ir(2),ir(3))

                        if (itest(fold_ind) == 0) then
                                num_new_points=num_new_points+1
                        else
                                ! write(9,'("pnt",x,I7,x," is on the wedge with itrans",x,I7)'), &
                                ! grid%c2f(IND)+fold_ind-1,itrans
                                ! write(9,*) "tested indexes",i,j,k
                                ! write(9,*) "mapped to indexes",ir(1),ir(2),ir(3)
                                !already found this point or an equivalent one
                                exit
                        endif !itest(fold_ind) ==0
                enddo !itrans

                !note: setting of rindex, rtrans (between indexg and indexw)
                !if the points are new, these are going to be re-written below
                ! write(9,'("SET ind/trans of pnt ",x,I7,x,"to",x,I7,x,I7 )') &
                !     grid%c2f(IND)+fold_ind-1,itest(fold_ind),itrans
                grid%rindex(grid%c2f(IND)+fold_ind-1) = itest(fold_ind)
                grid%rtrans(grid%c2f(IND)+fold_ind-1) = itrans
        enddo !fold_ind

        ! if at least one point on this block has not been found yet...
        if ( ANY(itest==0) ) then !setting of indexw(i,j,k)
                if (num_new_points<fold%volume) then
                        write(9,'("???? new indexw-block contains too few new points:",1x,I5,1x,"/",1x,I5)')&
                        num_new_points,fold%volume
                endif

                ! this is all very experimental but I am making this so it would
                ! create a 1:1 copy of the f and c arrays if symmetry is turned off
                ! the key here is to keep the orginial order of the sfc
                ! and just "shorten it", assigning the k[xyz] arrays as well
                ! we are also probably going to append to the domain new points
                ! and or remove old ones?
                nwedge_c = nwedge_c+1
                c2k_tmp(nwedge_c) = nwedge+1
                kcx_tmp(nwedge_c) = grid%fx(grid%c2f(IND))
                kcy_tmp(nwedge_c) = grid%fy(grid%c2f(IND))
                kcz_tmp(nwedge_c) = grid%fz(grid%c2f(IND))

                nwedge_new = nwedge + fold%volume !forcing all the points in the fold to change
                kx_tmp(nwedge+1:nwedge_new)=grid%fx(grid%c2f(IND):(grid%c2f(IND)+fold%volume-1))
                ky_tmp(nwedge+1:nwedge_new)=grid%fy(grid%c2f(IND):(grid%c2f(IND)+fold%volume-1))
                kz_tmp(nwedge+1:nwedge_new)=grid%fz(grid%c2f(IND):(grid%c2f(IND)+fold%volume-1))

                do fold_ind=1,fold%volume
                        i=grid%fx(grid%c2f(IND)+fold_ind-1)
                        j=grid%fy(grid%c2f(IND)+fold_ind-1)
                        k=grid%fz(grid%c2f(IND)+fold_ind-1)
                        grid%indexw(i,j,k)=nwedge + fold_ind

                        ! write(9,'("FORCE ind/trans of pnt ",x,I7,x,"to",x,I7,x,I7 )') &
                        !             grid%c2f(IND)+fold_ind-1,nwedge+fold_ind ,1
                        grid%rindex(grid%c2f(IND)+fold_ind-1) = nwedge + fold_ind 
                        grid%rtrans(grid%c2f(IND)+fold_ind-1) = 1 
                enddo

                nwedge = nwedge_new
        endif !any on wedge
enddo !IND

deallocate(itest)
c2k_tmp(nwedge_c+1)=c2k_tmp(nwedge_c)+fold%volume

! write(9,*) "The kc_tmp 3vec: (length)",nwedge_c
! write(9,'("kc3vec: ",I5,x,I5,x,I5)') (kcx_tmp(IND),kcy_tmp(IND),kcz_tmp(IND),IND=1,nwedge_c)
! write(9,*) "The k_tmp 3vec: (length)",nwedge
! write(9,'("k3vec: ",I5,x,I5,x,I5)') (kx_tmp(IND),ky_tmp(IND),kz_tmp(IND),IND=1,nwedge)













grid%nwedge = nwedge
grid%nwedge_c = nwedge_c
write(9,*) "nwedge/c=", nwedge, nwedge_c

write(9,*) "setting wedge"
call grid_set_wedge(grid)

write(9,*) "allocated the wedge arrays on grid"
grid%kx(1:grid%nwedge) = kx_tmp(1:grid%nwedge)
grid%ky(1:grid%nwedge) = ky_tmp(1:grid%nwedge)
grid%kz(1:grid%nwedge) = kz_tmp(1:grid%nwedge)
grid%kcx(1:grid%nwedge_c) = kcx_tmp(1:grid%nwedge_c)
grid%kcy(1:grid%nwedge_c) = kcy_tmp(1:grid%nwedge_c)
grid%kcz(1:grid%nwedge_c) = kcz_tmp(1:grid%nwedge_c)
grid%c2k(1:grid%nwedge_c+1) = c2k_tmp(1:grid%nwedge_c+1)

write(9,*) "DEBUG:: Manually deallocating temp arrays II"


deallocate(kx_tmp)
deallocate(ky_tmp)
deallocate(kz_tmp)
deallocate(kcx_tmp)
deallocate(kcy_tmp)
deallocate(kcz_tmp)
deallocate(c2k_tmp)









write(9,*) "...done deallocate II"


write(9,*)
write(9,*) 'GRID Setup messages:'
write(9,*) '---------------'
write(9,*) 'The Hamiltonian matrix size is', ndim
write(9,*) ' Symmetry reduced size is ', nwedge
write(9,*) ' maximum distance between grid points and their images is'
write(9,'(2x,g12.4,a)') dmax,'  [bohr]'

write(9,*) ""
write(9,*) ""
write(9,15) 6*sten_depth


if (parallel%iammaster) then
        write(7,*)
        write(7,*) 'GRID Setup messages:'
        write(7,*) '---------------'
        write(7,*) 'The Hamiltonian matrix size is', ndim
        write(7,*) ' Symmetry reduced size is ', nwedge
        write(7,*) ' maximum distance between grid points', &
                ' and their images is'
        write(7,'(2x,g12.4,a)') dmax,'  [bohr]'

        write(7,*)
        write(7,15) 6*sten_depth
endif



!TODO: This line is just confiusing now
15 format(1x,'There are at least',1x,i2,1x, &
        'laplacian-related non-diagonal elements per row') 

! This remains from the old grid partitioning method, as a sort of sanity check
! for the symmetry stuff
if (rsymm%ntrans > 1) then
        write(9,*) "Testing wedge reduction to see that no points were dropped"
        allocate (ninv(grid%nwedge),stat=alcstat)
        call alccheck('ninv',grid%nwedge,alcstat) 
        ninv = 0
        allocate (rinv(rsymm%ntrans,grid%nwedge),stat=alcstat)
        call alccheck('rinv',rsymm%ntrans*grid%nwedge,alcstat)

        do IND = 1,ndim
                i = grid%fx(IND)
                j = grid%fy(IND)
                k = grid%fz(IND)
                ii = grid%rindex(grid%indexg(i,j,k))
                ninv(ii) = ninv(ii) + 1
                rinv(ninv(ii),ii) = grid%indexg(i,j,k)
        enddo

          if (maxval(ninv) > rsymm%ntrans .or. minval(ninv) < rsymm%ntrans) then
             if (parallel%iammaster) then
                !write(7,*) 'WARNING: grid points in irreducible wedge ' &
                write(7,*) 'ERROR: grid points in irreducible wedge ' &
                     ,'have weights'
                write(7,*) 'different from the order of the reduced group'
                write(7,*) ' minimum and maximum values of weight =' &
                     ,minval(ninv),maxval(ninv)
                write(7,*) ' order of the reduced group = ',rsymm%ntrans
             endif
             !write(9,*) 'WARNING: grid points in irreducible wedge ' &
             write(9,*) 'ERROR: grid points in irreducible wedge ' &
                  ,'have weights'
             write(9,*) 'different from the order of the reduced group'
             write(9,*) ' minimum and maximum values of weight = ' &
                  ,minval(ninv),maxval(ninv)
             ! write(9,*) 'These are located at:',minloc(ninv),maxloc(ninv)
             write(9,*) ' order of the reduced group = ',rsymm%ntrans
             !DEBUG:
               ! do i=1,rsymm%ntrans
               ! write(9,*) "The inverse mapping test (rinv(i,:). i=",i
               ! write(9,'("rinv: ",I7)') (rinv(i,IND),IND=1,nwedge)
               ! enddo
             ierr = 272
             !ierr = 0
          endif

        deallocate(ninv, rinv)
        ierrvec = ierr
        call pisum(ierrvec,1,parallel%groups_num,parallel%gmaster_comm)
        ierr = ierrvec(1)
        if (ierr > 0) then
                ierr = 272
                return
        endif
endif !rsymm%trans>1








!
!  PART2: Partitioning The Domain
!
!  OLD text: At this point we are ready to do any kind of partitioning
!  geometrical or based on the nwedge-array.
!  Part(i,j,k,..) = processor number that the (i,j,k) resides on
!
!
!  Find how many rows each processor has and how many equivalent
!  points each grid point in IW has.
!  Note: since grid%indexw already has information about which
!  points to keep, we can run over (-nx,nx),(-ny,ny),(-nz,nz) for
!  periodic and non-periodic boundary conditions. For equivalent
!  points, search over all grid points where indexg in non-zero,
!  since those ones define the full grid.
!
remainder_parts = mod(nwedge, nnodes)
average_part_dim= (nwedge - remainder_parts)/nnodes
! make sure average_part is divisable by the fold

irows(:) = 0  !irows starts in 0 and has dim=nnodes+1
write(9,*) "new partitioning:: average part dimension:", average_part_dim

irows(0) = 1
do i = 1, nnodes
        do j = 1, grid%nwedge_c
                !write(9,*) "new block:", grid%c2k(j)
                if (grid%c2k(j)-irows(i-1)+1 > average_part_dim) then
                        write(9,*) "found a new cut point at j,c2k(j):", &
                                j, grid%c2k(j)
                        exit
                endif
        enddo

        ! KHL: We use (j-1) because after the above loop, the 
        !      loop index will 
        !      be automatically added 1. We substract 1 here to get the 
        !      correct index.
        !irows(i) = grid%c2k(j-1)
        ! KHL: Because we escape from the above loop so that 
        !      the loop index will not be automatically added 1.
        irows(i) = grid%c2k(j)
enddo


! now the last part holds the remainder
irows(nnodes) = nwedge + 1

ldn = maxval(irows(1:nnodes) - irows(0:nnodes-1))
write(9,*) 'ldn', ldn
!ldn = nwedge/nnodes + nnodes
!do IND = 2, nnodes
!        if (irows(IND)-irows(IND-1) > ldn) then
!                write(9,*) "you still can't guess ldn right? a part is larger than ldn"
!                write(9,*) "index, ldn, part size:", IND, ldn, irows(IND)-irows(IND-1)
!                ldn = irows(IND) - irows(IND-1)
!                write(9,*) "setting ldn to", ldn
!        endif
!enddo

!\note AJB: MKL says ldn should be divisible by the AVX register size (MKL: just by 16 which is almost the same)
if (mod(ldn,16) /= 0) then
        ldn = ldn + (16 - mod(ldn,16))
        write(9,*) "ldn now divides by 16", ldn
endif
!\note AJB: TODO: MKL says ldn should NOT be divisible by 2048 ?


parallel%ldn = ldn
parallel%ndim = ndim
parallel%nwedge = nwedge
parallel%nwedge_c = nwedge_c

! We just cut the curve at one of the fold edges
! this can be optimized so that the cut points slide around between blocks
! in order to minimize, e.g., number of nonlocal points, or make sure that
! individual parts are contigous. 

  

write(9,*) "irows now::"
write(9,*) irows(:)
write(9,*) "ldn is::", ldn


if (sum(irows(1:nnodes)-irows(0:nnodes-1)) /= nwedge) then
        write(9,*) "something wrong with the partitioning"
endif

cirows(:) = (irows(:) - 1)/fold%volume + 1
  
write(9,*) "cirows::"
write(9,*) cirows(:)
!  write(9,*) "c2k(cirows)::"
!  write(9,*) grid%c2k(cirows)





!
!  Transfer irows to parallel structure
!
parallel%irows(:) = irows(:)
parallel%cirows(:) = cirows(:)









!  Permutation so that rows on the same processors appear in
!  adjacent positions in the indexw numbering. Perform a
!  "stiching" movement through space, in order to ensure that
!  grid points with close (i,j,k) indices are also physically
!  close.
!
! KHL: I turn off the reordering for now (because I have not 
!      figured out how to do this for side_length == 2)
if ((.not. grid%use_sfc) .and. fold%side_length == -1) then
!if ((.not. grid%use_sfc) .and. fold%side_length == 1) then
        irows(:) = parallel%irows(:)

        j00 = -1
        k00 = -1
        do i = nxmin, nxmax
                j00 = -j00

                if (j00 == 1) then
                        ny1 = nymin
                        ny2 = nymax
                else
                        ny1 = nymax
                        ny2 = nymin
                endif

                do j = ny1, ny2, j00
                        k00 = -k00

                        if (k00 == 1) then
                                nz1 = nzmin
                                nz2 = nzmax
                        else
                                nz1 = nzmax
                                nz2 = nzmin
                        endif

                        do k = nz1, nz2, k00
                                if (grid%indexw(i,j,k) /= 0) then
                                        iold = grid%indexw(i,j,k)
                                        inode = Part(grid, parallel, nnodes, i, j, k, .TRUE.)
                                        nef = irows(inode)
                                        grid%indexw(i,j,k) = nef

                                        do ii = 1, rsymm%ntrans
                                                grid%rindex(rinv(ii,iold)) = nef
                                        end do

                                        irows(inode) = irows(inode) + 1
                                        grid%kx(nef) = i
                                        grid%ky(nef) = j
                                        grid%kz(nef) = k
                                        grid%kcx(nef) = grid%kx(nef)
                                        grid%kcy(nef) = grid%ky(nef)
                                        grid%kcz(nef) = grid%kz(nef)
                                endif
                        enddo
                enddo
        enddo

        irows(:) = parallel%irows(:)
endif










! PART 3 - Why Am I here?
!
!  if in a periodic system, points must be "wrapped around" the
!  boundary so that points on opposite sides of the box are
!  actually recognized as neighbors. For that, we go over
!  -nx-sten_depth to -nx-1 and nx to nx+sten_depth-1 (and so on in the y
!  and z directions), thus finding all the neighbors of points
!  that have neighbors that are "wrapped" on the other side of the
!  box. For each point, we go over 6 combinations in all,
!  coresponding to the 6 faces of the cube. Every time i00, j00
!  and k00 are flipped in sign accordingly so that all the 6
!  combinations are covered. In any one of these combinations, the
!  elements are mapped to the corresponding element on the
!  other side of the boundary (i.e., shifted by 2*nx and so on).
!
!\note AJB SFC : There might be an issue here, since we are folding the curve onto itself
!but probably not, because this is used for neighbor queries. 
!just make sure to fold it from the right end of the curve

grid_limits(1,1)=nxmin-sten_depth
grid_limits(1,2)=nxmin-1
grid_limits(1,3)=nxmax+1
grid_limits(1,4)=nxmax+sten_depth
grid_limits(1,5)=nxmin
grid_limits(1,6)=nxmax

grid_limits(2,1)=nymin-sten_depth
grid_limits(2,2)=nymin-1
grid_limits(2,3)=nymax+1
grid_limits(2,4)=nymax+sten_depth
grid_limits(2,5)=nymin
grid_limits(2,6)=nymax

grid_limits(3,1)=nzmin-sten_depth
grid_limits(3,2)=nzmin-1
grid_limits(3,3)=nzmax+1
grid_limits(3,4)=nzmax+sten_depth
grid_limits(3,5)=nzmin
grid_limits(3,6)=nzmax

gwrap(1)=grid%n1
gwrap(2)=grid%n2
gwrap(3)=grid%n3

if (pbc%per >= 1) then
        !  ---- -x direction
        do i = grid_limits(1,1),grid_limits(1,2)
        do j = grid_limits(2,5),grid_limits(2,6)
        do k = grid_limits(3,5),grid_limits(3,6)
                grid%indexg(i,j,k) = grid%indexg(i+gwrap(1),j,k)
        enddo
        enddo
        enddo

        !  ---- +x direction
        do i = grid_limits(1,3),grid_limits(1,4)
        do j = grid_limits(2,5),grid_limits(2,6)
        do k = grid_limits(3,5),grid_limits(3,6)
                grid%indexg(i,j,k) = grid%indexg(i-gwrap(1),j,k)
        enddo
        enddo
        enddo
endif

if (pbc%per >= 2) then
        !  ---- -y direction
        do i = grid_limits(1,5),grid_limits(1,6)
        do j = grid_limits(2,1),grid_limits(2,2)
        do k = grid_limits(3,5),grid_limits(3,6)
                grid%indexg(i,j,k) = grid%indexg(i,j+gwrap(2),k)
        enddo
        enddo
        enddo

        !  ---- +y direction
        do i = grid_limits(1,5),grid_limits(1,6)
        do j = grid_limits(2,3),grid_limits(2,4)
        do k = grid_limits(3,5),grid_limits(3,6)
                grid%indexg(i,j,k) = grid%indexg(i,j-gwrap(2),k)
        enddo
        enddo
        enddo
endif

if (pbc%per >= 3) then
        !  ---- -z direction
        do i = grid_limits(1,5),grid_limits(1,6)
        do j = grid_limits(2,5),grid_limits(2,6)
        do k = grid_limits(3,1),grid_limits(3,2)
                grid%indexg(i,j,k) = grid%indexg(i,j,k+gwrap(3))
        enddo
        enddo
        enddo

        !  ---- +z direction
        do i = grid_limits(1,5),grid_limits(1,6)
        do j = grid_limits(2,5),grid_limits(2,6)
        do k = grid_limits(3,3),grid_limits(3,4)
                grid%indexg(i,j,k) = grid%indexg(i,j,k-gwrap(3))
        enddo
        enddo
        enddo
endif



!\todo AJB: verify, this is not supposed to be run if not PBC!!!!
!\todo AJB: extra lap dirs are still broken!!
if (pbc%per >= 1) then !hack for making sure this does not happen in cluster
        do ii = 1, 3
                if (grid%lap_dir(ii) /= 0) then
                        do jj = 1, 3
                                if (grid%lap_neig(ii,jj) > 0) then
                                        idx1(jj,1)=1
                                        idx1(jj,2)=3
                                else
                                        if (grid%lap_neig(ii,jj)<0) then
                                                idx1(jj,1)=3
                                                idx1(jj,2)=1
                                        else
                                                idx1(jj,1)=5
                                                idx1(jj,2)=5
                                        endif
                                endif
                        enddo

                        do i = grid_limits(1,idx1(1,1))  , grid_limits(1,idx1(1,1)+1)
                        do j = grid_limits(2,idx1(2,1))  , grid_limits(2,idx1(2,1)+1)
                        do k = grid_limits(3,idx1(3,1))  , grid_limits(3,idx1(3,1)+1)
                                grid%indexg(i,j,k)= &
                                    grid%indexg(i+gwrap(1)*grid%lap_neig(ii,1) &
                                               ,j+gwrap(2)*grid%lap_neig(ii,2) &
                                               ,k+gwrap(3)*grid%lap_neig(ii,3))
                        enddo
                        enddo
                        enddo

                        do i = grid_limits(1,idx1(1,2))  , grid_limits(1,idx1(1,2)+1)
                        do j = grid_limits(2,idx1(2,2))  , grid_limits(2,idx1(2,2)+1)
                        do k = grid_limits(3,idx1(3,2))  , grid_limits(3,idx1(3,2)+1)

                                grid%indexg(i,j,k)= &
                                        grid%indexg(i-gwrap(1)*grid%lap_neig(ii,1) &
                                         ,j-gwrap(2)*grid%lap_neig(ii,2) &
                                         ,k-gwrap(3)*grid%lap_neig(ii,3))
                        enddo
                        enddo
                        enddo

                        !the following if treats the case where all coordinates
                        !of the neighbor are different than zero. In such a case
                        !one has to treat not just the combined edge of all 3 indices 
                        !but also the situation were one of the indices is inside the 
                        !permitted grid and the other 2 are outside. We assume that all
                        !neighbor coordinates are +/- 1. 

                        if(sum(abs(grid%lap_neig(ii,1:3)))>2) then
                                do jj=1,3
                                 idx2=idx1
                                 gwrap2=gwrap
                                 idx2(jj,1)=5
                                 idx2(jj,2)=5
                                 gwrap2(jj)=0

                                 do i = grid_limits(1,idx2(1,1))  , grid_limits(1,idx2(1,1)+1)
                                  do j = grid_limits(2,idx2(2,1))  , grid_limits(2,idx2(2,1)+1)
                                    do k = grid_limits(3,idx2(3,1))  , grid_limits(3,idx2(3,1)+1)

                                    grid%indexg(i,j,k)= &
                                     grid%indexg(i+gwrap2(1)*grid%lap_neig(ii,1) &
                                                ,j+gwrap2(2)*grid%lap_neig(ii,2) &
                                                ,k+gwrap2(3)*grid%lap_neig(ii,3))
                                    enddo
                                  enddo
                                 enddo

                                 do i = grid_limits(1,idx2(1,2))  , grid_limits(1,idx2(1,2)+1)
                                  do j = grid_limits(2,idx2(2,2))  , grid_limits(2,idx2(2,2)+1)
                                    do k = grid_limits(3,idx2(3,2))  , grid_limits(3,idx2(3,2)+1)

                                    grid%indexg(i,j,k)= &
                                     grid%indexg(i-gwrap2(1)*grid%lap_neig(ii,1) &
                                                ,j-gwrap2(2)*grid%lap_neig(ii,2) &
                                                ,k-gwrap2(3)*grid%lap_neig(ii,3))
                                    enddo
                                  enddo
                                 enddo
                                enddo
                        endif !  if(sum(abs(grid%lap_neig(ii,1:3)))>2) then
                endif !  if(grid%lap_dir(ii) /= 0) then
        enddo ! ii = 1,3
endif ! pbc%per>=1




!
! Set the indexes for grid points outside the domain to be nwedge+1 (it was zero before). 
!

! do k = nzmin - sten_depth,nzmax + sten_depth
!    do j = nymin - sten_depth,nymax + sten_depth
!       do i = nxmin - sten_depth,nxmax + sten_depth
do k = grid%bbox_pad%box_min(3), grid%bbox_pad%box_max(3)
do j = grid%bbox_pad%box_min(2), grid%bbox_pad%box_max(2)
do i = grid%bbox_pad%box_min(1), grid%bbox_pad%box_max(1)
        if (grid%indexw(i,j,k) == 0) grid%indexw(i,j,k) = grid%nwedge + 1
        if (grid%indexg(i,j,k) == 0) grid%indexg(i,j,k) =   grid%ndim + 1
enddo
enddo
enddo

! also here:
grid%rindex(grid%ndim+1) = grid%nwedge + 1
grid%rtrans(grid%ndim+1) = 1





! TODO: Setting of the FFT bounding box corners. CHECK THIS CAREFULLY
!
!  Finally, define grid shift in units of lattice vector
if (pbc%per >= 1) then
        pbc%mx = minval(grid%fx)
        pbc%shift(1) = (grid%shift(1) + real(pbc%mx,dp)) * &
                grid%step(1) * twopi / pbc%box_size(1)
else
        pbc%mx = 0
        pbc%shift(1) = zero
endif

if (pbc%per >= 2) then
        pbc%my = minval(grid%fy)
        pbc%shift(2) = (grid%shift(2) + real(pbc%my,dp)) * &
                grid%step(2) * twopi / pbc%box_size(2)
else
        pbc%my = 0
        pbc%shift(2) = zero
endif

if (pbc%per >= 3) then
        pbc%mz = minval(grid%fz)
        pbc%shift(3) = (grid%shift(3) + real(pbc%mz,dp)) * &
                grid%step(3) * twopi / pbc%box_size(3)
else
        pbc%mz = 0
        pbc%shift(3) = zero
endif

if (parallel%iammaster .and. pbc%is_on) then
        write(7,*) 'pbc shift indices = ',pbc%mx,pbc%my,pbc%mz
        write(7,'(A,3F10.4)') ' pbc shift [latt. vect. units] = ',pbc%shift/twopi
endif

write(9,*) "DEBUG: edge of grid partition"



contains

subroutine generate_grid_point_index_v1()

! AJB: Here we really start changing. We keep using the same 1d-3d conversions
! but we generate them first, adding either a space-filling curve or just 
! plain blocking.
! Blocking reverts back almost perfectly to the old partitioning if fold 
! size is [1 1 1]
if (grid%use_sfc) then
        box_vol = 8**sfc_order

        allocate(fx_sfc(box_vol), stat=alcstat)
        call alccheck('fx_sfc', box_vol, alcstat) 
        allocate(fy_sfc(box_vol), stat=alcstat)
        call alccheck('fy_sfc', box_vol, alcstat) 
        allocate(fz_sfc(box_vol), stat=alcstat)
        call alccheck('fz_sfc', box_vol, alcstat) 

        fx_sfc(:) = 0
        fy_sfc(:) = 0
        fz_sfc(:) = 0

        write(9,*) "SFC:: allocated the sfc temporary arrays"

        ! KHL: after this subroutine, f[x,y,z]_sfc(1:8**sfc_order) will store
        !      the integer coordinates of the points inside a cubic 
        !      with a length of 2**sfc_order
        !      For example, if sfc_order == 2, then there will be 
        !      8**2 = 64 points and maxval(fx_sfc(:)) will be 2**2 / 2 = 2,
        !      and minval(fx_sfc(:)) = -2**2 / 2 + 1 = -1
        call hilbert3d_int(sfc_order, fx_sfc(:), fy_sfc(:), fz_sfc(:))

        write(9,*) "SFC:: created a space-filling-curve approx. of order ", &
                sfc_order

        ! block_sfc : we need to expand the sfc otherwise it will not 
        ! encompass the domain
        if (fold%volume > 1) then
       
                call grid%bbox_sfc%from_3vec(fx_sfc(:), fy_sfc(:), &
                        fz_sfc(:), from=1, to=box_vol)
                write(9,*) "bbox_sfc (coarse) details:"
                write(9,*) "bbox_sfc%box_min::", grid%bbox_sfc%box_min
                write(9,*) "bbox_sfc%box_max::", grid%bbox_sfc%box_max
                write(9,*) ""

                allocate(coarse_map(grid%bbox_sfc%box_sides(1)+1))

                do IND = 1, grid%bbox_sfc%box_sides(1)+1
                        coarse_map(IND) = IND - 1
                enddo

                ! write(9,*) "corase map:",coarse_map

                do IND = 1, 3
                        bottom_shift(IND) = &
( (grid%bbox_sfc%box_sides(1)+1) - (grid%bbox_pad%box_sides(IND)/fold%blocksize(IND)) )/2
                enddo

                write(9,*) "block_sfc stage I : bottom_shift - ", &
                        bottom_shift(:)

                allocate(indmapx(size(coarse_map)))
                allocate(indmapy(size(coarse_map)))
                allocate(indmapz(size(coarse_map)))

                ! generate mapping to expand the sfc 
indmapx(:) = (coarse_map(:) - bottom_shift(1))*fold%blocksize(1) + grid%bbox_pad%box_min(1)
indmapy(:) = (coarse_map(:) - bottom_shift(2))*fold%blocksize(2) + grid%bbox_pad%box_min(2)
indmapz(:) = (coarse_map(:) - bottom_shift(3))*fold%blocksize(3) + grid%bbox_pad%box_min(3)
                ! write(9,*) "mapping from coarse to actual sfc:"
                ! write(9,'("indmap: ",I5,x,I5,x,I5)') (indmapx(IND),indmapy(IND),indmapz(IND),IND=1,size(coarse_map))
       
                allocate(fx_cxp(size(fx_sfc)))
                allocate(fy_cxp(size(fy_sfc)))
                allocate(fz_cxp(size(fz_sfc)))
                fx_cxp(:) = 0
                fy_cxp(:) = 0
                fz_cxp(:) = 0

                ! we expand the original sfc to the size of the padded domain
                do IND = 1, size(fx_sfc)
                        fx_cxp(IND) = indmapx( &
                                fx_sfc(IND)-grid%bbox_sfc%box_min(1)+1)
                enddo
                do IND = 1, size(fy_sfc)
                        fy_cxp(IND) = indmapy( &
                                fy_sfc(IND)-grid%bbox_sfc%box_min(2)+1)
                enddo
                do IND = 1, size(fz_sfc)
                        fz_cxp(IND) = indmapz( &
                                fz_sfc(IND)-grid%bbox_sfc%box_min(3)+1)
                enddo
                !fx_cxp=indmapx(fx_sfc-grid%bbox_sfc%box_min(1)+1)
                !fy_cxp=indmapy(fy_sfc-grid%bbox_sfc%box_min(2)+1)
                !fz_cxp=indmapz(fz_sfc-grid%bbox_sfc%box_min(3)+1)
                c_tmp = size(fx_cxp)
                write(9,*) "block_sfc stage II : expanded coarse size ", c_tmp
                ! write(9,*) "The sfc 3vec:"
                ! write(9,'("cxp3vec: ",I5,x,I5,x,I5)') (fx_cxp(IND),fy_cxp(IND),fz_cxp(IND),IND=1,c_tmp)
                deallocate(coarse_map)
                deallocate(indmapx)
                deallocate(indmapy)
                deallocate(indmapz)

                box_vol = grid%bbox_pad%box_vol
                allocate(fx_tmp(box_vol), stat=alcstat)
                call alccheck('fx_tmp', box_vol, alcstat) 
                allocate(fy_tmp(box_vol), stat=alcstat)
                call alccheck('fy_tmp', box_vol, alcstat) 
                allocate(fz_tmp(box_vol), stat=alcstat)
                call alccheck('fz_tmp', box_vol, alcstat) 
                fx_tmp(:) = 0
                fy_tmp(:) = 0
                fz_tmp(:) = 0
                !go through the elements and create a new sfc only for 
                ! the padded area, this time with blocks!
                !we treat every vertex as the bottom corner (0,0,0) of 
                ! the fold
                f_tmp = 1
                do IND = 1, c_tmp
                        i = fx_cxp(IND)

                        if (i >= grid%bbox_pad%box_min(1) .and. &
                                i <= grid%bbox_pad%box_max(1)) then

                                j = fy_cxp(IND)

                                if (j >= grid%bbox_pad%box_min(2) .and. &
                                        j <= grid%bbox_pad%box_max(2)) then

                                        k = fz_cxp(IND)

                                        if (k >= grid%bbox_pad%box_min(3) .and. &
                                                k <= grid%bbox_pad%box_max(3)) then

                                fx_tmp(f_tmp:(f_tmp+fold%volume-1))=fx_cxp(ind)+fold%foldx(:)
                                fy_tmp(f_tmp:(f_tmp+fold%volume-1))=fy_cxp(ind)+fold%foldy(:)
                                fz_tmp(f_tmp:(f_tmp+fold%volume-1))=fz_cxp(ind)+fold%foldz(:)

                                                f_tmp = f_tmp + fold%volume
                                        endif
                                endif
                        endif
                enddo
                ! write(9,*) "block_sfc stage III : replace original sfc - ",f_tmp

                ! we need to reallocate the sfc now to put the new one 
                ! in its place
                deallocate(fx_sfc)
                deallocate(fy_sfc)
                deallocate(fz_sfc)

                box_vol = f_tmp - 1

                allocate(fx_sfc(box_vol), stat=alcstat)
                call alccheck('fx_sfc', box_vol, alcstat) 
                allocate(fy_sfc(box_vol), stat=alcstat)
                call alccheck('fy_sfc', box_vol, alcstat) 
                allocate(fz_sfc(box_vol), stat=alcstat)
                call alccheck('fz_sfc', box_vol, alcstat) 

                fx_sfc(:) = fx_tmp(1:box_vol)
                fy_sfc(:) = fy_tmp(1:box_vol)
                fz_sfc(:) = fz_tmp(1:box_vol)

                ! and now we need to kill f[xyz]_tmp because they 
                ! are used later
                deallocate(fx_tmp)
                deallocate(fy_tmp)
                deallocate(fz_tmp)

                ! and we do not need the expansion curve anymore
                deallocate(fx_cxp)
                deallocate(fy_cxp)
                deallocate(fz_cxp)
        endif !fold%volume>1 (block_sfc)

else !not use_sfc
        box_vol = grid%bbox_pad%box_vol

        ! simple blocking:
        allocate(fx_sfc(box_vol),stat=alcstat)
        call alccheck('fx_sfc',box_vol,alcstat) 
        allocate(fy_sfc(box_vol),stat=alcstat)
        call alccheck('fy_sfc',box_vol,alcstat) 
        allocate(fz_sfc(box_vol),stat=alcstat)
        call alccheck('fz_sfc',box_vol,alcstat) 
        fx_sfc=0
        fy_sfc=0
        fz_sfc=0

        f_sfc=1

        do i = nxmin,nxmax,fold%blocksize(1)
        do j = nymin,nymax,fold%blocksize(2)
        do k = nzmin,nzmax,fold%blocksize(3)
                fx_sfc(f_sfc:(f_sfc+fold%volume-1))=(i+fold%foldx)
                fy_sfc(f_sfc:(f_sfc+fold%volume-1))=(j+fold%foldy)
                fz_sfc(f_sfc:(f_sfc+fold%volume-1))=(k+fold%foldz)
                f_sfc=f_sfc+fold%volume
        enddo
        enddo
        enddo

        write(9,*) "indexed entire padded domain, fold_vol,f_sfc, i j k:", &
                fold%volume,f_sfc,i,j,k

endif !if use_sfc


end subroutine generate_grid_point_index_v1





subroutine generate_grid_point_index_v2

if (grid%use_sfc) then
        write(9,*) "sfc_order", sfc_order

        box_vol = 8**sfc_order

        write(9,*) 'box_vol', box_vol


        if (fold%volume > 1) then
                allocate(fx_cxp(box_vol), stat=alcstat)
                call alccheck('fx_cxp', box_vol, alcstat) 
                allocate(fy_cxp(box_vol), stat=alcstat)
                call alccheck('fy_cxp', box_vol, alcstat) 
                allocate(fz_cxp(box_vol), stat=alcstat)
                call alccheck('fz_cxp', box_vol, alcstat) 

                ! ================================================
                ! KHL: generate the SFC for the coarse grid
                !      (the bottom corner points of the final blocks)
                ! ================================================
                call hilbert3d_int(sfc_order, fx_cxp, fy_cxp, fz_cxp)

                ! KHL: Before this, we have, for example
                !      (32, 31, ..., -30, -31)
                !      After this, we will have
                !      (62, 60, ..., -62, -64)
                do IND = 1, box_vol
                        fx_cxp(IND) = fx_cxp(IND)*fold%blocksize(1) - &
                                fold%blocksize(1)
                        fy_cxp(IND) = fy_cxp(IND)*fold%blocksize(2) - &
                                fold%blocksize(2)
                        fz_cxp(IND) = fz_cxp(IND)*fold%blocksize(3) - &
                                fold%blocksize(3)
                enddo

                ! ================================================
                ! KHL: Optional. Whether to shift the coarse grid.
                ! ================================================
                ! 
                !      To align the index of the corner of the maximum
                !      block of the padded box.
                !            ( 2   1* 0 -1)       side points = 4
                !         ( 3  2*  1  0 -1  -2)               = 6
                !      (4   3* 2   1  0 -1  -2  -3)           = 8
                !      * is the corner of the maximum block
                !
                !      (This is reversed because the start of our SFC is at 
                !      the (+x,+y,+z) corner, rather than (-x,-y,-z)
                !
                !      For a padded box (2  1*  0  -1), we shift 
                !      fx_cxp by the difference of the largest indii
                !      to make the indices from, for example
                !      (8   6   4   2   0  -2   -4   -6)
                !      to
                !      (1* -1  -3  -5  -7  -9  -11  -13)

                ! recipe 1: Align the SCF start block
                !bottom_shift(1) = &
                !        grid%bbox_pad%box_max(1) - maxval(fx_cxp) - 1
                !bottom_shift(2) = &
                !        grid%bbox_pad%box_max(2) - maxval(fy_cxp) - 1
                !bottom_shift(3) = &
                !        grid%bbox_pad%box_max(3) - maxval(fz_cxp) - 1

                ! recipe 2: Align the opposite block to the SCF start block
                !bottom_shift(1) = &
                !        grid%bbox_pad%box_min(1) - minval(fx_cxp)
                !bottom_shift(2) = &
                !        grid%bbox_pad%box_min(2) - minval(fy_cxp)
                !bottom_shift(3) = &
                !        grid%bbox_pad%box_min(3) - minval(fz_cxp)

                !do IND = 1, box_vol
                !        fx_cxp(IND) = fx_cxp(IND) + bottom_shift(1)
                !        fy_cxp(IND) = fy_cxp(IND) + bottom_shift(2)
                !        fz_cxp(IND) = fz_cxp(IND) + bottom_shift(3)
                !enddo

                ! Calculate the fx_cxp for the padded box region only
                c_tmp = 1

                do IND = 1, box_vol
                        i = fx_cxp(IND)

                        if (i >= grid%bbox_pad%box_min(1) .and. &
                            i <= grid%bbox_pad%box_max(1)) then

                        j = fy_cxp(IND)

                        if (j >= grid%bbox_pad%box_min(2) .and. &
                            j <= grid%bbox_pad%box_max(2)) then

                        k = fz_cxp(IND)

                        if (k >= grid%bbox_pad%box_min(3) .and. &
                            k <= grid%bbox_pad%box_max(3)) then

                                fx_cxp(c_tmp) = i
                                fy_cxp(c_tmp) = j
                                fz_cxp(c_tmp) = k

                                c_tmp = c_tmp + 1
                        endif
                        endif
                        endif
                enddo

                c_tmp = c_tmp - 1
                box_vol = c_tmp*fold%volume

                write(9,*) 'box_vol', box_vol
                write(9,*) 'box_vol of padded box', grid%bbox_pad%box_vol

                allocate(fx_sfc(box_vol), stat=alcstat)
                call alccheck('fx_sfc', box_vol, alcstat) 
                allocate(fy_sfc(box_vol), stat=alcstat)
                call alccheck('fy_sfc', box_vol, alcstat) 
                allocate(fz_sfc(box_vol), stat=alcstat)
                call alccheck('fz_sfc', box_vol, alcstat) 

                ! KHL: Expand the coarse grid to the full grid
                do IND = 1, c_tmp
                        f_tmp = (IND-1)*fold%volume + 1

                        fx_sfc(f_tmp:(f_tmp+fold%volume-1)) = &
                                fx_cxp(IND) + fold%foldx(:)
                        fy_sfc(f_tmp:(f_tmp+fold%volume-1)) = &
                                fy_cxp(IND) + fold%foldy(:)
                        fz_sfc(f_tmp:(f_tmp+fold%volume-1)) = &
                                fz_cxp(IND) + fold%foldz(:)
                enddo

                deallocate(fx_cxp)
                deallocate(fy_cxp)
                deallocate(fz_cxp)

        else
                allocate(fx_sfc(box_vol), stat=alcstat)
                call alccheck('fx_sfc', box_vol, alcstat) 
                allocate(fy_sfc(box_vol), stat=alcstat)
                call alccheck('fy_sfc', box_vol, alcstat) 
                allocate(fz_sfc(box_vol), stat=alcstat)
                call alccheck('fz_sfc', box_vol, alcstat) 

                ! ================================================
                ! KHL: directly generate the full SFC grid
                ! ================================================
                call hilbert3d_int(sfc_order, fx_sfc, fy_sfc, fz_sfc)
        endif

else
        box_vol = grid%bbox_pad%box_vol

        ! simple blocking:
        allocate(fx_sfc(box_vol),stat=alcstat)
        call alccheck('fx_sfc',box_vol,alcstat) 
        allocate(fy_sfc(box_vol),stat=alcstat)
        call alccheck('fy_sfc',box_vol,alcstat) 
        allocate(fz_sfc(box_vol),stat=alcstat)
        call alccheck('fz_sfc',box_vol,alcstat) 

        f_tmp = 1

        do i = nxmin, nxmax, fold%blocksize(1)
        do j = nymin, nymax, fold%blocksize(2)
        do k = nzmin, nzmax, fold%blocksize(3)
                fx_sfc(f_tmp:(f_tmp+fold%volume-1)) = i + fold%foldx(:)
                fy_sfc(f_tmp:(f_tmp+fold%volume-1)) = j + fold%foldy(:)
                fz_sfc(f_tmp:(f_tmp+fold%volume-1)) = k + fold%foldz(:)
                f_tmp = f_tmp + fold%volume
        enddo
        enddo
        enddo

        write(9,*) "indexed entire padded domain, fold_vol, f_tmp, i j k:", &
                fold%volume, f_tmp, i, j, k

endif






end subroutine generate_grid_point_index_v2






end subroutine grid_partition








!===============================================================
!
!  Simple partitioning routine.
!  Split the nwedge-long vector into nnodes equal parts.
!
!---------------------------------------------------------------
integer function Part(grid, parallel, nnodes, i, j, k, lprint)

use constants
use grid_module
use parallel_data_module
implicit none
!
!  Input/Output variables:
!
type(grid_data), intent(in) :: grid
type(parallel_data), intent(in) :: parallel
integer, intent(in) :: nnodes
integer, intent(in) :: i, j, k
logical, intent(in) :: lprint

integer nef, ii
!---------------------------------------------------------------

!  Give the processor number for the current i,j,k
!  For this routine partition according to rows:
!  (ijk) -> Indexw(ijk)
!
! TODO: rewrite this without using ist, only using irows
nef = grid%indexw(i,j,k)

do ii = 0, nnodes-1
        if (nef >= parallel%irows(ii) .and. nef < parallel%irows(ii+1)) then
                Part = ii
                return
        endif
enddo

Part = -1

if (lprint) write(7,*) 'The row nef:', nef, &
        'is outside bounds nwedge:', grid%nwedge

end function Part













!===============================================================
!
!  Determines if the point rr is outside the computational
!  domain.  The grid structure is needed since it contains
!  the type of domain shape and the necessary parameters.
!
!---------------------------------------------------------------
logical function outside_domain(grid, rr)

use constants
use grid_module
implicit none
!
!  Input/Output variables:
!
type(grid_data), intent(in) :: grid
real(dp), dimension(3), intent(in) :: rr
!
!  Work variables:
!
real(dp) :: rad2, rr_rad2, coord, polar1, polar2

! ---------------------------------------------------------------

coord = 0.d0
polar1 = 0.d0
polar2 = 0.d0

! generic return -> point rr is outside the domain
outside_domain = .true.

select case(grid%domain_shape)
case (0)
        ! Sphere
        ! points inside the sphere obey 
        ! x**2 + y**2 + z**2 <= r**2

        ! grid%d_shape_param(1) is the radius
        rad2 = grid%d_shape_param(1)**2
        !\todo AJB: perhaps the way to allow folds+symmetry is to include
        ! the triangle inequality in the domain test

        rr_rad2 = dot_product(rr, rr)

        outside_domain = (rr_rad2 > rad2)
case (1)
     ! Ellipsoid
     ! points inside the sphere obey 
     ! (x/r_x)**2 + (y/r_y)**2 + (z/r_z)**2 <= 1

     outside_domain = &
       ((rr(1) / grid%d_shape_param(1))**2 + &
        (rr(2) / grid%d_shape_param(2))**2 + &
        (rr(3) / grid%d_shape_param(3))**2     > 1.0d0)
case (2)
     ! Cylinder
     ! points inside the cylinder obey
     ! x**2 + y**2 <= r**2 AND |z| <= length
     ! for a cylinder oriented along the z-axis

     ! Get the length coordinate and the polar coordinates
     select case(grid%i_shape_param(1))
         case (1)
            ! oriented along x-axis
            coord = rr(1)
            polar1 = rr(2)
            polar2 = rr(3)
         case (2)
            ! oriented along y-axis
            coord = rr(2)
            polar1 = rr(1)
            polar2 = rr(3)
         case (3)
            ! oriented along z-axis
            coord = rr(3)
            polar1 = rr(2)
            polar2 = rr(1)
     end select

     outside_domain = &
       ( (polar1**2 + polar2**2 >  grid%d_shape_param(1)**2   ) &
                  .or. coord**2 > (grid%d_shape_param(2)/2.0d0)**2 )
case (3)
        ! Box
        ! If the coordinate is outside the length/2 (in magnitude)...

        outside_domain = ( &
                rr(1)**2 > (grid%d_shape_param(1)/2.0d0)**2 .or. &
                rr(2)**2 > (grid%d_shape_param(2)/2.0d0)**2 .or. &
                rr(3)**2 > (grid%d_shape_param(3)/2.0d0)**2)
end select

end function outside_domain
!===============================================================
end module grid_partition_module
