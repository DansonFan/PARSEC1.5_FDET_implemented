module inipbc_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  Define "reciprocal space" information and constructs the
!  reciprocal space.
!  
!  Call fourier_f to construct the relevant quanitites
!  (this breaks fourier filtering of pseudos for non pbc calculations)
!---------------------------------------------------------------
subroutine inipbc(clust, p_pot, grid, pbc, symm, ipr, ierr)

use constants
use cluster_module
use pseudo_potential_module
use grid_module
use pbc_module
use symmetry_module
use aux, only : mtrxin
use g_space_module, only : g_space
use fourier_f_module, only : fourier_f

implicit none



!  Input/Output variables:


! the cluster - needed for fourier_f
type(cluster), intent(in) :: clust

! pseudo_potential structure - needed for fourier_f
type(pseudo_potential), intent(inout) :: p_pot

type(grid_data), intent(inout) :: grid
type(pbc_data), intent(inout) :: pbc 
type(symmetry), intent(in) :: symm

!  print flag
integer, intent(in) :: ipr

!  error flag
integer, intent(out) :: ierr


!  Work variables:
integer :: ii
integer :: fold_x
integer :: fold_y
integer :: fold_z
integer, dimension(3) :: kmax
real(dp) :: htemp
real(dp) :: step_temp
real(dp) :: hold_step
real(dp) :: tmptr
real(dp) :: tmpdet
real(dp) :: tmpnorm
real(dp), dimension(3,3) :: tmpmat
logical  :: found_step


! ---------------------------------------------------------------

ierr = 0

fold_x = grid%fold%side_length
fold_y = grid%fold%side_length
fold_z = grid%fold%side_length



write(7,*) 'Reciprocal Space Data:'
write(7,*) '----------------------'



tmpmat(:,:) = transpose(pbc%latt_vec(:,:))
pbc%adot(:,:) = matmul(tmpmat(:,:), pbc%latt_vec(:,:))



! =====================================================
!  Using the following equation for the reciprocal
!  lattice vectors:     
!
!            T                 -1
!  [b1 b2 b3]  =  2pi [a1 a2 a3]  
!
!  note the definition of bvec here means that
!  reciprocal lattice vector i is given by bvec(:,i) !
!  this exactly as latt_vec arrangement. 
!  while lattic vector i is given by avec(i,:).
! =====================================================

pbc%bvec(:,:) = transpose(pbc%latt_vec(:,:))

call mtrxin(m=pbc%bvec(1,1), det=tmpdet, tr=tmptr)

!  Now multiplying bvec by 2Pi to agree to definition of 
!  reciprocal lattice vector.

pbc%bvec(:,:) = twopi * pbc%bvec(:,:)

!  Calculating the metric matrix.

pbc%bdot(:,:) = matmul(transpose(pbc%bvec(:,:)), pbc%bvec(:,:))

write(7,*) 'Reciprocal Lattice (a.u.):'

do ii = 1, pbc%per
        write(7,'(3(f15.10,1x))') pbc%bvec(1:pbc%per,ii)
enddo
  
grid%step(:) = grid%stepin

!\note AJB: these all seem to me as simply inits
grid%n1 = int(two*grid%rmax/grid%stepin) + 2
grid%n2 = grid%n1
grid%n3 = grid%n1

pbc%n1 = 1
pbc%n2 = 1
pbc%n3 = 1

! save the input stepin
htemp = grid%stepin
found_step = .false.

do while (.not. found_step)
        !  1) The new grid spacings must be commensurate with the lattice vectors as
        !  well as with all fractional translations present in non-symmorphic
        !  symmetry operations.

        hold_step = grid%stepin

        write(9,*) "calling adjust step now"
        call adjust_step(symm, pbc%per, pbc%box_size(:), grid%stepin, &
                grid%step(:), ierr)

        if (ierr > 0) return
  
        grid%stepin = minval(grid%step(1:pbc%per))

        !if (grid%stepin > hold_step) then
                ! adjust step increased the step size
                !let us try again with 5% smaller step
        !        hold_step = grid%stepin
        !        grid%stepin = 0.95d0*htemp

        !        write(9,*) "re-calling ajust step now with input step:", &
        !                grid%stepin

        !        call adjust_step(symm, pbc%per, pbc%box_size(:), &
        !                grid%stepin, grid%step(:), ierr)

        !        if (ierr > 0) return
        !endif

        if (abs(hold_step - grid%stepin) < parsec_tol) then
                ! adjust step did not adjust step
                found_step = .true.
        endif

        !  2) Also need to decrease grid spacing so that there will be 
        !     integer number of folds/blocks
        !     inside unit cell. These are the new n1,n2,n3
        if ( pbc%per >= 1 ) then
                !nint rounds to nearest whole number
                grid%n1 = fold_x * &
                        nint(pbc%box_size(1)/(real(fold_x,dp)*grid%step(1)))

                if (grid%n1 == 0) then
                        write(9,*) "inipbc, round-off problems on dir 1"
                        grid%n1 = fold_x* &
                                int(ceiling(pbc%box_size(1)/ &
                                (real(fold_x,dp)*grid%step(1))))
                endif

                !redo adjust_step if necessary
                step_temp = pbc%box_size(1)/real(grid%n1,dp)

                if (abs(grid%step(1) - step_temp) > parsec_tol) then
                        write(9,*) "inipbc, step(1) would need to be ajusted"
                        write(9,*) "grid%step(1)", grid%step(1)
                        write(9,*) "step_temp", step_temp
                        found_step = .false.
                        grid%step(1) = pbc%box_size(1)/real(grid%n1,dp)
                        write(9,*) "grid%step(1) changed to", grid%step(1)
                endif
        endif

        if ( pbc%per >= 2 ) then
                !nint rounds to nearest whole number
                grid%n2 = fold_y * &
                        nint(pbc%box_size(2)/(real(fold_y,dp)*grid%step(2)))

                if (grid%n2 == 0) then
                        write(9,*) "inipbc, round-off problems on dir 2"
                        grid%n2 = fold_y * &
                                int(ceiling(pbc%box_size(2)/ &
                                (real(fold_y,dp)*grid%step(2))))
                endif

                !redo adjust_step if necessary
                step_temp = pbc%box_size(2)/real(grid%n2,dp)

                if (abs(grid%step(2) - step_temp)>parsec_tol) then
                        write(9,*) "inipbc, step(2) would need to be ajusted"
                        write(9,*) "grid%step(2)", grid%step(2)
                        write(9,*) "step_temp", step_temp
                        found_step = .false.
                        grid%step(2) = pbc%box_size(2)/real(grid%n2,dp)
                        write(9,*) "grid%step(2) changed to", grid%step(2)
                endif
        endif

        if ( pbc%per >= 3 ) then
                !nint rounds to nearest whole number
                !TODO: this should change if using pbc and 
                !real wavefunctions, but is not that bad
                grid%n3 = fold_z * &
                        nint(pbc%box_size(3)/(real(fold_z,dp)*grid%step(3)))

                if (grid%n3 == 0) then
                        write(9,*) "inipbc, round-off problems on dir 2"
                        grid%n3 = fold_z * &
                                int(ceiling(pbc%box_size(3)/ &
                                (real(fold_z,dp)*grid%step(3))))
                endif

                !redo adjust_step if necessary
                step_temp = pbc%box_size(3)/real(grid%n3,dp)

                if (abs(grid%step(3) - step_temp)>parsec_tol) then
                        write(9,*) "inipbc, step(3) would need to be ajusted"
                        write(9,*) "grid%step(3)", grid%step(3)
                        write(9,*) "step_temp", step_temp
                        found_step = .false.
                        grid%step(3) = pbc%box_size(3)/real(grid%n3,dp)
                        write(9,*) "grid%step(3) changed to", grid%step(3)
                endif
        endif
 
        hold_step = minval(grid%step(1:pbc%per))
enddo !while found_step



write(9,*) " done adjusting step size"
write(9,*) "box_size", pbc%box_size(:)
write(9,*) "step", grid%step(:)
write(9,*) "box/step", pbc%box_size(1:pbc%per)/grid%step



!now that we are done, let us copy the decided box sides also to pbc
if ( pbc%per >= 1 ) then
        pbc%n1 = grid%n1
endif
if ( pbc%per >= 2 ) then
        pbc%n2 = grid%n2
endif
if ( pbc%per >= 3 ) then
        pbc%n3 = grid%n3
endif




!  Calculation of inverse of normalized lattice vectors
!  matrix - this is needed for the calculation in gradmvs.


! =====================================
! we prefer the same grid spacing in all directions
! even if only some of them are periodic,
!
! KHL: I do not understand why we force the grid spacing
!      in all directions the same... This is not there in parsec 1.4.
!      Not sure if this had been tested and advantageous.
!      I comment this out, so that we can make comparison with 1.4 in
!      the example of 2d non-ortho. grid.
! =====================================
!if (pbc%per < 2) then 
!        grid%step(2) = grid%step(1)
!endif
!if (pbc%per < 3) then 
!        grid%step(3) = grid%step(2)
!endif
! =====================================




tmpmat(:,:) = pbc%latt_vec(:,:)

do ii = 1, 3
        tmpnorm = sqrt(sum(tmpmat(:,ii)**2))
        tmpmat(:,ii) = tmpmat(:,ii)/tmpnorm
enddo

pbc%avec_norm(:,:) = tmpmat(:,:)

call mtrxin(tmpmat(:,:), tmpdet, tmptr)

grid%grad_bvec_norm(:,:) = transpose(tmpmat(:,:))
      

!  Calculation of volume element is done like this:
! \note AJB: umm, what?
!  hcub=det(grid%step(1)*x_vec+grid%step(2)*y_vec*grid%step(2)*z_vec)
!  x_vec,y_vec and z_vec are the unit vectors in direction of lattice
!  vectors.

tmpmat(:,:) = pbc%latt_vec(:,:)

write(9,*) "tmpmat <- pbc%latt_vec"
write(9,*) tmpmat(:,:)
write(9,*) "grid%step :", grid%step(:)
      
do ii = 1, 3
        tmpmat(:,ii) = grid%step(ii)*tmpmat(:,ii)/sqrt(sum(tmpmat(:,ii)**2))
enddo

!  Calling inversion routine because it computes also the 
!  required determinant and puts it in grid%hcub.
!  \note AJB: assuming the program wont crash because the matrix is singular
write(9,*) "tmpmat:"
write(9,*) tmpmat
call mtrxin(tmpmat(:,:), grid%hcub, tmptr)

!  So since we changed grid%step we also change hcub
grid%hcub = abs(grid%hcub)
! ...and two_invhcub
grid%two_invhcub = two/grid%hcub
!
!  kmax = n/2 if n is even; kmax = (n+1)/2 otherwise
!
!  kmax = 0 along non-periodic directions
kmax(:) = 0
if (pbc%per >= 1) kmax(1) = nint( (real(grid%n1,dp) + one/four)/ two )
if (pbc%per >= 2) kmax(2) = nint( (real(grid%n2,dp) + one/four)/ two )
if (pbc%per >= 3) kmax(3) = nint( (real(grid%n3,dp) + one/four)/ two )

pbc%vcell = grid%n1*grid%n2*grid%n3*grid%hcub


! Calculate 2-D cell area directly from lattice vectors
if (pbc%per==2) then
     pbc%a_surface_cell = abs(pbc%latt_vec(1,1)*pbc%latt_vec(2,2) - pbc%latt_vec(1,2)*pbc%latt_vec(2,1))
endif
 
!\note AJB moved fourier_f from parsec.f90 to here, since the step is being adjusted!



! ===============================================================
! Calculate Fourier transform of pseudopotentials
! Performed by master PE only.
! ===============================================================
! Actually, this is a fourier filtering and stuff is being replaced.
! However, this is only done if alpha and acore are set to all atom types
! More importantly, this also defines the Fourier transforms of the local
! pseudopotential and core-charge-density, so maybe it is a good idea to split
! this into two functions!
! It is called here because the step size is important, but we can't 
! hide the fact that the fourier transforms in fourier_f are 1D and don't
! care about grid%step being a vector.

! Also,
! Because this is called inside inipbc, fourier filtering is not available
! to non pbc calculations...
!write(9,*) "DEBUG:: going into fourier_f"
call fourier_f(clust, p_pot, pbc, grid%step(1),ipr) !instead of grid%stepin
!write(9,*) "done!"



!  rescale alpha energy
! (meaning that pbc%ealpha has to be set beforehand)
! this can easily be moved into fourier_f 
pbc%ealpha = pbc%ealpha/pbc%vcell

if(pbc%per==2) then
      !\todo AJB: why only if per==2? what's going on with per==1?
    pbc%ealpha=0
endif

!  construct reciprocal space
!\todo AJB: should time this and make it more efficent someday.
call g_space(pbc, symm, kmax, ipr, ierr)



write(7,*)
write(7,21) htemp
write(7,22) grid%step(:)
write(7,24) grid%n1, grid%n2, grid%n3
write(7,*)

21 format(' Input grid spacing:',1X,F6.3,1X,'bohr')
22 format(' Final grid spacings:',1X,3(F6.3,1X),'bohr')
24 format(' Number of grid points along each direction:',3(1X,I3))

end subroutine inipbc













!===============================================================
!
!  For input coordinates (i,j,k) in FFT grid, calculate the address
!  and phase associated to these coordinates. Input coordinates are
!  of the form 0 < i =< n1, and similarly for j, k. Output phase is
!  exp( -i G . V ) where V is the shift vector: coordinates of the
!  corner point in the real-space grid.
!
!---------------------------------------------------------------
subroutine get_address(pbc,i,j,k,iadd,phase)
  use constants
  use pbc_module
  implicit none
  !
  !  Input/Output variables:
  !
  !  pbc related data
  type (pbc_data), intent(in) :: pbc
  !  coordinates of g-vector in FFT grid
  integer, intent(in) :: i, j, k
  !  address of g-vector in FFT mesh
  integer, intent(out) :: iadd
  !  phase associated to this g-vector
  complex(dpc), intent(out) :: phase
  !
  !  Work variables:
  !
  !  exponent of phase
  real(dp) :: phi
  !  coordinates of g-vector
  integer :: gv(3)
  !---------------------------------------------------------------
  gv(1) = i - 1 - pbc%n1
  gv(2) = j - 1 - pbc%n2
  gv(3) = k - 1 - pbc%n3
  if (gv(1) < pbc%mx) gv(1) = gv(1) + pbc%n1
  if (gv(2) < pbc%my) gv(2) = gv(2) + pbc%n2
  if (gv(3) < pbc%mz) gv(3) = gv(3) + pbc%n3
  !\todo AJB: CHECK THIS CAREFULLY!
  iadd = ( (k-1)*pbc%n2 + j-1 )*pbc%n1 + i
  phi = dot_product(gv,pbc%shift)
  phase = cmplx(cos(phi),sin(phi),dpc)

end subroutine get_address





!===============================================================
!
!  Adjusts the grid spacing according to unit cell length and
!  translation vectors. Along each direction, the grid spacing (h)
!  must satisfy the following commensurability requirements:
!    a) a/h must be an even number, where "a" is the length of
!       the unit lattice vector along that direction. This way,
!       the real-space grid will be centered on the origin.
!    b) tau/h must be integer, where "tau" is any non-zero
!       translation vector (stored in symm%tnp). This requirement
!       is relevant only in non-symmorphic symmetry operations.
!       It makes the easy symmetrization of charge density
!       coded in subroutine scalar_symm possible.
!
!  author: Murilo L Tiago, ORNL, July 2007.
!
!---------------------------------------------------------------
subroutine adjust_step(symm, nper, box_size, stepin, stepout, ierr)

use constants
use symmetry_module
use aux, only : matvec3

implicit none
!
!  Input/Output variables:
!
type(symmetry), intent(in) :: symm

!  number of periodic directions
integer, intent(in) :: nper

!  length of lattice vectors
real(dp), dimension(3), intent(in) :: box_size

!  input grid spacing
real(dp), intent(in) :: stepin

!  output grid spacing
real(dp), dimension(3), intent(out) :: stepout

! error flag, 265 < ierr < 271
integer, intent(out) :: ierr
!
!  Work variables:
!
!  counters
integer :: itrans
integer :: idir
integer :: nn

!  temporary arrays
real(dp) :: xtest
real(dp) :: ytest
real(dp), dimension(3) :: tmpvec
real(dp), dimension(3,3) :: tmpmat

!  maximum number of grid order trials
integer, parameter :: nmax = 1000

!  tolerance in displacements
real(dp), parameter :: tol = 1.d-8

!  number of non-zero translations for each periodic direction
integer, dimension(nper) :: ntau

!  non-zero translations (in units of lattice vectors)
real(dp), dimension(nmax,nper) :: tau

!  shortest translation
real(dp) :: tau_min

!  true if the current grid spacing is commensurate with all translations
logical :: lcomm

! ---------------------------------------------------------------

ntau(:) = 0
tau(:,:) = zero

!  Go through all symmetry operations and search for the ones which have
!  fractional translations. Store those translations in array tau. When a
!  new translation is found, make it positive and increment the counter ntau.
do itrans = 1, symm%ntrans
        tmpmat(:,:) = real(symm%rmtrx(:,:,itrans), dp)

        call matvec3(op='N', mat=tmpmat(1,1), vec=symm%tnp(1,itrans), &
                mvec=tmpvec(1))

        do idir = 1, nper
                if (tmpvec(idir) < zero) tmpvec(idir) = -tmpvec(idir)

                if (tmpvec(idir) > tol) then
                        ntau(idir) = ntau(idir) + 1
                        tau(ntau(idir),idir) = tmpvec(idir)
                endif
        enddo
enddo

do idir = 1, nper
        !  Search for shortest translation. Notice that tau has zeros beyond
        !  ntau. If all translations are zero, choose tau_min = one.
        if (ntau(idir) == 0) then
                tau_min = one
        else
                tau_min = minval(tau(1:ntau(idir),idir))
        endif

        do nn = 1, nmax
                lcomm = .true.

                if (tau_min/real(nn,dp) < &
                        (stepin/box_size(idir) - parsec_tol)) then
                        ! write(9,'("adjust_step for dir",x,I3,x,": nn=",x,I4)'), idir,nn
                        ! write(9,*) "  exit condition encountered for - ", stepin/box_size(idir)
                        ! write(9,*) "  tau_min/nn is smaller - ", tau_min/real(nn,dp)
                        exit
                endif

                xtest = tau_min/real(nn,dp)

                !  Is this grid spacing commensurate with all translations?
                do itrans = 1, ntau(idir)

                        ytest = tau(itrans,idir)/xtest - nint(tau(itrans,idir)/xtest)

                        if (abs(ytest) > tol) then
                                lcomm = .false.
                                cycle
                        endif
                enddo

                !  Is the ratio between this grid spacing and lattice vector an
                !  even number?
                ytest = half/xtest - nint(half/xtest)

                if (abs(ytest) > tol) then
                        lcomm = .false.
                        cycle
                endif

                !  Save this grid spacing if commensurability conditions are satisfied.
                if (lcomm) then
                        ! write(9,*) "adjust_step - saving new step size as a fraction of box_size"
                        ! write(9,*) "fraction : ",xtest
                        stepout(idir) = xtest * box_size(idir)
                endif
        enddo

        !  Save this grid spacing if commensurability conditions are satisfied.
        if (nn == nmax) then
                write(9,*) 'ERROR in adjust_step! Could not find a commensurate grid spacing.'
                ierr = 266
                return
        endif
enddo

write(9,*) "adjust_step input step:", stepin
write(9,*) "adjust_step output step:", stepout(:)
write(9,*) "adjust_step end"

return
end subroutine adjust_step
!===============================================================
end module inipbc_module
