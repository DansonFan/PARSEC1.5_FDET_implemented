! ==================== grid structure ========================
module grid_module
use constants
use stencil_things
use aux, only : alccheck
implicit none

type bound_box
        !axis aligned bound box
        integer, dimension(3) :: box_min
        integer, dimension(3) :: box_max
        integer, dimension(3) :: box_sides
        integer :: box_vol

        contains
                procedure :: initalize => reset_bound_box
                procedure :: set => set_bound_box
                procedure :: from_3vec => get_bbox_from_3vec
end type bound_box

type foldblock
        !fold/block for 1D:
        integer, dimension(3) :: blocksize
        integer :: volume
        integer :: side_length
        integer, dimension(:), allocatable :: foldx
        integer, dimension(:), allocatable :: foldy
        integer, dimension(:), allocatable :: foldz

        contains 
                procedure :: initalize => init_fold
                procedure :: destroy => destroy_fold
                procedure :: create => create_fold
                procedure :: duplicate => copy_fold
end type foldblock




type grid_data
        ! boundary sphere size (atomic units) - for confined systems
        real(dp) :: rmax

        ! user provided grid spacing (atomic units) - h 
        real(dp) :: stepin

        ! step = program corrected h in each direction
        ! (different from user given one only for PBC)
        ! WARNING: if PBC are not used, step must be the same on all 3
        ! directions, otherwise the boundary charge in hartset will be wrong.
        real(dp), dimension(3) :: step

        ! hcub = h**3, two_invhcub = 2/(h**3), h_2 = h**2
        real(dp) :: hcub, two_invhcub, h_2

        ! total number of effective grid points
        integer :: ndim

        ! number of effective grid blocks/folds/coarse
        integer :: ndim_c

        ! total number of grid points in irreducible wedge/coarse wedge
        integer :: nwedge
        integer :: nwedge_c

        ! number of neighbors used on one side in numerical derivative
        integer :: norder

        ! number of external neighbors
        integer :: neibs_num

        ! order of double grid
        ! the number of dense-grid points between two neighbors in the
        ! original (coarser) grid is grid%ndouble - 1
        integer :: ndouble

        ! inverse order
        real(dp) :: invd

        ! coefficients in double-grid interpolation
        real(dp), dimension(:), allocatable :: fdouble

        ! nxmax-nxmin+1 -- number of grid points along x-axis (including
        ! points for derivative); same for y and z directions
        integer :: nxmin, nxmax
        integer :: nymin, nymax
        integer :: nzmin, nzmax
        integer :: nxyz

        ! n1,n2,n3 = number of grid points along x-axis, y-axis, and
        ! z-axis respectively (the ones that are actually used)
        integer :: n1, n2, n3

        ! 3d to 1d conversion table for grid point indexing - gives the
        ! 1d index based on the 3-d position (in h units, relative to the
        ! origin). Returns value of ndim+1 if point is outside the boundary sphere
        ! indexg(i,j,k) = ndim+1 for points outside the current boundary sphere
        ! indexg(i,j,k) = 1 to ndim for points inside the current boundary sphere
        integer, dimension(:,:,:), allocatable :: indexg

        ! indexw(i,j,k) : has the same meaning as indexg, but it is
        ! defined only in the irreducible wedge, after considering
        ! symmetry operations in the reduced, Abelian subgroup
        integer, dimension(:,:,:), allocatable :: indexw

        ! 1d to 3d conversion tables for grid point indexing - giving INDEX
        ! These arrays retrieve the three 3d indices for the ith 1d grid point
        ! 1d to 3d conversion tables for grid point indexing - giving
        ! cartesian coordinates (for irreducible wedge, replace fx with kx etc):
        ! xx = (shift(1) + kx)*h, yy=(shift(2) + ky)*h, zz=(shift(3) + kz)*h
        integer, dimension(:), allocatable :: kx, ky, kz
        integer, dimension(:), allocatable :: fx, fy, fz
        ! same as fx,kx but using a coarse grid representing the folded blocks:
        integer, dimension(:), allocatable :: kcx, kcy, kcz
        integer, dimension(:), allocatable :: cx, cy, cz
        ! map between c and f grids in grid and wedge
        integer, dimension(:), allocatable :: c2f, c2k





        ! hartree_neibs_flag is a logical flag that indicates
        ! whether the arrays neibs_index, neibs_fx, neibs_fy and neibs_fz
        ! are needed for the full hartree boundary conditions
        logical :: hartree_neibs_flag

     ! neibs_index is an array with an arbitrary index of all external 
     ! neighbors , this array is used to calculate some of the boundary
     ! conditions
     !integer, dimension (:,:,:), allocatable :: neibs_index
     ! neib_kx, neib_ky, neib_kz - has the same meanning as kx, ky and kz
     ! but for external grid points
     !integer, dimension (:), allocatable :: neibs_fx, neibs_fy, neibs_fz
     !
     ! shift of grid points
     real(dp), dimension(3) :: shift

        ! irreducible wedge parameters
        integer, dimension(:), allocatable :: rindex
        integer, dimension(:), allocatable :: rtrans

     ! data and arrays for the calculation of laplacian in
     ! non-orthogonal grid (u,v,w).

     ! number of additional directions for calculating derivatives:
     integer lap_dir_num

     ! direction value stored in lap_dir(3). Index meaning is 1 - uv 
     ! direction, 2 uw direction, 3 vw direction. Value meaning:
     ! 0 direction is not used, 1 u+v direction is used, -1 u-v
     ! direction is used.
     integer, dimension(3) :: lap_dir

     ! step size for each direction is stored in lap_dir_step(3)
     real(dp), dimension(3) :: lap_dir_step

     ! an array with the pointers of the 3 nearest neighbors that
     ! are used
     integer, dimension(3,3) :: lap_neig

     ! laplacian coefficients values for different directories
     ! this values are calculated by the routine pbc_grid_coefs
     real(dp), dimension(6) :: b_lap

     ! inverse of the normalized lattice vectors matrix.
     real(dp), dimension(3,3) :: grad_bvec_norm

     ! coefficients for the finite difference expansion
     real(dp), dimension (:,:), allocatable :: coe1, coe2
     ! coefficients for the gradient term of kinetic energy
     complex(dpc), dimension (:,:,:), allocatable :: kecoe1

     ! flag for domain shape in cluster BCs
     ! possible shapes:
     ! 0 - sphere, this is the default
     ! 1 - ellipsoid
     ! 2 - cylindrical
     ! 3 - box
     ! more options can be added.

     integer :: domain_shape

     ! Parameters relevant to the cluster shape
     ! The size of the array and the meaning of its parameters
     ! depend on the cluster shape.
     !
     ! Sphere: d_shape_param(1) = radius
     ! Ellipse: d_shape_param(1) = x radius
     !          d_shape_param(2) = y radius
     !          d_shape_param(3) = z radius
     ! Cylinder: d_shape_param(1) = radius
     !           d_shape_param(2) = length (centered at 0)
     !           i_shape_param(1) = orientation
     !                              (x = 1, y = 2, z = 3)
     ! Box: d_shape_param(1) = x length (centered at 0)
     !      d_shape_param(2) = y length (centered at 0)
     !      d_shape_param(3) = z length (centered at 0)
 
     real(dp), dimension(3)  :: d_shape_param
     integer, dimension(1) :: i_shape_param
     ! IMPORTANT: if the dimesions of these shape_param arrays
     ! are changed, update the broadcast statements in init_var
     !

        ! encapsulates laplacian data
        type(stencil_definitions) :: sten_def

        ! holds the tiled coeff for the folded stencil
        type(fold_stencil) :: sten_coeff


        ! bounding box information to be generated at grid creation time
        type(bound_box) :: bbox_domain
        type(bound_box) :: bbox_pad

        ! for the SFC itself
        type(bound_box) :: bbox_sfc

        ! The block/fold info 
        type(foldblock) :: fold

        ! use_sfc - Whether to use a space-filling curve based grid 
        !           partitioning scheme. If not, we will just 
        !           use a simple one
        logical :: use_sfc


end type grid_data


contains



subroutine init_grid(grid)
        use constants, only : zero
        implicit none
        type(grid_data), intent(inout) :: grid

        grid%step(:) = zero

        grid%nxmin = -1
        grid%nxmax = -1
        grid%nymin = -1
        grid%nymax = -1
        grid%nzmin = -1
        grid%nzmax = -1
end subroutine init_grid




subroutine destroy_grid(grid)
        implicit none
        type(grid_data), intent(inout) :: grid

        if (allocated(grid%fdouble)) deallocate (grid%fdouble) 
        if (allocated(grid%indexg)) deallocate (grid%indexg) 
        if (allocated(grid%indexw)) deallocate (grid%indexw)

        if (allocated(grid%kx)) deallocate (grid%kx) 
        if (allocated(grid%ky)) deallocate (grid%ky) 
        if (allocated(grid%kz)) deallocate (grid%kz)

        if (allocated(grid%kcx)) deallocate (grid%kcx) 
        if (allocated(grid%kcy)) deallocate (grid%kcy) 
        if (allocated(grid%kcz)) deallocate (grid%kcz)

        if (allocated(grid%c2k)) deallocate (grid%c2k)
        if (allocated(grid%c2f)) deallocate (grid%c2f)

        if (allocated(grid%fx)) deallocate (grid%fx)
        if (allocated(grid%fy)) deallocate (grid%fy)
        if (allocated(grid%fz)) deallocate (grid%fz)

        if (allocated(grid%cx)) deallocate (grid%cx)
        if (allocated(grid%cy)) deallocate (grid%cy)
        if (allocated(grid%cz)) deallocate (grid%cz)

        if (allocated(grid%rindex)) deallocate (grid%rindex)
        if (allocated(grid%rtrans)) deallocate (grid%rtrans)

        !if (allocated(grid%neibs_index)) deallocate (grid%neibs_index)
        !if (allocated(grid%neibs_fx)) deallocate (grid%neibs_fx)
        !if (allocated(grid%neibs_fy)) deallocate (grid%neibs_fy)
        !if (allocated(grid%neibs_fz)) deallocate (grid%neibs_fz)
        if (allocated(grid%coe1)) deallocate (grid%coe1)
        if (allocated(grid%kecoe1)) deallocate (grid%kecoe1)
        if (allocated(grid%coe2)) deallocate (grid%coe2)

        call grid%fold%destroy()
        call grid%sten_def%destroy()
        call grid%sten_coeff%destroy()
end subroutine destroy_grid




subroutine grid_set_rmax_step(rmax, step, grid)
        use constants
        implicit none
        real(dp), intent (in) :: rmax
        real(dp), intent (in) :: step
        type(grid_data), intent (inout) :: grid

        grid%rmax = rmax
        grid%stepin = step
        grid%hcub = step**3
        grid%two_invhcub = two/(step**3)
end subroutine grid_set_rmax_step





subroutine grid_set_index(nxmin, nxmax, nymin, nymax, nzmin, nzmax, grid)
        implicit none
        integer, intent(in) :: nxmin, nxmax, nymin, nymax, nzmin, nzmax
        type(grid_data), intent(inout) :: grid

        integer :: alcstat, nxyz

        grid%nxmax = nxmax
        grid%nxmin = nxmin
        grid%nymax = nymax
        grid%nymin = nymin
        grid%nzmax = nzmax
        grid%nzmin = nzmin

        nxyz = (nxmax-nxmin+1)*(nymax-nymin+1)*(nzmax-nzmin+1)

        allocate(grid%indexg(nxmin:nxmax,nymin:nymax,nzmin:nzmax), &
                stat=alcstat)
        call alccheck('indexg', nxyz, alcstat)

        !\note  AJB: I had an intel inspector report that this 
        ! is not initalized properly?
        ! commenting here to make sure this will be dealt with if 
        ! problem persists
        ! changing from this:
        grid%indexg(:,:,:) = 0
        ! to this:
        !grid%indexg = 0

        allocate(grid%indexw(nxmin:nxmax,nymin:nymax,nzmin:nzmax), &
                stat=alcstat)
        call alccheck('indexw', nxyz, alcstat)
        grid%indexw(:,:,:) = 0

        grid%nxyz = nxyz

end subroutine grid_set_index







subroutine grid_set_ndim(grid, ndim, ndim_c)
        implicit none
        type(grid_data), intent(inout) :: grid
        integer, intent(in) :: ndim
        integer, intent(in) :: ndim_c

        integer :: alcstat

        grid%ndim = ndim
        grid%ndim_c = ndim_c

        allocate(grid%rindex(ndim+1), stat=alcstat)
        call alccheck('grid%rindex', ndim+1, alcstat)
        allocate(grid%rtrans(ndim+1), stat=alcstat)
        call alccheck('grid%rtrans', ndim+1, alcstat)
end subroutine grid_set_ndim








subroutine grid_set_conversion(grid)
        implicit none
        type(grid_data), intent(inout) :: grid

        integer :: alcstat, ndim_f, ndim_c

        ndim_f = grid%ndim
        ndim_c = grid%ndim_c

        ! write(9,*) "grid_set_conversion - allocating fx, ndim_f:",ndim_f

        allocate(grid%fx(ndim_f), stat=alcstat)
        call alccheck('grid%fx', ndim_f, alcstat)
        allocate(grid%fy(ndim_f), stat=alcstat)
        call alccheck('grid%fy', ndim_f, alcstat)
        allocate(grid%fz(ndim_f), stat=alcstat)
        call alccheck('grid%fz', ndim_f, alcstat)

        ! write(9,*) "grid_set_conversion - allocating cx, ndim_c:",ndim_c

        allocate(grid%cx(ndim_c), stat=alcstat)
        ! write(9,*) "back from cx"
        call alccheck('grid%cx', ndim_c, alcstat)

        allocate(grid%cy(ndim_c), stat=alcstat)
        ! write(9,*) "back from cy"
        call alccheck('grid%cy', ndim_c, alcstat)

        allocate(grid%cz(ndim_c), stat=alcstat)
        ! write(9,*) "back from cz"
        call alccheck('grid%cz', ndim_c, alcstat)

        ! write(9,*) "grid_set_conversion - allocating c2f"

        allocate (grid%c2f(ndim_c+1), stat=alcstat)
        call alccheck('grid%c2f', ndim_c+1, alcstat)

        ! write(9,*) "grid_set_conversion - done"

end subroutine grid_set_conversion

  ! subroutine grid_set_ext_neibs(grid, nnodes)
  !   implicit none
  !   ! half order of finite difference
  !   type (grid_data), intent (inout) :: grid
  !   integer, intent(in) :: nnodes

  !   integer :: alcstat

  !   allocate(grid%neibs_fx (grid%neibs_num), stat=alcstat)
  !   call alccheck('grid%neibs_fx',grid%neibs_num,alcstat)
  !   allocate(grid%neibs_fy (grid%neibs_num), stat=alcstat)
  !   call alccheck('grid%neibs_fy',grid%neibs_num,alcstat)
  !   allocate(grid%neibs_fz (grid%neibs_num), stat=alcstat)
  !   call alccheck('grid%neibs_fz',grid%neibs_num,alcstat)


  ! end subroutine grid_set_ext_neibs

  ! subroutine grid_destroy_ext_neibs(grid,nnodes)
  !   implicit none
  !   ! half order of finite difference
  !   type (grid_data), intent (inout) :: grid
  !   integer, intent(in) :: nnodes

  !   if(allocated(grid%neibs_fx)) deallocate(grid%neibs_fx)
  !   if(allocated(grid%neibs_fy)) deallocate(grid%neibs_fy)
  !   if(allocated(grid%neibs_fz)) deallocate(grid%neibs_fz)
  !   if(allocated(grid%neibs_index)) deallocate(grid%neibs_index)

  ! end subroutine grid_destroy_ext_neibs


subroutine grid_set_wedge(grid)
        implicit none
        ! half order of finite difference
        type(grid_data), intent(inout) :: grid
        integer :: alcstat

        allocate(grid%kx(grid%nwedge), stat=alcstat) 
        call alccheck('grid%kx', grid%nwedge, alcstat)
        allocate(grid%ky(grid%nwedge),stat=alcstat)
        call alccheck('grid%ky', grid%nwedge, alcstat)
        allocate(grid%kz(grid%nwedge),stat=alcstat)
        call alccheck('grid%kz', grid%nwedge, alcstat)

        allocate(grid%kcx(grid%nwedge_c), stat=alcstat) 
        call alccheck('grid%kcx', grid%nwedge_c, alcstat)
        allocate(grid%kcy(grid%nwedge_c), stat=alcstat)
        call alccheck('grid%kcy', grid%nwedge_c, alcstat)
        allocate(grid%kcz(grid%nwedge_c), stat=alcstat)
        call alccheck('grid%kcz', grid%nwedge_c, alcstat)

        allocate(grid%c2k(grid%nwedge_c+1), stat=alcstat)
        call alccheck('grid%c2k', grid%nwedge_c+1, alcstat)
end subroutine grid_set_wedge












subroutine reset_bound_box(bbox)
        implicit none
        class(bound_box) :: bbox
        bbox%box_min(:) = 0
        bbox%box_max(:) = 0
        bbox%box_sides(:) = 0
        bbox%box_vol = 0
end subroutine reset_bound_box





subroutine set_bound_box(bbox, minx, miny, minz, maxx, maxy, maxz)
        implicit none
        class(bound_box) :: bbox
        integer, intent(in) :: minx, miny, minz, maxx, maxy, maxz

        bbox%box_min(1) = minx
        bbox%box_min(2) = miny
        bbox%box_min(3) = minz
        bbox%box_max(1) = maxx
        bbox%box_max(2) = maxy
        bbox%box_max(3) = maxz

        bbox%box_sides(:) = bbox%box_max(:) - bbox%box_min(:) + 1

        ! write(*,*) "box sides now:", bbox%box_sides

        bbox%box_vol = product(bbox%box_sides(:))
end subroutine set_bound_box





subroutine get_bbox_from_3vec(bbox, vec_x, vec_y, vec_z, from, to)
        implicit none

        class(bound_box) :: bbox
        integer, dimension(:), intent(in) :: vec_x, vec_y, vec_z
        integer, intent(in) :: from, to

        integer :: vec_size

        if (from > to) then
                write(*,*) "get_bbox...: the vector range is wrong", from, to
                stop
        endif

        vec_size = size(vec_x)

        if (to > vec_size) then
                write(*,*) "get_bbox...: vector range exceeds vector length", &
                        to, vec_size
                stop
        endif
    
        bbox%box_min(1) = minval(vec_x(from:to))
        bbox%box_min(2) = minval(vec_y(from:to))
        bbox%box_min(3) = minval(vec_z(from:to))
        bbox%box_max(1) = maxval(vec_x(from:to))
        bbox%box_max(2) = maxval(vec_y(from:to))
        bbox%box_max(3) = maxval(vec_z(from:to))

        bbox%box_sides(:) = bbox%box_max(:) - bbox%box_min(:) + 1
        bbox%box_vol = PRODUCT(bbox%box_sides(:))
end subroutine get_bbox_from_3vec




subroutine init_fold(fold)
        implicit none
        class(foldblock) :: fold
        fold%blocksize(:) = -1
        fold%volume = -1
end subroutine init_fold






subroutine destroy_fold(fold)
        implicit none
        class(foldblock) :: fold

        fold%blocksize(:) = -1
        fold%volume = -1

        if (allocated(fold%foldx)) deallocate(fold%foldx)
        if (allocated(fold%foldy)) deallocate(fold%foldy)
        if (allocated(fold%foldz)) deallocate(fold%foldz)
end subroutine destroy_fold





subroutine create_fold(fold, sizex, sizey, sizez)
        implicit none

        class(foldblock) :: fold
        integer, intent(in) :: sizex
        integer, intent(in) :: sizey
        integer, intent(in) :: sizez

        integer :: Fi
        integer :: Fj
        integer :: Fk
        integer :: fold_ind
        integer :: IND

        if (sizex < 1 .or. sizey < 1 .or. sizez < 1) then
                write(9,*) "WARNING: in create_fold: fold size incorrect, &
                        &using default (1 2 4)"

                fold%blocksize(1) = 1
                fold%blocksize(2) = 2
                fold%blocksize(3) = 4
        else
                fold%blocksize(1) = sizex
                fold%blocksize(2) = sizey
                fold%blocksize(3) = sizez
        endif

        fold%volume = product(fold%blocksize(:))
    
        allocate(fold%foldx(fold%volume))
        allocate(fold%foldy(fold%volume))
        allocate(fold%foldz(fold%volume))

        fold%foldx(:) = 0
        fold%foldy(:) = 0
        fold%foldz(:) = 0
        fold_ind = 0

        do Fi = 1, fold%blocksize(1)
        do Fj = 1, fold%blocksize(2)
        do Fk = 1, fold%blocksize(3)
                fold_ind = fold_ind + 1
                fold%foldx(fold_ind) = Fi - 1
                fold%foldy(fold_ind) = Fj - 1
                fold%foldz(fold_ind) = Fk - 1
        enddo
        enddo
        enddo

        write(9,*) "Fold created"
        write(9,'(I3,I3,I3)') (fold%foldx(IND),fold%foldy(IND),&
                fold%foldz(IND),IND=1,fold_ind)

end subroutine create_fold





subroutine copy_fold(fold, origin)
        implicit none
        class(foldblock) :: fold
        type(foldblock), intent(in) :: origin

        fold%blocksize(1) = origin%blocksize(1)
        fold%blocksize(2) = origin%blocksize(2)
        fold%blocksize(3) = origin%blocksize(3)

        fold%volume = origin%volume
    
        allocate(fold%foldx(fold%volume))
        allocate(fold%foldy(fold%volume))
        allocate(fold%foldz(fold%volume))

        fold%foldx(:) = origin%foldx(:)
        fold%foldy(:) = origin%foldy(:)
        fold%foldz(:) = origin%foldz(:)
end subroutine copy_fold





end module grid_module





! parking spot for my very crude implementation of a recursive algorithm to
! create an approximation to the hilbert space filling curve
! it is an okay spot since it is technically part of the grid
module sfc_module
use constants

contains

        recursive pure subroutine create_hilbert3d(order, rx, ry, rz)
                implicit none

                ! order of hilbert curve
                integer, intent(in) :: order

                real(dp), dimension(8**(order)), intent(out) :: rx
                real(dp), dimension(8**(order)), intent(out) :: ry
                real(dp), dimension(8**(order)), intent(out) :: rz

                real(dp), dimension(:), allocatable :: rx0
                real(dp), dimension(:), allocatable :: ry0
                real(dp), dimension(:), allocatable :: rz0
                integer :: IND0
                integer :: IND1

                allocate(rx0(8**(order-1)))
                allocate(ry0(8**(order-1)))
                allocate(rz0(8**(order-1)))

                if (order <= 0) then
                        rx(:) = zero
                        ry(:) = zero
                        rz(:) = zero
                else
                        call create_hilbert3d(order-1, rx0(:), ry0(:), rz0(:))

                        IND1 = size(rx0(:))

                        IND0 = 1
                        rx(IND0:IND0+IND1-1) = half*(half +rz0(:))
                        ry(IND0:IND0+IND1-1) = half*(half +rx0(:))
                        rz(IND0:IND0+IND1-1) = half*(half +ry0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(half +ry0(:))
                        ry(IND0:IND0+IND1-1) = half*(half +rz0(:))
                        rz(IND0:IND0+IND1-1) = half*(mhalf+rx0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(mhalf+ry0(:))
                        ry(IND0:IND0+IND1-1) = half*(half +rz0(:))
                        rz(IND0:IND0+IND1-1) = half*(mhalf+rx0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(mhalf-rx0(:))
                        ry(IND0:IND0+IND1-1) = half*(half +ry0(:))
                        rz(IND0:IND0+IND1-1) = half*(half -rz0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(mhalf-rx0(:))
                        ry(IND0:IND0+IND1-1) = half*(mhalf+ry0(:))
                        rz(IND0:IND0+IND1-1) = half*(half -rz0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(mhalf-ry0(:))
                        ry(IND0:IND0+IND1-1) = half*(mhalf-rz0(:))
                        rz(IND0:IND0+IND1-1) = half*(mhalf+rx0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(half -ry0(:))
                        ry(IND0:IND0+IND1-1) = half*(mhalf-rz0(:))
                        rz(IND0:IND0+IND1-1) = half*(mhalf+rx0(:))

                        IND0 = IND0 + IND1
                        rx(IND0:IND0+IND1-1) = half*(half +rz0(:))
                        ry(IND0:IND0+IND1-1) = half*(mhalf-rx0(:))
                        rz(IND0:IND0+IND1-1) = half*(half -ry0(:))
                endif

                deallocate(rx0)
                deallocate(ry0)
                deallocate(rz0)
        end subroutine create_hilbert3d

        subroutine hilbert3d_int(order, fx, fy, fz)
                implicit none

                integer, intent(in) :: order
                integer, dimension(8**order), intent(out) :: fx, fy, fz

                integer :: to_index
                real(dp), dimension(:), allocatable :: rx, ry, rz

                allocate(rx(8**order))
                allocate(ry(8**order))
                allocate(rz(8**order))

                to_index = 2**(order + 1)

                call create_hilbert3d(order, rx(:), ry(:), rz(:))

                fx(:) = (nint(rx(:)*real(to_index)) + 1)/2
                fy(:) = (nint(ry(:)*real(to_index)) + 1)/2
                fz(:) = (nint(rz(:)*real(to_index)) + 1)/2

                deallocate(rx)
                deallocate(ry)
                deallocate(rz)
        end subroutine hilbert3d_int



end module sfc_module
