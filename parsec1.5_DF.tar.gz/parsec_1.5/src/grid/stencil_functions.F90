! This file is part of parsec yada yada
! Poor man's vector folded stencils
! This is a simple tailor-made library of matrix-vector products
! I tried using the SIMD enabling thing, seems like it worked
!   we first show this for 2x2x2
!
! todo: explain more
module stencil_functions

use constants, only : dzero, dp

implicit none

integer, parameter :: vecsize = 8

contains




subroutine d222_CENTER(c0, cX, cY, cZ, invec, outvec)
        ! [ c0, cZ, cY,  0, cX,  0,  0,  0]
        ! [ cZ, c0,  0, cY,  0, cX,  0,  0]
        ! [ cY,  0, c0, cZ,  0,  0, cX,  0]
        ! [  0, cY, cZ, c0,  0,  0,  0, cX]
        ! [ cX,  0,  0,  0, c0, cZ, cY,  0]
        ! [  0, cX,  0,  0, cZ, c0,  0, cY]
        ! [  0,  0, cX,  0, cY,  0, c0, cZ]
        ! [  0,  0,  0, cX,  0, cY, cZ, c0]
        real(dp), intent(in) :: c0
        real(dp), intent(in) :: cX
        real(dp), intent(in) :: cY
        real(dp), intent(in) :: cZ
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner
        !integer, dimension(vecsize), parameter :: &
        !        idx1 = [5, 6, 7, 8, 1, 2, 3, 4]
        !integer, dimension(vecsize), parameter :: &
        !        idx2 = [3, 4, 1, 2, 7, 8, 5, 6]
        !integer, dimension(vecsize), parameter :: &
        !        idx3 = [2, 1, 4, 3, 6, 5, 8, 7]

        !center is responsible for initing outvec.#badcoding #sorrynotsorry
        !can you guarantee it gets called first? - if not, just call an init
        !func first
        !!$omp simd aligned(outvec,invec,idx1,idx2,idx3)
        !do inner = 1, 8
        !        outvec(inner) = c0*invec(inner) + &
        !                cX*invec(idx1(inner)) + &
        !                cY*invec(idx2(inner)) + &
        !                cZ*invec(idx3(inner))
        !enddo

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = c0*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner)   = outvec(inner)   + cX*invec(inner+4)
                outvec(inner+4) = outvec(inner+4) + cX*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner)   = outvec(inner)   + cY*invec(inner+2)
                outvec(inner+2) = outvec(inner+2) + cY*invec(inner)
                outvec(inner+4) = outvec(inner+4) + cY*invec(inner+6)
                outvec(inner+6) = outvec(inner+6) + cY*invec(inner+4)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + cZ*invec(2:8:2)
        outvec(2:8:2) = outvec(2:8:2) + cZ*invec(1:7:2)


end subroutine d222_CENTER





subroutine d222_DUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU
        real(dp), intent(in) :: cL
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner) + cU*invec(inner+4)
                outvec(inner+4) = outvec(inner+4) + &
                        cDiag*invec(inner+4) + cL*invec(inner)
        enddo

end subroutine d222_DUL








subroutine d222_DU(cDiag, cU, invec, outvec)
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + cU*invec(inner+4)
        enddo


end subroutine d222_DU



subroutine d222_DL(cDiag, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cL
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 5, 8
                outvec(inner) = outvec(inner) + cL*invec(inner-4)
        enddo

end subroutine d222_DL





subroutine d222_DULDUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU
        real(dp), intent(in) :: cL
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner
        !integer, dimension(4), parameter :: &
        !        idx1 = [1, 2, 5, 6]
        !integer, dimension(4), parameter :: &
        !        idx2 = [3, 4, 7, 8]

        !!$omp simd aligned(outvec,invec,idx1,idx2)
        !do inner = 1, 4
        !        outvec(idx1(inner)) = outvec(idx1(inner)) + &
        !                cDiag*invec(idx1(inner)) + cU*invec(idx2(inner))
        !        outvec(idx2(inner)) = outvec(idx2(inner)) + &
        !                cDiag*invec(idx2(inner)) + cL*invec(idx1(inner))
        !enddo

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner)   = outvec(inner)   + cU*invec(inner+2)
                outvec(inner+2) = outvec(inner+2) + cL*invec(inner)
                outvec(inner+4) = outvec(inner+4) + cU*invec(inner+6)
                outvec(inner+6) = outvec(inner+6) + cL*invec(inner+4)
        enddo


        !outvec(1:8) = outvec(1:8) + cDiag*invec(1:8)
        !outvec(1:2) = outvec(1:2) + cU*invec(3:4)
        !outvec(3:4) = outvec(3:4) + cL*invec(1:2)
        !outvec(5:6) = outvec(5:6) + cU*invec(7:8)
        !outvec(7:8) = outvec(7:8) + cL*invec(5:6)

end subroutine d222_DULDUL





subroutine d222_DUDU(cDiag, cU, invec, outvec)
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner)   = outvec(inner)   + cU*invec(inner+2)
                outvec(inner+4) = outvec(inner+4) + cU*invec(inner+6)
        enddo

end subroutine d222_DUDU




subroutine d222_DLDL(cDiag, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cL 
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner
        !integer, dimension(4), parameter :: &
        !        idx1 = [1, 2, 5, 6]
        !integer, dimension(4), parameter :: &
        !        idx2 = [3, 4, 7, 8]

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 3, 4
                outvec(inner)   = outvec(inner)   + cL*invec(inner-2)
                outvec(inner+4) = outvec(inner+4) + cL*invec(inner+2)
        enddo

end subroutine d222_DLDL




subroutine d222_QDU(cDiag, cU, invec, outvec)
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU 
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + cU*invec(2:8:2)

end subroutine d222_QDU





subroutine d222_QDL(cDiag, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cL
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(2:8:2) = outvec(2:8:2) + cL*invec(1:7:2)

end subroutine d222_QDL





subroutine d222_QDUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
        real(dp), intent(in) :: cDiag
        real(dp), intent(in) :: cU
        real(dp), intent(in) :: cL
        real(dp), dimension(vecsize), intent(in) :: invec
        real(dp), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + cU*invec(2:8:2)
        outvec(2:8:2) = outvec(2:8:2) + cL*invec(1:7:2)

end subroutine d222_QDUL



















end module stencil_functions




















! hand converted from abouve + special center routine
module zstencil_functions

use constants, only : zzero, dpc

implicit none

integer, parameter :: vecsize = 8

contains



subroutine z222_CENTER(c0, c6, invec, outvec)
        ! [ c0, cZ, cY,  0, cX,  0,  0,  0]
        ! [ cZ, c0,  0, cY,  0, cX,  0,  0]
        ! [ cY,  0, c0, cZ,  0,  0, cX,  0]
        ! [  0, cY, cZ, c0,  0,  0,  0, cX]
        ! [ cX,  0,  0,  0, c0, cZ, cY,  0]
        ! [  0, cX,  0,  0, cZ, c0,  0, cY]
        ! [  0,  0, cX,  0, cY,  0, c0, cZ]
        ! [  0,  0,  0, cX,  0, cY, cZ, c0]
        complex(dpc), intent(in) :: c0
        complex(dpc), dimension(6), intent(in) :: c6
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer, parameter :: XL=1, XR=2, YL=3, YR=4, ZL=5, ZR=6
        integer :: inner

        !center is responsible for initing outvec.#badcoding #sorrynotsorry
        !outvec(:) = zzero

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = c0*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + &
                        c6(XR)*invec(inner+4)
                outvec(inner+4) = outvec(inner+4) + &
                        c6(XL)*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner) = outvec(inner) + &
                        c6(YR)*invec(inner+2)
                outvec(inner+4) = outvec(inner+4) + &
                        c6(YR)*invec(inner+6)
                outvec(inner+2) = outvec(inner+2) + &
                        c6(YL)*invec(inner)
                outvec(inner+6) = outvec(inner+6) + &
                        c6(YL)*invec(inner+4)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + c6(ZR)*invec(2:8:2)
        outvec(2:8:2) = outvec(2:8:2) + c6(ZL)*invec(1:7:2)

end subroutine z222_CENTER






subroutine z222_DUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU
        complex(dpc), intent(in) :: cL
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner) + cU*invec(inner+4)
                outvec(inner+4) = outvec(inner+4) + &
                        cDiag*invec(inner+4) + cL*invec(inner)
        enddo
end subroutine z222_DUL



subroutine z222_DU(cDiag, cU, invec, outvec)
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner) + cU*invec(inner+4)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 5, 8
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner)
        enddo
end subroutine z222_DU





subroutine z222_DL(cDiag, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
        complex(dpc), intent(in) :: cDiag, cL
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 1, 4
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(4)
#else
        !$omp simd aligned(outvec,invec) safelen(4)
#endif
        do inner = 5, 8
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner) + cL*invec(inner-4)
        enddo
end subroutine z222_DL





subroutine z222_DULDUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU
        complex(dpc), intent(in) :: cL
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner)   = outvec(inner)   + cU*invec(inner+2)
                outvec(inner+4) = outvec(inner+4) + cU*invec(inner+6)
                outvec(inner+2) = outvec(inner+2) + cL*invec(inner)
                outvec(inner+6) = outvec(inner+6) + cL*invec(inner+4)
        enddo
end subroutine z222_DULDUL






subroutine z222_DUDU(cDiag, cU, invec, outvec)
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU 
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 1, 2
                outvec(inner)   = outvec(inner)   + cU*invec(inner+2)
                outvec(inner+4) = outvec(inner+4) + cU*invec(inner+6)
        enddo
end subroutine z222_DUDU





subroutine z222_DLDL(cDiag,cL,invec,outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cL
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner 

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + &
                        cDiag*invec(inner)
        enddo

#ifdef IS_GCC
        !$omp simd safelen(2)
#else
        !$omp simd aligned(outvec,invec) safelen(2)
#endif
        do inner = 3, 4
                outvec(inner)   = outvec(inner)   + cL*invec(inner-2)
                outvec(inner+4) = outvec(inner+4) + cL*invec(inner+2)
        enddo
end subroutine z222_DLDL







subroutine z222_QDU(cDiag, cU, invec, outvec)
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU 
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + cU*invec(2:8:2)
end subroutine z222_QDU






subroutine z222_QDL(cDiag, cL, invec, outvec)
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cL 
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(2:8:2) = outvec(2:8:2) + cL*invec(1:7:2)
end subroutine z222_QDL







subroutine z222_QDUL(cDiag, cU, cL, invec, outvec)
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
        complex(dpc), intent(in) :: cDiag
        complex(dpc), intent(in) :: cU
        complex(dpc), intent(in) :: cL
        complex(dpc), dimension(vecsize), intent(in) :: invec
        complex(dpc), dimension(vecsize), intent(inout) :: outvec
        integer :: inner

#ifdef IS_GCC
        !$omp simd safelen(8)
#else
        !$omp simd aligned(outvec,invec) safelen(8)
#endif
        do inner = 1, 8
                outvec(inner) = outvec(inner) + cDiag*invec(inner)
        enddo

        outvec(1:7:2) = outvec(1:7:2) + cU*invec(2:8:2)
        outvec(2:8:2) = outvec(2:8:2) + cL*invec(1:7:2)
end subroutine z222_QDUL








end module zstencil_functions
