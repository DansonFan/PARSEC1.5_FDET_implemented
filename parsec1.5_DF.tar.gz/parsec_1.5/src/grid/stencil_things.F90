!  helper module, defines a bunch of stuff
!  since we are moving deeper into graphs - we need 
!     an integer typed coo and csr matrices
!  they are also defined here
module stencil_things

use constants, only : dp, dpc
implicit none

type stencil_definitions
        !copy from grid, pending refactoring will 
        integer :: norder, lap_dir_num

        !=6+2*lap_dir_num, the variable defining the stride of 
        !  the lap operator
        integer :: num_shell_memb

        !bad hack for retaining nrep, assumed 1
        integer :: nrep

        !another hack for retaing info about wavefunctions
        logical :: cplx

        !  Pending - several sten_definitions per run. 
        ! if we implement varying order laplacians
        ! highest order of laplacian in this run, along with 
        !    lap_dir_num defines strides etc.
        !
        ! integer :: max_norder !defined max order for which comm_neigh is assembled
        ! last internal point - variable order then for each order ther is a different 'last internal point'
        ! integer :: inter1
        !
        ! Refactoring considerations for future - 
        ! these could move here, should not change once they are set.
        ! coe2 2nd der. coefficents
        ! coe1 1st der. coefficents - for gradient and kinetic energy
        !maybe put this here since it is inside gen_coeff1D
        ! kecoe1 !=-2i*coe1*ktmp
        ! coefficents transformed to 1D, without kpoint data

        !the r0 coefficents, diagonal part of the operator, sum(coe2(0,1:3+lap_dir_num))
        real(dp) :: coeff2_diag

        ! (1:(6+2*lap_dir)*norder)
        real(dp), dimension(:), allocatable :: coeff2_1d

        ! (3+lap_dir)*norder
        real(dp), dimension(:), allocatable :: coeff2_sym

        ! when also gradient
        !real(dp) :: coeff1_diag !the r0 coefficents, diagonal part of the operator
        !real(dp), dimension (:), pointer :: coeff1_1D  !(1:(6+2*lap_dir)*norder)
        !
        ! the full coefficents for the stencil in matvec

        !(1:(6+2*lap_dir)*norder)
        complex(dpc), dimension(:), allocatable :: gen_coeff2_1d

        contains
                procedure :: init => init_sten_definitions
                procedure :: create => create_sten_definitions
                procedure :: setcoe2_1d => set_sten_coeff2_1d
                procedure :: destroy => destroy_sten_definitions
end type stencil_definitions




type fold_stencil
        integer :: norder
        integer :: lap_dir_num

        real(dp), dimension(:), allocatable :: coeffsym
        real(dp), dimension(:), allocatable :: coeff_1d
        complex(dpc), dimension(:), allocatable :: coeff_gen
        integer :: num_tiles
        integer :: foldsize 
        logical :: gen
        real(dp) :: c0
        complex(dpc) :: c0_gen

        ! compiler is complaining about alignment of these:

        contains
                procedure :: init => fold_stencil_init
                procedure :: alloc => fold_stencil_allocate
                procedure :: copy_coeffsym => fldstncl_cp_coeff_from_sten
                procedure :: copy_coeff_gen => fldstncl_cp_coeffgen_from_sten
                procedure :: updateC0 => fold_stencil_update_c0
                procedure :: updateC0_gen => fold_stencil_update_c0_gen
                procedure :: destroy => fold_stencil_destroy
end type fold_stencil







type int_coo
        integer :: nnz = 0 
        integer, dimension(:), allocatable :: row
        integer, dimension(:), allocatable :: col
        integer, dimension(:), allocatable :: val

        contains
                procedure :: alloc => int_coo_allocate
                procedure :: init => int_coo_init 
                procedure :: destroy => int_coo_destroy
                procedure :: sortbycol => sortbycol_coo
end type int_coo
   




type int_csr
        integer :: nnz = 0
        integer :: nrows = 0 !number of rows
        integer, dimension(:), allocatable :: rows
        integer, dimension(:), allocatable :: cols
        integer, dimension(:), allocatable :: vals

        contains
                procedure :: alloc => int_csr_allocate
                procedure :: init => int_csr_init
                procedure :: destroy => int_csr_destroy
end type int_csr




!
!    Global variables within the module
!
! these contain the edges in csr format
type(int_csr) :: my_sten_edges
type(int_csr) :: ext_sten_edges

! later - symmetry?
! type (int_coo) mycoo_t
! type (int_coo) extcoo_t




contains



subroutine init_sten_definitions(sten_def, cplx_flag, nrep)
        use constants, only : zero
        implicit none
        class(stencil_definitions) :: sten_def
        logical, intent(in) :: cplx_flag
        integer, intent(in) :: nrep
    
        sten_def%coeff2_diag = zero
        sten_def%cplx = cplx_flag
        sten_def%nrep = nrep
end subroutine init_sten_definitions





subroutine destroy_sten_definitions(sten_def)
        implicit none
        class(stencil_definitions) :: sten_def

        if (allocated(sten_def%coeff2_1D)) deallocate(sten_def%coeff2_1D)
        if (allocated(sten_def%coeff2_sym)) deallocate(sten_def%coeff2_sym)
        if (allocated(sten_def%gen_coeff2_1D)) &
                deallocate(sten_def%gen_coeff2_1D)
end subroutine destroy_sten_definitions






subroutine set_sten_coeff2_1d(sten_def, coe2)
        ! converts the 2d coe2 array to a 1d vector
        !
        ! in coe2 it is order as (-norder:norder,direction)
        !
        ! in the 1d vector it will be arranged as 
        ! (shell 1 ) (shell 2 ) (shell 3). inside each shell 
        ! the coefficents are orderd like the parallel%neib array, 
        ! e.g. X_L X_R, Y_L Y_R, ...
        implicit none

        class(stencil_definitions) :: sten_def
        real(dp), dimension(-sten_def%norder:sten_def%norder, &
                3+sten_def%lap_dir_num) :: coe2
        integer :: ishell
        integer :: icoeff
        integer :: current_shell_shift

        !write(9,*) "NEW LAP - converting coe2 to 1d. coe2:"
        !write(9,*) coe2
        !shellwize coe2 is -norder..0..norder, we want 1..norder but each coefficent repeats twice:
        sten_def%coeff2_diag = sum(coe2(0,:))

        ! Fill the regular coefficents
        do ishell = 1, sten_def%norder
        do icoeff = 1, 3+sten_def%lap_dir_num
                current_shell_shift = (ishell-1)*2*(sten_def%lap_dir_num+3)
                sten_def%coeff2_1d(current_shell_shift+2*icoeff-1) = &
                        coe2(ishell,icoeff)
                sten_def%coeff2_1d(current_shell_shift+2*icoeff  ) = &
                        coe2(ishell,icoeff)
        enddo
        enddo

        ! Fill in the symmetric coefficents
        do ishell = 1, sten_def%norder
        do icoeff = 1, 3+sten_def%lap_dir_num
                current_shell_shift = (ishell-1)*(sten_def%lap_dir_num+3)
                sten_def%coeff2_sym(current_shell_shift+icoeff) = &
                        coe2(ishell,icoeff)
        enddo
        enddo
end subroutine set_sten_coeff2_1D

















!subroutine set_lap_coeff1_1D(sten_def,coe1) !{{{
!    ! not ready yet!
!    !converts the 2d coe1 array to a 1d vector
!    !in coe1 it is order as (-norder:norder,direction)
!    !in the 1d vector it will be arranged as (shell 1 ) (shell 2 ) (shell 3) 
!    !inside each shell the coefficents are orderd like the parallel%neib array, e.g. X_L X_R, Y_L Y_R, ...
!    implicit none
!    class (sten_definitions) :: sten_def
!    real(dp) :: coe1(-sten_def%norder:sten_def%norder,3)
!    !
!    integer :: ishell,icoeff,current_shell_shift
!    
!!    write(9,*) "NEW LAP - converting coe2 to 1d. coe2:"
!!    write(9,*)  coe2
!    !shellwize coe2 is -norder..0..norder, we want 1..norder but each coefficent repeats twice:
!
!    do ishell=1,sten_def%norder
!        do icoeff=1,3
!        current_shell_shift = (ishell-1)*(6)
!!    write(9,*) "coe2, ishell, icoeff:",coe2(ishell,icoeff), ishell,icoeff
!        sten_def%coeff2_1D(current_shell_shift+2*icoeff    ) =  coe1(ishell,icoeff)
!        sten_def%coeff2_1D(current_shell_shift+2*icoeff -1 )  =  coe1(ishell,icoeff)
!        end do
!    end do
!
!    ! write(9,*) "NEW LAP - coeff2_1D:",sten_def%coeff2_1D
!
!
!end subroutine set_lap_coeff1_1D  !}}}



subroutine create_sten_definitions(sten_def, norder, lap_dir_num)
        use constants, only : zero, zzero
        use aux, only : alccheck
        implicit none

        !eventually all coe definitions might be made here
        ! meanwhile create here just the struct that you need
        ! and copy the rest from (eigen_)solver
        class(stencil_definitions) :: sten_def
        integer, intent(in) :: norder
        integer, intent(in) :: lap_dir_num
        integer :: coeff_size
        integer :: alcstat
    
        sten_def%norder = norder
        sten_def%lap_dir_num = lap_dir_num
        sten_def%num_shell_memb = 6 + 2*sten_def%lap_dir_num

        coeff_size = sten_def%norder*sten_def%num_shell_memb
        allocate(sten_def%coeff2_1d(coeff_size), stat=alcstat)
        call alccheck('sten_def%coeff2_1d', coeff_size, alcstat)
        sten_def%coeff2_1d(:) = zero

        coeff_size = sten_def%norder*(sten_def%num_shell_memb/2)
        allocate(sten_def%coeff2_sym(coeff_size), stat=alcstat)
        call alccheck('sten_def%coeff2_sym', coeff_size, alcstat)
        sten_def%coeff2_sym(:) = zero

        if (sten_def%cplx) then
                ! porbably should only allocate this if running 
                ! pbc or cluster with complex numbers
                coeff_size = sten_def%norder*sten_def%num_shell_memb
                allocate(sten_def%gen_coeff2_1d(coeff_size), stat=alcstat)
                call alccheck('sten_def%gen_coeff2_1d', coeff_size, alcstat)
                sten_def%gen_coeff2_1d(:) = zzero
        endif
end subroutine create_sten_definitions










! sparse type functions (moved/adapted from spmatvec_module)
subroutine int_coo_init(sprs)
        implicit none
        class(int_coo):: sprs
        sprs%nnz = 0
end subroutine int_coo_init

subroutine int_coo_allocate(sprs, nzcount)
        use aux, only : alccheck
        implicit none
        class(int_coo):: sprs
        integer :: nzcount
        integer :: alcstat

        sprs%nnz = nzcount
        allocate(sprs%col(nzcount), stat=alcstat)
        call alccheck('coo_sprs%col', nzcount, alcstat)
        allocate(sprs%row(nzcount), stat=alcstat)
        call alccheck('coo_sprs%row', nzcount, alcstat)
        allocate(sprs%val(nzcount), stat=alcstat)
        call alccheck('coo_sprs%val', nzcount, alcstat)
end subroutine int_coo_allocate

subroutine int_coo_destroy(sprs)
        implicit none
        class(int_coo):: sprs
        if ( allocated(sprs%col) ) deallocate(sprs%col)
        if ( allocated(sprs%row) ) deallocate(sprs%row)
        if ( allocated(sprs%val) ) deallocate(sprs%val)
end subroutine int_coo_destroy





subroutine sortbycol_coo(sprs, row0, row1)
        !uses the iheapsort method already in parsec
        !it is a little problematic because it is based on NR code,
        !which is not GPL
        use sort_module, only : iheapsort
        implicit none

        class(int_coo):: sprs

        integer, intent(in) :: row0,row1

        integer, dimension(:), allocatable :: sortindex
        integer myrow,irow,ibegin,iend,maxedge,n 

        ! there would be at most maxedge columns to sort for every row
        maxedge=maxval(sprs%val(:))
        allocate(sortindex(maxedge))


        ! warning, clunky code written by a chemist :)
        do myrow=row0,row1

                iend = 0
                ibegin= 0

                !find which coo rows belong to the same matrix row
                do irow=1,sprs%nnz 

                        if (ibegin == 0 .AND. sprs%row(irow) == myrow) then

                            ibegin = irow
                            do iend = irow+1,sprs%nnz
                                    if (sprs%row(iend) == myrow) then
                                        cycle
                                    else
                                        exit
                                    endif
                            enddo
                            iend=iend-1
                        endif

                        if (iend /= 0 ) then
                                !write(9,*) "sortcoo myrow irow ibegin iend",myrow,irow,ibegin,iend
                                exit
                        endif
                enddo !irow

                ! if (iend == 0 ) then
                        ! write(9,*) "myrow, irow ibegin,iend=",myrow, irow,ibegin,iend
                ! endif

                !now sort these coo rows so that columns are at the correct order
                sortindex=0
                ! get the sorted index
                n=iend-ibegin+1

                if (n > 1 ) then
                        call iheapsort(n,sprs%col(ibegin:iend),sortindex)

                        !debug:
                !        write(9,*) "iheapsort did its thing. ibegin =",ibegin
                !        write(9,*) "before rearranging sprs matrix, see if the indexes are ok"
                !        write(9,*) ibegin-1+sortindex(1:n)

                        ! use it on all three arrays
                        sprs%col(ibegin:iend)=sprs%col(ibegin-1+sortindex(1:n))
                        sprs%row(ibegin:iend)=sprs%row(ibegin-1+sortindex(1:n))
                        sprs%val(ibegin:iend)=sprs%val(ibegin-1+sortindex(1:n))
                endif
        enddo !myrow
end subroutine sortbycol_coo









! int csr
subroutine int_csr_init(sprs)
        implicit none
        class(int_csr) :: sprs
        sprs%nnz   = 0
        sprs%nrows = 0
end subroutine int_csr_init

subroutine int_csr_allocate(sprs, nrows, nzcount)
        use aux, only : alccheck
        implicit none

        class(int_csr):: sprs
        integer :: nrows, nzcount, alcstat

        sprs%nnz = nzcount
        sprs%nrows = nrows

        if (nzcount > 0 .and. nrows > 0) then
                allocate(sprs%cols(nzcount), stat=alcstat)
                call alccheck('int_csr%cols', nzcount, alcstat)

                ! KHL: Note: From Wikipedia, for an m by n sparse matrix, the 
                ! sprs%rows(:) is of length m+1, and 
                ! sprs%rows(first_element) should be zero, but here we 
                ! seem to let sprs%rows(1) = 1 and 
                ! sprs%rows(m+1) = sprs%nnz + 1
                ! So the number of values in row k will be
                ! sprs%rows(k+1) - sprs%rows(k)
                allocate(sprs%rows(nrows+1), stat=alcstat)
                call alccheck('int_csr%rows', nrows+1, alcstat)

                allocate(sprs%vals(nzcount), stat=alcstat)
                call alccheck('int_csr%vals', nzcount, alcstat)
        else
                allocate(sprs%cols(1), stat=alcstat)
                call alccheck('int_csr%cols', 1, alcstat)
                allocate(sprs%rows(1), stat=alcstat)
                call alccheck('int_csr%rows', 1, alcstat)
                allocate(sprs%vals(1), stat=alcstat)
                call alccheck('int_csr%vals', 1, alcstat)
        endif
end subroutine int_csr_allocate

    subroutine int_csr_destroy(sprs)
        implicit none

        class(int_csr):: sprs

        if ( allocated(sprs%cols) ) deallocate(sprs%cols)
        if ( allocated(sprs%rows) ) deallocate(sprs%rows)
        if ( allocated(sprs%vals) ) deallocate(sprs%vals)
    end subroutine int_csr_destroy !}}}


subroutine coo2csr_int(coo, csr)
        ! csr representaton - standard row-wise compressed sparse matrix
        ! converts from coo to csr using already obtained information on 
        ! number for non-zeros and number of rows. 
        ! assumes csr type is already allocated
        ! also assumes coo col and row are properly sorted
        !
        ! based on coocsr in sparsekit
        implicit none
        type(int_coo), intent(in) :: coo
        type(int_csr), intent(inout) :: csr
        integer :: nnz, nrows
        integer :: i, j, k, num_vals_in_this_row, val, ioffset
       
        ! Grab nnz and nrows:
        nnz = coo%nnz
        nrows = csr%nrows

        !
        ! Determine row lengths
        !
        write(9,*) "init csr%rows to 0"
        csr%rows(:) = 0
        write(9,*) "done init csr%rows to 0"
        write(9,*) "nnz is", nnz

        ! KHL: Note that csr%rows(1:nrows+1) has length nrows+1
        !      Here we first calculate the number of elements in each row
        !      (1 to nrow)
        do k = 1, nnz
                csr%rows(coo%row(k)) = csr%rows(coo%row(k)) + 1
        enddo
        !
        ! Determine the starting position of each row 
        !
        ! KHL: Note that at this moment csr%rows(nrows+1) = 0
        !      After the following loop, csr%rows(nrows+1) would be nnz+1
        !
        k = 1
        do j = 1, nrows+1
                num_vals_in_this_row = csr%rows(j)
                csr%rows(j) = k
                k = k + num_vals_in_this_row
        enddo
        !
        ! Fill values
        !
        do k = 1, nnz
                i = coo%row(k)
                j = coo%col(k)
                val = coo%val(k) 
                ioffset = csr%rows(i)
                csr%vals(ioffset) = val
                csr%cols(ioffset) = j
                csr%rows(i) = ioffset + 1
        enddo
        !
        ! Reform the csrrows 
        !
        do j = nrows, 1, -1
                csr%rows(j+1) = csr%rows(j)
        enddo
        csr%rows(1) = 1

end subroutine coo2csr_int














subroutine csrprint_with_id(csrmtx,iam,filename) !{{{
  implicit none
  type (int_csr), intent(in) :: csrmtx
  integer, intent(in) :: iam
  character(len=*), intent(in) :: filename
   character(len=4)    :: idstring

  ! huge files:
  write(9,*) 'printing csr matix with nnz,nrows:',csrmtx%nnz,csrmtx%nrows
    write(idstring,'(I4.4)') iam !limited for 10k PE
    open(48,file=filename//'csrrows.'//idstring,form='formatted',status='unknown')
    open(47,file=filename//'csrcols.'//idstring,form='formatted',status='unknown')
    open(46,file=filename//'csrvals.'//idstring,form='formatted',status='unknown')
   write(46,300) csrmtx%vals
   close(46)

   write(47,300) csrmtx%cols
   close(47)

   write(48,300) csrmtx%rows
   close(48)
   write(9,*) 'done'

300 format (I8)
end subroutine csrprint_with_id!}}}

subroutine cooprint_with_id(coomtx,iam,filename) !{{{
  implicit none
  type (int_coo), intent(in) :: coomtx
  integer, intent(in) :: iam
  character(len=*), intent(in) :: filename
   character(len=4)    :: idstring
   integer:: nnz,IND

   nnz=coomtx%nnz
  ! huge files:
    write(idstring,'(I4.4)') iam !limited for 10k PE
    ! print (row col val)
    open(46,file=filename//'coo.'//idstring,form='formatted',status='unknown')
   write(46,'(I8,1X,I8,1X,I3)') (coomtx%row(IND), coomtx%col(IND), coomtx%val(IND), IND=1,nnz)  
   close(46)

end subroutine cooprint_with_id!}}}
!{{{ leftover subroutines (maybe useful in the future?)
    subroutine copy_coo_to_lower_tri(coomtx_in,coomtx_out,mydim)
        implicit none

        type (int_coo), intent(in) :: coomtx_in
        type (int_coo), intent(out) :: coomtx_out

        integer, intent(in) :: mydim
        integer :: myrow,mycol, nzind, cooind, newnnz

        write(9,*) "culling my coo matrix to lower triagonal"
        write(9,*) "original nnz:", coomtx_in%nnz
        newnnz = coomtx_in%nnz - mydim
        write(9,*) "nnz without diagonal", newnnz
        newnnz = newnnz/2
        newnnz = newnnz + mydim
        write(9,*) "final nnz with diagonal", newnnz

        call coomtx_out%destroy()
        call coomtx_out%init()
        call coomtx_out%alloc(newnnz)

        cooind = 0
        do nzind = 1,coomtx_in%nnz
           myrow = coomtx_in%row(nzind)
           mycol = coomtx_in%col(nzind)
           if (mycol <= myrow) then
               cooind = cooind+1
               coomtx_out%row(cooind) = myrow
               coomtx_out%col(cooind) = mycol
               coomtx_out%val(cooind) = coomtx_in%val(nzind)
           endif
        enddo
        write(9,*) "new coo matrix has", cooind, "non zero elements"

    end subroutine copy_coo_to_lower_tri
!}}}
!}}}





! fold stencil functions {{{
! the following is a working example,
! only true for fold 2x2x2 and a stencil depth of 6 
subroutine fold_stencil_init(foldsten, genflag, foldsize)
        use constants, only : dzero, zzero
        implicit none
        class(fold_stencil) :: foldsten
        logical, intent(in) :: genflag
        integer, intent(in) :: foldsize
        foldsten%foldsize = foldsize
        foldsten%c0 = dzero
        foldsten%c0_gen = zzero
        foldsten%gen = genflag
end subroutine fold_stencil_init




subroutine fold_stencil_allocate(foldsten, stendef)
        use constants, only : dzero, zzero
        use aux, only : alccheck
        implicit none

        class(fold_stencil) :: foldsten
        type(stencil_definitions), intent(in) :: stendef

        integer :: coeff_2nd_sym_size
        integer :: coeff_2nd_1d_size
        integer :: alcstat

        if (foldsten%gen) then
                coeff_2nd_1d_size = 2*stendef%norder*(3+stendef%lap_dir_num)
                allocate(foldsten%coeff_gen(coeff_2nd_1d_size), stat=alcstat)
                call alccheck('foldsten%coeff_gen', coeff_2nd_1d_size, alcstat)
                foldsten%coeff_gen(:) = zzero
        else
                coeff_2nd_sym_size = stendef%norder*(3+stendef%lap_dir_num)
                allocate(foldsten%coeffsym(coeff_2nd_sym_size), stat=alcstat)
                call alccheck('foldsten%coeffsym', coeff_2nd_sym_size, alcstat)
                foldsten%coeffsym(:) = dzero

                coeff_2nd_1d_size = 2*stendef%norder*(3+stendef%lap_dir_num)
                allocate(foldsten%coeff_1d(coeff_2nd_1d_size), stat=alcstat)
                call alccheck('foldsten%coeff_1d', coeff_2nd_1d_size, alcstat)
                foldsten%coeff_1d(:) = dzero
        endif
end subroutine fold_stencil_allocate




subroutine fldstncl_cp_coeff_from_sten(foldsten, stendef)
        implicit none
        class(fold_stencil):: foldsten
        type(stencil_definitions), intent(in) :: stendef

        foldsten%norder = stendef%norder
        foldsten%lap_dir_num = stendef%lap_dir_num

        foldsten%coeffsym(:) = stendef%coeff2_sym(:)
        foldsten%coeff_1d(:) = stendef%coeff2_1d(:)
end subroutine fldstncl_cp_coeff_from_sten





subroutine fldstncl_cp_coeffgen_from_sten(foldsten, stendef)
        use constants, only : dzero, dp
        implicit none
        class(fold_stencil) :: foldsten
        type(stencil_definitions), intent(in) :: stendef

        foldsten%norder = stendef%norder
        foldsten%lap_dir_num = stendef%lap_dir_num

        ! properly cast the real coefficents to complex
        foldsten%coeff_gen(:) = cmplx(stendef%coeff2_1d(:), dzero, dp)
end subroutine fldstncl_cp_coeffgen_from_sten








subroutine fold_stencil_update_c0(foldsten, c0replace)
        implicit none
        class(fold_stencil):: foldsten
        real(dp) :: c0replace

        foldsten%c0 = c0replace
end subroutine fold_stencil_update_c0




subroutine fold_stencil_update_c0_gen(foldsten, c0replace)
        use constants, only : dpc
        implicit none
        class(fold_stencil):: foldsten
        complex(dpc) :: c0replace

        foldsten%c0_gen = c0replace
end subroutine fold_stencil_update_c0_gen







subroutine fold_stencil_destroy(foldsten)
        implicit none
        class(fold_stencil):: foldsten

        foldsten%foldsize = -1

        if (allocated(foldsten%coeffsym)) deallocate(foldsten%coeffsym)
        if (allocated(foldsten%coeff_gen)) deallocate(foldsten%coeff_gen)
end subroutine fold_stencil_destroy!}}}



subroutine real_internal_edges_222_depth6(crow0, tasks_grainsize, &
        coeff, indim, outdim, invec, outvec)

        use constants, only : dzero
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: indim
        integer, intent(in) :: outdim
        real(dp), dimension(indim), intent(in) :: invec
        real(dp), dimension(outdim), intent(inout) :: outvec

        integer, parameter :: maxnumedges = 18
        integer, parameter :: foldsize = 8

        integer :: icrow
        integer :: jj
        integer :: rowptr
        integer :: c_colstart
        integer :: c_nval
        integer, dimension(maxnumedges) :: colptr, c_edgeval

        do icrow = crow0, crow0+tasks_grainsize-1
                rowptr = 1 + (icrow - 1)*foldsize
                c_colstart = my_sten_edges%rows(icrow)
                c_nval = my_sten_edges%rows(icrow+1) - c_colstart

                ! center traverse inits this:
                call center_traverse_real_222_depth6(coeff%coeffsym, &
                        coeff%c0, invec(rowptr), outvec(rowptr))

                !$omp simd
                do jj = 1, c_nval
                        colptr(jj) = 1 + foldsize* &
                                (my_sten_edges%cols(c_colstart+jj-1)-1)
                enddo
                !$omp end simd

                !$omp simd
                do jj = 1, c_nval
                        c_edgeval(jj) = my_sten_edges%vals(c_colstart+jj-1)
                enddo
                !$omp end simd

                ! KHL: Not sure why the simd reduction of an array 
                !      here will lead to a wrong answer. For now
                !      I just do not use it.
                do jj = 1, c_nval
                        call edge_traverse_real_222_depth6(coeff%coeffsym, &
                                c_edgeval(jj), invec(colptr(jj)), &
                                outvec(rowptr))
                enddo
        enddo

end subroutine real_internal_edges_222_depth6




subroutine real_internal_edges_111_depth6(crow0, tasks_grainsize, &
        coeff, indim, outdim, invec, outvec)
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: indim
        integer, intent(in) :: outdim
        real(dp), dimension(indim), intent(in) :: invec
        real(dp), dimension(outdim), intent(inout) :: outvec

        integer :: icrow
        integer :: jcol

#ifdef IS_GCC
        !$omp simd
#else
        !$omp simd aligned(outvec,invec)
#endif
        do icrow = crow0, crow0+tasks_grainsize-1
                outvec(icrow) = coeff%c0*invec(icrow)
        enddo

        do icrow = crow0, crow0+tasks_grainsize-1
        do jcol = my_sten_edges%rows(icrow), my_sten_edges%rows(icrow+1)-1
                outvec(icrow) = outvec(icrow) + &
                        coeff%coeff_1d( my_sten_edges%vals(jcol) )* &
                        invec( my_sten_edges%cols(jcol) )
        enddo
        enddo

end subroutine real_internal_edges_111_depth6





subroutine real_ghost_edges_111_depth6(crow0, tasks_grainsize, &
        coeff, buffdim, outdim, buffvec, outvec)
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: buffdim
        integer, intent(in) :: outdim
        real(dp), dimension(buffdim), intent(in) :: buffvec
        real(dp), dimension(outdim), intent(inout) :: outvec

        integer :: icrow
        integer :: jcol

        do icrow = crow0, crow0+tasks_grainsize-1
        do jcol = ext_sten_edges%rows(icrow), ext_sten_edges%rows(icrow+1)-1
                outvec(icrow) = outvec(icrow) + &
                        coeff%coeff_1d( ext_sten_edges%vals(jcol) )* &
                        buffvec( ext_sten_edges%cols(jcol) )
        enddo
        enddo

end subroutine real_ghost_edges_111_depth6












subroutine complex_internal_edges_111_depth6(crow0, tasks_grainsize, &
        coeff, indim, outdim, invec, outvec)

        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: indim
        integer, intent(in) :: outdim
        complex(dpc), dimension(indim), intent(in) :: invec
        complex(dpc), dimension(outdim), intent(inout) :: outvec

        integer :: icrow
        integer :: jcol
        integer :: edgeval

#ifdef IS_GCC
        !$omp simd
#else
        !$omp simd aligned(outvec,invec)
#endif
        do icrow = crow0, crow0+tasks_grainsize-1
                outvec(icrow) = coeff%c0_gen*invec(icrow)
        enddo

        do icrow = crow0, crow0+tasks_grainsize-1
        do jcol = my_sten_edges%rows(icrow), my_sten_edges%rows(icrow+1)-1
                edgeval = my_sten_edges%vals(jcol)
                outvec(icrow) = outvec(icrow) + &
                        coeff%coeff_gen(edgeval)* &
                        invec( my_sten_edges%cols(jcol) )
        enddo
        enddo

end subroutine complex_internal_edges_111_depth6





subroutine complex_ghost_edges_111_depth6(crow0, tasks_grainsize, &
        coeff, buffdim, outdim, buffvec, outvec)
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: buffdim
        integer, intent(in) :: outdim
        complex(dpc), dimension(buffdim), intent(in) :: buffvec
        complex(dpc), dimension(outdim), intent(inout) :: outvec

        integer :: icrow
        integer :: jcol
        integer :: edgeval

        do icrow = crow0, crow0+tasks_grainsize-1
        do jcol = ext_sten_edges%rows(icrow), ext_sten_edges%rows(icrow+1)-1
                edgeval = ext_sten_edges%vals(jcol)
                outvec(icrow) = outvec(icrow) + &
                        coeff%coeff_gen(edgeval)* &
                        buffvec( ext_sten_edges%cols(jcol) )
        enddo
        enddo

end subroutine complex_ghost_edges_111_depth6


































subroutine complex_internal_edges_222_depth6(crow0, tasks_grainsize, &
        coeff, indim, outdim, invec, outvec)

        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: indim
        integer, intent(in) :: outdim
        complex(dpc), dimension(indim), intent(in) :: invec
        complex(dpc), dimension(outdim), intent(inout) :: outvec

        integer, parameter :: maxnumedges = 18
        integer, parameter :: foldsize = 8

        integer :: icrow
        integer :: jj
        integer :: rowptr
        integer :: c_colstart
        integer :: c_nval
        integer, dimension(maxnumedges) :: colptr
        integer, dimension(maxnumedges) :: c_edgeval



        do icrow = crow0, crow0+tasks_grainsize-1
                rowptr = 1 + (icrow - 1)*foldsize
                c_colstart = my_sten_edges%rows(icrow)
                c_nval = my_sten_edges%rows(icrow+1) - c_colstart

                call center_traverse_complex_222_depth6(coeff%coeff_gen, &
                        coeff%c0_gen, invec(rowptr), outvec(rowptr))

                !$omp simd
                do jj = 1, c_nval
                        colptr(jj) = 1 + foldsize* &
                                (my_sten_edges%cols(c_colstart+jj-1)-1)
                enddo
                !$omp end simd

                !$omp simd
                do jj = 1, c_nval
                        c_edgeval(jj) = my_sten_edges%vals(c_colstart+jj-1)
                enddo
                !$omp end simd

                ! then do the stencil
                do jj = 1, c_nval
                        call edge_traverse_complex_222_depth6( &
                                coeff%coeff_gen, c_edgeval(jj), &
                                invec(colptr(jj)), outvec(rowptr))
                enddo
        enddo

end subroutine complex_internal_edges_222_depth6













subroutine real_ghost_edges_222_depth6(crow0, tasks_grainsize, &
        coeff, buffdim, outdim, buffvec, outvec)

        use constants, only : dzero
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: buffdim
        integer, intent(in) :: outdim
        real(dp), dimension(buffdim), intent(in) :: buffvec
        real(dp), dimension(outdim), intent(inout) :: outvec

        integer, parameter :: maxnumedges = 18
        integer, parameter :: foldsize = 8

        integer :: icrow
        integer :: jj
        integer :: rowptr
        integer :: c_colstart
        integer :: c_nval
        integer, dimension(maxnumedges) :: colptr, c_edgeval

        do icrow = crow0, crow0+tasks_grainsize-1
                rowptr = 1 + (icrow - 1)*foldsize
                c_colstart = ext_sten_edges%rows(icrow)
                c_nval = ext_sten_edges%rows(icrow+1) - c_colstart

                !$omp simd
                do jj = 1, c_nval
                        colptr(jj) = 1 + foldsize* &
                                (ext_sten_edges%cols(c_colstart+jj-1)-1)
                enddo
                !$omp end simd

                !$omp simd
                do jj = 1, c_nval
                        c_edgeval(jj) = ext_sten_edges%vals(c_colstart+jj-1)
                enddo
                !$omp end simd

                do jj = 1, c_nval
                        call edge_traverse_real_222_depth6(coeff%coeffsym, &
                                c_edgeval(jj), buffvec(colptr(jj)), &
                                outvec(rowptr))
                enddo
        enddo

end subroutine real_ghost_edges_222_depth6











subroutine complex_ghost_edges_222_depth6(crow0, tasks_grainsize, &
        coeff, buffdim, outdim, buffvec, outvec)
        implicit none

        integer, intent(in) :: crow0
        integer, intent(in) :: tasks_grainsize
        type(fold_stencil), intent(in) :: coeff
        integer, intent(in) :: buffdim
        integer, intent(in) :: outdim
        complex(dpc), dimension(buffdim), intent(in) :: buffvec
        complex(dpc), dimension(outdim), intent(inout) :: outvec

        integer, parameter :: maxnumedges = 18
        integer, parameter :: foldsize = 8

        integer :: icrow
        integer :: jj
        integer :: rowptr
        integer :: c_colstart
        integer :: c_nval
        integer, dimension(maxnumedges) :: colptr, c_edgeval

        do icrow = crow0, crow0+tasks_grainsize-1
                rowptr = 1 + (icrow - 1)*foldsize
                c_colstart = ext_sten_edges%rows(icrow)
                c_nval = ext_sten_edges%rows(icrow+1) - c_colstart

                !$omp simd
                do jj = 1, c_nval
                        colptr(jj) = 1 + foldsize* &
                                (ext_sten_edges%cols(c_colstart+jj-1)-1)
                enddo
                !$omp end simd

                !$omp simd
                do jj = 1, c_nval
                        c_edgeval(jj) = ext_sten_edges%vals(c_colstart+jj-1)
                enddo
                !$omp end simd

                do jj = 1, c_nval
                        call edge_traverse_complex_222_depth6( &
                                coeff%coeff_gen, &
                                c_edgeval(jj), buffvec(colptr(jj)), &
                                outvec(rowptr))
                enddo
        enddo
end subroutine complex_ghost_edges_222_depth6







subroutine center_traverse_real_222_depth6(coeffsym, cCENTER, infold, outfold)
        use stencil_functions, only : d222_CENTER
        implicit none

        integer, parameter :: foldsize = 8
        integer, parameter :: norder = 6
        integer, parameter :: coeffsymsize = norder*3

        real(dp), dimension(coeffsymsize), intent(in) :: coeffsym
        real(dp), intent(in) :: cCENTER
        real(dp), dimension(foldsize), intent(in) :: infold
        real(dp), dimension(foldsize), intent(out) :: outfold

        integer, parameter :: X1 = 1, Y1 = 2, Z1 = 3

        call d222_CENTER(c0=cCENTER, cX=coeffsym(X1), cY=coeffsym(Y1), &
                cZ=coeffsym(Z1), invec=infold(:), outvec=outfold(:))

end subroutine center_traverse_real_222_depth6



































subroutine center_traverse_complex_222_depth6(coeff_gen, cCENTER, infold, outfold)
        use zstencil_functions, only : z222_CENTER
        implicit none

        integer, parameter :: foldsize = 8
        integer, parameter :: norder = 6
        integer, parameter :: coeffgensize = norder*3*2

        complex(dpc), dimension(coeffgensize), intent(in) :: coeff_gen
        complex(dpc), intent(in) :: cCENTER
        complex(dpc), dimension(foldsize), intent(in) :: infold
        complex(dpc), dimension(foldsize), intent(out) :: outfold

        call z222_CENTER(c0=cCENTER, c6=coeff_gen(1:6), invec=infold, outvec=outfold)

end subroutine center_traverse_complex_222_depth6








!currently for num_lap_dir=0
subroutine edge_traverse_real_222_depth6(coeffsym, edgeval, infold, outfold)

        use constants, only : zero, dp
        use stencil_functions
        implicit none

        integer, intent(in) :: edgeval
        integer, parameter :: foldsize = 8
        integer, parameter :: norder = 6
        integer, parameter :: coeffsymsize = norder*3

        real(dp), dimension(coeffsymsize), intent(in) :: coeffsym
        real(dp), dimension(foldsize), intent(in) :: infold
        real(dp), dimension(foldsize), intent(inout) :: outfold

        integer, parameter :: X1 = 1,  Y1 = 2,  Z1 = 3
        integer, parameter :: X2 = 4,  Y2 = 5,  Z2 = 6
        integer, parameter :: X3 = 7,  Y3 = 8,  Z3 = 9
        integer, parameter :: X4 = 10, Y4 = 11, Z4 = 12
        integer, parameter :: X5 = 13, Y5 = 14, Z5 = 15
        integer, parameter :: X6 = 16, Y6 = 17, Z6 = 18
    
        ! need to optimize, the case statement is not helping
        select case (edgeval)
        case(1)
                call d222_DUL   (cDiag=coeffsym(X2), cU=coeffsym(X1), cL=coeffsym(X3), &
                        invec=infold, outvec=outfold)
        case(2)
                call d222_DUL   (cDiag=coeffsym(X2), cU=coeffsym(X3), cL=coeffsym(X1), &
                        invec=infold, outvec=outfold)
        case(3)
                call d222_DULDUL(cDiag=coeffsym(Y2), cU=coeffsym(Y1), cL=coeffsym(Y3), &
                        invec=infold, outvec=outfold)
        case(4)
                call d222_DULDUL(cDiag=coeffsym(Y2), cU=coeffsym(Y3), cL=coeffsym(Y1), &
                        invec=infold, outvec=outfold)
        case(5)
                call d222_QDUL  (cDiag=coeffsym(Z2), cU=coeffsym(Z1), cL=coeffsym(Z3), &
                        invec=infold, outvec=outfold)
        case(6)
                call d222_QDUL  (cDiag=coeffsym(Z2), cU=coeffsym(Z3), cL=coeffsym(Z1), &
                        invec=infold, outvec=outfold)
        case(7)
                call d222_DUL   (cDiag=coeffsym(X4), cU=coeffsym(X3), cL=coeffsym(X5), &
                        invec=infold, outvec=outfold)
        case(8)
                call d222_DUL   (cDiag=coeffsym(X4), cU=coeffsym(X5), cL=coeffsym(X3), &
                        invec=infold, outvec=outfold)
        case(9)
                call d222_DULDUL(cDiag=coeffsym(Y4), cU=coeffsym(Y3), cL=coeffsym(Y5), &
                        invec=infold, outvec=outfold)
        case(10)
                call d222_DULDUL(cDiag=coeffsym(Y4), cU=coeffsym(Y5), cL=coeffsym(Y3), &
                        invec=infold, outvec=outfold)
        case(11)
                call d222_QDUL  (cDiag=coeffsym(Z4), cU=coeffsym(Z3), cL=coeffsym(Z5), &
                        invec=infold, outvec=outfold)
        case(12)
                call d222_QDUL  (cDiag=coeffsym(Z4), cU=coeffsym(Z5), cL=coeffsym(Z3), &
                        invec=infold, outvec=outfold)
        case(13)
                call d222_DU    (cDiag=coeffsym(X6), cU=coeffsym(X5), &
                        invec=infold, outvec=outfold)
        case(14)
                call d222_DL    (cDiag=coeffsym(X6), cL=coeffsym(X5), &
                        invec=infold, outvec=outfold)
        case(15)
                call d222_DUDU  (cDiag=coeffsym(Y6), cU=coeffsym(Y5), &
                        invec=infold, outvec=outfold)
        case(16)
                call d222_DLDL  (cDiag=coeffsym(Y6), cL=coeffsym(Y5), &
                        invec=infold, outvec=outfold)
        case(17)
                call d222_QDU   (cDiag=coeffsym(Z6), cU=coeffsym(Z5), &
                        invec=infold, outvec=outfold)
        case(18)
                call d222_QDL   (cDiag=coeffsym(Z6), cL=coeffsym(Z5), &
                        invec=infold, outvec=outfold)
        end select

end subroutine edge_traverse_real_222_depth6
















! almost the same as above
!currently for num_lap_dir=0
subroutine edge_traverse_complex_222_depth6(coeff_gen, edgeval, infold, outfold)
        use constants
        use zstencil_functions
        implicit none

        integer, intent(in) :: edgeval
        integer, parameter :: foldsize = 8
        integer, parameter :: norder = 6
        integer, parameter :: coeffgensize = norder*3*2

        complex(dpc), dimension(coeffgensize), intent(in) :: coeff_gen
        complex(dpc), dimension(foldsize), intent(in) :: infold
        complex(dpc), dimension(foldsize), intent(inout) :: outfold

        integer, parameter :: XL1=1, XR1=2, YL1=3, YR1=4, ZL1=5, ZR1=6 
        integer, parameter :: XL2=7, XR2=8, YL2=9, YR2=10,ZL2=11,ZR2=12 
        integer, parameter :: XL3=13,XR3=14,YL3=15,YR3=16,ZL3=17,ZR3=18 
        integer, parameter :: XL4=19,XR4=20,YL4=21,YR4=22,ZL4=23,ZR4=24 
        integer, parameter :: XL5=25,XR5=26,YL5=27,YR5=28,ZL5=29,ZR5=30 
        integer, parameter :: XL6=31,XR6=32,YL6=33,YR6=34,ZL6=35,ZR6=36 
    
        select case (edgeval)
        case(1)
                call z222_DUL   (cDiag=coeff_gen(XL2),cU=coeff_gen(XL1),cL=coeff_gen(XL3), invec=infold,outvec=outfold)
        case(2)
                call z222_DUL   (cDiag=coeff_gen(XR2),cU=coeff_gen(XR3),cL=coeff_gen(XR1), invec=infold,outvec=outfold)
        case(3)
                call z222_DULDUL(cDiag=coeff_gen(YL2),cU=coeff_gen(YL1),cL=coeff_gen(YL3), invec=infold,outvec=outfold)
        case(4)
                call z222_DULDUL(cDiag=coeff_gen(YR2),cU=coeff_gen(YR3),cL=coeff_gen(YR1), invec=infold,outvec=outfold)
        case(5)
                call z222_QDUL  (cDiag=coeff_gen(ZL2),cU=coeff_gen(ZL1),cL=coeff_gen(ZL3), invec=infold,outvec=outfold)
        case(6)
                call z222_QDUL  (cDiag=coeff_gen(ZR2),cU=coeff_gen(ZR3),cL=coeff_gen(ZR1), invec=infold,outvec=outfold)
        case(7)
                call z222_DUL   (cDiag=coeff_gen(XL4),cU=coeff_gen(XL3),cL=coeff_gen(XL5), invec=infold,outvec=outfold)
        case(8)
                call z222_DUL   (cDiag=coeff_gen(XR4),cU=coeff_gen(XR5),cL=coeff_gen(XR3), invec=infold,outvec=outfold)
        case(9)
                call z222_DULDUL(cDiag=coeff_gen(YL4),cU=coeff_gen(YL3),cL=coeff_gen(YL5), invec=infold,outvec=outfold)
        case(10)
                call z222_DULDUL(cDiag=coeff_gen(YR4),cU=coeff_gen(YR5),cL=coeff_gen(YR3), invec=infold,outvec=outfold)
        case(11)
                call z222_QDUL  (cDiag=coeff_gen(ZL4),cU=coeff_gen(ZL3),cL=coeff_gen(ZL5), invec=infold,outvec=outfold)
        case(12)
                call z222_QDUL  (cDiag=coeff_gen(ZR4),cU=coeff_gen(ZR5),cL=coeff_gen(ZR3), invec=infold,outvec=outfold)
        case(13)
                call z222_DU    (cDiag=coeff_gen(XL6),cU=coeff_gen(XL5), invec=infold,outvec=outfold)
        case(14)
                call z222_DL    (cDiag=coeff_gen(XR6),cL=coeff_gen(XR5), invec=infold,outvec=outfold)
        case(15)
                call z222_DUDU  (cDiag=coeff_gen(YL6),cU=coeff_gen(YL5), invec=infold,outvec=outfold)
        case(16)
                call z222_DLDL  (cDiag=coeff_gen(YR6),cL=coeff_gen(YR5), invec=infold,outvec=outfold)
        case(17)
                call z222_QDU   (cDiag=coeff_gen(ZL6),cU=coeff_gen(ZL5), invec=infold,outvec=outfold)
        case(18)
                call z222_QDL   (cDiag=coeff_gen(ZR6),cL=coeff_gen(ZR5), invec=infold,outvec=outfold)
        end select

end subroutine edge_traverse_complex_222_depth6

    
end module

