module laplacian_ops_module

implicit none
contains



#if 0
!===============================================================
!
!  Distributed Laplacian operator. This subroutine receives as
!  input a distributed function over the grid (array lap_in) and
!  operates the laplacian over it, using finite differences.
!  Output is distributed function lap_out = -Laplacian(lap_in).
!
!  WARNING: notice that the output laplacian has a minus sign!
!
!  WARNING: input function func is assumed to have the full
!  symmetry of the system, so there are no representation
!  characters (cf. subroutine matvec).
!
!---------------------------------------------------------------
! REAL, full symmetry laplacian operator with communication, 
! assuming comm buffers externally managed
subroutine laplacian(parallel, sten_def, lap_buff, lap_in, lap_out)

use parallel_data_module
use dbuffer_module
use dlaplacian_module
use stencil_things
use constants 

implicit none

type(parallel_data), intent(in) :: parallel
type(stencil_definitions), intent(inout) :: sten_def
type(lap_buffer), intent(inout) :: lap_buff

real(dp), intent(in)    :: lap_in(parallel%mydim)
real(dp), intent(out)   :: lap_out(parallel%mydim)

real(dp), dimension(parallel%myworkdim+1) :: workvec

integer :: first_index, last_internal_point, save_actual_nrep
real(dp) :: dummy_chi(1)

! --------------------------------------------------------------

!    write(9,*) "hello from old laplacian, mydim:",parallel%mydim
!write(9,*) "myworkdim:",parallel%myworkdim
sten_def%nrep = 1 !symmetry hack 



!$OMP PARALLEL &
!$OMP& PRIVATE(first_index,last_internal_point,dummy_chi) &
!$OMP& DEFAULT(SHARED)

first_index = 1
last_internal_point = parallel%inter1 !will be different in case of varying lap order
dummy_chi(:) = one



! start parallel construct

! buffer object is input argument, can check communications
! so hpotcg etc. therefore should take care externally of init/allocate/destroy


!$OMP MASTER
if (parallel%nprow > 1) then
        call dbuff_lap_pack(parallel, lap_buff, lap_in, 1, 1, 1, parallel%mydim)
        call dbuff_lap_comm(parallel, lap_buff)
endif
!$OMP END MASTER

! copy/map input vector to work vector (high bandwidth memory/xeon phi?)
call dlap_copy_to_workvec(lap_in(:), parallel%mydim, workvec(:), parallel%myworkdim+1)




!$OMP MASTER
if (parallel%nprow > 1) then
        call buff_lap_check_comm(lap_buff, 1)
        call dbuffer_lap_unpack(parallel, workvec, lap_buff)
endif
!$OMP END MASTER




! 1D lap coefficents are already ready
! if there are enough internal points, commence laplacian
if (last_internal_point > 1) then
        ! write(9,*) "laplacian crunch inner"
        ! write(9,*) "coeff2_1D test"
        ! write(9,*) sten_def%coeff2_1D

        ! calculate diagonal term - also initalizes output vector
        call dlap_diag_true(parallel, first_index, last_internal_point, &
                parallel%mydim, sten_def%coeff2_diag, &
                lap_in, parallel%mydim, lap_out, parallel%mydim)

        call dlaplacian_crunch(parallel, sten_def, sten_def%coeff2_1D, &
                dummy_chi, first_index, last_internal_point, &
                workvec, lap_out, parallel%mydim)
                                                             !^hack for symmetry
endif



! complete laplacian calculation
!write(9,*) "laplacian crunch_final up to",parallel%mydim
call dlap_diag_true(parallel, last_internal_point+1, parallel%mydim, &
        parallel%mydim, sten_def%coeff2_diag, &
        lap_in, parallel%mydim, lap_out, parallel%mydim) 

call dlaplacian_crunch(parallel, sten_def, sten_def%coeff2_1D, &
        dummy_chi, last_internal_point+1, parallel%mydim, &
        workvec, lap_out, parallel%mydim)
                                                             !^hack for symmetry



!$OMP END PARALLEL



sten_def%nrep = save_actual_nrep

end subroutine laplacian


#endif








!===============================================================
!
!  Distributed Laplacian operator. This subroutine receives as
!  input a distributed function over the grid (array lap_in) and
!  operates the laplacian over it, using finite differences.
!  Output is distributed function lap_out = -Laplacian(lap_in).
!
!  WARNING: notice that the output laplacian has a minus sign!
!
!  WARNING: input function func is assumed to have the full
!  symmetry of the system, so there are no representation
!  characters (cf. subroutine matvec).
!
!---------------------------------------------------------------
! REAL, full symmetry laplacian operator with communication, 
! assuming comm buffers externally managed
subroutine laplacian_fold(parallel, sten_coeff, fold_buff, lap_in, lap_out)

use parallel_data_module
use dbuffer_module
use stencil_things
use constants 

#ifdef _OPENMP
use omp_lib
#endif

implicit none

type(parallel_data), intent(in) :: parallel
type(fold_stencil), intent(in) :: sten_coeff
type(fold_buffer), intent(inout) :: fold_buff

real(dp), dimension(parallel%mydim), intent(in) :: lap_in
real(dp), dimension(parallel%mydim), intent(out) :: lap_out

real(dp), dimension(sten_coeff%foldsize) :: tempvec
integer :: icrow, irow
integer :: foldsize
integer :: my_leftover, my_tasklim, my_tasks_grainsize
integer :: ext_leftover, ext_tasklim, ext_tasks_grainsize

! --------------------------------------------------------------

foldsize = sten_coeff%foldsize

my_leftover = mod(my_sten_edges%nrows,GRAIN_DIV)
my_tasklim = my_sten_edges%nrows - my_leftover
my_tasks_grainsize = max((my_tasklim/(GRAIN_DIV)),1)
ext_leftover = mod(ext_sten_edges%nrows,GRAIN_DIV)
ext_tasklim = ext_sten_edges%nrows - ext_leftover
ext_tasks_grainsize = max((ext_tasklim/(GRAIN_DIV)),1)



if (foldsize == 1) then 


#if 0



        !$omp parallel default(none) &
        !$omp& private(icrow) &
        !$omp& shared(my_leftover) &
        !$omp& shared(my_tasklim) &
        !$omp& shared(my_tasks_grainsize) &
        !$omp& shared(ext_leftover) &
        !$omp& shared(ext_tasklim) &
        !$omp& shared(ext_tasks_grainsize) &
        !$omp& shared(sten_coeff) &
        !$omp& shared(fold_buff) &
        !$omp& shared(parallel) &
        !$omp& shared(lap_in) &
        !$omp& shared(lap_out)

        !$omp single

        do icrow = 1, my_tasklim, my_tasks_grainsize
                !$omp task default(none) &
                !$omp& firstprivate(icrow) &
                !$omp& shared(my_tasks_grainsize) &
                !$omp& shared(sten_coeff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in) &
                !$omp& shared(lap_out)
                call real_internal_edges_111_depth6( &
                        crow0=icrow, &
                        tasks_grainsize=my_tasks_grainsize, &
                        coeff=sten_coeff, &
                        indim=parallel%mydim, &
                        outdim=parallel%mydim, &
                        invec=lap_in(:), &
                        outvec=lap_out(:))
                !$omp end task
        enddo

        if (my_leftover > 0) then
                !$omp task default(none) &
                !$omp& shared(my_tasklim) &
                !$omp& shared(my_leftover) &
                !$omp& shared(sten_coeff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in) &
                !$omp& shared(lap_out)
                call real_internal_edges_111_depth6( &
                        crow0=my_tasklim+1, &
                        tasks_grainsize=my_leftover, &
                        coeff=sten_coeff, &
                        indim=parallel%mydim, &
                        outdim=parallel%mydim, &
                        invec=lap_in(:), &
                        outvec=lap_out(:))
                !$omp end task
        endif

        !$omp taskwait

        if (parallel%nprow > 1) then
                !$omp task default(none) &
                !$omp& shared(fold_buff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in)
                call fold_buff%packsend(parallel, vec=lap_in(:), vec_num=1)
                call fold_buff%nonblock_comm(parallel)
                call fold_buff%wait_on_comm(vec_index=1)
                !$omp end task
        endif

        !$omp taskwait

        if (parallel%nprow > 1) then
                do icrow = 1, ext_tasklim, ext_tasks_grainsize
                        !$omp task default(none) &
                        !$omp& firstprivate(icrow) &
                        !$omp& shared(ext_tasks_grainsize) &
                        !$omp& shared(sten_coeff) &
                        !$omp& shared(parallel) &
                        !$omp& shared(fold_buff) &
                        !$omp& shared(lap_out)
                        call real_ghost_edges_111_depth6( &
                                crow0=icrow, &
                                tasks_grainsize=ext_tasks_grainsize, &
                                coeff=sten_coeff, &
                                buffdim=parallel%buffdim, &
                                outdim=parallel%mydim, &
                                buffvec=fold_buff%receive(:), &
                                outvec=lap_out(:))
                        !$omp end task
                enddo

                if (ext_leftover > 0) then
                        !$omp task default(none) &
                        !$omp& shared(ext_tasklim) &
                        !$omp& shared(ext_leftover) &
                        !$omp& shared(sten_coeff) &
                        !$omp& shared(parallel) &
                        !$omp& shared(fold_buff) &
                        !$omp& shared(lap_out)
                        call real_ghost_edges_111_depth6( &
                                crow0=ext_tasklim+1, &
                                tasks_grainsize=ext_leftover, &
                                coeff=sten_coeff, &
                                buffdim=parallel%buffdim, &
                                outdim=parallel%mydim, &
                                buffvec=fold_buff%receive(:), &
                                outvec=lap_out(:))
                        !$omp end task
                endif
        endif

        !$omp end single

        !$omp end parallel



#else

        do icrow = 1, my_sten_edges%nrows
                lap_out(icrow) = sten_coeff%c0*lap_in(icrow)
        enddo

        do icrow = 1, my_sten_edges%nrows
                do irow = my_sten_edges%rows(icrow), &
                          my_sten_edges%rows(icrow+1)-1

                        lap_out(icrow) = lap_out(icrow) + &
                                sten_coeff%coeff_1d( &
                                my_sten_edges%vals(irow) )* &
                                lap_in( my_sten_edges%cols(irow) )
                enddo
        enddo

        if (parallel%nprow > 1) then
                call fold_buff%packsend(parallel, vec=lap_in(:), vec_num=1)
                call fold_buff%nonblock_comm(parallel)
                call fold_buff%wait_on_comm(vec_index=1)
        endif

        if (parallel%nprow > 1) then
                do icrow = 1, ext_sten_edges%nrows
                do irow = ext_sten_edges%rows(icrow),  &
                          ext_sten_edges%rows(icrow+1)-1
                        lap_out(icrow) = lap_out(icrow) + &
                                sten_coeff%coeff_1d( ext_sten_edges%vals(irow) )* &
                                fold_buff%receive( ext_sten_edges%cols(irow) )
                enddo
                enddo
        endif














#endif

else



        !$omp parallel default(none) &
        !$omp& private(icrow) &
        !$omp& private(tempvec) &
        !$omp& shared(my_leftover) &
        !$omp& shared(my_tasklim) &
        !$omp& shared(my_tasks_grainsize) &
        !$omp& shared(ext_leftover) &
        !$omp& shared(ext_tasklim) &
        !$omp& shared(ext_tasks_grainsize) &
        !$omp& shared(sten_coeff) &
        !$omp& shared(fold_buff) &
        !$omp& shared(parallel) &
        !$omp& shared(lap_in) &
        !$omp& shared(lap_out) &
        !$omp& shared(foldsize)

        ! we want the gemv to be done with num_threads=1

        !$omp single

        do icrow = 1, my_tasklim, my_tasks_grainsize
                !$omp task default(none) &
                !$omp& firstprivate(icrow) &
                !$omp& shared(my_tasks_grainsize) &
                !$omp& shared(sten_coeff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in) &
                !$omp& shared(lap_out)
                call real_internal_edges_222_depth6( &
                        crow0=icrow, &
                        tasks_grainsize=my_tasks_grainsize, &
                        coeff=sten_coeff, &
                        indim=parallel%mydim, &
                        outdim=parallel%mydim, &
                        invec=lap_in(:), &
                        outvec=lap_out(:))
                !$omp end task
        enddo

        if (my_leftover > 0) then
                !$omp task default(none) &
                !$omp& shared(my_tasklim) &
                !$omp& shared(my_leftover) &
                !$omp& shared(sten_coeff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in) &
                !$omp& shared(lap_out)
                call real_internal_edges_222_depth6( &
                        crow0=my_tasklim+1, &
                        tasks_grainsize=my_leftover, &
                        coeff=sten_coeff, &
                        indim=parallel%mydim, &
                        outdim=parallel%mydim, &
                        invec=lap_in(:), &
                        outvec=lap_out(:))
                !$omp end task
        endif
 
        !$omp taskwait

        if (parallel%nprow > 1) then
                !$omp task default(none) &
                !$omp& shared(fold_buff) &
                !$omp& shared(parallel) &
                !$omp& shared(lap_in)
                call fold_buff%packsend(parallel, vec=lap_in(:), vec_num=1)
                call fold_buff%nonblock_comm(parallel)
                call fold_buff%wait_on_comm(vec_index=1)
                !$omp end task
        endif

        !$omp taskwait

        if (parallel%nprow > 1) then
                do icrow = 1, ext_tasklim, ext_tasks_grainsize
                        !$omp task default(none) &
                        !$omp& firstprivate(icrow) &
                        !$omp& shared(ext_tasks_grainsize) &
                        !$omp& shared(sten_coeff) &
                        !$omp& shared(parallel) &
                        !$omp& shared(fold_buff) &
                        !$omp& shared(lap_out)
                        call real_ghost_edges_222_depth6( &
                                crow0=icrow, &
                                tasks_grainsize=ext_tasks_grainsize, &
                                coeff=sten_coeff, &
                                buffdim=parallel%buffdim, &
                                outdim=parallel%mydim, &
                                buffvec=fold_buff%receive(:), &
                                outvec=lap_out(:))
                        !$omp end task
                enddo

                if (ext_leftover > 0) then
                        !$omp task default(none) &
                        !$omp& shared(ext_tasklim) &
                        !$omp& shared(ext_leftover) &
                        !$omp& shared(sten_coeff) &
                        !$omp& shared(parallel) &
                        !$omp& shared(fold_buff) &
                        !$omp& shared(lap_out)
                        call real_ghost_edges_222_depth6( &
                                crow0=ext_tasklim+1, &
                                tasks_grainsize=ext_leftover, &
                                coeff=sten_coeff, &
                                buffdim=parallel%buffdim, &
                                outdim=parallel%mydim, &
                                buffvec=fold_buff%receive(:), &
                                outvec=lap_out(:))
                        !$omp end task
                endif
        endif

        !$omp end single

        ! revert back to original mkl_num_threads=omp_num_threads
        !$omp end parallel

endif





end subroutine laplacian_fold












subroutine my_laplacian(parallel, sten_coeff, lap_buff, &
        lap_in, lap_out, vect)

use parallel_data_module
use dbuffer_module
use stencil_things
use constants 

#ifdef _OPENMP
use omp_lib
#endif

implicit none

type(parallel_data), intent(in) :: parallel
type(fold_stencil), intent(in) :: sten_coeff
!type(fold_buffer), intent(inout) :: fold_buff
type(lap_buffer), intent(inout) :: lap_buff

real(dp), dimension(parallel%mydim), intent(in) :: lap_in
real(dp), dimension(parallel%mydim), intent(out) :: lap_out
real(dp), dimension(parallel%myworkdim+1), intent(inout) :: vect

!real(dp), dimension(sten_coeff%foldsize) :: tempvec
!integer :: icrow
integer :: irow
integer :: foldsize
!integer :: my_leftover, my_tasklim, my_tasks_grainsize
!integer :: ext_leftover, ext_tasklim, ext_tasks_grainsize
integer :: ish

! --------------------------------------------------------------

foldsize = sten_coeff%foldsize


if (foldsize == 1) then 

        if (parallel%nprow > 1) then
                call dbuff_lap_pack(parallel, lap_buff, lap_in(:), &
                        1, 1, 1, parallel%mydim)
                call dbuff_lap_comm(parallel, lap_buff)
        endif

        call dcopy(parallel%mydim, lap_in(:), 1, vect(:), 1)

        vect(parallel%myworkdim+1) = zero 

        do irow = 1, parallel%mydim
                lap_out(irow) = sten_coeff%c0*lap_in(irow)
        enddo

        if (parallel%nprow > 1) then
                call buff_lap_check_comm(lap_buff, 1)
                call dbuffer_lap_unpack(parallel, vect(:), lap_buff)
        endif

        do irow = 1,parallel%mydim
        do ish = 1, (3+sten_coeff%lap_dir_num)*sten_coeff%norder*2
                lap_out(irow) = lap_out(irow) + &
                        sten_coeff%coeff_1d(ish)* &
                        vect( parallel%neibs(ish,irow) )
        enddo
        enddo
   



else


        write(9,*) 'my_laplacian(): for nonorthogonal grids right now &
                &only (foldblock_side_length == 1) is supported'
        stop

endif





end subroutine my_laplacian


















end module laplacian_ops_module
