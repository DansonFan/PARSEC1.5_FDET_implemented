module paux
   implicit none
   !> provides f:R^N-->R and f:C^N-->R
   interface distnorm
      module procedure :: distdnorm, distzdnorm
   end interface distnorm
   contains
!===============================================================
!
!  Dot product, MPI version of the BLAS ddot function.
!  needed by cg.
! 
!   This probably has to eventually get a similar invocation as psum
!   Will wait until I understand macros in Fortran a bit more so I can
!   Template Engine it. Maybe a graduation gift --CML
!---------------------------------------------------------------
function distdot(n,x,ix,y,iy,nnodes,comm)
  use constants
  use psum_module
  use external_interfaces, only : ddot
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: n, ix, iy, nnodes, comm
  real(dp), intent(in) :: x(n), y(n)
  !  dot product
  real(dp) :: distdot
  !
  !  Work variables:
  !---------------------------------------------------------------
  distdot = ddot(n,x,ix,y,iy)
  call psum(distdot,1,nnodes,comm)
end function distdot
function distddot(n,x,ix,y,iy,nnodes,comm)
  use constants
  use psum_module
  use external_interfaces, only : ddot
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: n, ix, iy, nnodes, comm
  real(dp), intent(in) :: x(n), y(n)
  !  dot product
  real(dp) :: distddot
  !
  !  Work variables:
  !---------------------------------------------------------------
  distddot = ddot(n,x,ix,y,iy)
  call psum(distddot,1,nnodes,comm)
end function distddot
function distdnorm(n,x,nnodes,comm)
  use constants, only : dp
  use psum_module
  use external_interfaces, only : ddot
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: n, nnodes, comm
  real(dp), intent(in) :: x(n)
  !  dot product
  real(dp) :: distdnorm
  integer, parameter :: ix = 1
  !
  !  Work variables:
  !---------------------------------------------------------------
  distdnorm = ddot(n,x,ix,x,ix)
  call psum(distdnorm,1,nnodes,comm)
  distdnorm = sqrt(distdnorm)
end function distdnorm
complex(dpc) function distznorm(n,x,nnodes,comm)
  use constants, only : dp, dpc
  use psum_module
  use external_interfaces, only : zdotc
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: n, nnodes, comm
  complex(dpc), intent(in) :: x(n)
  !  dot product
  integer, parameter :: ix = 1
  !
  !  Work variables:
  !---------------------------------------------------------------
  distznorm = zdotc(n,x,ix,x,ix)
  call psum(distznorm,1,nnodes,comm)
  distznorm = sqrt(distznorm)
end function distznorm
real(dp) function distzdnorm(n,x,nnodes,comm)
  use constants, only : dp, dpc
  use psum_module
  use external_interfaces, only : zdotc
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: n, nnodes, comm
  complex(dpc), intent(in) :: x(n)
  !  dot product
  integer, parameter :: ix = 1
  !  Work variables:
  complex(dpc) :: tmp_distzdnorm
  !---------------------------------------------------------------
  tmp_distzdnorm = zdotc(n,x,ix,x,ix)
  call psum(tmp_distzdnorm,1,nnodes,comm)
  distzdnorm = real(sqrt(tmp_distzdnorm),dp)
end function distzdnorm
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine shifts a ~potential~ array so that its average is zero.
! Needed only with periodic boundary conditions.
!
! author: ?
! Changing potshift to {Z,D}shiftvec in the future --CML
!
!---------------------------------------------------------------
subroutine potshift(vcell,hcub,nrep,ndim,procs_num,comm,pot,avg)

  use constants
  use psum_module
  implicit none
  !
  ! Input/Output variables:
  !
  ! hcub = (grid spacing)^3
  real(dp), intent(in) :: hcub
  ! number of symmetry representations (used as ratio between
  ! volumes of full cell and of irreducible wedge)
  integer, intent(in) :: nrep
  ! size of input potential
  integer, intent(in) :: ndim
  ! communication parameters
  integer, intent(in) :: procs_num, comm
  ! input: potential, output: shifted potential
  real(dp), intent(inout) :: pot(ndim)
  ! volume of unit cell
  real(dp), intent(in) :: vcell
  ! average of potential prior to shifting
  real(dp), intent(out) :: avg
  !---------------------------------------------------------------
  avg = sum(pot) * real(nrep,dp)
  call psum(avg,1,procs_num,comm)

  ! Rescale average.
  avg = avg * hcub / vcell
  pot = pot - avg
end subroutine potshift
!===============================================================
end module paux
