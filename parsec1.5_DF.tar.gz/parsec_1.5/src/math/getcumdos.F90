#ifdef __INTEL_MKL__
include 'mkl_vsl.f90'
#endif

! ===================================================================
subroutine getcumdos(x, y)

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08
#else
use mpi
#endif
#endif

#ifdef __INTEL_MKL__
use MKL_VSL_TYPE
use MKL_VSL
#endif

use constants
use parsec_global_data, only : pot, nloc_p_pot, u_pot, solver, parallel

implicit none



!> I/O variables
real(dp), dimension(:), allocatable, intent(out) :: x, y

#ifdef __INTEL_MKL__
!> Local variables
integer :: Nsamp, Nsamp_per_colgroup, Mdeg, m, jcol, irow, itmp, info, inode
integer :: nprow, npcol, icontext, n, ldn
integer :: brng, seed, method, mydim, colgroups_per_task
integer, parameter :: dlen_ = 9, rsrc = 0, csrc = 0
integer, external :: sys2blacs_handle, numroc
integer, dimension(dlen_) :: desc_w
integer, dimension(:,:), allocatable :: usermap

real(dp) :: evlb, evub, rtmp, mingap, mingap0, del
real(dp), dimension(:), allocatable :: v0, w, f, evlbs, evubs, theta, &
        gaps, gaps1
real(dp), dimension(:,:), allocatable :: V, T, sigmas, gamma2s, thetas

type(VSL_STREAM_STATE) :: stream

#ifdef WITH_MPI_F08
type(mpi_comm) :: rowgroup_comm_f08
#else
integer :: rowgroup_comm_f08
#endif

! ===================================================================


#ifdef USE_SCALAPACK


#ifdef WITH_MPI_F08
rowgroup_comm_f08%mpi_val = parallel%rowgroup_comm
#else
rowgroup_comm_f08 = parallel%rowgroup_comm
#endif



ldn = parallel%ldn
n = ldn * parallel%nprow
mydim = parallel%mydim
colgroups_per_task = parallel%npcol
Nsamp_per_colgroup = 2  !10
Nsamp = max(8, Nsamp_per_colgroup*colgroups_per_task)
do while (Nsamp > (Nsamp_per_colgroup * colgroups_per_task))
        Nsamp_per_colgroup = Nsamp_per_colgroup + 1
        Nsamp = max(8, Nsamp_per_colgroup*colgroups_per_task)
enddo
write(9,*) 'Nsamp_per_colgroup', Nsamp_per_colgroup
write(9,*) 'Nsamp', Nsamp
Mdeg = 100

if (n < 5000) Mdeg = 50
if (n < 4000) Mdeg = 40
if (n < 3000) Mdeg = 30
if (n < 2000) Mdeg = 20
if (n < 1000) Mdeg = 10

allocate(v0(ldn))
allocate(w(ldn))
allocate(f(ldn))
allocate(evlbs(Nsamp))
allocate(evubs(Nsamp))
allocate(theta(Mdeg+2))
allocate(gaps(Mdeg+1))
allocate(gaps1(Mdeg))
allocate(V(ldn,Mdeg))
allocate(T(Mdeg,Mdeg))
allocate(gamma2s(Mdeg,Nsamp))
allocate(thetas(Mdeg,Nsamp))
allocate(sigmas(Mdeg,Nsamp))

evlbs(:) = zero
evubs(:) = zero
gamma2s(:,:) = zero
thetas(:,:) = zero

!> Set up a BLACS process grid
nprow = parallel%nprow
npcol = 1
allocate(usermap(nprow,npcol))
do jcol = 1, npcol
        do irow = 1, nprow
                usermap(irow,jcol) = (jcol-1) * nprow + irow - 1
        enddo
enddo
icontext = sys2blacs_handle(parallel%colgroup_comm)
call blacs_gridmap(icontext, usermap, nprow, nprow, npcol)
deallocate(usermap)


call descinit(desc_w, n, 1, ldn, 1, rsrc, csrc, icontext, ldn, info)
if (info /= 0) write(9,*) 'An error occurred'


!> Create a random number stream
brng = VSL_BRNG_MT19937
seed = parallel%taskgroup_iam
method = VSL_RNG_METHOD_GAUSSIAN_ICDF
info = vslnewstream(stream, brng, seed)
if (info /= 0) write(9,*) 'An error occurred1'


!> Each column group starts to sample Nsamp_per_colgroup times
do m = 1, Nsamp_per_colgroup
        f(:) = zero
        w(:) = zero
        v0(:) = zero
        V(:,:) = zero
        T(:,:) = zero

        !> Note here we just get random numbers for the first mydim elements
        info = vdrnggaussian(method, stream, mydim, w(:), zero, one)
        if (info /= 0) write(9,*) 'An error occurred2'

        call pdnrm2(n, rtmp, w(:), 1, 1, desc_w, 1)
        call pdaxpy(n, one/rtmp, w(:), 1, 1, desc_w, 1, v0(:), 1, 1, desc_w, 1)
        call hslan(v0(:), Mdeg, V(:,:), T(:,:), f(:))
        T(:,:) = (T(:,:) + transpose(T(:,:))) / two

        do irow = 1, Mdeg
                do jcol = 1, Mdeg
                        if (T(irow,jcol) < 1d-14) then
                                T(irow,jcol) = zero
                        endif
                enddo
        enddo

        call pdnrm2(n, rtmp, f(:), 1, 1, desc_w, 1)
        itmp = (parallel%mycolgroup + 1) + (m-1) * colgroups_per_task
        write(9,*) 'itmp', itmp
        call getevbnds(T(:,:), rtmp, evlbs(itmp), evubs(itmp), &
                gamma2s(:,itmp), thetas(:,itmp), Mdeg)
        !call getevbnds(T(:,:), rtmp, evlbs(m), evubs(m), &
        !        gamma2s(:,m), thetas(:,m), Mdeg)
enddo

!> So far every proc in a colgroup has the same T(:,:)
!! After the MPI_Allreduce's, all procs have the same evlbs(:), evubs(:), 
!! gammas(:,:), and thetas(:,:)
call MPI_Allreduce(MPI_IN_PLACE, evlbs(:), Nsamp, &
        MPI_DOUBLE_PRECISION, MPI_SUM, rowgroup_comm_f08, info)
call MPI_Allreduce(MPI_IN_PLACE, evubs(:), Nsamp, &
        MPI_DOUBLE_PRECISION, MPI_SUM, rowgroup_comm_f08, info)
call MPI_Allreduce(MPI_IN_PLACE, gamma2s(:,:), Mdeg*Nsamp, &
        MPI_DOUBLE_PRECISION, MPI_SUM, rowgroup_comm_f08, info)
call MPI_Allreduce(MPI_IN_PLACE, thetas(:,:), Mdeg*Nsamp, &
        MPI_DOUBLE_PRECISION, MPI_SUM, rowgroup_comm_f08, info)

call blacs_gridexit(icontext)

info = vsldeletestream(stream)
if (info /= 0) then
        write(9,*) 'An error occurred'
        STOP
endif

evlb = maxval(evlbs(:))
evub = minval(evubs(:))

! Figures out sigma
mingap0 = evub - evlb

do m = 1, Nsamp
        theta(1) = evlbs(m)
        theta(2:Mdeg+1) = thetas(:,m)
        theta(Mdeg+2) = evubs(m)

        gaps(:) = theta(2:Mdeg+2) - theta(1:Mdeg+1)
        mingap = minval(gaps(:))

        if (mingap > mingap0) then
                mingap = mingap0
        endif

        gaps1(:) = (gaps(1:Mdeg) + gaps(2:Mdeg+1)) / two
        sigmas(:,m) = gaps1(:) / sqrt(log(10d4))
enddo

! Guard against multiple eigenvalues
if (mingap < (evub - evlb) / n) then
        mingap = (evub - evlb) / n
endif

del = mingap
itmp = floor(((evub+del) - (evlb-del)) / del)

allocate(x(itmp))
allocate(y(itmp))
y(:) = zero

do jcol = 1, itmp
        x(jcol) = (evlb-del) + del*(jcol-1)
enddo

call cumdos(n, sigmas, thetas, gamma2s, x, y, Mdeg, Nsamp, size(x))

deallocate(v0)
deallocate(w)
deallocate(f)
deallocate(evlbs)
deallocate(evubs)
deallocate(theta)
deallocate(gaps)
deallocate(gaps1)
deallocate(V)
deallocate(T)
deallocate(gamma2s)
deallocate(thetas)
deallocate(sigmas)

#endif

! paired with __INTEL_MKL__
#endif

end subroutine getcumdos
! ===================================================================


! ===================================================================
subroutine hslan(v0, maxiter, V, T, f)


#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08
#else
use mpi
#endif
#endif



use constants
use parsec_global_data
use matvecMP

implicit none

!> I/O variables
integer, intent(in) :: maxiter
real(dp), dimension(parallel%ldn), intent(inout) :: v0, f
real(dp), dimension(parallel%ldn,maxiter), intent(out) :: V
real(dp), dimension(maxiter,maxiter), intent(out) :: T

!> Local variables
integer :: info, irow, jcol, n, ldn
integer :: nprow, npcol, myrow, mycol, icontext
integer, parameter :: dlen_ = 9, rsrc = 0, csrc = 0
integer, dimension(dlen_) :: desc_w, desc_v, desc_h, desc_hs
integer, dimension(:,:), allocatable :: usermap
integer, external :: sys2blacs_handle
real(dp) :: beta
real(dp), dimension(:), allocatable :: Av, hh, ss


#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif

! ===================================================================


#ifdef USE_SCALAPACK


#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif


ldn = parallel%ldn
n = ldn * parallel%nprow

allocate(Av(ldn))

!> Set up a BLACS process grid
nprow = parallel%nprow
npcol = 1
allocate(usermap(nprow,npcol))
do jcol = 1, npcol
        do irow = 1, nprow
                usermap(irow,jcol) = (jcol-1) * nprow + irow - 1
        enddo
enddo
icontext = sys2blacs_handle(colgroup_comm_f08)
call blacs_gridmap(icontext, usermap, nprow, nprow, npcol)
deallocate(usermap)


!> Set up descriptors for global matrices
call descinit(desc_hs, n, n, ldn, n, rsrc, csrc, icontext, ldn, info)
call descinit(desc_w, n, 1, ldn, 1, rsrc, csrc, icontext, ldn, info)
call descinit(desc_v, n, maxiter, ldn, maxiter, &
        rsrc, csrc, icontext, ldn, info)
call descinit(desc_h, maxiter*nprow, 1, maxiter, 1, &
        rsrc, csrc, icontext, maxiter, info)


!> Start Lanczos
jcol = 1

call pdnrm2(n, beta, v0(:), 1, 1, desc_w, 1)
call pdscal(n, one/beta, v0(:), 1, 1, desc_w, 1)
call pdcopy(n, v0(:), 1, 1, desc_w, 1, V(:,:), 1, jcol, desc_v, 1)
call dmatvec9001(1, 1, v0(:), Av(:), ldn)

allocate(hh(jcol))
allocate(ss(jcol))

call pdgemv('T', n, 1, one, V(:,:), 1, 1, desc_v, &
        Av(:), 1, 1, desc_w, 1, zero, hh(:), 1, 1, desc_h, 1)
call pdcopy(n, Av(:), 1, 1, desc_w, 1, f(:), 1, 1, desc_w, 1)
call pdgemv('N', n, jcol, -one, V(:,:), 1, 1, desc_v, &
        hh(:), 1, 1, desc_h, 1, one, f(:), 1, 1, desc_w, 1)

!> One step of reorthogonalization
call pdgemv('T', n, 1, one, V(:,:), 1, 1, desc_v, &
        f(:), 1, 1, desc_w, 1, zero, ss(:), 1, 1, desc_h, 1)
call pdgemv('N', n, 1, -one, V(:,:), 1, 1, desc_v, &
        ss(:), 1, 1, desc_h, 1, one, f(:), 1, 1, desc_w, 1)

call MPI_Bcast(hh(:), jcol, MPI_DOUBLE_PRECISION, 0, &
        colgroup_comm_f08, info)
T(jcol,jcol) = hh(jcol)

deallocate(hh)
deallocate(ss)

!> Main loop
do jcol = 2, maxiter
        call pdnrm2(n, beta, f(:), 1, 1, desc_w, 1)
        T(jcol,jcol-1) = beta

        call pdcopy(n, f(:), 1, 1, desc_w, 1, v0(:), 1, 1, desc_w, 1)
        call pdscal(n, one/beta, v0(:), 1, 1, desc_w, 1)
        call pdcopy(n, v0(:), 1, 1, desc_w, 1, V(:,:), 1, jcol, desc_v, 1)
        call dmatvec9001(1, 1, v0(:), Av(:), ldn)

        allocate(hh(jcol))
        allocate(ss(jcol))

        call pdgemv('T', n, jcol, one, V(:,:), 1, 1, desc_v, &
                Av(:), 1, 1, desc_w, 1, zero, hh(:), 1, 1, desc_h, 1)
        call pdgemv('N', n, jcol, one, V(:,:), 1, 1, desc_v, &
                hh(:), 1, 1, desc_h, 1, zero, f(:), 1, 1, desc_w, 1)
        call pdscal(n, -one, f(:), 1, 1, desc_w, 1)
        call pdaxpy(n, one, Av(:), 1, 1, desc_w, 1, f(:), 1, 1, desc_w, 1)

        !> One step of reorthogonalization
        call pdgemv('T', n, jcol, one, V(:,:), 1, 1, desc_v, &
                f(:), 1, 1, desc_w, 1, zero, ss(:), 1, 1, desc_h, 1)
        hh(:) = hh(:) + ss(:)
        call pdgemv('N', n, jcol, -one, V(:,:), 1, 1, desc_v, &
                ss(:), 1, 1, desc_h, 1, one, f(:), 1, 1, desc_w, 1)

        call MPI_Bcast(hh(:), jcol, MPI_DOUBLE_PRECISION, 0, &
                colgroup_comm_f08, info)
        T(1:jcol,jcol) = hh(:)

        deallocate(hh)
        deallocate(ss)
enddo

T(:,:) = (T(:,:) + transpose(T(:,:))) / two

call blacs_gridexit(icontext)

#endif

end subroutine hslan
! ===================================================================





! ===================================================================
subroutine getevbnds(T, beta, evlb, evub, gamma2, d, Mdeg)

use constants

implicit none

integer, intent(in) :: Mdeg
real(dp), intent(in) :: beta
real(dp), intent(inout) :: evlb, evub
real(dp), dimension(Mdeg), intent(inout) :: gamma2, d
real(dp), dimension(Mdeg,Mdeg), intent(in) :: T

integer :: lwork, jcol, info
real(dp) :: tt, x
real(dp), dimension(:), allocatable :: work

allocate(work(1))
call dsyev('V', 'U', Mdeg, T(:,:), Mdeg, d, work(:), -1, info)
if (info /= 0) then
        write(9,*) 'An error occurred'
        STOP
endif
lwork = int(work(1))
deallocate(work)
allocate(work(lwork))
call dsyev('V', 'U', Mdeg, T(:,:), Mdeg, d, work, lwork, info)
if (info /= 0) then
        write(9,*) 'An error occurred'
        STOP
endif

do jcol = 1, Mdeg
        gamma2(jcol) = T(1,jcol) * T(1,jcol)
enddo

evlb = huge(0d0)
evub = -huge(0d0)

do jcol = 1, Mdeg
        tt = abs(beta * T(Mdeg,jcol))
        x = d(jcol) - tt

        if (x < evlb) then
                evlb = x
        endif

        x = d(jcol) + tt

        if (x > evub) then
                evub = x
        endif
enddo

!deallocate(S)

end subroutine getevbnds
! ===================================================================


! ===================================================================
!
! Compute the cumulative DOS from parameters returned from the hslandos
!
! ===================================================================
subroutine cumdos(n, sigmas, thetas, gamma2s, xx, yy, Mdeg, Nsamp, lxx)

use constants

implicit none

!> I/O variables
integer, intent(in) :: n, Mdeg, Nsamp, lxx
real(dp), dimension(Mdeg,Nsamp), intent(in) :: sigmas, gamma2s, thetas
real(dp), dimension(lxx), intent(in) :: xx
real(dp), dimension(lxx), intent(inout) :: yy

!> Local variables
integer :: irow, jcol
real(dp) :: prefactor
real(dp), dimension(:,:), allocatable :: exp_fact, sqrt_fact

allocate(exp_fact(Mdeg,Nsamp))
allocate(sqrt_fact(Mdeg,Nsamp))

do irow = 1, Mdeg
        do jcol = 1, Nsamp
                exp_fact(irow,jcol) = two * &
                        sigmas(irow,jcol) * sigmas(irow,jcol)
                sqrt_fact(irow,jcol) = sqrt(1d0 / exp_fact(irow,jcol))
        enddo
enddo

do irow = 1, Mdeg
        do jcol = 1, Nsamp
                prefactor = (real(n, dp) * gamma2s(irow,jcol) / real(Nsamp, dp)) / &
                        sqrt(PI * exp_fact(irow,jcol))
                yy(:) = yy(:) + (prefactor / sqrt_fact(irow,jcol)) * &
                        (erf(sqrt_fact(irow,jcol) * (xx(:) - thetas(irow,jcol))) + 1)
        enddo
enddo

yy(:) = sqrt(PI) * yy(:) / two

deallocate(exp_fact)
deallocate(sqrt_fact)

end subroutine cumdos
! ===================================================================

