!*===============================================================
!!
!> \copyright Copyright (C) 2005 Finite Difference Research Group
!> ! This file is part of parsec,  http://parsec.ices.utexas.edu/
!!
!> \brief  NUMERICAL CONSTANTS, SCIENTIFIC CONSTANTS and general parameters.
!! 
!> \details The numerical constants part of the file should NEVER be touched, barring new
!! and exciting developments in the value of, say, \f$\pi\f$.
!!
!!
!!---------------------------------------------------------------
module constants

use, intrinsic :: iso_fortran_env, only: real64, int32, int64

implicit none

!> \section Machine constants
!
!> Definitions of double precision real types
integer, parameter :: dp = real64
!> Definitions of double precision complex types
integer, parameter :: dpc = real64
! Change this depending on the integer type the mpi implementation uses
integer, parameter :: mympiint = int32
! Change this depending on the integer type Intel MKL uses
integer, parameter :: mymklint = int32
!>  Machine precision for 64bit 2**-52
real(dp), parameter :: mach_eps    = 2.220446049250313080847263336182e-16_dp
!>  2x Machine precision for 64bit 2**-52
real(dp), parameter :: twomach_eps = 4.440892098500626161694526672363e-16_dp
!
!> Tolerance used for semi-sensitive numerics
!
real(dp), parameter :: parsec_tol = 1e-15_dp
!
!> \section  Numerical constants:
real(dp), parameter :: zero = 0.d0, one = 1.d0 !< consider it an alias... don't ask
real(dp), parameter :: dzero = 0.d0, done = 1.d0, &
        two = 2.d0, three = 3.d0, four = 4.d0, five = 5.d0, &
        six = 6.d0, seven = 7.d0, eight = 8.d0, nine = 9.d0, mone = -1.d0, &
        pointninenine = 0.99d0, &
        half = 0.5d0, third = 1.d0/3.d0, mhalf = -0.5d0, &
        root3 = 1.73205080756887729352744634151d0, &
        pi = 3.1415926535897932384626433832795d0, &
        twopi = two*pi
complex(dpc), parameter :: zzero = (0.d0,0.d0), &
        zone = (1.d0,0.d0), zi = (0.d0,1.d0)
!
!> \section  Physical constants:
!
!>  convert energy units from rydbergs to eV
real(dp), parameter :: rydberg = 13.6058d0
!AJB - switch this on
!real(dp), parameter :: rydberg = 13.605693009d0 ! value from NIST 2014 CODATA
!  convert length units from atomic units (bohrs) to angstroms
real(dp), parameter :: angs = 0.529177d0, cubangs = angs**3
!> \param debye convert dipole units from au to debyes
real(dp), parameter :: debye = 2.54d0
!>  convert temperature from kelvins to rydbergs
real(dp), parameter :: tempkry = 6.33327186d-06
!AJB - switch this on
!real(dp), parameter :: tempkry = 6.33362078d-06 ! value from NIST 2014 CODATA
!  convert time from a.u. to ps
real(dp), parameter :: timeaups = 2.4188843d-05

!> Divisor of cdim to find the grain size for matvec
integer, parameter :: GRAIN_DIV = 16
!integer, parameter :: GRAIN_DIV = 64

!> N strikes and you're out
integer, parameter :: NUM_STRIKES_MD = 3

!> \todo turn following code into whatever we decide to use for ENUMERATIONS since that's what they
!! actually are. and get rid of the NONE there - that's sloppy and a keyword
!  constants for minimization scheme
integer, parameter :: OPTNONE = 0, STEEPDESC = 1, BFGS = 2, MANUAL = 3
!  constants for bound estimates
integer, parameter :: k_bounds_lanczos = 0, k_bounds_lanczos_fullorth = 1, k_bounds_static = 2
!  constants for mixing scheme
integer, parameter :: ANDERSON = 0, BROYDEN = 1 ,MSECANT1 = 2, MSECANT2 = 3, MSECANT3 = 4
!  constants for diagonalization scheme
integer, parameter :: ARPACK=1, CHEBDAV=2, CHEBFF=3
!  constants for pseudopotential format
integer, parameter :: MARTINS_OLD = 0, MARTINS_NEW = 1, MARTINS_WANG = 2, FHIPP = 3
!  constants for k-point sampling options
integer, parameter :: KP_MANUAL = 1, MONKHORST_PACK = 2
!  constants for molecular dynamics scheme
integer, parameter :: MD_STAIR = 1, MD_LINEAR = 2, MD_LOG = 3
!  constants for grid export routine. !! Relies also on NONE= 0 assigned above !!
integer, parameter :: CHGDENS = 1, VEXT = 2, VHAR = 3, VEXTHAR = 23, MAX_EXPORT_OPTS = 10
!  ratio between the dispersion of Gaussian distributions and
!  pseudopotential cut-off radius.
real(dp), parameter :: sigmafac = half

real(dp), parameter :: k_infinity = 1.d208
!!===========================================
!! Rayleigh Ritz module logic flags
integer, parameter :: default_nblk = 16 !< default block size for distributed 
!! eigensolving. \note CML elpa doesn't like <16
integer, parameter :: default_max_serial_eigensolver = 16*8-1 !< anything with more
!! eigenvalues requested than this will be solved with elpa
!! logic values are contained in rritz_data_module

real(dp), parameter :: orthtol = 2.5e-16 !< lanczos orthogonalization tolerance

end module constants
!===============================================================
