module aux

implicit none

!===================================================================
!
!  Non-recursive implementation of the quick sort method.
!  always sort the array such that the required eigenvalues
!  are located at the beginning of the sorted array.
!
!-------------------------------------------------------------------

contains

!===============================================================
!
!  Performs matrix-vector multiplications in 3-d arrays. This
!  should be used in place of matmul (which assumes both arguments
!  to be matrices). Input is 3x3 matrix M and vector V. Output is
!  vector MV.
!  If op='T', performs MV = transpose(M)*V
!  If op='N', performs MV = M*V
!
!---------------------------------------------------------------
subroutine matvec3(op, mat, vec, mvec)
        use constants
        implicit none
        !
        !  Input/Output variables:
        !
        !  operation: transpose(M) or M
        character(len=1), intent(in) :: op
        !  input matrix
        real(dp), dimension(3,3), intent(in) :: mat
        !  input vector V
        real(dp), dimension(3), intent(in) :: vec
        !  output vector MV = op(M)*V
        real(dp), dimension(3), intent(out) :: mvec
        !
        !  Work variables:
        !
        integer :: ii
        real(dp), dimension(3) :: vtmp
        !---------------------------------------------------------------
        !AJB: possibly should be a function? vectorize this + openmp if possible
        do ii = 1, 3
                if (op == 'N') then
                        vtmp(ii) = dot_product(mat(ii,:), vec(:))
                elseif (op == 'T') then
                        vtmp(ii) = dot_product(mat(:,ii), vec(:))
                endif
        enddo

        mvec(:) = vtmp(:)

        return
end subroutine matvec3



        !===============================================================
        !
        ! Checks allocation of array with size size, name wst. If
        ! allocation fails, an error message is writen in out.* file and
        ! the calculation is aborted in an abrupt and possibly nasty way.
        !
        ! All "big arrays" (i.e., with size proportional to grid size or
        ! square of number of eigenvalues) should have allocation checked.
        !
        !---------------------------------------------------------------
#ifdef WITH_CAUX
        subroutine alccheck(wst,isize,istat,caux_out)
#else
        subroutine alccheck(wst,isize,istat)
#endif

#ifdef MPI
#ifdef WITH_MPI_F08
                use mpi_f08, only : mpi_abort, mpi_comm_world
#else
                use mpi
#endif
#endif

#ifdef WITH_CAUX
                use, intrinsic :: iso_c_binding
#endif

                implicit none
                !
                ! Input/Output variables:
                !
                integer, intent(in) :: isize, istat
                character (len=*), intent(in) :: wst
#ifdef WITH_CAUX
                integer, optional :: caux_out(2)
#endif
                !
                ! Work variables:
                !
                logical :: ltest          ! true if unit 7 is open
                integer :: aborterr       ! just for completness of mpi call

#ifdef WITH_CAUX
                integer(c_int) :: ierror
                integer(c_int64_t) :: itmp1, itmp2

                interface

                        function get_memory_usage(current, maxout) bind(c, name="get_memory_usage")
                                import :: c_int, c_int64_t
                                integer(c_int) :: get_memory_usage
                                integer(c_int64_t), intent(inout) :: current, maxout
                        end function
                end interface

                interface
                        function get_memory_avail(current, maxout) bind(c, name="get_memory_avail")
                                import :: c_int, c_int64_t
                                integer(c_int) :: get_memory_avail
                                integer(c_int64_t), intent(inout) :: current, maxout
                        end function
                end interface
#endif

#ifdef WITH_CAUX
                if (present(caux_out)) then
                        ierror = get_memory_usage(itmp1,itmp2)
                        caux_out = [itmp1, itmp2]
                        ierror = get_memory_avail(itmp1,itmp2)
                        write(9,'(a,a,*(1x,i12," MB"))') ' memory[cur/highmark/avail/total]:',wst,caux_out,itmp1,itmp2
                endif
#endif

                if (istat /= 0) then
                        write(9,'("*** MEMORY ALLOCATION FAILED (",I2,") ON ARRAY ",a)') istat, wst
                        write(9,'(a,i12)') '     ARRAY SIZE [MB]: ',isize / 1024 * 8 / 1024
                        call myflush(9)
                        inquire(unit=7,opened=ltest)
                        if (ltest) then
                                write(7,'("*** MEMORY ALLOCATION FAILED (",I2,") ON ARRAY ",a)') istat, wst
                                write(7,'(a,i12)') '     ARRAY SIZE [MB]: ',isize / 1024 * 8 / 1024
                                call myflush(7)
                        endif
#ifdef MPI
                        call mpi_abort(mpi_comm_world,124,aborterr)
#endif
                        stop
                endif
        end subroutine alccheck
        !===============================================================



!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This is a machine-dependent subroutine that should be modified
! when porting to new systems.
!
!---------------------------------------------------------------
subroutine myflush(file_num)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  integer file_num 
#ifdef IBM
  external flush
#else
  !let's use fortran 2003 flush.
#endif
  !---------------------------------------------------------------
#ifdef IBM
  call flush(file_num)
#else
  flush(unit=file_num)
#endif

end subroutine myflush

!===============================================================




subroutine sortreal(which, n, x1, x2, targetval)
  use constants
  implicit none
  !
  !  Input/Output variables:
  !
  character(len=2), intent(in) :: which
  integer, intent(in) :: n
  real(dp), intent(inout) :: x1(0:n-1)  ! the array to be sorted
  integer, intent(inout) :: x2(0:n-1)   ! return the index of sorted x1
  real(dp),intent(in) :: targetval
  !
  !  Work variables:
  !
  integer :: i, igap, j
  real(dp) :: temp, xtmp(0:n-1)
  integer :: itemp
  integer :: ierr

  !-----------------------------------------------------------------
  igap = n / 2
  if (igap > 0) call which_xr(which, n, x1, xtmp, targetval,ierr)

  do while (igap > 0) 
              
     do i = igap, n-1
        j = i-igap

        do while (j >= 0) 
           !  always sort the array in non-decreasing order 
           !  according to xtmp, the required eigenvalues are 
           !  located at the beginning of the sorted array x1.
           if (xtmp(j) > xtmp(j+igap)) then
              !  need to reorder xtmp since the next comparisons
              !  are based on the changing x1,
              !  and xtmp need to reflect this change in x1
              temp = xtmp(j)
              xtmp(j) = xtmp(j+igap)
              xtmp(j+igap) = temp

              !  reorder x1
              temp = x1(j)
              x1(j) = x1(j+igap)
              x1(j+igap) = temp

              !  reorder x2
              itemp = x2(j)
              x2(j) = x2(j+igap)
              x2(j+igap) = itemp
           else
              exit
           end if
           j = j-igap
        end do
     end do
     igap = igap / 2
  end do

end subroutine sortreal



!===================================================================
subroutine  which_xr(which, n, x, xtmp, targetval, ierr)
  use constants
  implicit none
  !
  !  Input/Output variables:
  !
  character(len=2), intent(in) :: which
  integer, intent(in) :: n
  real(dp), intent(in) :: x(1:n)  
  real(dp), intent(out) :: xtmp(1:n)
  real(dp), intent(in) :: targetval
  integer, intent(out) :: ierr
  !
  !  Work variables:
  !
  integer :: i

  !-----------------------------------------------------------------

  ierr = 0
  if (which == 'SA'  .or.  which == 'SR') then
     do i = 1, n
        xtmp(i) =  x(i)
     end do
  elseif (which == 'LA'  .or.  which == 'LR') then
     do i = 1, n
        xtmp(i) = - x(i)
     end do
  elseif (which == 'SM') then
     do i = 1, n
        xtmp(i) = abs(x(i))
     end do
  elseif (which == 'LM') then
     do i = 1, n
        xtmp(i) = - abs(x(i))
     end do
  elseif (which == 'TA') then
     do i = 1, n
        xtmp(i) =  abs(x(i)-targetval)
     end do
  elseif (which == 'BE') then
     do i = 1, n
        xtmp(i) =  x(i)
     end do
  else
     write(9,*) "Invalid type of which in: subroutine which_xr"
     ierr = 1
  end if

end subroutine which_xr





!=====================================================================
!
! Printout routine.
!
!-------------------------------------------------------------------
subroutine print_array(ldn, m, n, A)
  use constants
  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: ldn, m, n
  real(dp), intent(in) :: A(ldn,n)
  !
  !  Work variables:
  !
  integer  :: irow, jcol

  if (ldn < m) then
     write(9,*) "Error in print_array: array ldn < m"
     return
  endif
  if (m /= 1 .and. n /= 1) then
     do irow = 1, m
        write(9,711) (A(irow, jcol), jcol=1,n)
     enddo
  elseif (n == 1) then
     write(9,711) (A(irow,1), irow=1,m)
  else 
     write(9,711) (A(1,jcol), jcol=1,n)
  endif

711 format(5(e16.9, 2x))

end subroutine print_array





        !===============================================================
        ! For MPI we use MPI_WTIME and for OpenMP we use omp_get_wtime.
        ! If using neither (why?) then the regular cpu_time would suffice
        !---------------------------------------------------------------
        subroutine mysecond(t)

                use constants

#ifdef MPI
#ifdef WITH_MPI_F08
                use mpi_f08, only : mpi_wtime
#else
                use mpi
#endif
#elif _OPENMP
                use omp_lib
#endif

                implicit none
                real(dp), intent(out) :: t 

                !$OMP MASTER
#ifdef MPI
                t = mpi_wtime()
#elif _OPENMP
                t = OMP_GET_WTIME()
#else
                ! reports time*num_cpu
                call cpu_time(t)
#endif
                !$OMP END MASTER
        end subroutine mysecond




        !===============================================================
        !
        !  This subroutine calculates all of the associated Legendre
        !  polynomials up to a supplied lpole (maximum lpole is 9). 
        !
        !---------------------------------------------------------------
        subroutine setplm(x, y, lpole, plm)

                use constants
                implicit none
                !
                !  Input/Output variables:
                !
                !  cos(theta),sin(theta), for a given grid point
                real(dp), intent(in) :: x,y
                !  order of multipole expansion
                integer, intent(in) :: lpole
                !  array containing P_{lm}, the associated Legendre polynomials
                real(dp), intent(out) :: plm(0:lpole, 0:lpole)
                !
                !  Work variables:
                !
                !  powers of x, y: xn=x^n, yn=y^n
                real(dp) :: x2, x3, x4, x5, x6, x7, x8, x9
                real(dp) :: y2, y3, y4, y5, y6, y7, y8, y9
                !---------------------------------------------------------------
                !
                !  Recursive Definitions for P_{lm}
                !
                !  P_{M,M}
                !  
                !  p00(x,y) = ONE
                !  p11(x,y) = -y
                !  p22(x,y) = +y*y*3.0
                !  p33(x,y) = -y*y*y*5.0*3.0
                !  p44(x,y) = +y*y*y*y*7.0*5.0*3.0
                !  p55(x,y) = -y*y*y*y*y*9.0*7.0*5.0*3.0
                !  p66(x,y) = +y*y*y*y*y*y*11.0*9.0*7.0*5.0*3.0
                !  p77(x,y) = -y*y*y*y*y*y*y*13.0*11.0*9.0*7.0*5.0*3.0
                !  p88(x,y) = +y*y*y*y*y*y*y*y*15.0*13.0*11.0*9.0*7.0*5.0*3.0
                !  p99(x,y) = -y*y*y*y*y*y*y*y*y*17.0*15.0*13.0*11.0*9.0*7.0*5.0*3.0
                !  
                !  P_{M+1,M}
                !  
                !  p10(x,y) = x*p00(x,y)
                !  p21(x,y) = x*3.0*p11(x,y)
                !  p32(x,y) = x*5.0*p22(x,y)
                !  p43(x,y) = x*7.0*p33(x,y)
                !  p54(x,y) = x*9.0*p44(x,y)
                !  p65(x,y) = x*11.0*p55(x,y)
                !  p76(x,y) = x*13.0*p66(x,y)
                !  p87(x,y) = x*15.0*p77(x,y)
                !  p98(x,y) = x*17.0*p88(x,y)
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=0
                !  
                !  p20(x,y) = (x*3.0*p10(x,y)-p00(x,y))/2.0
                !  p30(x,y) = (x*5.0*p20(x,y)-2.0*p10(x,y))/3.0
                !  p40(x,y) = (x*7.0*p30(x,y)-3.0*p20(x,y))/4.0
                !  p50(x,y) = (x*9.0*p40(x,y)-4.0*p30(x,y))/5.0
                !  p60(x,y) = (x*11.0*p50(x,y)-5.0*p40(x,y))/6.0
                !  p70(x,y) = (x*13.0*p60(x,y)-6.0*p50(x,y))/7.0
                !  p80(x,y) = (x*15.0*p70(x,y)-7.0*p60(x,y))/8.0
                !  p90(x,y) = (x*17.0*p80(x,y)-8.0*p70(x,y))/9.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=1
                !  
                !  p31(x,y) = (x*5.0*p21(x,y)-3.0*p11(x,y))/2.0
                !  p41(x,y) = (x*7.0*p31(x,y)-4.0*p21(x,y))/3.0
                !  p51(x,y) = (x*9.0*p41(x,y)-5.0*p31(x,y))/4.0
                !  p61(x,y) = (x*11.0*p51(x,y)-6.0*p41(x,y))/5.0
                !  p71(x,y) = (x*13.0*p61(x,y)-7.0*p51(x,y))/6.0
                !  p81(x,y) = (x*15.0*p71(x,y)-8.0*p61(x,y))/7.0
                !  p91(x,y) = (x*17.0*p81(x,y)-9.0*p71(x,y))/8.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=2
                !  
                !  p42(x,y) = (x*7.0*p32(x,y)-5.0*p22(x,y))/2.0
                !  p52(x,y) = (x*9.0*p42(x,y)-6.0*p32(x,y))/3.0
                !  p62(x,y) = (x*11.0*p52(x,y)-7.0*p42(x,y))/4.0
                !  p72(x,y) = (x*13.0*p62(x,y)-8.0*p52(x,y))/5.0
                !  p82(x,y) = (x*15.0*p72(x,y)-9.0*p62(x,y))/6.0
                !  p92(x,y) = (x*17.0*p82(x,y)-10.0*p72(x,y))/7.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=3
                !  
                !  p53(x,y) = (x*9.0*p43(x,y)-7.0*p33(x,y))/2.0
                !  p63(x,y) = (x*11.0*p53(x,y)-8.0*p43(x,y))/3.0
                !  p73(x,y) = (x*13.0*p63(x,y)-9.0*p53(x,y))/4.0
                !  p83(x,y) = (x*15.0*p73(x,y)-10.0*p63(x,y))/5.0
                !  p93(x,y) = (x*17.0*p83(x,y)-11.0*p73(x,y))/6.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=4
                !  
                !  p64(x,y) = (x*11.0*p54(x,y)-9.0*p44(x,y))/2.0
                !  p74(x,y) = (x*13.0*p64(x,y)-10.0*p54(x,y))/3.0
                !  p84(x,y) = (x*15.0*p74(x,y)-11.0*p64(x,y))/4.0
                !  p94(x,y) = (x*17.0*p84(x,y)-12.0*p74(x,y))/5.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=5
                !  
                !  p75(x,y) = (x*13.0*p65(x,y)-11.0*p55(x,y))/2.0
                !  p85(x,y) = (x*15.0*p75(x,y)-12.0*p65(x,y))/3.0
                !  p95(x,y) = (x*17.0*p85(x,y)-13.0*p75(x,y))/4.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=6
                !  
                !  p86(x,y) = (x*15.0*p76(x,y)-13.0*p66(x,y))/2.0
                !  p96(x,y) = (x*17.0*p86(x,y)-14.0*p76(x,y))/3.0
                !  
                !  P_{L,M} L=M+2, M+3, ... , lpole : M=7
                !  
                !  p97(x,y) = (x*17.0*p87(x,y)-15.0*p77(x,y))/2.0
                !
                !  Rather than defining these polynomials recursively as above it
                !  is much more efficient to simplify them all. As it turns out
                !  the numerical coefficients are all powers of two, so there are
                !  no repeating decimals and we avoid having to do computationally
                !  intensive things like divide by 3 or 7. 
                !  If x = cos(theta) and y = sin(theta) we get the following 
                !  simplifications for the associated Legendre polynomials:
                !
                plm(0,0) = 1.0_dp
                  if (lpole >= 1) then
                     plm(1,0) = x
                     plm(1,1) = -y
                  endif
                  if (lpole >= 2) then
                     x2 = x*x
                     y2 = y*y
                     plm(2,0) = 1.5_dp*x2 - 0.5_dp
                     plm(2,1) = -3.0_dp*x*y
                     plm(2,2) = 3.0_dp*y2
                  endif
                  if (lpole >= 3) then
                     x3 = x2*x
                     y3 = y2*y
                     plm(3,0) = 2.5_dp*x3 - 1.5_dp*x
                     plm(3,1) = -7.5_dp*x2*y + 1.5_dp*y
                     plm(3,2) = 15.0_dp*x*y2
                     plm(3,3) = -15.0_dp*y3
                  endif
                  if (lpole >= 4) then
                     x4 = x2*x2
                     y4 = y2*y2
                     plm(4,0) = 4.375_dp*x4 - 3.75_dp*x2 + 0.375_dp
                     plm(4,1) = -17.5_dp*x3*y + 7.5_dp*x*y
                     plm(4,2) = 52.5_dp*x2*y2 - 7.5_dp*y2
                     plm(4,3) = -105.0_dp*x*y3
                     plm(4,4) = 105.0_dp*y4
                  endif
                  if (lpole >= 5) then
                     x5 = x3*x2
                     y5 = y3*y2
                     plm(5,0) = 7.875_dp*x5 - 8.75_dp*x3 + 1.875_dp*x
                     plm(5,1) = -39.375_dp*x4*y + 26.25_dp*x2*y - 1.875_dp*y
                     plm(5,2) = 157.5_dp*x3*y2 - 52.5_dp*x*y2
                     plm(5,3) = -472.5_dp*x2*y3 + 52.5_dp*y3
                     plm(5,4) = 945.0_dp*x*y4
                     plm(5,5) = -945.0_dp*y5
                  endif
                  if (lpole >= 6) then
                     x6 = x3*x3
                     y6 = y3*y3
                     plm(6,0) = 14.4375_dp*x6 - 19.6875_dp*x4 + 6.5625_dp*x2 - 0.3125_dp
                     plm(6,1) = -86.625_dp*x5*y + 78.75_dp*x3*y - 13.125_dp*x*y
                     plm(6,2) = 433.125_dp*x4*y2 - 236.25_dp*x2*y2 + 13.125_dp*y2
                     plm(6,3) = -1732.5_dp*x3*y3 + 472.5_dp*x*y3
                     plm(6,4) = 5197.5_dp*x2*y4 - 472.5_dp*y4
                     plm(6,5) = -10395.0_dp*x*y5
                     plm(6,6) = 10395.0_dp*y6
                  endif
                  if (lpole >= 7) then
                     x7 = x4*x3
                     y7 = y4*y3
                     plm(7,0) = 26.8125_dp*x7 - 43.3125_dp*x5 + 19.6875_dp*x3 - 2.1875_dp*x
                     plm(7,1) = -187.6875_dp*x6*y + 216.5625_dp*x4*y - 59.0625_dp*x2*y + 2.1875_dp*y
                     plm(7,2) = 1126.125_dp*x5*y2 - 866.25_dp*x3*y2 + 118.125_dp*x*y2
                     plm(7,3) = -5630.625_dp*x4*y3 + 2598.75_dp*x2*y3 - 118.125_dp*y3
                     plm(7,4) = 22522.5_dp*x3*y4 - 5197.5_dp*x*y4
                     plm(7,5) = -67567.5_dp*x2*y5 + 5197.5_dp*y5
                     plm(7,6) = 135135.0_dp*x*y6
                     plm(7,7) = -135135.0_dp*y7
                  endif
                  if (lpole >= 8) then
                     x8 = x4*x4
                     y8 = y4*y4
                     plm(8,0) = 50.2734375_dp*x8 - 93.84375_dp*x6 + 54.140625_dp*x4 - &
                          9.84375_dp*x2 + 0.2734375_dp
                     plm(8,1) = -402.1875_dp*x7*y + 563.0625_dp*x5*y - 216.5625_dp*x3*y + &
                          19.6875_dp*x*y
                     plm(8,2) = 2815.3125_dp*x6*y2 - 2815.3125_dp*x4*y2 + 649.6875_dp*x2*y2 - &
                          19.6875_dp*y2
                     plm(8,3) = -16891.875_dp*x5*y3 + 11261.25_dp*x3*y3 - 1299.375_dp*x*y3
                     plm(8,4) = 84459.375_dp*x4*y4 - 33783.75_dp*x2*y4 + 1299.375_dp*y4
                     plm(8,5) = -337837.5_dp*x3*y5 + 67567.5_dp*x*y5
                     plm(8,6) = 1013512.5_dp*x2*y6 - 67567.5_dp*y6
                     plm(8,7) = -2027025.0_dp*x*y7
                     plm(8,8) = 2027025.0_dp*y8
                  endif

                if (lpole >= 9) then
                        y9 = y5*y4
                        x9 = x5*x4
                        plm(9,0) = 94.9609375_dp*x9 - 201.09375_dp*x7 + 140.765625_dp*x5 - &
                                36.09375_dp*x3 + 2.4609375_dp*x
                        plm(9,1) = -854.6484375_dp*x8*y + 1407.65625_dp*x6*y - &
                                703.828125_dp*x4*y + 108.28125_dp*x2*y - 2.4609375_dp*y
                        plm(9,2) = 6837.1875_dp*x7*y2 - 8445.9375_dp*x5*y2 + &
                                2815.3125_dp*x3*y2 - 216.5625_dp*x*y2
                        plm(9,3) = -47860.3125_dp*x6*y3 + 42229.6875_dp*x4*y3 - &
                                8445.9375_dp*x2*y3 + 216.5625_dp*y3
                        plm(9,4) = 287161.875_dp*x5*y4 - 168918.75_dp*x3*y4 + 16891.875_dp*x*y4
                        plm(9,5) = -1435809.375_dp*x4*y5 + 506756.25_dp*x2*y5 - 16891.875_dp*y5
                        plm(9,6) = 5743237.5_dp*x3*y6 - 1013512.5_dp*x*y6
                        plm(9,7) = -17229712.5_dp*x2*y7 + 1013512.5_dp*y7
                        plm(9,8) = 34459425.0_dp*x*y8
                        plm(9,9) = -34459425.0_dp*y9
                endif

        end subroutine setplm




!===============================================================
!
!  Functions for the calculation of modified Bessel functions with
!  non-zero argument.
!
!  WARNING: Coding for modified Bessel functions (bessel_i, bessel_k,
!  bessi0, bessi1, bessk0, bessk1) is copyrighted by Numerical Recipes.
!  They must be replaced with copyright-free equivalents before attaching
!  GPL license to this file.
!
subroutine bessel_i(n,x,bessi)
  use constants
  implicit none
  integer, intent(in) :: n
  real(dp), intent(in) :: x
  real(dp), intent(out) :: bessi(0:n)
  integer, parameter :: iacc = 40
  real(dp), parameter :: bigno=1.0d30, bigni=1.0d-30
  integer :: j, m
  real(dp) :: bi, bim, bip, tox

  if (abs(x) < twomach_eps) then
     bessi = zero
     bessi(0) = one
     return
  endif
  if (n == 0) then
     bessi(0) = bessi0(x)
     return
  endif
  if (n == 1) then
     bessi(0) = bessi0(x)
     bessi(1) = bessi1(x)
     return
  endif

  tox = two/abs(x)
  bip = zero
  bi = one
  m = 2*((n+int(sqrt(real(iacc*n,dp)))))
  do j = m, 1, -1
     bim = bip + j*tox*bi
     bip = bi
     bi = bim
     if (abs(bi) > bigno .and. j > n) then
        bi = bi*bigni
        bip = bip*bigni
     endif
     if (j <= n) bessi(j) = bip
  enddo
  bip = bessi0(x)
  bessi = bessi*bip/bi
  bessi(0) = bip
  bessi(1) = bessi1(x)
  return
end subroutine bessel_i
!===============================================================
subroutine bessel_k(n,x,bessk)
  use constants
  implicit none
  integer, intent(in) :: n
  real(dp), intent(in) :: x
  real(dp), intent(out) :: bessk(0:n)
  integer :: j
  real(dp) :: bk, bkm, bkp, tox

  tox = two/x
  bkm = bessk0(x)
  bk = bessk1(x)
  bessk(0) = bkm
  bessk(1) = bk
  do j =  1, n-1
     bkp = bkm + j*tox*bk
     bkm = bk
     bk = bkp
     bessk(j+1) = bk
  enddo
  return
end subroutine bessel_k
!===============================================================
function bessi0(x)
  use constants
  implicit none
  real(dp), intent(in) :: x
  real(dp) :: bessi0
  real(dp) :: a(0 : 64), b(0 : 69), c(0 : 44)
  real(dp) :: y,t,w
  integer :: i,k
  data (a(i), i = 0, 12) / &
     8.5246820682016865877d-11, 2.5966600546497407288d-9, &
     7.9689994568640180274d-8, 1.9906710409667748239d-6, &
     4.0312469446528002532d-5, 6.4499871606224265421d-4, &
     7.9012345761930579108d-3, 7.1111111109207045212d-2, &
     4.4444444444472490900d-1, 1.7777777777777532045d0, &
     4.0000000000000011182d0, 3.9999999999999999800d0, &
     1.0000000000000000001d0 / 
  data (a(i), i = 13, 25) / &
     1.1520919130377195927d-10, 2.2287613013610985225d-9, &
     8.1903951930694585113d-8, 1.9821560631611544984d-6, &
     4.0335461940910133184d-5, 6.4495330974432203401d-4, &
     7.9013012611467520626d-3, 7.1111038160875566622d-2, &
     4.4444450319062699316d-1, 1.7777777439146450067d0, &
     4.0000000132337935071d0, 3.9999999968569015366d0, &
     1.0000000003426703174d0 / 
  data (a(i), i = 26, 38) / &
     1.5476870780515238488d-10, 1.2685004214732975355d-9, &
     9.2776861851114223267d-8, 1.9063070109379044378d-6, &
     4.0698004389917945832d-5, 6.4370447244298070713d-4, &
     7.9044749458444976958d-3, 7.1105052411749363882d-2, &
     4.4445280640924755082d-1, 1.7777694934432109713d0, &
     4.0000055808824003386d0, 3.9999977081165740932d0, &
     1.0000004333949319118d0 / 
  data (a(i), i = 39, 51) / &
     2.0675200625006793075d-10, -6.1689554705125681442d-10, &
     1.2436765915401571654d-7, 1.5830429403520613423d-6, &
     4.2947227560776583326d-5, 6.3249861665073441312d-4, &
     7.9454472840953930811d-3, 7.0994327785661860575d-2, &
     4.4467219586283000332d-1, 1.7774588182255374745d0, &
     4.0003038986252717972d0, 3.9998233869142057195d0, &
     1.0000472932961288324d0 / 
  data (a(i), i = 52, 64) / &
     2.7475684794982708655d-10, -3.8991472076521332023d-9, &
     1.9730170483976049388d-7, 5.9651531561967674521d-7, &
     5.1992971474748995357d-5, 5.7327338675433770752d-4, &
     8.2293143836530412024d-3, 6.9990934858728039037d-2, &
     4.4726764292723985087d-1, 1.7726685170014087784d0, &
     4.0062907863712704432d0, 3.9952750700487845355d0, &
     1.0016354346654179322d0 / 
  data (b(i), i = 0, 13) / &
     6.7852367144945531383d-8, 4.6266061382821826854d-7, &
     6.9703135812354071774d-6, 7.6637663462953234134d-5, &
     7.9113515222612691636d-4, 7.3401204731103808981d-3, &
     6.0677114958668837046d-2, 4.3994941411651569622d-1, &
     2.7420017097661750609d0, 14.289661921740860534d0, &
     59.820609640320710779d0, 188.78998681199150629d0, &
     399.87313678256011180d0, 427.56411572180478514d0 / 
  data (b(i), i = 14, 27) / &
     1.8042097874891098754d-7, 1.2277164312044637357d-6, &
     1.8484393221474274861d-5, 2.0293995900091309208d-4, &
     2.0918539850246207459d-3, 1.9375315654033949297d-2, &
     1.5985869016767185908d-1, 1.1565260527420641724d0, &
     7.1896341224206072113d0, 37.354773811947484532d0, &
     155.80993164266268457d0, 489.52113711585409180d0, &
     1030.9147225169564806d0, 1093.5883545113746958d0 / 
  data (b(i), i = 28, 41) / &
     4.8017305613187493564d-7, 3.2613178439123800740d-6, &
     4.9073137508166159639d-5, 5.3806506676487583755d-4, &
     5.5387918291051866561d-3, 5.1223717488786549025d-2, &
     4.2190298621367914765d-1, 3.0463625987357355872d0, &
     18.895299447327733204d0, 97.915189029455461554d0, &
     407.13940115493494659d0, 1274.3088990480582632d0, &
     2670.9883037012547506d0, 2815.7166284662544712d0 / 
  data (b(i), i = 42, 55) / &
     1.2789926338424623394d-6, 8.6718263067604918916d-6, &
     1.3041508821299929489d-4, 1.4282247373727478920d-3, &
     1.4684070635768789378d-2, 1.3561403190404185755d-1, &
     1.1152592585977393953d0, 8.0387088559465389038d0, &
     49.761318895895479206d0, 257.26842323135291380d0, &
     1066.8543146269566231d0, 3328.3874581009636362d0, &
     6948.8586598121634874d0, 7288.4893398212481055d0 / 
  data (b(i), i = 56, 69) / &
     3.4093503681970328930d-6, 2.3079025203103376076d-5, &
     3.4691373283901830239d-4, 3.7949949772229085450d-3, &
     3.8974209677945602145d-2, 3.5949483804148783710d-1, &
     2.9522878893539528226d0, 21.246564609514287056d0, &
     131.28727387146173141d0, 677.38107093296675421d0, &
     2802.3724744545046518d0, 8718.5731420798254081d0, &
     18141.348781638832286d0, 18948.925349296308859d0 / 
  data (c(i), i = 0, 8) / &
     2.5568678676452702768d-15, 3.0393953792305924324d-14, &
     6.3343751991094840009d-13, 1.5041298011833009649d-11, &
     4.4569436918556541414d-10, 1.7463930514271679510d-8, &
     1.0059224011079852317d-6, 1.0729838945088577089d-4, &
     5.1503226936425277380d-2 / 
  data (c(i), i = 9, 17) / &
     5.2527963991711562216d-15, 7.2021184814210056410d-15, &
     7.2561421229904797156d-13, 1.4823121466731042510d-11, &
     4.4602670450376245434d-10, 1.7463600061788679671d-8, &
     1.0059226091322347560d-6, 1.0729838937545111487d-4, &
     5.1503226936437300716d-2 / 
  data (c(i), i = 18, 26) / &
     1.3365917359358069908d-14, -1.2932643065888544835d-13, &
     1.7450199447905602915d-12, 1.0419051209056979788d-11, &
     4.5804788198059832600d-10, 1.7442405450073548966d-8, &
     1.0059461453281292278d-6, 1.0729837434500161228d-4, &
     5.1503226940658446941d-2 / 
  data (c(i), i = 27, 35) / &
     5.3771611477352308649d-14, -1.1396193006413731702d-12, &
     1.2858641335221653409d-11, -5.9802086004570057703d-11, &
     7.3666894305929510222d-10, 1.6731837150730356448d-8, &
     1.0070831435812128922d-6, 1.0729733111203704813d-4, &
     5.1503227360726294675d-2 / 
  data (c(i), i = 36, 44) / &
     3.7819492084858931093d-14, -4.8600496888588034879d-13, &
     1.6898350504817224909d-12, 4.5884624327524255865d-11, &
     1.2521615963377513729d-10, 1.8959658437754727957d-8, &
     1.0020716710561353622d-6, 1.0730371198569275590d-4, &
     5.1503223833002307750d-2 / 
  w = abs(x)
  if (w .lt. 8.5d0) then
      t = w * w * 0.0625d0
      k = 13 * (int(t))
      y = (((((((((((a(k) * t + a(k + 1)) * t + &
         a(k + 2)) * t + a(k + 3)) * t + a(k + 4)) * t + &
         a(k + 5)) * t + a(k + 6)) * t + a(k + 7)) * t + &
         a(k + 8)) * t + a(k + 9)) * t + a(k + 10)) * t + &
         a(k + 11)) * t + a(k + 12)
  else if (w .lt. 12.5d0) then
      k = int(w)
      t = w - k
      k = 14 * (k - 8)
      y = ((((((((((((b(k) * t + b(k + 1)) * t + &
         b(k + 2)) * t + b(k + 3)) * t + b(k + 4)) * t + &
         b(k + 5)) * t + b(k + 6)) * t + b(k + 7)) * t + &
         b(k + 8)) * t + b(k + 9)) * t + b(k + 10)) * t + &
         b(k + 11)) * t + b(k + 12)) * t + b(k + 13)
  else
      t = 60 / w
      k = 9 * (int(t))
      y = ((((((((c(k) * t + c(k + 1)) * t + &
         c(k + 2)) * t + c(k + 3)) * t + c(k + 4)) * t + &
         c(k + 5)) * t + c(k + 6)) * t + c(k + 7)) * t + &
         c(k + 8)) * sqrt(t) * exp(w)
  end if
  bessi0 = y
  return
end function bessi0
!===============================================================
function bessi1(x)
  use constants
  implicit none
  real(dp), intent(in) :: x
  real(dp) :: bessi1
  real(dp) :: a(0 : 59), b(0 : 69), c(0 : 44)
  real(dp) :: y,t,w
  integer :: i,k
  data (a(i), i = 0, 11) / &
     1.2787464404046789181d-10, 3.5705860060088241077d-9, &
     9.9611537619347335040d-8, 2.2395070088633043177d-6, &
     4.0312466928887462346d-5, 5.6437387840203722356d-4, &
     5.9259259312934746096d-3, 4.4444444443499008870d-2, &
     2.2222222222232042719d-1, 6.6666666666666139867d-1, &
     1.0000000000000001106d0, 4.9999999999999999962d-1 / 
  data (a(i), i = 12, 23) / &
     1.7281952384448634449d-10, 3.0647204559976390130d-9, &
     1.0237662138842827028d-7, 2.2299494417341498163d-6, &
     4.0335364374929326943d-5, 5.6433440269141349899d-4, &
     5.9259754885893798654d-3, 4.4444399410880397870d-2, &
     2.2222225112835026730d-1, 6.6666665422146063244d-1, &
     1.0000000032274936821d0, 4.9999999961866867205d-1 / 
  data (a(i), i = 24, 35) / &
     2.3216048939948030996d-10, 1.7443372702334489579d-9, &
     1.1596478963485415499d-7, 2.1446755518623035147d-6, &
     4.0697440347437076195d-5, 5.6324394900433192204d-4, &
     5.9283484996093060678d-3, 4.4440673899150997921d-2, &
     2.2222638016852657860d-1, 6.6666358151576732094d-1, &
     1.0000013834029985337d0, 4.9999971643129650249d-1 / 
  data (a(i), i = 36, 47) / &
     3.1013758938255172562d-10, -8.4813676145611694984d-10, &
     1.5544980187411802596d-7, 1.7811109378708045726d-6, &
     4.2945322199060856985d-5, 5.5344850176852353639d-4, &
     5.9590327716950614802d-3, 4.4371611097707060659d-2, &
     2.2233578241986401111d-1, 6.6654747300463315310d-1, &
     1.0000756505206705927d0, 4.9997803664415994554d-1 / 
  data (a(i), i = 48, 59) / &
     4.1214758313965020365d-10, -5.3613317735347429440d-9, &
     2.4661360807517345161d-7, 6.7144593918926723203d-7, &
     5.1988027944945587571d-5, 5.0165568586065803067d-4, &
     6.1717530047005289953d-3, 4.3745229577317251404d-2, &
     2.2363147971477747996d-1, 6.6475469131117660240d-1, &
     1.0015686689447547657d0, 4.9941120439785391891d-1 / 
  data (b(i), i = 0, 13) / &
     6.6324787943143095845d-8, 4.5125928898466638619d-7, &
     6.7937793134877246623d-6, 7.4580507871505926302d-5, &
     7.6866382927334005919d-4, 7.1185174803491859307d-3, &
     5.8721838073486424416d-2, 4.2473949281714196041d-1, &
     2.6396965606282079123d0, 13.710008536637016903d0, &
     57.158647688180932003d0, 179.46182892089389037d0, &
     377.57997362398478619d0, 399.87313678256009819d0 / 
  data (b(i), i = 14, 27) / &
     1.7652713206027939711d-7, 1.1988179244834708057d-6, &
     1.8037851545747139231d-5, 1.9775785516370314656d-4, &
     2.0354870702829387283d-3, 1.8822164191032253600d-2, &
     1.5500485219010424263d-1, 1.1190100010560573210d0, &
     6.9391565185406617552d0, 35.948170579648649345d0, &
     149.41909525103032616d0, 467.42979492780642582d0, &
     979.04227423171290408d0, 1030.9147225169564443d0 / 
  data (b(i), i = 28, 41) / &
     4.7022299276154507603d-7, 3.1878571710170115972d-6, &
     4.7940153875711448496d-5, 5.2496623508411440227d-4, &
     5.3968661134780824779d-3, 4.9837081920693776234d-2, &
     4.0979593830387765545d-1, 2.9533186922862948404d0, &
     18.278176130722516369d0, 94.476497150189121070d0, &
     391.66075612645333624d0, 1221.4182034643210345d0, &
     2548.6177980961291004d0, 2670.9883037012546541d0 / 
  data (b(i), i = 42, 55) / &
     1.2535083724002034147d-6, 8.4845871420655708250d-6, &
     1.2753227372734042108d-4, 1.3950105363562648921d-3, &
     1.4325473993765291906d-2, 1.3212452778932829125d-1, &
     1.0849287786885151432d0, 7.8068089156260172673d0, &
     48.232254570679165833d0, 248.80659424902394371d0, &
     1029.0736929484210803d0, 3200.5629438795801652d0, &
     6656.7749162019607914d0, 6948.8586598121632302d0 / 
  data (b(i), i = 56, 69) / &
     3.3439394490599745013d-6, 2.2600596902211837757d-5, &
     3.3955927589987356838d-4, 3.7105306061050972474d-3, &
     3.8065263634919156421d-2, 3.5068223415665236079d-1, &
     2.8760027832105027316d0, 20.665999500843274339d0, &
     127.47939148516390205d0, 656.43636874254000885d0, &
     2709.5242837932479920d0, 8407.1174233600734871d0, &
     17437.146284159740233d0, 18141.348781638831600d0 / 
  data (c(i), i = 0, 8) / &
     -2.8849790431465382128d-15, -3.5125350943844774657d-14, &
     -7.4850867013707419750d-13, -1.8383904048277485153d-11, &
     -5.7303556446977223342d-10, -2.4449502737311496525d-8, &
     -1.6765373351766929724d-6, -3.2189516835265773471d-4, &
     5.1503226936425277377d-2 / 
  data (c(i), i = 9, 17) / &
     -5.8674306822281631119d-15, -9.4884898451194085565d-15, &
     -8.5033865136600364340d-13, -1.8142997866945285736d-11, &
     -5.7340238386338193949d-10, -2.4449138101742183665d-8, &
     -1.6765375646678855842d-6, -3.2189516826945356325d-4, &
     5.1503226936412017608d-2 / 
  data (c(i), i = 18, 26) / &
     -1.4723362506764340882d-14, 1.3945147385179042899d-13, &
     -1.9618041857586930923d-12, -1.3343606394065121821d-11, &
     -5.8649674606973244159d-10, -2.4426060539669553778d-8, &
     -1.6765631828366988006d-6, -3.2189515191449587253d-4, &
     5.1503226931820146445d-2 / 
  data (c(i), i = 27, 35) / &
     -5.8203519372580372987d-14, 1.2266326995309845825d-12, &
     -1.3921625844526453237d-11, 6.2228025878281625469d-11, &
     -8.8636681342142794023d-10, -2.3661241616744818608d-8, &
     -1.6777870960740520557d-6, -3.2189402882677074318d-4, &
     5.1503226479551959376d-2 / 
  data (c(i), i = 36, 44) / &
     -4.5801527369223291722d-14, 6.7998819697143727209d-13, &
     -4.1624857909290468421d-12, -3.2849009406112440998d-11, &
     -3.2478275690431118270d-10, -2.5739209934053714983d-8, &
     -1.6730566573215739195d-6, -3.2190010909008684076d-4, &
     5.1503229866932077150d-2 / 
  w = abs(x)
  if (w .lt. 8.5d0) then
      t = w * w * 0.0625d0
      k = 12 * (int(t))
      y = (((((((((((a(k) * t + a(k + 1)) * t + &
         a(k + 2)) * t + a(k + 3)) * t + a(k + 4)) * t + &
         a(k + 5)) * t + a(k + 6)) * t + a(k + 7)) * t + &
         a(k + 8)) * t + a(k + 9)) * t + a(k + 10)) * t + &
         a(k + 11)) * w
  else if (w .lt. 12.5d0) then
      k = int(w)
      t = w - k
      k = 14 * (k - 8)
      y = ((((((((((((b(k) * t + b(k + 1)) * t + &
         b(k + 2)) * t + b(k + 3)) * t + b(k + 4)) * t + &
         b(k + 5)) * t + b(k + 6)) * t + b(k + 7)) * t + &
         b(k + 8)) * t + b(k + 9)) * t + b(k + 10)) * t + &
         b(k + 11)) * t + b(k + 12)) * t + b(k + 13)
  else
      t = 60 / w
      k = 9 * (int(t))
      y = ((((((((c(k) * t + c(k + 1)) * t + &
         c(k + 2)) * t + c(k + 3)) * t + c(k + 4)) * t + &
         c(k + 5)) * t + c(k + 6)) * t + c(k + 7)) * t + &
         c(k + 8)) * sqrt(t) * exp(w)
  end if
  if (x .lt. 0) y = -y
  bessi1 = y
  return
end function bessi1
!===============================================================
function bessk0(x)
  use constants
  implicit none
  real(dp), intent(in) :: x
  real(dp) :: bessk0
  real(dp) :: a(0 : 15), b(0 : 111), c(0 : 134), d(0 : 39)
  real(dp) :: y,t
  integer :: i,k
  data (a(i), i = 0, 15) / &
     2.4307270476772195953d-12, 4.7091666363785304370d-10, &
     6.7816861334344265568d-8, 6.7816840204737508252d-6, &
     4.3402777777915334676d-4, 1.5624999999999872796d-2, &
     2.5000000000000000448d-1, 9.9999999999999999997d-1, &
     6.5878327432224993071d-12, 1.2083308769932888218d-9, &
     1.6271062073716412046d-7, 1.4914719278555277887d-5, &
     8.4603509071212245667d-4, 2.5248929932162333910d-2, &
     2.7898287891460312491d-1, 1.1593151565841244874d-1 / 
  data (b(i), i = 0, 13) / &
     -4.6430702971053162197d-13, 1.0377936059563728230d-11, &
     -1.0298475936392057807d-10, 5.3632747492333959219d-10, &
     -2.1674628861036068105d-10, -2.3316071545820437669d-8, &
     2.2557819578691704059d-7, -9.2325694638587080009d-7, &
     -3.3569097781613661759d-6, 8.7355061305812582974d-5, &
     -6.8021202111645760475d-4, 2.7434654781323362319d-4, &
     1.0031787169953909561d-1, 4.2102443824070833334d-1 / 
  data (b(i), i = 14, 27) / &
     4.1447451117883103686d-12, -3.4026589638576604315d-11, &
     9.3398790624638977468d-12, 1.5184181750799852630d-9, &
     -1.1364911665083029464d-8, 2.0619457602095915719d-8, &
     3.0431018037572243630d-7, -2.9749736264474555510d-6, &
     8.0143661611467038568d-6, 8.0937525149549218398d-5, &
     -1.0356346549612699886d-3, 2.8534806627578638795d-3, &
     9.7369634474060441807d-2, 3.2175066577856452683d-1 / 
  data (b(i), i = 28, 41) / &
     1.1170882570740727520d-13, -8.2865909408297066068d-11, &
     9.4656678749191182763d-10, -3.5832019841847883380d-9, &
     -9.5017955656904252761d-9, 1.5200595674883329093d-7, &
     -3.8663262571356059980d-7, -3.3350340828235103499d-6, &
     2.9359886663960844231d-5, -1.1266401822556801563d-5, &
     -1.2113572742435576205d-3, 6.3158973673701376253d-3, &
     8.8291790250128171341d-2, 2.2833982383240512262d-1 / 
  data (b(i), i = 42, 55) / &
     -3.2880638807053948433d-11, 4.3194884830465283512d-10, &
     -1.7455089683104033093d-9, -3.2437330799994764516d-9, &
     4.7393655539139519778d-8, -1.1929265603456272466d-8, &
     -1.3177845881013419388d-6, 3.3873375636197969526d-6, &
     3.2729835880668256625d-5, -1.8367283883002494561d-4, &
     -8.2830996454188084408d-4, 9.5512732229514251931d-3, &
     7.2233832113719266702d-2, 1.4753187103603405298d-1 / 
  data (b(i), i = 56, 69) / &
     7.9998492614150860098d-11, -7.0257346702686139490d-10, &
     7.8898821627084586270d-10, 1.1294796399671507085d-8, &
     -1.1360539648638059137d-8, -3.0346309115270564487d-7, &
     3.2235585426189451721d-7, 8.3575612102298214948d-6, &
     -8.5169628089198208211d-6, -2.5740175232173357342d-4, &
     1.2462734014689152770d-4, 1.0683232869192203450d-2, &
     5.1515690033637395779d-2, 8.5465862953544883657d-2 / 
  data (b(i), i = 70, 83) / &
     -8.6111506537356531608d-11, 5.1862926131024597823d-10, &
     7.5884324949371110022d-10, -6.4011975813006767417d-9, &
     -4.1966181325111763156d-8, 9.1306285446881485314d-8, &
     1.3573638315827954034d-6, 4.8683213252735694701d-7, &
     -3.8805424608710197066d-5, -1.1838986468688980610d-4, &
     9.2796213947750964945d-4, 8.9611057737319027776d-3, &
     3.1464453915862785606d-2, 4.4267648087536630780d-2 / 
  data (b(i), i = 84, 97) / &
     4.4400123834164610288d-11, -1.1411233140911074336d-10, &
     -8.8200670702467059830d-10, -1.9686735373323381456d-9, &
     1.9921120728941773855d-8, 1.4543974418584834740d-7, &
     1.8238418041265854754d-8, -4.5363700392899066037d-6, &
     -2.1688068222527688542d-5, 4.5496062166687034700d-5, &
     1.0435238076080528284d-3, 5.8374528996419979931d-3, &
     1.6611210710425455850d-2, 2.0756008367065750538d-2 / 
  data (b(i), i = 98, 111) / &
     -6.5166519951106397214d-12, -5.8572182858788539580d-11, &
     1.5550375065815375404d-10, 1.9526509484993563229d-9, &
     9.2637123346818426594d-9, -1.4136471501812055943d-8, &
     -4.3024895710889717172d-7, -2.3235612243330592076d-6, &
     4.0380616133862188804d-7, 9.2783767992909743602d-5, &
     7.2964887597817095035d-4, 3.1316245282223273413d-3, &
     7.8028233022066428316d-3, 9.0014807263791058095d-3 / 
  data (c(i), i = 0, 14) / &
     4.5161032649342790231d-11, -4.2774336988557091369d-11, &
     6.0998467173896677777d-10, 1.9845167242599996944d-9, &
     1.3097678767280215271d-8, 7.4505822268382641286d-8, &
     4.2893920879106814989d-7, 2.3900851955655303104d-6, &
     1.2533473009382380357d-5, 5.9693359063879871983d-5, &
     2.4775070661087304580d-4, 8.5106703131389516508d-4, &
     2.2500105115665788755d-3, 4.0446134454521634600d-3, &
     3.6910983340425942762d-3 / 
  data (c(i), i = 15, 29) / &
     3.5732826433251464989d-12, -3.2906649482312266258d-12, &
     7.0873811190464760555d-11, 2.9551320580484177120d-10, &
     2.2776940472505079894d-9, 1.5175463612815010036d-8, &
     9.9462487812170164133d-8, 6.1448757797853901100d-7, &
     3.4869531882907360750d-6, 1.7615836644757657443d-5, &
     7.6373536037879531886d-5, 2.7098571871205999668d-4, &
     7.3399047381788927036d-4, 1.3439197177355085297d-3, &
     1.2439943280131230863d-3 / 
  data (c(i), i = 30, 44) / &
     3.6343547836242523646d-13, 9.7997961751276137602d-14, &
     1.0184692699811569047d-11, 6.1495184828957652064d-11, &
     5.0238328349302602543d-10, 3.7498626376004337661d-9, &
     2.6689445483857236307d-8, 1.7591899737346368084d-7, &
     1.0486448307010701679d-6, 5.4986458466257148573d-6, &
     2.4521456351751345323d-5, 8.8900942259143832228d-5, &
     2.4483947714068300190d-4, 4.5418248688489693045d-4, &
     4.2479574186923180694d-4 / 
  data (c(i), i = 45, 59) / &
     5.2460389348163395857d-14, 7.4802063026503503540d-14, &
     2.0012201610651998417d-12, 1.4887306044735163359d-11, &
     1.2946705414232940350d-10, 1.0391628915892803144d-9, &
     7.8091180499677328456d-9, 5.3694223626907660084d-8, &
     3.3063914804658509029d-7, 1.7776972424421486506d-6, &
     8.0833148098458320202d-6, 2.9755556304448817780d-5, &
     8.2945928349220642178d-5, 1.5536921180500112883d-4, &
     1.4647070522281538711d-4 / 
  data (c(i), i = 60, 74) / &
     9.7531436733955514559d-15, 2.4084291220447154982d-14, &
     4.7654956400897494468d-13, 4.0200949504810597783d-12, &
     3.6726577109162191533d-11, 3.0939005665422637601d-10, &
     2.4122848979784500179d-9, 1.7071884462645525505d-8, &
     1.0752238955654933405d-7, 5.8844190041189462347d-7, &
     2.7136083303224014597d-6, 1.0102477728604441135d-5, &
     2.8420490721532571809d-5, 5.3637016379451944413d-5, &
     5.0881312956459247572d-5 / 
  data (c(i), i = 75, 89) / &
     2.1732049868189377260d-15, 7.2720052142815590531d-15, &
     1.2803083795536820100d-13, 1.1696825543787717167d-12, &
     1.1083298191597132094d-11, 9.6536661252658773139d-11, &
     7.7242553835198536397d-10, 5.5798366267110575620d-9, &
     3.5721345296543414370d-8, 1.9806931547193682466d-7, &
     9.2312964655319555313d-7, 3.4666258590861079959d-6, &
     9.8224698307751177077d-6, 1.8648773453825584428d-5, &
     1.7780062316167651812d-5 / 
  data (c(i), i = 90, 104) / &
     5.5012463763851934112d-16, 2.2254763392767319419d-15, &
     3.7187669817701214965d-14, 3.5819585377733489628d-13, &
     3.4866061263191556694d-12, 3.1101633450629652910d-11, &
     2.5358235662235617663d-10, 1.8597629779492599046d-9, &
     1.2052654739462999992d-8, 6.7501417351172136833d-8, &
     3.1720052198654584574d-7, 1.1993651363602981832d-6, &
     3.4179130317623363474d-6, 6.5208606745808860158d-6, &
     6.2430205476536771454d-6 / 
  data (c(i), i = 105, 119) / &
     1.5225407517829491689d-16, 6.9834820025664405161d-16, &
     1.1380182837138781431d-14, 1.1369488761077196511d-13, &
     1.1291168681618466716d-12, 1.0250757630526871007d-11, &
     8.4765287317253141514d-11, 6.2886627779402596211d-10, &
     4.1142865598366029316d-9, 2.3223773435632014408d-8, &
     1.0985095234166396934d-7, 4.1766260951820336228d-7, &
     1.1958609263543792991d-6, 2.2907574647671878055d-6, &
     2.2008253973114914005d-6 / 
  data (c(i), i = 120, 134) / &
     4.4863058691420695911d-17, 2.2437356594371819978d-16, &
     3.6107964803015652759d-15, 3.7031193629853392081d-14, &
     3.7341552790439784371d-13, 3.4355950129497564468d-12, &
     2.8719942600171304499d-11, 2.1499646844509516453d-10, &
     1.4171810843455227171d-9, 8.0501118772875784153d-9, &
     3.8281889106330295876d-8, 1.4621673458431979989d-7, &
     4.2029868696411098586d-7, 8.0785884122023473025d-7, &
     7.7845438614204963209d-7 / 
  data (d(i), i = 0, 7) / &
     -7.9737703860537066166d-14, 1.9543834380466766627d-12, &
     -4.7230794431646733538d-11, 1.4001773785771252004d-9, &
     -5.4864553020583098585d-8, 3.1601984250143742772d-6, &
     -3.3708783204090252161d-4, 1.6180215937964160437d-1 / 
  data (d(i), i = 8, 15) / &
     -5.2593898374798632343d-14, 1.7725913926973236457d-12, &
     -4.6672234858122387294d-11, 1.3991653503828889207d-9, &
     -5.4863400156413929639d-8, 3.1601976099900075541d-6, &
     -3.3708783171335864627d-4, 1.6180215937958433760d-1 / 
  data (d(i), i = 16, 23) / &
     -3.6135496189875398132d-14, 1.5466239429618130284d-12, &
     -4.5320259146602122624d-11, 1.3945974109459385552d-9, &
     -5.4853994841172088787d-8, 3.1601858228022739196d-6, &
     -3.3708782339998302320d-4, 1.6180215937704286491d-1 / 
  data (d(i), i = 24, 31) / &
     -2.5640663123518180635d-14, 1.3288079339404032671d-12, &
     -4.3368537955908371563d-11, 1.3848103653102203186d-9, &
     -5.4824335664256344123d-8, 3.1601315173126153586d-6, &
     -3.3708776779035695640d-4, 1.6180215935248373474d-1 / 
  data (d(i), i = 32, 39) / &
     -1.8678321325292127767d-14, 1.1354310934105733311d-12, &
     -4.1057197297998608931d-11, 1.3693990961296350970d-9, &
     -5.4762428935047089835d-8, 3.1599817092775027963d-6, &
     -3.3708756559715893599d-4, 1.6180215923508144240d-1 / 
  if (x .lt. 0.86d0) then
      t = x * x
      y = ((((((a(0) * t + a(1)) * t + &
         a(2)) * t + a(3)) * t + a(4)) * t + &
         a(5)) * t + a(6)) * t + a(7) 
      y = ((((((a(8) * t + a(9)) * t + &
         a(10)) * t + a(11)) * t + a(12)) * t + &
         a(13)) * t + a(14)) * t + a(15) - y * log(x) 
  else if (x .lt. 4.15d0) then
      t = x - 5 / x
      k = int(t + 5)
      t = (k - 4) - t
      k = k * 14
      y = ((((((((((((b(k) * t + b(k + 1)) * t + &
         b(k + 2)) * t + b(k + 3)) * t + b(k + 4)) * t + &
         b(k + 5)) * t + b(k + 6)) * t + b(k + 7)) * t + &
         b(k + 8)) * t + b(k + 9)) * t + b(k + 10)) * t + &
         b(k + 11)) * t + b(k + 12)) * t + b(k + 13)
  else if (x .lt. 12.5d0) then
      k = int(x)
      t = (k + 1) - x
      k = 15 * (k - 4)
      y = (((((((((((((c(k) * t + c(k + 1)) * t + &
         c(k + 2)) * t + c(k + 3)) * t + c(k + 4)) * t + &
         c(k + 5)) * t + c(k + 6)) * t + c(k + 7)) * t + &
         c(k + 8)) * t + c(k + 9)) * t + c(k + 10)) * t + &
         c(k + 11)) * t + c(k + 12)) * t + c(k + 13)) * t + &
         c(k + 14)
  else
      t = 60 / x
      k = 8 * (int(t))
      y = (((((((d(k) * t + d(k + 1)) * t + &
         d(k + 2)) * t + d(k + 3)) * t + d(k + 4)) * t + &
         d(k + 5)) * t + d(k + 6)) * t + d(k + 7)) * &
         sqrt(t) * exp(-x)
  end if
  bessk0 = y
end function bessk0
!===============================================================
function bessk1(x)
  use constants
  implicit none
  real(dp), intent(in) :: x
  real(dp) :: bessk1
  real(dp) :: a(0 : 15), b(0 : 119), c(0 : 119), d(0 : 39)
  real(dp) :: y,t,v
  integer :: i,k
  data (a(i), i = 0, 15) / &
     1.5151605362537935201d-13, 3.3637909513536510350d-11, &
     5.6514041131016827202d-9, 6.7816840255069534052d-7, &
     5.4253472222259226487d-5, 2.6041666666666637057d-3, &
     6.2500000000000000090d-2, 5.0000000000000000000d-1, &
     -8.9790303384748696588d-11, -1.4029047449249185771d-8,& 
     -1.5592893752540998113d-6, -1.1253607018469017569d-4, &
     -4.6421827665011579173d-3, -8.5370719728648409609d-2, &
     -3.0796575782920629660d-1, 1.0000000000000000004d0 / 
  data (b(i), i = 0, 14) / &
     -9.4055461896630579928d-12, 3.1307934665844664773d-11, &
     4.2005295001519243251d-10, -4.1636196779679820012d-9, &
     1.4483026181700966164d-8, 1.1661000205428816914d-8, &
     -3.5023996724943046209d-7, 1.4404279316339005012d-6, &
     5.3581564157158242080d-7, -3.5249754038612334639d-5, &
     1.7150324075631641453d-4, -4.1276362611239191024d-5, &
     -4.6943110979636602591d-3, 3.5085369853392357659d-2, &
     2.0063574339907819159d-1 / 
  data (b(i), i = 15, 29) / &
     3.3998989888944034586d-11, 7.1558979072937373055d-11, &
     -2.9226856932927698732d-9, 1.4591620256525610213d-8, &
     -6.6141635609854161666d-9, -1.9991101838984472332d-7, &
     5.9185836628873530572d-7, 1.9562880347358085687d-6, &
     -1.5814366450418102764d-5, 7.6791682910944612028d-6, &
     2.8354678948323983936d-4, -1.0217932669418690641d-3, &
     -3.2205661865210048433d-3, 4.3497494842354644077d-2, &
     1.6110284302315089935d-1 / 
  data (b(i), i = 30, 44) / &
     -2.0933987679665541827d-10, 7.9503322090520447316d-10, &
     3.8000150948242575774d-9, -2.3076136195585571309d-8, &
     -2.3902880302550799653d-8, 3.1914500937804377478d-7, &
     3.2639909831082417694d-7, -5.3166994792995439449d-6, &
     -3.1109524694269240094d-6, 9.2575906966353273247d-5, &
     7.5063709094147644746d-7, -1.7416491592625765379d-3, &
     1.2138560335171676007d-3, 4.5879687144659643175d-2, &
     1.1566544716132846709d-1 / 
  data (b(i), i = 45, 59) / &
     3.1582384905164908749d-10, -1.9959561818098999516d-9, &
     8.6959328920030927557d-10, 1.1642778282445577109d-8, &
     4.3552264337818440471d-8, -1.5057982160481803238d-7, &
     -1.0101729117980989857d-6, 7.7002002510177612013d-7, &
     1.9580574235590194233d-5, 1.9358461980242834361d-5, &
     -3.3932339942485532728d-4, -9.3416673584325090073d-4, &
     5.5800080455912847227d-3, 3.8668683062477179235d-2, &
     7.2651643500517000658d-2 / 
  data (b(i), i = 60, 74) / &
     -1.1554749629758510059d-10, 8.2270678758893273006d-10, &
     -5.0211156951551538591d-10, -1.4929179050554858361d-9, &
     -2.7107940791526366702d-8, -4.2204764086705349384d-8, &
     3.7253098167927628867d-7, 2.4374697215363361156d-6, &
     1.4141942006909768370d-6, -4.8766389019473918231d-5, &
     -2.1681387247526720978d-4, 2.9325729929653405236d-4, &
     6.4087534504827239815d-3, 2.6054628289709454356d-2, &
     4.0156431128194184336d-2 / 
  data (b(i), i = 75, 89) / &
     2.5506555170746221691d-11, -1.3521164018407978152d-10, &
     -8.3281235274106699399d-11, -9.7764849575562351891d-10, &
     3.4661828409940354542d-9, 3.9760633711791357544d-8, &
     1.5902906645504529930d-7, -1.4919441249454941275d-7, &
     -5.3779684992094351263d-6, -2.7513862296246223142d-5, &
     -9.7880089725297162007d-6, 7.0787668964515789714d-4, &
     4.6968199862345387583d-3, 1.4745740181663320127d-2, &
     2.0048622219583455723d-2 / 
  data (b(i), i = 90, 104) / &
     -3.4824483072529265585d-12, 1.5157161810563380451d-12, &
     8.5303859696700686144d-12, 3.3455414203743741076d-10, &
     2.0226016353844285376d-9, 5.3128154003266334990d-9, &
     -3.0799322316418042137d-8, -4.4455408272954712128d-7, &
     -2.4293274626893384034d-6, -3.2129079340119038354d-6, &
     5.9225403683075388850d-5, 5.6822962576781683532d-4, &
     2.7152446516406682732d-3, 7.4075873691848838485d-3, &
     9.3044450815739269849d-3 / 
  data (b(i), i = 105, 119) / &
     -2.7683216166276377232d-13, 3.1986676777610155465d-12, &
     9.4142986954031445666d-12, 6.7934609179456399334d-11, &
     3.4851529411470029330d-11, -2.5785248508896551557d-9, &
     -2.8310220027112571258d-8, -1.6384131113072271115d-7, &
     -3.2521663350596379097d-7, 4.0381388757622307160d-6, &
     5.1917606978077281001d-5, 3.3420027947470126154d-4, &
     1.3699550623118247094d-3, 3.4405619148342271096d-3, &
     4.1042919106665762794d-3 / 
  data (c(i), i = 0, 14) / &
     4.5281968025889407937d-12, 1.0806749918195271176d-11, &
     9.6200972728717669027d-11, 5.7214227063625263650d-10, &
     3.6077804282954825099d-9, 2.2465236858536681852d-8, &
     1.3676961264308735230d-7, 7.9561767489531997361d-7, &
     4.3014380065615550573d-6, 2.0921713905550285590d-5, &
     8.8079183950590176926d-5, 3.0549414408830252064d-4, &
     8.1295715613927890473d-4, 1.4679809476357079195d-3, &
     1.3439197177355090057d-3 / 
  data (c(i), i = 15, 29) / &
     7.6019964430402432637d-13, -2.2616198599158271190d-13, &
     1.7904450823779000744d-11, 9.1467054855312232717d-11, &
     7.1378582044879519122d-10, 4.9925255415445769102d-9, &
     3.3767315471315546644d-8, 2.1350774539167751457d-7, &
     1.2314353082655232903d-6, 6.2918685053670619181d-6, &
     2.7493229298777000013d-5, 9.8085825401369821771d-5, &
     2.6670282677770444935d-4, 4.8967895428135985381d-4, &
     4.5418248688489697144d-4 / 
  data (c(i), i = 30, 44) / &
     9.4180115230375147213d-14, 7.5943117003734061145d-14, &
     3.0335730243874287654d-12, 2.0202796115462268051d-11, &
     1.6839020189186971198d-10, 1.2907875663127201526d-9, &
     9.3547676125865798920d-9, 6.2471974110281880722d-8, &
     3.7585985422997380441d-7, 1.9838348288114906484d-6, &
     8.8884862203671982034d-6, 3.2333259238682810218d-5, &
     8.9266668913380400243d-5, 1.6589185669844051903d-4, &
     1.5536921180500113394d-4 / 
  data (c(i), i = 45, 59) / &
     1.5425475332301107271d-14, 2.8674534590132490434d-14, &
     6.5078462279160216936d-13, 5.0939757793961391211d-12, &
     4.4979837460748975520d-11, 3.6662925847520171711d-10, &
     2.7848878755089582413d-9, 1.9298120059339477820d-8, &
     1.1950323861976892013d-7, 6.4513432758147478287d-7, &
     2.9422095033982461936d-6, 1.0854433321174584937d-5, &
     3.0307433185818899481d-5, 5.6840981443065017850d-5, &
     5.3637016379451945253d-5 / 
  data (c(i), i = 60, 74) / &
     3.1077953698439839352d-15, 8.6899496170729520378d-15, &
     1.6258562067326054104d-13, 1.4104842571366761537d-12, &
     1.3019455544084110747d-11, 1.1070466372863950239d-10, &
     8.6890603844230597917d-10, 6.1793722175049967488d-9, &
     3.9058865943755615801d-8, 2.1432806981070368523d-7, &
     9.9034657762983230155d-7, 3.6925185861895664251d-6, &
     1.0399877577259449786d-5, 1.9644939661550210015d-5, &
     1.8648773453825584597d-5 / 
  data (c(i), i = 75, 89) / &
     7.2831555285336286457d-16, 2.6077534095895783532d-15, &
     4.4881202059263153495d-14, 4.1674329383944385626d-13, &
     3.9760100480223728037d-12, 3.4835976355351183010d-11, &
     2.7993254212770249700d-10, 2.0286513276830758107d-9, &
     1.3018343087118439152d-8, 7.2315927974997999365d-8, &
     3.3750708681924201599d-7, 1.2688020879407355571d-6, &
     3.5980954090811587848d-6, 6.8358260635246667316d-6, &
     6.5208606745808860557d-6 / 
  data (c(i), i = 90, 104) / &
     1.9026412343503745875d-16, 8.0073765508732553766d-16, &
     1.3245754278055523992d-14, 1.2885201653055058502d-13, &
     1.2600129301230402587d-12, 1.1283306843147549277d-11, &
     9.2261481309646814329d-11, 6.7812033168299846818d-10, &
     4.4020645304595102132d-9, 2.4685719238301517679d-8, &
     1.1611886719473112509d-7, 4.3940380936523135466d-7, &
     1.2529878285546791905d-6, 2.3917218527087570384d-6, &
     2.2907574647671878160d-6 / 
  data (c(i), i = 105, 119) / &
     5.3709522135744366512d-17, 2.5239221050372845433d-16, &
     4.0933147145899083360d-15, 4.1152784247617592367d-14, &
     4.0998840572769381012d-13, 3.7319354625807158852d-12, &
     3.0921671702920868014d-11, 2.2975898538634445343d-10, &
     1.5049754445782364328d-9, 8.5030864719789148982d-9, &
     4.0250559391118423810d-8, 1.5312755642491878591d-7, &
     4.3865020375297892208d-7, 8.4059737392822153101d-7, &
     8.0785884122023473319d-7 / 
  data (d(i), i = 0, 7) / &
     9.2371554649979581914d-14, -2.3111336195788410887d-12, &
     5.7728710326649832559d-11, -1.8002298130091372598d-9, &
     7.6810375010517145638d-8, -5.2669973752193823306d-6, &
     1.0112634961227401357d-3, 1.6180215937964160466d-1 / 
  data (d(i), i = 8, 15) / &
     6.1381146507252683381d-14, -2.1034499679806301862d-12, &
     5.7090233460448415278d-11, -1.7990724350642330817d-9, &
     7.6809056078388019946d-8, -5.2669964425290062357d-6, &
     1.0112634957478283390d-3, 1.6180215937970716383d-1 / 
  data (d(i), i = 16, 23) / &
     4.2458150578401296419d-14, -1.8435733128339016981d-12, &
     5.5534955081564656595d-11, -1.7938162188526358466d-9, &
     7.6798230945934117807d-8, -5.2669828728791921259d-6, &
     1.0112634861753356559d-3, 1.6180215938263409582d-1 / 
  data (d(i), i = 24, 31) / &
     3.0314798962267007518d-14, -1.5915009905364214455d-12, &
     5.3275907427402047438d-11, -1.7824862013841369751d-9, &
     7.6763890356447075810d-8, -5.2669199860465945909d-6, &
     1.0112634217687349189d-3, 1.6180215941108227283d-1 / 
  data (d(i), i = 32, 39) / &
     2.2211515002229271212d-14, -1.3664088221521734796d-12, &
     5.0585177270502341602d-11, -1.7645432205894533462d-9, &
     7.6691805594577373698d-8, -5.2667455286976269634d-6, &
     1.0112631862810974580d-3, 1.6180215954783127877d-1 / 
  if (x .lt. 0.8d0) then
      t = x * x
      y = (((((((a(0) * t + a(1)) * t + &
         a(2)) * t + a(3)) * t + a(4)) * t + &
         a(5)) * t + a(6)) * t + a(7)) * x
      y = (((((((a(8) * t + a(9)) * t + &
         a(10)) * t + a(11)) * t + a(12)) * t + &
         a(13)) * t + a(14)) * t + a(15)) / x + &
         y * log(x)
  else if (x .lt. 5.5d0) then
      v = 3 / x
      t = x - v
      k = int(t + 3)
      t = (k - 2) - t
      k = k * 15
      y = ((((((((((((((b(k) * t + b(k + 1)) * t + &
         b(k + 2)) * t + b(k + 3)) * t + b(k + 4)) * t + &
         b(k + 5)) * t + b(k + 6)) * t + b(k + 7)) * t + &
         b(k + 8)) * t + b(k + 9)) * t + b(k + 10)) * t + &
         b(k + 11)) * t + b(k + 12)) * t + b(k + 13)) * t + &
         b(k + 14)) * v
  else if (x .lt. 12.5d0) then
      k = int(x)
      t = (k + 1) - x
      k = 15 * (k - 5)
      y = (((((((((((((c(k) * t + c(k + 1)) * t + &
         c(k + 2)) * t + c(k + 3)) * t + c(k + 4)) * t + &
         c(k + 5)) * t + c(k + 6)) * t + c(k + 7)) * t + &
         c(k + 8)) * t + c(k + 9)) * t + c(k + 10)) * t + &
         c(k + 11)) * t + c(k + 12)) * t + c(k + 13)) * t + &
         c(k + 14)
  else
      t = 60 / x
      k = 8 * (int(t))
      y = (((((((d(k) * t + d(k + 1)) * t + &
         d(k + 2)) * t + d(k + 3)) * t + d(k + 4)) * t + &
         d(k + 5)) * t + d(k + 6)) * t + d(k + 7)) * &
         sqrt(t) * exp(-x)
  end if
  bessk1 = y
  return
end function bessk1
!===============================================================
!
!  Functions for the calculation of cosine and sine functions
!  rr must be of length 2.
!
!

subroutine cos_lm(rr,n,vec_in,vec_out)
  use constants
  implicit none

  real(dp), intent(in) :: rr(2)
  integer, intent(in) :: n
  real(dp), intent(in) :: vec_in(-n:n,0:n,2)
  real(dp), intent(out) :: vec_out(-n:n,0:n)
  real(dp) :: mult
  integer :: ll, mm

  do ll = -n, n
     do mm = 1, n
        mult = dot_product(rr,vec_in(ll,mm,:))
        vec_out(ll,mm) = cos(mult)
     enddo
  enddo

  do ll = 1, n
     mult = dot_product(rr,vec_in(ll,0,:))
     vec_out(ll,0) = cos(mult)
  enddo

  vec_out(0,0) = 0
  return

end subroutine cos_lm
!==============================================================

subroutine sin_lm(rr,n,vec_in,vec_out)
  use constants
  implicit none

  real(dp), intent(in) :: rr(2)
  integer, intent(in) :: n
  real(dp), intent(in) :: vec_in(-n:n,0:n,2)
  real(dp), intent(out) :: vec_out(-n:n,0:n)
  real(dp) :: mult
  integer :: ll, mm

  do ll = -n, n
     do mm = 1, n
        mult = dot_product(rr,vec_in(ll,mm,:))
        vec_out(ll,mm) = sin(mult)
     enddo
  enddo

  do ll = 1, n
     mult = dot_product(rr,vec_in(ll,0,:))
     vec_out(ll,0) = sin(mult)
  enddo

  vec_out(0,0) = 0
  return
 
end subroutine sin_lm




        !===============================================================
        !
        ! Subroutine to set the various clm coefficients. Separated so as
        ! to not clutter up the above code. calculates clm = (l-m)!/(l+m)! 
        ! for l = 0,lpole, m=0,l. 
        ! Evaluating these to 20 decimal places is certainly as accurate 
        ! as doing the calculations in the code but less work.
        !
        !---------------------------------------------------------------
        subroutine setclm(lpole, clm)
                use constants
                implicit none
                !
                ! Input/Output variables:
                !
                ! order of mutipole expansion
                integer, intent(in) :: lpole
                ! clm coefficients
                real(dp), dimension(0:lpole,0:lpole), intent(out) :: clm
                !---------------------------------------------------------------
                clm(0,0) = 1.00000000000000000000d+00

                if (lpole >= 1) then
                        clm(1,0) = 1.00000000000000000000d+00
                        clm(1,1) = 5.00000000000000000000d-01
                endif

                if (lpole >= 2) then
                        clm(2,0) = 1.00000000000000000000d+00
                        clm(2,1) = 1.66666666666666666670d-01
                        clm(2,2) = 4.16666666666666666670d-02
                endif

                if (lpole >= 3) then
                        clm(3,0) = 1.00000000000000000000d+00
                        clm(3,1) = 8.33333333333333333330d-02
                        clm(3,2) = 8.33333333333333333330d-03
                        clm(3,3) = 1.38888888888888888890d-03
                endif

                if (lpole >= 4) then
                        clm(4,0) = 1.00000000000000000000d+00
                        clm(4,1) = 5.00000000000000000000d-02
                        clm(4,2) = 2.77777777777777777780d-03
                        clm(4,3) = 1.98412698412698412700d-04
                        clm(4,4) = 2.48015873015873015870d-05
                endif

                if (lpole >= 5) then
                        clm(5,0) = 1.00000000000000000000d+00
                        clm(5,1) = 3.33333333333333333330d-02
                        clm(5,2) = 1.19047619047619047620d-03
                        clm(5,3) = 4.96031746031746031750d-05
                        clm(5,4) = 2.75573192239858906530d-06
                        clm(5,5) = 2.75573192239858906530d-07
                endif

                if (lpole >= 6) then
                        clm(6,0) = 1.00000000000000000000d+00
                        clm(6,1) = 2.38095238095238095240d-02
                        clm(6,2) = 5.95238095238095238100d-04
                        clm(6,3) = 1.65343915343915343920d-05
                        clm(6,4) = 5.51146384479717813050d-07
                        clm(6,5) = 2.50521083854417187750d-08
                        clm(6,6) = 2.08767569878680989790d-09
                endif

                if (lpole >= 7) then
                        clm(7,0) = 1.00000000000000000000d+00
                        clm(7,1) = 1.78571428571428571430d-02
                        clm(7,2) = 3.30687830687830687830d-04
                        clm(7,3) = 6.61375661375661375660d-06
                        clm(7,4) = 1.50312650312650312650d-07
                        clm(7,5) = 4.17535139757361979580d-09
                        clm(7,6) = 1.60590438368216145990d-10
                        clm(7,7) = 1.14707455977297247140d-11
                endif

                if (lpole >= 8) then
                        clm(8,0) = 1.00000000000000000000d+00
                        clm(8,1) = 1.38888888888888888890d-02
                        clm(8,2) = 1.98412698412698412700d-04
                        clm(8,3) = 3.00625300625300625300d-06
                        clm(8,4) = 5.01042167708834375500d-08
                        clm(8,5) = 9.63542630209296875960d-10
                        clm(8,6) = 2.29414911954594494280d-11
                        clm(8,7) = 7.64716373181981647590d-13
                        clm(8,8) = 4.77947733238738529740d-14
                endif

                if (lpole >= 9) then
                        clm(9,0) = 1.00000000000000000000d+00
                        clm(9,1) = 1.11111111111111111110d-02
                        clm(9,2) = 1.26262626262626262630d-04
                        clm(9,3) = 1.50312650312650312650d-06
                        clm(9,4) = 1.92708526041859375190d-08
                        clm(9,5) = 2.75297894345513393130d-10
                        clm(9,6) = 4.58829823909188988550d-12
                        clm(9,7) = 9.55895466477477059490d-14
                        clm(9,8) = 2.81145725434552076320d-15
                        clm(9,9) = 1.56192069685862264620d-16
                endif

                if (lpole >=10) then
                        write(9,*) "in setclm - lpole>9 What's wrong with you"
                endif
        end subroutine setclm

        !===============================================================


subroutine ylm_real(lp,rr,rnorm,ylm,ylmd)
! \TODO: AJB - HERE BE DRAGONS? ORDER OF m in 3 is wrong, one of the f terms is maybe wrong??
!
!  For an input point with cartesian coordinates rr(1:3),
!  calculate the real combination of spherical harmonics
!  ylm(1:2*lp-1) and their gradients, ylmd(1:3, 1:2*lp-1).
!
!---------------------------------------------------------------
  use constants
  implicit none 
  !
  !  Input variables:
  !
  integer, intent(in) :: lp ! l + 1, orbital quantum number
  real(dp), intent(in) :: rr(3),rnorm
  real(dp), intent(out) :: ylm(7),ylmd(3,7)
  !
  !  Work variables:
  !
  !  coordinate factors
  real(dp) :: xx, yy, zz, x2, y2, z2, xy, xz, yz, xyz, rinv, thrinv
  !
  !  Spherical harmonics coefficients - for s, p, and d
  !  formulae, see, e.g., pp. 11-12 in W. A. Harrison, "Electronic
  !  Structure and the Properties of Solids: The Physics of the
  !  Chemical Bond". For f formulae, see, e.g., 
  !  S. F. A. Kettle, "Physical Inorganic Chemistry", p. 244.
  !  Notice that they *have* the factor sqrt( (2*l+1)/4*pi ).
  !
  !  1/(2*sqrt(pi)) for s
  real(dp), parameter :: c0  = 0.282094791773878143474039725779d0
  !  sqrt(3/(4*pi)), for px, py, pz 
  real(dp), parameter :: c1  = 0.488602511902919921586384622837d0
  !  sqrt(15/(4*pi)), dxy, dzy, dzx 
  real(dp), parameter :: c21 = 1.092548430592079070543385705802d0
  !  sqrt(5/(16*pi)), for dz^2 
  real(dp), parameter :: c22 = 0.315391565252520006030893690294d0
  !  sqrt(7/(16*pi)), for f_z(5z^2-3r^2)
  real(dp), parameter :: c31 = 0.373176332590115391414395913197d0
  !  sqrt(21/(32*pi)), for f_x(5z^2-r^2),f_y(5z^2-r^2)
  real(dp), parameter :: c32 = 0.457045799464465736158020696916d0
  !  sqrt(105/(16*pi)), for f_z(x^2-y^2)
  real(dp), parameter :: c33 = 1.445305721320277027694690077198d0
  !  sqrt(105/(4*pi)), for f_xyz
  real(dp), parameter :: c34 = 2.890611442640554055389380154398d0
  !  sqrt(35/(32*pi)), for f_x(x^2-3y^2),f_y(y^2-3x^2)
  real(dp), parameter :: c35 = 0.590043589926643510345610277541d0

  !---------------------------------------------------------------

  ylm(:) = zero
  ylmd(:,:) = zero
  rinv = one/rnorm
  xx = rr(1) * rinv
  yy = rr(2) * rinv
  zz = rr(3) * rinv

  select case(lp)
  case (1)
     !
     !  l = 0 (lp = 1) , s orbital
     !
     ylm(1) = c0
  case (2)
     !
     !  l = 1 (lp = 2), p orbitals
     !
     !  --- px, py, pz
     ylm(1) = c1*xx
     ylm(2) = c1*yy
     ylm(3) = c1*zz
     !  --- derivatives of px,py,pz
     xy = -rinv*xx*yy
     xz = -rinv*xx*zz
     yz = -rinv*yy*zz

     ylmd(1,1) = c1*rinv*(one-xx*xx) 
     ylmd(2,1) = c1*xy
     ylmd(3,1) = c1*xz

     ylmd(1,2) = c1*xy
     ylmd(2,2) = c1*rinv*(one-yy*yy)
     ylmd(3,2) = c1*yz

     ylmd(1,3) = c1*xz
     ylmd(2,3) = c1*yz
     ylmd(3,3) = c1*rinv*(one-zz*zz)
  case (3)
     !
     !  l = 2 (lp = 3) , d orbitals
     !
     !  --- dxy, dyz, dxz, dz2, dx2-y2 
     ylm(1) = c21*xx*yy
     ylm(2) = c21*zz*yy
     ylm(3) = c21*xx*zz
     ylm(4) = c22*(three*zz*zz-one)
     ylm(5) = c21*half*(xx*xx-yy*yy)
     !  --- derivatives of dxy, dyz, dxz, dz2, dx2-y2 
     x2 = xx*xx
     y2 = yy*yy
     z2 = zz*zz
     xyz = -two*rinv*xx*yy*zz

     ylmd(1,1) = c21*rinv*yy*(one-two*x2) 
     ylmd(2,1) = c21*rinv*xx*(one-two*y2) 
     ylmd(3,1) = c21*xyz

     ylmd(1,2) = c21*xyz
     ylmd(2,2) = c21*rinv*zz*(one-two*y2) 
     ylmd(3,2) = c21*rinv*yy*(one-two*z2) 

     ylmd(1,3) = c21*rinv*zz*(one-two*x2) 
     ylmd(2,3) = c21*xyz
     ylmd(3,3) = c21*rinv*xx*(one-two*z2) 

     ylmd(1,4) = -c22*six*rinv*xx*z2 
     ylmd(2,4) = -c22*six*rinv*yy*z2 
     ylmd(3,4) =  c22*six*rinv*zz*(one-z2) 

     ylmd(1,5) =  c21*rinv*xx*(one-x2+y2) 
     ylmd(2,5) = -c21*rinv*yy*(one+x2-y2) 
     ylmd(3,5) = -c21*rinv*zz*(x2-y2) 
  case (4)
     !
     !  l = 3 (lp = 4) , f orbitals
     !
     !  --- fz(5z^2-3r^2), fx(5z^2-r^2), fy(5z^2-r^2),
     !      fz(x^2-y^2), fxyz, fx(x^2-3y^2), fy(y^2-3x^2)
     ylm(1) = c31*zz*(five*zz*zz-three)
     ylm(2) = c32*xx*(five*zz*zz-one)
     ylm(3) = c32*yy*(five*zz*zz-one)
     ylm(4) = c33*zz*(xx*xx-yy*yy)
     ylm(5) = c34*xx*yy*zz
     ylm(6) = c35*xx*(xx*xx-three*yy*yy)
     ylm(7) = c35*yy*(yy*yy-three*xx*xx)
     !  --- derivatives of the seven f orbitals
     x2 = xx*xx
     y2 = yy*yy
     z2 = zz*zz
     xy = rinv*xx*yy
     xz = rinv*xx*zz
     yz = rinv*yy*zz
     thrinv = three*rinv

     ylmd(1,1) = c31*three*xz*(one-five*z2)
     ylmd(2,1) = c31*three*yz*(one-five*z2)
     ylmd(3,1) = c31*thrinv*(z2-one)*(one-five*z2) 

     ylmd(1,2) = c32*rinv*(five*z2-one+x2*(one-15.d0*z2))
     ylmd(2,2) = c32*xy*(one-15.d0*z2)
     ylmd(3,2) = c32*xz*(11.d0-15.d0*z2)

     ylmd(1,3) = c32*xy*(one-15.d0*z2)
     ylmd(2,3) = c32*rinv*(five*z2-one+y2*(one-15.d0*z2))
     ylmd(3,3) = c32*yz*(11.d0-15.d0*z2)

     ylmd(1,4) =  c33*xz*(two-three*(x2-y2))
     ylmd(2,4) = -c33*yz*(two+three*(x2-y2))
     ylmd(3,4) =  c33*rinv*(one-three*z2)*(x2-y2)

     ylmd(1,5) = c34*yz*(one-three*x2)
     ylmd(2,5) = c34*xz*(one-three*y2)
     ylmd(3,5) = c34*xy*(one-three*z2)

     ylmd(1,6) = c35*thrinv*(x2-y2-x2*(x2-three*y2))
     ylmd(2,6) = c35*three*xy*(three*y2-x2-two)
     ylmd(3,6) = c35*three*xz*(three*y2-x2)

     ylmd(1,7) = c35*three*xy*(three*x2-y2-two)
     ylmd(2,7) = c35*thrinv*(y2-x2-y2*(y2-three*x2))
     ylmd(3,7) = c35*three*yz*(three*x2-y2)
  end select

end subroutine ylm_real
!===============================================================
subroutine ylm_cplx(lp,rr,rnorm,zylm,zylmd)
!
!  For an input point with cartesian coordinates rr(1:3),
!  calculate the real combination of spherical harmonics
!  ylm(1:2*lp-1) and their gradients, ylmd(1:3, 1:2*lp-1).
!
!---------------------------------------------------------------
  use constants
  implicit none
  !
  !  Input variables:
  !
  integer, intent(in) :: lp ! l + 1, orbital quantum number
  real(dp), intent(in) :: rr(3)
  real(dp), intent(in) :: rnorm
  complex(dpc), intent(out) :: zylm(5)
  complex(dpc), intent(out) :: zylmd(3,5)
  !
  !  Work variables:
  !
  !  coordinate factors
  real(dp) :: xx, yy, zz, x2, y2, z2, xy, xz, yz, xyz, rinv
  !
  !  Spherical harmonics coefficients - for s, p, and d
  !  formulae, see, e.g., pp. 11-12 in W. A. Harrison, "Electronic
  !  Structure and the Properties of Solids: The Physics of the
  !  Chemical Bond". For f formulae, see, e.g.,
  !  S. F. A. Kettle, "Physical Inorganic Chemistry", p. 244.
  !  Notice that they *have* the factor sqrt( (2*l+1)/4*pi ).
  !

  !  sqrt(3/(4*pi)), for Y10
  real(dp), parameter :: c10  = 0.488602511902919921586384622838d0
  !  sqrt(3/(8*pi)), for Y11
  real(dp), parameter :: c11 =  0.345494149471335479265244646031d0
  !  sqrt(5/(16*pi)), for Y20
  real(dp), parameter :: c20 =  0.315391565252520006030893690294d0
  !  sqrt(15/(8*pi)), for Y21
  real(dp), parameter :: c21 =  0.772548404046379160684385470622d0
  !  sqrt(15/(32*pi)), for Y22
  real(dp), parameter :: c22 =  0.386274202023189580342192735311d0

  !---------------------------------------------------------------

  zylm(:) = zzero
  zylmd(:,:) = zzero
  rinv = one/rnorm
  xx = rr(1) * rinv
  yy = rr(2) * rinv
  zz = rr(3) * rinv
  xy = xx*yy
  xz = xx*zz
  yz = yy*zz
  x2 = xx*xx
  y2 = yy*yy
  z2 = zz*zz
  xyz = two*xx*yy*zz
  select case(lp)
  case (1)
     !
     !  l = 1, p orbitals
     !
     !  --- Y1m
     zylm(1) = c11*cmplx(xx,-yy,dpc)  ! Y(1,-1)
     zylm(2) = c10*cmplx(zz,zero,dpc) ! Y(1, 0)
     zylm(3) = c11*cmplx(-xx,-yy,dpc) ! Y(1, 1)
     !  --- derivatives of Y1m

     zylmd(1,1) = c11*rinv*cmplx(one-xx*xx,-xy, dpc)
     zylmd(2,1) = c11*rinv*cmplx(xy,yy*yy-one, dpc)
     zylmd(3,1) = c11*rinv*cmplx(xz,-yz, dpc)

     zylmd(1,2) = c10*rinv*cmplx(xz,zero, dpc)
     zylmd(2,2) = c10*rinv*cmplx(yz,zero, dpc)
     zylmd(3,2) = c10*rinv*cmplx(one-zz*zz,zero, dpc)

     zylmd(1,3) = -conjg(zylmd(1,1))
     zylmd(2,3) = -conjg(zylmd(1,2))
     zylmd(3,3) = -conjg(zylmd(1,3))
  case (2)
     !
     !  l = 2 , d orbitals
     !
     !  --- Y2m

     zylm(1) = c22*cmplx(x2-y2,-two*xy, dpc)         ! Y(2,-2)
     zylm(2) = c21*cmplx(xz,-yz, dpc)                ! Y(2,-1)
     zylm(3) = c20*cmplx(three*z2-one,zero, dpc)     ! Y(2. 0)
     zylm(4) = c21*cmplx(-xz,-yz, dpc)               ! Y(2, 1)
     zylm(5) = c22*cmplx(x2-y2,two*xy, dpc)          ! Y(2, 2)

     !  --- derivatives of Y2m

     zylmd(1,1) = c22*rinv*two*cmplx(xx*(two*y2+z2),yy*(x2-y2-z2), dpc)
     zylmd(2,1) = c22*rinv*two*cmplx(-yy*(two*x2+z2),-xx*(x2-y2+z2), dpc)
     zylmd(3,1) = c22*rinv*two*cmplx(-zz*(x2-y2),xyz, dpc)

     zylmd(1,2) = c21*rinv*cmplx(zz*(x2-y2-z2),xyz, dpc)
     zylmd(2,2) = c21*rinv*cmplx(xyz,-zz*(x2-y2+z2), dpc)
     zylmd(3,2) = c21*rinv*cmplx(-xx*(x2+y2-z2),-yy*(x2+y2-z2), dpc)

     zylmd(1,3) = c20*rinv*cmplx(-six*xx*z2,zero, dpc)
     zylmd(2,3) = c20*rinv*cmplx(-six*yy*z2,zero, dpc)
     zylmd(3,3) = c20*rinv*cmplx(six*zz*(x2+y2),zero, dpc)

     zylmd(1,4) = -conjg(zylmd(1,2))
     zylmd(2,4) = -conjg(zylmd(2,2))
     zylmd(3,4) = -conjg(zylmd(3,2))

     zylmd(1,5) = conjg(zylmd(1,1))
     zylmd(2,5) = conjg(zylmd(2,1))
     zylmd(3,5) = conjg(zylmd(3,1))

  end select

end subroutine ylm_cplx
!===============================================================


!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Complementary error function erfc = 1 - erf
! http://www.kurims.kyoto-u.ac.jp/~ooura/gamerf.html
! error function in double precision.
!
!---------------------------------------------------------------
function my_erfc(x)

use constants
implicit none
!
!  Input/Output variables:
!
real(dp), intent(in) :: x
real(dp) :: my_erfc
!
!  Work variables:
!
integer :: k, i
real(dp) :: t, w, y
real(dp) :: a(0 : 64), b(0 : 64)
data (a(i), i = 0, 12) / &
        0.00000000005958930743d0, -0.00000000113739022964d0, &
        0.00000001466005199839d0, -0.00000016350354461960d0, &
        0.00000164610044809620d0, -0.00001492559551950604d0, &
        0.00012055331122299265d0, -0.00085483269811296660d0, &
        0.00522397762482322257d0, -0.02686617064507733420d0, &
        0.11283791670954881569d0, -0.37612638903183748117d0, &
        1.12837916709551257377d0 / 
data (a(i), i = 13, 25) / &
        0.00000000002372510631d0, -0.00000000045493253732d0, &
        0.00000000590362766598d0, -0.00000006642090827576d0, &
        0.00000067595634268133d0, -0.00000621188515924000d0, &
        0.00005103883009709690d0, -0.00037015410692956173d0, &
        0.00233307631218880978d0, -0.01254988477182192210d0, &
        0.05657061146827041994d0, -0.21379664776456006580d0, &
        0.84270079294971486929d0 / 
data (a(i), i = 26, 38) / &
        0.00000000000949905026d0, -0.00000000018310229805d0, &
        0.00000000239463074000d0, -0.00000002721444369609d0, &
        0.00000028045522331686d0, -0.00000261830022482897d0, &
        0.00002195455056768781d0, -0.00016358986921372656d0, &
        0.00107052153564110318d0, -0.00608284718113590151d0, &
        0.02986978465246258244d0, -0.13055593046562267625d0, &
        0.67493323603965504676d0 / 
data (a(i), i = 39, 51) / &
        0.00000000000382722073d0, -0.00000000007421598602d0, &
        0.00000000097930574080d0, -0.00000001126008898854d0, &
        0.00000011775134830784d0, -0.00000111992758382650d0, &
        0.00000962023443095201d0, -0.00007404402135070773d0, &
        0.00050689993654144881d0, -0.00307553051439272889d0, &
        0.01668977892553165586d0, -0.08548534594781312114d0, &
        0.56909076642393639985d0 / 
data (a(i), i = 52, 64) / &
        0.00000000000155296588d0, -0.00000000003032205868d0, &
        0.00000000040424830707d0, -0.00000000471135111493d0, &
        0.00000005011915876293d0, -0.00000048722516178974d0, &
        0.00000430683284629395d0, -0.00003445026145385764d0, &
        0.00024879276133931664d0, -0.00162940941748079288d0, &
        0.00988786373932350462d0, -0.05962426839442303805d0, &
        0.49766113250947636708d0 / 
data (b(i), i = 0, 12) / &
        -0.00000000029734388465d0, 0.00000000269776334046d0, &
        -0.00000000640788827665d0, -0.00000001667820132100d0, &
        -0.00000021854388148686d0, 0.00000266246030457984d0, &
        0.00001612722157047886d0, -0.00025616361025506629d0, &
        0.00015380842432375365d0, 0.00815533022524927908d0, &
        -0.01402283663896319337d0, -0.19746892495383021487d0, &
        0.71511720328842845913d0 / 
data (b(i), i = 13, 25) / &
        -0.00000000001951073787d0, -0.00000000032302692214d0, &
        0.00000000522461866919d0, 0.00000000342940918551d0, &
        -0.00000035772874310272d0, 0.00000019999935792654d0, &
        0.00002687044575042908d0, -0.00011843240273775776d0, &
        -0.00080991728956032271d0, 0.00661062970502241174d0, &
        0.00909530922354827295d0, -0.20160072778491013140d0, &
        0.51169696718727644908d0 / 
data (b(i), i = 26, 38) / &
        0.00000000003147682272d0, -0.00000000048465972408d0, &
        0.00000000063675740242d0, 0.00000003377623323271d0, &
        -0.00000015451139637086d0, -0.00000203340624738438d0, &
        0.00001947204525295057d0, 0.00002854147231653228d0, &
        -0.00101565063152200272d0, 0.00271187003520095655d0, &
        0.02328095035422810727d0, -0.16725021123116877197d0, &
        0.32490054966649436974d0 / 
data (b(i), i = 39, 51) / &
        0.00000000002319363370d0, -0.00000000006303206648d0, &
        -0.00000000264888267434d0, 0.00000002050708040581d0, &
        0.00000011371857327578d0, -0.00000211211337219663d0, &
        0.00000368797328322935d0, 0.00009823686253424796d0, &
        -0.00065860243990455368d0, -0.00075285814895230877d0, &
        0.02585434424202960464d0, -0.11637092784486193258d0, &
        0.18267336775296612024d0 / 
data (b(i), i = 52, 64) / &
        -0.00000000000367789363d0, 0.00000000020876046746d0, &
        -0.00000000193319027226d0, -0.00000000435953392472d0, &
        0.00000018006992266137d0, -0.00000078441223763969d0, &
        -0.00000675407647949153d0, 0.00008428418334440096d0, &
        -0.00017604388937031815d0, -0.00239729611435071610d0, &
        0.02064129023876022970d0, -0.06905562880005864105d0, &
        0.09084526782065478489d0 / 

! ---------------------------------------------------------------

w = abs(x)

if (w < 2.2d0) then
        t = w * w
        k = int(t)
        t = t - k
        k = k * 13
        y = ((((((((((((a(k) * t + a(k + 1)) * t +  &
                a(k + 2)) * t + a(k + 3)) * t + a(k + 4)) * t +  &
                a(k + 5)) * t + a(k + 6)) * t + a(k + 7)) * t +  &
                a(k + 8)) * t + a(k + 9)) * t + a(k + 10)) * t +  &
                a(k + 11)) * t + a(k + 12)) * w
elseif (w < 6.9d0) then
        k = int(w)
        t = w - k
        k = 13 * (k - 2)
        y = (((((((((((b(k) * t + b(k + 1)) * t +  &
                b(k + 2)) * t + b(k + 3)) * t + b(k + 4)) * t +  &
                b(k + 5)) * t + b(k + 6)) * t + b(k + 7)) * t +  &
                b(k + 8)) * t + b(k + 9)) * t + b(k + 10)) * t +  &
                b(k + 11)) * t + b(k + 12)
        y = y * y
        y = y * y
        y = y * y
        y = 1 - y * y
else
        y = 1
endif

if (x < 0) y = -y

my_erfc = 1 - y

end function my_erfc


!===================================================================


function my_erf(x)
use constants
implicit none
real(dp), intent(in) :: x
real(dp) :: my_erf

my_erf = 1 - my_erfc(x)

end function my_erf

!===================================================================

subroutine fplus(vecsize,zdiff,eta,output)
use constants
implicit none

real(dp), intent(in) :: vecsize
real(dp), intent(in) :: zdiff
real(dp), intent(in) :: eta
real(dp), intent(out) :: output

real(dp) :: mult     ! mult = vecsize*zdiff
real(dp) :: etasqr   ! etasqr = 2*(eta**2)
real(dp) :: inveta   ! inveta = 1/(2*eta)

mult = vecsize * zdiff
etasqr = 2*(eta**2)
inveta = 0.5d0 / eta

output = exp(-mult) * my_erfc(inveta*(vecsize - etasqr*zdiff)) + &
         exp(mult)  * my_erfc(inveta*(vecsize + etasqr*zdiff))

!if(ISNAN(output)) output=0

return
end subroutine fplus


!==================================================================


subroutine fminus(vecsize,zdiff,eta,output)
use constants
implicit none

real(dp), intent(in) :: vecsize
real(dp), intent(in) :: zdiff
real(dp), intent(in) :: eta
real(dp), intent(out) :: output

real(dp) :: mult     ! mult = vecsize*zdiff
real(dp) :: etasqr   ! etasqr = 2*(eta**2)
real(dp) :: inveta   ! inveta = 1/(2*eta)

mult = vecsize * zdiff
etasqr = 2*(eta**2)
inveta = 0.5d0 / eta

output = exp(-mult) * my_erfc(inveta*(vecsize - etasqr*zdiff)) - &
         exp(mult)  * my_erfc(inveta*(vecsize + etasqr*zdiff))

!if(ISNAN(output)) output=0.0

return
end subroutine fminus


!===============================================================
!
!  Computes the exponential integral E1(x), for x > 0
!
!  (C) Copr. 1986-92 Numerical Recipes Software #0).
!
!---------------------------------------------------------------------
function expint(x,ierr)

  use constants
  implicit none
  !
  !  Input/Output variables:
  !
  real(dp), intent(in) :: x
  real(dp) :: expint
  integer, intent(out) :: ierr
  !
  !  Work variables:
  !
  !  constants:
  integer, parameter :: maxit = 1000000
  real(dp), parameter :: eps = 1.d-20, fpmin = 1.d-39
  real(dp), parameter :: euler = 0.57721566490153286d0

  ! counters
  integer :: jj
  real(dp) :: del, fact
  !---------------------------------------------------------------------
  ierr = 0
  if (x <= zero ) then
     write(9,*) 'ERROR: bad arguments in expint'
     expint = zero
     ierr = 1
     goto 10
  else
     expint = -log(x) - euler
     fact = one
     do jj = 1, maxit
        fact = -fact*x/real(jj,dp)
        del = -fact/real(jj,dp)
        expint = expint + del
        if (abs(del) < abs(expint)*eps) goto 10
     enddo
     write(9,*) 'ERROR: series failed in expint'
     ierr = 2
  endif
10 continue

end function expint





!=====================================================================
!
! Inverts 3x3 matrix m corresponding to a symmetry operation,
! storing the result in m. It also calculates determinant and
! trace of the input matrix. Matrix inversion is aborted if
! det<del.
!
!---------------------------------------------------------------
subroutine mtrxin(m, det, tr)
        use constants
        implicit none
        !
        ! Input/Output variables:
        !
        real(dp), dimension(3,3), intent(inout) :: m
        real(dp), intent(out) :: det
        real(dp), intent(out) :: tr
        !
        ! Work variables:
        !
        real(dp), dimension(3,3) :: a
        real(dp) :: del, x
        integer :: i, j
        !---------------------------------------------------------------
        !
        ! compute matrix of cofactors
        !
        a(1,1) =  m(2,2)*m(3,3) - m(2,3)*m(3,2)
        a(2,1) = -m(2,1)*m(3,3) + m(2,3)*m(3,1)
        a(3,1) =  m(2,1)*m(3,2) - m(2,2)*m(3,1)
        a(1,2) = -m(1,2)*m(3,3) + m(1,3)*m(3,2)
        a(2,2) =  m(1,1)*m(3,3) - m(1,3)*m(3,1)
        a(3,2) = -m(1,1)*m(3,2) + m(1,2)*m(3,1)
        a(1,3) =  m(1,2)*m(2,3) - m(1,3)*m(2,2)
        a(2,3) = -m(1,1)*m(2,3) + m(1,3)*m(2,1)
        a(3,3) =  m(1,1)*m(2,2) - m(1,2)*m(2,1)
        !
        ! compute determinant
        !
        det = m(1,1)*a(1,1) + m(1,2)*a(2,1) + m(1,3)*a(3,1)
        tr = m(1,1) + m(2,2) + m(3,3)
        del = 1.0d-05
        ! \todo AJB: need to quit parsec via exit_err, not like this!
        if (abs(det) < del) then 
                write (*,*) "mtrxin problem!"
                call myflush(6) 
                stop 501
        endif
        !
        ! form mi
        !
        do i = 1, 3
        do j = 1, 3
                x = a(i,j)/det
                m(i,j) = x
        enddo
        enddo
end subroutine mtrxin







!===============================================================
!
! For an input function vql in reciprocal space, perform Fourier
! filtering and calculate fint at a given point in real space
! according to:
!
! fint = int_0^infty vql(q) * F_filter(q) * J(ll,q*r) dq
!
! with F_filter(q) = 1                                  q < q0 
!                  = exp( -beta1 * (q/q0 - 1)^2 )       q > q0
! q0 = alpha*pi/h
!
! The filter function was proposed by Briggs et al., PRB 54,
! 14362 (1996). Input function vql is tabulated on a regular grid
! with nql points and spacing delql. First value vql(1) corresponds
! to q = 0.
!
!---------------------------------------------------------------
function fint(r,nql,delql,vql,ll,alpha,beta1,h)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  ! radial position at which vr is to be calculated
  real(dp), intent(in) :: r
  ! number of reciprocal space points
  integer, intent(in) :: nql
  ! grid spacing
  real(dp), intent(in) :: delql
  ! input function in reciprocal space
  real(dp), intent(in) :: vql(nql)
  ! order of Bessel function
  integer, intent(in) :: ll
  ! parameters for filter function
  real(dp), intent(in) :: alpha, beta1, h
  ! filtered function
  real(dp) :: fint
  !
  ! Work variables:
  !
  ! counters
  integer :: ii, nfilter
  real(dp) :: xx, ff, q0d, qq0, qq0max, fsum
  ! integrand in Newton-Cottes integration
  real(dp), dimension(nql) :: y

  y = zero
  q0d = alpha*pi/h/delql
  nfilter = int( q0d ) + 1
  if (beta1 > zero) then
     qq0max = sqrt(10.d0/beta1) + one
  else
     qq0max = one
  endif

  do ii = 1, nfilter
     xx = r * delql * real(ii-1,dp)
     y(ii) = vql(ii)*besselj(ll,xx)
  enddo

  do ii = nfilter + 1, nql
     qq0 = real(ii-1,dp) / q0d
     if (qq0 > qq0max) exit
     ff = exp( - beta1 * (qq0 - 1) * (qq0 - 1) )
     xx = r * delql * real(ii-1,dp)
     y(ii) = vql(ii)*besselj(ll,xx)*ff
  enddo

  fsum = zero
  do ii = 1, nql-4, 4
     fsum = fsum + 7.0_dp*y(ii) + 32.0_dp*y(ii+1) + &
          12.0_dp*y(ii+2) + 32.0_dp*y(ii+3) + 7.0_dp*y(ii+4)
  enddo
  fint = fsum * delql * two / five / nine

end function fint
!===============================================================
!
! Similar to fint, but calculates the derivative of fint,
! dfint = (d/dr) fint(r).
!
!---------------------------------------------------------------
function dfint(r,nql,delql,vql,ll,alpha,beta1,h)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  ! radial position at which vr is to be calculated
  real(dp), intent(in) :: r
  ! number of reciprocal space points
  integer, intent(in) :: nql
  ! grid spacing
  real(dp), intent(in) :: delql
  ! input function in reciprocal space
  real(dp), intent(in) :: vql(nql)
  ! order of Bessel function
  integer, intent(in) :: ll
  ! parameters for filter function
  real(dp), intent(in) :: alpha, beta1, h
  ! derivative of filtered function
  real(dp) :: dfint
  !
  ! Work variables:
  !
  ! counters
  integer :: ii, nfilter
  real(dp) :: xx, ff, q0d, qq0, qq0max, dbessel, fsum
  ! integrand in Newton-Cottes integration
  real(dp), dimension(nql) :: y

  y = zero
  q0d = alpha*pi/h/delql
  nfilter = int( q0d ) + 1
  if (beta1 > zero) then
     qq0max = sqrt(10.d0/beta1) + one
  else
     qq0max = one
  endif

  do ii = 2, nfilter
     xx = r * delql * real(ii-1,dp)
     dbessel = real(ll,dp)*besselj(ll,xx)/xx - besselj(ll+1,xx)
     y(ii) = vql(ii)*dbessel*delql * real(ii-1,dp)
  enddo

  do ii = nfilter + 1, nql
     qq0 = real(ii-1,dp) / q0d
     if (qq0 > qq0max) exit
     ff = exp( - beta1 * (qq0 - 1) * (qq0 - 1) )
     xx = r * delql * real(ii-1,dp)
     dbessel = real(ll,dp)*besselj(ll,xx)/xx - besselj(ll+1,xx)
     y(ii) = vql(ii)*dbessel*delql * real(ii-1,dp)*ff
  enddo

  fsum = zero
  do ii = 1, nql-4, 4
     fsum = fsum + 7.0_dp*y(ii) + 32.0_dp*y(ii+1) + &
          12.0_dp*y(ii+2) + 32.0_dp*y(ii+3) + 7.0_dp*y(ii+4)
  enddo
  dfint = fsum * delql * two / five / nine

end function dfint




!===============================================================
!
! Spherical Bessel function of the first kind.
!
!---------------------------------------------------------------
function besselj(l, x)
#ifdef IS_GCC
#else
!$omp declare simd(besselj) uniform(l)
#endif

use constants
implicit none

! Input/Output variables:

! argument
real(dp), intent(in) :: x

! order
integer, intent(in) :: l

! function value
real(dp) :: besselj


! Work variables:

integer :: j
real(dp) :: x2, sb0, sb1, by, bym, byp, ux
real(dp), parameter :: ten = 10.0d0, fourtn = 14.0d0, tol=0.001d0

! ---------------------------------------------------------------

if (abs(x) > tol) then
        sb0 = sin(x)/x
else
        x2 = x*x/two
        sb0 = one - (x2/three)*(one - x2/ten)
endif

if (l == 0) then
        besselj = sb0
else
        if (abs(x) > tol) then
                sb1 = (sin(x)/x - cos(x)) / x
        else
                x2 = x*x/two
                sb1 = (x/three)*(one - (x2/five)*(one - x2/fourtn))
        endif

        if (l == 1) then
                besselj = sb1
        elseif (x < twomach_eps) then
                besselj = zero
        else
                by = sb1
                bym = sb0
                ux = one / x

                do j = 1, l-1
                        byp = real(2*j+1,dp)*ux*by - bym
                        bym = by
                        by = byp
                enddo

                besselj = by
        endif
endif

end function besselj




        !===============================================================
        !
        !  Gets the date (day-month-year) and time, with time zone. It
        !  also returns the wall-clock time in absolute seconds.
        !
        !---------------------------------------------------------------
        subroutine custom_date_time(datelabel, wallclock)
                use constants
                implicit none
                !
                !  Input/Output variables:
                !
                character(len=26), intent(out) :: datelabel
                real(dp), intent(out) :: wallclock
                !
                !  Work variables:
                !
                integer, dimension(8) :: values
                integer :: lmonth
                integer, dimension(8) :: idate
                character(len=11) :: bdate
                character(len=14) :: btime
                character(len=10) :: atime
                character(len=8) :: adate
                character(len=5) :: azone
                character(len=4) :: year
                character(len=2) :: day
                character(len=2) :: hour,min,sec
                character(len=3), dimension(12), parameter :: &
                        month = (/'JAN','FEB','MAR', 'APR','MAY','JUN', &
                        'JUL','AUG','SEP','OCT','NOV','DEC'/)
                character(len=1), parameter ::  dash = '-'
                !---------------------------------------------------------------
                call date_and_time(adate,atime,azone,idate)
                read(adate,'(a4,i2,a2)') year,lmonth,day
                write(bdate,'(a2,a1,a3,a1,a4)') day,dash,month(lmonth),dash,year
                read(atime,'(a2,a2,a2,a4)') hour,min,sec
                write(btime,'(a2,a1,a2,a1,a2,a1,a5)') hour,':',min,':',sec,' ',azone
                write(datelabel,'(a,1x,a)') bdate,btime

                call date_and_time(values=values)
                wallclock = ((values(3)*24.0d0+values(5))*60.0d0+values(6))* &
                        60.0d0+values(7)+values(8)*0.001d0
        end subroutine custom_date_time

        !===============================================================



integer function c_locate_part(myblock, nnodes, cirows, iam)

implicit none

integer, intent(in) :: myblock, iam, nnodes
integer, dimension(0:nnodes), intent(in) :: cirows
integer :: inode

!---------------------------------------------------------------

c_locate_part = iam

do inode = 0, nnodes-1
        if (cirows(inode) <= myblock .and. myblock < cirows(inode+1)) then
                c_locate_part = inode
                exit
        endif
enddo

end function c_locate_part



end module aux
