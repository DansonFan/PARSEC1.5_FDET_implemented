module gradmvs_module

implicit none
contains

!===============================================================
!
!  Distributed Gradient operator. This subroutine receives as
!  input a distributed function over the grid (array func) and
!  operates the Gradient over it, using finite differences.
!
!  WARNING: input function is assumed to have the full symmetry
!  of the system, so there are no representation characters (cf.
!  subroutine matvec).
!
!---------------------------------------------------------------
subroutine gradmvs(grid, parallel, func, gradf, coeke, norder, vec)

use grid_module
use parallel_data_module
use dbuffer_module
use constants
use aux, only : matvec3
use external_interfaces, only : dcopy

implicit none

#ifdef ITAC
include 'VT.inc'
include 'vtcommon.inc'
#endif

!
!  Input/Output variables:
!
!  grid related data
type(grid_data), intent(in) :: grid

!  parallel computation related data
type(parallel_data), intent(in) :: parallel

!  order of finite-difference expansion
integer, intent(in) :: norder

!  finite-difference coefficients for a first derivative
real(dp), dimension(-norder:norder,3), intent(in) :: coeke

!  input function
real(dp), dimension(parallel%mydim), intent(in) :: func

!  output gradient, gradf(:,i) = Gradient [ func(i) ]
real(dp), dimension(3,parallel%mydim), intent(out) :: gradf

!  work array
real(dp), dimension(parallel%myworkdim+1), intent(out) :: vec

!
!  Work variables:
!

type(lap_buffer) :: rho_lap_buffer

!  local scalars
integer :: i, ish, irow
!integer :: ioffset
integer :: kk

!  maxdim = maximum number of rows handled by each proc
!  needed for MPI communication inside bdxc_as
!integer :: maxdim
real(dp), dimension(3) :: tmpvec

!  work variable for extra directions
integer :: lap_dir_nump6

#ifdef ITAC
integer :: gradmverr
call VTBEGIN(vt_grad , gradmverr)
#endif

!---------------------------------------------------------------

if (parallel%nprow > 1) then
        !AJB: Using the same coomunication pattern that the laplacian has
        call init_lap_buffer(rho_lap_buffer)
        call allocate_lap_buffer(rho_lap_buffer, parallel)
        call dbuff_lap_pack(parallel, rho_lap_buffer, func, 1, 1, 1, &
                parallel%mydim)
        call dbuff_lap_comm(parallel, rho_lap_buffer)
endif

  ! maxdim = 0
  ! do i = 0, parallel%group_size - 1
  !    irow = parallel%irows(i+1)-parallel%irows(i)
  !    if (irow > maxdim) maxdim = irow
  ! enddo

  ! !  Global dimension and local rows' offset
  ! ioffset = parallel%irows(parallel%group_iam) - 1
  ! !
  ! !  Initiate the boundary exchange information
  ! !
call dcopy(parallel%mydim, func(:), 1, vec(:), 1)
! #ifdef MPI
  ! call bdxc_as( vec, maxdim, parallel%nwedge, parallel%irecvp, &
  !      parallel%jsendp,parallel%senrows, parallel%group_comm, &
  !      parallel%group_size, parallel%group_iam)
! #endif
  !
  !  Set wave function outside the domain be zero.
  !  The index for points outside the domain is ndim+1.
  !
gradf(:,:) = zero
vec(parallel%myworkdim+1) = zero 

!==============OMP PARALLEL CONSTRUCT================!
!$OMP PARALLEL 

!$OMP MASTER
if (parallel%nprow > 1) then
        call buff_lap_check_comm(rho_lap_buffer, 1)
        call dbuffer_lap_unpack(parallel, vec(:), rho_lap_buffer)
endif
!$OMP END MASTER
!$OMP BARRIER



!
!  Finite difference.
!  non-orthogonal grid: works?
if (grid%lap_dir_num > 0) then
     lap_dir_nump6 = 6 + grid%lap_dir_num * 2
!$OMP DO &
!$OMP& SCHEDULE(RUNTIME) &
!$OMP& PRIVATE(i,tmpvec,irow,kk,ish)
     do i = 1,parallel%mydim
        tmpvec = 0
        irow = parallel%pint(i)
        kk = 0
        do ish = 1,norder
           tmpvec(1) = tmpvec(1) + &
              coeke(ish,1)*(vec( parallel%neibs(kk+2,irow) ) - &
                            vec( parallel%neibs(kk+1,irow) ))
           tmpvec(2) = tmpvec(2) + &
              coeke(ish,2)*(vec( parallel%neibs(kk+4,irow) ) - &
                            vec( parallel%neibs(kk+3,irow) ))
           tmpvec(3) = tmpvec(3) + &
              coeke(ish,3)*(vec( parallel%neibs(kk+6,irow) ) - &
                            vec( parallel%neibs(kk+5,irow) ))
           kk = kk + lap_dir_nump6
        enddo
        call matvec3('N',grid%grad_bvec_norm,tmpvec,gradf(1,irow))
     enddo
!$OMP END DO

else

        ! orthogonal grid
        !$OMP DO &
        !$OMP& SCHEDULE(RUNTIME) &
        !$OMP& PRIVATE(i,tmpvec,irow,kk,ish)
        do i = 1,parallel%mydim
                tmpvec = 0
                irow = parallel%pint(i)
                kk = 0

                do ish = 1, norder
                        tmpvec(1) = tmpvec(1) + &
                                coeke(ish,1)*(vec( parallel%neibs(kk+2,irow) ) - &
                                              vec( parallel%neibs(kk+1,irow) ))
                        tmpvec(2) = tmpvec(2) + &
                                coeke(ish,2)*(vec( parallel%neibs(kk+4,irow) ) - &
                                              vec( parallel%neibs(kk+3,irow) ))
                        tmpvec(3) = tmpvec(3) + &
                                coeke(ish,3)*(vec( parallel%neibs(kk+6,irow) ) - &
                                              vec( parallel%neibs(kk+5,irow) ))
                        kk = kk + 6
                enddo

                gradf(1:3,irow) = tmpvec(:)
        enddo
        !$OMP END DO

endif
!$OMP END PARALLEL 

if (parallel%nprow > 1) then
        call destroy_lap_buffer(rho_lap_buffer)
endif

#ifdef ITAC
call VTEND(vt_grad , gradmverr)
#endif

end subroutine gradmvs

end module gradmvs_module
! legacy code follows
!{{{
! subroutine old_gradmvs(grid,parallel, func, gradf, coeke, norder, vec) !{{{

!   use grid_module
!   use parallel_data_module

!   use constants
! #ifdef MPI
!   !  include mpi definitions
!   use mpi_f08
! #endif
!   implicit none
!   !
!   !  Input/Output variables:
!   !
!   !  grid related data
!   type (grid_data), intent(in) :: grid
!   !  parallel computation related data
!   type (parallel_data), intent(in) :: parallel
!   !  order of finite-difference expansion
!   integer, intent(in) :: norder
!   !  finite-difference coefficients for a first derivative
!   real(dp), intent(in) :: coeke(-norder:norder,3)
!   !  input function
!   real(dp), intent(in) :: func(parallel%mydim)
!   !  output gradient, gradf(:,i) = Gradient [ func(i) ]
!   real(dp), intent(out) :: gradf(3,parallel%mydim)
!   !  work array
!   real(dp), intent(out) :: vec(parallel%nwedge+1)
!   !
!   !  Work variables:
!   !
!   !  local scalars
!   integer i, ish, irow,  ioffset, kk
!   !  maxdim = maximum number of rows handled by each proc
!   !  needed for MPI communication inside bdxc_as
!   integer maxdim
!   real(dp), dimension(3) :: tmpvec
!   !  work variable for extra directions
!   integer :: lap_dir_nump6

!   !---------------------------------------------------------------

!   maxdim = 0
!   do i = 0, parallel%group_size - 1
!      irow = parallel%irows(i+1)-parallel%irows(i)
!      if (irow > maxdim) maxdim = irow
!   enddo

!   !  Global dimension and local rows' offset
!   ioffset = parallel%irows(parallel%group_iam) - 1
!   !
!   !  Initiate the boundary exchange information
!   !
!   call dcopy(parallel%mydim,func,1,vec,1)
!   ! this sends too many neighbors - since it expects the laplacian operator
! #ifdef MPI
!   call bdxc_as( vec, maxdim, parallel%nwedge, parallel%irecvp, &
!        parallel%jsendp,parallel%senrows, parallel%group_comm, &
!        parallel%group_size, parallel%group_iam)
! #endif
!   !
!   !  Set wave function outside the domain be zero.
!   !  The index for points outside the domain is ndim+1.
!   !
!   vec(parallel%nwedge+1) = zero 
!   !
!   !  Finite difference.
!   !
!   gradf(:,:) = zero
!   if (grid%lap_dir_num > 0) then
!      lap_dir_nump6 = 6 + grid%lap_dir_num * 2
!      do i = 1,parallel%mydim
!         tmpvec = 0
!         irow = parallel%pint(i)
!         kk = 0
!         do ish = 1,norder
!            tmpvec(1) = tmpvec(1) + &
!               coeke(ish,1)*(vec( parallel%neibs(kk+2,irow) ) - &
!                             vec( parallel%neibs(kk+1,irow) ))
!            tmpvec(2) = tmpvec(2) + &
!               coeke(ish,2)*(vec( parallel%neibs(kk+4,irow) ) - &
!                             vec( parallel%neibs(kk+3,irow) ))
!            tmpvec(3) = tmpvec(3) + &
!               coeke(ish,3)*(vec( parallel%neibs(kk+6,irow) ) - &
!                             vec( parallel%neibs(kk+5,irow) ))
!            kk = kk + lap_dir_nump6
!         enddo
!         call matvec3('N',grid%grad_bvec_norm,tmpvec,gradf(1,irow))
!      enddo
!   else
!      do i = 1,parallel%mydim
!         tmpvec = 0
!         irow = parallel%pint(i)
!         kk = 0
!         do ish = 1,norder
!            tmpvec(1) = tmpvec(1) + &
!               coeke(ish,1)*(vec( parallel%neibs(kk+2,irow) ) - &
!                             vec( parallel%neibs(kk+1,irow) ))
!            tmpvec(2) = tmpvec(2) + &
!               coeke(ish,2)*(vec( parallel%neibs(kk+4,irow) ) - &
!                             vec( parallel%neibs(kk+3,irow) ))
!            tmpvec(3) = tmpvec(3) + &
!               coeke(ish,3)*(vec( parallel%neibs(kk+6,irow) ) - &
!                             vec( parallel%neibs(kk+5,irow) ))
!            kk = kk + 6
!         enddo
!         gradf(1:3,irow) = tmpvec
!      enddo
!   endif

! end subroutine old_gradmvs !}}}
!====old functions - ready for removal ====!
! subroutine lapmvs(parallel, func, lapl, coeke, norder, lap_dir_num, vec) !{{{
! !  The new lampvs would eventually be a wrapper for the one_true_laplacian
! !  Right now we will just add in the use of the buffer module and some openmp

!   use parallel_data_module
!   use buffer_module

!   use constants
! ! #ifdef MPI
! !   !  include mpi definitions
! !   use mpi_f08
! ! #endif
!   implicit none
! #ifdef ITAC
!   include 'VT.inc'
!   include 'vtcommon.inc'
! #endif
!   !
!   !  Input/Output variables:
!   !
!   !  parallel computation related data
!   type (parallel_data), intent(in) :: parallel
!   !  order of finite-difference expansion
!   integer, intent(in) :: norder
!   !  lap_dir_num - number of extra directions for the laplacian.
!   integer, intent(in) :: lap_dir_num
!   !  finite-difference coefficients for a second derivative
!   real(dp), intent(in) :: coeke(-norder:norder,lap_dir_num+3)
!   !  input function
!   real(dp), intent(in) :: func(parallel%mydim)
!   !  output function, lapl = -Laplacian(func)
!   real(dp), intent(out) :: lapl(parallel%mydim)
!   !  work array
!   real(dp), intent(out) :: vec(parallel%nwedge+1)
!   !
!   !  Work variables:
!   type (lap_buffer) :: rho_lap_buffer
!   !
!   !  local scalars
!   integer :: i,ii,jj, ish, irow,  ioffset
!   real(dp) :: tmp, t0, t1, t2
!   !  maxdim = maximum number of rows handled by each proc
!   !  needed for MPI communication inside bdxc_as
! !  integer :: maxdim
! #ifdef ITAC
!   integer :: lapmverr
! #endif

!   !---------------------------------------------------------------

!   ! maxdim = 0
!   ! do i = 0, parallel%group_size - 1
!   !    irow = parallel%irows(i+1)-parallel%irows(i)
!   !    if (irow > maxdim) maxdim = irow
!   ! enddo

!   ! !  Global dimension and local rows' offset.
!   ! ioffset = parallel%irows(parallel%group_iam) - 1
!   !
!   !  Initiate the boundary exchange information for laplacian.
!   !
! !  call mysecond(t0)
!    if (parallel%group_size > 1 ) then
! !DEBUG: 
! !    write(9,*) "Initiate comminucations on lapmvs"

!   call init_lap_buffer(rho_lap_buffer)
!   call allocate_lap_buffer(rho_lap_buffer,parallel)
!   call buff_lap_pack(parallel,rho_lap_buffer,func,1,1,1,parallel%mydim)
!   call buff_lap_comm(parallel,rho_lap_buffer)

! !  call mysecond(t1)
! !    write(9,*) "lapmvs comm part I time", t1-t0
! !  call buff_lap_just_test_comm(rho_lap_buffer)
!   endif

!   tmp = sum(coeke(0,1:3+lap_dir_num))
! #ifdef ITAC
!     call VTBEGIN(vt_laplacian , lapmverr)
! #endif
! !DEBUG:
! !  write(9,*) "Starting parallel construct on hpotcg lapmvs"
! !==============OMP PARALLEL CONSTRUCT================!
! !$OMP PARALLEL &
! !$OMP& SHARED(func,vec,parallel,rho_lap_buffer,coeke,lapl,tmp,norder,lap_dir_num,t0) 
! ! !$OMP& PRIVATE(ii,irow,jj,ish)

! !$OMP MASTER
!    if (parallel%group_size > 1 ) then
!     call buff_lap_check_comm(rho_lap_buffer,1)
!   ! call mysecond(t2)
!     call buffer_lap_unpack(parallel,vec,rho_lap_buffer)
! !DEBUG: 
!    ! write(9,*) "comminucations were over after", t2-t1
!    endif
! !$OMP END MASTER

!   !  Set wave function outside the domain be zero.
!   !  The index for points outside the domain is ndim+1.
!   !
! !$OMP SINGLE
!     vec(parallel%nwedge+1) = zero 
! !$OMP END SINGLE NOWAIT


!   ! call dcopy(parallel%mydim,func,1,vec,1)
!   !  with
!   !  Diagonal part.
!   !
! !$OMP DO &
! !$OMP& SCHEDULE(RUNTIME) & 
! !$OMP& PRIVATE(i)
!     do i=1,parallel%mydim
!         vec(i) = func(i)
!        lapl(i) = tmp * func(i)
!     end do
! !$OMP END DO
! ! ! !$OMP END DO NOWAIT
! ! !$OMP DO &
! ! !$OMP& SCHEDULE(RUNTIME) & 
! ! !$OMP& PRIVATE(i)
! !   do i = 1, parallel%mydim
! !      lapl(i) = tmp * vec(i)
! !   enddo
! ! !$OMP END DO


!   !
!   !  Non-local part, symmetric function (no characters).
!   ! 
!   !  AJB: time to do this with openmp. 
!   !
!   select case (lap_dir_num)
!   case (0)
! !$OMP DO &
! !$OMP& SCHEDULE(RUNTIME) &
! !$OMP& PRIVATE(ii,irow,jj,ish)
!      do ii = 1,parallel%mydim
!         irow = parallel%pint(ii)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) ))
!            jj = jj + 6
!         enddo
!      enddo
! !$OMP END DO
!   case (1)
! !$OMP DO &
! !$OMP& SCHEDULE(RUNTIME) &
! !$OMP& PRIVATE(ii,irow,jj,ish)
!      do ii = 1,parallel%mydim
!         irow = parallel%pint(ii)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) ))
!            jj = jj + 8
!         enddo
!      enddo
! !$OMP END DO
!   case (2)
! !$OMP DO &
! !$OMP& SCHEDULE(RUNTIME) &
! !$OMP& PRIVATE(ii,irow,jj,ish)
!      do ii = 1,parallel%mydim
!         irow = parallel%pint(ii)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) )) + &
!                 coeke(ish,5)*(vec( parallel%neibs(jj+9,irow) ) + &
!                               vec( parallel%neibs(jj+10,irow) ))
!            jj = jj + 10
!         enddo
!      enddo
! !$OMP END DO
!   case (3)
! !$OMP DO &
! !$OMP& SCHEDULE(RUNTIME) &
! !$OMP& PRIVATE(ii,irow,jj,ish)
!      do ii = 1,parallel%mydim
!         irow = parallel%pint(ii)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) )) + &
!                 coeke(ish,5)*(vec( parallel%neibs(jj+9,irow) ) + &
!                               vec( parallel%neibs(jj+10,irow) )) + &
!                 coeke(ish,6)*(vec( parallel%neibs(jj+11,irow) ) + &
!                               vec( parallel%neibs(jj+12,irow) ))
!            jj = jj + 12
!         enddo
!      enddo
! !$OMP END DO
!   end select
! !$OMP END PARALLEL 
! !DEBUG:
! !    write(9,*) "Ended parallel construct on hpotcg lapmvs"
!   ! call mysecond(t2)
!     ! write(9,*) "lapmvs time, ", t2-t0
! #ifdef ITAC
!     call VTEND(vt_laplacian , lapmverr)
! #endif
!     if (parallel%group_size > 1 ) then
!     call destroy_lap_buffer(rho_lap_buffer)
!     endif

! end subroutine lapmvs !}}}
! subroutine lapmvs_old(parallel, func, lapl, coeke, norder, lap_dir_num, vec) !{{{

!   use parallel_data_module

!   use constants
! #ifdef MPI
!   !  include mpi definitions
!   use mpi_f08
! #endif
!   implicit none
! #ifdef ITAC
!   include 'VT.inc'
!   include 'vtcommon.inc'
! #endif
!   !
!   !  Input/Output variables:
!   !
!   !  parallel computation related data
!   type (parallel_data), intent(in) :: parallel
!   !  order of finite-difference expansion
!   integer, intent(in) :: norder
!   !  lap_dir_num - number of extra directions for the laplacian.
!   integer, intent(in) :: lap_dir_num
!   !  finite-difference coefficients for a second derivative
!   real(dp), intent(in) :: coeke(-norder:norder,lap_dir_num+3)
!   !  input function
!   real(dp), intent(in) :: func(parallel%mydim)
!   !  output function, lapl = -Laplacian(func)
!   real(dp), intent(out) :: lapl(parallel%mydim)
!   !  work array
!   real(dp), intent(out) :: vec(parallel%nwedge+1)
!   !
!   !  Work variables:
!   !
!   !  local scalars
!   integer :: i, jj, ish, irow,  ioffset
!   real(dp) :: tmp
!   !  maxdim = maximum number of rows handled by each proc
!   !  needed for MPI communication inside bdxc_as
!   integer :: maxdim
! #ifdef ITAC
!   integer :: lapmverr
! #endif

!   !---------------------------------------------------------------

!   maxdim = 0
!   do i = 0, parallel%group_size - 1
!      irow = parallel%irows(i+1)-parallel%irows(i)
!      if (irow > maxdim) maxdim = irow
!   enddo

!   !  Global dimension and local rows' offset.
!   ioffset = parallel%irows(parallel%group_iam) - 1
!   !
!   !  Initiate the boundary exchange information for laplacian.
!   !
!   ! AJB: switch with buffers, not because you need the buffer,
!   ! but because it will be with the neighborhood collectives
!   ! and you are copying to a buffer anyways
!   call dcopy(parallel%mydim,func,1,vec,1)
! #ifdef MPI
!   call bdxc_as( vec, maxdim, parallel%nwedge, parallel%irecvp, &
!        parallel%jsendp,parallel%senrows, parallel%group_comm, &
!        parallel%group_size, parallel%group_iam)
! #endif
!   !
!   !  Set wave function outside the domain be zero.
!   !  The index for points outside the domain is ndim+1.
!   !
!   vec(parallel%nwedge+1) = zero 
!   !
!   !  Diagonal part. AJB: time for Openmp
!   !
!   tmp = sum(coeke(0,1:3+lap_dir_num))
!   do i = 1, parallel%mydim
!      lapl(i) = tmp * vec(i)
!   enddo
!   !
!   !  Non-local part, symmetric function (no characters).
!   ! 
!   !  AJB: time to do this with openmp. 
!   !  next - would be to use the same laplacian for
!   !  matvec and lapmvs.
!   !
! #ifdef ITAC
!     call VTBEGIN(vt_laplacian , lapmverr)
! #endif
!   select case (lap_dir_num)
!   case (0)
!      do i = 1,parallel%mydim
!         irow = parallel%pint(i)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) ))
!            jj = jj + 6
!         enddo
!      enddo
!   case (1)
!      do i = 1,parallel%mydim
!         irow = parallel%pint(i)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) ))
!            jj = jj + 8
!         enddo
!      enddo
!   case (2)
!      do i = 1,parallel%mydim
!         irow = parallel%pint(i)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) )) + &
!                 coeke(ish,5)*(vec( parallel%neibs(jj+9,irow) ) + &
!                               vec( parallel%neibs(jj+10,irow) ))
!            jj = jj + 10
!         enddo
!      enddo
!   case (3)
!      do i = 1,parallel%mydim
!         irow = parallel%pint(i)
!         jj = 0
!         do ish = 1,norder
!            lapl(irow) = lapl(irow) + &
!                 coeke(ish,1)*(vec( parallel%neibs(jj+1,irow) ) + &
!                               vec( parallel%neibs(jj+2,irow) )) + &
!                 coeke(ish,2)*(vec( parallel%neibs(jj+3,irow) ) + &
!                               vec( parallel%neibs(jj+4,irow) )) + &
!                 coeke(ish,3)*(vec( parallel%neibs(jj+5,irow) ) + &
!                               vec( parallel%neibs(jj+6,irow) )) + &
!                 coeke(ish,4)*(vec( parallel%neibs(jj+7,irow) ) + &
!                               vec( parallel%neibs(jj+8,irow) )) + &
!                 coeke(ish,5)*(vec( parallel%neibs(jj+9,irow) ) + &
!                               vec( parallel%neibs(jj+10,irow) )) + &
!                 coeke(ish,6)*(vec( parallel%neibs(jj+11,irow) ) + &
!                               vec( parallel%neibs(jj+12,irow) ))
!            jj = jj + 12
!         enddo
!      enddo
!   end select
! #ifdef ITAC
!     call VTEND(vt_laplacian , lapmverr)
! #endif

! end subroutine lapmvs_old !}}}
!}}}
! end of legacy code
