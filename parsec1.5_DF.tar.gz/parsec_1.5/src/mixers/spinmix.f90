module spinmix_module

implicit none
contains

!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! author: ?
!
!---------------------------------------------------------------
subroutine spinmix(pot, mixer)

use potential_module
use mixer_module
implicit none

! Input/Output variables
type(potential), intent(in) :: pot
type(mixer_data), intent(inout) :: mixer

! Work variables
integer :: irow

! ---------------------------------------------------------------

do irow = 1, pot%ndim
        mixer%xin(irow) = pot%vold(irow,1)
        mixer%xin(pot%ndim+irow) = pot%vold(irow,2)
        mixer%xout(irow) = pot%vnew(irow,1)
        mixer%xout(pot%ndim+irow)=pot%vnew(irow,2)
enddo

end subroutine spinmix



!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! author: ?
!
!---------------------------------------------------------------
subroutine spinunmix(pot, mixer)

use potential_module
use mixer_module
implicit none

! Input/Output variables
type(potential), intent(inout) :: pot
type(mixer_data), intent(in) :: mixer

! Work variables:
integer :: irow

! ---------------------------------------------------------------

do irow = 1, pot%ndim
        pot%vnew(irow,1) = mixer%xout(irow)
        pot%vnew(irow,2) = mixer%xout(pot%ndim+irow)
enddo

end subroutine spinunmix
!===============================================================



end module spinmix_module
