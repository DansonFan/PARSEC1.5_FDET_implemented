module anderson_module

implicit none
contains

!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!              Anderson mixing scheme
!
! This suborutine mixes the old and new potential to create a new
! guess for the potential in the self-consistent cycle.
! D. G. Anderson, J. Assoc. Computing Machinery, Vol12, p547(1965).
! V. Eyert, J. Comput. Phys. Vol124,P271(1996)
!
! NOTE: the mixed potential is returned as xin, BUT to be
! consistent with the old anderson.f and parsec, xout is also
! updated as the new potential.
!
! Author: Lingzhu Kong(2005)
!    
!---------------------------------------------------------------
subroutine anderson_mix(mixer, parallel, iter, nrep, xin, xout, ierr)

use constants
use mixer_module
use parallel_data_module
use psum_module
use external_interfaces, only : dgesv
use qinv_module, only : qinv
implicit none


! Input/Output variables:



! mixer related data
type(mixer_data), intent(inout) :: mixer

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! iteration number
integer, intent(in) :: iter

! order of the reduced group
integer,intent(in) :: nrep

! error flag, 440 < ierr < 451
integer,intent(out) :: ierr

! old potential
real(dp), dimension(mixer%ndim*mixer%nspin), intent(inout) :: xin

! new potentials 
real(dp), dimension(mixer%ndim*mixer%nspin), intent(inout) :: xout



! Work variables:

! Residual vectors F[n] = ( xout - xin ) (Eq(2.1) in Eyert)
real(dp), dimension(:,:), allocatable :: f

! Mixed input (Eq(4.1) in Eyert)
real(dp), dimension(:), allocatable :: aver

! Mixed residual (Eq(4.2) in Eyert)
real(dp), dimension(:), allocatable :: faver

! Coefficient matrix in (4.3)(Eyert)
real(dp), dimension(mixer%memory,mixer%memory) :: b

! Right hand side(RHS) vector in (4.3)(Eyert)
real(dp), dimension(mixer%memory,1) :: b0

! dimension of the potential vector
integer :: mydim_full

! multiplicity of grid points
real(dp) :: weight

! counters, temporary variables
integer :: i
integer :: j
integer :: k
integer :: anderi
integer, dimension(mixer%memory) :: ipiv
integer :: info
integer :: alcstat
real(dp) :: xsum

! ---------------------------------------------------------------


mydim_full = mixer%ndim*mixer%nspin

allocate(f(mydim_full,mixer%memory+1), stat=alcstat)
call alccheck('f ', mydim_full*(mixer%memory+1), alcstat)

allocate(aver(mydim_full), stat=alcstat)
call alccheck('aver ', mydim_full, alcstat)

allocate(faver(mydim_full), stat=alcstat)
call alccheck('faver ', mydim_full, alcstat)


if ( mixer%istart .and. (iter < mixer%memory) ) then
        ! KHL: if iter has not saturate mixer%memory, we
        !      will use data from the previous 
        !      xinold and xoutold.
        !      As a reuslt, we need to modify anderi
        anderi = iter + mixer%old_stored_memory
        anderi = min(anderi, mixer%memory+1)
else
        anderi = mod(iter-1, mixer%restart) + 1
        anderi = min(anderi, mixer%memory+1)
endif


weight = real(nrep, dp)



mixer%stored_memory = min(anderi, mixer%memory)




if (anderi == 1) then
        ! first iteration - previous information not available yet!
        do k = 1, mydim_full
                ! store for next iteration
                mixer%xinold(k,1) = xin(k)
                mixer%xoutold(k,1) = xout(k)

                ! next guess obtained by pure linear mixing
                xin(k) = mixer%param*xout(k) + (one - mixer%param)*xin(k)
                xout(k) = xin(k)
        enddo
else
        ! residual from current iteration 
        do k = 1, mydim_full
                f(k,1) = xout(k) - xin(k)
        enddo

        ! residual from previous iterations
        do j = 2, anderi
        do k = 1, mydim_full
                f(k,j) = mixer%xoutold(k,j-1) - mixer%xinold(k,j-1)
        enddo
        enddo

        ! Coefficient matirx b and RHS vector b0 initialised as zero
        b(:,:) = dzero
        b0(:,:) = dzero

        ! update matrix b from redidual vectors f
        do j = 1, anderi-1
        do i = 1, j
                xsum = dzero

                do k = 1, mydim_full
                        xsum = xsum + (f(k,1)-f(k,i+1))*(f(k,1)-f(k,j+1))
                enddo

                call psum(xsum, parallel%nprow, parallel%colgroup_comm)

                b(i,j) = xsum*weight

                if (i /= j) b(j,i) = b(i,j)
        enddo
        enddo
        ! End of the update of matrix b



        ! update vectors b0
        do i = 1, anderi-1
                xsum = zero

                do k = 1, mydim_full
                        xsum = xsum + (f(k,1)-f(k,i+1))*f(k,1)
                enddo

                call psum(xsum, parallel%nprow, parallel%colgroup_comm)

                b0(i,1) = xsum*weight
        enddo
        ! End  of the update of b0

        ! Solve b * X = b0 for X, overwrite b0. vector X is the
        ! coefficients of the previous iterations that enter the new
        ! guess potential.
        info = 0

        call dgesv(int(anderi-1, mymklint), 1_mymklint, b, &
                int(mixer%memory, mymklint), int(ipiv, mymklint), b0, &
                int(mixer%memory, mymklint), int(info, mymklint))
 
        if (info /= 0) then
                write(9,*) ' ERROR: dgesv diagonalization failed in '
                write(9,*) ' subroutine anderson.f, info = ', info
                ierr = 441
                return
        endif

        ! mixed input and mixed residual 
        do k = 1, mydim_full
                aver(k) = xin(k)
                faver(k) = f(k,1)

                do i = 1, anderi-1
                        aver(k) = aver(k) + &
                                b0(i,1)*( mixer%xinold(k,i)-xin(k) )
                        faver(k) = faver(k) + &
                                b0(i,1)*( f(k,i+1) - f(k,1) )
                enddo
        enddo

        ! Store the old information for next mxing
        if ( anderi == mixer%memory+1 ) then
                if (anderi > 2) then
                        do k = 1, mydim_full
                        do i = anderi-2, 1, -1
                                mixer%xinold(k,i+1) = mixer%xinold(k,i)
                                mixer%xoutold(k,i+1) = mixer%xoutold(k,i)
                        enddo
                        enddo
                endif
        else
                do k = 1, mydim_full
                do i = anderi-1, 1, -1
                        mixer%xinold(k,i+1) = mixer%xinold(k,i)
                        mixer%xoutold(k,i+1) = mixer%xoutold(k,i)
                enddo
                enddo
        endif
        ! end of store

        ! Linear mix the mixed input and mixed residual for the new potential.
        do k = 1, mydim_full
                mixer%xinold(k,1) = xin(k)
                mixer%xoutold(k,1) = xout(k)
                xin(k) = aver(k) + mixer%param*faver(k)
                xout(k) = xin(k)
        enddo
endif

deallocate( f , aver , faver )

end subroutine anderson_mix
!===============================================================
end module anderson_module
