module eigval_module 

implicit none

!=====================================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Call one of the iterative diagonalization subroutines 
! (arpack, chebdav, chebff) for diagonalization at 
! each SCF step; or call a diagonalization subroutine only for the
! first SCF step, then switch to the subspace filtering method
! using adaptive Chebyshev polynomials (the latter approach is
! significantly faster than iterative diagonalization at each 
! SCF step).
!
! Ver1.4 main updates by ykzhou as implemented by AJB:
! (1)  implemented chebff for the 1st diagonalization 
!      (chebff is a lot faster than diagonalization, and it uses less memory)
! (2)  implemented newer bounds estimator for the chebyshev filters 
! (3)  implemented the scaled chebyshev filters, need input flag to switch them.
! (4)  Trlanc and Diagla removed.
!      
! Feb--April 2014, Austin
!---------------------------------------------------------------------

contains

subroutine eigval(elec_st, pot, u_pot, solver, parallel, ipr, ierr)

use constants, only : dzero, zzero
use electronic_struct_module
use potential_module
use non_local_psp_module
use eigen_solver_module
use parallel_data_module
use psum_module
use solver_chebdav
use solver_chebff

#ifdef USEARPACK 
use solver_arpk
#endif

use subspace_module
use external_interfaces, only : dcopy, zscal, dscal, ddot, zdotc
use aux, only : myflush

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_barrier, mpi_allreduce, mpi_in_place, &
        mpi_integer, mpi_max, mpi_bcast, mpi_double_precision
#else
use mpi
#endif
#endif

implicit none

#ifdef ITAC
include 'VT.inc'
include 'vtcommon.inc'
#endif 



! Input/Output variables:



! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! potential related data
type(potential), intent(in) :: pot

! on-site Coulomb interaction related data
type(nonloc_pseudo_potential), intent(inout) :: u_pot

! solver related data
type(eigen_solver), intent(inout) :: solver

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! printout flag
integer, intent(in) :: ipr

! error flag, 400 < ierr < 421
integer, intent(out) :: ierr




! Work variables:

#ifdef MPI
integer :: masterid
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: comm_f08
integer :: colgroup_comm_f08
#endif
#endif


integer :: node
integer :: i
integer :: irp
integer :: ntotal
integer :: isc
integer :: iit
integer :: mxstate


! number of k-points
integer :: kpnum

! number of spins
integer :: isp
integer :: spnum

! integer array used to save number of truly converged eigenpairs
! per representation !!replaced by solver%nconvt!!
!  integer :: nconvt(elec_st%nrep)
integer :: kplp
real(dp) :: dnorm
real(dp) :: magmom
real(dp) :: rtmp
real(dp) :: tmpcoe
complex(dpc) :: znorm

! number of eigenpairs converged
integer, dimension(:,:,:), allocatable :: nec

! maximum number of matrix-vector multiplications performed.
integer, dimension(:,:,:), allocatable :: maxmvs

! Number of states to be calculated for each representation so
! that they add up to at least elec_st%nstate, required on input.
integer, dimension(:,:,:), allocatable :: nrep

! Number of additional states to be calculated for each
! representation. This is used as safety window, to prevent
! calculating too few eigenstates on some representation.
integer, dimension(:,:,:), allocatable :: nrep_add

! temporary representation array
integer, dimension(:), allocatable :: irep_in

! output error
integer, dimension(:,:,:), allocatable :: out_info

! temporary arrays for communication
integer, dimension(:,:,:), allocatable :: itmp
integer, dimension(:,:,:), allocatable :: mxstt

! maximum number of diagonalization iterations before quitting
integer, parameter :: maxit = 5

! flag for chebdav_diag
character(len=4) :: flag

! stuff for modifying FD coefficents
integer :: ishell
integer :: icoeff
integer :: current_shell_shift
integer :: irow
integer :: jcol

integer :: num_of_taskgroups
integer :: jbegloc
integer :: jendloc

! ---------------------------------------------------------------

#ifdef MPI
masterid = parallel%masterid
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
comm_f08 = parallel%comm
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif


! Set nec = elec_st%eig%nec if this eigensolver can reuse old info
! having eigenvalues and eigenvectors only.
kpnum = max(elec_st%nkpt, 1)
spnum = elec_st%nspin/elec_st%mxwd

num_of_taskgroups = elec_st%nrep*kpnum*spnum

allocate(nec(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('nec', num_of_taskgroups, ierr)
nec(:,:,:) = 0
allocate(maxmvs(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('maxvms', num_of_taskgroups, ierr)
maxmvs(:,:,:) = 0
allocate(nrep(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('nrep', num_of_taskgroups, ierr)
nrep(:,:,:) = 0
allocate(nrep_add(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('nrep_add', num_of_taskgroups, ierr)
nrep_add(:,:,:) = 0
allocate(out_info(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('out_info', num_of_taskgroups, ierr)
out_info(:,:,:) = 0
allocate(itmp(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('itmp', num_of_taskgroups, ierr)
itmp(:,:,:) = 0
allocate(mxstt(elec_st%nrep,kpnum,spnum), stat=ierr)
call alccheck('mxstt', num_of_taskgroups, ierr)
mxstt(:,:,:) = 0

do isp = 1, spnum
do kplp = 1, kpnum
do irp = 1, elec_st%nrep
        if (solver%name == CHEBFF) then
                nec(irp,kplp,isp) = max(elec_st%eig(irp,kplp,isp)%nec,0)
        elseif (solver%name == CHEBDAV) then
                nec(irp,kplp,isp) = max(elec_st%eig(irp,kplp,isp)%nec,0)
        else
                nec(irp,kplp,isp) = 0
        endif
enddo
enddo
enddo




! Diagonalization loop.

elec_st%eig(:,:,:)%nec = 0


!do iit = 1, maxit
        maxmvs(:,:,:) = 0

        ! Start loop over spin,kpoints and representations in this PE group
        do isp = 1, spnum
        do kplp = 1, kpnum
                u_pot%isp = isp

                ! Retrieve the current Hartree potential and adjust 
                ! kinetic energy coeffs if needed
                call update_adiag_and_coeff()

                do irp = 1, elec_st%nrep
                        ! if no eigenstates are needed, skip diagonalization
                        ! \note AJB - hmmm? when is nec /=0 ?
                        
                        if (elec_st%eig(irp,kplp,isp)%nec /= 0) cycle
                        if (elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                parallel%mytaskgroup) cycle

                        !call renormalize_wfns()

                        ! copy characters and matrix-vector counter
                        maxmvs(irp,kplp,isp) = solver%maxmv
                        solver%chi(:) = elec_st%chi(irp,:)

                        ! if mxstate changes, reset eig_init flag
                        ! ntotal stores the new value of mxstate
                        ntotal  = elec_st%eig(irp,kplp,isp)%nn
                        mxstate = elec_st%eig(irp,kplp,isp)%mm

                        if (mxstate /= ntotal) then
                                if (solver%do_subsp .and. &
                                        mxstate < ntotal) then

                                        solver%eig_init(irp,kplp,isp) = &
                                                .false.
                                endif

                                mxstate = ntotal
                        endif

                        if (mod(mxstate,parallel%npcol) /= 0) then
                                if (parallel%iammaster) then
                                        write(7,*) ' WARNING in eigval.F &
                                                &while working at'
                                        write(7,*) ' representation ', &
                                                irp, ' k-point ', kplp, &
                                                ' spin ', isp
                                        write(7,*) ' mxstate is not divisible by npcol; &
                                                &rounding up work size.'
                                        write(7,*) 'requested mxstate', mxstate, &
                                                'npcol', parallel%npcol
                                        call myflush(7)
                                endif

                                mxstate = ((mxstate + parallel%npcol - 1) / &
                                        parallel%npcol) * parallel%npcol
                        endif


                        call eig_adj_size(eigen=elec_st%eig(irp,kplp,isp), &
                                ldn=parallel%ldn_full, &
                                new_nstates_per_colgroup= &
                                        mxstate/parallel%npcol, &
                                winsize=solver%winsize, &
                                npcol=parallel%npcol, &
                                cplx=elec_st%cplx)

                        ! Do Chebyshev filtering only if 
                        ! the number of eigenvalues has not changed.
                        if ( solver%do_subsp .and. &
                             solver%eig_init(irp,kplp,isp) ) then 

                                if (ipr >= 2) then
write(9,*) ' subspace (irp,kplp,isp,mm,nn,nec) = ', irp, kplp, isp, &
        mxstate, elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp)

                                        call myflush(9)
                                endif 

                                if (parallel%iammaster) then
                                        if (ipr >=2) then
                                                write(7,*)
                                                write(7,*) 'EIGVAL:: Subspace'
                                                write(7,*)
                                        endif
                                endif

#ifdef ITAC
                                call VTBEGIN(vt_subspace,ierr)
#endif

                                ! KHL: Here evec_dim is set to 
                                !      nstates_per_colgroup
                                !      rather than nstates_per_colgroup_max,
                                !      because we will do chefsi() no matter 
                                !      the first SCF is using davison or first-filtering
                                !      The reason for eval_dim
                                if (elec_st%cplx) then
                                        call zsubspace(kplp=kplp, &
                                                evec_ldn=parallel%ldn_full, &
                                                evec_dim=elec_st%eig(irp,kplp,isp)%nstates_per_colgroup, &
                                                evec_mydim=parallel%mydim_full, &
                                                evec=elec_st%eig(irp,kplp,isp)%zwf, &
                                                eval_dim=elec_st%eig(irp,kplp,isp)%nstates, &
                                                eval=elec_st%eig(irp,kplp,isp)%en, &
                                                mvcount=maxmvs(irp,kplp,isp), &
                                                blksize=solver%mv_blksize, &
                                                verbose=ipr, &
                                                irp=irp, &
                                                isp=isp, &
                                                info=out_info(irp,kplp,isp))
                                else
                                        if (solver%spectrum_slicing .and. &
                                                solver%num_of_iter_still_using_chebyshev == 0) then

                                                write(9,*) 'SUBSPACE: spectrum_slicing is on'

                                                call mpi_bcast(elec_st%efermi, 1, &
                                                        mpi_double_precision, &
                                                        parallel%masterid, &
                                                        comm_f08, mpinfo)
                                                
                                                call dspectrum_slicing_diag( &
                                                        elec_st%eig(irp,kplp,isp), &
                                                        kplp, &
                                                        elec_st%eig(irp,kplp,isp)%nn, &
                                                        nec(irp,kplp,isp), &
                                                        maxmvs(irp,kplp,isp), &
                                                        irp, &
                                                        isp, &
                                                        ipr, &
                                                        solver%mv_blksize, &
                                                        elec_st%efermi, &
                                                        elec_st%sre(isp), &
                                                        out_info(irp,kplp,isp))

                                                call renormalize_wfns()
 
                                        else
                                                write(9,*) 'SUBSPACE: spectrum_slicing is off'

                                                if (solver%spectrum_slicing) then
                                                        write(9,*) &
                                                                'solver%num_of_iter_still_using_chebyshev', &
                                                                solver%num_of_iter_still_using_chebyshev

                                                        solver%num_of_iter_still_using_chebyshev = &
                                                                solver%num_of_iter_still_using_chebyshev - 1
                                                endif

                                                call dsubspace(kplp=kplp, &
                                                        evec_ldn=parallel%ldn_full, &
                                                        evec_dim=elec_st%eig(irp,kplp,isp)%nstates_per_colgroup, &
                                                        evec_mydim=parallel%mydim_full, &
                                                        evec=elec_st%eig(irp,kplp,isp)%wf, &
                                                        eval_dim=elec_st%eig(irp,kplp,isp)%nstates, &
                                                        eval=elec_st%eig(irp,kplp,isp)%en, &
                                                        mvcount=maxmvs(irp,kplp,isp), &
                                                        blksize=solver%mv_blksize, &
                                                        verbose=ipr, &
                                                        irp=irp, &
                                                        isp=isp, &
                                                        info=out_info(irp,kplp,isp))
                                        endif
                                endif

                                ! nec stores the number of 
                                ! converged eigenpairs
                                nec(irp,kplp,isp) = &
                                        elec_st%eig(irp,kplp,isp)%nstates

#ifdef ITAC
                                call VTEND(vt_subspace,ierr)
#endif

                                ! In case the "chebdav" eigensolver 
                                ! is called after a call to "subspace" 
                                ! (because the value of "nec" has changed,
                                ! for example), then it should know that 
                                ! all eigenpairs up
                                ! to the old value of "nec" are converged.
                                ! (--ykz: why call chebdav after a call to "subspace"?? shouldn't do this)
                                solver%nconvt(irp,kplp,isp) = &
                                        nec(irp,kplp,isp)

                        else

                                if (ipr >= 2) then
write(9,*) ' eigval (irp,kplp,isp,mm,nn,nec) = ', irp, kplp, isp, &
        mxstate, elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp)

                                        call myflush(9)
                                endif

                                do isc = 1, maxit
                                        if (elec_st%cplx) then
                                                select case(solver%name)
                                                case (ARPACK)
                                                        ! Residual vector is not reused for the moment.
                                                        !out_info(irp,kplp,isp) = solver%info(irp,kplp,isp)
                                                        out_info(irp,kplp,isp) = 0

#ifdef ITAC
                                                        call VTBEGIN(vt_arpack,ierr)
#endif

#ifdef USEARPACK 
                                                        call zarpk_diag (kplp=kplp, &
                                                                evec_ldn=parallel%ldn_full, &
                                                                evec_dim=elec_st%eig(irp,kplp,isp)%nn, &
                                                                evec_mydim=parallel%mydim_full, &
                                                                evec=elec_st%eig(irp,kplp,isp)%zwf, &
                                                                eval_dim=elec_st%eig(irp,kplp,isp)%nn, &
                                                                eval=elec_st%eig(irp,kplp,isp)%en, &
                                                                nec=nec(irp,kplp,isp), &
                                                                maxmvs=maxmvs(irp,kplp,isp), &
                                                                tol=solver%toler, &
                                                                resid_restart=solver%zres_res(:,irp,kplp,isp), &
                                                                ipr=ipr, &
                                                                info=out_info(irp,kplp,isp))
#endif

                                                                solver%info(irp,kplp,isp) = out_info(irp,kplp,isp)

#ifdef ITAC
                                                        call VTEND(vt_arpack,ierr)
#endif

                                                case (CHEBFF)

#ifdef ITAC
                                                        call VTBEGIN(vt_chebff,ierr)
#endif
                                                        if (nec(irp,kplp,isp) <= 0) then
                                                                flag = "new";
                                                        else
                                                                flag = "cont"
                                                                write(9,*) "DEBUG: continue mode in chebff"
                                                        endif

                                                        call zchebff_diag(kplp=kplp, &
                                                                evec_ldn=parallel%ldn_full, &
                                                                evec_dim=elec_st%eig(irp,kplp,isp)%nstates_per_colgroup_max, &
                                                                evec_mydim=parallel%mydim_full, &
                                                                evec=elec_st%eig(irp,kplp,isp)%zwf, &
                                                                eval_dim=elec_st%eig(irp,kplp,isp)%nstates_max, &
                                                                eval=elec_st%eig(irp,kplp,isp)%en, &
                                                                nec=nec(irp,kplp,isp), &
                                                                mvcount=maxmvs(irp,kplp,isp), &
                                                                blksize=solver%mv_blksize, &
                                                                verbose=ipr, &
                                                                flag=flag, &
                                                                max_iter=solver%ff_maxiter, &
                                                                tol=solver%toler, &
                                                                info=out_info(irp,kplp,isp))

                                                        nec(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates
                                                        solver%nconvt(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates

#ifdef ITAC
                                                        call VTEND(vt_chebff,ierr)
#endif

                                                case (CHEBDAV)

#ifdef ITAC
                                                        call VTBEGIN(vt_chebdav,ierr)
#endif

                                                        !  chebdav cannot restart correctly?
                                                        !if (nec(irp,kplp,isp) <= 0) then
                                                                flag = "new";
                                                        !else
                                                        ! if (parallel%iammaster) then
                                                        !     if (ipr >2) then
                                                        !        write(7,*)
                                                        !        write(7,*) 'EIGVAL:: zCHEBDAV (CONT)'
                                                        !        write(7,*)
                                                        !    endif
                                                        ! endif
                                                        !    flag = "cont"
                                                        !    !nec(irp,kplp,isp) = min(nec(irp,kplp,isp), solver%nconvt(irp,kplp,isp))
                                                        !   end if

                                                        if (ipr >= 2) then
                                                                if (nec(irp,kplp,isp) <= 0) then
                                                                        write(9,'(a, a, a, i2, a, i5)') "Chebdav flag=" &
                                                                                , flag,", nec(",irp,")=", nec(irp,kplp,isp)
                                                                else
                                                                        write(9,'(a, a, 2(a, i2, a, i5))') "Chebdav flag=", &
                                                                                flag,", nec(",irp,")=", nec(irp,kplp,isp), &
                                                                                ", nconvt(",irp,")=",solver%nconvt(irp,kplp,isp)
                                                                endif
                                                        endif

                                                        if (parallel%iammaster) then
                                                                if (ipr >=1) then
                                                                        write(7,*)
                                                                        write(7,*) 'EIGVAL:: zCHEBDAV'
                                                                        write(7,*)
                                                                endif
                                                        endif

                                                        call zchebdav_diag(kplp, &
                                                                mxstate+solver%winsize, &
                                                                elec_st%eig(irp,kplp,isp)%nn, &
                                                                nec(irp,kplp,isp), &
                                                                maxmvs(irp,kplp,isp), &
                                                                elec_st%eig(irp,kplp,isp)%en, &
                                                                elec_st%eig(irp,kplp,isp)%zwf, &
                                                                solver%toler, &
                                                                ipr, &
                                                                flag, &
                                                                solver%nconvt(irp,kplp,isp), &
                                                                out_info(irp,kplp,isp), &
                                                                solver%mv_blksize)

#ifdef ITAC
                                                        call VTEND(vt_chebdav,ierr)
#endif

                                                end select

                                        else !if (elec_st%cplx) then

                                                select case(solver%name)
                                                case (ARPACK)
                                                        !    Residual vector is not reused for the moment
                                                        !out_info(irp,kplp,isp) = solver%info(irp,kplp,isp)
                                                        out_info(irp,kplp,isp) = 0

#ifdef ITAC
                                                        call VTBEGIN(vt_arpack,ierr)
#endif

#ifdef USEARPACK 
                                                        call darpk_diag (kplp, &
                                                                evec_ldn=parallel%ldn_full, &
                                                                evec_dim=elec_st%eig(irp,kplp,isp)%nn, &
                                                                evec_mydim=parallel%mydim_full, &
                                                                evec=elec_st%eig(irp,kplp,isp)%wf, &
                                                                eval_dim=elec_st%eig(irp,kplp,isp)%nn, &
                                                                eval=elec_st%eig(irp,kplp,isp)%en, &
                                                                nec=nec(irp,kplp,isp), &
                                                                maxmvs=maxmvs(irp,kplp,isp), &
                                                                tol=solver%toler, &
                                                                resid_restart=solver%res_res(:,irp,kplp,isp), &
                                                                ipr=ipr, &
                                                                info=out_info(irp,kplp,isp))
#endif

#ifdef ITAC
                                                        call VTEND(vt_arpack,ierr)
#endif

                                                case (CHEBFF)
                                                        if (nec(irp,kplp,isp) <= 0) then
                                                                flag = "new";
                                                        else
                                                                flag = "cont"
                                                                write(9,*) "DEBUG: continue mode in chebff"
                                                        endif

#ifdef ITAC
                                                        call VTBEGIN(vt_chebff,ierr)
#endif

                                                        if (solver%spectrum_slicing .and. &
                                                                solver%use_lanczos_dos_estimation) then

                                                                call dspectrum_slicing_diag( &
                                                                        elec_st%eig(irp,kplp,isp), &
                                                                        kplp, &
                                                                        elec_st%eig(irp,kplp,isp)%nn, &
                                                                        nec(irp,kplp,isp), &
                                                                        maxmvs(irp,kplp,isp), &
                                                                        irp, &
                                                                        isp, &
                                                                        ipr, &
                                                                        solver%mv_blksize, &
                                                                        elec_st%efermi, &
                                                                        elec_st%sre(isp), &
                                                                        out_info(irp,kplp,isp))

                                                                call renormalize_wfns()

                                                                nec(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates
                                                                solver%nconvt(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates
                                                        else
                                                                call dchebff_diag(kplp=kplp, &
                                                                        evec_ldn=parallel%ldn_full, &
                                                                        evec_dim=elec_st%eig(irp,kplp,isp)%nstates_per_colgroup_max, &
                                                                        evec_mydim=parallel%mydim_full, &
                                                                        evec=elec_st%eig(irp,kplp,isp)%wf, &
                                                                        eval_dim=elec_st%eig(irp,kplp,isp)%nstates_max, &
                                                                        eval=elec_st%eig(irp,kplp,isp)%en, &
                                                                        nec=nec(irp,kplp,isp), &
                                                                        mvcount=maxmvs(irp,kplp,isp), &
                                                                        blksize=solver%mv_blksize, &
                                                                        verbose=ipr, &
                                                                        flag=flag, &
                                                                        max_iter=solver%ff_maxiter, &
                                                                        tol=solver%toler, &
                                                                        info=out_info(irp,kplp,isp))

                                                                nec(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates
                                                                solver%nconvt(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nstates
                                                        endif


#ifdef ITAC
                                                        call VTEND(vt_chebff,ierr)
#endif

                                                case (CHEBDAV)

#ifdef ITAC
                                                        call VTBEGIN(vt_chebdav,ierr)
#endif

                                                        !  chebdav cannot restart correctly?
                                                        !if (nec(irp,kplp,isp) <= 0) then
                                                                flag = "new";
                                                        ! else
                                                        ! if (parallel%iammaster) then
                                                        !     if (ipr >0) then
                                                        !        write(7,*)
                                                        !        write(7,*) 'EIGVAL:: CHEBDAV (CONT)'
                                                        !        write(7,*)
                                                        !    endif
                                                        ! endif
                                                        !    flag = "cont"
                                                        !    !nec(irp,kplp,isp) = min(nec(irp,kplp,isp), solver%nconvt(irp,kplp,isp))
                                                        !    end if

                                                        if (ipr >= 2) then
                                                                if (nec(irp,kplp,isp) <= 0) then
                                                                        write(9,'(a,a,a,i2,a,i5)') &
                                                                                "Chebdav flag=", flag, &
                                                                                ", nec(", irp, ")=", nec(irp,kplp,isp)
                                                                else
                                                                        write(9,'(a,a,2(a,i2,a,i5))') &
                                                                                "Chebdav flag=", flag, &
                                                                                ", nec(", irp, ")=", nec(irp,kplp,isp), &
                                                                                ", nconvt(",irp,")=",  solver%nconvt(irp,kplp,isp)
                                                                endif
                                                        endif

                                                        if (parallel%iammaster) then
                                                                if (ipr >= 2) then
                                                                        write(7,*)
                                                                        write(7,*) 'EIGVAL:: CHEBDAV'
                                                                        write(7,*)
                                                                endif
                                                        endif

                                                        call dchebdav_diag(kplp, &
                                                                mxstate+solver%winsize,  &
                                                                elec_st%eig(irp,kplp,isp)%nn, &
                                                                nec(irp,kplp,isp), &
                                                                maxmvs(irp,kplp,isp), &
                                                                elec_st%eig(irp,kplp,isp)%en, &
                                                                elec_st%eig(irp,kplp,isp)%wf, &
                                                                solver%toler, &
                                                                ipr, &
                                                                flag, &
                                                                solver%nconvt(irp,kplp,isp),  &
                                                                out_info(irp,kplp,isp), &
                                                                solver%mv_blksize)

#ifdef ITAC
                                                        call VTEND(vt_chebdav,ierr)
#endif
                                                end select
                                        endif   !if (elec_st%cplx) then



#ifdef MPI
                                        call mpi_barrier(colgroup_comm_f08, mpinfo)
#endif



                                        if (ipr >=0) then
                                                  write(9,*) ' Eigensolver, end of iteration = ', isc
                                                  write(9,*) ' repr. = ',irp, ' k-point = ',kplp,' spin = ',isp 
                                                  write(9,*) ' maxmvs = ',maxmvs(irp,kplp,isp), &
                                                       ' nec = ', nec(irp,kplp,isp)
                                                  write(9,*) ' nstate = ', elec_st%eig(irp,kplp,isp)%nn, &
                                                       ' info = ',out_info(irp,kplp,isp)
                                        endif


                                        if (out_info(irp,kplp,isp) /= 0) exit

                                        if (nec(irp,kplp,isp) >= elec_st%eig(irp,kplp,isp)%nn) then
                                                nec(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nn

                                                exit
                                        endif

                                enddo   !do isc = 1, maxit


                                ! If using Chebyshev-filtered subspace method, save information 
                                ! for the subsequent iterations.
                                if (solver%do_subsp) then
                                        solver%eval_loc(1:mxstate,irp,isp) = &
                                                elec_st%eig(irp,kplp,isp)%en(1:mxstate)

                                        solver%eig_init(irp,kplp,isp) = .TRUE.
                                endif

                        endif   !if (solver%do_subsp .and. solver%eig_init(irp,kplp,isp)) then 

                        mxstt(irp,kplp,isp) = mxstate

                enddo  !do irp = 1, elec_st%nrep
        enddo   !do kplp = 1, kpnum
        enddo   !do isp = 1, spnum


#ifdef MPI
        ! Share information across groups
        ! TODO: consider switch to iallreduce
        call MPI_Allreduce(mpi_in_place, out_info, num_of_taskgroups, mpi_integer, mpi_max, comm_f08, mpinfo)
        call MPI_Allreduce(mpi_in_place, nec     , num_of_taskgroups, mpi_integer, mpi_max, comm_f08, mpinfo)
        call MPI_Allreduce(mpi_in_place, maxmvs  , num_of_taskgroups, mpi_integer, mpi_max, comm_f08, mpinfo)
        call MPI_Allreduce(mpi_in_place, mxstt   , num_of_taskgroups, mpi_integer, mpi_max, comm_f08, mpinfo)
#endif


        ! report number of eigenpairs and matrix-vector operations
        do isp = 1, spnum
        do kplp = 1, kpnum
                if (parallel%iammaster .and. elec_st%nspin == 2) then
                        if (isp == 1) write(7,*) ' SPIN UP'
                        if (isp == 2) write(7,*) ' SPIN DOWN'
                endif

                do irp = 1, elec_st%nrep
                        elec_st%eig(irp,kplp,isp)%mm = mxstt(irp,kplp,isp)

                        if (elec_st%eig(irp,kplp,isp)%taskgroup /= parallel%mytaskgroup) then
                                ! KHL: Make an empty (no wfns) 
                                !      eigenstate structure for this task 
                                !      (irp,kplp,isp), since I am not
                                !      in this taskgroup.
                                call eig_e_adj_size( &
                                        elec_st%eig(irp,kplp,isp), &
                                        nec(irp,kplp,isp))

                                if (elec_st%nspin == 2) then
                                        if (isp == 1) write(9,*) ' DEALING WITH SPIN UP'
                                        if (isp == 2) write(9,*) ' DEALING WITH SPIN DOWN'
                                endif
                        endif

#ifdef ITAC
                        call VTBEGIN(vt_eigencomm_state,ierr)
#endif

#ifdef MPI
                        !\todo Need to understand what is going on here, since this takes too long:
                        node = parallel%gmap(1,1,elec_st%eig(irp,kplp,isp)%taskgroup + 1)
                        call MPI_BCAST(elec_st%eig(irp,kplp,isp)%en,nec(irp,kplp,isp),MPI_DOUBLE_PRECISION,node,comm_f08, mpinfo)
#endif

#ifdef ITAC
                        call VTEND(vt_eigencomm_state,ierr)
#endif

                        if (out_info(irp,kplp,isp) /= 0) then
                                if (parallel%iammaster) then
                                        write(7,*) ' ERROR in eigval.F while working at'
                                        write(7,*) ' representation ', irp, ' spin ', isp
                                        write(7,*) ' error flag = ', out_info(irp,kplp,isp)
                                endif

                                ierr = 401
                                return
                        endif

                        if ((nec(irp,kplp,isp) < elec_st%eig(irp,kplp,isp)%nn) .and. &
                        !if ((nec(irp,kplp,isp) < elec_st%eig(irp,kplp,isp)%nn .or. maxmvs(irp,kplp,isp) >= solver%maxmv) .and. &
                                solver%name /= CHEBDAV) then

                                if (parallel%iammaster) then
                                        write(7,*)
                                        write(7,*) 'ERROR: ', &
                                                'Iterative diagonalization has failed!'
                                        write(7,*) ' representation ', irp, ' spin ', isp
                                        write(7,*) isc, ' iterations performed'
                                        write(7,*) ' Increase value of Maximum_matvec in parsec.in'
                                        write(7,*) ' (It will not help)'
                                        write(7,*) ' error flag = ', out_info(irp,kplp,isp)
                                endif

                                ierr = 402
                                return
                        endif
                enddo

                if (parallel%iammaster) then
                        solver%totalmv = solver%totalmv + sum(maxmvs(:,kplp,isp))

                        if (kpnum > 1) then
                                write(7,*) 'Kpoint (spin)', kplp, '(',isp,')'
                        endif

                        if (ipr >= 0) then
                                write(7,*) 'Number of converged eigen-pairs per representation:', nec(:,kplp,isp)
                                write(7,*) 'Number of matrix-vector multiplications: ',  maxmvs(:,kplp,isp)
                                write(7,*) 'Cumulated number of matrix-vector mult. = ', solver%totalmv

                                !also appearing in old format:
                                !write(7,'(a,i7)') ' nec  total = ',sum(nec(:,kplp,isp))
                                !write(7,'(a,i7)') ' maxmvs total = ',sum(maxmvs(:,kplp,isp))
                                call myflush(7)
                        endif
                endif

                ! Error messages from eigensolver.
                do irp = 1, elec_st%nrep
                        if (out_info(irp,kplp,isp) /= 0) then
                                if (parallel%iammaster) then
                                        write(7,*) ' ERROR in eigval.F while working at'
                                        write(7,*) ' representation ',irp,' spin ',isp
                                        write(7,*) ' error flag = ',out_info(irp,kplp,isp)
                                endif

                                ierr = 403
                                return
                        endif
                enddo
        enddo  !do kplp = 1, kpnum
        enddo  !do isp = 1, spnum


#ifdef ITAC
        call VTBEGIN( vt_eigensort_state,ierr)
#endif



        ! Sort eigenvalues in ascending order and define the number of
        ! states per representation, nrep. Update elec_st%irep and all
        ! elec_st%eig%nec accordingly.
        !
        do isp = 1, spnum
        do kplp = 1, kpnum
                ntotal = 0

                do irp = 1, elec_st%nrep
                        ntotal = ntotal + elec_st%eig(irp,kplp,isp)%nn
                enddo

                allocate(irep_in(ntotal))

                call eigen_sort(elec_st, isp, kplp, ntotal, &
                        nrep(1,kplp,isp), nrep_add(1,kplp,isp), irep_in)

                ntotal = min(sum(nrep(:,kplp,isp) + nrep_add(:,kplp,isp)), &
                        elec_st%nstate)

                elec_st%irep(:,kplp,isp) = 0
                elec_st%irep(1:ntotal,kplp,isp) = irep_in(1:ntotal)

                do irp = 1, elec_st%nrep
                        elec_st%eig(irp,kplp,isp)%nn = &
                                nrep(irp,kplp,isp) + nrep_add(irp,kplp,isp)
                        elec_st%eig(irp,kplp,isp)%nec = nrep(irp,kplp,isp)
                enddo

                deallocate(irep_in)

                elec_st%ntotal(isp) = ntotal

                if (solver%fix_num_eig) then
                        do irp = 1, elec_st%nrep
                                elec_st%eig(irp,kplp,isp)%nn = &
                                        elec_st%eig(irp,kplp,isp)%mm
                                elec_st%eig(irp,kplp,isp)%nec = &
                                        elec_st%eig(irp,kplp,isp)%mm
                        enddo

                        exit
                endif

        enddo
        enddo



#ifdef ITAC
        call VTEND( vt_eigensort_state,ierr)
#endif




        ! KHL: I modified this part, so that nstates_per_colgroup will not 
        !      be changed. That is, the number of states to be computed will
        !      be fixed, and in parsec.in we need to use a bigger states_num 
        !      in order to make sure each representation has computed 
        !      enough number of states and no valence states are missed.
#ifdef MPI
        !call mpi_allreduce(mpi_in_place, nrep_add, num_of_taskgroups, &
        !        mpi_integer, mpi_max, comm_f08, mpinfo)
#endif
        !if ( all(nrep_add /= 0) ) exit

!enddo   !do iit = 1, maxit




! Print error message if there are not enough eigenstates.
do isp = 1, spnum
do kplp = 1, kpnum

        ntotal = 0

        do irp = 1, elec_st%nrep
                ntotal = ntotal + elec_st%eig(irp,kplp,isp)%nec
        enddo

        if (ntotal < elec_st%nstate) then
                if (parallel%iammaster) then
                        write(7,*) 'ERROR: not enough eigenstates &
                                &are computed! '
                        write(7,*) (elec_st%eig(irp,kplp,isp)%nec, &
                                irp=1,elec_st%nrep)
                        write(7,*) elec_st%nstate, &
                                ' eigenstates requested but only ', &
                                ntotal, ' found.'
                        write(7,*) 'Increase initial_subspace_acc and/or ', &
                                'subspace_buffer_size in parsec.in'
                        write(7,*) ' STOP'
                endif

                ierr = 404
                return
        endif

        elec_st%ntotal(isp) = ntotal
enddo
enddo




! If spin-orbit, calculate the magnetic moment of each state.
! (Must assume that wave-functions are complex!)
if (elec_st%mxwd == 2) then

#ifdef ITAC
        call VTBEGIN( vt_so,ierr)
#endif

        do kplp = 1, kpnum
        do i = 1, elec_st%nstate
                magmom = zero
                irp = elec_st%irep(i,kplp,1)

                if (elec_st%eig(irp,kplp,1)%taskgroup == parallel%mygroup) then
                        do iit = 1, parallel%mydim
                                if(elec_st%ncl) then
                                        ! \todo the shift by mydim should probably be a shift by ldn
                                        magmom = magmom + &
                                            (conjg(elec_st%eig(irp,kplp,1)%zwf(iit,i))* &
                                            elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i)+ &
                                            conjg(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))* &
                                            elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 + &
                                            (zi*(-conjg(elec_st%eig(irp,kplp,1)%zwf(iit,i))* &
                                            elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i) + &
                                            conjg(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))* &
                                            elec_st%eig(irp,kplp,1)%zwf(iit,i)))**2 + &
                                            ((abs(elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 - &
                                            abs(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))**2))**2
                                else
                                     magmom = magmom + &
                                          abs(elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 - &
                                          abs(elec_st%eig(irp,kplp,1)% &
                                          zwf(iit+parallel%mydim,i))**2
                                endif
                        enddo
                endif


                call psum(magmom,1,parallel%procs_num,parallel%comm)

                elec_st%magmom(i,kplp) = magmom

                if (elec_st%ncl) magmom = sqrt(magmom)


        enddo
        enddo


#ifdef ITAC
        call VTEND( vt_so,ierr)
#endif

endif

deallocate(nec,maxmvs,nrep,nrep_add,out_info,itmp,mxstt)



!AJB: I still don't like you:
#ifdef MPI
call MPI_BARRIER(colgroup_comm_f08, mpinfo)
#endif


contains

        subroutine update_adiag_and_coeff()

        ! SET THE ADIAG PART FOR MATVEC
        if (elec_st%mxwd == 1) then !the case for mxwd is treated within matvec_so.. 

                if (elec_st%nkpt == 0) then
                        !cast the FD coeffiecnets to complex if needed (cplx flag dep.)
                        !This is instead of zset_lap_gen_coeff2D since implementaion is problematic 
                        !when the hartree retrival stage is not encapsulated
                        !
                        ! KHL: elec_st%nkpt=0 and     elec_st%cplx ==> gamma point
                        !      elec_st%nkpt=0 and not elec_st%cplx ==> 0d, confined
                        !
                        !      Both of the above will call the real number version 
                        !      of eigensolvers
                        rtmp = sum(solver%coe2(0,:))
                        do irow = 1, parallel%mydim
                                solver%adiag(irow) = pot%vnew(irow,isp) + rtmp
                        enddo

                        do irow = parallel%mydim+1, parallel%ldn
                                solver%adiag(irow) = dzero
                        enddo

                        call solver%sten_coeff%copy_coeffsym(stendef=solver%sten_def)

                        ! since diagonal term is done in adiag, need to zero out diagonals - 
                        call solver%sten_coeff%updateC0(dzero)
                else

                        if (parallel%iammaster) then
                                if (kpnum > 1) then
                                        write(7,*) ' ...Working on k-point ', kplp
                                endif
                        endif

                        ! now we move pot%vnew which is real to solver%zadiag which is complex
                        tmpcoe = sum(solver%coe2(0,:)) + &
                                elec_st%kpts(1,kplp)*elec_st%kpts(1,kplp) + &
                                elec_st%kpts(2,kplp)*elec_st%kpts(2,kplp) + &
                                elec_st%kpts(3,kplp)*elec_st%kpts(3,kplp)

                        do irow = 1, parallel%mydim
                                rtmp = pot%vnew(irow,isp) + tmpcoe
                                solver%zadiag(irow) = cmplx(rtmp, dzero, dpc)
                        enddo

                        do irow = parallel%mydim+1, parallel%ldn
                                solver%zadiag(irow) = zzero
                        enddo


                        !NOW TODO: gen_coeff2_1d -> sten_coeff 
                        !modify the FD coefficents for the kinetic energy of this k-point
                        !This is instead of zset_lap_gen_coeff2D since implementaion is problematic 
                        !when the hartree retirval stage is not encapsulated
                        call solver%sten_coeff%copy_coeff_gen(stendef=solver%sten_def)

                        do ishell = 1, solver%norder
                        do icoeff = 1, 3+parallel%lap_dir_num
                                current_shell_shift = (ishell-1)*(2*solver%sten_def%lap_dir_num+6)
                    
                                solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff-1) = &
                                        solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff-1) - &
                                        solver%kecoe1(kplp,icoeff,ishell) !(L)
                                solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff) = &
                                        solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff  ) + &
                                        solver%kecoe1(kplp,icoeff,ishell) !(R)
                        enddo
                        enddo

                        ! since diagonal term is done in adiag, need to zero out diagonals
                        call solver%sten_coeff%updateC0_gen(zzero)
                endif
        endif
        
        end subroutine update_adiag_and_coeff


subroutine renormalize_wfns()
        !
        ! Renormalize calculated eigenvectors to 1 (outside the eigensolver,
        ! eigenvectors are assumed to be normalized over the *full* grid,
        ! dot_product(wf,wf) = elec_st%nrep).
        !
        ! Only processors belonging to the group in charge of this
        ! representation should work.
        !
        ! \todo warning - the limits on the dot product are dangerous here
        !
        jbegloc = 1 + elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*parallel%mycolgroup
        jendloc =     elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*(parallel%mycolgroup + 1)

        if (elec_st%cplx) then
                do jcol = 1, elec_st%nstate
                        if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                            elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then

                                znorm = zdotc(parallel%mydim*elec_st%mxwd, &
elec_st%eig(irp,kplp,isp)%zwf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1, &
elec_st%eig(irp,kplp,isp)%zwf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1)
                        else
                                znorm = zzero
                        endif

                        call zpsum(znorm, 1, parallel%procs_num, &
                                parallel%comm)

                        if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                            elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then
                                znorm = zone/sqrt(znorm)

                                call zscal(parallel%mydim*elec_st%mxwd, znorm, &
elec_st%eig(irp,kplp,isp)%zwf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1)
                        endif
                enddo

        else
                do jcol = 1, elec_st%nstate
                        if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                            elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then

                                dnorm = ddot(parallel%mydim, &
elec_st%eig(irp,kplp,isp)%wf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1, &
elec_st%eig(irp,kplp,isp)%wf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1)
                        else
                                dnorm = dzero
                        endif

                        call psum(dnorm, 1, parallel%procs_num, parallel%comm)

                        if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                            elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then
                                dnorm = one/sqrt(dnorm)

                                call dscal(parallel%mydim, dnorm, &
elec_st%eig(irp,kplp,isp)%wf(1,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1), 1)
                        endif
                enddo
        endif

end subroutine renormalize_wfns




end subroutine eigval












!===============================================================
!
! For a given set of eigenvalues (for all representations), sort
! them in ascending order. Use straight insertion, no need for
! fancy algorithms since the arrays are always "short".
!
! \todo AJB: "always"
!
!---------------------------------------------------------------
subroutine eigen_sort(elec_st, isp, kplp, nmax, nrep, nrep_add, irep)

use constants
use electronic_struct_module

implicit none


!
! Input/Output variables:
!

! electronic structure
type(electronic_struct), intent(in) :: elec_st

! spin orientation
integer, intent(in) :: isp

! kpoint
integer, intent(in) :: kplp

! size of representation array
integer, intent(in) :: nmax

! lowest number of states for each representation, such that the
! total sums up to (elec_st%nstate-1) after eigenvalues are sorted
integer, intent(out) :: nrep(elec_st%nrep)

! number of additional states on each representation, after
! removing the first (elec_st%nstate-1) ones
integer, intent(out) :: nrep_add(elec_st%nrep)

! representation array, irep(i) = 0 for i > sum( nrep_add + nrep )
integer, intent(out) :: irep(nmax)



!
! Work variables:
!
! counters, temporary variables
integer :: irp
integer :: jj
integer :: ntotal
integer :: tmp_order
real(dp) :: tmp_energy
integer :: istate
integer :: nstates_to_be_sorted

! temporary arrays: representation, order index, eigenvalues
integer, dimension(:), allocatable :: rep_tmp
integer, dimension(:), allocatable :: ord_tmp
real(dp), dimension(:), allocatable :: eig_tmp

! ---------------------------------------------------------------


ntotal = 0

do jj = 1, size(elec_st%eig(:,kplp,isp))
        ntotal = ntotal + elec_st%eig(jj,kplp,isp)%nn
enddo

allocate(eig_tmp(ntotal))
allocate(rep_tmp(ntotal))
allocate(ord_tmp(ntotal))



nstates_to_be_sorted = 0
do irp = 1, elec_st%nrep
do istate = 1, elec_st%eig(irp,kplp,isp)%nn
        nstates_to_be_sorted = nstates_to_be_sorted + 1
        eig_tmp(nstates_to_be_sorted) = elec_st%eig(irp,kplp,isp)%en(istate)
        rep_tmp(nstates_to_be_sorted) = irp
        ord_tmp(nstates_to_be_sorted) = istate
enddo
enddo




! KHL: Bubble sort
!      After this loop, eig_tmp(:) will be in ascending order.
!      That is, eig_tmp(1) is the smallest eigenvalue.
do istate = 2, nstates_to_be_sorted
        tmp_energy = eig_tmp(istate)
        irp = rep_tmp(istate)
        tmp_order = ord_tmp(istate)

        do jj = istate-1, 1, -1
                if (eig_tmp(jj) <= tmp_energy) goto 10

                eig_tmp(jj+1) = eig_tmp(jj)
                rep_tmp(jj+1) = rep_tmp(jj)
                ord_tmp(jj+1) = ord_tmp(jj)
        enddo

        jj = 0

10 continue

        eig_tmp(jj+1) = tmp_energy
        rep_tmp(jj+1) = irp
        ord_tmp(jj+1) = tmp_order
enddo




! KHL: I modified this part, so that nstates_per_colgroup will not 
!      be changed. That is, the number of states to be computed will
!      be fixed, and in parsec.in we need to use a bigger states_num 
!      in order to make sure each representation has computed 
!      enough number of states and no valence states are missed.
nrep(:) = 0
irep(:) = 0
do istate = 1, elec_st%nstate
        irep(istate) = rep_tmp(istate)
        nrep(irep(istate)) = nrep(irep(istate)) + 1
enddo

nrep_add(:) = 0

deallocate(eig_tmp)
deallocate(rep_tmp)
deallocate(ord_tmp)

end subroutine eigen_sort




!===============================================================
!
! Adjust size of eigenstate arrays.
!
!---------------------------------------------------------------
subroutine eig_adj_size(eigen, ldn, new_nstates_per_colgroup, &
        winsize, npcol, cplx)

use constants
use electronic_struct_module
implicit none


!
! Input/Output variables:
!
! eigenstates
type(eigenstates), intent(inout) :: eigen

! size of grid local to this processor (i.e. local number of rows)
integer, intent(in) :: ldn

! new size of arrays
integer, intent(in) :: new_nstates_per_colgroup

integer, intent(in) :: winsize
integer, intent(in) :: npcol

! real/complex flag
logical, intent(in) :: cplx




!
! Work variables:
!
! allocation flag
integer :: alcstat

! old size of arrays
integer :: old_nstates_per_colgroup_max

integer :: new_nstates_per_colgroup_max
integer :: old_nstates


! work integers
integer :: jcol
integer :: irow

! buffer arrays for eigenvectors, eigenvalues, occupancy factors
! these should be aligned because of the -align compiler flag
real(dp), dimension(:), allocatable :: eig_buff
real(dp), dimension(:), allocatable :: occ_buff
real(dp), dimension(:,:), allocatable :: wf_buff
complex(dpc), dimension(:,:), allocatable :: zwf_buff
logical :: save_flag

! --------------------------------------------------------------

old_nstates_per_colgroup_max = eigen%nstates_per_colgroup_max
new_nstates_per_colgroup_max = new_nstates_per_colgroup + winsize

write(9,*) 'eig_adj_size'
write(9,*) 'old_nstates_per_colgroup_max', old_nstates_per_colgroup_max
write(9,*) 'new_nstates_per_colgroup_max', new_nstates_per_colgroup_max

! If new_size is smaller than old_size, do nothing.
if (old_nstates_per_colgroup_max >= new_nstates_per_colgroup_max) return


write(9,*) 'changing the size of the wave functions...'


!
! If the structure already has some data, save it in temporary arrays.
!
if (allocated(eigen%en)) then
        old_nstates = size(eigen%en)

        allocate(eig_buff(old_nstates))
        allocate(occ_buff(old_nstates))

        if (cplx) then
                allocate(zwf_buff(ldn,old_nstates_per_colgroup_max), &
                        stat=alcstat)
                call alccheck('zwf_buff', ldn*old_nstates_per_colgroup_max, &
                        alcstat)
        else
                allocate(wf_buff(ldn,old_nstates_per_colgroup_max), &
                        stat=alcstat)
                call alccheck('wf_buff', ldn*old_nstates_per_colgroup_max, &
                        alcstat)
        endif

        do jcol = 1, old_nstates
                eig_buff(jcol) = eigen%en(jcol)
        enddo

        do jcol = 1, old_nstates
                occ_buff(jcol) = eigen%occ(jcol)
        enddo

        if (cplx) then
                do jcol = 1, old_nstates_per_colgroup_max
                do irow = 1, ldn
                        zwf_buff(irow,jcol) = eigen%zwf(irow,jcol)
                enddo
                enddo
        else
                do jcol = 1, old_nstates_per_colgroup_max
                do irow = 1, ldn
                        wf_buff(irow,jcol) = eigen%wf(irow,jcol)
                enddo
                enddo
        endif

        save_flag = .true.
else
        save_flag = .false.
endif



!
! Now, reallocate arrays.
!
call destroy_eigenstate(eigen)



call create_eigenstate(eigen=eigen, ldn=ldn, &
        nstates_per_colgroup=new_nstates_per_colgroup, &
        winsize=winsize, npcol=npcol, cplx=cplx)



!
! Transfer information from old arrays to resized arrays.
!
if (save_flag) then
        do jcol = 1, old_nstates
                eigen%en(jcol) = eig_buff(jcol)
        enddo

        do jcol = 1, old_nstates
                eigen%occ(jcol) = occ_buff(jcol)
        enddo

        if (cplx) then
                do jcol = 1, old_nstates_per_colgroup_max
                do irow = 1, ldn
                        eigen%zwf(irow,jcol) = zwf_buff(irow,jcol)
                enddo
                enddo

                deallocate(zwf_buff)
        else
                do jcol = 1, old_nstates_per_colgroup_max
                do irow = 1, ldn
                        eigen%wf(irow,jcol) = wf_buff(irow,jcol)
                enddo
                enddo

                deallocate(wf_buff)
        endif

        deallocate(occ_buff)
        deallocate(eig_buff)
endif

end subroutine eig_adj_size





!===============================================================
!
! Adjust size of eigenstate arrays.
!
!---------------------------------------------------------------
subroutine eig_e_adj_size(eigen, new_size)

use constants
use electronic_struct_module

implicit none

!
! Input/Output variables:
!

! eigenstates
type(eigenstates), intent(inout) :: eigen

! new size of arrays
integer, intent(in) :: new_size

!
! Work variables:
!

! old size of arrays
integer :: old_size

! number of saved states (useful if old_size > new_size)
integer :: nn

! buffer arrays for eigenvectors, eigenvalues, occupancy factors
real(dp), dimension(:), allocatable :: eig_buff
real(dp), dimension(:), allocatable :: occ_buff
logical :: save_flag

! ---------------------------------------------------------------

old_size = 0

if (allocated(eigen%en)) old_size = size(eigen%en)

! If new_size is smaller than old_size, do nothing.
if (old_size >= new_size) return




!
! If the structure already has some data, save it in temporary arrays.
!
if (allocated(eigen%en)) then
        nn = min(old_size, new_size)

        allocate(eig_buff(nn))
        eig_buff(1:nn) = eigen%en(1:nn)

        allocate(occ_buff(nn))
        occ_buff(1:nn) = eigen%occ(1:nn)

        save_flag = .true.
else
        save_flag = .false.
endif



!
! Now, reallocate arrays.
!
if (allocated(eigen%en)) deallocate(eigen%en)
if (allocated(eigen%occ)) deallocate(eigen%occ)


if (new_size == 0) then
        if (save_flag) then
                deallocate(eig_buff)
                deallocate(occ_buff)
        endif

        return
endif

allocate(eigen%en(new_size))
eigen%en = zero

allocate(eigen%occ(new_size))
eigen%occ = zero



!
! Transfer information from old arrays to resized arrays.
!
if (save_flag) then
        eigen%en(1:nn) = eig_buff(1:nn)
        eigen%occ(1:nn) = occ_buff(1:nn)
        deallocate(eig_buff)
        deallocate(occ_buff)
endif

end subroutine eig_e_adj_size






!===============================================================
!
! Initialize various arrays and variables before any eigensolver
! is called. This used to be performed at the beginning of
! subroutine eigval.F. (now called in calc_nscf.F90 and parsec.F90)?
!
!---------------------------------------------------------------
subroutine initeigval(elec_st)

use constants
use electronic_struct_module
use eigen_solver_module
use parallel_data_module
implicit none

! Input/Output variables:

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! Work variables:
integer :: kpnum, spnum, kplp, isp, ntotal, itmp, irp

!---------------------------------------------------------------

kpnum = max(elec_st%nkpt,1)
spnum = elec_st%nspin/elec_st%mxwd

! assume a "blind guess" for the number of eigenstates to be
! computed; later, nn will be dynamically adjusted

#ifndef FERMIBETA
! \todo AJB: moved back by Yunkai, change protected by BETA flag
! If I am not mistaken, placing this line here will hurt any
! attempt of doing kpoints with representations,
! and will also have an effect on calculation with spin>1 and mxwd=1
ntotal = 0
#endif

do isp = 1, spnum
do kplp = 1, kpnum               

#ifdef FERMIBETA
        ntotal = 0 ! I moved this line up .. (YKZ: you better not)
#endif

        do irp = 1, elec_st%nrep
                ntotal = ntotal + elec_st%eig(irp,kplp,isp)%nec
        enddo

        if (ntotal < elec_st%nstate) then
                do irp = 1, elec_st%nrep
                        itmp = elec_st%nstate/elec_st%nrep

                        if (elec_st%eig(irp,kplp,isp)%nn < itmp) then
                                elec_st%eig(irp,kplp,isp)%nn = itmp
                        endif
                enddo

                elec_st%ntotal(isp) = elec_st%nstate
        endif

        ! calculate at least one eigenvector
        do irp = 1, elec_st%nrep
                if (elec_st%eig(irp,kplp,isp)%nn == 0) then
                        elec_st%eig(irp,kplp,isp)%nn = 1
                endif
        enddo
enddo
enddo

return

end subroutine initeigval
!===============================================================
end module eigval_module
