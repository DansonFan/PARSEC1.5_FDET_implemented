module setup_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  Setup a uniform, real space grid, composed of a boundary sphere
!  inside a rectangular box. 
!
!  NOTE:
!  Other geometries (e.g., an individual sphere around each atom)
!  may be attempted. They are not implemented in the current
!  version. Their addition may require adding additional tests to
!  isolat.f (see comment there).
!
!---------------------------------------------------------------
subroutine setup(grid, pbc, rsymm, parallel, nspin, kpnum, ierr)

use constants
use grid_module
use pbc_module
use symmetry_module
use parallel_data_module
use block_neib
use grid_partition_module, only : grid_partition
use comm_neigh_module, only : comm_neigh

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, mpi_double_precision
#else
use mpi
#endif
#endif

implicit none

!
!  Input/Output variables:
!
!  grid related data
type(grid_data), intent(inout) :: grid

!  periodic boundary conditions data
type(pbc_data), intent(inout) :: pbc

!  symmetry operations in reduced (Abelian) group
type(symmetry), intent(in) :: rsymm

!  parallel computation related data
type(parallel_data), intent(inout) :: parallel

!  number of spins
integer, intent(in) :: nspin

!  number of k-points (or 1, if there are no k-points)
integer, intent(in) :: kpnum

!  error flag
integer, intent(inout) :: ierr

!
!  Work variables:
!

!  number of procs available, node index
integer :: nnodes, inode

!  rank of the master in the above communicator
integer :: masterid

integer :: neibs_num, icount, nelem, mxelem, alcstat

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif
#endif

! ---------------------------------------------------------------


! Create groups of processors.
call create_group_layout_2d(parallel, rsymm%ntrans*nspin*kpnum)

nnodes   = parallel%nprow
masterid = parallel%colgroup_masterid
!comm     = parallel%colgroup_comm

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif



! Create communicator arrays.
allocate(parallel%irows(0:nnodes))
allocate(parallel%irecvp(0:nnodes))
allocate(parallel%jsendp(0:nnodes))
allocate(parallel%cirows(0:nnodes))
allocate(parallel%c_irecvp(0:nnodes))
allocate(parallel%c_jsendp(0:nnodes))
















! ================================================================
!  Construct regular grid, irreducible wedge, and partition.
! ================================================================
if (parallel%iam_colgroup_master) then
        call grid_partition(grid, pbc, rsymm, parallel, ierr)
endif

if (ierr /= 0) then
        if (parallel%iammaster) then
                write(7,*) 'Error in grid_partition. Stop!'
        endif

        write(9,*) "Setup(), ierr", ierr
        return
endif








#ifdef MPI
! ================================================================
!  Broadcast Partitioning Information and PBC parameters
! ================================================================
call MPI_Bcast(parallel%ndim,     1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(parallel%ldn,      1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(parallel%nwedge,   1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(parallel%nwedge_c, 1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(parallel%irows(0),  nnodes+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(parallel%cirows(0), nnodes+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(pbc%mx,       1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(pbc%my,       1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(pbc%mz,       1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(pbc%shift(1), 3, MPI_DOUBLE_PRECISION, masterid, &
        colgroup_comm_f08, mpinfo)

! ================================================================
! broadcast grid neighbors dimensions
! ================================================================
call MPI_Bcast(grid%neibs_num, 1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nxyz,      1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
#endif








! ================================================================
!  define local dimension mydim
! ================================================================
parallel%mydim = parallel%irows(parallel%colgroup_iam+1) - &
        parallel%irows(parallel%colgroup_iam)
parallel%mycdim = parallel%cirows(parallel%colgroup_iam+1) - &
        parallel%cirows(parallel%colgroup_iam)

!todo - change ldn to mydim here:
allocate(parallel%pint(parallel%ldn), stat=alcstat)
call alccheck('parallel%pint', parallel%ldn, alcstat)

allocate(parallel%senrows(parallel%nwedge), stat=alcstat)
call alccheck('parallel%senrows', parallel%nwedge, alcstat)

!how did you get here?
! allocate(parallel%c_senblocks(parallel%nwedge_c),stat=alcstat)
! call alccheck('parallel%c_senblocks',parallel%nwedge_c,alcstat)
!

neibs_num = 6 + 2*grid%lap_dir_num

allocate(parallel%neibs(neibs_num*grid%norder,parallel%mydim), stat=alcstat)
call alccheck('parallel%neibs', neibs_num*grid%norder*parallel%mydim, alcstat)
parallel%neibs(:,:) = 0

allocate(parallel%tneibs(neibs_num*grid%norder,parallel%mydim), stat=alcstat)
call alccheck('parallel%tneibs', neibs_num*grid%norder*parallel%mydim, alcstat)
parallel%tneibs(:,:) = 0

if (.not. parallel%iamgmaster) then
        grid%nwedge = parallel%nwedge
        grid%nwedge_c = parallel%nwedge_c
        call grid_set_wedge(grid)
endif







write(9,*) 'BCAST BLOCK I'
#ifdef MPI
call MPI_Bcast(grid%kx(1),      grid%nwedge, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%ky(1),      grid%nwedge, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%kz(1),      grid%nwedge, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%kcx(1),   grid%nwedge_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%kcy(1),   grid%nwedge_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%kcz(1),   grid%nwedge_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%c2k(1), grid%nwedge_c+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
#endif





write(9,*) 'BCAST BLOCK II'
#ifdef MPI
call MPI_Bcast(grid%nxmax,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nxmin,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nymax,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nymin,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nzmax,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%nzmin,  1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%n1,     1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%n2,     1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%n3,     1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%ndim,   1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%ndim_c, 1, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
#endif




if (.not. parallel%iamgmaster) then
        call grid_set_ndim(grid, ndim=grid%ndim, ndim_c=grid%ndim_c)
        call grid_set_conversion(grid)
endif





write(9,*) 'BCAST BLOCK III'
#ifdef MPI
call MPI_Bcast(grid%rindex(1), grid%ndim+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%rtrans(1), grid%ndim+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%fx(1),       grid%ndim, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%fy(1),       grid%ndim, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%fz(1),       grid%ndim, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%cx(1),     grid%ndim_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%cy(1),     grid%ndim_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%cz(1),     grid%ndim_c, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
call MPI_Bcast(grid%c2f(1),  grid%ndim_c+1, MPI_INTEGER, masterid, &
        colgroup_comm_f08, mpinfo)
#endif






! ================================================================
! Create the neighbor array
! ================================================================
! step 1 - temporarily store indexg on each PE
if (.not. parallel%iamgmaster) then

        allocate(grid%indexg(grid%nxmin:grid%nxmax, &
                             grid%nymin:grid%nymax, &
                             grid%nzmin:grid%nzmax), stat=alcstat)
        call alccheck('indexg', grid%nxyz, alcstat)

        ! if(grid%hartree_neibs_flag) then
        !  allocate (grid%neibs_index (grid%nxmin:grid%nxmax, &
        !                              grid%nymin:grid%nymax, &
        !                              grid%nzmin:grid%nzmax), &
        !                              stat=alcstat)
        !  call alccheck('neibs_index',grid%nxyz,alcstat)
        ! endif
endif

#ifdef MPI
call MPI_Bcast(grid%indexg(grid%nxmin,grid%nymin,grid%nzmin), &
        grid%nxyz, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
#endif


! step 2 - calculate neibs 
call calc_my_neibs(parallel, grid)

! experimental - calculate c_neibs
if (grid%lap_dir_num == 0) then
        call calc_my_cneibs(parallel, grid)
endif





!  Master PE broadcasts indexw
if (.not. parallel%iamgmaster) then
        deallocate(grid%indexg)

        allocate(grid%indexw(grid%nxmin:grid%nxmax, &
                             grid%nymin:grid%nymax, &
                             grid%nzmin:grid%nzmax), stat=alcstat)
        call alccheck('indexw', grid%nxyz, alcstat)
endif

#ifdef MPI
call MPI_Bcast(grid%indexw(grid%nxmin,grid%nymin,grid%nzmin), &
        grid%nxyz, MPI_INTEGER, masterid, colgroup_comm_f08, mpinfo)
! if(grid%hartree_neibs_flag) call MPI_BCAST(grid%neibs_index,grid%nxyz,MPI_INTEGER,masterid,comm,mpinfo)
#endif






write(9,*) 'The local dimension is :', parallel%mydim

parallel%lap_dir_num = grid%lap_dir_num
!AJB: might as well remove this someday
! write(9,*) "before comm_neib"
! write(9,*) "parallel%neibs(:,1):"
! write(9,*)  parallel%neibs(:,1)
! write(9,*) "grid%c2f(parallel%c_neibs(:,1):"
! write(9,*)  grid%c2f(parallel%c_neibs(:,1))
! write(9,*) "parallel%c_neibs(:,1):"
! write(9,*)  parallel%c_neibs(:,1)

!  Find boundary information for exchange
call comm_neigh(parallel, grid%norder)





! new stuff:
if (grid%lap_dir_num == 0) then
        call comm_cneib(parallel, norder=grid%norder, &
                blocksizes=grid%fold%blocksize(1))
        !
        ! it is a good idea to test neib and cneib here:
        ! write(9,*) "after comm_neib"
        !  write(9,*) "parallel%neibs(:,1):"
        !  write(9,*)  parallel%neibs(:,1)
        !  write(9,*) "grid%c2f(parallel%c_neibs(:,1):"
        !  write(9,*)  grid%c2f(parallel%c_neibs(:,1))
        !  write(9,*) "parallel%c_neibs(:,1):"
        !  write(9,*)  parallel%c_neibs(:,1)

        ! now for the interesting things:
        mxelem = maxval(grid%norder/grid%fold%blocksize(:))

        call convert_to_graphs(parallel, folded_stencil_depth=mxelem)

        ! no need for you anymore
        deallocate(parallel%c_neibs)
endif !lap_dir_num == 0 - since I still have not figured out what to do with extra dirs now



write(9,*) 'Information to be sent to neighbors:'

icount = 0
mxelem = 0

do inode = 0, nnodes-1
        nelem = parallel%jsendp(inode+1) - parallel%jsendp(inode)
        write(9,*) 'send PE ', inode, ' #rows:', nelem
        mxelem = mxelem + nelem
        if (nelem /= 0) icount = icount +1
enddo

parallel%maxcomm   = mxelem
parallel%countcomm = icount
parallel%maxcomm2  = parallel%irecvp(nnodes) - parallel%irecvp(0)

write(9,*) 'I communicate with ', icount, &
        ' processors, a total of ', parallel%maxcomm, ' elements'
write(9,*) 'Also, I receive from these procs: ', &
        parallel%maxcomm2, ' elements'
write(9,*) 'my workvector has thus  ', parallel%myworkdim, ' elements'





#ifdef MPI
!  create the graph communicator and update local comm data
write(9,*) 'calling topo aware'
write(9,*) ''
call topo_aware(parallel) 
write(9,*) 'done topo aware'


write(9,*) "COMMDEBUG:"
write(9,*) "irecvp:"
write(9,*) parallel%irecvp(:)
write(9,*) "c_irecvp:"
write(9,*) parallel%c_irecvp(:)
write(9,*) "jsendp:"
write(9,*) parallel%jsendp(:)
write(9,*) "c_jsendp:"
write(9,*) parallel%c_jsendp(:)
write(9,*) "parallel%sdispls:"
write(9,*) parallel%sdispls(:)
write(9,*) "parallel%c_sdispls"
write(9,*) parallel%c_sdispls(:)
write(9,*) "END COMMDEBUG:"



#endif


end subroutine setup
!===============================================================
end module setup_module
