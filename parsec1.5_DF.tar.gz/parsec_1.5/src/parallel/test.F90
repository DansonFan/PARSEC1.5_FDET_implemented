!===============================================================
!!
!> \copyright Copyright (C) 2018 Finite Difference Research Group
!! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!!
!> \brief  Represent test logic
!> \author Charles Lena
!!
!---------------------------------------------------------------
module test_module
! test logic options
   integer, parameter :: k_test_none = 0 
   integer, parameter :: k_test_forces= 1
   integer, parameter :: k_test_lanczos= 2

   type tests_data
      integer :: logic = k_test_none
      contains
      procedure :: bcast => bcast_tests
   endtype tests_data
contains
   subroutine bcast_tests(tests, masterid, comm, mpinfo)

#ifdef MPI
#ifdef WITH_MPI_F08
      use mpi_f08, only : mpi_comm, mpi_bcast, mpi_logical
#else
        use mpi
#endif
#endif
      class(tests_data), intent(inout) :: tests

      integer, intent(in) :: comm !< integer mpi_comm
      integer, intent(in) :: masterid !< mpi_rank
      integer, intent(out) :: mpinfo !< error code

#ifdef MPI
#ifdef WITH_MPI_F08
      type(mpi_comm) :: comm_f08 !< actual mpi_comm
#else
      integer :: comm_f08 !< actual mpi_comm
#endif
#endif

#ifdef MPI
#ifdef WITH_MPI_F08
        comm_f08%mpi_val = comm
#else
        comm_f08 = comm
#endif
#endif

      call MPI_BCAST(tests%logic,1,MPI_LOGICAL,masterid,comm_f08,mpinfo)
   end subroutine bcast_tests
end module
