! ==================== parallel data structure ==================
module parallel_data_module !{{{

use constants, only : dp, dpc

#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_max_processor_name
#else
use mpi
#endif

implicit none

type parallel_data

        ! total number of processors
        integer :: procs_num

        ! ID of master
        integer :: masterid

        ! name of node
        character(mpi_max_processor_name) :: core_name

        ! true for master processor, false for all other ones
        logical :: iammaster

        ! rank of all the processors in the groups
        integer :: iam

        ! communicator for inter-processor communication
        integer :: comm

        ! handle of the world group (containing all processors)
        integer :: world_handle

        ! total number of groups
        integer :: groups_num

        ! number of processors per group ( group_size * groups_num = procs_num)
        integer :: group_size

        ! order of group to which each processor belongs to
        integer :: mygroup

        ! true for the master processors of this group (each group has one
        ! and only one master)
        logical :: iamgmaster

        ! rank of the master processor of this group
        integer :: group_master

        ! rank of processors within a group
        integer :: group_iam

        ! handle of a group
        integer :: group_handle

        ! communicator within a group
        integer :: group_comm

        ! optimized comm for matvec
        integer :: colgroup_comm_topo

        ! optimized comm for the block folded matvec
        integer :: colgroup_comm_c_topo

        ! mpi type for the fold (created)
        integer :: c_fold_type

        ! always real mpi type for the fold in charge density (created)
        integer :: c_fold_rho

        ! plan of the groups: all processors belonging to j-th group
        ! have parallel%iam = parallel%gmap(parallel%group_iam,j)
        integer, dimension(:,:,:), allocatable :: gmap

        ! rank of processors in the group of masters
        integer :: gmaster_iam

        ! handle of the group of masters
        integer :: gmaster_handle

        ! communicator in the group of masters
        integer :: gmaster_comm

        ! actual size of hamiltonian
        integer :: ndim, nwedge, nwedge_c

        ! local size of hamiltonian (equal to number of grid points
        ! held by each processor)
        integer :: mydim, mycdim, myworkdim, mycworkdim, buffdim

        ! dimension of distributed grid arrays; in order to account
        ! for points outside the domain, choose ldn > max(numb)
        integer :: ldn

        ! When including spin-orbit interaction, 
        !      ldn_full = 2*ldn and mydim_full = 2*mydim
        ! The size of the first dimension of the wave functions would
        ! be [1, ..., mydim, mydim+1, ..., mydim_full, mydim_full+1, ..., ldn_full]
        ! in which its tail [mydim_full+1, ..., ldn_full] should not be used and 
        ! had better to be set __t_zero at all times
        !
        ! When no spin-orbit interaction,
        !      ldn_full = ldn and mydim_full = mydim
        ! So the size of the first dimension of the wave functions would also
        ! be [1, ..., mydim, mydim+1, ..., ldn]. That is, in this case it is
        ! the same as [1, ..., mydim_full, mydim_full+1, ..., ldn_full]
        integer :: ldn_full
        integer :: mydim_full

        ! alias for grid%lap_dir_num
        integer :: lap_dir_num

        ! work array for functions on the irreducible wedge,
        ! allocated by master PE only!
        real(dp), dimension(:), allocatable :: ftmp
        complex(dpc), dimension(:), allocatable :: zftmp

        ! Position of the first block of rows (=points in irreducible
        ! wedge) that each processor holds. The number of rows in
        ! processor ipe is irows(ipe+1)-irows(ipe). Global
        integer, dimension(:), allocatable :: irows
        integer, dimension(:), allocatable :: cirows

        ! arrays for inter-processor communication
        ! they are all local (i.e., different values on different procs)
        ! see more about the meaning of these variables in comm_neigh.F
        integer, dimension(:), allocatable :: irecvp
        integer, dimension(:), allocatable :: jsendp
        integer, dimension(:), allocatable :: c_irecvp
        integer, dimension(:), allocatable :: c_jsendp
        integer, dimension(:), allocatable :: senrows
        integer, dimension(:), allocatable :: c_senblocks
        integer, dimension(:), allocatable :: pint
        integer :: inter1

        ! neighbor points to each point belonging to a computing PE;
        ! this index array indicates the position, in the 1-d array, 
        ! of the ith neighbor of point j (i from 1 to norder*3, because
        ! there are three directions, j from 1 to ndim). used for
        ! calculating derivatives; notice that neibs points to the
        ! index in irreducible wedge, not full grid!
        ! c_neibs is the same only for the folded grid
        integer, dimension(:,:), allocatable :: neibs
        integer, dimension(:,:), allocatable :: c_neibs

        ! index array indicating the symmetry operation needed to
        ! bring this neighor point back to the irreducible wedge
        ! NOTE: tneibs should be used whenever generic functions are
        ! evaluated at a neighbor point, with the exception of totally
        ! symmetric functions (like charge density, potentials etc.);
        ! that is because totally symmetric functions have character one
        ! (i.e., they do not gain phase factors upon a symmetry operation)
        ! c_tneibs is the same only for the folded grid
        integer, dimension(:,:), allocatable :: tneibs
        integer, dimension(:,:), allocatable :: c_tneibs

        ! local size for communication buffers (edges,size of send,size of receive)
        integer :: countcomm, maxcomm, maxcomm2

        ! local size for communication buffers for blocks:
        integer :: numedges, c_maxcomm, c_maxcomm2

        ! local information about communication:
        integer, allocatable, dimension(:) :: sources, destinations, &
                sendcounts,recvcounts,rdispls,sdispls

        ! for blocked communication using the conitg. data type: 
        integer, allocatable, dimension(:) :: c_sources, c_destinations, &
                c_sendcounts,c_recvcounts,c_rdispls,c_sdispls

        !info about laplacian buffers used for communication:
        integer :: max_lap_buffers

        ! additional spin dimension of wave-function due to spin-orbit
        ! and\or non-collinear states
        integer :: nshift

        integer :: mytaskgroup, myoverallrowgroup, mycolgroup, myrowgroup
        integer :: taskgroup_comm, overallrowgroup_comm, colgroup_comm, &
                rowgroup_comm
        integer :: taskgroups_num, nprow, npcol, procs_per_task
        integer :: taskgroup_iam, overallrowgroup_iam, colgroup_iam, &
                rowgroup_iam

        integer :: taskgroup_masterid, overallrowgroup_masterid, &
                colgroup_masterid, rowgroup_masterid

        logical :: iam_taskgroup_master, iam_colgroup_master, &
                iam_rowgroup_master, iam_overallrowgroup_master

        !integer :: nstates_evec_loc

        ! additional spin dimension of wave-function
        ! due to spin-orbit and\or non-collinear states
        integer :: mxwd

        contains
                procedure, pass :: create_fold_mpi_type
end type parallel_data

contains






subroutine destroy_parallel_data(parallel)
        implicit none
        type(parallel_data), intent(inout) :: parallel

        if (allocated(parallel%irows))       deallocate(parallel%irows)
        if (allocated(parallel%cirows))      deallocate(parallel%cirows)
        if (allocated(parallel%ftmp))        deallocate(parallel%ftmp)
        if (allocated(parallel%zftmp))       deallocate(parallel%zftmp)
        if (allocated(parallel%irecvp))      deallocate(parallel%irecvp)
        if (allocated(parallel%jsendp))      deallocate(parallel%jsendp)
        if (allocated(parallel%c_irecvp))    deallocate(parallel%c_irecvp)
        if (allocated(parallel%c_jsendp))    deallocate(parallel%c_jsendp)
        if (allocated(parallel%senrows))     deallocate(parallel%senrows)
        if (allocated(parallel%c_senblocks)) deallocate(parallel%c_senblocks)
        if (allocated(parallel%pint))        deallocate(parallel%pint)
        if (allocated(parallel%neibs))       deallocate(parallel%neibs)
        if (allocated(parallel%tneibs))      deallocate(parallel%tneibs)
        if (allocated(parallel%c_neibs))     deallocate(parallel%c_neibs)
        if (allocated(parallel%c_tneibs))    deallocate(parallel%c_tneibs)
        if (allocated(parallel%gmap))        deallocate(parallel%gmap)
end subroutine destroy_parallel_data







subroutine create_parallel_data(parallel)

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_thread_multiple, mpi_thread_funneled, &
        mpi_thread_serialized, mpi_thread_single, &
        mpi_init_thread, mpi_abort, mpi_comm_world, &
        mpi_comm_size, mpi_comm_rank, mpi_get_processor_name, mpi_comm
#else
use mpi
#endif
#endif

implicit none
type(parallel_data), intent(out) :: parallel

#ifdef MPI
integer :: l_core_name
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

! check for required thread support
integer :: thread_provided
integer :: thread_requested

! ------------------------------------------------

#if _OPENMP && MPI


#if defined(THREAD_MULTIPLE) || (FALSE_THREAD_MULTIPLE) 
thread_requested = mpi_thread_multiple
#else
!thread_requested = mpi_thread_funneled
thread_requested = mpi_thread_serialized
#endif


#elif MPI


thread_requested = mpi_thread_single


#endif






#ifdef MPI

! Initialise MPI, get size and my id, create communicator
call mpi_init_thread(thread_requested, thread_provided, mpinfo)

if (thread_provided < thread_requested) then
        write(7,*) 'Error: MPI init does not support &
                &requested thread level '
        call mpi_abort(mpi_comm_world, -1, mpinfo)
endif

comm_f08 = mpi_comm_world

#ifdef WITH_MPI_F08
parallel%comm = comm_f08%mpi_val
#else
parallel%comm = comm_f08
#endif

call mpi_comm_size(comm_f08, parallel%procs_num, mpinfo)
call mpi_comm_rank(comm_f08, parallel%iam, mpinfo)
call mpi_get_processor_name(parallel%core_name, l_core_name, mpinfo)
parallel%core_name = adjustl(parallel%core_name(1:l_core_name))

#else

! For a non-MPI calculation, define degenerate environment
parallel%comm = 0
parallel%procs_num = 1
parallel%iam = 0
parallel%core_name = ''

#endif

! zero stuff for saftey:
parallel%colgroup_comm_topo = 0
parallel%colgroup_comm_c_topo = 0
parallel%c_fold_type = 0
parallel%masterid = 0

if (parallel%masterid == parallel%iam) then
        parallel%iammaster = .true.
else
        parallel%iammaster = .false.
endif

parallel%nshift = 1

end subroutine create_parallel_data




#ifdef ITAC
!=============================Intel TraceAnalyzer API ======================================
  subroutine init_trace_data (vtierr) !{{{
      implicit none
    include 'VT.inc'
    include 'vtcommon.inc'
      integer vtierr
      vtierr = 0
!define the classes of state handles
      call VTCLASSDEF( 'Contexts',      main_class ,vtierr )
      call VTCLASSDEF( 'Matvec',     matvec_class ,vtierr )
      call VTCLASSDEF( 'Solvers',     solver_class ,vtierr )
      call VTCLASSDEF( 'Workers',     worker_class ,vtierr )
      call VTCLASSDEF( 'Comm',     comm_class ,vtierr )

!define basic states handles

call VTFUNCDEF( 'H_nl.p'        , matvec_class, vt_matvec_ps , vtierr          )
call VTFUNCDEF( 'Lap.my'        , matvec_class, vt_lap_inner, vtierr           )
call VTFUNCDEF( 'Lap.ghost'     , matvec_class, vt_lap_outer, vtierr           )
call VTFUNCDEF( 'Gradient'      , matvec_class, vt_grad, vtierr           )
call VTFUNCDEF( 'Diagonal'      , matvec_class, vt_matvec_diag, vtierr             )
call VTFUNCDEF( 'Stencil.my'    , matvec_class, vt_matvec_inner, vtierr             )
call VTFUNCDEF( 'Stencil.ghost' , matvec_class, vt_matvec_outer, vtierr             )
call VTFUNCDEF( 'MATVEC-IDLE'   , matvec_class, vt_mvecidle, vtierr             )
call VTFUNCDEF( 'NOT USED'      , comm_class, vt_bdxc , vtierr                 )
call VTFUNCDEF( 'Buffering'     , comm_class, vt_buffer , vtierr              )
call VTFUNCDEF( 'Prebuffering'  , comm_class, vt_prebuffer , vtierr              )
call VTFUNCDEF( 'ARPACK'        , solver_class, vt_arpack, vtierr              )
call VTFUNCDEF( 'CHEBDAV'       , solver_class, vt_chebdav , vtierr            )
call VTFUNCDEF( 'CHEBFF'        , solver_class, vt_chebff, vtierr              )
call VTFUNCDEF( 'SUBSPACE'      , solver_class, vt_subspace , vtierr           )
call VTFUNCDEF( 'Spin-Orbit?'   , solver_class, vt_so, vtierr                  )
call VTFUNCDEF( 'Lanczos'       , worker_class, vt_lancz, vtierr               )
call VTFUNCDEF( 'Filter'        , worker_class, vt_filter , vtierr            )
call VTFUNCDEF( 'Orthnormal'    , worker_class, vt_orth , vtierr              )
call VTFUNCDEF( 'Project'       , worker_class, vt_proj, vtierr            )
call VTFUNCDEF( 'Decomp'        , worker_class, vt_decomp , vtierr            )
call VTFUNCDEF( 'Update'        , worker_class, vt_update, vtierr             )
call VTFUNCDEF( 'ARPACK-work'   , worker_class, vt_naupd, vtierr               )
call VTFUNCDEF( 'ARPACK-post'   , worker_class, vt_seupd, vtierr               )
call VTFUNCDEF( 'Grid_Setup'    , main_class, vt_grid_setup_state , vtierr    )
call VTFUNCDEF( 'Pre-SCF'       , main_class, vt_pre_scf_state, vtierr        )
call VTFUNCDEF( 'HXC'           , main_class, vt_hart_xc, vtierr               )
call VTFUNCDEF( 'NonLocal'      , main_class, vt_nonloc, vtierr               )
call VTFUNCDEF( 'SCF'           , main_class, vt_scf_state , vtierr            )
call VTFUNCDEF( 'PostSCF'       , main_class, vt_post_scf_state, vtierr        )
call VTFUNCDEF( 'Ions'          , main_class, vt_pbc_ion , vtierr             )
call VTFUNCDEF( 'Forces'        , main_class, vt_forces_state, vtierr         )
call VTFUNCDEF( 'Move'          , main_class, vt_move_state, vtierr           )
call VTFUNCDEF( 'Postprocessing', main_class, vt_post_processing_state , vtierr)
call VTFUNCDEF( 'Eigencomm'     , comm_class , vt_eigencomm_state, vtierr     )
call VTFUNCDEF( 'Eigensort'     , solver_class , vt_eigensort_state, vtierr   )
!

end subroutine init_trace_data !}}}
#endif








!> @brief creates a group layout amongst N and s and npcol for kpoints
subroutine create_group_layout_2d(parallel, groups_num_in)

use aux, only : myflush
use psum_module, only : pisum

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, mpi_comm_split, &
        mpi_cart_create, mpi_cart_sub, mpi_comm_rank, mpi_comm_free
#else
use mpi
#endif
#endif

implicit none

type(parallel_data), intent(inout) :: parallel
integer, intent(in) :: groups_num_in
integer :: itmp
integer :: max_taskgroups_num

#ifdef MPI
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_2d_f08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: taskgroup_comm_f08
type(mpi_comm) :: colgroup_comm_f08
type(mpi_comm) :: rowgroup_comm_f08
type(mpi_comm) :: overallrowgroup_comm_f08
#else
integer :: comm_2d_f08
integer :: comm_f08
integer :: taskgroup_comm_f08
integer :: colgroup_comm_f08
integer :: rowgroup_comm_f08
integer :: overallrowgroup_comm_f08
#endif
integer, dimension(2) :: dims
logical, dimension(2) :: keep_dims
logical, dimension(2) :: periodic
integer :: mpinfo
#endif

! ------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

! ======================================================
! Numbering of processes and groups starts at 0
! Numbering of tasks starts at 1
! ======================================================

#ifdef MPI
! parallel%groups_num is npcol. (Need to unify the names later)
call mpi_bcast(parallel%groups_num, 1, mpi_integer, &
        parallel%masterid, comm_f08, mpinfo)
#endif

parallel%npcol = parallel%groups_num

if (mod(parallel%procs_num, parallel%npcol) /= 0) then
        write(9,*) "mod(parallel%procs_num, parallel%npcol) /= 0)"
        STOP
endif

max_taskgroups_num = parallel%procs_num / parallel%npcol

do itmp = max_taskgroups_num, 1, -1
        if (mod(max_taskgroups_num,itmp) == 0 .and. &
                mod(groups_num_in,itmp) == 0) then

                parallel%taskgroups_num = itmp
                parallel%nprow = max_taskgroups_num / itmp
                parallel%procs_per_task = parallel%nprow * &
                        parallel%npcol
                exit
        endif
enddo

! ======================================================
!     Set up taskgroups
! ======================================================
parallel%mytaskgroup = parallel%iam / parallel%procs_per_task 
parallel%taskgroup_iam = mod(parallel%iam, parallel%procs_per_task)
parallel%taskgroup_comm = 0
parallel%taskgroup_masterid = 0

#ifdef MPI
call mpi_comm_split(comm_f08, parallel%mytaskgroup, &
        parallel%taskgroup_iam, taskgroup_comm_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%taskgroup_comm = taskgroup_comm_f08%mpi_val
#else
parallel%taskgroup_comm = taskgroup_comm_f08
#endif
#endif

! ======================================================
!     Set up column and row groups within a task
! ======================================================

parallel%mycolgroup = parallel%taskgroup_iam / parallel%nprow
parallel%myrowgroup = mod(parallel%taskgroup_iam, parallel%nprow)

parallel%colgroup_iam = parallel%myrowgroup
parallel%rowgroup_iam = parallel%mycolgroup

parallel%colgroup_comm = 0
parallel%colgroup_masterid = 0
parallel%rowgroup_comm = 0
parallel%rowgroup_masterid = 0

#ifdef MPI
dims(1) = parallel%npcol 
dims(2) = parallel%nprow
periodic(:) = .true.

call mpi_cart_create(taskgroup_comm_f08, &
        size(dims), dims(:), &
        periodic(:), .true., comm_2d_f08, mpinfo)

keep_dims(1) = .true.
keep_dims(2) = .false.
call mpi_cart_sub(comm_2d_f08, keep_dims(:), rowgroup_comm_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%rowgroup_comm = rowgroup_comm_f08%mpi_val
#else
parallel%rowgroup_comm = rowgroup_comm_f08
#endif

keep_dims(1) = .false.
keep_dims(2) = .true.
call mpi_cart_sub(comm_2d_f08, keep_dims(:), colgroup_comm_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%colgroup_comm = colgroup_comm_f08%mpi_val
#else
parallel%colgroup_comm = colgroup_comm_f08
#endif

call mpi_comm_rank(comm_2d_f08, itmp, mpinfo)
if (itmp /= parallel%taskgroup_iam) then
        write(9,*) "itmp /= parallel%taskgroup_iam"
        STOP
endif

call mpi_comm_rank(colgroup_comm_f08, itmp, mpinfo)
if (itmp /= parallel%colgroup_iam) then
        write(9,*) "itmp /= parallel%colgroup_iam"
        STOP
endif

call mpi_comm_rank(rowgroup_comm_f08, itmp, mpinfo)
if (itmp /= parallel%rowgroup_iam) then
        write(9,*) "itmp /= parallel%rowgroup_iam"
        STOP
endif

call mpi_comm_free(comm_2d_f08, mpinfo)
#endif

! ======================================================
!     Set up overallrowgroups
! ======================================================
parallel%overallrowgroup_masterid = 0
parallel%overallrowgroup_iam = &
        parallel%mytaskgroup * parallel%npcol + parallel%mycolgroup

#ifdef MPI
call mpi_comm_split(comm_f08, parallel%myrowgroup, &
        parallel%iam, overallrowgroup_comm_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%overallrowgroup_comm = overallrowgroup_comm_f08%mpi_val
#else
parallel%overallrowgroup_comm = overallrowgroup_comm_f08
#endif

call mpi_comm_rank(overallrowgroup_comm_f08, itmp, mpinfo)
if (itmp /= parallel%overallrowgroup_iam) then
        write(9,*) "itmp /= parallel%overallrowgroup_iam"
        STOP
endif
#endif


parallel%gmaster_comm = parallel%overallrowgroup_comm
parallel%group_comm = parallel%colgroup_comm
parallel%group_iam = parallel%colgroup_iam
parallel%mygroup = parallel%mytaskgroup
parallel%group_size = parallel%nprow


!parallel%groups_num = parallel%taskgroups_num


if (parallel%taskgroup_iam == parallel%taskgroup_masterid) then
        parallel%iam_taskgroup_master = .true.
else
        parallel%iam_taskgroup_master = .false.
end if

if (parallel%colgroup_iam == parallel%colgroup_masterid) then
        parallel%iam_colgroup_master = .true.
        parallel%iamgmaster = .true.
else
        parallel%iam_colgroup_master = .false.
        parallel%iamgmaster = .false.
end if


write(9, *) 'procs_per_task', parallel%procs_per_task
write(9, *) 'my task/col/row group', &
        parallel%mytaskgroup, &
        parallel%mycolgroup, &
        parallel%myrowgroup
write(9, *) 'task/col/row/overallrow iam', &
        parallel%taskgroup_iam, &
        parallel%colgroup_iam, &
        parallel%rowgroup_iam, &
        parallel%overallrowgroup_iam

allocate(parallel%gmap(parallel%nprow, &
        parallel%npcol, parallel%taskgroups_num))

parallel%gmap(:,:,:) = 0
parallel%gmap(parallel%colgroup_iam+1,parallel%mycolgroup+1, &
        parallel%mytaskgroup+1) = parallel%iam

call pisum(parallel%gmap(:,:,:), parallel%procs_num, &
        parallel%procs_num, parallel%comm)



if (parallel%iammaster) then
        write(7,*) (' ',itmp=1,20),('*',itmp=1,20),(' ',itmp=1,20)
        write(7,*)
        write(7,*) ' Distributing ', parallel%procs_num, &
                ' PEs among ', parallel%taskgroups_num, &
                ' taskgroups.'
        write(7,*) ' Each taskgroup contains ', &
                parallel%npcol, ' column groups.'
        write(7,*) ' Each column group contains ', &
                parallel%nprow, ' PEs.'
        write(7,*)
        write(7,*) (' ',itmp=1,20),('*',itmp=1,20),(' ',itmp=1,20)
        call myflush(7)
endif

write(9,*) (' ',itmp=1,20),('*',itmp=1,20),(' ',itmp=1,20)
write(9,*)
write(9,*) ' Group partition information: '
write(9,*) ' I am PE with rank ', parallel%taskgroup_iam , &
        ' in taskgroup ', parallel%mytaskgroup

if (parallel%iam_taskgroup_master) then
        write(9,*) ' I am master in my taskgroup, &
                &with master rank ', parallel%taskgroup_masterid
else
        write(9,*) ' I am not master in my group.'
endif

write(9,*)
write(9,*) (' ',itmp=1,20),('*',itmp=1,20),(' ',itmp=1,20)
call myflush(9)


!call MPI_Barrier(parallel%comm, mpinfo)
!STOP

end subroutine create_group_layout_2d





subroutine create_fold_mpi_type(parallel, foldvol, cmplx_flag)

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_type_contiguous, mpi_double_complex, &
        mpi_double_precision, mpi_type_commit, mpi_datatype
#else
use mpi
#endif
#endif

implicit none

class(parallel_data), intent (inout) :: parallel

! length of the contigous type
integer, intent(in) :: foldvol

logical, intent(in) :: cmplx_flag

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_datatype) :: c_fold_type_f08
type(mpi_datatype) :: c_fold_rho_f08
#else
integer :: c_fold_type_f08
integer :: c_fold_rho_f08
#endif
#endif

! ------------------------------------------------------------

#ifdef MPI
if (cmplx_flag) then
        call mpi_type_contiguous(foldvol, mpi_double_complex, &
                c_fold_type_f08, mpinfo)
else
        call mpi_type_contiguous(foldvol, mpi_double_precision, &
                c_fold_type_f08, mpinfo)
endif

call mpi_type_commit(c_fold_type_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%c_fold_type = c_fold_type_f08%mpi_val
#else
parallel%c_fold_type = c_fold_type_f08
#endif



call mpi_type_contiguous(foldvol, mpi_double_precision, &
        c_fold_rho_f08, mpinfo)
call mpi_type_commit(c_fold_rho_f08, mpinfo)
#ifdef WITH_MPI_F08
parallel%c_fold_rho = c_fold_rho_f08%mpi_val
#else
parallel%c_fold_rho = c_fold_rho_f08
#endif
#endif

end subroutine create_fold_mpi_type
















subroutine export_function(parallel, f_distrib)
!
! Distributes array parallel%ftmp from master PE to the other
! processors. The distribution follows grid partition defined
! in parallel%irows. Ordinary processors keep
! the distributed data in array f_distrib.
!
use constants, only : dp, dzero
use external_interfaces, only : dcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_status, mpi_bcast, mpi_double_precision, &
        mpi_comm, mpi_send, mpi_recv, mpi_barrier
#else
use mpi
#endif
#endif

implicit none
type (parallel_data), intent (inout) :: parallel
real(dp), dimension(parallel%mydim), intent(inout) :: f_distrib

! communication variables
integer :: node
integer :: nelems

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_status) :: my_status
type(mpi_comm) :: gmaster_comm_f08
type(mpi_comm) :: colgroup_comm_f08
#else
integer, dimension(mpi_status_size) :: my_status
integer :: gmaster_comm_f08
integer :: colgroup_comm_f08
#endif
#endif

! -------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
gmaster_comm_f08%mpi_val = parallel%gmaster_comm
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
gmaster_comm_f08 = parallel%gmaster_comm
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

f_distrib(:) = dzero
!
! First, master processor broadcasts copies of parallel%ftmp to
! the masters within each group.

#ifdef MPI
if (parallel%iamgmaster) then
        call mpi_bcast(parallel%ftmp(:), parallel%nwedge, &
                mpi_double_precision, parallel%masterid, gmaster_comm_f08, mpinfo)
endif
#endif

do node = 1, parallel%nprow
        nelems = parallel%irows(node) - parallel%irows(node-1)

        if (parallel%iamgmaster) then
                if (node == parallel%colgroup_iam + 1) then
                        call dcopy(nelems, &
                                parallel%ftmp(parallel%irows(node-1):), 1, &
                                f_distrib(:), 1)
                else

#ifdef MPI
                        call mpi_send( &
                                parallel%ftmp(parallel%irows(node-1)), &
                                nelems, &
                                mpi_double_precision, &
                                node-1, &
                                node, &
                                colgroup_comm_f08, mpinfo)
#endif

                endif
        else
                if (node == parallel%group_iam + 1) then
#ifdef MPI
                        call mpi_recv( &
                                f_distrib(:), &
                                nelems, &
                                mpi_double_precision, &
                                parallel%colgroup_masterid, &
                                node, &
                                colgroup_comm_f08, &
                                my_status, mpinfo)
#endif

                endif
        endif

#ifdef MPI
        call mpi_barrier(colgroup_comm_f08, mpinfo)
#endif

enddo

end subroutine export_function









subroutine export_zfunction(parallel, f_distrib, mxwd)
!
! Similar to export_function, but for complex arrays with size
! parallel%mydim * mxwd.
!
use constants, only : dpc, zzero
use external_interfaces, only : zcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_status, mpi_bcast, mpi_double_complex, &
        mpi_send, mpi_recv, mpi_barrier
#else
use mpi
#endif
#endif

implicit none

type(parallel_data), intent (in) :: parallel
integer, intent(in) :: mxwd
complex(dpc), intent(inout) :: f_distrib(parallel%mydim*mxwd)

! counters
integer :: ii, istart

! communication variables
integer node, nelems
integer :: offset

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: gmaster_comm_f08
type(mpi_comm) :: group_comm_f08
type(mpi_status) :: my_status
#else
integer :: gmaster_comm_f08
integer :: group_comm_f08
integer, dimension(mpi_status_size) :: my_status
#endif
#endif

! -------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
gmaster_comm_f08%mpi_val = parallel%gmaster_comm
group_comm_f08%mpi_val = parallel%group_comm
#else
gmaster_comm_f08 = parallel%gmaster_comm
group_comm_f08 = parallel%group_comm
#endif
#endif

f_distrib(:) = zzero
!
! First, master processor broadcasts copies of parallel%zftmp to
! the masters within each group.
!
#ifdef MPI
if (parallel%iamgmaster) then
        call mpi_bcast(parallel%zftmp, parallel%nwedge*mxwd, &
                mpi_double_complex, parallel%masterid, gmaster_comm_f08, mpinfo)
endif
#endif

do ii = 1, mxwd
        istart = 1 + (ii - 1)*parallel%mydim

        do node = 1, parallel%group_size
          nelems = parallel%irows(node) - parallel%irows(node-1)
          offset = parallel%irows(node-1) + (ii - 1)*parallel%nwedge

          if (parallel%iamgmaster) then
             if (node == parallel%group_iam + 1) then
                call zcopy(nelems,parallel%zftmp(offset:),1,f_distrib(istart:),1)
             else
#ifdef MPI
                call mpi_send(parallel%zftmp(offset), &
                     nelems,mpi_double_complex, &
                     node-1,node,group_comm_f08, mpinfo)
#endif
             endif
          else
             if (node == parallel%group_iam + 1) then
#ifdef MPI
                call mpi_recv(f_distrib(istart),nelems,mpi_double_complex, &
                     parallel%group_master,node,group_comm_f08,my_status, mpinfo)
#endif
             endif
          endif
#ifdef MPI
          call mpi_barrier(group_comm_f08, mpinfo)
#endif
       enddo
enddo

end subroutine export_zfunction














subroutine collect_function(parallel, f_distrib)

! Collects array parallel%ftmp to master PE. The
! distribution follows grid partition defined in parallel%irows.
! Input dat is in array f_distrib
!
! \todo AJB: need to upgrade all of these with GATHERV etc.
!
use constants, only : dp, dzero
use external_interfaces, only : dcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_status, &
        mpi_double_precision, &
        mpi_send, mpi_recv, mpi_barrier
#else
use mpi
#endif
#endif

implicit none

type(parallel_data), intent (inout) :: parallel
real(dp), dimension(parallel%mydim), intent(in) :: f_distrib

integer :: inode, nelems

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
type(mpi_status) :: my_status
#else
integer :: colgroup_comm_f08
integer, dimension(mpi_status_size) :: my_status
#endif
#endif

! ----------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

if (parallel%iammaster) parallel%ftmp(:) = dzero

do inode = 1, parallel%nprow
        nelems = parallel%irows(inode) - parallel%irows(inode-1)

        if (.not. parallel%iamgmaster) then
                if (inode == parallel%colgroup_iam + 1) then

#ifdef MPI
                        call mpi_send(f_distrib(:), nelems, &
                                mpi_double_precision, &
                                parallel%colgroup_masterid, inode, &
                                colgroup_comm_f08, mpinfo)
#endif

                endif
        else
                if (inode == parallel%colgroup_iam + 1) then
                        call dcopy(nelems, f_distrib(:), 1, &
                                parallel%ftmp( &
                                parallel%irows(inode-1):), 1)
                else

#ifdef MPI
                        call mpi_recv(parallel%ftmp( &
                                parallel%irows(inode-1)), &
                                nelems, mpi_double_precision, &
                                inode-1, inode, &
                                colgroup_comm_f08, &
                                my_status, mpinfo)
#endif

                endif
        endif

#ifdef MPI
        call mpi_barrier(colgroup_comm_f08, mpinfo)
#endif

enddo

end subroutine collect_function













subroutine collect_zfunction(parallel, f_distrib, mxwd)
!
! Collects array parallel%zftmp to master PE. The
! distribution follows grid partition defined in parallel%irows.
! Input dat is in array f_distrib
!
use constants, only : dpc, zzero
use external_interfaces, only : zcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_status, &
        mpi_double_complex, &
        mpi_send, mpi_recv, mpi_barrier
#else
use mpi
#endif
#endif

implicit none

type (parallel_data), intent (inout) :: parallel
integer, intent(in) :: mxwd
complex(dpc), intent(in) :: f_distrib(parallel%mydim*mxwd)

! counters
integer :: ii, istart

! communication variables
integer :: node, nelems
integer :: offset

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: group_comm_f08
type(mpi_status) :: my_status
#else
integer :: group_comm_f08
integer, dimension(mpi_status_size) :: my_status
#endif
#endif

! -----------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
group_comm_f08%mpi_val = parallel%group_comm
#else
group_comm_f08 = parallel%group_comm
#endif
#endif

if (parallel%iammaster) parallel%zftmp(:) = zzero

do ii = 1, mxwd
        istart = 1 + (ii - 1)*parallel%mydim

        do node = 1, parallel%group_size
                nelems = parallel%irows(node) - parallel%irows(node-1)
                offset = parallel%irows(node-1) + (ii - 1)*parallel%nwedge

                if (.not. parallel%iamgmaster) then
                        if (node == parallel%group_iam + 1) then
#ifdef MPI
                                call mpi_send(f_distrib(istart), &
                                        nelems, mpi_double_complex, &
                                        parallel%group_master, &
                                        node, group_comm_f08, mpinfo)
#endif
                        endif
                else
                        if (node == parallel%group_iam + 1) then
                                call zcopy(nelems,f_distrib(istart:),1, &
                                        parallel%zftmp(offset:),1)
                        else
#ifdef MPI
                                call mpi_recv(parallel%zftmp(offset), &
                                        nelems, mpi_double_complex, &
                                        node-1, node, group_comm_f08, &
                                        my_status, mpinfo)
#endif
                        endif
                endif
#ifdef MPI
                call mpi_barrier(group_comm_f08, mpinfo)
#endif
        enddo
enddo

end subroutine collect_zfunction







subroutine group_reduction(parallel, f_distr)
!
! Performs a reduction of function f_distr distributed across
! groups. The reduction is done over all processors which share
! the same set of grid points.
!
! \todo AJB: oh well... maybe something better than recv send?

use constants, only : dp

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_allreduce, mpi_in_place, &
        mpi_double_precision, mpi_sum, mpi_comm
#else
use mpi
#endif
#endif

implicit none

type(parallel_data), intent(in) :: parallel
real(dp), dimension(parallel%mydim), intent(inout) :: f_distr

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: overallrowgroup_comm_f08
#else
integer :: overallrowgroup_comm_f08
#endif
#endif

! --------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
overallrowgroup_comm_f08%mpi_val = parallel%overallrowgroup_comm
#else
overallrowgroup_comm_f08 = parallel%overallrowgroup_comm
#endif
#endif

#ifdef MPI
call mpi_allreduce(mpi_in_place, f_distr(1), parallel%mydim, &
        mpi_double_precision, mpi_sum, overallrowgroup_comm_f08, mpinfo)
#endif

end subroutine group_reduction




end module parallel_data_module
