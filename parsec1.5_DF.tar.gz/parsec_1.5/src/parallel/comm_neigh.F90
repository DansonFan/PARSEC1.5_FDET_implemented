module comm_neigh_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  AJB: BEGIN UPDATE
!
!  Defines:  
!      1. parallel%neibs in local form
!      2. irecvp,jsendp,senrows indices for exchanging
!         info in matvec
!      2. New: TODO - for irecvp - map whose row this belongs to 
!                                  and the neihbor distance
!  Old text:
!      3. ip1,jp1 for exchanging info in preconditioning
!  New:
!      3. ip1,jp1 markers disabled
!  Old text:
!      4. pint local permutation with inter1 interior points
!  New:
!      4. TODO: pint local permutation is not needed but kept for compatabililty
!

!  Rewrites parallel%neibs with a local one with the properties:
!
!              |--> parallel%neibs(neigh,row)-ioffset for all 
!              |     neighbors "neigh" local on this processor
!              |
!  parallel%neibs(neigh,row)= --> position of neigh, (> mydim) in the boundary 
!              |    values appended at the end of the current vector.
!              |    This is the "neigh" neighbor of the local "row" 
!              |   
!              |--> ndim+1 for all unused neighbors 
!
!  The boundary values needed from this node are padded at the
!  end of a local vector in a boundary-exchange information step.
!
!                     Receive and append info from 
!             local on the node    Proc1  Proc2  Proc4
!           <-------------------> <-----> <---> <------->
!
!  There is a local IP array : IP(i) = where the info from proc i
!  should be padded at. (eg IP(0) = ndim + 1, and IP(1) = ndim + 1
!  if nothing is received from proc 0). The rows that must be sent
!  to other processors are in senrows with index for each proc JP
!  Then matrix vector multiply is performed by exchanging info
!  filling the padded area and running the old mat-vec on it.
!
!  Also IP1 and JP1 are used for the communication in the 
!  preconditioning. This uses only the first shell (neighbors up
!  to norder) for every point. Since these are numbered first in
!  the boundary we put them in the same positions as in matvec.
!  Then parallel%neibs knows how to access them. Notice that IP
!  carries the positions of where they should be put. So we only
!  keep the sizes. Since we number the first shell first, the
!  senrows will contain exactly these rows if we take JP1(*) of them.
!
!  COMMUNICATION SIZE GRAPH:
!              Recv from 
!   local on the node    Proc1  Proc2  Proc4
! <-------------------> <-----> <---> <------->  index IP  (matvec)
!                       <->     <->   <-->    sizes in IP1 (precond)
!
!                  senrows
! <----------------------------------------->
! send Proc1     Proc2    Proc3      Proc4
! <-------><---------><------><------------->    index JP  (matvec)
! <-->     <-->       <->     <----->         sizes in JP1 (precond)
!
!----------------------------------------------------------------------
!  Experimentally sort first the interior rows (ie that do not 
!  require any neighbors from other nodes). Sort second the rows
!  that do not require any first shell neighbors. These will be
!  considered interior for the preconditioning. Permutation array
!  is pint and the above numbers inter1 respectively.
!                        pint
!            <----------------------------------------->
!            <---------> inter1
!
!	Algorithm
!  Count how many and which rows I need from each processor. (irecvp)
!  Also count the number of my rows each of my neighbors needs (jsendp)
!  (each time irow needs info from proc node, irow will be needed
!  by proc node -symmetric matrix-. If I have not received this
!  row already, add it in irecvp for reception. For sending out, a 
!  row should be sent only once to a node and not for all the 
!  neighbors of this row that reside on that node. To guarantee
!  that, for each node a flag array is updated for each row.
!  To keep the order of reception same to the one that other procs
!  will compute ---to retain locality in the access pattern of 
!     neighbors--- senrows is used as scratch to store the order.
!
!---------------------------------------------------------------
! Modified to eliminate local stack arrays.  MGR 16feb09
!---------------------------------------------------------------
subroutine comm_neigh(parallel, norder)

use constants
use parallel_data_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_alltoallv, mpi_integer
#else
use mpi
#endif
#endif

implicit none



!  Input/Output variables:

!  parallel computation related data
type(parallel_data), intent(inout) :: parallel

!  number of neighbors used on one side in numerical derivative
integer, intent(in) :: norder



!  Work variables:

integer :: node, neibs_num, itmp, &
        ioffset, num_of_rows_from_other_procs, &
        ish, inode, irow_local, neighbor_irow_global

logical :: is_interior_point
integer, dimension(:), allocatable :: recrows, neighbor_irow_local
logical, dimension(:), allocatable :: is_received
logical, dimension(:,:), allocatable :: is_sent

integer, dimension(0:parallel%nprow) :: &
        isendcount, irecvcount, &
        send_offset, recv_offset, &
        tmp_send_offset, tmp_recv_offset

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif
#endif

!---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

ioffset = parallel%irows(parallel%colgroup_iam) - 1
neibs_num = 6 + 2*parallel%lap_dir_num

isendcount(:) = 0
irecvcount(:) = 0
send_offset(:) = 0
recv_offset(:) = 0
tmp_send_offset(:) = 0
tmp_recv_offset(:) = 0






!
!  * Experimental *
!  *** notice that locality on the vec won't be great in matvec
!  *** Eventually parallel%neibs must be turned into
!  *** parallel%neibs(rows,neighbors)
!  *** We will have to experiment with the effects of index pint
!
! ===========================
! Determine the numbers of elements to be sent and received
! ===========================
allocate(is_sent(parallel%mydim,0:parallel%nprow-1))
allocate(is_received(parallel%nwedge))
is_sent(:,:) = .false.
is_received(:) = .false.

num_of_rows_from_other_procs = 0
do ish = 1, neibs_num*norder
do irow_local = 1, parallel%mydim
        neighbor_irow_global = parallel%neibs(ish,irow_local)

        ! Find PE # of neighbor neighbor_irow_global
        ! If you cant find it (outside domain) - it is on your node
        node = lochome(neighbor_irow_global, parallel%nprow, &
                parallel%irows(:), parallel%colgroup_iam)

        if (node /= parallel%colgroup_iam) then
                if (.not. is_sent(irow_local,node)) then
                        is_sent(irow_local,node) = .true.
                        isendcount(node) = isendcount(node) + 1
                endif

                if (.not. is_received(neighbor_irow_global)) then
                        is_received(neighbor_irow_global) = .true.
                        irecvcount(node) = irecvcount(node) + 1

                        num_of_rows_from_other_procs = &
                                num_of_rows_from_other_procs + 1
                        ! KHL: Here I use parallel%senrows(:) as 
                        !      a tmp array to store neighbor_irow_global
                        parallel%senrows(num_of_rows_from_other_procs) = &
                                neighbor_irow_global
                endif
        endif
enddo
enddo
deallocate(is_sent)
deallocate(is_received)

num_of_rows_from_other_procs = sum(irecvcount(:))
parallel%myworkdim = parallel%mydim + num_of_rows_from_other_procs
write(9,*) "parallel%myworkdim", parallel%myworkdim






! ===========================
! Determine the offsets and the final positions of first elements
! ===========================
do inode = 0, parallel%nprow
        recv_offset(inode) = sum(irecvcount(0:inode-1))
        send_offset(inode) = sum(isendcount(0:inode-1))
enddo

parallel%irecvp(:) = recv_offset(:) + parallel%mydim + 1
parallel%jsendp(:) = send_offset(:) + 1




! ===========================
! Make recrows(1:num_of_rows_from_other_procs) and 
! share/distribute parallel%senrows(:)
!
! parallel%senrows(:) (used as a tmp array here) is unsorted
! recrows(:) will be in the order of proc ranks
! ===========================
allocate(recrows(num_of_rows_from_other_procs))
recrows(:) = 0
allocate(neighbor_irow_local(parallel%nwedge))
neighbor_irow_local(:) = 0

tmp_recv_offset(:) = recv_offset(:)
tmp_send_offset(:) = send_offset(:)

do irow_local = 1, num_of_rows_from_other_procs
        neighbor_irow_global = parallel%senrows(irow_local)
        node = lochome(neighbor_irow_global, parallel%nprow, &
                parallel%irows(:), parallel%colgroup_iam)
        tmp_recv_offset(node) = tmp_recv_offset(node) + 1
        itmp = tmp_recv_offset(node)
        recrows(itmp) = neighbor_irow_global

        ! Make a table so that later we can directly use this 
        ! when changing parallel%neibs(:,:) to local indices
        neighbor_irow_local(neighbor_irow_global) = itmp
enddo


#ifdef MPI
call mpi_alltoallv(recrows(:), irecvcount(:), recv_offset(:), mpi_integer, &
        parallel%senrows(:), isendcount(:), send_offset(:), mpi_integer, &
        colgroup_comm_f08, mpinfo)
#endif



! ===========================
! Change parallel%senrows(:) and parallel%neibs(:,:) to local indices
! ===========================
parallel%senrows(:) = parallel%senrows(:) - ioffset

do ish = 1, neibs_num*norder
do irow_local = 1, parallel%mydim
        neighbor_irow_global = parallel%neibs(ish,irow_local)
        node = lochome(neighbor_irow_global, parallel%nprow, &
                parallel%irows(:), parallel%colgroup_iam)

        if (node == parallel%colgroup_iam) then
                if (neighbor_irow_global == parallel%nwedge+1) then
                        parallel%neibs(ish,irow_local) = &
                                parallel%myworkdim + 1
                else
                        parallel%neibs(ish,irow_local) = &
                                neighbor_irow_global - ioffset 
                endif
        else
                parallel%neibs(ish,irow_local) = &
                        neighbor_irow_local(neighbor_irow_global) + &
                        parallel%mydim
        endif
enddo
enddo


deallocate(recrows)
deallocate(neighbor_irow_local)



!write(9,*) "isendcount(:)"
!write(9,*) isendcount(:)
!write(9,*) "irecvcount(:)"
!write(9,*) irecvcount(:)
!write(9,*) "parallel%irecvp(:)"
!write(9,*) parallel%irecvp(:)
!write(9,*) "parallel%jsendp(:)"
!write(9,*) parallel%jsendp(:)





!  Find and permute the inter1 interior points in pint
!
do irow_local = 1, parallel%mydim
        parallel%pint(irow_local) = irow_local
enddo



! Block laplacian sketch: start from bottom corner (min_i,min_j,min_k)
!
!    0. block += 1, first_point=irow(min_i,j,k)
!    a. Does this point have a neighbor which is >parallel%mydim?
!    b. if yes - Does this point have a neighbor which is outside domain?
!    c. if so mark the entire block as  block_type(block)=ext
!    d. if not mark the entire blok as block_type(block)=comm
!       if it has both external and neighbor mark the entire block as
!       block_type(block)=ext+comm
!       else block_type(block)=normal
!    e. travel = neighbor to switch to inside the block via traversal order &
!        next point = neighb(travel,irow_local)
!        goto a.
!    f. else if travel = end go to next block via block traversal order next
!    block = neighb(travel_outside_block,first_point)
!    
! g (finally) sort blocks as normal ext comm ext+comm

!but for now...

parallel%inter1 = 0
do irow_local = 1, parallel%mydim
        is_interior_point = .true.

        do ish = 1, neibs_num*norder
                neighbor_irow_global = parallel%neibs(ish,irow_local)

                if (neighbor_irow_global > parallel%mydim) then
                        is_interior_point = .false.
                        exit
                endif
        enddo
        
        if (is_interior_point) then
                parallel%inter1 = parallel%inter1 + 1

                ! permute to the begining !AJB ...maybe not...
                itmp = parallel%pint(irow_local)
                parallel%pint(irow_local) = parallel%pint(parallel%inter1)
                parallel%pint(parallel%inter1)= itmp
        endif
enddo




write(9,*) 'INTERIOR POINTS Mvec, PreCond (', parallel%inter1, ') '
if (parallel%inter1 == 0) then
        write(9,*) 'WARNING, NO MATVEC INTERIOR POINTS'
        write(9,*) 'CURRENT SYSTEM SIZE/PE RATIO NOT RECOMMENDED'
endif




end subroutine comm_neigh

















!subroutine make_sparse_lap_coo(parallel,params) !{{{
!!=========================================================================
!!  This subroutine creates the laplacian operator for the grid This is
!!  essentialy the graph in COO format.  The data column for the matrix are
!!  integers representing the 3-d distance between neigbors, according to
!!  their order in parallel%neibs, so 1=+x,2=-x,3=+y,4=-y etc.
!
! !later - maybe shift ish so that directions are +-1 for x, +=2 for y etc
!!  
!!  converting the data column into the real coefficent matrix is is done in
!!  a different subroutine
!!
!!  We will have to test wether it is more efficent to store this as a sum of
!!  a few matrices, each stored in a different sparse format
!!
!!  Author: AJB
!!
!    use constants
!    use parallel_data_module
!
!  implicit none
!
!  !  Input/Output variables:
!  !  parallel computation related data
!  type (parallel_data), intent(inout) :: parallel
!  !  parameters from comm_neigh that are needed here:
!  integer, intent(in) :: params(5) !params(1) = FD order (half-order actually)
!                                   !params(2) = reserved
!                                   !params(3) = number of rows needed from other PEs
!                                   !params(4) = reserved
!                                   !params(5) = reserved
!
!  ! Work variables
!  integer :: norder,neibs_num,ext_nzcount
!  integer, allocatable :: nzcount_ish(:)
!  ! the two sparse matrices in coo format
!  ! the csr matrices made from these are part of spmatvec_base
!  ! we also hold these in spmatvec_base
!  ! integer, allocatable :: coo_sprs_row(:),coo_sprs_col(:),coo_sprs_ishval(:)
!  ! integer, allocatable :: ext_sprs_row(:),ext_sprs_col(:),ext_sprs_ishval(:)
!  ! compatabililty:
!  ! integer, dimension(:), allocatable :: irows
!
!  integer irow,myrow,mydim,ioffset,ncur,ish,cooind,extind
!
!
!  ! integer i, alcstat ,nzcount, ierr
!
!  ! ! for dev. purposes:
!  ! ! timer objects
!   real(dp)            ::t0,t1
!   character(len=4)    :: idstring
!
!  ! integer :: neibs_num
!
!
!  !---------------------------------------------------------------
!
!
!  !  Initializations - this is purposely similar to comm_neigh 
!!  iam = parallel%group_iam
!!  nnodes = parallel%group_size
!
!  ! allocate(irows(0:nnodes))
!  ! irows(:) = parallel%irows
!
!  !ioffset = parallel%irows(iam) - 1
!  mydim   = parallel%mydim
!
!  norder = params(1)
!  neibs_num = 6 + 2*parallel%lap_dir_num
!
!  ! go over all parallel neibs (here already in the local indexing)
!  ! and begin the splitting by counting the number neighbors actually
!  ! present on the PE local memory and those that are not
!  ext_nzcount = 0
!  allocate(nzcount_ish(neibs_num*norder))
!  nzcount_ish(:) = 0
!!#ifdef 1
!  call mysecond(t0)
!!#endif
!!$OMP PARALLEL DO COLLAPSE(2) &
!!$OMP& DEFAULT(SHARED) PRIVATE(irow) & 
!!$OMP& REDUCTION(+:ext_nzcount,nzcount_ish)
!  do myrow = 1, mydim
!      do ish = 1,neibs_num*norder
!        irow = parallel%neibs(ish,myrow)
!            if (irow > mydim) then
!                !we don't want to think about elements
!                !that are outside of the edge
!                if (irow < parallel%myworkdim+1) then
!                ext_nzcount=ext_nzcount+1
!                endif
!            else
!            !$OMP ATOMIC
!                nzcount_ish(ish)=nzcount_ish(ish)+1
!            endif
!       enddo      !ish
!  enddo           ! myrow = 1, mydim
!!$OMP END PARALLEL DO  
!!#ifdef 1
!  call mysecond(t1)
!    write(9,*) "time to sort through original neibs", t1-t0
!    write(9,*) "Laplacian structure:"
!    write(9,*) "non-zero elements present on this PE:", sum(nzcount_ish(:))
!    write(9,*) "nnz elements received from other PEs:", ext_nzcount
!    ! write(9,*) nzcount_ish
!!#endif
!
!
!  ! AJB: I want to hold the shell and the local row that needs the recrows/senrows
!  ! such that 
!  ! laplcian(myrow)= laplacian(local_rows)+sum(data(recrows)*coefficent(ish))
!  !
!  ! Eventually we might create several COO sparse matrices for this purpose, but 
!  ! currently two is enough - one for external neibs and one for my neibs.
!
!! allocate the coo structures (no need to init)
!call coo_sprs%alloc(sum(nzcount_ish)+mydim) !+mydim is for the diagonal zero
!call ext_sprs%alloc(ext_nzcount)
!
!!actually create the coo matrices:
!!Difficult to do in openmp so we won't do it right now
!!#ifdef 1
!  call mysecond(t0)
!!#endif
!  cooind = 0
!  extind = 0
!  do myrow = 1, mydim
!  ! MKL may also want to hold the matrix 
!  ! zeros if you want to use the symmetry
!  ! add the zero diagonal first
!    cooind = cooind + 1
!    coo_sprs%row(cooind) = myrow
!    coo_sprs%col(cooind) = myrow
!    coo_sprs%ishval(cooind) = 0
!
!      do ish = 1,neibs_num*norder
!        irow = parallel%neibs(ish,myrow)
!            if (irow > mydim) then !single direction
!                if (irow < parallel%myworkdim+1) then
!                !add to COO index of ext
!                extind = extind + 1
!                ext_sprs%row(extind) = myrow
!                !I should have commented on whats going on in this line:
!                ext_sprs%col(extind) = irow - mydim
!                ext_sprs%ishval(extind) = ish
!                endif
!            else !bidirectional!
!                !add to COO index
!                cooind = cooind + 1
!                coo_sprs%row(cooind) = myrow
!                coo_sprs%col(cooind) = irow
!                coo_sprs%ishval(cooind) = ish
!            endif
!       enddo      !ish
!  enddo           ! myrow = 1, mydim
!!#ifdef 1
!   
!
!  call mysecond(t1)
!
!    write(9,*) ""
!    write(9,*) "Time used to create coo sparse matrices", t1-t0
!    ! write(9,*) "non zero elements on ext coo", extind
!    ! write(9,*) "non zero elements on local coo:", cooind
!    write(9,*) ""
!!#endif
!!
!! NOW WOULD BE THE TIME TO APPLY REORDERING AND UPDATE parallel%pint
!! Also need to update ext_sprs with the same permutation. If you are
!! reordering the actual points, need to make sure
!! that when packing the rows for sending, you use the reodered indices
!!{{{ DEBUG - print the matrices
!#ifdef SPRSDEBUG
!  ! huge files:
!    write(idstring,'(I4.4)') parallel%iam !limited for 10k PE
!    open(46,file='mycoo_val.'//idstring,form='formatted',status='unknown')
!    open(47,file='mycoo_col.'//idstring,form='formatted',status='unknown')
!    open(48,file='mycoo_row.'//idstring,form='formatted',status='unknown')
!   write(46,300) coo_sprs%ishval
!   close(46)
!
!   write(47,300) coo_sprs%col
!   close(47)
!
!   write(48,300) coo_sprs%row
!   close(48)
!
!  ! huge file:
!    write(idstring,'(I4.4)') parallel%iam !limited for 10k PE
!    open(46,file='extcoo_val.'//idstring,form='formatted',status='unknown')
!    open(47,file='extcoo_col.'//idstring,form='formatted',status='unknown')
!    open(48,file='extcoo_row.'//idstring,form='formatted',status='unknown')
!   write(46,300) ext_sprs%ishval
!   close(46)
!
!   write(47,300) ext_sprs%col
!   close(47)
!
!   write(48,300) ext_sprs%row
!   close(48)
!300 format (I8)
!#endif 
!!}}}
!
! end subroutine make_sparse_lap_coo !}}}












!===============================================================
!
!  Returns the processor that the global row irow is on.
!
!---------------------------------------------------------------
integer function lochome(irow, nnodes, irows, iam)

implicit none
!
!  Input/Output variables:
!
integer, intent(in) :: irow, iam, nnodes
integer, dimension(0:nnodes), intent(in) :: irows
!
!  Work variables:
!
integer :: inode

!---------------------------------------------------------------

lochome = iam

do inode = 0, nnodes-1
        if (irows(inode) <= irow .and. irow < irows(inode+1)) then
                lochome = inode
                exit
        endif
enddo

end function lochome


end module comm_neigh_module
