!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  AJB: block_neib module
!
!  *will contain a subroutine that will supercede comm_neigh in the near future
!  *for now, leaves the information used by comm_neigh.F90 intact so they can coexist
!
!
module block_neib

use stencil_things
implicit none

contains




!  1. calculates the parallel%neib and parallel%tneib for a PE
subroutine calc_my_neibs(parallel, grid)

! I calculate the neighbor list based on indexg, I need to have also rindex and rtrans!
!
!  For each point in the domain, make an array which points to the
!  position of all neighbors to be used for derivation. There are
!  3*norder of those for each point.
!
use constants
use grid_module
use parallel_data_module

implicit none
!
! I/O
!
type(parallel_data), intent(inout) :: parallel
type(grid_data), intent(in) :: grid
!
! Temp vars
!
integer :: irow, irow_local, j, k, neib, neibs_num, ishell
integer, dimension(12) :: indx

! --------------------------------------------------------------------

neibs_num = 6 + 2*grid%lap_dir_num



irow_local = 0
do irow = parallel%irows(parallel%colgroup_iam), &
          parallel%irows(parallel%colgroup_iam+1)-1

        irow_local = irow_local + 1
        neib = 0

        do ishell = 1, grid%norder

        !  Doing first the main axes neighbors

indx(1) = grid%indexg(grid%kx(irow)-ishell,grid%ky(irow)       ,grid%kz(irow))
indx(2) = grid%indexg(grid%kx(irow)+ishell,grid%ky(irow)       ,grid%kz(irow))
indx(3) = grid%indexg(grid%kx(irow)       ,grid%ky(irow)-ishell,grid%kz(irow))
indx(4) = grid%indexg(grid%kx(irow)       ,grid%ky(irow)+ishell,grid%kz(irow))
indx(5) = grid%indexg(grid%kx(irow)       ,grid%ky(irow)       ,grid%kz(irow)-ishell)
indx(6) = grid%indexg(grid%kx(irow)       ,grid%ky(irow)       ,grid%kz(irow)+ishell)

                do j = 1, 6
                        parallel%neibs (neib+j,irow_local) = grid%rindex(indx(j))
                        parallel%tneibs(neib+j,irow_local) = grid%rtrans(indx(j))
                enddo

                if (grid%lap_dir_num <= 0) then
                        neib = neib + neibs_num
                        cycle
                endif



                j = 7 ! set the place for next copy of special directions.

                ! The following lines do the elements of laplacian
                ! coefficients that are not positioned on the main axes.

                ! Neighbors for the uv plane.
                ! changing of j is done if there is an active new laplacian
                ! direction. if the direction is not active (lap_dir(i) is 0) 
                ! then the code continues to the next direction without 
                ! advancing j!

                do k = 1, 3 
                        if (grid%lap_dir(k) /= 0) then
                                indx(j) = grid%indexg( &
                                        grid%kx(irow)-ishell*grid%lap_neig(k,1), &
                                        grid%ky(irow)-ishell*grid%lap_neig(k,2), &
                                        grid%kz(irow)-ishell*grid%lap_neig(k,3))
                                indx(j+1) = grid%indexg( &
                                        grid%kx(irow)+ishell*grid%lap_neig(k,1), &
                                        grid%ky(irow)+ishell*grid%lap_neig(k,2), &
                                        grid%kz(irow)+ishell*grid%lap_neig(k,3))
                  
                                parallel%neibs (neib+j,irow_local) = grid%rindex(indx(j))
                                parallel%tneibs(neib+j,irow_local) = grid%rtrans(indx(j))
                                j = j + 1
                                parallel%neibs (neib+j,irow_local) = grid%rindex(indx(j))
                                parallel%tneibs(neib+j,irow_local) = grid%rtrans(indx(j))
                                j = j + 1
                        endif
                enddo

                neib = neib + neibs_num
        enddo
enddo

end subroutine calc_my_neibs











!  2. calculates a new parallel%cneib and parallel%ctneib for use in the folded stencil 
subroutine calc_my_cneibs(parallel, grid)

use constants
use aux, only : alccheck, mysecond, c_locate_part
use grid_module
use parallel_data_module

implicit none
!
! I/O
!
type (parallel_data), intent(inout) :: parallel
type (grid_data), intent(in) :: grid
!
! Working
!
integer, dimension(3) :: max_blocks
integer :: max_max_blocks
integer, dimension(:), allocatable :: sten_memb
integer :: shift,shshift,shdir,Bx,By,Bz
integer :: Fx,Fy,Fz
integer :: mydim, myoffset, neibsize
integer :: myblock,block0,block1,mycdim
integer :: tmpneib,foldvol
integer :: ii
integer :: alcstat
!logical :: logical_tmp = .true.

! ------------------------------------------------------------------------

!if (parallel%iammaster) logical_tmp = .true.
!do while (logical_tmp)
!enddo

mydim = parallel%mydim
myoffset = parallel%irows(parallel%colgroup_iam) - 1
max_blocks(:) = grid%norder / grid%fold%blocksize(:)
foldvol = grid%fold%volume
max_max_blocks = maxval(max_blocks(:))
shdir = 6 + 2*grid%lap_dir_num
neibsize = max_max_blocks*shdir

! write(9,*) "max_blocks: in each principal direction", max_blocks
! write(9,*) "number of neighbors in stencil", shdir
! write(9,*) "size of folded neib array", neibsize

allocate(sten_memb(neibsize))

if (grid%lap_dir_num > 0) then
        write(9,*) " i can't calculate c_neib for non cubic grids"
        stop "boom"
endif
 
! allocate c_neibs, c_tneibs
mycdim = parallel%mycdim
allocate(parallel%c_neibs(neibsize,mycdim), stat=alcstat)
call alccheck('c_neib', neibsize*mycdim, alcstat)
allocate(parallel%c_tneibs(neibsize,mycdim), stat=alcstat)
call alccheck('c_tneib', neibsize*mycdim, alcstat)
parallel%c_neibs(:,:) = 0
parallel%c_tneibs(:,:) = 0

! KHL: These array indices should be 1, 2, 3, rather than 1, 1, 1, right?
Fx = grid%fold%blocksize(1)
Fy = grid%fold%blocksize(1)
Fz = grid%fold%blocksize(1)

block0 = parallel%cirows(parallel%colgroup_iam)
block1 = parallel%cirows(parallel%colgroup_iam+1) - 1

write(9,*) "calc: block0", block0
write(9,*) "calc: block1", block1
write(9,*) "max_max_blocks:", max_max_blocks

do myblock = block0, block1
        ! grab block location from wedge index
        Bx = grid%kcx(myblock)
        By = grid%kcy(myblock)
        Bz = grid%kcz(myblock)

        ! use block location on full grid to find out real neighbors:
        do shift = 1, max_max_blocks
                shshift = (shift-1)*shdir

                ! dirs=(x-1 x+1 y-1 y+1 z-1 z+1 ... x-2 x+2 ...)
                if (shift <= max_blocks(1)) then
                        sten_memb(1+shshift) = grid%indexg(BX-shift*Fx,BY,BZ)
                        sten_memb(2+shshift) = grid%indexg(BX+shift*Fx,BY,BZ)
                else
                        sten_memb(1+shshift) = -1
                        sten_memb(2+shshift) = -1
                endif
            
                if (shift <= max_blocks(2)) then
                        sten_memb(3+shshift) = grid%indexg(BX,BY-shift*Fy,BZ)
                        sten_memb(4+shshift) = grid%indexg(BX,BY+shift*Fy,BZ)
                else
                        sten_memb(3+shshift) = -1
                        sten_memb(4+shshift) = -1
                endif

                if (shift <= max_blocks(3)) then
                        sten_memb(5+shshift) = grid%indexg(BX,BY,BZ-shift*Fz)
                        sten_memb(6+shshift) = grid%indexg(BX,BY,BZ+shift*Fz)
                else
                        sten_memb(5+shshift) = -1
                        sten_memb(6+shshift) = -1
                endif

                ! insert extra dirs here

        enddo



        do ii = 1, neibsize
                ! if we are within the folded stencil:

                if (sten_memb(ii) > 0) then
                        ! NOTW: from now on I am still not sure I know what 
                        ! I am doing with symmetry.
                        !after rotation we need to shift back to 
                        ! the bottom left corner index
                        !and now since indexg is in 
                        !the non-folded grid and we want the folded grid
                        !we need to translate the numbers we just got to block numbers

                        tmpneib = grid%rindex(sten_memb(ii))

                        ! safety?
                        if (mod(tmpneib-1,foldvol) == 0) then
                                parallel%c_neibs(ii,myblock-block0+1) = &
                                        1 + (tmpneib-1)/foldvol
                        else
                                if (tmpneib/foldvol == 0) then
                                        write(9,*) "tmpneib/foldvol = 0!! on myblock",myblock
                                        write(9,*) "  stencil member is", ii
                                        write(9,*) "which is grid point", sten_memb(ii)
                                        write(9,*) "   mapped to rindex", grid%rindex(sten_memb(ii))
                                        write(9,*) "     using symm op:", grid%rtrans(sten_memb(ii))
                                        write(9,*) "       neib/foldvol", (tmpneib)/foldvol 
                                        write(9,*) "         points to ", 1+((tmpneib)/foldvol)*foldvol
                                        write(9,*) "     1+neib/foldvol", (tmpneib)/foldvol + 1
                                        write(9,*) "         points to ", 1+((tmpneib)/foldvol + 1)*foldvol
                                        write(9,*) "assign    it now to", myblock-block0+1
                            
                                endif

                                parallel%c_neibs(ii,myblock-block0+1) = max(1,tmpneib/foldvol)
                        endif

                        ! the symmetry remains the same (I think)
                        parallel%c_tneibs(ii,myblock-block0+1) = grid%rtrans(sten_memb(ii))




                        if (parallel%c_neibs(ii,myblock-block0+1) == myblock ) then

                                if ( grid%rtrans(sten_memb(ii)) == 1 ) then
                                        write(9,*) "in calc_my_cneibs, block is a neighbor of itself, myblock=",myblock
                                        ! write(9,*) "the entire sten_memb is:"
                                        ! write(9,*) sten_memb
                                        write(9,*) "  stencil member is", ii
                                        write(9,*) "which is grid point", sten_memb(ii)
                                        write(9,*) "   mapped to rindex", grid%rindex(sten_memb(ii))
                                        write(9,*) "     using symm op:", grid%rtrans(sten_memb(ii))
                                        write(9,*) "       neib/foldvol", (tmpneib)/foldvol 
                                        write(9,*) "         points to ", 1+((tmpneib)/foldvol)*foldvol
                                        write(9,*) "     1+neib/foldvol", (tmpneib)/foldvol + 1
                                        write(9,*) "         points to ", 1+((tmpneib)/foldvol + 1)*foldvol
                                        write(9,*) "assign    it now to", myblock-block0+1
                                endif
                        endif
                else !need to think what to assign to these
                        parallel%c_neibs (ii,myblock-block0+1) = 0
                        parallel%c_tneibs(ii,myblock-block0+1) = -1
                endif

                if (sten_memb(ii) == 0) then
                        write(9,*) "warning - accessed an unexpected part of &
                                &indexg! myblock,ii=",myblock,ii
                endif
        enddo
enddo

end subroutine calc_my_cneibs















!  3. does to c_neib what comm_neib does to neib, but does not 
!touch the communications (will be done later)

!  transformrs parallel%cneibs to local form like in comm_neigh
!  creates too csr matrices - one for the internal points and one for the external points
!  these will be used in the new graph-stencil subroutine
! #not ready#    also defines an MPI type and the 
!topologically aware communication pattern for folded stencil
subroutine comm_cneib(parallel, norder, blocksizes)

use parallel_data_module
use stencil_things
use grid_module
use aux, only : c_locate_part

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_alltoallv, mpi_integer
#else
use mpi
#endif
#endif

implicit none
!
!  Input/Output variables:
!
type(parallel_data), intent(inout) :: parallel
!  stencil depth
integer, intent(in) :: norder
integer, dimension(3), intent(in):: blocksizes
!
! Working Variables:
!
integer, dimension(3) :: maxBlocks
integer :: maxmaxBlocks
integer :: nnodes, iam, node
integer ielem,jelem,istart,jstart
integer neibblock,ineib,mydim,mycdim
integer ioffset,ncur

logical, dimension(:,:), allocatable :: sentto
integer, dimension(:), allocatable :: received

integer, dimension(:), allocatable :: &
        cirows,isendcount,irecvcount,myrecblocks,mysenblocks
  
integer :: neibs_num,neibsize

integer i, iblock
integer myblock,block0,block1,nblocks

integer icount,nelem,mxelem,foldvol

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif
#endif

! ---------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

!  Initializations
iam = parallel%colgroup_iam
nnodes = parallel%nprow

allocate(cirows(0:nnodes))
allocate(sentto(parallel%mycdim,0:nnodes))
allocate(isendcount(0:nnodes))
allocate(irecvcount(0:nnodes))
allocate(received(parallel%nwedge_c))
allocate(myrecblocks(parallel%nwedge_c))
allocate(mysenblocks(parallel%nwedge_c))

cirows(:) = parallel%cirows(:)
ioffset = cirows(parallel%colgroup_iam) - 1
mydim = parallel%mydim
mycdim = parallel%mycdim

maxBlocks(:) = norder/blocksizes(:)
maxmaxBlocks = maxval(maxBlocks(:))
neibs_num = 6 + 2*parallel%lap_dir_num
! still not working with more than 0 lap_dir_num
neibsize = maxmaxBlocks*neibs_num 

myrecblocks(:) = 0
mysenblocks(:) = 0
received(:) = -1
parallel%c_irecvp(:) = 0 
parallel%c_jsendp(:) = 0
isendcount(:) = 0
irecvcount(:) = 0

sentto(:,:) = .false.


block0 = parallel%cirows(parallel%colgroup_iam)
block1 = parallel%cirows(parallel%colgroup_iam+1) - 1
nblocks = block1 - block0 + 1




ncur = 0
do ineib = 1, neibsize
do myblock = 1, nblocks
        neibblock = parallel%c_neibs(ineib,myblock)

        ! neibblock == 0
        ! This one is not part of the folded stencil
        if (neibblock < 1) cycle

        node = c_locate_part(neibblock, nnodes, cirows(:), &
                parallel%colgroup_iam)

        if (node /= parallel%colgroup_iam) then
                if (.not. sentto(myblock,node)) then
                        parallel%c_jsendp(node) = parallel%c_jsendp(node) + 1
                        sentto(myblock,node) = .true.
                endif

                if (received(neibblock) == -1) then
                        parallel%c_irecvp(node) = parallel%c_irecvp(node) + 1
                        ncur = ncur + 1
                        mysenblocks(ncur) = neibblock
                        received(neibblock) = node
                endif
        endif
enddo
enddo





!
!  Find where info from (irecvp) and to (jsendp) each proc starts
!
ielem = parallel%c_irecvp(0)
jelem = parallel%c_jsendp(0)
parallel%c_irecvp(0) = 1
parallel%c_jsendp(0) = 1
do node = 1, nnodes
        istart = parallel%c_irecvp(node-1) + ielem
        jstart = parallel%c_jsendp(node-1) + jelem
        ielem = parallel%c_irecvp(node)
        jelem = parallel%c_jsendp(node)
        parallel%c_irecvp(node) = istart
        parallel%c_jsendp(node) = jstart
enddo






!
!  Use received and senblocks arrays to paste together the columns 
!  I will need. Reset received to zero wherever it has something
!  else. block are according to the global indexing
!
do i = 1, ncur
        myblock = mysenblocks(i)
        node = received(myblock)
        received(myblock) = -1
        myrecblocks( parallel%c_irecvp(node) ) = myblock
        parallel%c_irecvp(node) = parallel%c_irecvp(node) + 1
enddo





!
!  Restore the ip index to starting points in the "appended vector"
!  for each node. This is local now (eg irecvp(0) = 1 + nblocks)
!
do i = nnodes-1, 1, -1
        parallel%c_irecvp(i) = parallel%c_irecvp(i-1) + nblocks
enddo
parallel%c_irecvp(0) = 1 + nblocks





!
!  Go through parallel%c_neibs array to set the neigh global
!  indexing to a local. Notice the order of the loops must be the
!  same as in previous loops over ineib,myblock
!  IMPORTANT: Since this is not 1-to-1 mapping, the same block may
!  be accessed as a neighbor of many blocks in parallel%c_neibs. To
!  remember where this block resides in the new order, the received
!  array now records the position of the first time this block
!  (neighbor) is encountered.
!
do ineib = 1, neibsize
do myblock = 1, nblocks
        neibblock = parallel%c_neibs(ineib,myblock)

        if (neibblock < 1) cycle

        node = c_locate_part(neibblock, nnodes, cirows(:), &
                parallel%colgroup_iam)

        if (node /= parallel%colgroup_iam) then
                ! First time encountered. Change irecvp, received
                if (received(neibblock) == -1) then
                        ! write(9,*) "I am ext neibblock, node-", neibblock, node
                        received(neibblock) = parallel%c_irecvp(node)
                        parallel%c_irecvp(node) = parallel%c_irecvp(node) + 1
                endif

                parallel%c_neibs(ineib,myblock) = received(neibblock)
        else
                ! AJB: prune the tree towards nwedge_c+1
                if (neibblock == parallel%nwedge_c+1) cycle

                ! write(9,*) "I am internal neibblock, node-", neibblock, node
                parallel%c_neibs(ineib,myblock) = neibblock - ioffset 
        endif
enddo
enddo






!
!  Restore again the irecvp index to starting points, but in the 
!  non-appended vector to be used in the alltoall
!
!
do i = nnodes-1, 1, -1
        parallel%c_irecvp(i) = parallel%c_irecvp(i-1) - nblocks
enddo
parallel%c_irecvp(0) = 1 





!
!  Communicate the information from other processors' irecvp into 
!  the appropriate jsendp locations. This is an alltoallv step 
!  where the j-th section of recblocks (from irecvp(j) to irecvp(j+1)-1) on 
!  processor i, goes to the j-th processor senblocks between its 
!  jsendp(i) and jsendp(i+1)-1.
!
do i = 0, nnodes-1
        isendcount(i) = parallel%c_irecvp(i+1) - parallel%c_irecvp(i)
        irecvcount(i) = parallel%c_jsendp(i+1) - parallel%c_jsendp(i)
enddo

do i = 0, nnodes
        parallel%c_irecvp(i) = parallel%c_irecvp(i) - 1
        parallel%c_jsendp(i) = parallel%c_jsendp(i) - 1
enddo


#ifdef MPI
call mpi_alltoallv(myrecblocks(:), isendcount(:), parallel%c_irecvp(:), &
        mpi_integer, &
        mysenblocks(:), irecvcount(:), parallel%c_jsendp(:), mpi_integer, &
        colgroup_comm_f08, mpinfo)
#endif









!
!  Finally, restore irecvp and jsendp indices 
!
do i = 0, nnodes
        parallel%c_irecvp(i) = parallel%c_irecvp(i) + 1 + nblocks
        parallel%c_jsendp(i) = parallel%c_jsendp(i) + 1
enddo

parallel%mycworkdim = mycdim + parallel%c_irecvp(nnodes) - parallel%c_irecvp(0)
write(9,*) "comm_cneib - my cworkdim is now - ", parallel%mycworkdim
parallel%buffdim = (parallel%c_irecvp(nnodes) - parallel%c_irecvp(0))*PRODUCT(blocksizes)
write(9,*) "size of buffer is always ", parallel%buffdim







! probably not needed - 
! change the neib structure so that instead of nwedge_c+1
! the external blocks are at mycdim+ irecvp(nnodes)-irecvp(0) + 1
! this has to be done this way since we cannot expect each PE to
! allocate the entire wedge!
do myblock = 1, mycdim
do iblock = 1, neibsize
        neibblock = parallel%c_neibs(iblock,myblock)

        if (neibblock > parallel%nwedge_c) then
                !write(9,*) "comm_cneib: found external in iblock",iblock
                parallel%c_neibs(iblock,myblock) = parallel%mycworkdim + 1
                !write(9,*) "comm_cneib: now iblock is",parallel%cneibs(iblock,myblock)
        endif
enddo
enddo



!  Change the senblocks to local numbering (subtract the offset)
do i = 1, parallel%c_jsendp(nnodes)-1
        mysenblocks(i) = mysenblocks(i) - ioffset
enddo



! copy senblocks to global data, allocating only what we need
allocate(parallel%c_senblocks(parallel%c_jsendp(nnodes)-1))
parallel%c_senblocks(:) = mysenblocks(1:parallel%c_jsendp(nnodes)-1)



deallocate(cirows)
deallocate(sentto)
deallocate(isendcount)
deallocate(irecvcount)
deallocate(received)
deallocate(myrecblocks)
deallocate(mysenblocks)




write(9,*) 'COMM: bounary exchange information between PEs:'
icount = 0
mxelem = 0
do i = 0, nnodes-1
        nelem = parallel%c_jsendp(i+1) - parallel%c_jsendp(i)
        write(9,*) 'COMM:: sending PE ',i ,' #blocks:', nelem
        mxelem = mxelem + nelem
        if (nelem /= 0) icount = icount +1
enddo

parallel%c_maxcomm  = mxelem
parallel%c_maxcomm2 = parallel%c_irecvp(nnodes) - parallel%c_irecvp(0)
parallel%numedges = icount

foldvol = product(blocksizes)
write(9,*) 'I send data to  ', icount, ' MPI PEs, a total of ', &
        parallel%c_maxcomm, ' blocks, equivalent to', &
        parallel%c_maxcomm*foldvol, ' elements'
write(9,*) 'Also, I receive from these PEs: ', parallel%c_maxcomm2, ' blocks'
write(9,*) 'my workvector _could_ thus have ', parallel%mycworkdim, ' blocks'
write(9,*) 'BUT NOT ACTUALLY, since we are going to access the comm buffer directly!'

#ifdef MPI
write(9,*) 'now creating the topologically aware communicator with the dedicated mpi type'
call block_topo_aware(parallel)
#endif

write(9,*) '...done'


end subroutine comm_cneib















#ifdef MPI
subroutine block_topo_aware(parallel)
!  This is the topo_aware version that creates 
! colgroup_comm_c_topo based on c_fold_type
!
!  MPI_DIST_GRAPH_CREATE_ADJACENT is a scalable communicator creator
!  That creates a topologically aware communicator to use in 
!  the boundary exchange inside matvec, laplacian, etc.
!  
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_info_null, &
        mpi_dist_graph_create_adjacent, &
        mpi_dist_graph_neighbors_count, &
        mpi_dist_graph_neighbors, &
        mpi_comm_rank, mpi_comm_free
#else
use mpi
#endif
use parallel_data_module
implicit none
!
!   I/O variables
!
type(parallel_data), intent(inout) :: parallel
!
!   Work vars
!
integer :: graph_count, nnodes, inode, ipack, irank0, irank1
integer, dimension(parallel%nprow) :: nelem_in, nelem_out
!type(MPI_Info) :: info !supposedly has some hints on the graph.
!integer :: info
logical :: reorder   !wether to reorder ranks in new comm
!
#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
type(mpi_comm) :: comm_dist_graph_f08
type(mpi_comm) :: comm_dist_graph_reorder_f08
#else
integer :: colgroup_comm_f08
integer :: comm_dist_graph_f08
integer :: comm_dist_graph_reorder_f08
#endif
#endif
!
!   Topology data
!
integer :: graph_degree !size of arrays needed to describe local communication
!   Actual local communication data
integer :: max_in_degree, max_out_degree
integer, dimension(0:parallel%numedges-1) :: sources
integer, dimension(0:parallel%numedges-1) :: source_weights
integer, dimension(0:parallel%numedges-1) :: destinations
integer, dimension(0:parallel%numedges-1) :: destination_weights
! integer arrays with the j-th element containing the number
! of elements to send to neighbor j
integer, dimension(0:parallel%numedges-1) :: sendcounts
integer, dimension(0:parallel%numedges-1) :: recvcounts
! integer arrays with the j-th element containing the displacement to
! send/recvbuff for the j-th neighbor data
integer, dimension(0:parallel%numedges-1) :: sdispls
integer, dimension(0:parallel%numedges-1) :: rdispls
!
! verification
!
integer :: source_check
integer :: destination_check
logical :: weight_check

! ---------------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

sources = 0
source_weights = 0
destinations = 0
destination_weights = 0
sendcounts = 0
recvcounts = 0
sdispls = 0
rdispls = 0


graph_degree = parallel%numedges
nnodes = parallel%nprow

do inode = 0, nnodes-1
        nelem_in(inode+1) = &
                parallel%c_jsendp(inode+1) - parallel%c_jsendp(inode)
        nelem_out(inode+1) = &
                parallel%c_irecvp(inode+1) - parallel%c_irecvp(inode)
enddo
! write(9,*) 'this is what I have right now:'
! write(9,*) 'nelem_in', nelem_in
! write(9,*) 'nelem_out', nelem_out

!    graph_count=size(nelem_in)
!    write(9,*) 'size(nelems)', graph_count

graph_count = 0
do inode = 0, nnodes-1
        if (nelem_in(inode+1) /= 0) then
                sources(graph_count) = inode
                source_weights(graph_count) = nelem_in(inode+1)
                graph_count = graph_count + 1
        endif
enddo

graph_count = 0
do inode = 0, nnodes-1
        if (nelem_out(inode+1) /= 0) then
                destinations(graph_count) = inode
                destination_weights(graph_count) = nelem_out(inode+1)
                graph_count = graph_count + 1
        endif
enddo

reorder = .false.

! call MPI_INFO_CREATE(info, mpinfo)

!info = MPI_INFO_NULL

#ifdef STABLE_ALLTOALLV
#ifdef WITH_MPI_F08
parallel%colgroup_comm_c_topo = colgroup_comm_f08%mpi_val
#else
parallel%colgroup_comm_c_topo = colgroup_comm_f08
#endif

max_in_degree = parallel%numedges
max_out_degree = parallel%numedges

do inode = 0, max_in_degree-1
        sendcounts(inode) = parallel%c_jsendp(sources(inode)+1) - &
                parallel%c_jsendp(sources(inode))
enddo

if (parallel%numedges /= 0) sdispls(0) = 0
do ipack = 1, max_in_degree-1
        sdispls(ipack) = sdispls(ipack-1) + sendcounts(ipack-1)
enddo

do inode = 0, max_out_degree-1
        recvcounts(inode) = parallel%c_irecvp(destinations(inode)+1) - &
                parallel%c_irecvp(destinations(inode))
enddo

if (parallel%numedges /= 0) rdispls(0) = 0
do ipack = 1, max_out_degree-1
        rdispls(ipack) = rdispls(ipack-1) + recvcounts(ipack-1)
enddo

allocate(parallel%c_sendcounts(0:parallel%numedges-1))
allocate(parallel%c_sources(0:parallel%numedges-1))
allocate(parallel%c_sdispls(0:parallel%numedges-1))
parallel%c_sendcounts(:) = sendcounts(:)
parallel%c_sources(:) = sources(:)
parallel%c_sdispls(:) = sdispls(:)

allocate(parallel%c_recvcounts(0:parallel%numedges-1))
allocate(parallel%c_destinations(0:parallel%numedges-1))
allocate(parallel%c_rdispls(0:parallel%numedges-1))
parallel%c_recvcounts(:) = recvcounts(:)
parallel%c_destinations(:) = destinations(:)
parallel%c_rdispls(:) = rdispls(:)

write(9,*) ' STABLE BLOCK ALLTOALLV COMMUNICATION DATA UPDATED FOR EACH PE '
return
#endif

! KHL: Not sure why mpi_dist_graph_create_adjacent() must have mpinfo
!      though it is said to be optional on the spec...
!      Perhaps it is a bug of openmpi/3.0.0. 
!      If mpinfo is removed, there will be runtime error. So I put it 
!      in the arguments for now.
call mpi_dist_graph_create_adjacent(colgroup_comm_f08, &
        graph_degree, sources(:), source_weights(:), &
        graph_degree, destinations(:), destination_weights(:), &
        mpi_info_null, reorder, comm_dist_graph_f08, mpinfo)

write(9,*) ' NOTE: A NEIGHBORHOOD GRAPH COMMUNICATOR WAS CREATED!'

call mpi_dist_graph_neighbors_count(comm_dist_graph_f08, source_check, &
        destination_check, weight_check, mpinfo)

write(9,*) 'block_topo_aware: I am now aware that I communicate with', &
        source_check, 'PEs'
if (source_check-destination_check /= 0) then
        write(9,*) '?????? how come you are sending and receiving from &
                &different number of PEs?'
        write(9,*) 'This is VERY WRONG.'
        ! should quit program 
endif
write(9,*) ''

!call MPI_TOPO_TEST(parallel%group_comm,inode,mpinfo)
!write(9,*) 'topo_test returns:',inode

!actually change stuff for communication:
!we call the graph_neighbors to make sure mpi got the message about the communication pattern
#ifdef MPI
#ifdef WITH_MPI_F08
parallel%colgroup_comm_c_topo = comm_dist_graph_f08%mpi_val
#else
parallel%colgroup_comm_c_topo = comm_dist_graph_f08
#endif
#endif

max_in_degree = parallel%numedges
max_out_degree = parallel%numedges
call MPI_Dist_graph_neighbors(comm_dist_graph_f08, &
        max_in_degree, sources(:), source_weights(:), &
        max_out_degree, destinations(:), destination_weights(:), mpinfo)

do inode = 0, max_in_degree-1
        sendcounts(inode) = parallel%c_jsendp(sources(inode)+1) - &
                parallel%c_jsendp(sources(inode))
enddo

if (parallel%numedges /= 0) sdispls(0) = 0
do ipack = 1, max_in_degree-1
        sdispls(ipack) = sdispls(ipack-1) + sendcounts(ipack-1)
enddo

do inode = 0, max_out_degree-1
        recvcounts(inode) = parallel%c_irecvp(destinations(inode)+1) - &
                parallel%c_irecvp(destinations(inode))
enddo

if (parallel%numedges /= 0) rdispls(0) = 0
do ipack = 1, max_out_degree-1
        rdispls(ipack) = rdispls(ipack-1) + recvcounts(ipack-1)
enddo

allocate(parallel%c_sendcounts(0:parallel%numedges-1))
allocate(parallel%c_sources(0:parallel%numedges-1))
allocate(parallel%c_sdispls(0:parallel%numedges-1))
parallel%c_sendcounts(:) = sendcounts(:)
parallel%c_sources(:) = sources(:)
parallel%c_sdispls(:) = sdispls(:)

allocate(parallel%c_recvcounts(0:parallel%numedges-1))
allocate(parallel%c_destinations(0:parallel%numedges-1))
allocate(parallel%c_rdispls(0:parallel%numedges-1))
parallel%c_recvcounts(:) = recvcounts(:)
parallel%c_destinations(:) = destinations(:)
parallel%c_rdispls(:) = rdispls(:)

write(9,*) "block topo, some debug data:"
write(9,*) "sources:"
write(9,*) parallel%c_sources(:)
write(9,*) "destinations:"
write(9,*) parallel%c_destinations(:)
write(9,*) "sdispls:"
write(9,*) parallel%c_sdispls
write(9,*) "rdispls:"
write(9,*) parallel%c_rdispls

write(9,*) ' BLOCK-NEIGHBORHOOD COMMUNICATION DATA UPDATED FOR EACH PE '

! specific test - should we start working towards rank reordering?
!
! KHL: Not sure why mpi_dist_graph_create_adjacent() must have mpinfo
!      though it is said to be optional on the spec...
!      Perhaps it is a bug of openmpi/3.0.0. 
!      If mpinfo is removed, there will be runtime error. So I put it 
!      in the arguments for now.
call MPI_Dist_graph_create_adjacent(colgroup_comm_f08, &
        graph_degree, sources(:), source_weights(:), &
        graph_degree, destinations(:), destination_weights(:), &
        mpi_info_null, .true., comm_dist_graph_reorder_f08, mpinfo)
call MPI_Comm_rank(comm_dist_graph_f08, irank0, mpinfo)
call MPI_Comm_rank(comm_dist_graph_reorder_f08, irank1, mpinfo)
call MPI_Comm_free(comm_dist_graph_reorder_f08, mpinfo)
if (irank0 /= irank1) then
        write(9,*) 'block_topo_ware: RANK REORDER ?? I am PE rank', irank0, &
                'but MPI would like me to be rank', irank1, '!!'
else
        !    write(9,*) 'topo_ware: I am PE rank',irank0,'both in the group comm and the topo comm'
endif

end subroutine block_topo_aware
#endif















!  4. dumps c_neibs for a better data representation
subroutine convert_to_graphs(parallel, folded_stencil_depth)

! converts a neib format to 2 csr sparse matrices which represent two graphs
! 1) the internal neib list - representing a dense mtrx of size mydim*mydim
! 2) the external neib list - representing a dense mtrx of size mydim*comm_size
!    where comm_size is the number of vertices that are on other PEs
! These are global variables inside "stencil_things"
!
use stencil_things
use parallel_data_module
implicit none

integer, intent(in) :: folded_stencil_depth
type(parallel_data), intent(in) :: parallel
!integer, intent(in) :: comm_size

type(int_coo) :: mycoo, extcoo
integer :: findnrows, findncols_coo, findncols_csr

!!!! STEP I - convert cneib to coo format and split to internal and external !!!!!
!  write(9,*) "convert_to_graphs :: converting c_neib to coo fomrat"
call mycoo%init()
call extcoo%init()

!  write(9,*) "block_neib - some debug data:"
call neib2coo_int(parallel, folded_stencil_depth, mycoo, extcoo)
    
!debug - print matrices
!  write(9,*) "block_neib - nzcount",mycoo%nnz
!  write(9,*) "convert_to_graphs :: writing coo matrices to file"
!    call cooprint_with_id(mycoo,parallel%iam,filename='my')
!  if (extcoo%nnz >0) then
!    call cooprint_with_id(extcoo,parallel%iam,filename='ext_unsorted')
!   endif



!  write(9,*) "convert_to_graphs :: proceeding to step II - allocation of global csr mtxs"


!!!! STEP II - convert coos to csr and store inside parallel data structure!!!!!
call my_sten_edges%init()

! KHL: Now I set findnrows to parallel%mycdim. But if we separate 
!       __Tmyedges() and __t_matvec_diag_slice() from the same loop,
!       then I think we can use findnrows=mycoo%row(mycoo%nnz)
findnrows = parallel%mycdim
!findnrows=mycoo%row(mycoo%nnz)

call my_sten_edges%alloc(nrows=findnrows, nzcount=mycoo%nnz)

!  write(9,*) "properties of my_sten_edges:"
!  write(9,*) "nnz", my_sten_edges%nnz
!  write(9,*) "nrows", my_sten_edges%nrows
!  write(9,*) "findnrows was", findnrows

call ext_sten_edges%init()

if (extcoo%nnz > 0) then
        ! we allocate the ext csr to have the same amount of rows 
        ! since it is easier to distribute work that way.
        !findnrows=extcoo%row(extcoo%nnz)
else
        findnrows = -1
endif

write(9,*) "properties of ext_sten_edges:"
write(9,*) "findnrows was", findnrows

call ext_sten_edges%alloc(nrows=findnrows, nzcount=extcoo%nnz)


!  write(9,*) "nnz", ext_sten_edges%nnz
!  write(9,*) "nrows", ext_sten_edges%nrows







!  write(9,*) "convert_to_graphs ::  step III  - converting to csr"
!!!! STEP III - convert coos to csr and store inside parallel data structure!!!!!
call coo2csr_int(mycoo, my_sten_edges)







if (extcoo%nnz > 0) then
        !write(9,*) "done with my, doing ext"
        ! unlike the internal elements, the external ones may be unsorted
        call extcoo%sortbycol(row0=1, row1=findnrows)
        call coo2csr_int(extcoo, ext_sten_edges)
        !  call cooprint_with_id(extcoo,parallel%iam,filename='ext')
        !  call csrprint_with_id(ext_sten_edges,parallel%iam,filename='ext')
        !  write(9,*) "done with ext, sanity check time:"
endif







! KHL: The number of columns is equal to the number of values
!      in both coo and csr format, so checking ncols is the same
!      as checking nnz.
findncols_coo = maxval(mycoo%col(:))
findncols_csr = maxval(my_sten_edges%cols(:))

if (findncols_coo /= findncols_csr) then
        write(9,*) "big problem - structure of coo matrix &
                &not conserved in csr?"
        write(9,*) "encountered for internal coo"
endif

if (extcoo%nnz > 0) then
        findncols_coo = maxval(extcoo%col(:))
        findncols_csr = maxval(ext_sten_edges%cols(:))

        if (findncols_coo /= findncols_csr) then
                write(9,*) "big problem - structure of coo matrix &
                        &not conserved in csr?"
                write(9,*) "encountered for external coo"
        endif
endif

!  write(9,*) "convert_to_graphs ::  returning. you may now deallocate parallel%c_neib"
 
end subroutine convert_to_graphs












!  5. required conversion routines
subroutine neib2coo_int(parallel, folded_stencil_depth, mycoo, extcoo)
        ! coo representation - a sorted list of the form:
        ! (myrow,otherrow) = distance
        ! where distance is represented as the row in the neib table this 
        !element was found
        ! for this we need to indicate the stencil depth
        !
        ! there are two kinds of zeros to be encounterd - 
        ! "outside_domain" zero - these can be collected later if 
        !needed, but we turn them into real zeros
        ! "outside_stencil" zero - if the grid folding is not to 
        !a cube, there might be directions with fewer edges
        use constants
        use stencil_things
        use parallel_data_module
        use aux, only : mysecond

        implicit none

        type(parallel_data), intent(in) :: parallel
        integer, intent(in) :: folded_stencil_depth
        type(int_coo), intent(inout) :: mycoo, extcoo
        !type(int_coo) mycoo_t,extcoo_t

        integer :: norder, neibs_num, ext_nzcount, &
                folded_stencil_size, my_nzcount
        integer, allocatable :: nzcount_ish(:)

  
        integer cirow,mycrow,mycdim,ish,cooind,extind
        integer :: out_domain_nzcount
        real(dp) :: t0,t1

        ! --------------------------------------------------------

        mycdim = parallel%mycdim

        ! KHL: Note that for fold%blocksize(:) = (2,2,2) and grid%norder = 6, 
        !      folded_stencil_depth is 3 = maxval(6/(2,2,2))
        norder = folded_stencil_depth
        neibs_num = 6 + 2*parallel%lap_dir_num
        folded_stencil_size = neibs_num*norder

        if (norder /= 3) then
                write(9,*) "warning"
                write(9,*) "warning"
                write(9,*) "warning"
                write(9,*) "warning, I only tested this with 2x2x2 fold and 12 order stencil"
                write(9,*) "warning"
                write(9,*) "warning"
                write(9,*) "warning"
        endif

        ! go over all cneibs (here already in the local indexing)
        ! and begin the splitting by counting the number neighbors actually
        ! present on the PE local memory and those that are not
        ext_nzcount = 0
        allocate(nzcount_ish(folded_stencil_size))
        nzcount_ish(:) = 0

        ! KHL: used for checking. ext_nzcount+sum(nzcount_ish(:))+out_domain_nzcount
        !      should be equal to folded_stencil_size*parallel%mycdim
        out_domain_nzcount = 0


        call mysecond(t0)

        !$OMP PARALLEL DO COLLAPSE(2) &
        !$OMP& DEFAULT(SHARED) &
        !$OMP& PRIVATE(mycrow,ish,cirow) & 
        !$OMP& REDUCTION(+:ext_nzcount,out_domain_nzcount)
        do mycrow = 1, mycdim
        do ish = 1, folded_stencil_size
                cirow = parallel%c_neibs(ish,mycrow)

                ! KHL: 
                !  1 <= cirow <= mycdim : blocks owned by the proc itself
                !
                !  mycdim < cirow <= parallel%mycworkdim : needed blocks 
                !    owned by other procs
                !
                !  cirow > parallel%mycworkdim : should be impossible 
                !       because that's how we set parallel%mycworkdim
                !
                if (cirow > mycdim) then
                        !currently we are giving up on elements that 
                        ! are outside
                        ! so there will be more "internal" grid points 
                        ! than in the old comm_neib
                        if (cirow < parallel%mycworkdim+1) then
                                ext_nzcount = ext_nzcount + 1
                        else
                                out_domain_nzcount = out_domain_nzcount + 1
                        endif
                else
                        !$OMP ATOMIC
                        nzcount_ish(ish) = nzcount_ish(ish) + 1
                endif
        enddo
        enddo
        !$OMP END PARALLEL DO  

        call mysecond(t1)

        write(9,*) "time to sort through cneibs", t1-t0

        write(9,*) "non-zero elements present on this PE:", sum(nzcount_ish(:))
        write(9,*) "nnz elements received from other PEs:", ext_nzcount
        write(9,*) "out_domain_nzcount", out_domain_nzcount
        write(9,*) "sum(nzcount_ish(:))+ext_nzcount+out_domain_nzcount", &
                sum(nzcount_ish(:))+ext_nzcount+out_domain_nzcount
        write(9,*) "folded_stencil_size", folded_stencil_size
        write(9,*) "parallel%mycdim", parallel%mycdim




        my_nzcount = sum(nzcount_ish(:))






        call mycoo%alloc(my_nzcount) !+mycdim is added if need the diagonal (we don't)
        call extcoo%alloc(ext_nzcount)
        !symmetry, later:
        !  call mycoo_t%alloc(sum(nzcount_ish)) !+mycdim is added if need the diagonal (we don't)
        !  call extcoo_t%alloc(ext_nzcount)

        !actually create the coo matrices:
        !Difficult to do in openmp so we won't do it right now

        call mysecond(t0)

        cooind = 0
        extind = 0

        do mycrow = 1, mycdim
                ! convention says you add the diagonal first in each line, 
                !we do not need that,
                ! but if we would, the place is here and the time is now:

                ! cooind = cooind + 1
                ! mycoo%row(cooind) = mycrow
                ! mycoo%col(cooind) = mycrow
                ! mycoo%val(cooind) = 0

                do ish = 1, folded_stencil_size
                        cirow = parallel%c_neibs(ish,mycrow)

                        if (cirow > mycdim) then !single direction
                                if (cirow < parallel%mycworkdim+1) then
                                        !add to COO index of ext
                                        !we dont need the offset anymore -
                                        !so the first external element has to be in index 1, 
                                        !hence the subtracting of mycdim
                                        extind = extind + 1
                                        extcoo%row(extind) = mycrow
                                        extcoo%col(extind) = cirow - mycdim
                                        extcoo%val(extind) = ish

                                        ! symmetry - later
                                        !extcoo_t%val(extind) = parallel%c_tneibs(ish,mycrow)
                                endif
                        else !bidirectional!
                                ! KHL: This situation should never happen
                                if (cirow == 0) then
                                        write(9,*) "my column value is 0. how?", mycrow, ish
                                        write(9,*) "printing all of neibs for this row - "
                                        write(9,*) parallel%c_neibs(:,mycrow)
                                endif

                                ! KHL: This situation should never happen
                                if (cirow == mycrow) then
                                        if (parallel%c_tneibs(ish,mycrow) == 1) then
                                                write(9,*) "Hold on there, cirow==mycrow"
                                        else
                                                !write(9,*) "Hold on there, cirow==mycrow, itrans",mycrow,parallel%c_tneibs(ish,mycrow)
                                        endif
                                endif

                                !add to COO index
                                cooind = cooind + 1
                                mycoo%row(cooind) = mycrow
                                mycoo%col(cooind) = cirow
                                mycoo%val(cooind) = ish

                                ! symmetry - later
                                !mycoo_t%val(cooind) = parallel%c_tneibs(ish,mycrow)
                        endif
                enddo  !ish
        enddo ! mycrow = 1, mycdim

        call mysecond(t1)

        write(9,*) ""
        write(9,*) "Time used to create coo sparse matrices", t1-t0
        write(9,*) "non zero elements on ext coo", extind
        write(9,*) "non zero elements on local coo:", cooind
        write(9,*) "out_domain_nzcount", out_domain_nzcount
        write(9,*) ""


        ! now to sort the col vals for each row :

end subroutine neib2coo_int







subroutine try_print_csr(iam) !{{{
    use stencil_things
    implicit none
    integer, intent(in) :: iam
  call csrprint_with_id(my_sten_edges,iam,filename='my')
  call csrprint_with_id(ext_sten_edges,iam,filename='ext')
end subroutine !}}}














subroutine new_matvec_planning(parallel)
    use stencil_things
    use parallel_data_module
    implicit none
    
    type(parallel_data), intent(in)::parallel

  !debug - huge files:
  ! call try_print_csr(parallel%iam)
  !debug - inflate out.* with matvec openmp "order" 
  call print_matvec_order(parallel)
end subroutine

subroutine print_matvec_order(parallel)
#ifdef OMP
    use omp_lib
#endif
    use parallel_data_module
    use stencil_things, ONLY:ext_sten_edges,my_sten_edges
    implicit none

    type(parallel_data), intent(in)::parallel

    integer irow,grain_size,foldsize,tasklim,leftover
    integer :: mpinfo

     foldsize=8
     grain_size=5
     tasklim = my_sten_edges%nrows/grain_size
     tasklim = tasklim*grain_size
     leftover = my_sten_edges%nrows - tasklim


    write(9,*) "This is how I would do the internal elemets:"
!$OMP PARALLEL

!$OMP MASTER

    do irow=1,tasklim,grain_size

!$OMP TASK
    call report_process_my_irow(irow,grain_size)
!$OMP END TASK
    enddo !irow (my)
    write(9,*) "DEBUG: last row, nrows  ",irow,my_sten_edges%nrows

    if (leftover>0) then
        write(9,*) "DEBUG: some rows are leftover!, leftover,irow = ",leftover,irow
!$OMP TASK
    call report_process_my_irow(irow,leftover)
!$OMP END TASK
    endif

  call mpi_barrier(parallel%group_comm, mpinfo)

!$OMP END MASTER

!$OMP BARRIER

!$OMP MASTER
    write(9,*) "This is how I would do the external elemets:"

    write(9,*) "ext_sten_edges%nrows=", ext_sten_edges%nrows
    do irow=1,ext_sten_edges%nrows
!$OMP TASK
    call report_process_ext_irow(irow)
!$OMP END TASK

    enddo !irow
!$OMP END MASTER

!$OMP END PARALLEL


end subroutine print_matvec_order

subroutine report_process_my_irow(irow,grain_size)
#ifdef OMP
    use omp_lib
#endif
    use stencil_things, ONLY:my_sten_edges
    implicit none

    integer, intent(in) :: irow,grain_size
    integer nval,colstart,colend,icol,colptr,edgeval,jrow

    do jrow=irow,irow+grain_size-1

#ifdef OMP
    write(9,'("MYEDGES: thread_id - ",1x,I3,1x,"calling c0 element for row",1x,I7)') &
       OMP_GET_THREAD_NUM(),jrow
#else
    write(9,'("MYEDGES: thread_id - ",1x,I3,1x,"calling c0 element for row",1x,I7)') &
       1,jrow
#endif
    nval=my_sten_edges%rows(jrow+1)-my_sten_edges%rows(jrow)
    colstart=my_sten_edges%rows(jrow)
    colend=colstart+nval-1

    do icol=colstart,colend

    colptr=my_sten_edges%cols(icol)
    edgeval=my_sten_edges%vals(icol)

    ! line truncation sucks
#ifdef OMP
    write(9,'("MYEDGES: thread_id - ",1x,I3,1x,"calling edge",1x,I3,1x,"for (row,col)",1x,I7,I7)') &
       OMP_GET_THREAD_NUM(),edgeval,jrow,colptr
#else
    write(9,'("MYEDGES: thread_id - ",1x,I3,1x,"calling edge",1x,I3,1x,"for (row,col)",1x,I7,I7)') &
       1,edgeval,jrow,colptr
#endif

    enddo !icol (my)
    enddo
end subroutine report_process_my_irow

subroutine report_process_ext_irow(irow)
#ifdef OMP
    use omp_lib
#endif
    use stencil_things, ONLY:ext_sten_edges
    implicit none

    integer, intent(in) :: irow
    integer nval,colstart,colend,icol,colptr,edgeval


    nval=ext_sten_edges%rows(irow+1)-ext_sten_edges%rows(irow)
    colstart=ext_sten_edges%rows(irow)
    colend=colstart+nval-1

    do icol=colstart,colend

    colptr=ext_sten_edges%cols(icol)
    edgeval=ext_sten_edges%vals(icol)
#ifdef OMP
    write(9,'("EXTEDGES: thread_id - ",1x,I3,1x,"calling edge",1x,I3,1x,"for (row,col) of buffer",1x,I7,I7)') &
       OMP_GET_THREAD_NUM(),edgeval,irow,colptr
#else
    write(9,'("EXTEDGES: thread_id - ",1x,I3,1x,"calling edge",1x,I3,1x,"for (row,col) of buffer",1x,I7,I7)') &
       1,edgeval,irow,colptr
#endif

    enddo !icol (my)
end subroutine report_process_ext_irow

end module block_neib
