
!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  MPI_DIST_GRAPH_CREATE_ADJACENT is a scalable communicator
!  That would evolve to be especially good for PARSEC at the moment
!  
!  This subroutine will hopefully become something productive very soon
!  Currently does the following:
!
!  1. Creates a comm_dist_graph communicator 
!     based on local output from comm_neigh.F90, 
!  2. updates local communication data in parallel, to be used with
!     either neighborhood collectives (MPI3) or plain old isend/irecv
!
!
!
!  In the future:
!
!  1. Perhaps the send/recv buffers can be allocated here?
!
!  2. In the future this subroutine should be called before any data 
!     is distributed to the nodes, so reordering of the
!     ranks can be made based on the network topology 
!
! 
!===============================================================!
subroutine topo_aware(parallel)

use parallel_data_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_info_null, &
        mpi_dist_graph_create_adjacent, &
        mpi_dist_graph_neighbors_count, &
        mpi_dist_graph_neighbors, &
        mpi_comm_rank, mpi_comm_free
#else
use mpi
#endif
#endif


implicit none
!
!   I/O variables
!
type (parallel_data), intent(inout) :: parallel
!
!   
!
!   Work vars
!
integer :: graph_count, nnodes, inode, ipack, irank0, irank1
integer, dimension(parallel%group_size) :: nelem_in, nelem_out


! whether to reorder ranks in new comm
logical :: reorder

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
! supposedly has some hints on the graph.
!type(mpi_info) :: info

! the new communicator. 
type(mpi_comm) :: colgroup_comm_f08
type(mpi_comm) :: comm_dist_graph_f08
type(mpi_comm) :: comm_dist_graph_reorder_f08
#else
integer :: colgroup_comm_f08
integer :: comm_dist_graph_f08
integer :: comm_dist_graph_reorder_f08
#endif
#endif

!
!   Topology data
!
integer :: graph_degree !size of arrays needed to describe local communication
!   Actual local communication data
integer :: max_in_degree,max_out_degree
integer, dimension(0:parallel%countcomm-1) :: sources
integer, dimension(0:parallel%countcomm-1) :: source_weights
integer, dimension(0:parallel%countcomm-1) :: destinations
integer, dimension(0:parallel%countcomm-1) :: destination_weights
! integer arrays with the j-th element containing the number
! of elements to send to neighbor j
integer, dimension(0:parallel%countcomm-1) :: sendcounts
integer, dimension(0:parallel%countcomm-1) :: recvcounts
! integer arrays with the j-th element containing the displacement to
! send/recvbuff for the j-th neighbor data
integer, dimension(0:parallel%countcomm-1) :: sdispls
integer, dimension(0:parallel%countcomm-1) :: rdispls
!
! verification
!
integer :: source_check
integer :: destination_check
logical :: weight_check


! ---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

graph_degree = parallel%countcomm
nnodes = parallel%nprow

do inode = 0, nnodes-1
        nelem_in (inode+1) = parallel%jsendp(inode+1) - parallel%jsendp(inode)
        nelem_out(inode+1) = parallel%irecvp(inode+1) - parallel%irecvp(inode)
enddo

! write(9,*) 'this is what I have right now:'
! write(9,*) 'nelem_in', nelem_in
! write(9,*) 'nelem_out', nelem_out

!    graph_count=size(nelem_in)
!    write(9,*) 'size(nelems)', graph_count

graph_count = 0

do inode = 0, nnodes-1
        if (nelem_in(inode+1) /= 0) then
                sources(graph_count) = inode
                source_weights(graph_count) = nelem_in(inode+1)
                graph_count = graph_count + 1
        endif
enddo

graph_count=0

do inode = 0, nnodes-1
        if (nelem_out(inode+1) /= 0) then
                destinations(graph_count) = inode
                destination_weights(graph_count) = nelem_out(inode+1)
                graph_count = graph_count + 1
        endif
enddo

reorder = .false.

! call MPI_INFO_CREATE(info, mpinfo)

#ifdef STABLE_ALLTOALLV
#ifdef WITH_MPI_F08
parallel%colgroup_comm_topo = colgroup_comm_f08%mpi_val
#else
parallel%colgroup_comm_topo = colgroup_comm_f08
#endif

max_in_degree = parallel%countcomm
max_out_degree= parallel%countcomm

do inode = 0, max_in_degree-1
        sendcounts(inode) = parallel%jsendp(sources(inode)+1) - &
                parallel%jsendp(sources(inode))
enddo

if (parallel%countcomm /= 0) sdispls(0) = 0
do ipack = 1, max_in_degree-1
        sdispls(ipack) = sdispls(ipack-1) + sendcounts(ipack-1)
enddo

do inode = 0, max_out_degree-1
        recvcounts(inode) = parallel%irecvp(destinations(inode)+1) - &
                parallel%irecvp(destinations(inode))
enddo

if (parallel%countcomm /= 0) rdispls(0)=0
do ipack = 1, max_out_degree-1
        rdispls(ipack) = rdispls(ipack-1) + recvcounts(ipack-1)
enddo

allocate(parallel%sendcounts(0:parallel%countcomm-1))
allocate(parallel%sources(0:parallel%countcomm-1))
allocate(parallel%sdispls(0:parallel%countcomm-1))
parallel%sendcounts(:) = sendcounts(:)
parallel%sources(:) = sources(:)
parallel%sdispls(:) = sdispls(:)

allocate(parallel%recvcounts(0:parallel%countcomm-1))
allocate(parallel%destinations(0:parallel%countcomm-1))
allocate(parallel%rdispls(0:parallel%countcomm-1))
parallel%recvcounts(:) = recvcounts(:)
parallel%destinations(:) = destinations(:)
parallel%rdispls(:) = rdispls(:)

write(9,*) ' STABLE MPI ALLTOALLV COMMUNICATION DATA UPDATED FOR EACH PE '
return
#endif

#ifdef MPI
! KHL: Not sure why mpi_dist_graph_create_adjacent() must have mpinfo
!      though it is said to be optional on the spec...
!      Perhaps it is a bug of openmpi/3.0.0. 
!      If mpinfo is removed, there will be runtime error. So I put it 
!      in the arguments for now.
call mpi_dist_graph_create_adjacent(colgroup_comm_f08, &
        graph_degree, sources, source_weights, &
        graph_degree, destinations, destination_weights, &
        mpi_info_null, reorder, comm_dist_graph_f08, mpinfo)

write(9,*) ' NOTE: NEIGHBORHOOD GRAPH COMMUNICATOR WAS CREATED!'

call mpi_dist_graph_neighbors_count(comm_dist_graph_f08, source_check, &
        destination_check, weight_check, mpinfo)

write(9,*) 'topo_aware: I am now aware that I communicate with', source_check, 'PEs'

if (source_check - destination_check /= 0) then
        write(9,*) 'how come you are sending and receiving from different number of PEs?'
        write(9,*) 'This is VERY WRONG.'
        ! quit program 
endif

write(9,*) ''

 



!call MPI_TOPO_TEST(parallel%group_comm,inode,mpinfo)
!write(9,*) 'topo_test returns:',inode




!actually change stuff for communication:
!we call the graph_neighbors to make sure mpi got the message about the communication pattern
#ifdef WITH_MPI_F08
parallel%colgroup_comm_topo = comm_dist_graph_f08%mpi_val
#else
parallel%colgroup_comm_topo = comm_dist_graph_f08
#endif
max_in_degree = parallel%countcomm
max_out_degree=parallel%countcomm

call mpi_dist_graph_neighbors(comm_dist_graph_f08, &
        max_in_degree, sources(:), source_weights(:), &
        max_out_degree, destinations(:), destination_weights(:), mpinfo)

do inode = 0, max_in_degree-1
        sendcounts(inode) = parallel%jsendp(sources(inode)+1) - &
                parallel%jsendp(sources(inode))
enddo

if (parallel%countcomm /= 0) sdispls(0) = 0
do ipack = 1, max_in_degree-1
        sdispls(ipack) = sdispls(ipack-1) + sendcounts(ipack-1)
enddo

do inode = 0, max_out_degree-1
        recvcounts(inode) = parallel%irecvp(destinations(inode)+1) - &
                parallel%irecvp(destinations(inode))
enddo

if (parallel%countcomm /= 0) rdispls(0)=0
do ipack = 1, max_out_degree-1
        rdispls(ipack) = rdispls(ipack-1) + recvcounts(ipack-1)
enddo

allocate(parallel%sendcounts(0:parallel%countcomm-1))
allocate(parallel%sources(0:parallel%countcomm-1))
allocate(parallel%sdispls(0:parallel%countcomm-1))
parallel%sendcounts(:) = sendcounts(:)
parallel%sources(:) = sources(:)
parallel%sdispls(:) = sdispls(:)

allocate(parallel%recvcounts(0:parallel%countcomm-1))
allocate(parallel%destinations(0:parallel%countcomm-1))
allocate(parallel%rdispls(0:parallel%countcomm-1))
parallel%recvcounts(:) = recvcounts(:)
parallel%destinations(:) = destinations(:)
parallel%rdispls(:) = rdispls(:)

write(9,*) ' NEIGHBORHOOD COMMUNICATION DATA UPDATED FOR EACH PE '

! tests:
!
! KHL: Not sure why mpi_dist_graph_create_adjacent() must have mpinfo
!      though it is said to be optional on the spec...
!      Perhaps it is a bug of openmpi/3.0.0. 
!      If mpinfo is removed, there will be runtime error. So I put it 
!      in the arguments for now.
call mpi_dist_graph_create_adjacent(colgroup_comm_f08, &
        graph_degree, sources(:), source_weights(:), &
        graph_degree, destinations(:), destination_weights(:), &
        mpi_info_null, .true., comm_dist_graph_reorder_f08, mpinfo)

call mpi_comm_rank(comm_dist_graph_f08, irank0, mpinfo)
call mpi_comm_rank(comm_dist_graph_reorder_f08, irank1, mpinfo)
call mpi_comm_free(comm_dist_graph_reorder_f08, mpinfo)

if (irank0 /= irank1) then
        write(9,*) 'topo_ware: I am PE rank', irank0, &
                'but MPI would like me to be rank', irank1, '!!'
else
        !write(9,*) 'topo_ware: I am PE rank',irank0,'both in the group comm and the topo comm'
endif
#endif


end subroutine topo_aware
