function [evlb, evub, gamma2, d] = getevbnds(T,beta) 
%
% Compute lower/upper bound (evlb/evub) of the spectrum of a matrix 
% reduced to tridiagonal form T via Lanczos.
% Also returns the eigenvalues of T and the squares of the elements of 
% the 1st row of the eigenvector matrix
% usage:  [evlb, evub, S, D] = getevbnds(T,beta); 
%
[S,D]=eig(T);
d = diag(D);
gamma2 = S(1,:).^2;
gamma2 = gamma2';
evlb = inf;
evub = -inf;
n = size(T,1);

for j=1:n
   t = abs(beta*S(n,j));
   x = d(j) - t; 
   if (x < evlb) 
      evlb = x;
   end;
   x = d(j) + t; 
   if (x > evub) 
      evub = x;
   end;
end;
