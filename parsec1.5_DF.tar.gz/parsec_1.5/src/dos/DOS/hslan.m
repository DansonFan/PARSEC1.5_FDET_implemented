function [V,T,f]=hslan(H,S,v0,maxiter)
%
% [V,T,f]=hslan(H,S,v0,maxiter);
%
R = chol(S);
;
beta   = norm(v0);
v      = v0 / beta;
V(:,1) = v;
Av     = R'\(H*(R\v));
h      = V(:,1)'*Av;
T(1,1) = h;
f      = Av - V(:,1)*h;
   % ONE STEP OF REORTHOGONALIZATION
     s    = V(:,1)'*f;
     h    = h + s;
     f    = f - V(:,1)*s;
   %
%
% MAIN LOOP
for j = 2:maxiter
   beta = norm(f);
   T(j,j-1) = beta;
   v    = f/beta;
   V(:,j) = v;
   Av   = R'\(H*(R\v));
   h    = V'*Av;
   f    = Av - V*h;
   % ONE STEP OF REORTHOGONALIZATION
     s    = V'*f;
     h    = h + s;
     f    = f - V*s;
   %
   T(1:j,j) = h;
end;
T=(T+T')/2;
