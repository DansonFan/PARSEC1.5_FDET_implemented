function yy = cumdos(n, sigmas, thetas, gamma2s, xx) 
%
% compute the cumulative DOS from parameters returned from the hslandos
%
% yy = cumdos(n, sigmas, thetas, gamma2s, xx);
%
exp_fact = 2*sigmas.^2;
sqrt_fact = sqrt(1./exp_fact);
[Mdeg,nsamp] = size(thetas);
yy = zeros(size(xx));
for isamp = 1:nsamp
  for jdeg = 1:Mdeg
     prefactor = (n*gamma2s(jdeg,isamp)/nsamp)/sqrt(pi*exp_fact(jdeg,isamp));
     yy = yy + (prefactor/sqrt_fact(jdeg,isamp))*(erf(sqrt_fact(jdeg,isamp)*(xx-thetas(jdeg,isamp)))+1);
  end;
end;
yy = sqrt(pi)*yy/2.0;
