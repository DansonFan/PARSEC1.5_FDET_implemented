function [xx,yy] = getdos(H, S, opt)
%
% usage: [xx,yy] = getdos(H, S, opt)
%
% DOS estimation by Lanczos
%
% opt not used for now

n = size(H,1);
Nsamp = 10;
Mdeg = 100;
n = size(H,1);
Nsamp = 10;
if (n < 5000) Mdeg = 50; end;
if (n < 4000) Mdeg = 40; end;
if (n < 3000) Mdeg = 30; end;
if (n < 2000) Mdeg = 20; end;
if (n < 1000) Mdeg = 10; end;

evlbs = zeros(Nsamp,1);
evubs = zeros(Nsamp,1);
gamma2s = zeros(Mdeg,Nsamp);
thetas  = zeros(Mdeg,Nsamp);
for m = 1 : Nsamp
  w = randn(n,1); 
  v0 = w/norm(w);
  [V,T,f] = hslan(H,S,v0,Mdeg);
  T = (T+T')/2;
  T(find(abs(T(:))<1e-14)) = 0;
  [evlbs(m), evubs(m), gamma2s(:,m), thetas(:,m)] = getevbnds(T,norm(f));
end
evlb = max(evlbs);
evub = min(evubs);

% figures out sigma
mingap0 = evub - evlb;
for m = 1:Nsamp
   theta = [evlbs(m); thetas(:,m); evubs(m)];
   gaps  = theta(2:end)-theta(1:end-1);
   mingap = min(gaps);
   if (mingap > mingap0) 
      mingap = mingap0;
   end;
   gaps1 = (gaps(1:end-1)+gaps(2:end))/2;
   sigmas(:,m) = gaps1/sqrt(log(10e4));
end;
%
% guard against multiple eigenvalues
%
if (mingap < (evub-evlb)/n) 
   mingap = (evub-evlb)/n;
end;
del = mingap*10;
xx = evlb-del:del:evub+del;
yy = evaldos(n, evlb, evub, xx, thetas, gamma2s, sigmas);

function yy = evaldos(n, evlb, evub, xx, thetas, gamma2s, sigmas)

gFunc = @(x,sigma) 1.0/sqrt(2*pi*sigma^2) * exp( -x.^2 ./ (2.0*sigma^2) );

Mdeg = size(thetas,1);
Nsamp = size(thetas,2);
yy = zeros(size(xx));
for m = 1:Nsamp
  theta  = thetas(:,m);
  gamma2 = gamma2s(:,m);
  % Accumulate DOS
  for i=1:Mdeg
    yy = yy + gamma2(i) * gFunc( xx-theta(i), sigmas(i,m) );
  end     
end;
yy = n*(yy / Nsamp);
