function [shifts,maxevcnt] = getshifts(H, S, nev, nshifts, opts)
%
% shifts = getshifts(H, S, nev, nshifts, opts);
%
% partition the low end of spectrum that contains the 
% leading nev eigenvalues into slices with approximately
% nevloc = nev/nshifts eigenvalues in each slice. 
% 
% n is the size of the dimension of the problem, i.e. the total number of
% all eigenvalues.
% nev is the number of eigenvalues to be computed (at the low end of the spectrum)
% nshifts is the number of shifts to be generated
% (xx,yy) gives the spectral density (density of states)
% evcnts(j) gives the approximate eigenvalue count between 
% shifts(j-1) and shifts(j)
%
n = size(H,1);
Nsamp = 10;
Mdeg = 100;
if (n < 5000) Mdeg = 50; end;
if (n < 4000) Mdeg = 40; end;
if (n < 3000) Mdeg = 30; end;
if (n < 2000) Mdeg = 20; end;
if (n < 1000) Mdeg = 10; end;

evlbs = zeros(Nsamp,1);
evubs = zeros(Nsamp,1);
gamma2s = zeros(Mdeg,Nsamp);
thetas  = zeros(Mdeg,Nsamp);
for m = 1 : Nsamp
  w = randn(n,1); 
  v0 = w/norm(w);
  [V,T,f] = hslan(H,S,v0,Mdeg);
  T = (T+T')/2;
  T(find(abs(T(:))<1e-14)) = 0;
  [evlbs(m), evubs(m), gamma2s(:,m), thetas(:,m)] = getevbnds(T,norm(f));
end
evlb = max(evlbs);
evub = min(evubs);

% figures out sigma
for m = 1:Nsamp
   theta = [evlbs(m); thetas(:,m); evubs(m)];
   gaps  = theta(2:end)-theta(1:end-1);
   gaps1 = (gaps(1:end-1)+gaps(2:end))/2;
   sigmas(:,m) = gaps1/sqrt(log(10e4));
end;

nevloc = ceil(nev*1.1/nshifts);
upper = evub;
shifts = [];
for js = nshifts:-1:1
   afun = @(x)(cumdos(n, sigmas, thetas, gamma2s, x) - js*nevloc); 
   upper = Bisection(afun, evlb, upper);
   shifts = [upper shifts]; 
end;

function x = Bisection(afun, a, b)
tol = 1e-4;
maxiter = 300;
fa = afun(a);
for iter = 1:maxiter
   x = (a+b)/2;
   afunx = afun(x);
   if ( abs(afunx) < tol || b - a < tol) 
      break
   end;
   if ( sign(fa) == sign(afunx) )
      a = x;
      fa = afunx;
   else
      b = x;
   end
end;
if (iter > maxiter) 
   fprintf('Bisection failed, last bracket a = %11.3e, b = %11.3e\n', a, b);
end;

