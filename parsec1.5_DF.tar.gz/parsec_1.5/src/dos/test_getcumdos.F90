#define PI 3.141592653589793d0

include 'mkl_vsl.f90'

program test


implicit none

integer :: irow, jcol, total, n, info, lwork, io, counter, lx
real*8 :: rtmp
real*8, dimension(:,:), allocatable :: H, S
real*8, dimension(:), allocatable :: x, y, work, w

interface

        subroutine getcumdos(H, S, x, y, n)
                implicit none

                integer, intent(in) :: n
                real*8, dimension(:), allocatable, intent(out) :: x, y
                real*8, dimension(n,n), intent(in) :: H, S
        end subroutine getcumdos

end interface

n = 5832

allocate(H(n,n))
allocate(S(n,n))

H(:,:) = 0d0
S(:,:) = 0d0

counter = 0
open(9, file='H.txt', form='formatted')
do
        read(9,*,iostat=io) irow, jcol, rtmp
        if (io /= 0) exit
        H(irow,jcol) = rtmp
        counter = counter + 1
enddo
close(9)

!write(*,*) counter, H(1:5,1)

counter = 0
open(10, file='S.txt', form='formatted')
do
        read(10,*,iostat=io) irow, jcol, rtmp
        if (io /= 0) exit
        S(irow,jcol) = rtmp
        counter = counter + 1
enddo
close(10)

!write(*,*) counter

!allocate(w(n))
!allocate(work(1))
!call dsygv(1, 'V', 'U', n, H(:,:), n, S(:,:), n, w, work, -1, info)
!write(*,*) work(1)
!lwork = int(work(1))
!write(*,*) lwork
!deallocate(work)
!allocate(work(lwork))
!call dsygv(1, 'V', 'U', n, H(:,:), n, S(:,:), n, w, work, lwork, info)
!write(*,*) w

call getcumdos(H, S, x, y, n)
!write(*,*) size(x)

open(11, file='xy.txt', form='formatted')
do irow = 1, size(x)
        write(11,*) x(irow), y(irow)
enddo


deallocate(H)
deallocate(S)
if (allocated(x)) deallocate(x)
if (allocated(y)) deallocate(y)

end program test



! ===================================================================
subroutine getcumdos(H, S, x, y, n)

use MKL_VSL_TYPE
use MKL_VSL

implicit none

integer, intent(in) :: n
real*8, dimension(:), allocatable, intent(out) :: x, y
real*8, dimension(n,n), intent(in) :: H, S

integer :: Nsamp, Mdeg, m, jcol, irow, itmp
real*8 :: evlb, evub, rtmp, mingap, mingap0, del
real*8, dimension(:), allocatable :: v0, w, f, evlbs, evubs, theta, &
        gaps, gaps1
real*8, dimension(:,:), allocatable :: V, T, sigmas, gamma2s, thetas

type(VSL_STREAM_STATE) :: stream
integer :: errcode
integer :: brng, seed, method
real*8, external :: dnrm2

brng = VSL_BRNG_MT19937
seed = 777
method = VSL_RNG_METHOD_GAUSSIAN_ICDF

Nsamp = 10
Mdeg = 100

if (n < 5000) Mdeg = 50
if (n < 4000) Mdeg = 40
if (n < 3000) Mdeg = 30
if (n < 2000) Mdeg = 20
if (n < 1000) Mdeg = 10

allocate(v0(n))
allocate(w(n))
allocate(f(n))
allocate(evlbs(Nsamp))
allocate(evubs(Nsamp))
allocate(theta(Mdeg+2))
allocate(gaps(Mdeg+1))
allocate(gaps1(Mdeg))
allocate(V(n,Mdeg))
allocate(T(Mdeg,Mdeg))
allocate(gamma2s(Mdeg,Nsamp))
allocate(thetas(Mdeg,Nsamp))
allocate(sigmas(Mdeg,Nsamp))

f(:) = 0d0
V(:,:) = 0d0
T(:,:) = 0d0

!write(*,*) H(1:5,2:3)

errcode = vslnewstream(stream, brng, seed)
if (errcode /= 0) write(*,*) 'An error occurred'

do m = 1, Nsamp
        write(*,*) 'm', m
        errcode = vdrnggaussian(method, stream, n, w(:), 0d0, 1d0)
        if (errcode /= 0) write(*,*) 'An error occurred'

        rtmp = dnrm2(n, w(:), 1)
        v0(:) = w(:) / rtmp

        call hslan(H(:,:), S(:,:), v0(:), Mdeg, V(:,:), T(:,:), f(:), n)

        T(:,:) = (T(:,:) + transpose(T(:,:))) / 2d0

        do irow = 1, Mdeg
                do jcol = 1, Mdeg
                        if (T(irow,jcol) < 1d-14) then
                                T(irow,jcol) = 0d0
                        endif
                enddo
        enddo

        call getevbnds(T(:,:), dnrm2(n, f(:), 1), evlbs(m), evubs(m), &
                gamma2s(:,m), thetas(:,m), Mdeg)
        !write(*,*) 'evlbs(m)', evlbs(m)
        !write(*,*) 'evubs(m)', evubs(m)
enddo
!write(*,*) 'evlbs', evlbs
!write(*,*) 'evubs', evubs
!write(*,*) 'gamma2s', gamma2s
!STOP

errcode = vsldeletestream(stream)
if (errcode /= 0) write(*,*) 'An error occurred'

evlb = maxval(evlbs(:))
evub = minval(evubs(:))
!write(*,*) 'evlb', evlb
!write(*,*) 'evub', evub

! Figures out sigma
mingap0 = evub - evlb

do m = 1, Nsamp
        theta(1) = evlbs(m)
        theta(2:Mdeg+1) = thetas(:,m)
        theta(Mdeg+2) = evubs(m)

        gaps(:) = theta(2:Mdeg+2) - theta(1:Mdeg+1)
        mingap = minval(gaps(:))
        !write(*,*) 'mingap', mingap

        if (mingap > mingap0) then
                mingap = mingap0
        endif

        gaps1(:) = (gaps(1:Mdeg) + gaps(2:Mdeg+1)) / 2d0
        sigmas(:,m) = gaps1(:) / sqrt(log(10d4))
enddo
!write(*,*) 'gaps1', gaps1

! Guard against multiple eigenvalues
if (mingap < (evub - evlb) / n) then
        mingap = (evub - evlb) / n
endif

del = mingap
itmp = floor(((evub+del) - (evlb-del)) / del)

allocate(x(itmp))
allocate(y(itmp))
y(:) = 0d0

do jcol = 1, itmp
        x(jcol) = (evlb-del) + del*(jcol-1)
enddo
!write(*,*) 'del', del
!write(*,*) 'itmp', itmp
!write(*,*) 'x(1:5)', x(1:5)
!write(*,*) 'x(5830:)', x(5830:)
!STOP

call cumdos(n, sigmas, thetas, gamma2s, x, y, Mdeg, Nsamp, size(x))


deallocate(v0)
deallocate(w)
deallocate(f)
deallocate(evlbs)
deallocate(evubs)
deallocate(theta)
deallocate(gaps)
deallocate(gaps1)
deallocate(V)
deallocate(T)
deallocate(gamma2s)
deallocate(thetas)
deallocate(sigmas)

end subroutine getcumdos
! ===================================================================


! ===================================================================
subroutine hslan(H, S, v0, maxiter, V, T, f, n)

implicit none

integer, intent(in) :: maxiter, n
real*8, dimension(n), intent(inout) :: v0, f
real*8, dimension(n,n), intent(in) :: H, S
real*8, dimension(n,maxiter), intent(out) :: V
real*8, dimension(maxiter,maxiter), intent(out) :: T

integer :: info, irow, jcol
real*8 :: beta
real*8, dimension(:), allocatable :: Av, hh, ss
real*8, dimension(:,:), allocatable :: R
real*8, external :: dnrm2

allocate(Av(n))
allocate(R(n,n))

! R = chol(S)
R(:,:) = S(:,:)

call dpotrf('U', n, R(:,:), n, info)
if (info /= 0) write(*,*) 'error occurred'

do jcol = 1, n
        do irow = 1, jcol-1
                R(irow,jcol) = R(jcol,irow)
        enddo
enddo

!write(*,*) v0(1:5)
beta = dnrm2(n, v0(:), 1)
!write(*,*) 'beta', beta
v0(:) = v0(:) / beta
V(:,1) = v0(:)
!write(*,*) v0(1:5)

! Av = R' \ (H * (R \ v))
call dpotrs('U', n, 1, R(:,:), n, v0(:), n, info)
if (info /= 0) write(*,*) 'error occurred'
!write(*,*) v0(1:5)

call dgemv('N', n, n, 1d0, H(:,:), n, v0(:), 1, 0d0, Av(:), 1)

call dpotrs('L', n, 1, R(:,:), n, Av(:), n, info)
if (info /= 0) write(*,*) 'error occurred'

allocate(hh(1))
allocate(ss(1))

call dgemv('T', n, 1, 1d0, V(:,:), n, Av(:), 1, 0d0, hh(:), 1)
!write(*,*) 'hh', hh

T(1,1) = hh(1)
f(:) = Av(:) - V(:,1)*hh(1)

! One step of reorthogonalization
call dgemv('T', n, 1, 1d0, V(:,:), n, f(:), 1, 0d0, ss(:), 1)

!write(*,*) 'hh, ss', hh, ss
hh(1) = hh(1) + ss(1)

call dgemv('N', n, 1, -1d0, V(:,:), n, ss(:), 1, 1d0, f(:), 1)

deallocate(hh)
deallocate(ss)

! Main loop
do jcol = 2, maxiter
        !write(*,*) 'jcol', jcol
        beta = dnrm2(n, f(:), 1)
        !write(*,*) 'beta', beta
        T(jcol,jcol-1) = beta
        v0(:) = f(:) / beta
        V(:,jcol) = v0(:)
        !write(*,*) v0(1:5)

        ! Av = R' \ (H * (R \ v))
        call dpotrs('U', n, 1, R(:,:), n, v0(:), n, info)
        if (info /= 0) write(*,*) 'error occurred'

        call dgemv('N', n, n, 1d0, H(:,:), n, v0(:), 1, 0d0, Av(:), 1)

        call dpotrs('L', n, 1, R(:,:), n, Av(:), n, info)
        if (info /= 0) write(*,*) 'error occurred'

        allocate(hh(jcol))
        allocate(ss(jcol))

        call dgemv('T', n, jcol, 1d0, V(:,:), n, Av(:), 1, 0d0, hh(:), 1)
        call dgemv('N', n, jcol, 1d0, V(:,:), n, hh(:), 1, 0d0, f(:), 1)
        f(:) = Av(:) - f(:)
        !write(*,*) 'f', f(1:5)
        !write(*,*) 'sum(V)', sum(V)
        !write(*,*) 'sum(f)', sum(f)

        ! One step of reorthogonalization
        call dgemv('T', n, jcol, 1d0, V(:,:), n, f(:), 1, 0d0, ss(:), 1)
        !write(*,*) 'hh', hh
        !write(*,*) 'ss', ss
        !write(*,*) 'sum(hh)', sum(hh)
        !write(*,*) 'sum(ss)', sum(ss)
        hh(:) = hh(:) + ss(:)
        !write(*,*) 'sum(hh)', sum(hh)
        !write(*,*) 'sum(ss)', sum(ss)
        call dgemv('N', n, jcol, -1d0, V(:,:), n, ss(:), 1, 1d0, f(:), 1)

        T(1:jcol,jcol) = hh(:)
        !write(*,*) 'sum(T)', sum(T)
        !write(*,*) 'sum(f)', sum(f)

        deallocate(hh)
        deallocate(ss)
enddo

!write(*,*) 'jcol, maxiter', jcol, maxiter
T(:,:) = (T(:,:) + transpose(T(:,:))) / 2d0

end subroutine hslan
! ===================================================================



! ===================================================================
subroutine getevbnds(T, beta, evlb, evub, gamma2, d, Mdeg)

implicit none

integer, intent(in) :: Mdeg
real*8, intent(in) :: beta
real*8, intent(inout) :: evlb, evub
real*8, dimension(Mdeg), intent(inout) :: gamma2, d
real*8, dimension(Mdeg,Mdeg), intent(in) :: T

integer :: lwork, jcol, info
real*8 :: tt, x
real*8, dimension(:), allocatable :: work
real*8, dimension(:,:), allocatable :: S

allocate(S(Mdeg,Mdeg))
S(:,:) = T(:,:)

allocate(work(1))
call dsyev('V', 'U', Mdeg, S(:,:), Mdeg, d, work(:), -1, info)
if (info /= 0) write(*,*) 'An error occurred'

lwork = int(work(1))
deallocate(work)
allocate(work(lwork))
call dsyev('V', 'U', Mdeg, S(:,:), Mdeg, d, work, lwork, info)
if (info /= 0) write(*,*) 'An error occurred'

do jcol = 1, Mdeg
        gamma2(jcol) = S(1,jcol) * S(1,jcol)
enddo

evlb = huge(0d0)
evub = -huge(0d0)

do jcol = 1, Mdeg
        tt = abs(beta * S(Mdeg,jcol))
        x = d(jcol) - tt

        if (x < evlb) then
                evlb = x
        endif

        x = d(jcol) + tt

        if (x > evub) then
                evub = x
        endif
enddo

deallocate(S)

end subroutine getevbnds
! ===================================================================


! ===================================================================
!
! Compute the cumulative DOS from parameters returned from the hslandos
!
! ===================================================================
subroutine cumdos(n, sigmas, thetas, gamma2s, xx, yy, Mdeg, Nsamp, lxx)

implicit none

integer, intent(in) :: n, Mdeg, Nsamp, lxx
real*8, dimension(Mdeg,Nsamp), intent(in) :: sigmas, gamma2s, thetas
real*8, dimension(lxx), intent(in) :: xx
real*8, dimension(lxx), intent(inout) :: yy

integer :: irow, jcol
real*8 :: prefactor
real*8, dimension(:,:), allocatable :: exp_fact, sqrt_fact

allocate(exp_fact(Mdeg,Nsamp))
allocate(sqrt_fact(Mdeg,Nsamp))

do irow = 1, Mdeg
        do jcol = 1, Nsamp
                exp_fact(irow,jcol) = 2d0 * sigmas(irow,jcol) * sigmas(irow,jcol)
                sqrt_fact(irow,jcol) = sqrt(1d0 / exp_fact(irow,jcol))
        enddo
enddo
!write(*,*) 'exp_fact', exp_fact
!write(*,*) 'sqrt_fact', sqrt_fact
!write(*,*) 'exp_fact', exp_fact(1,1:5)
!write(*,*) 'sqrt_fact', sqrt_fact(1,1:5)

do irow = 1, Mdeg
        do jcol = 1, Nsamp
                prefactor = (real(n) * gamma2s(irow,jcol) / real(Nsamp)) / &
                        sqrt(PI * exp_fact(irow,jcol))
                !write(*,*) (real(n) * gamma2s(irow,jcol) / real(Nsamp))
                !write(*,*) sqrt(PI * exp_fact(irow,jcol))
                !write(*,*) 'prefactor', prefactor
                !STOP
                yy(:) = yy(:) + (prefactor / sqrt_fact(irow,jcol)) * &
                        (erf(sqrt_fact(irow,jcol) * &
                        (xx(:) - thetas(irow,jcol))) &
                        + 1)
        enddo
enddo

yy(:) = sqrt(PI) * yy(:) / 2d0

!write(*,*) 'prefactor', prefactor
!write(*,*) yy(1:10)
!STOP

deallocate(exp_fact)
deallocate(sqrt_fact)

end subroutine cumdos
! ===================================================================

