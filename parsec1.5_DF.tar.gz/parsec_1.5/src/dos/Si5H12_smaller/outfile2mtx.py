#!/usr/bin/env python3

"""
Please use dump_hamiltonian() in parsec.F90. It will output matrix entries to 
each out.??????.
This python script is to collect the matrix entries from the out.?????? files.
"""

import re
import glob

mtxfile = 'Si29H36_itr0.mtx'
irow = []
jcol = []
value = []

for outfile in glob.glob('./out.*'):
    with open(outfile, 'r') as ifs:
        data = ifs.read()

    for m in re.finditer('MTX:\s+(\S+)\s+(\S+)\s+(\S+)', data):
        irow.append(int(m.group(1)))
        jcol.append(int(m.group(2)))
        value.append(m.group(3))

with open(mtxfile, 'x') as ofs:
    ofs.write("%%MatrixMarket matrix coordinate real symmetric\n")
    ofs.write(str(max(irow))+' '+str(max(jcol))+' '+str(len(value))+'\n')

    for i in range(len(value)):
        ofs.write(str(irow[i]) + ' ' + str(jcol[i]) + ' ' + value[i] + '\n')
