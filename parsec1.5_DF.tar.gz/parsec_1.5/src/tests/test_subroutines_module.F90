
module test_subroutines_module



contains

subroutine test_chefsi()

use constants
use file_units
use parsec_global_data, only : parallel

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_barrier, &
        mpi_finalize
#else
use mpi
#endif
#endif

integer :: itmp
integer :: irow

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08 !< actual mpi_comm
#else
integer :: comm_f08 !< actual mpi_comm
#endif
#endif

! ---------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

write(9,*) 'f_outpar', f_outpar
write(f_outpar,*) "parallel%iam", parallel%iam

itmp = 0
do irow = 1, parallel%mydim
        itmp = itmp + 1
enddo

write(f_outpar,*) 'itmp', itmp

call mpi_barrier(comm_f08, mpinfo)
call mpi_finalize(mpinfo)
stop

end subroutine test_chefsi

end module test_subroutines_module
