!> @brief tests random capabilities and scaling
program randomtest

use constants, only : dp, dpc
use aux, only : mysecond

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08
#else
use mpi
#endif
#endif

#ifdef _OPENMP
use omp_lib
#endif

use prandom_module
implicit none
real(dp), parameter :: a = -1.d0
real(dp), parameter :: b = 1.d0
! problem specs
integer :: N !< numger of gridpoints
integer :: s !< number of states
! local quantities
integer :: ldn !< local leading dimension of vec
integer :: ndim0 !< typical number of gridpoints for this processor
integer :: mydim !< number of gridpoints for this processor
real(dp), allocatable :: vec(:,:)
real(dp), allocatable :: wholevec(:), wholevec2(:)
!DIR$ attributes align:64 :: vec, wholevec
! work
integer :: requested = MPI_THREAD_MULTIPLE
integer :: j
integer :: provided
integer :: ierr
! parallel components
integer :: comm
integer :: rank
integer :: mpisize
integer :: tid, ctid
! seed component
integer :: seed0
integer(kind=8) :: skip
type(random_generator) :: rangen
type(VSL_STREAM_STATE) :: stream
type(padded_stream), allocatable :: pstream(:)
real(dp), dimension(2) :: t_create, t_generate, t_delete, t_loop, t_inter
real(dp) :: t_sum_skip, t_sum_gen
t_sum_skip = 0
t_sum_gen = 0

call MPI_Init_thread(requested, provided, ierr)
comm = MPI_COMM_WORLD
call MPI_Comm_rank(comm, rank, ierr)
call MPI_Comm_size(comm, mpisize, ierr)
allocate(pstream(0:11))

N = 3800800
ndim0 = N/mpisize
mydim = ndim0
ldn = N-(mpisize-1)*ndim0
ldn = ldn + mod(ldn,16)
if(rank==mpisize-1) mydim = N-rank*ndim0
s = 80
skip=ndim0*rank
seed0 = 4095

allocate(vec(ldn,s))
allocate(wholevec(N))
allocate(wholevec2(N))
vec=0.d0
#if 0
call init_random_generator(rangen)
call alloc_random_generator(rangen)
call createStream(rangen % stream, 1, &
 rangen % brng, seed0, rank, mpisize)
if(rank >= 5) then
 call skipAheadStream(rangen % stream(0), int(skip,8))
endif
#if 1
call harvestStream(rangen % stream(0), rangen%method, vec, ldn, ndim0, a, b, ierr)
#endif
#elif 1
!$OMP PARALLEL SHARED(rangen) PRIVATE(tid)
#ifdef VSL_THREADED_RNG
tid = omp_get_thread_num()
ctid = omp_get_num_threads()
#else 
tid = 0
ctid = 1
#endif
!$OMP MASTER
call init_random_generator(rangen)
allocate(rangen % stream(0:ctid-1))
!$OMP END MASTER
!$OMP END PARALLEL
call mysecond(t_create(1))
tid = 0
ierr = vslNewStream(rangen % stream(tid) % stream, VSL_BRNG_MT19937, seed0)
! start
call mysecond(t_create(2))
write(*,'("RAND:CREATE ",E12.5)') (t_create(2)-t_create(1))
do j = 1,s
 ! skip to my location
 call mysecond(t_inter(1))
 ierr = vslSkipAheadStream(rangen % stream(tid) % stream, int(rank*ndim0,8))
 ! get numbers 
 call mysecond(t_generate(1))
#if 1 
 ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, rangen % stream(tid) % stream, mydim, vec(:,j), a, b) 
#else
 call random_number(vec(:,j))
#endif
 call mysecond(t_generate(2))
 ! skip to boundary
 ierr = vslSkipAheadStream(rangen % stream(tid) % stream, int(N - rank*ndim0 - mydim,8))
 call mysecond(t_inter(2))
#if 0
 write(*,'("RAND: GEN",I2.2," ",E12.5)') j, (t_generate(2)-t_generate(1))
 write(*,'("RAND:SKIP",I2.2," ",E12.5)') j, (t_inter(2)-t_inter(1))-(t_generate(2)-t_generate(1))
#endif
 t_sum_gen  = t_sum_gen  + (t_generate(2)-t_generate(1))
 t_sum_skip = t_sum_skip + (t_inter(2)-t_inter(1))-(t_generate(2)-t_generate(1))
enddo
call mysecond(t_delete(1))
ierr = vslDeleteStream(rangen % stream(tid) % stream)
call mysecond(t_delete(2))
write(*,'("RAND: GEN** ",E12.5)') t_sum_gen
write(*,'("RAND:SKIP** ",E12.5)') t_sum_skip
write(*,'("RAND:DELETE ",E12.5)') (t_delete(2)-t_delete(1))
ierr = vslNewStream(rangen % stream(tid) % stream, VSL_BRNG_MT19937, seed0)
ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, rangen % stream(tid) % stream, N, wholevec, a, b)
ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, rangen % stream(tid) % stream, N, wholevec2, a, b)
#else
!$OMP PARALLEL
#ifdef VSL_THREADED_RNG
tid = omp_get_thread_num()
#else 
tid = 0
#endif
!$OMP END PARALLEL
tid = 0
ierr = vslNewStream(pstream(tid) % stream, VSL_BRNG_MT19937, seed0)
! start
do j = 1,s
 ! skip to my location
 ierr = vslSkipAheadStream(pstream(tid) % stream, int(rank*ndim0,8))
 ! get numbers 
 ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, pstream(tid) % stream, mydim, vec(:,j), a, b)
 ! skip to boundary
 ierr = vslSkipAheadStream(pstream(tid) % stream, int(N - rank*ndim0 - mydim,8))
enddo
ierr = vslDeleteStream(pstream(tid) % stream)
ierr = vslNewStream(pstream(tid) % stream, VSL_BRNG_MT19937, seed0)
ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, pstream(tid) % stream, N, wholevec, a, b)
ierr = vdRngUniform(VSL_RNG_METHOD_UNIFORM_STD, pstream(tid) % stream, N, wholevec2, a, b)
#endif
open(rank+10)
write(rank+10,*) 'harvestStream:',ierr
write(rank+10,'("rank: ",I5," a=",E16.7," b=",E16.7)') rank,a,b
write(rank+10,'(A6,A9,A6,A6,A6)') 'size','N','s','ndim0','ldn'
write(rank+10,'(I6,I9,I6,I6,I6)') mpisize, N, s, ndim0, ldn
do j = 1,mydim
 write(rank+10,*) vec(j,1)
enddo
write(rank+10,*) '=== '
do j = 1,mydim
 write(rank+10,*) vec(j,2)
enddo
write(rank+10,*) '=== '
do j = 1,N
 write(rank+10,*) wholevec(j)
enddo
do j = 1,N
 write(rank+10,*) wholevec2(j)
enddo
close(rank+10)
deallocate(vec)

call MPI_Finalize(ierr)

end program
