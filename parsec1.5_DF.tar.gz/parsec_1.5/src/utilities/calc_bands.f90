module calc_bands_module

implicit none
contains

!=====================================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Author: ???
! 
! Problems: Yes. Reuses the eigensolver and something about nec not quite right
!
subroutine calc_bands(band_st, elec_st, pbc, pot, u_pot, solver, &
        parallel, grid, nloc_p_pot, clust, p_pot, ipr, ierr)

use constants, only : zzero, dzero, dp
use cluster_module
use electronic_struct_module
use potential_module
use non_local_psp_module
use eigen_solver_module
use eigval_module, only : eigval
use parallel_data_module
use pseudo_potential_module
use bandstruc_module
use pbc_module
use grid_module
use nonloc_module
use aux, only : matvec3
  
implicit none

! Input/Output variables:

! bands structure
type(bandstruc), intent(inout) :: band_st

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! grid
type(grid_data), intent(in) :: grid

! pbc
type(pbc_data), intent(inout) :: pbc

! potential related data
type(potential), intent(in) :: pot

! on-site Coulomb interaction related data
type(nonloc_pseudo_potential), intent(inout) :: u_pot

! solver related data
type(eigen_solver), intent(inout) :: solver

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! non local pseudo potential part
type(nonloc_pseudo_potential), intent(inout) :: nloc_p_pot

! pseudo_potential related data
type(pseudo_potential), intent(in) :: p_pot

! cluster data
type(cluster), intent(in) :: clust

! printout flag
integer, intent(in) :: ipr

! error flag, 400 < ierr < 421
integer, intent(out) :: ierr



! Work variables:

integer :: isp
integer :: kplp
integer :: offset
integer :: spnum
integer :: nrep
integer :: nmax
integer :: jj, kk, ll
integer :: original_ff_maxiter
integer :: total_nkpt
integer :: leftover_nkpt

real(dp), dimension(3) :: vec
real(dp), dimension(3) :: ktmp
real(dp) :: min_length

! kpoint list (Cartesian coordinates, units of inverse Bohr radius)
real(dp), dimension(:,:), allocatable :: tmp_kpts

! eigenvlues by kpoint number, spin index, state number
real(dp), dimension(:,:,:), allocatable :: tmp_eigs

! ----------------------------------------------------------------------

spnum = elec_st%nspin/elec_st%mxwd  
original_ff_maxiter = solver%ff_maxiter


!until we figure out what to do with symmetry
nrep = 1



! Conversion of kpoints of start and end of lines to
! cartesian coordinates of inverse Bohr radius
! by multiplying by reciprocal lattice verctors
do jj = 1, band_st%nlines
        call matvec3(op='N', mat=pbc%bvec(:,:), &
                vec=band_st%blines(jj)%start(:), mvec=vec(:))

        band_st%blines(jj)%startb(:) = vec(:)

        call matvec3(op='N', mat=pbc%bvec(:,:), &
                vec=band_st%blines(jj)%end(:), mvec=vec(:))

        band_st%blines(jj)%endb(:) = vec(:)
enddo
 




! Find the length of the shortest line 
do jj = 1, band_st%nlines
        vec(:) = band_st%blines(jj)%endb(:) - band_st%blines(jj)%startb(:)
        band_st%blines(jj)%length = sqrt(dot_product(vec(:),vec(:)))
enddo
  
min_length = band_st%blines(1)%length
if (band_st%nlines > 1) then
        do jj = 2, band_st%nlines
                if (band_st%blines(jj)%length < min_length) then
                        min_length = band_st%blines(jj)%length
                endif
        enddo
endif





! Calculate the number of kpoints for each line
! proportional to the length of the line
! for the last line the end point is also included
total_nkpt = 0
do jj = 1, band_st%nlines-1
        band_st%blines(jj)%nkpt = nint(band_st%blines(jj)%length/min_length*real(band_st%npoints,dp))
        total_nkpt = total_nkpt + band_st%blines(jj)%nkpt
enddo
band_st%blines(band_st%nlines)%nkpt = &
        nint(band_st%blines(band_st%nlines)%length/min_length*real(band_st%npoints,dp) + 1)
total_nkpt = total_nkpt + band_st%blines(band_st%nlines)%nkpt


if (parallel%iammaster) then
        do jj = 1, band_st%nlines
                write(7,*) 'band #, number of k-points', &
                        jj, band_st%blines(jj)%nkpt
        enddo
endif





! Create list of kpoints for each line

allocate(tmp_kpts(3,total_nkpt))
tmp_kpts(:,:) = dzero

allocate(tmp_eigs(total_nkpt,spnum,elec_st%nstate))
tmp_eigs(:,:,:) = dzero

offset = 0
do jj = 1, band_st%nlines-1
        do kk = 1, band_st%blines(jj)%nkpt
                tmp_kpts(:,offset+kk) = band_st%blines(jj)%startb(:) + &
                        (kk-1)* &
                        (band_st%blines(jj)%endb(:) - &
                        band_st%blines(jj)%startb(:))/band_st%blines(jj)%nkpt
        enddo

        offset = offset + band_st%blines(jj)%nkpt
enddo

jj = band_st%nlines
do kk = 1, band_st%blines(jj)%nkpt
        tmp_kpts(:,offset+kk) = band_st%blines(jj)%startb(:) + &
                (kk-1)* &
                (band_st%blines(jj)%endb(:) - &
                band_st%blines(jj)%startb(:))/(band_st%blines(jj)%nkpt - 1)
enddo
offset = offset + band_st%blines(jj)%nkpt









! Devide each line to batches of kpoints and find eigenvalues for each batch      

! some array initializations...

if (allocated(solver%eig_init)) deallocate(solver%eig_init)
allocate(solver%eig_init(nrep,elec_st%nkpt,spnum))
solver%eig_init(:,:,:) = .false.

if (allocated(solver%nconvt)) deallocate(solver%nconvt)
allocate(solver%nconvt(nrep,elec_st%nkpt,spnum))
solver%nconvt(:,:,:) = 0

if (allocated(solver%eval_loc)) deallocate(solver%eval_loc)
nmax = elec_st%nstate + solver%winsize
allocate(solver%eval_loc(nmax,nrep,spnum))

if (solver%name == ARPACK) then
        if (allocated(solver%zres_res)) deallocate(solver%zres_res)
        allocate(solver%zres_res(parallel%ldn*elec_st%mxwd,nrep,elec_st%nkpt,spnum))
        solver%zres_res(:,:,:,:) = zzero

        if (allocated(solver%info)) deallocate(solver%info)
        allocate(solver%info(nrep,elec_st%nkpt,spnum))
        solver%info(:,:,:) = 0
endif





leftover_nkpt = mod(total_nkpt, elec_st%nkpt)

do jj = 1, total_nkpt-leftover_nkpt, elec_st%nkpt
        call kpts_eigval(start_kpt=jj, num_kpts=elec_st%nkpt)
enddo

if (leftover_nkpt > 0) then
        call kpts_eigval(start_kpt=total_nkpt-leftover_nkpt+1, &
                num_kpts=leftover_nkpt)
endif





! Write results to file
! Eigenvalues are shifted so that Ef=0

if (parallel%iammaster) then
        open(88, file='bands.dat',form='formatted',status='unknown')

        ! Number of spins, number of states for each k-points, 
        ! number of band segments, Fermi energy (in Ry)
        write(88,*) '# of spins, # of states, # of segments, Ef (Ry)'
        write(88,*) spnum, elec_st%nstate, band_st%nlines, elec_st%efermi

        ! Number of k-points of each segment
        write(88,*) 'idx of segment, # of k-points'
        do jj = 1, band_st%nlines
                write(88,*) jj, band_st%blines(jj)%nkpt
        enddo

        ! For each spin, print out one line of (spin, # seg., # kp, kp coord)
        ! Then the eigenvalues (in Ry)
        write(88,*) 'spin, segment, kpt, kpt coord. (1/bohr), &
                &followed by eigs (Ry)'
        do isp = 1, spnum    
                offset = 0

                do jj = 1, band_st%nlines
                        do kk = 1, band_st%blines(jj)%nkpt
                                write(88,'(3i6,3(3x,f12.8))') isp, jj, kk, &
                                        tmp_kpts(:,offset+kk)

                                do ll = 1, elec_st%nstate
                                        write(88,*) &
                                                tmp_eigs(offset+kk,isp,ll)
                                enddo
                        enddo

                        offset = offset + band_st%blines(jj)%nkpt
                enddo
        enddo

        close(88)
endif

deallocate(tmp_kpts)
deallocate(tmp_eigs)


contains

subroutine kpts_eigval(start_kpt, num_kpts)
        use constants, only : zi
        implicit none
        integer, intent(in) :: start_kpt
        integer, intent(in) :: num_kpts

        elec_st%nkpt = num_kpts
        pbc%nkpt = num_kpts
        nloc_p_pot%nkpt = num_kpts

        elec_st%kpts(1:3,1:num_kpts) = &
                tmp_kpts(1:3,start_kpt:start_kpt-1+num_kpts)
        pbc%kpts(1:3,1:num_kpts) = &
                tmp_kpts(1:3,start_kpt:start_kpt-1+num_kpts)
        nloc_p_pot%kpts(1:3,1:num_kpts) = &
                tmp_kpts(1:3,start_kpt:start_kpt-1+num_kpts)

        do kplp = 1, num_kpts
        do ll = 0, grid%norder
                call matvec3(op='T', mat=grid%grad_bvec_norm(:,:), &
                        vec=elec_st%kpts(:,kplp), mvec=ktmp(:))

                solver%kecoe1(kplp,1:3,ll) = -2*zi*grid%coe1(ll,1:3)*ktmp(:)
        enddo
        enddo
    
        solver%eig_init(:,:,:) = .false.
        elec_st%eig(:,:,:)%nec = 0
        solver%nconvt(:,:,:) = 0

        call nonloc(clust, grid, p_pot, nloc_p_pot, pbc, parallel, ipr, ierr)

        solver%ff_maxiter = solver%bands_ff_maxiter
        call eigval(elec_st, pot, u_pot, solver, parallel, ipr, ierr)
        solver%ff_maxiter = original_ff_maxiter

        do kk = 1, num_kpts
        do isp = 1, spnum
                tmp_eigs(start_kpt-1+kk,isp,1:elec_st%nstate) = &
                        elec_st%eig(1,kk,isp)%en(1:elec_st%nstate)
        enddo
        enddo
end subroutine kpts_eigval

end subroutine calc_bands 
end module calc_bands_module
