
! ==================== solver  structure ========================
module eigen_solver_module

use constants
use dlaplacian_module
use stencil_things, only : stencil_definitions, fold_stencil
use aux, only : alccheck

implicit none

type eigen_solver
        ! eigensolver flag
        integer :: name

        ! diagonalization tolerance
        real(dp) :: toler

        ! dynamic diagonalization tolerance
        logical :: dyntol

        ! dynamic diagonalization tolerance
        real(dp), dimension(2) :: dtoler
        real(dp) :: dyntoler

        ! order of multipole expansion used in computation of
        ! the Hartree potential (MAXIMUM VALUE CURRENTLY SUPPORTED - 9)
        integer :: lpole

        ! relative tolerance of the CG Poisson solver (keyword
        ! hartree_cg_tolerance, default 1.d-13; PARSEC 1.4 used 1.d-7)
        real(dp) :: hartree_rtol = 1.0d-13
        ! CG stopping test (keyword hartree_cg_criterion): 1 = relative to the
        ! initial residual (default), 2 = relative to the right-hand side
        integer :: hartree_test = 1

        ! full_hartree_flag - if true - a full hartree calculation is 
        ! done for the boundaries instead of the multipole expansion. this
        ! is needed in some cases where the multipole expansion is not appropriate
        ! (for example - long cylinder).
        logical :: full_hartree_flag

        ! maximum number of matrix-vector multiplications allowed.
        integer :: maxmv

        ! number of matrix-vector multiplications performed (for
        ! statistics purposes only)
        integer :: totalmv

        ! number of additional eigenstates to be computed for each
        ! representation (important if first guess of eigenvalues is too
        ! different from the converged ones)
        !integer :: nadd

        ! window size (used in chebdav)
        integer :: winsize

        ! polynomial degree for chebff and chebdav (Chebyshev-Davidson), first diagonalization only
        integer :: polym0, ff_maxiter, bands_ff_maxiter
        integer :: num_lancz_bound !< number of lanczos bound steps
        integer :: boundsmethod !< which bounds method to use

        ! whether to use Yunkai's scaled cheb or regular one (also in chebff!)
        logical :: scaledcheb

        ! polynomial degree for Chebyshev filtering
        integer :: polym
        integer :: polym_t

        ! delta_degree: difference between the polynomial degree used at low
        ! energy versus high energy.
        integer :: dpm

        ! input/output flag (input is used by ARPACK only, as flag for
        ! residue restart vector)
        integer, dimension(:,:,:), allocatable :: info

        ! residual restart vector, used only for arpack
        complex(dpc), dimension(:,:,:,:), allocatable :: zres_res
        real(dp), dimension(:,:,:,:), allocatable :: res_res

        ! distributed diagonal part of Hamiltonian
        real(dp), dimension(:), allocatable :: adiag

        ! but if complex we want to use this one
        complex(dpc), dimension(:), allocatable :: zadiag

        ! distributed noncollinear diagonal part of Hamiltonian
        complex(dpc), dimension(:,:), allocatable :: bxc

        ! alias for grid%norder, order of finite order expansion
        integer :: norder

        ! alias for grid%coe2
        real(dp), dimension(:,:), allocatable :: coe2

        ! alias for grid%kecoe1
        complex(dpc), dimension(:,:,:), allocatable :: kecoe1

        ! alias for rsymm%nrep
        integer :: nrep

        ! characters for current irreducible representation
        real(dp), dimension(:), allocatable :: chi

        ! true if noncollinear calculation
        logical :: ncl

        ! true if Chebyshev filtering is being done
        logical :: do_subsp

        ! true if the number of eigenvalues per representation is kept fixed
        logical :: fix_num_eig

        ! set of Ritz values, or Kohn-Sham eigenvalues, used for
        ! Chebyshev filtering
        real(dp), dimension(:,:,:), allocatable :: eval_loc

        ! lower bound of spectrum in Chebyshev filtering
        real(dp), dimension(:,:), allocatable :: lowerb

        ! blocksize for everything matvec related
        integer :: mv_blksize

        integer, dimension (:,:), allocatable :: ncompcnt

        ! seed for random vector generation
        integer :: rng_seed

        ! will we use threads to randomize init guess?
        logical :: randommp
        logical :: oldvectorrng

        ! true if a first guess of eigenvalues and eigenvectors is
        ! available for this representation and spin
        logical, dimension(:,:,:), allocatable :: eig_init

        ! true if this is the first iteration in Chebyshev filtering
        logical, dimension(:,:), allocatable :: firstfilt
        logical :: use_smart_bound_in_subspace

        ! number of converged eigenvalues to be used in eigval 
        ! with chebdav routine
        integer, dimension(:,:,:), allocatable :: nconvt

        ! flag for external manetic field
        logical :: is_mag

        ! Vector potential: rot{A}=H_ext
        real(dp), dimension(:,:), allocatable :: vecpot

        !encapsulates laplacian data
        type(stencil_definitions) :: sten_def 
        type(fold_stencil) :: sten_coeff 

        ! some threading support
        ! integer :: matvec_mkl_threads,max_mkl_threads
        logical :: use_scalapack
        integer :: scalapack_block_size
        logical :: use_elpa
        integer :: elpa_block_size

        ! Use spectrum slicing if it is true
        logical :: spectrum_slicing
        logical :: use_krylov_subspace_method
        logical :: use_lanczos_dos_estimation
        logical :: spectrum_slicing_cycles_early_quit
        integer :: spectrum_slicing_max_cycles
        integer :: spectrum_slicing_max_cycles_first
        integer :: num_of_iter_still_using_chebyshev
        integer :: polym_first_ss_iter
        integer :: polym_ss
        integer :: num_of_copied_groups
        integer :: num_of_slice1_filtering
        integer :: nslices
        real(dp) :: spectrum_slicing_ratio




end type eigen_solver

contains

        subroutine destroy_eigen_solver (solver)
                implicit none
                type(eigen_solver), intent(inout) :: solver

                if (allocated(solver%info)) deallocate(solver%info)
                if (allocated(solver%nconvt)) deallocate(solver%nconvt)
                if (allocated(solver%res_res)) deallocate(solver%res_res)
                if (allocated(solver%zres_res)) deallocate(solver%zres_res)
                if (allocated(solver%adiag)) deallocate(solver%adiag)
                if (allocated(solver%zadiag)) deallocate(solver%zadiag)
                if (allocated(solver%bxc)) deallocate(solver%bxc)
                if (allocated(solver%coe2)) deallocate(solver%coe2)
                if (allocated(solver%kecoe1)) deallocate(solver%kecoe1)
                if (allocated(solver%chi)) deallocate(solver%chi)
                if (allocated(solver%eval_loc)) deallocate(solver%eval_loc)
                if (allocated(solver%lowerb)) deallocate(solver%lowerb)
                if (allocated(solver%ncompcnt)) deallocate(solver%ncompcnt)
                if (allocated(solver%eig_init)) deallocate(solver%eig_init)
                if (allocated(solver%firstfilt)) deallocate(solver%firstfilt)
                if (allocated(solver%vecpot)) deallocate(solver%vecpot)

                call solver%sten_def%destroy()
                call solver%sten_coeff%destroy()
        end subroutine destroy_eigen_solver

        subroutine create_eigen_solver(solver, grid, ldn, nrep, nspin, &
                nstates, nkpt_in, cplx, mxwd)

                use grid_module
                implicit none

                type(eigen_solver), intent(inout) :: solver
                type(grid_data), intent(in) :: grid
                integer, intent(in) :: ldn, nrep, nspin, &
                        nstates, nkpt_in, mxwd
                logical, intent(in) :: cplx

                integer :: alcstat, nmax, ntmp, nkpt
    
                ! nkpt = 0 if kpoints are not used; must increase it to one
                nkpt = max(nkpt_in, 1)

                ! should be inserted by the user inside parsec.in, 
                ! maximum is 9
                solver%lpole = 9

                ! should also be inserted by the user inside parsec.in
                ! chebdav need extra window
                if (solver%name == CHEBDAV) then
                        solver%winsize = 12
                else
                        solver%winsize = 0
                endif

                solver%totalmv = 0
                solver%nrep = nrep

                allocate(solver%chi(nrep))






                ! KHL: The size of zadiag/adiag is parallel%ldn
                !      rather than parallel%ldn_full, since
                !      for the case of mxwd=2, we will deal with
                !      spin up/down separately and each of them
                !      only use solver%adiag(parallel%ldn)
                if (cplx) then
                        !AJB: for performance reasons we want 
                        !     zadiag instead of adiag
                        allocate(solver%zadiag(ldn), stat=alcstat)
                        call alccheck('solver%zadiag', ldn, alcstat)
                        solver%zadiag(:) = zzero

                        ! KHL: For now we still use solver%adiag in 
                        !      zmatvec_so()
                        if (mxwd == 2) then
                                allocate(solver%adiag(ldn), stat=alcstat)
                                call alccheck('solver%adiag', ldn, alcstat)
                                solver%adiag(:) = zero
                        endif
                else
                        allocate(solver%adiag(ldn), stat=alcstat)
                        call alccheck('solver%adiag', ldn, alcstat)
                        solver%adiag(:) = zero
                endif






                if (mxwd == 2) then
                        allocate(solver%bxc(ldn,2), stat=alcstat)
                        call alccheck('solver%bxc', 2*ldn, alcstat)
                endif






                allocate(solver%info(nrep,nkpt,nspin))
                solver%info(:,:,:) = 0






                solver%norder = grid%norder
                ntmp = 3 + grid%lap_dir_num

                allocate(solver%coe2(-solver%norder:solver%norder,ntmp))
                solver%coe2(:,:) = grid%coe2(:,:)

                if (nkpt_in /= 0) then
                        allocate(solver%kecoe1(nkpt_in,6,0:solver%norder))
                        solver%kecoe1(:,:,:) = grid%kecoe1(:,:,:)
                endif






                allocate(solver%eig_init(nrep,nkpt,nspin))

                if (solver%do_subsp) then
                        solver%eig_init(:,:,:) = .false.

                        allocate(solver%firstfilt(nrep,nspin))
                        solver%firstfilt(:,:) = .true.

                        allocate(solver%lowerb(nrep,nspin))
                        solver%lowerb(:,:) = mach_eps 

                        allocate(solver%ncompcnt(nrep,nspin))
                        solver%ncompcnt(:,:) = 0

                        nmax = nstates + solver%winsize

                        ! KHL: is solver%eval_loc only a temporary array when 
                        !      solving eigenvalue problems? Because different 
                        !      k-points may use the same memory space...
                        allocate(solver%eval_loc(nmax,nrep,nspin))
                        solver%eval_loc(:,:,:) = zero
                endif

                if (solver%name == ARPACK) then
                        if (cplx) then
                                allocate(solver%zres_res( &
                                        ldn*mxwd,nrep,nkpt,nspin), &
                                        stat=alcstat)
                                call alccheck('solver%zres_res', &
                                        ldn*mxwd*nrep*nkpt*nspin, alcstat)
                                solver%zres_res(:,:,:,:) = zzero
                        else
                                allocate(solver%res_res(ldn,nrep,nkpt,nspin), &
                                        stat=alcstat)
                                call alccheck('solver%res_res', &
                                        ldn*nrep*nkpt*nspin, alcstat)
                                solver%res_res(:,:,:,:) = zero
                       endif
                endif

                ! initialize nconvt to zero
                allocate(solver%nconvt(nrep,nkpt,nspin))
                solver%nconvt(:,:,:) = 0

                if (solver%is_mag) then
                        allocate(solver%vecpot(ldn,3), stat=alcstat)
                        call alccheck('solver%vecpot', 3*ldn, alcstat)
                        solver%vecpot(:,:) = zero
                endif

        end subroutine create_eigen_solver
  
end module eigen_solver_module
