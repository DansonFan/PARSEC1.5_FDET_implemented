module potsave_module
   implicit none
   contains

!========================================================================================
! Save grid, potentials, density, and kinetic energy in the pot.dat format used by
! FDET-based AFM simulations.
!========================================================================================
subroutine potsave(clust, elec_st, grid, pbc, rsymm, vion, vhart, vxc, &
        rho, rhoc, newk, parallel, iunit)

use constants, only : dp
use cluster_module
use electronic_struct_module
use grid_module
use pbc_module
use symmetry_module
use parallel_data_module

implicit none

type(cluster), intent(in) :: clust
type(electronic_struct), intent(inout) :: elec_st
type(grid_data), intent(in) :: grid
type(pbc_data), intent(in) :: pbc
type(symmetry), intent(in) :: rsymm
type(parallel_data), intent(inout) :: parallel
real(dp), intent(in) :: vion(parallel%mydim)
real(dp), intent(in) :: vhart(parallel%mydim)
real(dp), intent(in) :: vxc(parallel%mydim, elec_st%nspin)
real(dp), intent(in) :: rho(parallel%mydim, 2*elec_st%nspin-1)
real(dp), intent(in) :: rhoc(parallel%mydim)
real(dp), intent(in) :: newk
integer, intent(in) :: iunit

integer :: ii, jj, kk
integer :: stype(10)

if (parallel%iammaster) then
        open(iunit, file='pot.dat', form='unformatted', status='replace')
endif

stype(:) = 0
stype(1) = elec_st%nspin
if (elec_st%cplx) then
        if (elec_st%is_so) then
                stype(2) = 2
        else
                stype(2) = 1
        endif
endif

select case (pbc%per)
case (0)
        stype(3) = 0
case (1)
        stype(3) = 2
case (2)
        stype(3) = 3
case (3)
        stype(3) = 1
end select

if (parallel%iammaster) then
        write(iunit) newk
        write(iunit) clust%atom_num
        do ii = 1, clust%atom_num
                write(iunit) clust%xatm(ii), clust%yatm(ii), clust%zatm(ii)
        enddo

        write(iunit) stype

        if (pbc%is_on) then
                write(iunit) (grid%step(kk), kk=1,3)
                write(iunit) (pbc%box_size(kk), kk=1,3)
                write(iunit) ((pbc%latt_vec(jj,kk), jj=1,3), kk=1,3)
        else
                write(iunit) grid%step(1), grid%rmax
        endif

        write(iunit) grid%ndim
        write(iunit) grid%shift
        write(iunit) grid%nwedge, rsymm%ntrans
        write(iunit) rsymm%rmtrx
        write(iunit) rsymm%trans
        write(iunit) rsymm%tnp
        write(iunit) rsymm%alatt, rsymm%invlat
        write(iunit) ((rsymm%chi(kk,jj), kk=1,rsymm%ntrans), &
                jj=1,rsymm%ntrans)
        write(iunit) ((grid%kx(kk), grid%ky(kk), grid%kz(kk)), &
                kk=1,grid%nwedge)
endif

call collect_function(parallel, vion)
if (parallel%iammaster) write(iunit) (parallel%ftmp(kk), kk=1,grid%nwedge)

call collect_function(parallel, vhart)
if (parallel%iammaster) write(iunit) (parallel%ftmp(kk), kk=1,grid%nwedge)

call collect_function(parallel, vxc(1,1))
if (parallel%iammaster) write(iunit) (parallel%ftmp(kk), kk=1,grid%nwedge)

call collect_function(parallel, rho(1,1))
if (parallel%iammaster) write(iunit) (parallel%ftmp(kk), kk=1,grid%nwedge)

call collect_function(parallel, rhoc)
if (parallel%iammaster) write(iunit) (parallel%ftmp(kk), kk=1,grid%nwedge)

if (parallel%iammaster) close(iunit)

end subroutine potsave

end module potsave_module
