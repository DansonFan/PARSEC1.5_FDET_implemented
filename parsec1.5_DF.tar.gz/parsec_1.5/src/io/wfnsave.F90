!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  This subroutine saves grid, potential, wave function, energy
!  levels, etc, in parsec.dat file for restarting purposes.
!
!---------------------------------------------------------------
module wfn_io_module


contains


subroutine wfnsave(elec_st, grid, pbc, rsymm, parallel, vnew, rho, &
        iunit, spin3d)

use constants
use electronic_struct_module
use grid_module
use pbc_module
use symmetry_module
use parallel_data_module
use aux, only : custom_date_time, myflush
use external_interfaces, only : zcopy, dcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_allreduce, mpi_in_place, &
        mpi_integer, mpi_max, mpi_barrier, mpi_double_complex, &
        mpi_double_precision, mpi_bcast
#else
use mpi
#endif
#endif

implicit none 

!  Input/Output variables:

!  electronic structure
type(electronic_struct), intent(inout) :: elec_st

!  grid related data
type(grid_data), intent(in) :: grid

!  periodic boundary conditions data
type(pbc_data), intent(in) :: pbc

!  symmetry operations:
type(symmetry), intent(in) :: rsymm

!  parallel computation related data
type(parallel_data), intent(inout) :: parallel

!  distributed self-consistent potential and electron density
!  (passed outside the structure to overcome a bug with the IBM compiler)
real(dp), dimension(parallel%mydim,elec_st%nspin), intent(in) :: vnew
real(dp), dimension(parallel%mydim,2*elec_st%nspin-1), intent(in) :: rho
real(dp), dimension(parallel%mydim,3), intent(in), optional :: spin3d

!  number of output unit
integer, intent(in) :: iunit




!  Work variables:

!  counters
integer :: isp, jj, kk, irow, jcol, mydim
real(dp) :: tmpd

integer :: colgroup_of_this_state, jcol_local
integer :: progress_stride

integer :: msgtype, nstate

!  counters for representations
integer :: irp

!  temporary arrays for eigenvalues/occupations, before reshaping
!  according to symmetry operations
real(dp), dimension(:), allocatable :: en_tmp, occ_tmp

!  jrep keeps track of how many eigenstates are already in each
!  representation
integer :: jrep(elec_st%nrep),jrepinv(elec_st%nspin,elec_st%nstate)

!  work array
complex(dpc), dimension(:), allocatable :: zwftmp
real(dp), dimension(:), allocatable :: wftmp

!  date/time tag
character(len=26) :: datelabel

!  flags for type of system
!  stype(1) = nspin
!  stype(2) = 0 : real wavefunctions
!  stype(2) = 1 : complex wavefunctions
!  stype(2) = 2 : spin-orbit (complex doubled wavefunctions)
!  stype(2) = 3 : noncollinear (spin3d present)
!  stype(2) = 4 : spin-orbit and noncollinear (spin3d present)
!  stype(3) = 0 : confined system (cluster)
!  stype(3) = 1 : system periodic on all directions (bulk)
!  stype(3) = 2 : system periodic on x direction only (wire)
integer, dimension(10) :: stype

!  kpoint variables
integer :: ikp, kpnum

!  weight of each kpoint being examined
real(dp), dimension(:), allocatable :: weight

!  coordinates of each kpoint
real(dp), dimension(:,:), allocatable :: kpts
!integer :: tt


#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: rowgroup_comm_f08
type(mpi_comm) :: overallrowgroup_comm_f08
#else
integer :: comm_f08
integer :: rowgroup_comm_f08
integer :: overallrowgroup_comm_f08
#endif
#endif



! ---------------------------------------------------------------

progress_stride = 100

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
rowgroup_comm_f08%mpi_val = parallel%rowgroup_comm
overallrowgroup_comm_f08%mpi_val = parallel%overallrowgroup_comm
#else
comm_f08 = parallel%comm
rowgroup_comm_f08 = parallel%rowgroup_comm
overallrowgroup_comm_f08 = parallel%overallrowgroup_comm
#endif
#endif

if (elec_st%cplx) then
        allocate(zwftmp(parallel%mydim*elec_st%mxwd))
else
        allocate(wftmp(parallel%mydim))
endif

if (elec_st%nkpt > 0) then
        kpnum = elec_st%nkpt

        allocate(kpts(3,kpnum))
        kpts(:,:) = elec_st%kpts(:,:)

        allocate(weight(kpnum))
        weight(:) = elec_st%kpwt(:)
else
        kpnum = 1

        allocate(kpts(3,kpnum))
        kpts(:,:) = zero

        allocate(weight(kpnum))
        weight(:) = one
endif





!  Open unit.
if (parallel%iammaster) then
        open(iunit,file='parsec.dat',form='unformatted',status='unknown')
endif









!  Build system flags.
stype = 0
stype(1) = elec_st%nspin

if (elec_st%cplx) then
        if (elec_st%mxwd == 2) then
                if (elec_st%is_so) then 
                        if (present(spin3d)) then 
                                stype(2) = 4
                        else
                                stype(2) = 2
                        endif
                else
                        if (present(spin3d)) then
                                stype(2) = 3
                        endif
                endif
        else
                stype(2) = 1
        endif
endif

select case(pbc%per)
case(0)
        stype(3) = 0
case(1)
        stype(3) = 2
case(2)
        stype(3) = 3
case(3)
        stype(3) = 1
end select

mydim = parallel%mydim*elec_st%mxwd



if (parallel%iammaster) then
        rewind(iunit)

        call custom_date_time(datelabel,tmpd)

        write(iunit) datelabel
        write(iunit) stype

        if (pbc%is_on) then
                write(iunit) (grid%step(kk),kk=1,3), &
                        (pbc%box_size(kk),kk=1,3), grid%rmax
                write(iunit) ((pbc%latt_vec(jj,kk),jj=1,3),kk=1,3)
                write(iunit) grid%lap_dir_num
                write(iunit) grid%lap_dir
                write(iunit) grid%lap_dir_step
                write(iunit) kpnum
                write(iunit) elec_st%kptmethod
                write(iunit) (elec_st%mpgrid(kk),kk=1,3)
                write(iunit) (elec_st%mpshift(kk),kk=1,3)
                write(iunit) ((kpts(jj,kk),jj=1,3),kk=1,kpnum)
                write(iunit) (weight(kk),kk=1,kpnum)
        else
                write(iunit) grid%step(1), grid%rmax
        endif

        write(iunit) grid%ndim
        write(iunit) grid%shift
        write(iunit) grid%nwedge,rsymm%ntrans
        write(iunit) rsymm%rmtrx
        write(iunit) rsymm%trans
        write(iunit) rsymm%tnp
        write(iunit) rsymm%alatt, rsymm%invlat
        write(iunit) ((rsymm%chi(kk,jj),kk=1,rsymm%ntrans),jj=1,rsymm%ntrans)
        write(iunit) (grid%kx(kk),grid%ky(kk),grid%kz(kk),kk=1,grid%nwedge)
endif

jrepinv = 0

do isp = 1, elec_st%nspin/elec_st%mxwd
        jj = isp - 1 + elec_st%nspin

        !  Print out eigenvalues for all k-points.
        do ikp = 1, kpnum
                jrep = 0

                do jcol = 1, elec_st%nstate
                        irp = elec_st%irep(jcol,ikp,isp)
                        jrep(irp) = jrep(irp) + 1

                        if (ikp == 1) jrepinv(isp,jcol) = jrep(irp)
                enddo

                if (parallel%iammaster) then
                        allocate(en_tmp(elec_st%nstate))
                        allocate(occ_tmp(elec_st%nstate))
                        jrep = 0

                        do jcol = 1, elec_st%nstate
                                irp = elec_st%irep(jcol,ikp,isp)
                                jrep(irp) = jrep(irp) + 1

                                if (ikp == 1) jrepinv(isp,jcol) = jrep(irp)

                                en_tmp(jcol) = &
                                        elec_st%eig(irp,ikp,isp)%en(jrep(irp))
                                occ_tmp(jcol) = &
                                        elec_st%eig(irp,ikp,isp)%occ(jrep(irp))
                        enddo

                        write(iunit) elec_st%nstate
                        write(iunit) (elec_st%irep(jcol,ikp,isp), &
                                jcol=1,elec_st%nstate)
                        write(iunit) (en_tmp(jcol),jcol=1,elec_st%nstate)
                        write(iunit) (occ_tmp(jcol),jcol=1,elec_st%nstate)

                        deallocate(en_tmp)
                        deallocate(occ_tmp)
                endif
        enddo

#ifdef MPI
        call mpi_barrier(comm_f08, mpinfo)
#endif

#ifdef AJB_DEBUG
        write(9,*) ' going to collect potential for spin component , isp=', &
                isp
#endif

        call collect_function(parallel, vnew(1,isp))

        if (parallel%iammaster) then
                write(iunit) (parallel%ftmp(irow),irow=1,grid%nwedge)
        endif

#ifdef AJB_DEBUG
        write(9,*) ' going to collect charge for component , jj= ', jj
#endif

        call collect_function(parallel, rho(1,jj))

        if (parallel%iammaster) then
                write(iunit) (parallel%ftmp(irow),irow=1,grid%nwedge)
        endif
enddo





!  If spin-orbit potential is present or noncollinear states, then the 
!  potential and density for the second spin component must be printed out.
!  The loop above goes only over the first spin component.

if (elec_st%mxwd == 2) then

#ifdef AJB_DEBUG
        write(9,*) ' going to collect potential for spin component 2'
#endif

        call collect_function(parallel, vnew(1,2))

        if (parallel%iammaster) then
                write(iunit) (parallel%ftmp(irow),irow=1,grid%nwedge)
        endif

#ifdef AJB_DEBUG
        write(9,*) ' going to collect charge for component 3 '
#endif

        call collect_function(parallel, rho(1,3))

        if (parallel%iammaster) then
                write(iunit) (parallel%ftmp(irow),irow=1,grid%nwedge)
        endif

        if (stype(2) > 2) then

#ifdef AJB_DEBUG
                write(9,*) 'skipping collection of spin3d '
#endif

                ! do tt = 1,3
                !    call collect_function(parallel,spin3d(1,tt))
                !    if (parallel%iammaster) write(iunit) &
                !    (parallel%ftmp(kk),kk=1,grid%nwedge)
                ! enddo
        endif
endif





! Print out wave-functions. With many k-points, must do it for all
! k-points. Also, must print the irreducible wedge (different
! k-points may have different wedges).
msgtype = 1

do isp = 1, elec_st%nspin/elec_st%mxwd
do ikp = 1, kpnum

        !  If elec_st%nsave < 0, then print out only occupied levels.
        if (elec_st%nsave < 0) then
                nstate = elec_st%ifmax(isp)

                allocate(elec_st%indxsave(nstate))

                do jcol = 1, nstate
                        elec_st%indxsave(jcol) = jcol
                enddo
        else
                nstate = elec_st%nsave
        endif

        if (parallel%iammaster) then
                write(iunit) grid%nwedge, rsymm%ntrans
                write(iunit) rsymm%rmtrx
                write(iunit) rsymm%trans
                write(iunit) rsymm%tnp
                write(iunit) rsymm%alatt, rsymm%invlat
                write(iunit) ((rsymm%chi(irow,jcol),irow=1,rsymm%ntrans), &
                        jcol=1,rsymm%ntrans)
                write(iunit) (grid%kx(irow),grid%ky(irow),grid%kz(irow), &
                        irow=1,grid%nwedge)
                write(iunit) nstate

                if (nstate > 0) write(iunit) elec_st%indxsave(1:nstate)

                if (nstate > 0) then
                        write(7,*) '  parsec.dat: writing ', nstate, &
                                ' wave functions for k-point ', ikp, &
                                ' spin ', isp
                        call myflush(7)
                endif
        endif

        do jcol = 1, nstate
                if (parallel%iammaster) then
                        if (mod(jcol-1, progress_stride) == 0) then
                                write(7,*) '  parsec.dat: starting wave function ', &
                                        jcol, ' of ', nstate, &
                                        ' for k-point ', ikp, ' spin ', isp
                                call myflush(7)
                        endif
                endif

                kk = elec_st%indxsave(jcol)
                irp = elec_st%irep(kk,ikp,isp)

#ifdef MPI
                ! KHL: For the MPI ranks that are not in 
                !      elec_st%eig(irp,ikp,isp)%taskgroup, their
                !      elec_st%eig(irp,ikp,isp)%nstates_per_colgroup is -1 (uninitialized)
                !      Here the allreduce() make all MPI ranks have the same value
                call MPI_Allreduce(MPI_IN_PLACE, &
                        elec_st%eig(irp,ikp,isp)%nstates_per_colgroup, &
                        1, MPI_INTEGER, MPI_MAX, &
                        overallrowgroup_comm_f08, mpinfo)
#endif

                colgroup_of_this_state = (jrepinv(isp,kk)-1) / &
                        elec_st%eig(irp,ikp,isp)%nstates_per_colgroup
                jcol_local = mod((jrepinv(isp,kk)-1), &
                        elec_st%eig(irp,ikp,isp)%nstates_per_colgroup) + 1

                !write(9,*) 'colgroup_of_this_state', colgroup_of_this_state
                !write(9,*) 'jcol_local', jcol_local

                if (elec_st%cplx) then
                        if (elec_st%eig(irp,ikp,isp)%taskgroup == &
                                parallel%mytaskgroup .and. &
                                parallel%mycolgroup == &
                                colgroup_of_this_state) then

                                call zcopy(mydim, &
                                        elec_st%eig(irp,ikp,isp)% &
                                        zwf(1,jcol_local), 1, &
                                        !zwf(1,jrepinv(isp,kk)), 1, &
                                        zwftmp(1), 1)
                        else
                                zwftmp(:) = zzero
                        endif

#ifdef MPI
                        call MPI_Bcast(zwftmp, &
                                parallel%mydim*elec_st%mxwd, &
                                MPI_DOUBLE_COMPLEX, colgroup_of_this_state, &
                                rowgroup_comm_f08, mpinfo)
#endif

                        call collect_zfunction(parallel, zwftmp, elec_st%mxwd)

#ifdef MPI
                        if (parallel%iam_colgroup_master) then
                                jj = elec_st%eig(irp,ikp,isp)%taskgroup * &
                                        parallel%npcol + &
                                        colgroup_of_this_state
                                !jj = elec_st%eig(irp,ikp,isp)%taskgroup

                                call MPI_Bcast(parallel%zftmp, &
                                        grid%nwedge*elec_st%mxwd, &
                                        MPI_DOUBLE_COMPLEX, jj, &
                                        overallrowgroup_comm_f08, mpinfo)
                        endif
#endif

                        if (parallel%iammaster) then
                                write(iunit) (parallel%zftmp(irow), &
                                        irow=1,grid%nwedge*elec_st%mxwd)
                        endif
                else
                        if (elec_st%eig(irp,ikp,isp)%taskgroup == &
                                parallel%mytaskgroup .and. &
                                parallel%mycolgroup == &
                                colgroup_of_this_state) then

                                call dcopy(parallel%mydim, &
                                        elec_st%eig(irp,ikp,isp)% &
                                        wf(1,jcol_local), 1, &
                                        !wf(1,jrepinv(isp,kk)), 1, &
                                        wftmp(1), 1)
                        else
                                wftmp(:) = zero
                        endif

#ifdef MPI
                        call MPI_Bcast(wftmp, &
                                parallel%mydim, &
                                MPI_DOUBLE_PRECISION, colgroup_of_this_state, &
                                rowgroup_comm_f08, mpinfo)
#endif

                        call collect_function(parallel, wftmp)

#ifdef MPI
                        if (parallel%iam_colgroup_master) then
                                jj = elec_st%eig(irp,ikp,isp)%taskgroup * &
                                        parallel%npcol + &
                                        colgroup_of_this_state
                                !jj = elec_st%eig(irp,ikp,isp)%taskgroup

                                call MPI_Bcast(parallel%ftmp, grid%nwedge, &
                                        MPI_DOUBLE_PRECISION, jj, &
                                        overallrowgroup_comm_f08, mpinfo)
                        endif
#endif

                        if (parallel%iammaster) then
                                write(iunit) (parallel%ftmp(irow), &
                                        irow=1,grid%nwedge)
                        endif
                endif

                if (parallel%iammaster) then
                        if (mod(jcol, progress_stride) == 0 .or. &
                                jcol == nstate) then
                                write(7,*) '  parsec.dat: finished wave function ', &
                                        jcol, ' of ', nstate, &
                                        ' for k-point ', ikp, ' spin ', isp
                                call myflush(7)
                        endif
                endif
        enddo

        if (elec_st%nsave < 0) deallocate(elec_st%indxsave)
enddo
enddo

if (elec_st%cplx) then
        deallocate(zwftmp)
else
        deallocate(wftmp)
endif

#ifdef MPI
call MPI_Barrier(comm_f08, mpinfo)
#endif

if (parallel%iammaster) close(iunit)

end subroutine wfnsave
end module wfn_io_module
