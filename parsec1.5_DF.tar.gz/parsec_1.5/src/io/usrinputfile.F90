module io_module

use prandom_module, only : K_RANGEN_USE_DEFAULT

! IO options

integer, parameter :: k_io_none_out      = 0 
integer, parameter :: k_io_parsecdat_out = 1
integer, parameter :: k_io_ascii_out     = 2
integer, parameter :: k_io_hdf5_out      = 3

type inputs_data
        logical :: enable_data_out           = .true.
        logical :: calculate_force           = .true.
        logical :: use_old_forces            = .false.
        logical :: redirect_timings          = .false.
        logical :: output_ascii_data         = .false.
        logical :: enable_per_process_file   = .true.
        logical :: enable_process_binning    = .true.
        logical :: print_unconverged_density = .false.
        integer :: vecgen_rng_type           = K_RANGEN_USE_DEFAULT
        logical :: use_hdf5                  = .false.

        contains
                procedure :: bcast => bcast_inputs
end type inputs_data

contains




subroutine bcast_inputs(inputs, masterid, comm, mpinfo)

#ifdef MPI
#ifdef WITH_MPI_F08
        use mpi_f08, only : mpi_comm, mpi_bcast, &
                mpi_logical, mpi_integer
#else
        use mpi
#endif
#endif

        class(inputs_data), intent(inout) :: inputs


        integer, intent(in) :: comm !< integer mpi_comm
        integer, intent(in) :: masterid !< mpi_rank
        integer, intent(out) :: mpinfo !< error code

#ifdef MPI
#ifdef WITH_MPI_F08
        type(mpi_comm) :: comm_f08
#else
        integer :: comm_f08
#endif
#endif

#ifdef MPI
#ifdef WITH_MPI_F08
        comm_f08%mpi_val = comm
#else
        comm_f08 = comm
#endif
#endif

        call MPI_Bcast(inputs%enable_data_out, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%calculate_force, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%use_old_forces, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%redirect_timings, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%enable_per_process_file, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%enable_process_binning, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%print_unconverged_density, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%output_ascii_data, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%vecgen_rng_type, 1, MPI_INTEGER, &
                masterid, comm_f08, mpinfo)
        call MPI_Bcast(inputs%use_hdf5, 1, MPI_LOGICAL, &
                masterid, comm_f08, mpinfo)
end subroutine bcast_inputs



!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Read in user parameters from parsec.in.
!
!---------------------------------------------------------------
subroutine usrinput(parallel, clust, band_st, elec_st, grid, pot, p_pot, &
        mol_dynamic, pbc, mixer, solver, rritz, move, &
        istart, mxiter, vconv, vconv_approach, npolflg, electric_field, &
        outflag, ipr, export_griddata_flag, chsym, &
        ngroups, nnodes, wstrt, nscf, &
        outevflag, readwfndat, ignoresym, outputgw, enable_data_out, &
        inputs, tests, ierr)
  
use constants, only : dp, dzero, zero
use rritz_data_module
use file_units
use cluster_module
use electronic_struct_module
use grid_module
use potential_module
use pseudo_potential_module
use molecular_dynamic_module
use pbc_module
use mixer_module
use eigen_solver_module
use movement_module
use bandstruc_module
use nscf_module
use aux, only : myflush, matvec3, mtrxin, custom_date_time, mysecond
use esdf
use test_module
use parallel_data_module
use fdet_tipsphere_module, only : tipsphere_on

#ifdef _OPENMP
use omp_lib
#endif

#ifdef USE_LIBXC
use xc_f03_lib_m
#endif 

implicit none
!
! Input/Output variables:
!

type(parallel_data), intent(inout) :: parallel

! the cluster
type(cluster), intent(inout) :: clust

! band structure
type(bandstruc), intent(inout) :: band_st

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! grid related data
type(grid_data), intent(inout) :: grid

! potential related data
type (potential), intent(inout) :: pot

! pseudopotential related data
type(pseudo_potential), intent (inout) :: p_pot

! molecular dynamic related data
type(molecular_dynamic), intent (inout) :: mol_dynamic

! periodic boundary conditions data
type(pbc_data), intent (inout) :: pbc

! mixer related data
type(mixer_data), intent(inout) :: mixer

! solver related data
type(eigen_solver), intent(inout) :: solver

! rayleight ritz related data
type(rritz_data), intent(inout) :: rritz

! movement data
type(movement), intent (inout) :: move

! non selfconsistent data
type(nscf_data), intent(inout) :: nscf

! input data from usrinput, for options etc
type(inputs_data), intent(inout) :: inputs

! test data for instrumenting internal tests
type(tests_data), intent(inout) :: tests

! restart flag
integer, intent(out) :: istart

! maximal # of iterations
integer, intent(out) :: mxiter

! convergence criterion
real(dp), intent(out) :: vconv

! convergence criterion approaching
real(dp), intent(out) ::  vconv_approach

! polarizability flag
integer, intent(out) :: npolflg

! polarizability field
real(dp), intent(out) :: electric_field

! output flag for writing parsec.dat file:
! mod(outflag,2) = 1 : write all calculated wave functions 
! mod(outflag,2) = 0 : write only the ones for occupied states
! mod(outflag/2,2) = 1 : write parsec.dat only after SCF is finished
! mod(outflag/2,2) = 0 : write parsec.dat between steps of SCF loop
integer, intent(out) :: outflag

! output flag for additional info in parsec.out
! default is ipr = 0 (only basic output); higher values will
! cause additional information to be printed out
! ipr >= 1 : print out local/non-local components of force and
!              initial eigenvalues
! ipr >= 2 : print out all symmetry data and additional arpack output
! ipr >= 3 : print out more BFGS output
! ipr >= 4 : print out all BFGS output
! ipr >= 5 : print out all g-stars (warning: _lots_ of data)
! ipr >= 6 : print out local potentials (warning: _lots_ of data)
integer, intent(out) :: ipr

! output flag for exporting of grid data to external files
! (size matches definition in def.h)
integer, dimension(MAX_EXPORT_OPTS), intent(inout) :: export_griddata_flag

! flag for symmetrization of charge density
logical, intent(out) :: chsym

! number of groups of processors
integer, intent(out) :: ngroups

! number of processors
integer, intent(in) :: nnodes

! starting time
real(dp), intent(inout) :: wstrt

logical, intent(out) :: readwfndat

! output flag for writing eigen.dat file:
! mod(outevflag,2) = 0 : write all calculated eigenvalues in eigen.dat
! mod(outevflag,2) = 1 : write only the ones for occupied states
! mod((outevflag-1)/2,2) = 0 : write eigen.dat only after SCF is finished
! mod(outevflag/2,2) = 1 : write eigen.dat between steps of SCF loop
integer, intent(out) :: outevflag

! true if all symmetry should be ignored
logical, intent(out) :: ignoresym

! flag for GW
logical, intent(out) :: outputgw

! flag for data output
logical, intent(out) :: enable_data_out

! error flag; 100 < ierr < 201
integer, intent(out) :: ierr
!
! Work variables:
!
! counters
integer ity, i, itmp, ilow, iup, jj, i1, i2, i3
real(dp) :: dtmp, tmp

integer flag_words_ntmp

! spin number
integer :: nspin

#ifdef USE_LIBXC
! libxc work variables
type(xc_f03_func_t) :: xc_func
type(xc_f03_func_info_t) :: xc_info

! functional counter
integer :: ifunc

! printing functional info
character(len=60) :: func
character(len=60) :: family

! printing libxc version
integer :: vmajor
integer :: vminor
integer :: vmicro
#endif

! use libxc flag stored later in elec_st
logical :: use_libxc

! libxc functinal id
integer, dimension(2) :: func_id

! reference counter
!integer :: iref

! correlation type
character(len=2) :: icorr

! ionization energy difference, used with cc correlation only
real(dp) :: dioniz

! electron temperature (in Kelvin), tfermi
! [fixed occupations flag if negative]
real(dp) :: tfermi

! string flag
character(len=llength) :: cooling_method
character(len=llength) :: correlation_type
character(len=llength) :: mixing_method
character(len=llength) :: test_logic
character(len=llength) :: bounds_method
character(len=llength) :: rritz_logic
character(len=llength) :: eigensolver
character(len=llength) :: nscf_kpoint_unit
character(len=llength) :: kpoint_unit
character(len=llength) :: kpoint_method
character(len=llength) :: shapeflag
character(len=llength) :: boundary_conditions
character(len=llength) :: coordinate_unit
character(len=llength) :: minimization
character(len=llength) :: fdet_kinetic_functional

! string with local components of pseudopotential
character(len=1), dimension(:), allocatable :: local_component

! flag for selecting which atoms are allows to move
! flag is used for constructing mvat only.
! flag is NOT passed to the main code
integer, dimension(:), allocatable :: move_flag


! boundary sphere size (atomic units) - for confined systems
! (zero boundary condition)
real(dp) :: rmax

! parameters for describing the domain shape
! in zero boundary conditions
! these parameters are copied to grid at the end
integer :: domain_shape
real(dp), dimension(3) :: d_shape_param
integer, dimension(1) :: i_shape_param

! scale used for atomic coordinates
real(dp), dimension(3,3) :: cscale
real(dp), dimension(3) :: vtmp
real(dp), dimension(3,3) :: lattvec
real(dp), dimension(3,3) :: pbc_latt_vec

! grid spacing (atomic units)
real(dp) :: h

! net charge in the system (in units of electron charge)
real(dp) :: ncharge

! number of different atom types
integer :: naty

! total actual number of atoms (from all types combined)
! used as counter during atom coordinate read-in 
integer :: natom

! number of replicas of unit cell in a super-cell calculation
integer, dimension(3) :: supercell

! amount of vacuum in super-cell
integer, dimension(3) :: cell_vac

! number of lines in block data
integer :: nlines

! number of states
integer :: nstate

! order of finite difference expansion
integer :: norder

integer, parameter :: mxorder = 20

logical :: restart_run
logical :: polarizability
logical :: so_start

logical :: do_vdw
integer, dimension(1,3) :: hirsh_cell_total
real(dp) :: stpmax

logical lflag, outputallstates
  
! temporary arrays for atom information
integer, parameter :: maxatm = 1000000
integer, dimension(:), allocatable :: tmove
integer, dimension(:), allocatable :: atype
real(dp), dimension(:,:), allocatable :: atom_coord
real(dp), dimension(:,:), allocatable :: initmag

! default pseudopotential file name
character (len=90) :: default_ppfile

! point charge variables
! number of point charge types
integer :: npttyp  

! number of point charges
integer :: nptchrg

! counter
integer :: ipttyp

! charged sheet variables
! number of charged sheet types
integer :: number_charged_sheet_type

! number of charged sheets
integer :: number_charged_sheets

! counter
integer :: icharged_sheet_type

! name of main output file
character(len=200) :: parsec_out_filename

! date label
character(len=26) :: datelabel

! Array for the esdf_split function (llength defined in esdf module)
character(len=llength), dimension(MAX_EXPORT_OPTS) :: flag_words
character(len=llength) :: output_grid_data_copy

character(32) :: format_buffer

integer :: pbc_per
real(dp) :: pbc_ealpha
logical :: pbc_is_on
integer :: elec_st_nkpt
integer :: vector_rng_seed
integer :: vecgen_rng_type
integer :: foldblock_side_length
logical :: md_is_on

real(dp) :: lattice_vector_scale
real(dp), dimension(3) :: grid_shift
logical :: explicit_hartree_pbc
integer :: ndouble
type(bandline), dimension(:), allocatable :: band_st_blines
real(dp), dimension(:,:), allocatable :: nscf_kpts
real(dp), dimension(:), allocatable :: nscf_kpwt

real(dp), dimension(:,:), allocatable :: elec_st_kpts
real(dp), dimension(:), allocatable :: elec_st_kpwt
logical :: band_st_bands_on
integer :: elec_st_kptmethod
integer, dimension(3) :: elec_st_mpgrid
real(dp), dimension(3) :: elec_st_mpshift
logical :: create_dos
logical :: nscf_on
integer, dimension(3) :: dos_mpgrid
real(dp), dimension(3) :: dos_mpshift
logical :: orb_mag
logical :: pot_is_cur
logical :: elec_st_is_cur
logical :: is_mag
real(dp) :: mag_field
logical :: cplx_wfn
logical :: use_old_forces
logical :: print_unconverged_density
logical :: output_ascii_data
integer :: pbc_ylmdos_l
integer :: mv_blksize
integer :: solver_name
integer :: max_lap_buffers
integer :: chebdav_degree
logical :: thread_random_init
logical :: old_vector_random

logical :: spectrum_slicing
logical :: use_krylov_subspace_method
logical :: use_lanczos_dos_estimation
logical :: spectrum_slicing_cycles_early_quit
integer :: spectrum_slicing_max_cycles
integer :: spectrum_slicing_max_cycles_first
integer :: num_of_iter_still_using_chebyshev
integer :: polym_first_ss_iter
integer :: polym_ss
integer :: num_of_copied_groups
integer :: num_of_slice1_filtering
integer :: nslices
real(dp) :: spectrum_slicing_ratio

integer :: bands_ff_maxiter
integer :: ff_maxiter
logical :: use_scalapack
logical :: use_elpa
logical :: use_sfc
logical :: fix_num_eig
logical :: do_subsp
integer :: nscf_nstate
integer :: dos_pnum
logical :: scaledcheb
logical :: use_smart_bound_in_subspace
integer :: chebyshev_degree
integer :: polym_t
logical :: dyntol
real(dp) :: toler
logical :: use_plain_sre
integer :: dpm
logical :: mixer_scf_fail
integer :: tests_logic
integer :: rritz_forced_logic
integer :: solver_boundsmethod
integer :: scalapack_block_size
integer :: elpa_block_size
integer :: maxmv
integer :: mixer_name
integer :: mixer_memory
integer :: mixer_restart
real(dp) :: mixer_param
integer :: lpole
integer :: num_lancz_bound
integer :: mixer_group_size
integer :: mixer_en_stage
real(dp) :: mixer_restart_factor
real(dp) :: mixer_expand_factor
integer :: mixer_preferred_type

integer, dimension(:), allocatable :: clust_natmi
character(len=2), dimension(:), allocatable :: clust_name
real(dp), dimension(:), allocatable :: clust_ylmdos_cutoff
character(len=1024), dimension(:), allocatable :: clust_ppfile
integer :: mixer_block

integer, dimension(:), allocatable :: p_pot_format
real(dp), dimension(:), allocatable :: p_pot_rcore
integer, dimension(:), allocatable :: p_pot_nlocp
integer, dimension(:), allocatable :: p_pot_loc
real(dp), dimension(:,:), allocatable :: p_pot_eleatm
real(dp), dimension(:), allocatable :: p_pot_spol
integer, dimension(:), allocatable :: p_pot_icore
real(dp), dimension(:), allocatable :: p_pot_alpha
real(dp), dimension(:), allocatable :: p_pot_beta1
real(dp), dimension(:), allocatable :: p_pot_acore
logical, dimension(:), allocatable :: p_pot_uspline
real(dp), dimension(:,:), allocatable :: p_pot_uu
real(dp), dimension(:,:), allocatable :: p_pot_jj
logical, dimension(:), allocatable :: p_pot_so
logical, dimension(:), allocatable :: p_pot_rvcd


character(len=llength), dimension(:), allocatable :: pseudopotential_format
logical, dimension(:), allocatable :: nonlinear_core_correction
real(dp), dimension(:), allocatable :: p_pot_rws
logical :: p_pot_is_so
logical :: scf_so
logical :: ncl
integer :: mxwd
real(dp) :: p_pot_so_hcub
integer :: move_name
logical :: recenter_atoms_in_aperiodic_directions
logical :: has_ptchrg
logical :: elec_st_is_so
real(dp), dimension(:,:), allocatable :: ptchrg_coord
real(dp), dimension(:), allocatable :: clust_qpt
integer, dimension(:), allocatable :: clust_nptt
logical :: has_charged_sheet
integer :: clust_nptchrg
real(dp), dimension(:), allocatable :: clust_sheet_charge_of_type
integer, dimension(:), allocatable :: clust_number_charged_sheets_per_type
real(dp), dimension(:,:), allocatable :: sheetchrg_coord
logical :: spin_polarization
logical :: calculate_force
logical :: use_hdf5
integer :: elec_st_nsave
integer, dimension(:), allocatable :: elec_st_indxsave
integer, dimension(3) :: nscf_kgrid
real(dp), dimension(3) :: nscf_kshift
logical :: save_intermediate_charge_density
logical :: save_intermediate_eigenvalues
real(dp) :: elec_st_efermi
logical :: p_pot_oldinpformat
logical :: output_eigenvalues
logical :: move_is_on

integer :: move_mxmove
real(dp) :: move_fmin
real(dp) :: move_stepmax
real(dp) :: move_stepmin
logical :: move_is_restart
logical :: move_write_restart
integer :: restart_cheb_after_n
integer :: restart_cheb_remained_times
integer :: remained_times_atomic_chrg_den
integer :: move_mmax
real(dp) :: md_tempi
real(dp) :: md_tempf
real(dp) :: md_step_tmp
real(dp) :: md_time_step
integer :: md_cool_type
integer :: md_step_num
real(dp) :: md_friction_coef
integer :: md_rng_seed
logical :: md_use_test_rng
logical :: md_is_restart
integer :: md_stride
logical :: generate_complete_parsec_in
integer :: band_st_nlines
integer :: nscf_nkpt
logical :: full_hartree_flag
real(dp), dimension(3) :: pbc_box_size
integer :: band_st_npoints






interface
        character(16) function build_gitcommit()
        end function
end interface

interface
       character(1024) function build_config()
       end function
end interface

interface
       character(2000) function build_defines()
       end function
end interface

interface
       character(2000) function build_flags()
       end function
end interface

interface
       character(6000) function build_line()
       end function
end interface
  
  
! initializing default values
character, parameter :: string_default = ' '

! ---------------------------------------------------------------


! KHL: We will do the following in order
!       1) Read in the parameters and print out to parsec.out
!          (ESDF is used in this stage only)
!       2) Print out to bak_complete_parsec.in
!       3) Copy the parameters to the internal data structures

 
    
  
! initialize error flag
ierr = 0
  


domain_shape = 0
d_shape_param(:) = dzero
i_shape_param(:) = 0







! User parameter input from file 'parsec.in'
! Progress output written into 'parsec.out' (this name can be
! modified by the user)
call esdf_init('parsec.in')
  



! Initialize output:
parsec_out_filename = esdf_string('output_file_name', 'parsec.out')

open(f_parsec,file=trim(parsec_out_filename),form='formatted')  
write(f_parsec,*)
write(f_parsec,*) ('=', i=1,65)
write(f_parsec,*)
write(f_parsec,*) ' PARSEC 1.5.0 - Real-space DFT Program'
write(f_parsec,*) ' Highly experimental, not for production runs !!'
write(f_parsec,*) ' '

! Pack in the build details to the parsec.out file, so have some idea in the
! future of what was used to generate the files. In between the GIT number
! mach file, and defines, we should have a pretty good idea of what was
! underpinning this
write(f_parsec,*) ' begin BUILD_DETAILS '
write(f_parsec,'(a17,a)') ' git commit  : ',trim(build_gitcommit())
write(f_parsec,'(a17,a)') '  config file  : ',trim(build_config())
write(f_parsec,'(a17,a)') '  flags        : ',trim(build_flags())
write(f_parsec,'(a17,a)') '  defines      : ',trim(build_defines())
write(f_parsec,'(a17,a)') '  line         : ',trim(build_line())
write(f_parsec,*) ' end BUILD_DETAILS '

#ifdef MPI
write(f_parsec,*) ' parallel run - using ', nnodes, ' PEs '
#else
write(f_parsec,*) ' serial run, no MPI interface'
#endif

#ifdef _OPENMP
write(f_parsec,*) ' OMP enabled. Max. Threads/PE: ', OMP_GET_MAX_THREADS()
#endif
write(f_parsec,*)  ""
write(f_parsec,*)  " My Task grain number is ", GRAIN_DIV
write(f_parsec,*)  ""

#ifdef _OPENMP
! AJB: probably(!) want to fix this -  
! https://gcc.gnu.org/onlinedocs/gfortran/OpenMP-Modules-OMP_005fLIB-and-OMP_005fLIB_005fKINDS.html
write(f_parsec,*) ' DEBUG: Runtime OMP thread affinity set to ',OMP_GET_PROC_BIND()
write(f_parsec,*) ' where...'
write(f_parsec,*)  "  false state stat =", OMP_PROC_BIND_FALSE
write(f_parsec,*)  "  true  state stat =", OMP_PROC_BIND_TRUE
write(f_parsec,*) ' alternatively...'
write(f_parsec,*)  "  master   binding =", OMP_PROC_BIND_MASTER
write(f_parsec,*)  "  close    binding =", OMP_PROC_BIND_CLOSE
write(f_parsec,*)  "  spread   binding =", OMP_PROC_BIND_SPREAD
#endif

call custom_date_time(datelabel, wstrt)
write(f_parsec,'(/,a,a,a,/)') '  starting run on ', datelabel, ' UTC'
write(f_parsec,*) ('=',i=1,65)
write(f_parsec,*)

call myflush(f_parsec)
  
  




!> read in restart flag: 
!! .false. for initial run, .true. for restaring from parsec.dat
restart_run = esdf_boolean('restart_run', .false.)

if (restart_run) then
        istart = 1
        write(f_parsec,*) ' Restarted Run - from parsec.dat'
else
        istart = 0
        write(f_parsec,*) 'Initial Run - starting from atomic potentials'
endif







vector_rng_seed = esdf_integer('vector_rng_seed', -1)

if (vector_rng_seed == -1) then
        write(f_parsec,*) '**Vector Seed Randomized'
        call mysecond(dtmp)
        vector_rng_seed = int(dtmp)
else
        write(f_parsec,*) '**Vector Seed Specified'
endif

write(f_parsec,*) 'Vector Seed: ', vector_rng_seed

vecgen_rng_type = esdf_integer('vector_rng_type', inputs%vecgen_rng_type)

write(f_parsec,*) 'RNG Type: ', vecgen_rng_type
  







!> specify wfn.dat as restarting file
readwfndat = esdf_boolean('restart_from_wfndat', .false.)

if (readwfndat) then
        write(f_parsec,*) ' WARNING! Restarting from file parsec.dat '
        write(f_parsec,*) ' You should think seriously about &
                &upgrading source code!'
endif
 


! KHL: I changed the default from 2 to 1 for now, for the support of 
!      nonorthogonal grid and symmetry.
foldblock_side_length = esdf_integer('foldblock_side_length', 1)
write(f_parsec,*) 'The side length of a foldblock is', foldblock_side_length






!> should symmetry be ignored
!
! KHL: For now I turn it off. Need to make sure the calculation of 
!      multiple representations of symmetry works.
ignoresym = esdf_boolean('ignore_symmetry', .true.)
write(f_parsec,*) 'input ignore_symmmetry=', ignoresym

!> \note AJB: easy switching off of symmetry for debug:
if (foldblock_side_length /= 1) then
        ignoresym = .true.
        write(f_parsec,*) ' WARNING! SYMMETRY IS AUTOMATICALLY SWITCHED OFF'
endif
    






!> read in Langevin molecular dynamics flag 
md_is_on = esdf_boolean('molecular_dynamics', .false.)
  
h = esdf_physical('grid_spacing', dzero, 'bohr')

if (h == dzero) then
        write(f_parsec,*) 'ERROR: specification of grid spacing not found! '
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 112
        return
endif

write(f_parsec,*)









! read in boundary condition type 
write(f_parsec,*) 'Grid data:'
write(f_parsec,*) '~~------~~'
write(f_parsec,*)
  




!> read in (boundary sphere size / side of box), and grid spacing
boundary_conditions = esdf_reduce( &
        esdf_string('boundary_conditions', 'cluster'))
select case(trim(boundary_conditions))
case ('cluster','0d')
        pbc_per = 0
        pbc_ealpha = dzero
        pbc_is_on = .false.
        elec_st_nkpt = 0
    
case ('wire','tube','1d')
        pbc_per = 1
        pbc_ealpha = dzero
        pbc_is_on = .true.
        elec_st_nkpt = -1

case ('slab','2d')
        pbc_per = 2
        pbc_ealpha = dzero
        pbc_is_on = .true.
        elec_st_nkpt = -1

case ('bulk','3d','pbc')
        pbc_per = 3
        pbc_ealpha = dzero
        pbc_is_on = .true.
        elec_st_nkpt = -1

case default
        write(f_parsec,'(/,a,a)') ' ERROR IN BOUNDARY CONDITIONS! STOP. ', &
                boundary_conditions
        ierr = 101
        return
end select







lattice_vector_scale = &
        esdf_physical('lattice_vector_scale', done, 'bohr')

rmax = esdf_physical('boundary_sphere_radius', dzero, 'bohr')

shapeflag = esdf_reduce(esdf_string('cluster_domain_shape', 'undef'))


select case(pbc_per)
case (3)

#ifndef USEFFTW3
        write(f_parsec,*) 'ERROR! Periodic boundary conditions are input '
        write(f_parsec,*) 'in parsec.in but this executable does not seem '
        write(f_parsec,*) 'to have support for FFTW. Stop. Hammer time.'
        ierr = 105
        return
#endif

        if (esdf_block('cell_shape', nlines)) then
                if (nlines == 1) then
                        write(f_parsec,*) ' Assume orthorhombic periodic cell'

                        pbc_latt_vec(:,:) = dzero

                        read(block_data(1),*,iostat=ierr) &
                                (pbc_latt_vec(i,i), i=1,3)
                else
                        if (nlines /= 3) then
                                write(f_parsec,*) 'ERROR: there should be &
                                        &1 or 3 lines instead of ', nlines
                                write(f_parsec,*) &
                                        'in the "cell_shape" block for 3D PBC'
                                write(f_parsec,*) 'STOP in usrinput'
                                ierr = 102
                                return
                        endif

                        do i = 1, nlines
                                read(block_data(i),*,iostat=ierr) &
                                        pbc_latt_vec(:,i)
                        enddo
                endif

                if (ierr /= 0) then
                        write(f_parsec,*) &
                                'ERROR: bad specification of "Cell_Shape" '
                        write(f_parsec,*) ' block for periodic system! '
                        write(f_parsec,'(10(a,/))') block_data(1:nlines)
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 103
                        return
                endif
        else
                write(f_parsec,*) 'ERROR: specification of "cell_shape" block'
                write(f_parsec,*) ' for periodic system not found! '
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 104
                return
        endif


        pbc_latt_vec(:,:) = lattice_vector_scale*pbc_latt_vec(:,:)
        rmax = done

case (2)

        if (esdf_block('cell_shape', nlines)) then
                if (nlines /= 2) then
                        write(f_parsec,*) 'ERROR: there should be &
                                &2 lines instead of ', nlines
                        write(f_parsec,*) 'in the "cell_shape" block'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 106
                        return
                endif

                pbc_latt_vec(:,:) = zero

                do i = 1, nlines
                        read(block_data(i),*,iostat=ierr) pbc_latt_vec(:,i)
                enddo

                if (ierr /= 0) then
                        write(f_parsec,*) 'ERROR: bad specification &
                                &of "cell_shape" '
                        write(f_parsec,*) ' block for periodic system! '
                        write(f_parsec,'(10(a,/))') block_data(1:nlines)
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 107
                        return
                endif
        else
                write(f_parsec,*) 'ERROR: specification of "cell_shape" block'
                write(f_parsec,*) ' for slab system not found! '
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 108
                return
        endif
  
        pbc_latt_vec(:,:) = lattice_vector_scale*pbc_latt_vec(:,:)
  

        if (rmax == dzero) then
                write(f_parsec,*) 'ERROR: specification of boundary &
                        &length for'
                write(f_parsec,*) ' non-periodic direction not found! '
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 109
                return
        endif
  
case (1)
        if (esdf_block('cell_shape', nlines)) then
                if (nlines /= 1) then
                        write(f_parsec,*) 'ERROR: there should be &
                                &1 line instead of ', nlines
                        write(f_parsec,*) 'in the "Cell_Shape" block'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 106
                        return
                endif

                pbc_latt_vec(:,:) = dzero

                read(block_data(1),*,iostat=ierr) pbc_latt_vec(1,1)

                if (ierr /= 0) then
                        write(f_parsec,*) 'ERROR: bad specification &
                                &of "cell_shape" '
                        write(f_parsec,*) ' block for periodic system! '
                        write(f_parsec,'(10(a,/))') block_data(1:nlines)
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 107
                        return
                endif
        else
                write(f_parsec,*) 'ERROR: specification of "cell_shape" block'
                write(f_parsec,*) ' for slab system not found! '
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 108
                return
        endif

        pbc_latt_vec(:,:) = lattice_vector_scale*pbc_latt_vec(:,:)
  

        if (rmax == dzero) then
                write(f_parsec,*) 'ERROR: specification of &
                        &boundary length for'
                write(f_parsec,*) ' non-periodic direction not found! '
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 109
                return
        endif

case (0)

        select case(trim(shapeflag))
        case ('sphere')
                domain_shape = 0
                d_shape_param(1) = rmax
  
                if (rmax == dzero) then
                        write(f_parsec,*) &
                                'ERROR: specification of boundary radius for'
                        write(f_parsec,*) ' finite system not found! '
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif
  
                if (rmax <= zero) then
                        write(f_parsec,*) &
                                'ERROR: spherical radius must be positive'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif

        case ('ellipsoid')
                domain_shape = 1

                if (esdf_block('domain_shape_parameters', nlines)) then
                        if (nlines /= 1) then
write(f_parsec,*) "ERROR: ellipsoidal radii should be specified"
write(f_parsec,*) " in one line: x_radius y_radius z_radius"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
  
                        read(block_data(1),*,iostat=ierr) &
                                d_shape_param(1), &
                                d_shape_param(2), &
                                d_shape_param(3)
  
                        if (ierr /= 0) then
write(f_parsec,*) "ERROR: bad specification of ellipsoidal"
write(f_parsec,*) " boundary conditions. Should be:"
write(f_parsec,*) " x_radius y_radius z_radius"
                                write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
  
                        if (d_shape_param(1) <= zero .or. &
                            d_shape_param(2) <= zero .or. &
                            d_shape_param(3) <= zero) then

write(f_parsec,*) "ERROR: bad specification of ellipsoidal radii"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
                else
write(f_parsec,*) "ERROR: A Domain_Shape_Parameters block is"
write(f_parsec,*) " required for ellipsoidal cluster domains."
write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif

                rmax = maxval(d_shape_param(:))

        case ('cylinder')
                domain_shape = 2

                if (esdf_block('domain_shape_parameters', nlines)) then
                        if (nlines /= 1) then
write(f_parsec,*) "ERROR: cylindrical boundaries should be specified"
write(f_parsec,*) " in one line: radius length orientation"
write(f_parsec,*) " -- orientation is 1 for x axis, 2 for y, 3 for z"
                                write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
  
                        read(block_data(1),*,iostat=ierr) &
                                d_shape_param(1), &
                                d_shape_param(2), &
                                i_shape_param(1)
          
                        if (ierr /= 0) then
write(f_parsec,*) "ERROR: bad specification of cylindrical"
write(f_parsec,*) " boundary conditions. Should be:"
write(f_parsec,*) " radius length orientation"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
          
                        if (d_shape_param(1) <= zero) then
write(f_parsec,*) "ERROR: bad specification of cylindrical"
write(f_parsec,*) " radius (should be positive)"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
          
                        if (d_shape_param(2) <= zero) then
write(f_parsec,*) "ERROR: bad specification of cylindrical"
write(f_parsec,*) " length (should be positive)"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
          
                        if ( (i_shape_param(1) < 1) .or. &
                             (i_shape_param(1) > 3) ) then
write(f_parsec,*) "ERROR: bad specification of cylindrical"
write(f_parsec,*) " orientation. Should be 1 for x-axis,"
write(f_parsec,*) " 2 for y-axis, 3 for z-axis"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
                else
write(f_parsec,*) "ERROR: A domain_shape_parameters block is"
write(f_parsec,*) " required for cylindrical cluster domains."
write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif

                rmax = sqrt((d_shape_param(2)/2.0d0)**2 + d_shape_param(1)**2)

        case ('box')
                domain_shape = 3

                if (esdf_block('domain_shape_parameters', nlines)) then
                        if (nlines /= 1) then
write(f_parsec,*) "ERROR: box boundaries should be specified"
write(f_parsec,*) " in one line: x_length y_length z_length"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
  
                        read(block_data(1),*,iostat=ierr) &
                                d_shape_param(1), &
                                d_shape_param(2), &
                                d_shape_param(3)
          
                        if (ierr /= 0) then
write(f_parsec,*) "ERROR: bad specification of box"
write(f_parsec,*) " boundary conditions. Should be:"
write(f_parsec,*) " x_length y_length z_length"
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
  
                        if (d_shape_param(1) <= zero .or. &
                            d_shape_param(2) <= zero .or. &
                            d_shape_param(3) <= zero) then

write(f_parsec,*) "ERROR: bad specification of box"
write(f_parsec,*) " dimensions.  All lengths should be positive."
write(f_parsec,*) 'STOP in usrinput'
                                ierr = 110
                                return
                        endif
                else
write(f_parsec,*) "ERROR: A domain_shape_parameters block is"
write(f_parsec,*) " required for box cluster domains."
write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif

                rmax = sqrt((d_shape_param(1)/2.0d0)**2 + &
                            (d_shape_param(2)/2.0d0)**2 + &
                            (d_shape_param(3)/2.0d0)**2)

        case default
                write(f_parsec,*) "WARNING: Cluster Calculation &
                        &Domain Shape Unspecified"
                write(f_parsec,*) " Assuming Spherical Shape"

                domain_shape = 0

                if (rmax == dzero) then
                        write(f_parsec,*) &
                                'ERROR: specification of boundary radius for'
                        write(f_parsec,*) ' finite system not found! '
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 110
                        return
                endif

                d_shape_param(1) = rmax
        end select ! end of domain_shape
  
case default
        write(f_parsec,*) 'ERROR: unspecified boundary conditions! '
        write(f_parsec,*) 'STOP in usrinput ', pbc_per
        ierr = 111
        return
end select













supercell(:) = 1

if (esdf_block('super_cell', nlines)) then
        if (nlines /= 1) then
                write(f_parsec,*) &
                        'ERROR: there should be 1 line instead of ', nlines
                write(f_parsec,*) 'in the "super_cell" block'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 158
                return
        endif

        read (block_data(1),*,iostat=ierr) supercell(1:pbc_per)

        if (ierr /= 0) then
                write(f_parsec,*) 'ERROR: bad specification of "super_cell" '
                write(f_parsec,*) ' block for periodic system! '
                write(f_parsec,'(10(A,/))') block_data(1:nlines)
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 159
                return
        endif

        write(f_parsec,*) ' Periodic cell is being replicated &
                &according to super-cell'
        write(f_parsec,*) ' specification. Super-cell size = ', &
                supercell(1:pbc_per)

        do i = 1, pbc_per
                pbc_latt_vec(:,i) = pbc_latt_vec(:,i)*real(supercell(i),dp)
        enddo
endif






cell_vac(:) = 0

if (esdf_block('super_cell_vac',nlines)) then
        if (nlines /= 1) then
                write(f_parsec,*) &
                        'ERROR: there should be 1 line instead of ', nlines
                write(f_parsec,*) 'in the "super_cell_vac" block'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 160
                return
        endif

        read(block_data(1),*,iostat=ierr) cell_vac(1:pbc_per)

        if (ierr /= 0) then
                write(f_parsec,*) 'ERROR: bad specification of &
                        &"super_cell_vac" '
                write(f_parsec,*) ' block for periodic system! '
                write(f_parsec,'(10(a,/))') block_data(1:nlines)
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 161
                return
        endif

        write(f_parsec,*) ' Vacuum is added to super-cell'
        write(f_parsec,*) ' amount of vacuum space = ', cell_vac(1:pbc_per)

        do i = 1, pbc_per
                pbc_latt_vec(:,i) = &
                        pbc_latt_vec(:,i)*( one + real(cell_vac(i),dp) )
        enddo
endif




!
! Add 1 to the diagonal part of pbc%latt_vec for non-periodic directions.
!
do i = pbc_per+1, 3
        pbc_latt_vec(i,i) = done
enddo
  




! ==============================================================
! ==============================================================
! Define grid shift:
! Non-periodic directions : shift = 0.5;
! Periodic directions orthogonal to all others: shift = 0.5;
! Periodic directions non-orthogonal to some other direction: shift = zero.
!
!> \note AJB: wrote this more explicitly to appease the O2/O1 level on ifort16
if (ignoresym) then 
        grid_shift(:) = dzero !> \note AMIR - this should be checked !!!!!!!
else
        grid_shift(:) = half
endif
  
! AJB: override to specify a shift via input
if (esdf_block('grid_shift', nlines)) then
        write(f_parsec,*) '   Grid Shift is read from input. &
                &This has untested consequences!'

        if (nlines /= 1) then
                write(f_parsec,*) 'Warning: Grid_Shift only needs one line'
                write(f_parsec,*) 'Taking only the first line in the block'
        endif

        read(block_data(1),*,iostat=ierr) (grid_shift(i), i=1,3)

        grid_shift(:) = abs(grid_shift(:))
endif
  




lattvec(:,:) = matmul( transpose(pbc_latt_vec(:,:)), pbc_latt_vec(:,:) )

do i1 = 1, pbc_per
do i2 = 1, pbc_per
        if (i1 /= i2) then
                if (abs(lattvec(i1,i2)) > dzero) then
                        grid_shift(i1) = dzero

                        !write(f_parsec,*) ' Will not grid shift &
                        !        &based on directions', i1, i2
                else
                        !write(f_parsec,*) ' Will shift based on 
                        !        &directions', i1, i2
                endif
        endif
enddo
enddo








do jj = 1, pbc_per
        lattvec(:,jj) = pbc_latt_vec(:,jj)/ &
                (one + real(cell_vac(jj),dp))/ &
                real(supercell(jj),dp)
enddo
  




! Are we explicitly calculating the hartree potential?
explicit_hartree_pbc = esdf_boolean('calc_hartree_g', .false.)


select case(pbc_per)
case (0)
        write(f_parsec,*) 'Confined system (cluster) with zero &
                &boundary condition!'

        select case(domain_shape)
        case (0)
                write(f_parsec,*) ' Spherical domain shape:'
                write(f_parsec,'(a,f10.6,a)') ' --- Max Radius is ', &
                        rmax, ' bohrs'
        case (1)
                write(f_parsec,*) ' Ellipsoidal domain shape:'
                write(f_parsec,'(a,f10.6,a)') ' --- x radius is ', &
                        d_shape_param(1), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- y radius is ', &
                        d_shape_param(2), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- z radius is ', &
                        d_shape_param(3), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for &
                        &grid creation) is ', rmax, ' bohrs'
        case (2)
                write(f_parsec,*) ' Cylindrical domain shape:'

                select case(i_shape_param(1))
                case (1)
                        write(f_parsec,*) ' --- Oriented along the x axis'
                case (2)
                        write(f_parsec,*) ' --- Oriented along the y axis'
                case (3)
                        write(f_parsec,*) ' --- Oriented along the z axis'
                end select

                write(f_parsec,'(a,f10.6,a)') ' --- Radius is ', &
                        d_shape_param(1), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- Length is ', &
                        d_shape_param(2), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for &
                        &grid creation) is ', rmax, ' bohrs'
        case (3)
                write(f_parsec,*) ' Box domain shape:'
                write(f_parsec,'(a,f10.6,a)') ' --- x length is ', &
                        d_shape_param(1), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- y length is ', &
                        d_shape_param(2), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- z length is ', &
                        d_shape_param(3), ' bohrs'
                write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for &
                        &grid creation) is ', rmax, ' bohrs'
        case default
                write(f_parsec,*) 'Incorrect domain shape encountered'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
        end select

        write(f_parsec,'(a,f9.6,a)') ' Grid spacing is ', h, ' bohrs'

case (1)
        pbc_box_size(:) = dzero
        pbc_box_size(1) = abs(pbc_latt_vec(1,1))
           
        write(f_parsec,*) 'Tube boundary conditions!' 
        write(f_parsec,*) 'System is non-periodic on the yz plane'
        write(f_parsec,*) 'and periodic along x direction.'
        write(f_parsec,*)
        write(f_parsec,*) 'Periodicity length [bohr] : '
        write(f_parsec,'(3(f15.10,1x))') pbc_latt_vec(1,1)
        write(f_parsec,*)
        write(f_parsec,'(a,f10.6,a)') ' Boundary cylinder radius is ', &
                rmax, ' bohrs'
        write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ', &
                h,' bohrs'
        write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
        write(f_parsec,*)
  
case (2)
        pbc_box_size(:) = dzero

        do i = 1, 2
                pbc_box_size(i) = sqrt( sum(pbc_latt_vec(:,i)**2) )
        enddo
  
        write(f_parsec,*) 'Periodic boundary conditions!'
        write(f_parsec,*) 'System is periodic on the xy plane'
        write(f_parsec,*) 'and non-periodic on the z direction.'
        write(f_parsec,*)
        write(f_parsec,*) 'Unit lattice vectors [bohr] : '

        do i = 1, 3
                write(f_parsec,'(3(f15.10,1x))') pbc_latt_vec(:,i)
        enddo

        write(f_parsec,*)
        write(f_parsec,'(a,f10.6,a)') ' Boundary slab height is ', &
                rmax, ' bohrs'
        write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ', &
                h,' bohrs'
        write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
        write(f_parsec,*)
  
case (3)
        do i = 1, 3
                pbc_box_size(i) = sqrt( sum(pbc_latt_vec(:,i)**2) )
        enddo
  
        write(f_parsec,*) 'Periodic boundary conditions!' 
        write(f_parsec,*) 'System is fully periodic '
        write(f_parsec,*) 'Unit lattice vectors [bohr] : '

        do i = 1, 3
                write(f_parsec,'(3(f15.10,1x))') pbc_latt_vec(:,i)
        enddo

        write(f_parsec,*)
        write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ', &
                h,' bohrs'
        write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
        write(f_parsec,*)
  

        if (explicit_hartree_pbc) then
                write(f_parsec,*)
                write(f_parsec,*) 'CAUTION: The Hartree potential will &
                        &be calculated in reciprocal space'
                write(f_parsec,*) 'IMPLEMENTATION INCOMPLETE - &
                        &GARBAGE INCOMING'
                write(f_parsec,*)
        endif
end select
  








ndouble = esdf_integer('double_grid_order', 1)

if (ndouble < 1) then
        write(f_parsec,*) 'ERROR! double grid order must be greater &
                &than zero! ', ndouble
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 113
        return
endif
    
if (ndouble > 1) then
        write(f_parsec,'(a,i4)') ' Order of double grid is ', ndouble
        write(f_parsec,'(a,/)') ' WARNING! DOUBLE GRID WILL MODIFY &
                &FORCES AND TOTAL ENERGY!'
endif











write(f_parsec,*) 'Grid points could be shifted from origin: '
write(f_parsec,'(a,3f8.4,a)') ' shift vector = ', &
        grid_shift(:), '   [units of grid spacing]'
  



! Read information about kpoint sampling.

! this flag is here to make sure that it is off in cluster runs.  
band_st_bands_on = .false.

! this flag is here to make sure that it is off in 
! cluster runs -- although later it might make sense to reseruct it
nscf_on = .false.

 





elec_st_kptmethod = -1


kpoint_method = esdf_reduce(esdf_string ('kpoint_method', 'none'))

kpoint_unit = esdf_reduce( esdf_string('kpoint_unit', &
        'cartesian_inverse_bohr') )

band_st_nlines = 0
band_st_npoints = esdf_integer('bandstruc_points', 100)
nscf_nkpt = 0
nscf_kpoint_unit = esdf_reduce( esdf_string ('nscf_kpoint_unit', &
        'cartesian_inverse_bohr') )


if (pbc_is_on) then
  
        select case(trim(kpoint_method))
        case ('none')
                write(f_parsec,*) ' Kpoint sampling is off.'
                write(f_parsec,*) ' Calculation at gamma point'
                elec_st_nkpt = 0
        case ('mp')
                elec_st_kptmethod = MONKHORST_PACK
                elec_st_nkpt = 1

                write(f_parsec,*) ' kpoints selected by &
                        &Monkhort-Pack algorithm'

                if (esdf_block('monkhorst_pack_grid', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Grid: ', nlines
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 114
                                return
                        endif

                        elec_st_mpgrid(:) = 1

                        read(block_data(nlines),*,iostat=ierr) &
                                (elec_st_mpgrid(i), i=1,pbc_per)

                        if ( (ierr /= 0) .or. &
                             (elec_st_mpgrid(1) <= 0) .or. &
                             (elec_st_mpgrid(2) <= 0) .or. &
                             (elec_st_mpgrid(3) <= 0)) then

                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Grid'
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 115
                        endif
                endif

                write(f_parsec,*) ' Monkhorst-Pack grid dimensions specified'
                write(f_parsec,37) (elec_st_mpgrid(i), i=1,pbc_per)
  37 format(1x,i3,1x,'X',i3,1x,'X',i3)

                if (esdf_block('monkhorst_pack_shift', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Shift'
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 116
                                return
                        endif

                        elec_st_mpshift(:) = dzero

                        read(block_data(nlines),*,iostat=ierr) &
                                (elec_st_mpshift(i), i=1,pbc_per)

                        if ( (ierr /= 0) .or. &
                             (elec_st_mpshift(1) < dzero) .or. &
                             (elec_st_mpshift(2) < dzero) .or. &
                             (elec_st_mpshift(3) < dzero) ) then
                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Shift'
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 117
                                return
                        endif

                        write(f_parsec,*)' Monkhorst-Pack shift specified'
                else
                        elec_st_mpshift(:) = dzero

                        write(f_parsec,*)' Default Monkhorst-Pack shift '
                endif

                write(f_parsec,38) (elec_st_mpshift(i), i=1,pbc_per)
  38 format(1x,f7.3,1x,'X',f7.3,1x,'X',f7.3)

        case ('manual')
                elec_st_kptmethod = KP_MANUAL

                write(f_parsec,*)' kpoints selected manually'

                if (esdf_block('kpoint_list', nlines)) then
                        elec_st_nkpt = nlines

                        allocate(elec_st_kpts(3,elec_st_nkpt))
                        allocate(elec_st_kpwt(elec_st_nkpt))
                        elec_st_kpts(:,:) = dzero
                        elec_st_kpwt(:) = dzero

                        do i = 1, nlines
                                read(block_data(i),*) &
                                        elec_st_kpts(1:3,i), elec_st_kpwt(i)
                        enddo
                else
                        write(f_parsec,*) 'ERROR: Could not find list &
                                &of kpoint coordiantes'
                        write(f_parsec,*) 'STOP in usrinput.'
                        ierr = 118
                        return
                endif

                ! cscale : reciprocal unit lattice vectors; necessary only if
                ! kpoint_unit is unit_reciprocal_lattice_vectors.
                !
                ! KHL:      / a1_x a2_x a3_x \       / b1_x b2_x b3_x \
                !       A = | a1_y a2_y a3_y |   B = | b1_y b2_y b3_y |
                !           \ a1_z a2_z a3_z /       \ b1_x b2_z b3_z /
                !
                !       trans(B) A = 2*pi I  ==>  B = 2*pi inv(trans(A))
                cscale(:,:) = dzero
                cscale(:,:) = transpose(lattvec(:,:))

                call mtrxin(cscale(:,:), vtmp(1), vtmp(2))

                cscale(:,:) = cscale(:,:)*twopi

                if (trim(kpoint_unit) == 'reciprocal_lattice_vectors') then
                        do i = 1, elec_st_nkpt
                                call matvec3('N', cscale(:,:), &
                                        elec_st_kpts(:,i), vtmp(:))

                                elec_st_kpts(:,i) = vtmp(:)
                        enddo
                endif

                write(f_parsec,*)' Kpoints (units 1/Bohr) and &
                        &sampling weights'

                do i = 1, elec_st_nkpt
                        write(f_parsec,'(3x,f8.5,1x,f8.5,1x,f8.5,1x,f8.5)') &
                                elec_st_kpts(:,i), elec_st_kpwt(i)

                        if (elec_st_kpwt(i) < 0) then
                                write(f_parsec,*) 'Sampling weight must &
                                        &be positive'
                                write(f_parsec,*) 'STOP in usrinput.'
                                ierr = 119
                                return
                        endif
                enddo
        end select




        ! read band structure parameters from input file   
        if (esdf_block('bandstruc', nlines)) then
                if (nlines > 0) then
                        if (elec_st_nkpt == 0) then
                                write(f_parsec,*) 'Wave functions are &
                                        &real. Cannot calculate band &
                                        &structure. Please use MP or &
                                        &manual to enable the calculation.'
                                write(f_parsec,*) 'STOP in usrinput.'
                                ierr = -1
                                return
                        endif

                        band_st_bands_on = .true.
                        band_st_nlines = nlines

                        allocate(band_st_blines(nlines))  

                        do i = 1, nlines
                                read(block_data(i),*) &
                                        band_st_blines(i)%line_num, &
                                        band_st_blines(i)%start(1:3), &
                                        band_st_blines(i)%end(1:3), &
                                        band_st_blines(i)%line_name
                        enddo

                        write(f_parsec,*) 'Calculating band structure'
                endif
        endif
  
        ! Read non self consistent calculation kpoints from file
        if (esdf_block('nscf_kpoints', nlines)) then
                if (nlines > 0) then
                        nscf_on = .true. 
                        nscf_nkpt = nlines

                        allocate(nscf_kpts(3,nscf_nkpt))
                        allocate(nscf_kpwt(nscf_nkpt))
                        nscf_kpts(:,:) = dzero
                        nscf_kpwt(:) = dzero

                        do i = 1, nlines
                                read(block_data(i),*) &
                                        nscf_kpts(1:3,i), nscf_kpwt(i)
                        enddo

                        write(f_parsec,*) ' Calculating non self consistent &
                                &electronic structure'
                endif
        endif

        if (nscf_on) then

                ! cscale : reciprocal unit lattice vectors; necessary only if
                ! kpoint_unit is unit_reciprocal_lattice_vectors.
                cscale(:,:) = dzero
                cscale(:,:) = transpose(lattvec(:,:))

                call mtrxin(cscale(:,:), vtmp(1), vtmp(2))

                cscale(:,:) = cscale(:,:)*twopi

                if (trim(nscf_kpoint_unit) == &
                        'reciprocal_lattice_vectors') then

                        do i = 1, nscf_nkpt
                                call matvec3('N', cscale(:,:), &
                                        nscf_kpts(:,i), vtmp(:))

                                nscf_kpts(:,i) = vtmp(:)
                        enddo
                endif

                ! Renormalize the weights to 1
                dtmp = sum(nscf_kpwt(:), 1) 
                nscf_kpwt(:) = nscf_kpwt(:)/dtmp
  
                write(f_parsec,*)' Kpoints (units 1/Bohr) and &
                        &sampling weights'

                do i = 1, nscf_nkpt
                        write(f_parsec,'(3x,f8.5,1x,f8.5,1x,f8.5,1x,f8.5)') &
                                nscf_kpts(:,i), nscf_kpwt(i)

                        if (nscf_kpwt(i) < 0) then
                                write(f_parsec,*) 'Sampling weight must &
                                        &be positive'
                                write(f_parsec,*) 'STOP in usrinput.'
                                ierr = 119
                                return
                        endif
                enddo
        endif
  

        if (nscf_on) then
                if (.not. restart_run) then
write(f_parsec,*) ' In case of non self consistent calculations'
write(f_parsec,*) ' Please specify restart flag to read potential'
write(f_parsec,*) ' from a previous run'
write(f_parsec,*) ' STOP in usrinput'
                        ierr = 114
                        return
                endif
        endif
  
endif ! pbc_is_on







   
create_dos = esdf_boolean('create_dos', .false.)

dos_pnum = esdf_integer('dos_pnum', 1000)

pbc_ylmdos_l = esdf_integer('ylm_dos_l', -1)

if (create_dos .and. pbc_is_on) then
        write(f_parsec,*)' Full DOS creation is on'

        if (esdf_block('dos_mp_grid', nlines)) then
                if (nlines /= 1) then
                        write(f_parsec,*) &
                                'ERROR: there should be 1 line &
                                &instead of ', nlines
                        write(f_parsec,*) 'in the "dos_mp_grid" block'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 160
                        return
                endif

                dos_mpgrid(:) = 1

                read(block_data(nlines),*,iostat=ierr) dos_mpgrid(1:pbc_per)

                if ( (ierr /= 0) .or. &
                     (dos_mpgrid(1) <= 0) .or. &
                     (dos_mpgrid(2) <= 0) .or. &
                     (dos_mpgrid(3) <= 0)) then

                        write(f_parsec,*)' error in specifying DOS MP Grid'
                        write(f_parsec,*)' STOP in usrinput'
                        ierr = 1
                endif

                write(f_parsec,*)' DOS MP grid dimensions specified'
                write(f_parsec,37) (dos_mpgrid(i), i=1,pbc_per)

                if (esdf_block('dos_mp_shift', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*)' error in specifying &
                                        &DOS MP Shift'
                                write(f_parsec,*)' STOP in usrinput'
                                ierr = 1
                        endif

                        dos_mpshift(:) = zero

                        read(block_data(nlines),*,iostat=ierr) &
                                (dos_mpshift(i), i=1,pbc_per)

                        if ( (ierr /= 0) .or. &
                             (dos_mpshift(1) < dzero) .or. &
                             (dos_mpshift(2) < dzero) .or. &
                             (dos_mpshift(3) < dzero) ) then

                                write(f_parsec,*)' error in specifying &
                                        &DOS MP Shift'
                                write(f_parsec,*)' STOP in usrinput'
                                ierr = 1
                        endif
                endif

                write(f_parsec,*)' DOS MP shift specified'
                write(f_parsec,38) (dos_mpshift(i), i=1,pbc%per)
        else
                if (elec_st_kptmethod == KP_MANUAL) then
                        write(f_parsec,*) ' WARNING: DOS cannot be &
                                &created based on a manual MP grid, &
                                &please specify a DOS MP grid. &
                                &DOS creation aborted !'

                        create_dos = .false.
                else
                        write(f_parsec,*)' DOS MP Grid not specified, &
                                &using one used for density calculation'

                        dos_mpgrid(:) = elec_st_mpgrid(:)
                        dos_mpshift(:) = elec_st_mpshift(:)  
                endif
        endif 
  
        if (restart_run) then
                elec_st_kptmethod = MONKHORST_PACK
                elec_st_mpgrid(:) = dos_mpgrid(:)
                elec_st_mpshift(:) = dos_mpshift(:)
                outflag = -1
        endif

endif





! ==============================================================
! Read request for orbital magnetism
! ==============================================================
orb_mag = esdf_boolean('orb_mag', .false.)
if (orb_mag)then
        pot_is_cur = .true.
        elec_st_is_cur = .true.
else
        pot_is_cur = .false.
        elec_st_is_cur = .false.
endif
  


! ==============================================================
! Read value of external magnetic field
! ==============================================================
is_mag = .false.
mag_field = esdf_double('external_mag_field', dzero)

if (abs(mag_field) > dzero) then
        is_mag = .true.
        mag_field = mag_field/2.5d+9

        write(f_parsec,'(/,a)') ' Applying external uniform magnetic field'
        write(f_parsec,'(a,f11.5,a)') ' Magnetic field: H =', &
                mag_field, ' Gauss'
else
        is_mag = .false.
        !write(f_parsec,'(/,a)') ' No external uniform magnetic field H=0 !!'
endif
  


! ==============================================================
! Read user defined complex or real wfn value.
! ==============================================================
cplx_wfn = .false.

if (elec_st_nkpt > 0) cplx_wfn = .true.
if (is_mag) cplx_wfn = .true.

if (cplx_wfn) then
        write(f_parsec,*) 'WAVEFUNCTIONS ARE COMPLEX!'
        !> \todo AJB: call grid_set_rmax_step again and modify fold size
else
        write(f_parsec,*) 'WAVEFUNCTIONS ARE REAL!'
endif
  



! ==============================================================
! Read order of finite difference expansion.
! ==============================================================
norder = esdf_integer('expansion_order', 12)

if (norder /= 12) then
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Expansion_Order must be 12 until &
                &more stencils'
        write(f_parsec,*) 'patterning are added to the kernel -AJB'
        write(f_parsec,*) 'STOP in usrinput.'
        ierr = 121
        return
endif
  
write(f_parsec,'(a,i2,/)') ' The Finite-difference expansion is &
        &of order ', norder

if ((norder < 1) .or. (norder > mxorder)) then
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Expansion_Order is the number of'
        write(f_parsec,*) 'neighbors used on two sides in numerical'
        write(f_parsec,*) 'derivative. It should be an integer' 
        write(f_parsec,*) 'between 2 and ', mxorder,' Input as ', norder
        write(f_parsec,*) 'STOP in usrinput.'
        ierr = 121
        return
endif
  
if (mod(norder,2) /= 0) then
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Expansion_Order should be an even number'
       write(f_parsec,*) 'between 2 and ', mxorder,' Input as ',norder
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 122
       return
endif











! ==============================================================
! Read in the number of eigenstates to be calculated, nstate;
! net cluster charge, ncharge.
! ==============================================================
nstate = esdf_integer('states_num', 0)

nscf_nstate = esdf_integer('nscf_states_num', nstate)

if (nstate == 0) then
        write(f_parsec,*) 'ERROR: unknown number of states. '
        write(f_parsec,*) ' Input line "states_num" not found!'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 123
        return
endif
  
if (nstate < 0) then
        write(f_parsec,*) 'States_Num is negative. Preparing for &
                &Special TEST MODE'
        nstate = 0
endif
  
ncharge = esdf_physical('net_charges', dzero, 'e')

write(f_parsec,*) 'Eigenvalue data: '
write(f_parsec,*) '---------------- '
write(f_parsec,*) 'Number of states: ', nstate
write(f_parsec,'(a,g12.4,a)') ' Net cluster charge = ', ncharge,'  [e] '
  
  






! ==============================================================
! read in electron temperature (in Kelvin)
! ==============================================================
tfermi = esdf_physical('fermi_temp', 80.0d0, 'k')

write(f_parsec,*)

if (tfermi >= dzero) then
        write(f_parsec,*) 'Fermi temperature = ', tfermi, ' [K]'
else 
        write(f_parsec,*) 'WARNING: reading occupations from occup.in file'

        ! occupations read from file in initial.f
        if (elec_st_nkpt > 0) then
                write(f_parsec,*) '...but kpoint sampling is ON!'
                write(f_parsec,*) 'STOP in usrinput.'
                ierr = 120
                return
        endif
endif






write(f_parsec,*)
write(f_parsec,*) 'Self-consistency data: '
write(f_parsec,*) '----------------------'

! read in maximal # of iterations before giving up on self-consistency
mxiter = esdf_integer('max_iter', 50)

write(f_parsec,*) 'Maximum number of iterations is ', mxiter
  








! ==============================================================
! read in eigensolver
! ==============================================================
eigensolver = esdf_reduce(esdf_string ('eigensolver', 'chebff'))
  
#ifndef USEARPACK
if (trim(eigensolver) == 'arpack') then
        write(f_parsec,*) ' ERROR: arpack is selected as eigensolver but'
        write(f_parsec,*) ' this executable seems to have missing arpack.'
        write(f_parsec,*) ' Stop in usrinput.'
        ierr = 124
        return
endif
#endif

! use old forces
use_old_forces = esdf_boolean('use_old_forces', inputs%use_old_forces)

! print unconverged density during each iteration
print_unconverged_density = esdf_boolean('print_unconverged_density', &
        inputs%print_unconverged_density)

! print final density after scf loop
output_ascii_data = esdf_boolean('output_ascii_data', &
        inputs%output_ascii_data)

! Frozen-density embedding external potential for AFM simulations.
pot%fex_is = esdf_boolean('potential_field', .false.)
pot%fex_name = ''
pot%kin_name = 0
pot%vum = zero
pot%vuk = zero
if (pot%fex_is) then
        pot%fex_name = esdf_string('potential_field_name', 'pot.dat')
        write(f_parsec,*) 'External potential field is provided by user.'

        fdet_kinetic_functional = &
                esdf_reduce(esdf_string('kinetic_energy_functional', 'tf'))
        select case (trim(fdet_kinetic_functional))
        case ('pw')
                pot%kin_name = 1
                write(f_parsec,*) 'Kinetic Energy Functional is PW91K GGA.'
        case ('pb')
                pot%kin_name = 2
                write(f_parsec,*) 'Kinetic Energy Functional is PBE-like GGA.'
                pot%vum = esdf_double('pbe_m', 0.2319d0)
                pot%vuk = esdf_double('pbe_k', 0.8438d0)
                write(f_parsec,*) 'PBE mu and kappa:'
                write(f_parsec,*) 'mu    = ', pot%vum
                write(f_parsec,*) 'kappa = ', pot%vuk
        case ('tf')
                pot%kin_name = 3
                write(f_parsec,*) 'Kinetic Energy Functional is Thomas-Fermi LDA.'
        case ('tw')
                pot%kin_name = 4
                write(f_parsec,*) 'Kinetic Energy Functional is Thomas-Fermi plus GEA.'
        case ('no')
                pot%kin_name = 0
                write(f_parsec,*) 'CAUTION! Kinetic Energy is not computed.'
        case default
                write(f_parsec,*) 'No kinetic energy functional has been specified.'
                write(f_parsec,*) 'Using Thomas-Fermi functional.'
                pot%kin_name = 3
        end select
        ! New option (default off): tip run in a sphere centred on the tip.
        tipsphere_on = esdf_boolean('boundary_sphere_around_tip', .false.)
        if (tipsphere_on) write(f_parsec,*) &
                'FDET: the tip is computed in its own sphere (boundary_sphere_around_tip).'
endif

! default use of semi-random initial guess (same each run)
thread_random_init = esdf_boolean('thread_random_init', .true.)
old_vector_random = esdf_boolean('old_vector_random', .false.)


! not used:
max_lap_buffers = esdf_integer('max_lap_buffers', 2)

ff_maxiter = esdf_integer('ff_maxiter', 3)
bands_ff_maxiter = esdf_integer('bands_ff_maxiter', ff_maxiter)
write(f_parsec,*) 'bands_ff_maxiter', bands_ff_maxiter

select case (trim(eigensolver))
case ('arpack')
        write(f_parsec,*) 'Using ARPACK (implicitly restarted &
                &Arnoldi eigensolver)'

        solver_name = ARPACK

        mv_blksize = min(nstate/2, 4)
        mv_blksize  = esdf_integer('matvec_blocksize', mv_blksize)

        if (mv_blksize > nstate) then
                write(f_parsec,*) 'Matvec block size bigger than &
                        &the number of states, adjusting.'
                mv_blksize  = nstate/2
        else
                write(f_parsec,*) 'The matvec operations are (mostly) &
                        &called to with block size: ', mv_blksize
        endif

case ('chebff') 
        write(f_parsec,*) 'Using first-filter solver'

        solver_name = CHEBFF

        ! continue to use 'chebdav_degree' without introducing 
        ! a new variable/parameter
        chebdav_degree = esdf_integer('chebdav_degree', 20)

        write(f_parsec,'(a,1x,i5)') ' Polynomial degree for First-filter &
                &is ', chebdav_degree

        ! If the degree is between 10 and 15, can still try 
        ! without erring out
        if (chebdav_degree < 10) then  
                write(f_parsec,*) &
                        ' warning: for chebff, the chebdav_degree &
                        &better be at least 10'
                write(f_parsec,*) ' your chebdav_degree = ', chebdav_degree
                write(f_parsec,*) &
                        ' automatically updating chebdav_degree to 12 '

                chebdav_degree = 12
        endif

        mv_blksize = min(nstate/2, 6)
        mv_blksize = esdf_integer('matvec_blocksize', mv_blksize)

        write(f_parsec,*) 'The matvec operations are (mostly) &
                &called to with block size: ', mv_blksize


        write(f_parsec,'(a,1x,i5)') ' Maximum iteration number &
                &for First-filter is ', ff_maxiter

        !> \todo CML-changed the minimum to 0 to enable testing, but probably
        !! should have an override flag for purposes of this to keep helpful
        !! stuff when expert isn't using
        if (ff_maxiter < 0 .or. ff_maxiter > 50) then
                write(f_parsec,*) ' warning: input ff_maxiter is not &
                        &within [1, 50] '
                write(f_parsec,*) ' your ff_maxiter = ', ff_maxiter
                write(f_parsec,*) ' automatically update ff_maxiter to 3'

                ff_maxiter = 3
        endif

        if (thread_random_init) then
                write(f_parsec,*) 'WARNING, threaded randomization of &
                        &initial guess is selected'
                write(f_parsec,*) 'Results will differ from old PARSEC runs'
        endif

case ('chebdav') 
        write(f_parsec,*) 'Using Chebyshev-Davidson eigensolver'

        solver_name = CHEBDAV

        chebdav_degree = esdf_integer('chebdav_degree', 20)

        write(f_parsec,'(a,1x,i5)') ' Polynomial degree for &
                &Chebyshev-Davidson is ', chebdav_degree

        if (chebdav_degree < 15) then
                write(f_parsec,*) ' ERROR: chebdav_degree should be &
                        &at least 15!'
                write(f_parsec,*) ' chebdav_degree = ', chebdav_degree
                write(f_parsec,*) ' automatically update chebdav_degree &
                        &to 15 '
                chebdav_degree = 15
                return
        endif

        mv_blksize = min(nstate/2, 6)
        mv_blksize = esdf_integer('matvec_blocksize', mv_blksize)

        write(f_parsec,*) 'The matvec operations are (mostly) &
                &called to with block size: ', mv_blksize

case default
        write(f_parsec,*) 'wrong input eigen solver name: ', trim(eigensolver)
        write(f_parsec,*) 'STOP in usrinput.'
        ierr = 127
        return
end select
  










! ===============================================================
! Spectrum slicing
! ===============================================================
write(7,*)

spectrum_slicing = esdf_boolean('spectrum_slicing', .false.)
use_krylov_subspace_method = esdf_boolean('use_krylov_subspace_method', .false.)
use_lanczos_dos_estimation = esdf_boolean('use_lanczos_dos_estimation', .false.)
spectrum_slicing_cycles_early_quit = esdf_boolean('spectrum_slicing_cycles_early_quit', .false.)
spectrum_slicing_max_cycles = esdf_integer('spectrum_slicing_max_cycles', 1)
spectrum_slicing_max_cycles_first = esdf_integer('spectrum_slicing_max_cycles_first', -1)
num_of_iter_still_using_chebyshev = esdf_integer('num_of_iter_still_using_chebyshev', 1)
polym_first_ss_iter = esdf_integer('polym_first_ss_iter', -1)
polym_ss = esdf_integer('polym_ss', 100)
num_of_copied_groups = esdf_integer('num_of_copied_groups', 2)
num_of_slice1_filtering = esdf_integer('num_of_slice1_filtering', -1)
nslices = esdf_integer('nslices', 1)
spectrum_slicing_ratio = esdf_double('spectrum_slicing_ratio', -1d0)

if (use_lanczos_dos_estimation) then
        write(7,*) 'use_lanczos_dos_estimation is on'
else
        write(7,*) 'use_lanczos_dos_estimation is off'
endif


if (spectrum_slicing) then
        write(7,*) 'Spectrum slicing is on'

#ifndef USE_SCALAPACK
        write(f_parsec,*) "use_spectrum_slicing is true, but PARSEC was not compiled with ScaLAPACK"
        write(f_parsec,*) "Spectrum slicing needs ScaLAPACK. Please compile PARSEC with WITH_SCALAPACK = 1"
        stop
#endif

        if (spectrum_slicing_ratio < 0d0) then
                write(f_parsec,*) 'spectrum_slicing_ratio is not used'
        elseif (spectrum_slicing_ratio < 1d0) then
                write(f_parsec,*) 'default spectrum_slicing_ratio will be used'
        else
                write(f_parsec,*) 'spectrum_slicing_ratio is ', spectrum_slicing_ratio
        endif

        if (use_krylov_subspace_method) then
                write(f_parsec,*) 'Use Krylov subspace method when doing spectrum slicing'
        else
                write(f_parsec,*) 'Use subspace iteration method when doing spectrum slicing'
                write(f_parsec,*) 'spectrum_slicing_cycles_early_quit is ', spectrum_slicing_cycles_early_quit
                write(f_parsec,*) 'Number of subspace iteration cycles for spectrum slicing is ', spectrum_slicing_max_cycles

                if (spectrum_slicing_max_cycles_first == -1) then
                        write(f_parsec,*) 'Number of subspace iteration cycles at the &
                                &first spectrum slicing SCF iteration will be &
                                &the same as spectrum_slicing_max_cycles'
                else
                        write(f_parsec,*) 'Number of subspace iteration cycles at the &
                                &first spectrum slicing SCF iteration is ', spectrum_slicing_max_cycles_first
                endif

                write(f_parsec,*) 'Number of iterations that still use CheFS after &
                        &the first iteration is ', num_of_iter_still_using_chebyshev

                write(f_parsec,*) 'Degree of the rectangular filters for the spectrum slicing method is ', polym_ss

                if (polym_first_ss_iter == -1) then
                        write(f_parsec,*) 'Degree of the rectangular filters for the &
                                &first spectrum slicing iteration will be the same as that for subspace iterations'
                else
                        write(f_parsec,*) 'Degree of the rectangular filters for the &
                                &first spectrum slicing iteration is ', polym_first_ss_iter
                endif

                write(f_parsec,*) 'num_of_copied_groups is', num_of_copied_groups
                write(f_parsec,*) 'num_of_slice1_filtering is', num_of_slice1_filtering
        endif

        write(f_parsec,*) 'Number of slices is ', nslices
else
        write(f_parsec,*) 'Spectrum slicing is off'
endif









write(f_parsec,*)

use_elpa = esdf_boolean('use_elpa', .false.)
elpa_block_size = esdf_integer('elpa_block_size', 8)

use_scalapack = esdf_boolean('use_scalapack', .false.)
scalapack_block_size = esdf_integer('scalapack_block_size', 8)


if (use_elpa) then
        write(f_parsec,*) "use_elpa is on"

#ifndef USE_ELPA
        write(f_parsec,*) "use_elpa is true, but PARSEC was not compiled with WITH_ELPA = 1"
        stop
#endif

        write(f_parsec,*) 'Block size used in ELPA routines is ', elpa_block_size
else
        write(f_parsec,*) 'use_elpa is off'
endif


if (use_scalapack) then
        write(f_parsec,*) "use_scalapack is on"
        write(f_parsec,*) "We will use ScaLAPACK and PBLAS in &
                &orthogonalization and Rayleigh-Ritz"
        write(f_parsec,*) 'Block size used in ScaLAPACK routines is ', &
                scalapack_block_size

#ifndef USE_SCALAPACK
        write(f_parsec,*) "use_scalapack is true, but PARSEC was not compiled with WITH_SCALAPACK = 1"
        stop
#endif

#ifndef MPI
        write(f_parsec,*) "Not compiled with MPI, but use_scalapack is on"
        stop
#endif

else
        write(f_parsec,*) 'use_scalapack is off'
endif


#ifdef USE_SCALAPACK
write(f_parsec,*) 'USE_SCALAPACK is defined'
#else
write(f_parsec,*) 'USE_SCALAPACK is not defined'
#endif





! ===============================================================
! Space-filling curve
! ===============================================================
write(f_parsec,*)

use_sfc = esdf_boolean('use_sfc', .true.)

write(f_parsec,*) 'use_sfc', use_sfc








fix_num_eig = esdf_boolean('fix_number_eigenvalues', .false.)

if (fix_num_eig) then
        write(f_parsec,*) 'Fixing the number of eigenvalues &
                &per representation'
        write(f_parsec,*) 'WARNING!! This option should only be used &
                &when restarting from previous SCF.'
endif

write(f_parsec,*)




do_subsp = esdf_boolean('chebyshev_filtering', .false.)
scaledcheb = esdf_boolean('chebyshev_scaled', .true.)
  
! always do subspace filtering at latter steps
if (solver_name == CHEBFF .or. solver_name == CHEBDAV) then
        do_subsp = .true.
endif
  
if (do_subsp) then
        use_smart_bound_in_subspace = esdf_boolean('smart_subspace', .true.)

        chebyshev_degree = esdf_integer('chebyshev_degree', 15)
        polym_t = chebyshev_degree

        if (scaledcheb) then
                write(f_parsec,*) 'Performing (EXPERIMENTAL) Scaled &
                        &Chebyshev subspace filtering'
        else
                write(f_parsec,*) 'Performing Chebyshev subspace filtering'
        endif

        if (use_smart_bound_in_subspace) then
                write(f_parsec,*) ''
                write(f_parsec,*) 'Using (EXPERIMENTAL) S.M.A.R.T &
                        &adaptive lower filter bound'
                write(f_parsec,*) ''
        endif

        write(f_parsec,'(a,1x,i5)') ' Polynomial degree for &
                &Chebyshev filtering is ', chebyshev_degree

        if (chebyshev_degree < 10) then
                itmp = 1
        else
                itmp = 3
        endif
        dpm = esdf_integer('chebyshev_degree_delta', itmp)

        write(f_parsec,'(a,1x,i5)') ' Change in polynomial degree (dpm) &
                &for Chebyshev filtering is ', dpm 
        write(f_parsec,*) 'Performing Rayleigh-Ritz rotation on &
                &all SCF iterations'
else
        write(f_parsec,*) 'No Chebyshev subspace filtering'
endif

write(f_parsec,*)











! read in value for convergence criterion and diagonalization tolerance
vconv = esdf_physical('convergence_criterion', 2.d-4, 'ry')

!dtmp = 100.d0 * vconv 
!AJB - nut sure about this, but it seems like vconv_approach should be lower than 100
!AJB2 - In fact, lets make it closer to vconv unless user wants it
!dtmp = 50.d0 * vconv 
dtmp = 2.d0*vconv 
vconv_approach = esdf_physical('convergence_criterion_approach', dtmp, 'ry')





use_plain_sre = esdf_boolean('use_plain_sre', .false.)

if (solver_name == CHEBFF) then
        ! KHL: If solver%toler is negative, run chefsi() max_iter times.
        !      If solver%toler is non-negative, run chefsi() until the 
        !         largest residual is less than solver%toler.
        !      For details, see chebff().
        dtmp = -1.d0
else
        dtmp = 1.d-4
endif
toler = esdf_double('diag_tolerance', dtmp)
  
! read in value for dynamic convergence tolerance
dyntol = esdf_boolean('dynamic_diag_tol', .false.)

! insert dynamic tolerance for faster convergence
if (dyntol) then
        if (restart_run) then
                dyntol = .false.

                write(f_parsec,*) 'dynamic tolerance is not working &
                        &with restart run!'
        else
                toler = 0.1d0

                write(f_parsec,*) 'YOU ARE USING DYNAMIC TOLERANCE &
                        &FOR CONVERGENCE'
        endif
endif
  
write(f_parsec,'(a,es11.4,a)') ' Self-consistency convergence &
        &criterion (vs. SRE) is ', vconv, ' Ry'
write(f_parsec,'(a,es11.4,a)') ' Self-consistency convergence &
        &indicator is at', vconv_approach, ' Ry'

write(f_parsec,'(a)') ' If applicable, Chebyshev polynomial order &
        &will decrease up to '
write(f_parsec,'(a)') ' 10 after SRE becomes less than the &
        &self-consistency convergence indicator.'

if (use_plain_sre) then
        write(f_parsec,'(a)') ''
        write(f_parsec,'(a)') '  Using the unweighted SRE for &
                &convergence checking'
        write(f_parsec,'(a)') ''
endif

write(f_parsec,*) ' Diagonalization tolerance is ', toler

maxmv = esdf_integer('maximum_matvec', 30000)









rritz_logic = esdf_string('rritz_logic', 'none')

select case(trim(rritz_logic))
case ('classic')
        write(f_parsec,*) 'Using rayleigh_ritz::classic'
        rritz_forced_logic = k_rritz_force_classic

case ('tiled')
        write(f_parsec,*) 'Using rayleigh_ritz::tiled'
        rritz_forced_logic = k_rritz_force_tiled

case ('dist1')

#ifndef WITH_ELPA
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: ELPA not linked. ', trim(rritz_logic), &
                ' not available'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 128
        return
#endif

        write(f_parsec,*) 'Using rayleigh_ritz::dist1'
        rritz_forced_logic = k_rritz_force_dist1

case ('dist2')

#ifndef WITH_ELPA
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: ELPA not linked. ', trim(rritz_logic), &
                ' not available'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 128
        return
#endif

        write(f_parsec,*) 'Using rayleigh_ritz::dist2'
        rritz_forced_logic = k_rritz_force_dist2

case ('distmixed')

#ifndef WITH_ELPA
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: ELPA not linked. ', trim(rritz_logic), &
                ' not available'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 128
        return
#endif

        write(f_parsec,*) 'Using rayleigh_ritz::dist*'
        rritz_forced_logic = k_rritz_force_distmixed

case ('custom')
        write(f_parsec,*) 'Using rayleigh_ritz::* - custom logic - variable!'
        rritz_forced_logic = k_rritz_force_custom

case ('none')
        write(f_parsec,*) 'Using default logic - based on problem'
        rritz_forced_logic = k_rritz_force_none

case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Unknown rritz logic type: ', &
                trim(rritz_logic)
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 128
        return
end select








bounds_method = esdf_string('bounds_method', 'lanczos')

select case(trim(bounds_method))
case ('static')
        solver_boundsmethod = k_bounds_static
case ('lanczos_full')
        solver_boundsmethod = k_bounds_lanczos_fullorth
case ('lanczos')
        solver_boundsmethod = k_bounds_lanczos
case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Unknown boundsmethod type: ', &
                trim(bounds_method)
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 129
        return
end select



num_lancz_bound = esdf_integer('bounds_iter', 10)



test_logic = esdf_string('test_logic', 'none')

select case(trim(test_logic))
case ('none')
        tests_logic = k_test_none
case ('forces')
        tests_logic = k_test_forces
case ('lanczos')
        tests_logic = k_test_lanczos
case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Unknown test_logic type: ', &
                trim(test_logic)
        write(f_parsec,*) 'STOP in ',__FILE__,':',__LINE__
        ierr = 130
        return
end select
















  
write(f_parsec,*)
write(f_parsec,*) 'Mixer data:'
write(f_parsec,*) '-----------'

mixer_scf_fail = .false.
  
! read in mixer type
mixing_method = esdf_reduce(esdf_string ('mixing_method', 'anderson'))
  
select case (trim(mixing_method))
case ('anderson')
        mixer_name = ANDERSON
case ('broyden')
        mixer_name = BROYDEN
case ('msecant1')
        mixer_name = MSECANT1
case ('msecant2')
        mixer_name = MSECANT2
case ('msecant3')
        mixer_name = MSECANT3
case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Unknown mixer type: ',trim(mixing_method)
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 128
        return
end select
  
mixer_memory = esdf_integer('memory_param', 4)
mixer_restart = esdf_integer('restart_mixing', 20)
mixer_param = esdf_double('mixing_param', 0.30d0)

lpole = esdf_integer('solver_lpole', 9)
write(f_parsec,*) 'solver lpole is : ', lpole
solver%hartree_rtol = esdf_double('hartree_cg_tolerance', 1.0d-13)
solver%hartree_test = esdf_integer('hartree_cg_criterion', 1)
if (solver%hartree_test /= 2) solver%hartree_test = 1
if (solver%hartree_test /= 1) write(f_parsec,*) &
        'Hartree CG test relative to the right-hand side'
if (solver%hartree_rtol /= 1.0d-13) write(f_parsec,*) &
        'Hartree CG relative tolerance : ', solver%hartree_rtol
  
solver%full_hartree_flag = esdf_boolean('full_hartree', .false.)
if (solver%full_hartree_flag) then
        write(f_parsec,*) 'Full hartree boundary conditions are used'
        grid%hartree_neibs_flag = .true.
else
        grid%hartree_neibs_flag = .false.
endif



mixer_group_size = esdf_integer('mixing_group_size', 1)
mixer_en_stage = esdf_integer ('mixing_en_like', 0)
mixer_restart_factor = esdf_double('mixing_restart_factor', 0.3d0)
mixer_expand_factor = esdf_double('mixing_memory_expand_factor', 2.0d0)

! Preferred type of update, used by hybrid methods implemented in
! msecant3.f90.
mixer_preferred_type = esdf_integer('mixing_preferred_type', 1)

! Maximum memory parameter, mixer%block > mixer%memory+1
mixer_block = 20
  
if (mixer_name == ANDERSON) then
        ! read mixing parameter (Anderson mixer)
        write(f_parsec,*) 'Anderson mixer'
        write(f_parsec,'(a,f6.3,a,i2)') ' Initial Jacobian: ', &
                mixer_param, '  Mixing memory is ', mixer_memory
        write(f_parsec,*) 'Mixing restarted after ', &
                mixer_restart,' iterations'
  
elseif (mixer_name == BROYDEN) then
        write(f_parsec,*) ' Generalized Broyden mixer'

        if (mixer_memory+1 > mixer_block) then
                write(f_parsec,*)
                write(f_parsec,*) 'Warning: insufficient memory for mixing.'
                write(f_parsec,*) '  now reset mixer%block to ', &
                        mixer_memory+1

                mixer_block = mixer_memory + 1
        endif

        write(f_parsec,'(a,f6.3,a,i2)') ' Initial Jacobian: ', &
                mixer_param, '  Mixing memory is ', mixer_memory

        write(f_parsec,*) 'Mixing restarted after ', &
                mixer_restart, ' iterations'
  
elseif (mixer_name == MSECANT1 .or. mixer_name == MSECANT2) then
        if (mixer_name == MSECANT1) then
                if (mixer_en_stage == 0) then
                        write(f_parsec,*) 'Multisecant method, &
                                &Broyden-like Type-I update'
                else
                        write(f_parsec,*) 'Multisecant method, &
                                &EN-like Type-I update'
                endif

        elseif (mixer_en_stage == 0) then
                write(f_parsec,*) 'Multisecant method, &
                        &Broyden-like Type-II update'
        else
                write(f_parsec,*) 'Multisecant method, EN-like Type-II update'
        endif

        if (mixer_group_size == 0) then
                write(f_parsec,'(a,f6.3,a,i2)') &
                        ' Mixing parameter: ', mixer_param, &
                        '  All secant equations taken into account &
                        &in one group'
        else
                write(f_parsec,'(a,f6.3,a,i2)') &
                        ' Mixing parameter: ', mixer_param, &
                        '  Group size of secant equations: ', &
                        mixer_group_size
        endif

        write(f_parsec,'(a,f6.3)') &
                ' Restarting factor is: ', mixer_restart_factor
  
elseif (mixer_name == MSECANT3) then
        if (mixer_en_stage == 0) then
                write(f_parsec,*) 'Multisecant method, &
                        &Broyden-like hybrid update'
        else
                write(f_parsec,*) 'Multisecant method, EN-like hybrid update'
        endif

        if (mixer_preferred_type == 1) then
                write(f_parsec,*) 'Preferred type of update is Type-I'
        else
                write(f_parsec,*) 'Preferred type of update is Type-II'
        endif

        write(f_parsec,'(a,f6.3,a,i2)') &
                ' Mixing parameter: ', mixer_param, &
                '  Group size of secant equations: ', mixer_group_size
        write(f_parsec,'(a,f6.3)') &
                ' Restarting factor is: ', mixer_restart_factor
endif

write(f_parsec,*)











write(f_parsec,*) 'Atom data:'
write(f_parsec,*) '--~--~--~-'

! read in and write number of atom types
naty = esdf_integer('atom_types_num', 0)

if (naty == 0) then
        write(f_parsec,*) 'ERROR: unknown number of atom types. '
        write(f_parsec,*) ' Input line "atom_types_num" not found!'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 130
        return
endif

write(f_parsec,'(/,a,i5,/)') ' Tot. # of atom types is ', naty













coordinate_unit = esdf_reduce( &
        esdf_string('coordinate_unit', 'cartesian_bohr') )

! cscale : for periodic systems, hold unit lattice vectors in
! column-wise form

cscale(:,:) = dzero
  
select case (trim(coordinate_unit))
case ('cartesian_bohr')
        write(f_parsec,*) 'Atom coordinates input in Bohr radii'

        do i = 1, 3
                cscale(i,i) = done
        enddo

case ('cartesian_ang')
        write(f_parsec,*) 'Atom coordinates input in angstroms'

        do i = 1, 3
                cscale(i,i) = done/angs
        enddo

case ('lattice_vectors')
        write(f_parsec,*) 'Atom coordinates input in lattice vector units'

        if (.not. pbc_is_on) then
                write(f_parsec,*) ' ERROR: this is not a periodic system'
                write(f_parsec,*) ' Lattice vectors not defined. STOP.'
                ierr = 131
                return
        endif

        cscale(:,:) = lattvec(:,:)

        do i = pbc_per+1, 3
                write(f_parsec,*) ' Warning, lattice_vectors flag &
                        &does NOT affect coordinates on &
                        &non-periodic direction', i

                cscale(i,i) = done
        enddo

case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: unknown coordinate_unit: ', &
                trim(coordinate_unit)
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 132
        return
end select

write(f_parsec,*)
  




allocate(tmove(maxatm))
allocate(atom_coord(3,maxatm))
allocate(atype(maxatm))
 

allocate(clust_natmi(naty))
clust_natmi(:) = 0
allocate(clust_name(naty))
clust_name(:) = ''
allocate(clust_ppfile(naty))
clust_ppfile(:) = ''
allocate(clust_ylmdos_cutoff(naty))
clust_ylmdos_cutoff(:) = dzero

allocate(nonlinear_core_correction(naty))

allocate(local_component(naty))
local_component(:) = ''
allocate(move_flag(naty))
move_flag(:) = 0

allocate(pseudopotential_format(naty))
allocate(p_pot_format(naty))
allocate(p_pot_rcore(naty))
allocate(p_pot_nlocp(naty))
p_pot_nlocp(:) = 0
allocate(p_pot_loc(naty))
allocate(p_pot_eleatm(naty,4))
p_pot_eleatm(:,:) = dzero
allocate(p_pot_spol(naty))
allocate(p_pot_icore(naty))
allocate(p_pot_alpha(naty))
allocate(p_pot_beta1(naty))
allocate(p_pot_acore(naty))
allocate(p_pot_uspline(naty))
allocate(p_pot_uu(4,naty))
allocate(p_pot_jj(4,naty))
allocate(p_pot_so(naty))
allocate(p_pot_rvcd(naty))



allocate(p_pot_rws(naty))
p_pot_rws(:) = dzero




















! read in minimization data
minimization = esdf_reduce( esdf_string('minimization', 'none') )

select case (trim(minimization))
case ('none')
        move_name = OPTNONE
case ('simple')
        move_name = STEEPDESC

        write(f_parsec,*) 'WARNING - simple steepest descent &
                &is not recommended'
        write(f_parsec,*) 'WARNING - relaxation method will probably &
                &not work!'
case ('bfgs')
        move_name = BFGS
case ('manual')
        move_name = MANUAL
case default
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: unknown minimization method: ', &
                trim(minimization)
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 133
        return
end select













! For each atom type:
natom = 0

do ity = 1, naty
        ! read name and core cutoff
        clust_name(ity) = esdf_string('atom_type', string_default)

        write(f_parsec,'(/,a,a)') ' Chemical element : ', &
                trim(clust_name(ity))
  
        pseudopotential_format(ity) = esdf_reduce( &
                esdf_string('pseudopotential_format','martins_new'))

        write(f_parsec,*) trim(pseudopotential_format(ity))
  
        select case (trim(pseudopotential_format(ity)))
        case ('martins_old')
                p_pot_format(ity) = MARTINS_OLD
                write(f_parsec,*) ' pseudopotential format : old Martins'
                default_ppfile = trim(clust_name(ity))//'_POTR.DAT'
        case ('martins_new')
                p_pot_format(ity) = MARTINS_NEW
                write(f_parsec,*) ' pseudopotential format : new Martins'
                default_ppfile = trim(clust_name(ity))//'_POTRE.DAT'
        case ('martins_wang')
                p_pot_format(ity) = MARTINS_WANG
                write(f_parsec,*) ' pseudopotential format : Martins-Wang'
                default_ppfile = trim(clust_name(ity))//'_POTRW.DAT'
        case ('fhipp')
                p_pot_format(ity) = FHIPP
                write(f_parsec,*) ' pseudopotential format : FHIPP'
                default_ppfile = trim(clust_name(ity))//'_FHIPP.DAT'
        case default
                write(f_parsec,*) ' Unknown pseudopotential format :', &
                        trim(pseudopotential_format(ity))
                ierr = 134
                return
        end select
  
        ! read pseudopotential file path
        clust_ppfile(ity) = esdf_string ('pseudopot_file', default_ppfile)

        write(f_parsec,'(/,a,a)') ' Pseudopotential file : ', &
                trim(clust_ppfile(ity))
  
        ! does this atom type have spin-orbit psp?
        p_pot_so(ity) = esdf_boolean('so_psp', .false.)

        if (p_pot_format(ity) == FHIPP .and. p_pot_so(ity)) then
                write(f_parsec,*) ' ERROR: FHIPP pseudopotential is &
                        &input for atom type ', clust_name(ity), &
                        ' and spin-orbit is enabled for this atom. &
                        &But FHIPP does not have support for &
                        &spin-orbit potentials! STOP'
                ierr = 135
                return
        endif
  
        ! should the valence charge be read from psp for this atom type?
        p_pot_rvcd(ity) = esdf_boolean('read_vcd', .false.)

        if (p_pot_format(ity) /= MARTINS_NEW .and. p_pot_rvcd(ity)) then
                write(f_parsec,*) ' ERROR: check the type of &
                        &pseudopotential    '
                write(f_parsec,*) ' atom type ', clust_name(ity)
                write(f_parsec,*) ' Can not read valence charge density &
                        &from file'
                ierr = 234
                return
        endif
  
        ! Local component, read for all formats except Martins-Wang
        if ( p_pot_format(ity) /= MARTINS_WANG ) then
                local_component(ity) = esdf_reduce( &
                        esdf_string('local_component', string_default) )
  
                if (local_component(ity) == 's') then
                        p_pot_loc(ity) = 1
                elseif (local_component(ity) == 'p') then
                        p_pot_loc(ity) = 2
                elseif (local_component(ity) == 'd') then
                        p_pot_loc(ity) = 3
                elseif (local_component(ity) == 'f') then
                        p_pot_loc(ity) = 4
                else
                        write(f_parsec,*)
                        write(f_parsec,*) 'ERROR: problem with atom type', ity
                        write(f_parsec,*) 'Impossible local pseudopotential'
                        write(f_parsec,*) 'Must be s, p, d, or f'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 136
                        return
                endif
        endif
        !
        ! Other parameters for this atom type: core cut-off radius,
        ! number of psp channels, number of electrons per pseudo-orbital.
        ! Read for formats Martins_old and FHIPP only.
        !
        if ( (p_pot_format(ity) == MARTINS_OLD) .or. &
             (p_pot_format(ity) == FHIPP) ) then

                p_pot_nlocp(ity) = esdf_integer('potential_num', 0)
        endif

        if ( (p_pot_format(ity) == MARTINS_OLD) .or. &
             (p_pot_format(ity) == MARTINS_WANG) .or. &
             (p_pot_format(ity) == FHIPP) ) then

                p_pot_rcore(ity) = esdf_physical('core_cutoff_radius', &
                        dzero, 'bohr')
        endif

        if ( (p_pot_format(ity) == MARTINS_OLD) .or. &
             (p_pot_format(ity) == FHIPP) ) then

                if (esdf_block('electron_per_orbital', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*) 'ERROR: there should &
                                        &be only one line '
                                write(f_parsec,*) 'in the &
                                        &"electron_per_orbital" block'
                                write(f_parsec,*) 'STOP in usrinput'
                                ierr = 137
                                return
                        endif

                        read(block_data(nlines),*) &
                                (p_pot_eleatm(ity,itmp), &
                                itmp=1,p_pot_nlocp(ity))
                else
                        write(f_parsec,*) 'Cannot find &
                                &#electrons/orbital block'
                endif
        endif
        !
        ! FHIPP format also need the non-linear core correction flag to
        ! be specified.
        !
        if ( p_pot_format(ity) == FHIPP ) then
                nonlinear_core_correction(ity) = &
                        esdf_boolean('nonlinear_core_correction', .false.)

                if (nonlinear_core_correction(ity)) then
                        p_pot_icore(ity) = 1
                else
                        p_pot_icore(ity) = 0
                endif
        endif
        !
        ! Test sanity of pseudopotential parameters.
        ! Martins_old and FHIPP formats only.
        !
        if ( (p_pot_format(ity) == MARTINS_OLD) .or. &
             (p_pot_format(ity) == FHIPP) ) then

                if ( (p_pot_nlocp(ity) <= 0) .or. &
                     (p_pot_nlocp(ity) > 4)) then

                        write(f_parsec,*)
                        write(f_parsec,*) 'ERROR: problem with atom type', ity
                        write(f_parsec,*) 'impossible number of &
                                &potentials! ', p_pot_nlocp(ity)
                        write(f_parsec,*) 'STOP in usrinput.'
                        ierr = 138
                        return
                endif

                if (p_pot_loc(ity) > p_pot_nlocp(ity)) then
                        write(f_parsec,*)
                        write(f_parsec,*) 'ERROR: problem with atom type', ity
                        write(f_parsec,*) 'local pseudopot. &
                                &beyond # of components'
                        write(f_parsec,*) 'STOP in usrinput.'
                        ierr = 139
                        return
                endif
        endif

        ! read initial spin polarization; this is used only in spin-polarized
        ! calculations and when not restating from previous charge density.
        p_pot_spol(ity) = esdf_double('initial_spin_polarization', 0.1d0)

        ! this is now only available for pbc
        if (pbc_is_on) then
                ! read parameters for Fourier filtering of 
                ! pseudopotentials and core charge (if it exists)
                p_pot_alpha(ity) = esdf_double('alpha_filter', dzero)
                p_pot_beta1(ity) = esdf_double('beta1_filter', dzero)
                p_pot_acore(ity) = &
                        esdf_double('core_filter', p_pot_alpha(ity))
        endif

        ! Use cubic spline interpolation for pseudopotentials?
        p_pot_uspline(ity) = esdf_boolean('cubic_spline', .false.)

        ! read number of atoms of this type
        move_flag(ity) = esdf_integer('move_flag', 0)

        clust_ylmdos_cutoff(ity) = &
                esdf_physical('ylm_dos_cutoff', one, 'bohr')

        ! read their coordinates
        if (esdf_block('atom_coord', clust_natmi(ity))) then   
                if (move_flag(ity) > clust_natmi(ity)) then
                        write(f_parsec,*)
                        write(f_parsec,*) &
                                'ERROR: invalid move_flag value: ', &
                                move_flag(ity)
                        write(f_parsec,*) 'STOP in usrinput.'
                        ierr = 140
                        return
                endif

                i = supercell(1)*supercell(2)*supercell(3)

                write(f_parsec,12) clust_natmi(ity)*i, clust_name(ity)
                write(f_parsec,*) 'and their initial coordinates are:'
                write(f_parsec,*)
                write(f_parsec,16)
  
                do i = 1, clust_natmi(ity)
                        natom = natom + 1
                        atype(natom) = ity

                        if (natom > maxatm) then
                                write(f_parsec,*) ' ERROR: too many &
                                        &atoms in input! ', &
                                        natom, maxatm, &
                                        ' Increase maxatm in usrinput. '
                                ierr = 141
                                return
                        endif

                        if (move_flag(ity) == 0) then
                                read(block_data(i),*) atom_coord(:,natom)
                                tmove(natom) = 1
                        elseif (move_flag(ity) > 0) then
                                read(block_data(i),*) atom_coord(:,natom)

                                if (i <= move_flag(ity)) then 
                                        tmove(natom) = 1
                                else
                                        tmove(natom) = 0
                                endif
                        else
                                if ( (move_name == OPTNONE) .and. &
                                     (.not. md_is_on) ) then

                                        read(block_data(i),*) &
                                                atom_coord(:,natom)
                                        tmove(natom) = 1
                                else
                                        read(block_data(i),*) &
                                                atom_coord(:,natom), &
                                                tmove(natom)
                                endif

                                if ( (tmove(natom) /= 0) .and. &
                                     (tmove(natom) /= 1) ) then
                                        write(f_parsec,*)
                                        write(f_parsec,*) &
                                                'ERROR: invalid atom &
                                                &movement index: ', &
                                                tmove(natom)
                                        write(f_parsec,*) 'STOP in usrinput'
                                        ierr = 142
                                        return
                                endif
                        endif

                        call matvec3('N', cscale(:,:), &
                                atom_coord(:,natom), vtmp(:))

                        ! If multiple periodic cells are defined 
                        ! in a super-cell, augment number of atoms.
                        if (supercell(1)*supercell(2)*supercell(3) /= 1) then
                                jj = tmove(natom)
                                natom = natom - 1

                                select case(pbc_per)
                                case(1)
                                        do i1 = 0, supercell(1)-1
                                                natom = natom + 1
atom_coord(:,natom) = vtmp(:) + real(i1,dp)*lattvec(:,1)
                                                tmove(natom) = jj

                                                write(f_parsec,18) &
                                                        atom_coord(:,natom), &
                                                        tmove(natom)
                                        enddo
                                case(2)
                                        do i1 = 0, supercell(1)-1
                                        do i2 = 0, supercell(2)-1
                                                natom = natom + 1
atom_coord(:,natom) = vtmp(:) + &
        real(i1,dp)*lattvec(:,1) + &
        real(i2,dp)*lattvec(:,2)
                                                tmove(natom) = jj

                                                write(f_parsec,18) &
                                                        atom_coord(:,natom), &
                                                        tmove(natom)
                                        enddo
                                        enddo
                                case(3)
                                        do i1 = 0, supercell(1)-1
                                        do i2 = 0, supercell(2)-1
                                        do i3 = 0, supercell(3)-1
                                                natom = natom + 1
atom_coord(:,natom) = vtmp(:) + &
        real(i1,dp)*lattvec(:,1) + &
        real(i2,dp)*lattvec(:,2) + &
        real(i3,dp)*lattvec(:,3)
                                                tmove(natom) = jj

                                                write(f_parsec,18) &
                                                        atom_coord(:,natom), &
                                                        tmove(natom)
                                        enddo
                                        enddo
                                        enddo
                                end select
                        else
                                atom_coord(:,natom) = vtmp(:)
                                write(f_parsec,18) &
                                        atom_coord(:,natom), tmove(natom)
                        endif
                enddo

                clust_natmi(ity) = clust_natmi(ity)* &
                        supercell(1)*supercell(2)*supercell(3)
        else
                write(f_parsec,*) 'ERROR: no atom coordinates were found'
                write(f_parsec,*) 'for atom type ', clust_name(ity)
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 143
                return
        endif


        ! read parameters for the LDA+U (if applicable)
        ! assume LDA+U only for d channel (lp1 = 3)
        p_pot_uu(:,ity) = dzero
        p_pot_jj(:,ity) = dzero
        p_pot_uu(3,ity) = esdf_physical('ldaplusu_u', dzero, 'ry')
        p_pot_jj(3,ity) = esdf_physical('ldaplusu_j', dzero, 'ry')

        if ( (abs(p_pot_uu(3,ity)) > twomach_eps) .or. &
             (abs(p_pot_jj(3,ity)) > twomach_eps) ) then

                write(f_parsec,'(/,a,f10.3,a,f10.3,a)') &
                        ' LDA+U parameters : U = ', &
                        p_pot_uu(3,ity)*rydberg, ' eV   J = ', &
                        p_pot_jj(3,ity)*rydberg, ' eV'
        endif


        p_pot_rws(ity) = esdf_double('atomic_radius', dzero)

enddo  !do ity = 1,naty
12 format(1x,'There are ',i6,1x,a2,1x,'atoms')
16 format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]',5x,'movable?')
18 format(3(f15.9,3x),3x,i1)







! Does any chemical element have spin-orbit?
p_pot_is_so = .false.

do ity = 1, naty
        if (p_pot_so(ity)) p_pot_is_so = .true.
enddo

p_pot_so_hcub = dzero

if (p_pot_is_so) then
        !AJB: please explain why hcub==sqrt(hcub)
        p_pot_so_hcub = sqrt(h**3)

        write(f_parsec,'(a,/)') '  Spin-Orbit corrected computation!'

        if (pbc_per > 0) then
                write(f_parsec,'(a,/)') '  WARNING: I have used the input &
                        &grid parameter to setup parameters for SO, &
                        &but the actual grid parameter COULD be &
                        &modified by PARSEC below'
        endif
endif




so_start = .false.

! read spin-orbit flag for scf (default is perturbation theory)
scf_so = esdf_boolean('scf_so', .false.)

if (scf_so) then
        write(f_parsec,'(A,/)') ' Self-Consistent Spin-Orbit Correction!'
endif
  



! read spin-orbit flag for spinor representation from scratch
ncl = esdf_boolean('non_collinear_magnetism', .false.)

if (ncl) then
        nspin = 2
        mxwd = 2
        cplx_wfn = .true.

        write(f_parsec,'(A,/)') 'Performing Non-Collinear Clculation!'

        if (scf_so .or. p_pot_is_so) then
                so_start = .true.
        endif

        allocate(initmag(3,maxatm))
        initmag(:,:) = dzero

        natom = 0
        do ity = 1, naty
                if (esdf_block('initial_ncl_moment', clust_natmi(ity))) then
                        do i = 1, clust_natmi(ity)
                                natom = natom + 1
                                read(block_data(i),*) initmag(:,natom)
                                tmp = sqrt(dot_product( &
                                        initmag(:,natom), initmag(:,natom)))
                                initmag(:,natom) = initmag(:,natom)/tmp
                        enddo
                endif
        enddo
endif








! read spin-orbit flag for spinor representation from scratch
so_start = esdf_boolean('so_from_scratch', so_start)

if (so_start) then
        cplx_wfn = .true.
        nspin = 2
        scf_so = .true.
        mxwd = 2
        elec_st_is_so = .true.

        write(f_parsec,'(a,/)') 'Starting Self-Consistent &
                &Spin-Orbit Clculation!'
else
        if (.not. ncl) mxwd = 1

        ! AJB: Nowhere in the code is elec_st%is_so set to false 
        ! so I put it here for now
        elec_st_is_so = .false.
endif
  
nstate = nstate*mxwd













! Make sure there are atoms with spin-orbit if p_pot%is_so = .true.
if (p_pot_is_so) then
        lflag = .false.

        do ity = 1, naty
                if (p_pot_so(ity)) lflag = .true.
        enddo

        if (.not. lflag) then
                write(f_parsec,*) ' WARNING: spin-orbit interaction &
                        &is enabled but there are no atom types with &
                        &spin-orbit potential'
                p_pot_is_so = .false.
        endif
endif





if (naty > 0) then
        write(f_parsec,'(/,a,i7,/)') ' Tot. number of atoms = ', &
                sum(clust_natmi(:))
endif



recenter_atoms_in_aperiodic_directions = &
        esdf_boolean('recenter_atoms_in_aperiodic_directions', .true.)
if (.not. recenter_atoms_in_aperiodic_directions) then
        write(f_parsec,*) 'WARNING: recenter_atoms_in_aperiodic_directions &
                &is off. Need to check the sum of electrons from atomic &
                &density'
endif


! read in point charge flag
has_ptchrg = esdf_boolean('add_point_charges', .false.)

!  read in and write number of atom types
npttyp = esdf_integer('point_typ_num', 0)

  
if (has_ptchrg) then
        if (pbc_is_on) then
                write(f_parsec,*) 'ERROR: support for point charges &
                        &is only available in'
                write(f_parsec,*) 'non-periodic systems. STOP in usrinput'
                ierr = 145
                return
        endif

        allocate(ptchrg_coord(3,maxatm))

        write(f_parsec,*) 'Point Charge data:'
        write(f_parsec,*) '------------------'

        if (npttyp == 0) then
                write(f_parsec,*) 'ERROR: unknown number of point &
                        &charge types. '
                write(f_parsec,*) ' Input line "Point_Typ_Num" not found!'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 146
                return
        endif

        write(f_parsec,*) 'Tot. # of point charge types is ', npttyp

        allocate(clust_nptt(npttyp))
        allocate(clust_qpt(npttyp))
  
        ! For each point charge type:
        nptchrg = 0
        do ipttyp = 1, npttyp
                ! read amount of charge per type
                clust_qpt(ipttyp) = &
                        esdf_physical('pt_chg', dzero, 'e')

                ! read coordinates
                if (esdf_block('point_coord', clust_nptt(ipttyp))) then
                        write(f_parsec,22) &
                                clust_nptt(ipttyp), clust_qpt(ipttyp)
                        write(f_parsec,*) 'and their coordinates are:'
                        write(f_parsec,*)
                        write(f_parsec,26)

                        do i = 1, clust_nptt(ipttyp)
                                nptchrg = nptchrg + 1

                                if (nptchrg > maxatm) then
                                        write(f_parsec,*) &
                                                'ERROR: too many point &
                                                &charges in input! &
                                                &Increase maxatm in &
                                                &usrinputfile. '
                                        ierr = 147
                                        return
                                endif

                                read(block_data(i),*) &
                                        ptchrg_coord(:,nptchrg)

                                call matvec3('N', cscale(:,:), &
                                        ptchrg_coord(:,nptchrg), vtmp(:))

                                ptchrg_coord(:,nptchrg) = vtmp(:)

                                write(f_parsec,18) ptchrg_coord(:,nptchrg)
                        enddo
                else
                        write(f_parsec,*) 'ERROR: no point charge &
                                &coordinates were found'
                        write(f_parsec,*) 'for point charge type ', ipttyp
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 148
                        return
                endif
        enddo
  
22 format(1x,'There are',1x,i4,1x,'point charges with charge ',f5.2,' e')
26 format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]')

        clust_nptchrg = nptchrg
  
        write(f_parsec,*)
        write(f_parsec,'(a,i4,/)') &
                ' Tot. number of point charges = ', clust_nptchrg
endif ! end point charges












! read in charged sheet flag
has_charged_sheet = esdf_boolean('add_charged_sheets', .false.)

!  read in and write number of charged sheet types
number_charged_sheet_type = &
       esdf_integer('num_charged_sheets', 0)
  
if (has_charged_sheet) then
        if (pbc_per /= 2) then
                write(f_parsec,*) 'ERROR: support for charged sheets &
                        &is only available in'
                write(f_parsec,*) '2-D (slab) systems. STOP in usrinput'
                ierr = 145 !TODO: choose a different error number
                return
        endif

        allocate(sheetchrg_coord(3,maxatm))

        write(f_parsec,*) 'Charged sheet data:'
        write(f_parsec,*) '------------------'


        if (number_charged_sheet_type == 0) then
                write(f_parsec,*) &
                        'ERROR: unknown number of charged sheets. '
                write(f_parsec,*) &
                        ' Input line "num_charged_sheets" not found!'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 146 !TODO: choose a different error number
                return
        endif

        write(f_parsec,*) 'Tot. # of charged sheets is ', &
                number_charged_sheet_type

        allocate(clust_number_charged_sheets_per_type( &
                number_charged_sheet_type))
        allocate(clust_sheet_charge_of_type(number_charged_sheet_type))

        ! For each charged sheet type:
        number_charged_sheets = 0
        do icharged_sheet_type = 1, number_charged_sheet_type
                ! read amount of charge per type
                clust_sheet_charge_of_type(icharged_sheet_type) = &
                        esdf_physical('sheet_charge', dzero, 'e')

                ! read coordinates
                if (esdf_block('sheet_coord', &
                        clust_number_charged_sheets_per_type( &
                        icharged_sheet_type))) then

                        write(f_parsec,10022) &
                                clust_number_charged_sheets_per_type(&
                                icharged_sheet_type), &
                                clust_sheet_charge_of_type( &
                                icharged_sheet_type)

                        write(f_parsec,*) 'and their coordinates are:'
                        write(f_parsec,*)
                        write(f_parsec,10026)

                        do i = 1, &
                                clust_number_charged_sheets_per_type( &
                                icharged_sheet_type)

                                number_charged_sheets = &
                                        number_charged_sheets + 1

                                if (number_charged_sheets > maxatm) then
                                        write(f_parsec,*) &
                                                'ERROR: too many charged &
                                                &sheets in input! Increase &
                                                &maxatm in usrinputfile. '
                                                ierr = 147 !TODO choose a different error number 
                                        return
                                endif

                                read(block_data(i),*) &
                                        sheetchrg_coord(:, &
                                        number_charged_sheets)

                                call matvec3('N', cscale(:,:), &
                                        sheetchrg_coord(:, &
                                        number_charged_sheets), vtmp(:))

                                sheetchrg_coord(:,number_charged_sheets) = &
                                        vtmp(:)

                                write(f_parsec,18) &
                                        sheetchrg_coord(:, &
                                        number_charged_sheets)
                        enddo
                else
                        write(f_parsec,*) 'ERROR: no charged sheet &
                                &coordinates were found'
                        write(f_parsec,*) 'for sheet charge number: ', &
                                icharged_sheet_type
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 148 !TODO choose a different error number
                        return
                endif
        enddo
 
10022 format(1x,'There are',1x,i4,1x,'charged sheets with charge ',f5.2,' e')
10026 format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]')
 
        write(f_parsec,*)
        write(f_parsec,'(a,i4,/)') ' Tot. number of charged sheets = ', &
                number_charged_sheets
endif ! end charged sheets








! Read in spin polarization flag.
spin_polarization = esdf_boolean('spin_polarization', .false.)
if (spin_polarization) then
        nspin = 2
else
        nspin = 1
endif












use_libxc = esdf_boolean('use_libxc', .false.)

#ifndef USE_LIBXC
if (use_libxc) then
        write(f_parsec,*) "use_libxc is true, but PARSEC wasn't &
                &compiled with -DUSE_LIBXC"
        use_libxc = .false. 
endif
#endif


! read the functional, for now recognise only functional id, 
! later will add string input.
! default = 1 = lda_x, might want to change that
func_id(1) = esdf_integer('func_id_x', -1)
func_id(2) = esdf_integer('func_id_c', -1)

correlation_type = esdf_reduce(esdf_string('correlation_type', 'xx'))

! read-in the ionization energy difference (actually used 
! only with 'cs' corr.)
dioniz = esdf_physical('ion_energy_diff', dzero, 'ry')

if (use_libxc) then

#ifdef USE_LIBXC

        call xc_f03_version(vmajor, vminor, vmicro)
        write(f_parsec,'("you are using Libxc version: ",I1,".",I1,".",I1)') &
                vmajor, vminor, vmicro
        write(f_parsec,*) 'XC functional data:'
        write(f_parsec,*) '-----------------'

        if (func_id(1) == -1) then
                ! lda_x
                func_id(1) = 1
        endif

        if (func_id(2) == -1) then
                if (nspin == 2) then
                        ! PWLDA
                        func_id(2) = 12
                else
                        ! PZLDA
                        func_id(2) = 9
                endif
        endif

        do ifunc = 1, 2
                if (func_id(ifunc) /= 0) then
                        call xc_f03_func_init(xc_func, func_id(ifunc), nspin)

                        xc_info = xc_f03_func_get_info(xc_func)

                        select case(xc_f03_func_info_get_kind(xc_info))
                        case (XC_EXCHANGE)
                                write(func,'(a)') 'an exchange functional'
                        case (XC_CORRELATION)
                                write(func,'(a)') 'a correlation functional'
                        case (XC_EXCHANGE_CORRELATION)
                                write(func,'(a)') &
                                        'an exchange-correlation functional'
                        case (XC_KINETIC)
                                write(func,'(a)') &
                                        'a kinetic energy functional'
                        case default
                                write(func,'(a)') 'of unknown kind'
                        end select

                        select case (xc_f03_func_info_get_family(xc_info))
                        case (XC_FAMILY_LDA);
                                write(family,'(a)') "LDA"
                        case (XC_FAMILY_GGA);
                                write(family,'(a)') "GGA"
                        case (XC_FAMILY_HYB_GGA);
                                write(family,'(a)') "Hybrid GGA"
                        case (XC_FAMILY_MGGA);
                                write(family,'(a)') "MGGA"
                        case (XC_FAMILY_HYB_MGGA);
                                write(family,'(a)') "Hybrid MGGA"
                        case default;
                                write(family,'(a)') "unknown"
                        end select

                        write(f_parsec, &
                                '("The functional ''", a, "'' is ", a, ", &
                                &it belongs to the ''", a, "'' family and &
                                &is defined in the reference(s):")') &
                                trim(xc_f03_func_info_get_name(xc_info)), &
                                trim(func), trim(family)

                        i = 0
                        do while(i >= 0)
                                write(f_parsec,'(a,i1,2a)') &
                                        '[', i+1, '] ', &
                                        trim(xc_f03_func_reference_get_ref( &
                                        xc_f03_func_info_get_references(&
                                        xc_info,i)))
                        enddo
                endif
        enddo

#endif

else
        ! go to the parsec implemented functionals
        ! Read in correlation type. Default spin-polarized functional is
        ! LSDA Perdew-Wang. Default non-spin-polarized functional is
        ! LDA Perdew-Zunger.
 
        write(f_parsec,*) 'Correlation data:'
        write(f_parsec,*) '-----------------'


        if (trim(correlation_type) == 'xx') then
                if (nspin == 2) then
                        correlation_type = 'pl'
                else
                        correlation_type = 'ca'
                endif
        endif
 
        select case (trim(correlation_type))
        case ('xa')
                icorr = 'xa'
                write(f_parsec,20) icorr, 'LDA, Slater x-alpha'
        case ('wi')
                icorr = 'wi'
                write(f_parsec,20) icorr, 'LDA, Wigner interpolation'
        case ('hl')
                icorr = 'hl'
                write(f_parsec,20) icorr, 'LDA, Hedin-Lundqvist'
        case ('ca','pz','lda')
                icorr = 'ca'
                write(f_parsec,20) icorr, 'LDA, Ceperley-Alder, &
                        &Perdew-Zunger parametrization'
        case ('pl','pw92','pwlda')
                icorr = 'pl'
                write(f_parsec,20) icorr, 'LDA, Perdew-Wang parametrization'
        case ('pw','pw91','pwgga')
                icorr = 'pw'
                write(f_parsec,20) icorr, 'GGA, Perdew-Wang parametrization'
        case ('pb','pbe')
                icorr = 'pb'
                write(f_parsec,20) icorr, 'GGA, Perdew-Burke-Ernzerhof &
                        &parametrization'
             case ('wb')
                icorr = 'wb'
                write(f_parsec,20) icorr,'GGA, Perdew-Burke-Ernzerhof &
                     &parametrization'
                write(f_parsec,20) icorr, 'with a numerical Vxc derivation &
                     &(white and Bird 1994).'
             case ('lb')
                icorr = 'lb'
                write(f_parsec,20) icorr, 'ACLDA, Leeuwen-Baerends correction'
        case ('cs')
                icorr = 'cs'
                write(f_parsec,20) icorr, 'ACLDA, Casida-Salahub correction'

                write(f_parsec,'(a,f7.4,a)') ' Ionization energy &
                        &difference is: ', dioniz, ' Ry'
        case default
                write(f_parsec,*)
                write(f_parsec,*) 'ERROR: unknown correlation type:', &
                        trim(correlation_type)
                write(f_parsec,*) 'STOP in usrinput.'
                ierr = 149
                return
        end select

        write(f_parsec,*) 
endif

20 format(1x,'Exchange-Correlation functional is',1x,a2,/,1x,a)














!!! VDW PART
do_vdw = esdf_boolean('van_der_waals', .false.)

hirsh_cell_total(:,:) = 0

if (do_vdw) then
        write(f_parsec,*) &
                'including Tkatchenko-Scheffler dispersion correction!'

        if ( (icorr /= 'pb') .or. use_libxc ) then
                write(f_parsec,*) 'Error, the TS correction implemented &
                        &only for GGA-PBE functional!'
                ierr = 158
                return
        endif

        if (.not. ignoresym) then
                write(f_parsec,*) 'Error, for the TS correction &
                        &symmetry has to be switched off'
                ierr = 159
                return
        endif

        if (pbc_is_on) then
                if (pbc_per /= 3) then
                        write(f_parsec,*)'Error, in this version &
                                &the TS correction implemented only &
                                &for 3D periodic boundary conditions (sorry)'
                        ierr = 160
                        return
                endif

                write(f_parsec,*)'TS-VDW: with periodic calculation'

                hirsh_cell_total(1,1) = esdf_integer('hf_one', 0)
                hirsh_cell_total(1,2) = esdf_integer('hf_two', 0)
                hirsh_cell_total(1,3) = esdf_integer('hf_three', 0)

                write(f_parsec,*)'Got the following Hf parameters:'
                write(f_parsec,*) hirsh_cell_total(:,:)
                write(f_parsec,*)'The numbers for the Hf cells are: &
                        &2*(Hf_One, Hf_Two, Hf_Three)+1 '
                write(f_parsec,*) hirsh_cell_total(1,1)*2+1, &
                        hirsh_cell_total(1,2)*2+1, hirsh_cell_total(1,3)*2+1
                write(f_parsec,*)'Note: The thresold for the TS energy &
                        &component is 10^-6 [eV]'
        else
                hirsh_cell_total(:,:) = 0
        endif
else
        !write(f_parsec,*)'Note: The calculation does not include dispersion corrections.'
endif  
  
!!! END VDW PART






calculate_force = esdf_boolean('calculate_force', &
        inputs%calculate_force)







write(f_parsec,*) 'Other input data:'
write(f_parsec,*) '-----------------'

!check to see that data output is enabled
enable_data_out = esdf_boolean('output_data', .true.)

if (.not. enable_data_out) then
        write(f_parsec,*) 'NOTICE: Raw Data output has been &
                &completely disabled'
        write(f_parsec,*) 'NOTICE: All other output flags &
                &but GW will be ingnored'
endif






use_hdf5 = esdf_boolean('use_hdf5', .false.)

#ifdef USE_HDF5

if (use_hdf5) then
        write(7,*) 'use_hdf5 is on'
else
        write(7,*) 'use_hdf5 is off'
endif

#else

if (use_hdf5) then
        write (7, *) 'NOTICE: Not compiled with -DUSE_HDF5'
        ! KHL: I just use a temporary ierr=-1 for now
        ! DR : I don't want parsec to exit, notice is enough.
        !ierr = -1        
        !return
endif

#endif









! read in output flag: 
outflag = 0
outputallstates = esdf_boolean('output_all_states', .false.)

if (outputallstates) then
        ! save all eigenvectors to disk
        outflag = outflag + 1
        elec_st_nsave = nstate*mxwd

        allocate(elec_st_indxsave(elec_st_nsave))

        do i = 1, elec_st_nsave
                elec_st_indxsave(i) = i
        enddo

        write(f_parsec,*) 'Writing all calculated wave functions &
                &to parsec.dat file'
else
        ! read in set of eigenvectors to be written to disk
        if (esdf_block('save_wfn_bands', nlines)) then
                if (nlines == 0) then
                        elec_st_nsave = 0
                elseif (nlines == 1) then
                        read(block_data(1),*,iostat=ierr) ilow, iup

                        if (ierr == 0) then
                                elec_st_nsave = iup - ilow + 1

                                allocate(elec_st_indxsave(elec_st_nsave))

                                do i = ilow, iup
                                        elec_st_indxsave(i-ilow+1) = i
                                enddo
                        else
                                elec_st_nsave = nlines

                                allocate(elec_st_indxsave(nlines))

                                do i = 1, nlines
                                        read(block_data(i),*,iostat=ierr) &
                                                elec_st_indxsave(i)
                                enddo
                        endif
                else
                        elec_st_nsave = nlines

                        allocate(elec_st_indxsave(nlines))

                        do i = 1, nlines
                                read(block_data(i),*,iostat=ierr) &
                                        elec_st_indxsave(i)
                        enddo
                endif

                if (elec_st_nsave > 0) then
                        write(f_parsec,*) 'Writing ', elec_st_nsave, &
                                ' selected wave functions to &
                                &parsec.dat file:'

                        write(f_parsec,'(10i6)') &
                                elec_st_indxsave(1:elec_st_nsave)
                else
                        write(f_parsec,*) 'No wave functions are &
                                &written to  parsec.dat file'
                endif

                if (ierr /= 0) then
                        write(f_parsec,*) 'ERROR: bad specification &
                                &of "save_wfn_bands" block!'
                        write(f_parsec,*) 'STOP in usrinput.'
                        ierr = 150
                        return
                endif
        else
                ! save only eigenvectors of occupied levels to disk
                elec_st_nsave = -1

                write(f_parsec,*) 'Writing only wave functions &
                        &of occupied levels to parsec.dat file'
        endif
endif

write(f_parsec,*)


outputgw = esdf_boolean('output_gw', .false.)

elec_st_efermi = esdf_physical('nscf_fermi_level', dzero, 'Ry')
nscf_kgrid(:) = 1
nscf_kshift(:) = dzero

if (outputgw) then

#ifdef GW

        write(f_parsec,*) 'Writing files for GW calculation using BerkeleyGW'

#else

        write(f_parsec,*) 'Please recompile the code with -DGW flag to &
                &enable this and link it to appropriate libraries &
                &from BerkeleyGW'
        write(f_parsec,*) 'STOP in usrinput.'
        ierr = 150
        return

#endif

        if (nscf_on) then
                if (esdf_block('nscf_kgrid', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*) ' error in specifying &
                                        &kgrid for nscf calc: ', nlines
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 114
                                return
                        endif


                        read(block_data(nlines),*,iostat=ierr) &
                                (nscf_kgrid(i), i=1,3)

                        write(f_parsec,*) ' Non-self consistent &
                                &kgrid dimensions'

                        write(f_parsec,37) (nscf_kgrid(i), i=1,3)
                else
                        write(f_parsec,*) ' Have to specify nscf_kgrid'
                        write(f_parsec,*) ' STOP in usrinput'
                        ierr = 114
                        return
                endif

                if (esdf_block('nscf_kgrid_shift', nlines)) then
                        if (nlines /= 1) then
                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Shift'
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 116
                                return
                        endif


                        read(block_data(nlines),*,iostat=ierr) &
                                (nscf_kshift(i), i=1,3)

                        if ( (ierr /= 0) .or. &
                             (nscf_kshift(1) < dzero) .or. &
                             (nscf_kshift(2) < dzero) .or. &
                             (nscf_kshift(3) < dzero) ) then
                                write(f_parsec,*) ' error in specifying &
                                        &Monkhorst-Pack Shift'
                                write(f_parsec,*) ' STOP in usrinput'
                                ierr = 117
                                return
                        endif

                        write(f_parsec,*)' Non-selfconsistent kgrid shift'
                        write(f_parsec,38) (nscf_kshift(i), i=1,3)
                else
                        write(f_parsec,*) ' Have to specify nscf_kgrid_shift'
                        write(f_parsec,*) ' STOP in usrinput'
                        ierr = 114
                        return
                endif


                if (elec_st_efermi == dzero) then
write(f_parsec,*) 'ERROR: specification of Fermi level for'
write(f_parsec,*) ' non self consistent calculation not found! '
write(f_parsec,*) ' Please specify nscf_efermi taken from scf calculation '
write(f_parsec,*) 'STOP in usrinput'
                        ierr = 114
                        return
                endif
        endif
endif








if (elec_st_nkpt > 0) then
        write(f_parsec,*) 'Note - charge symmetrization is &
                &turned off by default.'
endif

chsym = esdf_boolean('symmetrize_charge_density', .false.)

if (chsym) then
        write(f_parsec,*) 'Symmetrizing charge density &
                &according to symm.  operations in the full point group'
endif



save_intermediate_charge_density = &
        esdf_boolean('save_intermediate_charge_density', .false.)

if (save_intermediate_charge_density) then
        write(f_parsec,*) 'Writing charge density to parsec.dat &
                &file after each step of SCF'
        write(f_parsec,*)

        outflag = outflag + 2
endif






if (nspin == 2) then
        write(f_parsec,'(a,/)') ' Spin-polarized computation!'
        write(f_parsec,*) 'Initial spin polarization: '

        do ity = 1, naty
                write(f_parsec,'(2x,a2,5x,f11.4)') &
                        clust_name(ity), p_pot_spol(ity)
        enddo

        write(f_parsec,*)
else
        nspin = 1

        write(f_parsec,'(a,/)') ' No spin effects!'

        if (p_pot_is_so) then
                write(f_parsec,*) 'ERROR: spin-orbit requires &
                        &spin polarized functional.'
                write(f_parsec,*) 'Must declare "spin_polarization .true." &
                        &in parsec.in.'
                write(f_parsec,*) 'STOP'
                ierr = 151
                return
        endif
endif

p_pot_oldinpformat = esdf_boolean('old_interpolation_format', .false.)

write(f_parsec,*)

if (p_pot_oldinpformat) then
        write(f_parsec,*) 'Using old (direct) interpolation of pseudopot. !'
else
        write(f_parsec,*) 'Using new (r*V_ps) interpolation of pseudopot. !'
endif





! Output level flag
ipr = esdf_integer('output_level', 0)

write(f_parsec,'(/,a,i2,/)') ' output level [1 - 6] = ', ipr






output_grid_data_copy = esdf_reduce(esdf_string('output_grid_data', 'none'))

! Grid data output flag
flag_words(:) = esdf_split(output_grid_data_copy, &
        MAX_EXPORT_OPTS, flag_words_ntmp)

export_griddata_flag(:) = OPTNONE

i = 0
do while (i < flag_words_ntmp)
        i = i + 1

        select case (trim(flag_words(i)))
        case ('none')
                i = flag_words_ntmp
        case ('charge_density')
                write(f_parsec,*) 'Writing total charge density to &
                        &external file'
                write(f_parsec,*)
                export_griddata_flag(i) = CHGDENS
        case ('v_external')
                write(f_parsec,*) 'Writing external potential to &
                        &external file'
                write(f_parsec,*)
                export_griddata_flag(i) = VEXT
        case ('v_hartree')
                write(f_parsec,*) 'Writing hartree potential to external file'
                write(f_parsec,*)
                export_griddata_flag(i) = VHAR
        case ('v_external+v_hartree')
                write(f_parsec,*) 'Writing sum of external and &
                        &hartree potentials to external file'
                write(f_parsec,*)
                export_griddata_flag(i) = VEXTHAR
        case ('all')
                write(f_parsec,*) 'Writing charge density, &
                        &external potential, hartree potentials and &
                        &the sum of the two to external files'
                write(f_parsec,*)
                export_griddata_flag(1) = CHGDENS
                export_griddata_flag(2) = VEXT
                export_griddata_flag(3) = VHAR
                export_griddata_flag(4) = VEXTHAR
                i = flag_words_ntmp
        case default
                write(f_parsec,*) 'Wrong input to output_grid_data: ', &
                        trim(flag_words(i))
                write(f_parsec,*) 'STOP in usrinput.'
                ierr = 1001 !TODO: choose a different error number
                return
        end select
enddo







! read in  eigenstate to separated file output  flag:
! .false. / .true.
outevflag = 0
output_eigenvalues = esdf_boolean('output_eigenvalues', .false.)

if (elec_st_nkpt > 0) output_eigenvalues = .true.
  
if (output_eigenvalues) then
        outevflag = outevflag + 1

        write(f_parsec,*) 'Generating Eigenvalue Output File!' 

        if (outputallstates)  then
                write(f_parsec,*) 'Writing all calculated &
                        &eigenvalues to eigen.dat'
                write(f_parsec,*)
                outevflag = outevflag + 1
        endif

        save_intermediate_eigenvalues = &
                esdf_boolean('save_intermediate_eigenvalues', .false.)

        if (save_intermediate_eigenvalues)  then
                write(f_parsec,*) 'Writing eigenvalues to eigen.dat &
                        &after each step of SCF'
                write(f_parsec,*)
                outevflag = outevflag + 2
        endif
else
        write(f_parsec,*) 'No eigenvalue output File!'
endif

write(f_parsec,*) 'outevflag = ', outevflag
write(f_parsec,*)










if (move_name == OPTNONE) then
        move_is_on = .false.
        write(f_parsec,*) 'No minimization!'
else
        move_is_on = .true.
endif


move_mxmove = esdf_integer('movement_num', 500)
move_fmin = esdf_physical('force_min', 1.d-2, 'ry/bohr')

stpmax = 0.05d0
move_stepmax = esdf_physical('max_step', stpmax, 'bohr')

move_stepmin = esdf_physical('min_step', 1.d-4, 'bohr')
move_is_restart = esdf_boolean('relax_restart', .false.)


! AJB: we no longer write out restart information unless requested
! This decision might be reversed in the future.
move_write_restart = esdf_boolean('write_relax_restart', .false.)

move_mmax = esdf_integer('BFGS_number_corr', 7)

restart_cheb_after_n = esdf_integer('filter_restart_after', 5000)
restart_cheb_remained_times = esdf_integer( &
        'restart_cheb_remained_times', 3)
remained_times_atomic_chrg_den = esdf_integer( &
        'remained_times_atomic_chrg_den', 3)

if (move_is_on) then

        !AJB: The accuracy is hard coded
        write(f_parsec,*) 'Minimization data:'
        write(f_parsec,*) '------------------'

        if (move_fmin < 1.d-5) then
                write(f_parsec,*) 'ERROR: minimum force below &
                        &numerical accuracy'
                write(f_parsec,*) 'increase it to at least 1E-5'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 152
                return
        endif

        if (move_name == STEEPDESC) then
                write(f_parsec,*) 'Simple minimization!'
                write(f_parsec,*) 'This scheme is not robust!'
                write(f_parsec,*) 'make sure the construction of &
                        &displacements in domove.f fits your purpose.'

                if (move_stepmax < 1.d-5) then
                        write(f_parsec,*) 'ERROR: maximum step size too small!'
                        write(f_parsec,*) 'increase it to at least 1E-5'
                        write(f_parsec,*) 'STOP in usrinput'
                        ierr = 153
                        return
                endif
        elseif (move_name == BFGS) then
                write(f_parsec,*) 'Limited-memory BFGS minimization!'


                if (move_stepmax == stpmax) then
                        ! unrestricted BFGS, no bounds on atom coordinates
                        move_stepmax  = -1.d0
                else
                        ! restricted BFGS, move%stepmax defines 
                        ! the maximum displacement
                        write(f_parsec,*) 'Restricted BFGS'
                        write(f_parsec,*) 'Maximum displacement of atoms &
                                &from initial position is ', move_stepmax
                        write(f_parsec,*) ' bohrs along each &
                                &cartesian direction.'
                endif

        elseif (move_name == MANUAL) then
                write(f_parsec,*) 'atoms move according to info in manual.dat'

                ! make all atoms movable
                tmove(:) = 1

                ! Set force limit to zero (this avoids undesirable 
                ! outputs from subroutine domove).
                move_fmin = dzero
        endif

        write(f_parsec,'(a,i4)') ' Maximum number of movements  = ', &
                move_mxmove

        if (move_name == STEEPDESC) then
                write(f_parsec,91) ' Maximum step size  = ', move_stepmax
                write(f_parsec,91) ' Mininum step size  = ', move_stepmin
        endif

        if (move_name /= MANUAL) then
                write(f_parsec,'(a,f8.5,a)') &
                        ' Minimum force  = ', move_fmin, ' [Ry/au]'
        endif

        if (move_is_restart) then
                write(f_parsec,*) 'Restart relaxation, information on &
                        &previous runs read from relax_restart.dat file.'
        endif

        if (move_name == BFGS) then
                write(f_parsec,'(a,a,i4)') ' Number of ', &
                        'corrections used in LBFGS update = ', move_mmax
        endif

endif
91 format(a,f8.5,' [au]')


if (move_is_on .or. md_is_on) then
        write(f_parsec,*) ' Will restart from scratch after', &
                restart_cheb_after_n, 'ionic steps'

        write(f_parsec,*) 'restart_cheb_remained_times', &
                restart_cheb_remained_times

        write(f_parsec,*) 'remained_times_atomic_chrg_den', &
                remained_times_atomic_chrg_den
endif

write(f_parsec,*)









! read in LMD parameters
! initial and final temperatures (in kelvin), 
! step temperature for stair cooling
! # of step, cooling scheme (1 - stair, 2- linear, 3 - log)
! time step, friction coefficient, # of time steps
cooling_method = esdf_reduce(esdf_string ('cooling_method', 'stair'))
  
select case (trim(cooling_method))
case ('stair')
        md_cool_type = MD_STAIR
case ('linear')
        md_cool_type = MD_LINEAR
case ('log')
        md_cool_type = MD_LOG
case default
        write(f_parsec,*)  
        write(f_parsec,*) 'ERROR: unkown molecular dynamics &
                &cooling scheme: ', trim(cooling_method)
        write(f_parsec,*)'STOP in usrinput'
        ierr = 154
        return
end select

md_tempi = esdf_physical('tinit', 500.0d0, 'k')
md_tempf = esdf_physical('t_final', 500.0d0, 'k')
md_step_tmp = esdf_physical('t_step', 150.0d0, 'k')
md_time_step = esdf_physical('time_step', 150.0d0, 'ps')
md_friction_coef = esdf_double('friction_coefficient', dzero)
md_step_num = esdf_integer('step_num', 250)

! For debug purposes - fix the rng seed
md_rng_seed = esdf_integer('mol_rng_seed', 0)
md_use_test_rng = esdf_boolean ('test_rng', .false.)
md_is_restart = esdf_boolean('restart_mode', .false.)

md_stride = -1

if (.not. md_is_on) then
        write(f_parsec,*) 'No molecular dynamics!'
else
        write(f_parsec,*) 'Molecular dynamics data:'
        write(f_parsec,*) '-------------------------'

        if (md_is_restart) then
                write(f_parsec,*) 'WARNING: restarted molecular dynamics run'
                write(f_parsec,*) 'restart data assumed present in mdinit.dat'
        endif

        if (md_rng_seed > 0) then
                write(f_parsec,*) 'WARNING: running with user defined &
                        &RNG seed: ', md_rng_seed
        endif

        if (md_use_test_rng) then
                write(f_parsec,*) 'WARNING: running with simple RNG engine ' 

                if (md_is_restart) then
                        write(f_parsec,*) 'MD restart will try to &
                                &perserve RNG seed position'
                endif
        endif

        select case (md_cool_type)
        case (MD_STAIR)
                write(f_parsec,*) '"Stairstep" cooling scheme '
                write(f_parsec,'(a,f6.1,a)') ' Temperature step = ', &
                        md_step_tmp, ' [K]'

                i = int( (md_tempi - md_tempf)/md_step_tmp + 1 )

                md_stride = md_step_num/i

                if (md_stride*i < md_step_num) then
                        md_stride = md_stride + 1
                endif

                write(f_parsec,*) 'Temperature modified after ', &
                        md_stride, ' iterations'

        case (MD_LINEAR)
                write(f_parsec,*) 'Linear cooling scheme '
        case (MD_LOG)
                write(f_parsec,*) 'Logarithmic cooling scheme '
        end select

        write(f_parsec,52) ' Initial Temperature = ', md_tempi
        write(f_parsec,52) ' Final Temperature = ', md_tempf
        write(f_parsec,'(a,f8.2,a,f6.4,a)') ' Time step = ' , &
                md_time_step, ' [au] = ', md_time_step*timeaups, ' [ps]'
        write(f_parsec,'(a,f8.7,a)') ' Friction Coefficient = ', &
                md_friction_coef,' [au]'

        if (md_friction_coef < 10d-6) then
                write(f_parsec,*) 'Small coefficient, &
                        &doing MICROcanonical ensemble'
                write(f_parsec,*) ' '
        else
                write(f_parsec,*) 'Large coefficient, &
                        &doing (MACRO)canonical ensemble'
                write(f_parsec,*) ' '
        endif

        write(f_parsec,'(a,i5)') ' Number of MD iterations = ', &
                md_step_num
        write(f_parsec,*) ' '
endif
52 format(a,f6.1,' [K]')





! read in polarizability flag and electric field
polarizability = esdf_boolean('polarizability', .false.)

electric_field = esdf_physical('electric_field', 0.001d0, 'ry/bohr/e')

if (polarizability) then
        npolflg = 1
        write(f_parsec,*) 'Polarizability data:'
        write(f_parsec,*) '--------------------'
        write(f_parsec,*) 'Using seven-fields polarizability approach'
        write(f_parsec,'(a,f8.5,a)') ' Electric field  = ', &
                electric_field, ' [Ry/au]'
else
        npolflg = 0
        write(f_parsec,*) 'No polarizability!'
endif

write(f_parsec,*)



ngroups = esdf_integer('npcol', 1)

#ifndef USE_SCALAPACK
if (ngroups > 1) then
        write(f_parsec,*) 'For now please define USE_SCALAPACK if you &
                &want to use multiple MPI groups (npcol > 1) in one task.'
        !DR I don't want parsec to exit
        ngroups = 1 
        write(9,*) "ngroups", ngroups
        !STOP
endif
#endif

if (ngroups > 1) then

        if (solver_name /= CHEBFF) then
                write(f_parsec,*) 'For now only CHEBFF can use multiple &
                        &column groups (npcol > 1)'
                ierr = -1
                return
        endif

        if (mod(nnodes,ngroups) /= 0) then
                write(f_parsec,*) 'nnodes', nnodes
                write(f_parsec,*) 'npcol', ngroups
                write(f_parsec,*) 'ERROR: Number of processes should be &
                        &a multiple of npcol'
                ierr = -1
                return
        endif

#ifdef USE_SCALAPACK
        if (mod(nstate,(ngroups*scalapack_block_size)) /= 0) then
                write(f_parsec,*) 'nstate', nstate
                write(f_parsec,*) 'npcol', ngroups
                write(f_parsec,*) 'scalapack_block_size', &
                        scalapack_block_size
                write(f_parsec,*) 'WARNING: Number of states should be &
                        &a multiple of npcol*scalapack_block_size; &
                        &rounding up.'
                nstate = ((nstate + ngroups*scalapack_block_size - 1) / &
                        (ngroups*scalapack_block_size)) * &
                        (ngroups*scalapack_block_size)
                write(f_parsec,*) 'Adjusted number of states: ', nstate
        endif

        if (.not. use_scalapack) then
                write(f_parsec,*) "ERROR: When use_scalapack is off, &
                        &multiple column groups is not supported"
                ierr = -1
                return
        endif
#endif

endif







! flag compatibility tests
if ( md_is_on .or. (move_name /= OPTNONE) ) then
        if (polarizability) then
                write(f_parsec,*)  
                write(f_parsec,*) 'ERROR: Cannot do polarizability and &
                        &move atoms'
                write(f_parsec,*) 'set MD and Minimization Flags = 0'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 155
                return
        endif
endif
  
if (pbc_per > 2 .and. polarizability) then
        write(f_parsec,*)
        write(f_parsec,*) 'ERROR: Cannot do polarizability with periodic'
        write(f_parsec,*) 'boundary conditions!'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 156
        return
endif
  
if ( md_is_on .and. (move_name /= OPTNONE) ) then
        write(f_parsec,*)  
        write(f_parsec,*) 'ERROR: Cannot do minimization and MD'
        write(f_parsec,*) 'set either MD or minimization flag to zero'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 157
        return
endif
  
if (mxwd == 2) then
        write(f_parsec,*)  
        write(f_parsec,*) 'ERROR: SO type calculations with '
        write(f_parsec,*) 'the new matvec are not yet implemented. Sorry!'
        write(f_parsec,*) 'STOP in usrinput'
        ierr = 158
        return
endif


! KHL: If the solver is chebff and the user sets tolerance for 
!      the residuals of wave functions, we override the maximum number 
!      of subspace iterations to avoid too many subspace iterations.
!     
if (solver_name == CHEBFF .and. toler /= -1.d0) then
        ff_maxiter = 50

        write(f_parsec,*) ' warning: diag_tolerance is set and the &
                &solver is chebff. Changing ff_maxiter to 50...'
endif

if (spectrum_slicing) then
        if (nslices > ngroups) then
                write(f_parsec,*) "warning: the number of slices is &
                        &less than the number of process columns."
                write(f_parsec,*) "Please increase the number of &
                        &process columns [npcol]"
                stop
        endif
endif


generate_complete_parsec_in = &
        esdf_boolean('generate_complete_parsec_in', .false.)


call esdf_close()
  



















! ==============================================================
!
! Print out to bak_complete_parsec.in
!
! ==============================================================


if (generate_complete_parsec_in) then
        call write_out_parameters()
endif













 


  






! ==============================================================
!
! Copy the parameters to internal data structures
!
! ==============================================================

! ========================
! Copy to output arguments
! ========================

istart = istart
mxiter = mxiter
vconv = vconv
vconv_approach = vconv_approach
electric_field = electric_field
outflag = outflag
ipr = ipr
export_griddata_flag(:) = export_griddata_flag(:)
chsym = chsym
ngroups = ngroups
wstrt = wstrt
readwfndat = readwfndat
outevflag = outevflag
ignoresym = ignoresym
outputgw = outputgw
enable_data_out = enable_data_out
npolflg = npolflg






! ========================
! Copy to internal structures
! ========================

band_st%bands_on = band_st_bands_on
band_st%nlines = band_st_nlines

if (band_st_nlines > 0) then
        allocate(band_st%blines(band_st_nlines))

        do i = 1, band_st_nlines
                band_st%blines(i)%line_num = band_st_blines(i)%line_num
                band_st%blines(i)%start(1:3) = band_st_blines(i)%start(1:3)
                band_st%blines(i)%end(1:3) = band_st_blines(i)%end(1:3)
                band_st%blines(i)%line_name = band_st_blines(i)%line_name
        enddo

        band_st%npoints = band_st_npoints
endif



clust%type_num = naty

allocate(clust%natmi(naty))
allocate(clust%name(naty))
allocate(clust%ppfile(naty))
allocate(clust%ylmdos_cutoff(naty))

itmp = norder/2
call create_pseudo_potential(naty, itmp, p_pot)


allocate(p_pot%rws(naty))
p_pot%rws(:) = zero

do ity = 1, naty
        clust%name(ity) = clust_name(ity)
        p_pot%format(ity) = p_pot_format(ity)
        clust%ppfile(ity) = clust_ppfile(ity)
        p_pot%so(ity) = p_pot_so(ity)
        p_pot%rvcd(ity) = p_pot_rvcd(ity)
        p_pot%loc(ity) = p_pot_loc(ity)
        p_pot%nlocp(ity) = p_pot_nlocp(ity)
        p_pot%rcore(ity) = p_pot_rcore(ity)
        p_pot%eleatm(ity,1:p_pot_nlocp(ity)) = &
                p_pot_eleatm(ity,1:p_pot_nlocp(ity))
        p_pot%icore(ity) = p_pot_icore(ity)
        p_pot%spol(ity) = p_pot_spol(ity)
        p_pot%alpha(ity) = p_pot_alpha(ity)
        p_pot%beta1(ity) = p_pot_beta1(ity)
        p_pot%acore(ity) = p_pot_acore(ity)
        p_pot%uspline(ity) = p_pot_uspline(ity)
        clust%ylmdos_cutoff(ity) = clust_ylmdos_cutoff(ity)
        clust%natmi(ity) = clust_natmi(ity)
        p_pot%uu(:,ity) = p_pot_uu(:,ity)
        p_pot%jj(:,ity) = p_pot_jj(:,ity)

        p_pot%rws(ity) = p_pot_rws(ity)
 
enddo









! creating the 'empty' cluster
if (naty > 0) then
        natom = sum(clust_natmi(:))

        call create_cluster(natom, clust)

        clust%mvat(1:natom) = tmove(1:natom)
        clust%xatm(1:natom) = atom_coord(1,1:natom)
        clust%yatm(1:natom) = atom_coord(2,1:natom)
        clust%zatm(1:natom) = atom_coord(3,1:natom)
        clust%atype(1:natom) = atype(1:natom)
  
        deallocate(tmove)
        deallocate(atom_coord)
endif


clust%recenter_atoms_in_aperiodic_directions = &
        recenter_atoms_in_aperiodic_directions

clust%has_ptchrg = has_ptchrg
clust%npttyp = npttyp

if (has_ptchrg) then
        allocate(clust%nptt(npttyp))
        allocate(clust%qpt(npttyp))

        clust%nptt(:) = clust_nptt(:)
        clust%qpt(:) = clust_qpt(:)
        clust%nptchrg = clust_nptchrg

        allocate(clust%xpt(clust_nptchrg))
        allocate(clust%ypt(clust_nptchrg))
        allocate(clust%zpt(clust_nptchrg))

        clust%xpt(1:clust_nptchrg) = ptchrg_coord(1,1:clust_nptchrg)
        clust%ypt(1:clust_nptchrg) = ptchrg_coord(2,1:clust_nptchrg)
        clust%zpt(1:clust_nptchrg) = ptchrg_coord(3,1:clust_nptchrg)

        deallocate(ptchrg_coord)
endif



clust%has_charged_sheet = has_charged_sheet
clust%number_charged_sheet_type = number_charged_sheet_type

if (has_charged_sheet) then
        allocate(clust%number_charged_sheets_per_type( &
                number_charged_sheet_type))
        allocate(clust%sheet_charge_of_type(number_charged_sheet_type))

        clust%number_charged_sheets_per_type(:) = &
                clust_number_charged_sheets_per_type(:)
        clust%sheet_charge_of_type(:) = clust_sheet_charge_of_type(:)
        clust%number_charged_sheets = number_charged_sheets

        ! create appropriate arrays in cluster structure
        !allocate(clust%x_charged_sheets(number_charged_sheets))
        !allocate(clust%y_charged_sheets(number_charged_sheets))
        allocate(clust%z_charged_sheets(number_charged_sheets))

        !clust%x_charged_sheets(1:number_charged_sheets) = &
        !        sheetchrg_coord(1,1:number_charged_sheets)
        !clust%y_charged_sheets(1:number_charged_sheets) = &
        !        sheetchrg_coord(2,1:number_charged_sheets)
        clust%z_charged_sheets(1:number_charged_sheets) = &
                sheetchrg_coord(3,1:number_charged_sheets)

        deallocate(sheetchrg_coord)
endif








! creating the 'empty' electronic_structure
call create_electronic_struct(nspin, nstate, elec_st, mxwd)


elec_st%nkpt = elec_st_nkpt
elec_st%explicit_hartree_pbc = explicit_hartree_pbc
elec_st%kptmethod = elec_st_kptmethod
elec_st%mpgrid(:) = elec_st_mpgrid(:)
elec_st%mpshift(:) = elec_st_mpshift(:)
elec_st%dos_mpgrid(:) = dos_mpgrid(:)
elec_st%dos_mpshift(:) = dos_mpshift(:)
elec_st%orb_mag = orb_mag
elec_st%is_cur = elec_st_is_cur
elec_st%is_mag = is_mag
elec_st%mag_field = mag_field
elec_st%cplx = cplx_wfn
elec_st%use_plain_sre = use_plain_sre
elec_st%scf_so = scf_so
elec_st%ncl = ncl
elec_st%nspin = nspin
elec_st%mxwd = mxwd
elec_st%is_so = elec_st_is_so
elec_st%do_vdw = do_vdw

elec_st%ncharge = ncharge 
elec_st%use_libxc = use_libxc
elec_st%func_id(1:2) = func_id(1:2)
elec_st%icorr(:) = icorr(:)
elec_st%dioniz = dioniz

elec_st%nsave = elec_st_nsave

! KHL: elec_st_nsave could be -1
if (elec_st_nsave > 0) then
        allocate(elec_st%indxsave(elec_st_nsave))
        elec_st%indxsave(1:elec_st_nsave) = &
                elec_st_indxsave(1:elec_st_nsave)
        deallocate(elec_st_indxsave)
endif

elec_st%efermi = elec_st_efermi



elec_st%hirsh_3d_cell(:,:) = hirsh_cell_total(:,:)
elec_st%tfermi = tfermi

if (allocated(elec_st_kpts)) then
        allocate(elec_st%kpts(3,elec_st_nkpt))
        elec_st%kpts(:,:) = elec_st_kpts(:,:)
        deallocate(elec_st_kpts)
endif

if (allocated(elec_st_kpwt)) then
        allocate(elec_st%kpwt(elec_st_nkpt))
        elec_st%kpwt(:) = elec_st_kpwt(:)
        deallocate(elec_st_kpwt)
endif


if (ncl) then
        allocate(elec_st%init_mag(3,maxatm))
        elec_st%init_mag(:,:) = dzero

        natom = 0
        do ity = 1, naty
        do i = 1, clust_natmi(ity)
                natom = natom + 1
                elec_st%init_mag(:,natom) = initmag(:,natom)
                deallocate(initmag)
        enddo
        enddo
endif







grid%fold%side_length = foldblock_side_length
grid%domain_shape = domain_shape
grid%d_shape_param(:) = d_shape_param(:)
grid%i_shape_param(:) = i_shape_param(:)

call grid_set_rmax_step(rmax, h, grid)

grid%shift(:) = grid_shift(:)
grid%ndouble = ndouble
grid%norder = norder/2
grid%use_sfc = use_sfc




inputs%vecgen_rng_type = vecgen_rng_type
inputs%use_old_forces = use_old_forces
inputs%print_unconverged_density = print_unconverged_density
inputs%output_ascii_data = output_ascii_data
inputs%calculate_force = calculate_force
inputs%use_hdf5 = use_hdf5



mol_dynamic%is_on = md_is_on

mixer%scf_fail = mixer_scf_fail
mixer%name = mixer_name
mixer%param = mixer_param
mixer%memory = mixer_memory
mixer%restart = mixer_restart
mixer%group_size = mixer_group_size
mixer%en_stage = mixer_en_stage
mixer%restart_factor = mixer_restart_factor
mixer%expand_factor = mixer_expand_factor
mixer%preferred_type = mixer_preferred_type
mixer%block = mixer_block
 
move%name = move_name

move%is_on = move_is_on
move%mxmove = move_mxmove
move%fmin = move_fmin
move%stepmax = move_stepmax
move%stepmin = move_stepmin
move%is_restart = move_is_restart
move%write_restart = move_write_restart
move%mmax = move_mmax
move%restart_cheb_after_n = restart_cheb_after_n
move%restart_cheb_remained_times = restart_cheb_remained_times
move%remained_times_atomic_chrg_den = remained_times_atomic_chrg_den


mol_dynamic%cool_type = md_cool_type
mol_dynamic%tempi = md_tempi
mol_dynamic%tempf = md_tempf
mol_dynamic%step_tmp = md_step_tmp
mol_dynamic%time_step = md_time_step
mol_dynamic%friction_coef = md_friction_coef
mol_dynamic%step_num = md_step_num
mol_dynamic%rng_seed = md_rng_seed
mol_dynamic%use_test_rng = md_use_test_rng

if (md_is_on) then
        call molecular_dynamic_turn_on(mol_dynamic, sum(clust_natmi(:)))
endif

mol_dynamic%is_restart = md_is_restart
mol_dynamic%stride = md_stride





nscf%nscf_on = nscf_on
nscf%nkpt = nscf_nkpt
nscf%nstate = nscf_nstate

if (nscf_nkpt > 0) then
        allocate(nscf_kpts(3,nscf_nkpt))
        nscf%kpts(:,:) = nscf_kpts(:,:)
        deallocate(nscf_kpts)

        allocate(nscf%kpwt(nscf_nkpt))
        nscf%kpwt(:) = nscf_kpwt(:)
        deallocate(nscf_kpwt)
endif

nscf%kgrid(:) = nscf_kgrid(:)
nscf%kshift(:) = nscf_kshift(:)










pbc%per = pbc_per
pbc%ealpha = pbc_ealpha
pbc%is_on = pbc_is_on
pbc%latt_vec(:,:) = pbc_latt_vec(:,:)
pbc%box_size(:) = pbc_box_size(:)
pbc%create_dos = create_dos
pbc%dos_pnum = dos_pnum
pbc%ylmdos_l = pbc_ylmdos_l
pot%is_cur = pot_is_cur
parallel%max_lap_buffers = max_lap_buffers


p_pot%nlocp = p_pot_nlocp
p_pot%eleatm(:,:) = p_pot_eleatm(:,:)
p_pot%is_so = p_pot_is_so
p_pot%so_hcub = p_pot_so_hcub
p_pot%oldinpformat = p_pot_oldinpformat



pot%nspin = nspin


  
if (pbc_is_on) then
        call pbc_turn_on(sum(clust_natmi(:)), naty, pbc)
endif
 



 


rritz%forced_logic = rritz_forced_logic



solver%rng_seed = vector_rng_seed
solver%randommp = thread_random_init
solver%oldvectorrng = old_vector_random
solver%name = solver_name
solver%mv_blksize = mv_blksize
solver%polym0 = chebdav_degree
solver%ff_maxiter = ff_maxiter
solver%bands_ff_maxiter = bands_ff_maxiter

solver%spectrum_slicing = spectrum_slicing
solver%use_krylov_subspace_method = use_krylov_subspace_method
solver%use_lanczos_dos_estimation = use_lanczos_dos_estimation
solver%spectrum_slicing_cycles_early_quit = spectrum_slicing_cycles_early_quit
solver%spectrum_slicing_max_cycles = spectrum_slicing_max_cycles
solver%spectrum_slicing_max_cycles_first = spectrum_slicing_max_cycles_first
solver%num_of_iter_still_using_chebyshev = num_of_iter_still_using_chebyshev
solver%polym_first_ss_iter = polym_first_ss_iter
solver%polym_ss = polym_ss
solver%num_of_copied_groups = num_of_copied_groups
solver%num_of_slice1_filtering = num_of_slice1_filtering
solver%nslices = nslices
solver%spectrum_slicing_ratio = spectrum_slicing_ratio

solver%use_elpa = use_elpa
solver%elpa_block_size = elpa_block_size
solver%use_scalapack = use_scalapack
solver%scalapack_block_size = scalapack_block_size
solver%fix_num_eig = fix_num_eig
solver%do_subsp = do_subsp
solver%scaledcheb = scaledcheb
solver%use_smart_bound_in_subspace = use_smart_bound_in_subspace
solver%polym = chebyshev_degree
solver%polym_t = chebyshev_degree
solver%dpm = dpm
solver%toler = toler
solver%dyntol = dyntol
solver%maxmv = maxmv
solver%boundsmethod = solver_boundsmethod
solver%num_lancz_bound = num_lancz_bound
solver%lpole = lpole





tests%logic = tests_logic



contains

subroutine write_out_parameters()

        ! ==============================================================
        !
        ! Print out to bak_complete_parsec.in
        ! (Remember that all values are in atomic units at this stage)
        ! (Also the lattice vectors and atoms are already expanded)
        ! (supercell are all 1's because of the expansion)
        ! (cell_vac are all 0's because of the expansion)
        !
        ! ==============================================================



        open(f_bak_parsec_in,file=trim('bak_complete_parsec.in'),form='formatted')  


        ! ========================
        ! real-space grid
        ! ========================

        write(f_bak_parsec_in,*) 'boundary_conditions ', &
                trim(boundary_conditions)
        write(f_bak_parsec_in,*) 'boundary_sphere_radius', rmax
        write(f_bak_parsec_in,*) 'grid_spacing', h
        write(f_bak_parsec_in,*) 'expansion_order', norder
        write(f_bak_parsec_in,*) 'ignore_symmetry', ignoresym
        write(f_bak_parsec_in,*) 'lattice_vector_scale', 1.0d0
        write(f_bak_parsec_in,*) 'double_grid_order', ndouble
        write(f_bak_parsec_in,*) 'cluster_domain_shape ', trim(shapeflag)
        write(f_bak_parsec_in,*) 'full_hartree', full_hartree_flag
        !write(f_bak_parsec_in,*) 'boundary_mask'
        write(f_bak_parsec_in,*) 'use_sfc', use_sfc
        write(f_bak_parsec_in,*) 'foldblock_side_length', &
                foldblock_side_length

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin cell_shape'
        do i = 1, pbc_per
                write(f_bak_parsec_in,*) pbc_latt_vec(:,i)
        enddo
        write(f_bak_parsec_in,*) 'end cell_shape'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin super_cell'
        write(f_bak_parsec_in,*) (trim("  1"), i=1,pbc_per)
        write(f_bak_parsec_in,*) 'end super_cell'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin super_cell_vac'
        write(f_bak_parsec_in,*) (trim("  0"), i=1,pbc_per)
        write(f_bak_parsec_in,*) 'end super_cell_vac'
        write(f_bak_parsec_in,*)

        select case(trim(shapeflag))
        case ('ellipsoid','box')
                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin domain_shape_parameters'
                write(f_bak_parsec_in,*) d_shape_param(1:3)
                write(f_bak_parsec_in,*) 'end domain_shape_parameters'
                write(f_bak_parsec_in,*)
        case ('cylinder')
                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin domain_shape_parameters'
                write(f_bak_parsec_in,*) d_shape_param(1:2), i_shape_param(1)
                write(f_bak_parsec_in,*) 'end domain_shape_parameters'
                write(f_bak_parsec_in,*)
        end select

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin grid_shift'
        write(f_bak_parsec_in,*) grid_shift(:)
        write(f_bak_parsec_in,*) 'end grid_shift'
        write(f_bak_parsec_in,*)






        ! ========================
        ! diagonalization parameters
        ! ========================

        write(f_bak_parsec_in,*) 'eigensolver ', trim(eigensolver)
        write(f_bak_parsec_in,*) 'diag_tolerance', toler
        write(f_bak_parsec_in,*) 'ff_maxiter', ff_maxiter
        write(f_bak_parsec_in,*) 'maximum_matvec', maxmv
        !write(f_bak_parsec_in,*) 'subspace_buffer_size'
        write(f_bak_parsec_in,*) 'chebyshev_filtering', do_subsp
        write(f_bak_parsec_in,*) 'chebdav_degree', chebdav_degree
        write(f_bak_parsec_in,*) 'chebyshev_degree', chebyshev_degree
        write(f_bak_parsec_in,*) 'chebyshev_degree_delta', dpm
        write(f_bak_parsec_in,*) 'use_elpa', use_elpa
        write(f_bak_parsec_in,*) 'elpa_block_size', elpa_block_size
        write(f_bak_parsec_in,*) 'use_scalapack', use_scalapack
        write(f_bak_parsec_in,*) 'scalapack_block_size', scalapack_block_size
        write(f_bak_parsec_in,*) 'matvec_blocksize', mv_blksize
        write(f_bak_parsec_in,*) 'solver_lpole', lpole
        write(f_bak_parsec_in,*) 'hartree_cg_tolerance', solver%hartree_rtol
        write(f_bak_parsec_in,*) 'hartree_cg_criterion', solver%hartree_test

        write(f_bak_parsec_in,*) 'spectrum_slicing', spectrum_slicing
        write(f_bak_parsec_in,*) 'use_krylov_subspace_method', use_krylov_subspace_method
        write(f_bak_parsec_in,*) 'use_lanczos_dos_estimation', use_lanczos_dos_estimation
        write(f_bak_parsec_in,*) 'spectrum_slicing_cycles_early_quit', spectrum_slicing_cycles_early_quit
        write(f_bak_parsec_in,*) 'spectrum_slicing_max_cycles', spectrum_slicing_max_cycles
        write(f_bak_parsec_in,*) 'spectrum_slicing_max_cycles_first', spectrum_slicing_max_cycles_first
        write(f_bak_parsec_in,*) 'num_of_iter_still_using_chebyshev', num_of_iter_still_using_chebyshev
        write(f_bak_parsec_in,*) 'polym_first_ss_iter', polym_first_ss_iter
        write(f_bak_parsec_in,*) 'polym_ss', polym_ss
        write(f_bak_parsec_in,*) 'num_of_copied_groups', num_of_copied_groups
        write(f_bak_parsec_in,*) 'num_of_slice1_filtering', num_of_slice1_filtering
        write(f_bak_parsec_in,*) 'nslices', nslices
        write(f_bak_parsec_in,*) 'spectrum_slicing_ratio', spectrum_slicing_ratio

        write(f_bak_parsec_in,*) 'bounds_method ', trim(bounds_method)
        write(f_bak_parsec_in,*) 'bounds_iter', num_lancz_bound
        write(f_bak_parsec_in,*) 'rritz_logic ', trim(rritz_logic)
        write(f_bak_parsec_in,*) 'test_logic ', trim(test_logic)
        write(f_bak_parsec_in,*) 'dynamic_diag_tol', dyntol
        write(f_bak_parsec_in,*) 'vector_rng_seed', vector_rng_seed
        write(f_bak_parsec_in,*) 'vector_rng_type', vecgen_rng_type
        write(f_bak_parsec_in,*) 'old_vector_random', old_vector_random
        write(f_bak_parsec_in,*) 'max_lap_buffers', max_lap_buffers
        write(f_bak_parsec_in,*) 'chebyshev_scaled', scaledcheb
        write(f_bak_parsec_in,*) 'smart_subspace', &
                use_smart_bound_in_subspace




        ! ========================
        ! Self-consistency and Mixing Parameters
        ! ========================

        write(f_bak_parsec_in,*) 'max_iter', mxiter
        write(f_bak_parsec_in,*) 'convergence_criterion', vconv
        write(f_bak_parsec_in,*) 'convergence_criterion_approach', &
                vconv_approach
        write(f_bak_parsec_in,*) 'fix_number_eigenvalues', fix_num_eig
        write(f_bak_parsec_in,*) 'use_plain_sre', use_plain_sre

        write(f_bak_parsec_in,*) 'mixing_method ', trim(mixing_method)
        write(f_bak_parsec_in,*) 'memory_param', mixer_memory
        write(f_bak_parsec_in,*) 'restart_mixing', mixer_restart
        write(f_bak_parsec_in,*) 'mixing_param', mixer_param
        write(f_bak_parsec_in,*) 'mixing_group_size', mixer_group_size
        write(f_bak_parsec_in,*) 'mixing_en_like', mixer_en_stage
        write(f_bak_parsec_in,*) 'mixing_restart_factor', &
                mixer_restart_factor
        write(f_bak_parsec_in,*) 'mixing_memory_expand_factor', &
                mixer_expand_factor
        write(f_bak_parsec_in,*) 'mixing_preferred_type', &
                mixer_preferred_type



        ! ========================
        ! Global Atom and Pseudopotential Parameters
        ! ========================

        write(f_bak_parsec_in,*) 'atom_types_num', naty

        ! Here is we print out 'cartesian_inverse_bohr' because we
        ! have converted the kpoints into those in this unit
        write(f_bak_parsec_in,*) 'coordinate_unit ', 'cartesian_bohr'

        write(f_bak_parsec_in,*) 'old_interpolation_format', &
                p_pot_oldinpformat
        write(f_bak_parsec_in,*) 'scf_so', scf_so
        write(f_bak_parsec_in,*) 'so_from_scratch', so_start
        write(f_bak_parsec_in,*) 'recenter_atoms_in_aperiodic_directions', &
                recenter_atoms_in_aperiodic_directions

        ! For each atom type:
        natom = 0
        do ity = 1, naty
                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) '# ==========================='
                write(f_bak_parsec_in,*) '# Parameters for atom type', ity
                write(f_bak_parsec_in,*) '# ---------------------------'

                write(f_bak_parsec_in,*) 'atom_type ', clust_name(ity)
                write(f_bak_parsec_in,*) 'pseudopotential_format ', &
                        trim(pseudopotential_format(ity))
                write(f_bak_parsec_in,*) 'potential_num', p_pot_nlocp(ity)
                write(f_bak_parsec_in,*) 'core_cutoff_radius', &
                        p_pot_rcore(ity)
                write(f_bak_parsec_in,*) 'local_component ', &
                        local_component(ity)
                write(f_bak_parsec_in,*) 'nonlinear_core_correction', &
                        nonlinear_core_correction(ity)
                write(f_bak_parsec_in,*) 'move_flag', move_flag(ity)
                write(f_bak_parsec_in,*) 'alpha_filter', p_pot_alpha(ity)
                write(f_bak_parsec_in,*) 'beta1_filter', p_pot_beta1(ity)
                write(f_bak_parsec_in,*) 'core_filter', p_pot_acore(ity)
                write(f_bak_parsec_in,*) 'initial_spin_polarization', &
                        p_pot_spol(ity)
                write(f_bak_parsec_in,*) 'ldaplusu_u', p_pot_uu(3,ity)
                write(f_bak_parsec_in,*) 'ldaplusu_j', p_pot_jj(3,ity)
                write(f_bak_parsec_in,*) 'so_psp', p_pot_so(ity)
                write(f_bak_parsec_in,*) 'cubic_spline', p_pot_uspline(ity)
                !write(f_bak_parsec_in,*) 'pseudopot_file', clust_ppfile(ity)
                !write(f_bak_parsec_in,*) 'read_vcd', p_pot_rvcd(ity)
                !write(f_bak_parsec_in,*) 'ylm_dos_cutoff', clust_ylmdos_cutoff(ity)
                !write(f_bak_parsec_in,*) 'atomic_radius', p_pot_rws(ity)

                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin electron_per_orbital'
                if (p_pot_nlocp(ity) > 0) then
                        write(f_bak_parsec_in,*) &
                                (p_pot_eleatm(ity,i), i=1,p_pot_nlocp(ity))
                endif
                write(f_bak_parsec_in,*) 'end electron_per_orbital'
                write(f_bak_parsec_in,*)

                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin atom_coord'
                do i = 1, clust_natmi(ity)
                        natom = natom + 1
                        write(f_bak_parsec_in,'(3(f20.12,1x),i2)') &
                                atom_coord(:,natom), tmove(natom)
                enddo
                write(f_bak_parsec_in,*) 'end atom_coord'
                write(f_bak_parsec_in,*)

                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin initial_ncl_moment'
                if (ncl) then
                        natom = 0
                        do i = 1, clust_natmi(ity)
                                natom = natom + 1
                                write(f_bak_parsec_in,*) initmag(:,natom)
                        enddo
                endif
                write(f_bak_parsec_in,*) 'end initial_ncl_moment'
                write(f_bak_parsec_in,*)

        enddo  !do ity = 1,naty



        ! ========================
        ! Electronic Parameters
        ! ========================

        write(f_bak_parsec_in,*) 'restart_run', restart_run
        write(f_bak_parsec_in,*) 'states_num', nstate
        write(f_bak_parsec_in,*) 'net_charges', ncharge
        write(f_bak_parsec_in,*) 'fermi_temp', tfermi
        write(f_bak_parsec_in,*) 'correlation_type ', trim(correlation_type)
        write(f_bak_parsec_in,*) 'use_libxc', use_libxc
        write(f_bak_parsec_in,*) 'func_id_x', func_id(1)
        write(f_bak_parsec_in,*) 'func_id_c', func_id(2)
        write(f_bak_parsec_in,*) 'ion_energy_diff', dioniz
        write(f_bak_parsec_in,*) 'spin_polarization', spin_polarization
        write(f_bak_parsec_in,*) 'symmetrize_charge_density', chsym
        write(f_bak_parsec_in,*) 'add_point_charges', has_ptchrg
        write(f_bak_parsec_in,*) 'point_typ_num', npttyp
        write(f_bak_parsec_in,*) 'add_charged_sheets', has_charged_sheet
        write(f_bak_parsec_in,*) 'num_charged_sheets', number_charged_sheet_type
        write(f_bak_parsec_in,*) 'external_mag_field', mag_field
        write(f_bak_parsec_in,*) 'orb_mag', orb_mag

        ! For each point charge type:
        nptchrg = 0
        do ipttyp = 1, npttyp
                write(f_bak_parsec_in,*) 'pt_chg', clust_qpt(ipttyp)

                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin point_coord'
                do i = 1, clust_nptt(ipttyp)
                        nptchrg = nptchrg + 1
                        write(f_bak_parsec_in,*) ptchrg_coord(:,nptchrg)
                enddo
                write(f_bak_parsec_in,*) 'end point_coord'
                write(f_bak_parsec_in,*)
        enddo

        ! For each charged sheet type:
        number_charged_sheets = 0
        do icharged_sheet_type = 1, number_charged_sheet_type

                write(f_bak_parsec_in,*) 'sheet_charge', &
                        clust_sheet_charge_of_type(icharged_sheet_type)
                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin sheet_coord'
  
  
                do i = 1, clust_number_charged_sheets_per_type( &
                        icharged_sheet_type)

                        number_charged_sheets =  &
                                number_charged_sheets + 1

                        write(f_bak_parsec_in,*) &
                                sheetchrg_coord(:,number_charged_sheets)
                enddo

                write(f_bak_parsec_in,*) 'end sheet_coord'
                write(f_bak_parsec_in,*)
        enddo



        ! ========================
        ! Wave Functions and k-points
        ! ========================

        write(f_bak_parsec_in,*) 'kpoint_method ', trim(kpoint_method)

        ! Here is we print out 'cartesian_inverse_bohr' because we
        ! have converted the kpoints into those in this unit
        write(f_bak_parsec_in,*) 'kpoint_unit ', 'cartesian_inverse_bohr'


        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin monkhorst_pack_grid'
        if (pbc_per > 0) then
                write(f_bak_parsec_in,*) elec_st_mpgrid(1:pbc_per)
        endif
        write(f_bak_parsec_in,*) 'end monkhorst_pack_grid'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin monkhorst_pack_shift'
        if (pbc_per > 0) then
                write(f_bak_parsec_in,*) elec_st_mpshift(1:pbc_per)
        endif
        write(f_bak_parsec_in,*) 'end monkhorst_pack_shift'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin kpoint_list'
        ! KHL: do not output when using Monkhorst-Pack because
        !      elec_st_nkpt is 1 but elec_st_kpts(:,:) is not defined
        if (elec_st_kptmethod == KP_MANUAL) then
                do i = 1, elec_st_nkpt
                        write(f_bak_parsec_in,*) &
                                elec_st_kpts(1:3,i), elec_st_kpwt(i)
                enddo
        endif
        write(f_bak_parsec_in,*) 'end kpoint_list'
        write(f_bak_parsec_in,*)



        ! ========================
        ! Band Structure and Density of States
        ! ========================

        write(f_bak_parsec_in,*) 'bandstruc_points', band_st_npoints
        write(f_bak_parsec_in,*) 'bands_ff_maxiter', bands_ff_maxiter
        write(f_bak_parsec_in,*) 'create_dos', create_dos
        write(f_bak_parsec_in,*) 'dos_pnum', dos_pnum

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin bandstruc'
        do i = 1, band_st_nlines
                ! KHL: the length limit of ESDF (llength) is 80
                write(f_bak_parsec_in,'(i2,1x,6(f9.6,1x),a)') &
                        band_st_blines(i)%line_num, &
                        band_st_blines(i)%start(1:3), &
                        band_st_blines(i)%end(1:3), &
                        trim(band_st_blines(i)%line_name)
        enddo
        write(f_bak_parsec_in,*) 'end bandstruc'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin dos_mp_grid'
        if (create_dos) then
                write(f_bak_parsec_in,*) dos_mpgrid(1:pbc_per)
        endif
        write(f_bak_parsec_in,*) 'end dos_mp_grid'
        write(f_bak_parsec_in,*)


        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin dos_mp_shift'
        if (create_dos) then
                write(f_bak_parsec_in,*) dos_mpshift(1:pbc_per)
        endif
        write(f_bak_parsec_in,*) 'end dos_mp_shift'
        write(f_bak_parsec_in,*)






        ! ========================
        ! Non-self Consistent Calculations and BerkeleyGW Interface
        ! ========================

        ! Here is we print out 'cartesian_inverse_bohr' because we
        ! have converted the kpoints into those in this unit
        write(f_bak_parsec_in,*) 'nscf_kpoint_unit ', 'cartesian_inverse_bohr'

        write(f_bak_parsec_in,*) 'nscf_states_num', nscf_nstate
        write(f_bak_parsec_in,*) 'nscf_fermi_level', elec_st_efermi
        write(f_bak_parsec_in,*) 'output_gw', outputgw

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin nscf_kpoints'
        do i = 1, nscf_nkpt
                write(f_bak_parsec_in,*) nscf_kpts(1:3,i), nscf_kpwt(i)
        enddo
        write(f_bak_parsec_in,*) 'end nscf_kpoints'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin nscf_kgrid'
        if (outputgw .and. nscf_on) then
                write(f_bak_parsec_in,*) nscf_kgrid(:)
        endif
        write(f_bak_parsec_in,*) 'end nscf_kgrid'
        write(f_bak_parsec_in,*)

        write(f_bak_parsec_in,*)
        write(f_bak_parsec_in,*) 'begin nscf_kgrid_shift'
        if (outputgw .and. nscf_on) then
                write(f_bak_parsec_in,*) nscf_kshift(:)
        endif
        write(f_bak_parsec_in,*) 'end nscf_kgrid_shift'
        write(f_bak_parsec_in,*)






        ! ========================
        ! Structural Relaxation
        ! ========================


        write(f_bak_parsec_in,*) 'minimization ', trim(minimization)
        write(f_bak_parsec_in,*) 'movement_num', move_mxmove
        write(f_bak_parsec_in,*) 'force_min', move_fmin
        write(f_bak_parsec_in,*) 'max_step', move_stepmax
        write(f_bak_parsec_in,*) 'min_step', move_stepmin
        write(f_bak_parsec_in,*) 'bfgs_number_corr', move_mmax
        write(f_bak_parsec_in,*) 'relax_restart', move_is_restart
        !write(f_bak_parsec_in,*) 'write_relax_restart', move_write_restart

        write(f_bak_parsec_in,*) 'filter_restart_after', restart_cheb_after_n

        write(f_bak_parsec_in,*) 'restart_cheb_remained_times', &
                restart_cheb_remained_times

        write(f_bak_parsec_in,*) 'remained_times_atomic_chrg_den', &
                remained_times_atomic_chrg_den





        ! ========================
        ! Molecular Dynamics
        ! ========================

        write(f_bak_parsec_in,*) 'molecular_dynamics', md_is_on
        write(f_bak_parsec_in,*) 'cooling_method ', trim(cooling_method)
        write(f_bak_parsec_in,*) 'tinit', md_tempi
        write(f_bak_parsec_in,*) 't_final', md_tempf
        write(f_bak_parsec_in,*) 't_step', md_step_tmp
        write(f_bak_parsec_in,*) 'time_step', md_time_step
        write(f_bak_parsec_in,*) 'friction_coefficient', md_friction_coef
        write(f_bak_parsec_in,*) 'step_num', md_step_num
        write(f_bak_parsec_in,*) 'restart_mode', md_is_restart
        !write(f_bak_parsec_in,*) 'mol_rng_seed', md_rng_seed
        !write(f_bak_parsec_in,*) 'test_rng', md_use_test_rng

        ! ========================
        ! Polarizability
        ! ========================


        write(f_bak_parsec_in,*) 'polarizability', polarizability
        write(f_bak_parsec_in,*) 'electric_field', electric_field



        ! ========================
        ! MPI Parallelization Options
        ! ========================

        !write(f_bak_parsec_in,*) 'max_taskgroups'
        write(f_bak_parsec_in,*) 'npcol', ngroups


        ! ========================
        ! Flags for Additional Input/Output
        ! ========================

        write(f_bak_parsec_in,*) 'output_all_states', outputallstates
        write(f_bak_parsec_in,*) 'save_intermediate_charge_density', &
                save_intermediate_charge_density
        write(f_bak_parsec_in,*) 'output_eigenvalues', output_eigenvalues
        write(f_bak_parsec_in,*) 'save_intermediate_eigenvalues', &
                save_intermediate_eigenvalues
        write(f_bak_parsec_in,*) 'output_level', ipr
        write(f_bak_parsec_in,*) 'output_file_name ', &
                trim(parsec_out_filename)
        write(f_bak_parsec_in,*) 'restart_from_wfndat', readwfndat
        write(f_bak_parsec_in,*) 'use_hdf5', use_hdf5
        write(f_bak_parsec_in,*) 'print_unconverged_density', &
                print_unconverged_density
        write(f_bak_parsec_in,*) 'output_ascii_data', output_ascii_data
        write(f_bak_parsec_in,*) 'potential_field', pot%fex_is
        if (pot%fex_is) then
                write(f_bak_parsec_in,*) 'potential_field_name ', &
                        trim(pot%fex_name)
                write(f_bak_parsec_in,*) 'kinetic_energy_functional ', &
                        trim(fdet_kinetic_functional)
                write(f_bak_parsec_in,*) 'pbe_m', pot%vum
                write(f_bak_parsec_in,*) 'pbe_k', pot%vuk
        endif
        write(f_bak_parsec_in,*) 'thread_random_init', thread_random_init
        write(f_bak_parsec_in,*) 'output_data', enable_data_out
        write(f_bak_parsec_in,*) 'calculate_force', calculate_force

        if (.not. outputallstates .and. elec_st_nsave /= -1) then
                ! KHL: Here elec_st_nsave == -1 has its meaning
                !      (no save_wfn_bands block), and is different from 
                !      elec_st_nsave == 0 (save_wfn_bands exists but 
                !      no lines)
                write(f_bak_parsec_in,*)
                write(f_bak_parsec_in,*) 'begin save_wfn_bands'
                do i = 1, elec_st_nsave
                        write(f_bak_parsec_in,*) elec_st_indxsave(i)
                enddo
                write(f_bak_parsec_in,*) 'end save_wfn_bands'
                write(f_bak_parsec_in,*)
        endif

        write(f_bak_parsec_in,*) 'output_grid_data ', &
                trim(output_grid_data_copy)



        ! ========================
        ! to be sorted
        ! ========================

        write(f_bak_parsec_in,*) 'calc_hartree_g', explicit_hartree_pbc
        write(f_bak_parsec_in,*) 'ylm_dos_l', pbc_ylmdos_l
        write(f_bak_parsec_in,*) 'non_collinear_magnetism', ncl
        write(f_bak_parsec_in,*) 'van_der_waals', do_vdw
        write(f_bak_parsec_in,*) 'hf_one', hirsh_cell_total(1,1)
        write(f_bak_parsec_in,*) 'hf_two', hirsh_cell_total(1,2)
        write(f_bak_parsec_in,*) 'hf_three', hirsh_cell_total(1,3)
        write(f_bak_parsec_in,*) 'use_old_forces', use_old_forces








        close(f_bak_parsec_in)



end subroutine write_out_parameters





 
   
end subroutine usrinput




end module io_module
