!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  This subroutine reads grid, potential, wave function, energy
!  levels, etc, from a previous calculation, as stored in parsec.dat,
!  for restart purposes.
!  Extrapolation (i.e., reshaping of charge density, and wave
!  functions) is always done, although it is only relevant if
!  periodic boundary conditions are not used and the previous
!  parsec.dat refer to a calculation with smaller enclosing sphere.
!
!---------------------------------------------------------------
subroutine hdf5_restart_run(parallel, elec_st, grid, pbc, pot, solver, &
        mixer, iunit, ixtrpflg, ierr)

use constants
use parallel_data_module
use electronic_struct_module
use grid_module
use pbc_module
use potential_module
use eigen_solver_module
use mixer_module
use eigval_module

#ifdef USE_HDF5
use hdf5
#endif

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, mpi_info_null, &
        mpi_logical
#else
use mpi
#endif
#endif

implicit none

!  Input/Output variables:

type(parallel_data), intent(inout) :: parallel
type(electronic_struct), intent(inout) :: elec_st
type(grid_data), intent(in) :: grid
type(pbc_data), intent(in) :: pbc
type(potential), intent(inout) :: pot 
type(eigen_solver), intent(inout) :: solver
type(mixer_data), intent(inout) :: mixer

!  distributed self-consistent potential and electron density
!  (passed outside the structure to overcome a bug with the IBM compiler)
!real(dp), dimension(parallel%mydim,elec_st%nspin), intent(out) :: vold

!real(dp), dimension(parallel%mydim), intent(out) :: vhart


!real(dp), dimension(parallel%mydim,2*elec_st%nspin-1), intent(out) :: rho

!  number of output unit
integer, intent(in) :: iunit

!  flag indicating whether or not extrapolation to a larger sphere
!  size is performed. It is used in the main code for deciding
!  whether or not the Hartree and exchange-correlation potentials
!  need to be calculated upon a restart.
integer, intent(out) :: ixtrpflg

!  compatibility flag: read output to parsec.dat if false; read

!  error flag, 360 < ierr < 381
integer, intent(out) :: ierr

!  Work variables:

!  rank of the master in the above communicator
integer masterid

!  variables for old sphere size, old grid spacing, and
!  old Hamiltonian size from a previous run
real(dp) :: rmaxold, hold(3), avec_old(3,3)
integer ndimold, nwold, nstate_old

!  the following are actually used only when extrapolating from a
!  grid pertaining to a smaller sphere
!  arrays containing 1d->3d grid mapping for the stored data
integer, dimension(:), allocatable :: kxold, kyold, kzold

!  array containing the mapping from the 1d vector of the STORED
!  grid to the 1d vector of the NEW grid
integer, dimension(:), allocatable :: map

!  array for temporary storage of vectors that need to be mapped
!  from the old 1d ordering to the new 1d ordering
real(dp), dimension(:), allocatable :: fnold
complex(dpc), dimension(:), allocatable :: zfnold

!  counters
integer irow, ii, jj, isp
real(dp) :: rtmp

integer :: totdim

!  array for temporary storage of eigenvectors
complex(dpc), allocatable :: zwf(:)
!real(dp), allocatable :: wf(:)

!  actual number of spins used
integer nspin

!  sphere size
real(dp) :: rmax

!  current Hamiltonian size, wedge size
integer ndim, nwedge

integer :: mydim

!  allocation check
integer alcstat

!  date label on parsec.dat file
character(len=26) :: datelabel

!  counters for representations
integer nrep, nrold, irp

!  old character table
integer :: chiold(elec_st%nrep,elec_st%nrep)

!  flags for type of system
!  stype(1) = number of spins
!  stype(2) = 0 : real wavefunctions
!  stype(2) = 1 : complex wavefunctions
!  stype(3) = 0 : confined system
!  stype(3) = 1 : system periodic on all directions
integer stype(10)

! tolerance threshold
real(dp), parameter :: tol = 1.d-10

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

!  kpoint variables
integer kpnum, kpold, kplp

!  coordinates of each kpoint
real(dp), dimension(:,:), allocatable :: kpts
!real(dp) :: kp_diff(3)

!  true if there is mismatch between kpoints in parsec.dat and kpoints
!  in memory
!logical :: kpt_mismatch

#ifdef USE_HDF5
integer(HID_T) :: file_id, dset_id, dset_id2, plist_id, attr_id, &
    atype_id, filespace, memspace

character(len=5) :: isp_string, kplp_string, irp_string
integer(HSSIZE_T), dimension(2) :: offset

integer(HSIZE_T), dimension(2) :: adims, fdims, chunk_dims, &
    count, stride, block

integer :: chunk_rank, frank, hdferr, istate

!logical, dimension(:,:,:), allocatable :: is_isp_info_read, &
!    is_kplp_isp_info_read

real(dp), dimension(parallel%mydim) :: wfn_re, wfn_im

integer :: nstates_loc, offset_nstates

#endif

!---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif


#ifdef USE_HDF5

jj = 0
kpnum = max(elec_st%nkpt, 1)
nspin = elec_st%nspin
rmax = grid%rmax
ndim = grid%ndim
mydim = parallel%mydim
nwedge = grid%nwedge
masterid = parallel%masterid
nrep = elec_st%nrep
ierr = 0

!if (nspin * kpnum * nrep == 1 .and. parallel%groups_num > 1) then
!        parallel%mygroup = 0
!end if


!allocate(is_isp_info_read(elec_st%nrep,kpnum,elec_st%nspin))
!is_isp_info_read(:,:,:) = .FALSE.
!allocate(is_kplp_isp_info_read(elec_st%nrep,kpnum,elec_st%nspin))
!is_kplp_isp_info_read(:,:,:) = .FALSE.

call h5open_f(hdferr)
if (hdferr /= 0) then
        write(9, *) 'h5_restart_run: error in h5open_f'
end if

call h5pcreate_f(h5p_file_access_f, plist_id, hdferr)
#ifdef WITH_MPI_F08
call h5pset_fapl_mpio_f(plist_id, comm_f08%mpi_val, &
        mpi_info_null%mpi_val, hdferr)
#else
call h5pset_fapl_mpio_f(plist_id, comm_f08, &
        mpi_info_null, hdferr)
#endif
call h5fopen_f('restart.h5', h5f_acc_rdonly_f, file_id, hdferr, &
        access_prp=plist_id)
if (hdferr /= 0) then
        if (parallel%iammaster) then
                write(7,*) 'ERROR: restart.h5 file not found.'
                write(7,*) 'Stop in restart_run.'
        end if
        ierr = 371
        goto 14
end if
call h5pclose_f(plist_id, hdferr)

call h5tcopy_f(h5t_native_character, atype_id, hdferr)
call h5tset_size_f(atype_id, int(26, HSIZE_T), hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/details', 'date', attr_id, hdferr, &
        h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, atype_id, datelabel, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(size(stype(:),1), hsize_t)
call h5aopen_by_name_f(file_id, '/details', 'stype(:)', attr_id, hdferr, &
        h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, stype(:), adims, hdferr)
call h5aclose_f(attr_id, hdferr)

!  Read the old grid spacing, sphere size, Hamiltonian size.
!read(iunit) datelabel

if (parallel%iammaster) then
        write(7,*)
        write(7,*) 'Restarting from previous run'
        write(7,*) '----------------------------'
        write(7,*)
        write(7,*) ' restart.h5 file created on   ', datelabel
        write(7,*)
end if

if (stype(1) /= nspin) then
        if (parallel%iammaster) then
                write(7, *)
                write(7, *) 'ERROR: stored number of spins is incorrect, ', &
                        stype(1), nspin
                write(7, *) 'STOP in restart_run.'
        end if
        ierr = 361
        goto 14
end if

if ((elec_st%cplx .and. stype(2) == 0) .or. &
        (.not. elec_st%cplx .and. stype(2) == 1)) then
        if (parallel%iammaster) then
                write(7, *)
                write(7, *) 'ERROR: complex algebra incorrect, ', &
                        stype(2), elec_st%cplx
                write(7, *) 'STOP in restart_run.'
        end if
        ierr = 362
        goto 14
end if

if (stype(2) == 2) elec_st%is_so = .true.

select case(pbc%per)
case(0)
        jj = 0
case(1)
        jj = 2
case(2)
        jj = 3
case(3)
        jj = 1
end select

if (stype(3) /= jj) then
        if (parallel%iammaster) then
                write(7, *)
                write(7, *) 'ERROR: boundary conditions are incorrect, ', &
                        stype(3), pbc%is_on
                write(7, *) 'STOP in restart_run.'
        end if
        ierr = 363
        goto 14
end if

adims(1) = int(size(grid%step(:),1), HSIZE_T)
call h5aopen_by_name_f(file_id, '/grid', 'grid%step(:)', attr_id, &
        hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_double, hold(:), adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/grid', 'grid%rmax', attr_id, &
        hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_double, rmaxold, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/elec_st', 'elec_st%nkpt', attr_id, &
        hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, kpold, adims, hdferr)
call h5aclose_f(attr_id, hdferr)


if (pbc%is_on) then
    adims(:) = int(shape(pbc%latt_vec(:,:)), HSIZE_T)
    call h5aopen_by_name_f(file_id, '/grid', 'pbc%latt_vec(:,:)', &
        attr_id, hdferr, h5p_default_f, h5p_default_f)
    call h5aread_f(attr_id, h5t_native_double, avec_old(:,:), adims, &
        hdferr)
    call H5Aclose_f(attr_id, hdferr)

    ! Sanity tests.
    hold(:) = hold(:) - grid%step(:)
    avec_old(:,:) = avec_old(:,:) - pbc%latt_vec(:,:)
    if (maxval(abs(hold)) > tol) then
        write(7,*)
        write(7,*) 'ERROR: stored grid spacing conflicts with'
        write(7,*) 'current grid spacing'
        write(7,*) hold + grid%step
        write(7,*) grid%step(1:3)
        write(7,*) 'STOP in restart_run.'
        ierr = 364
        goto 14
    elseif (maxval(abs(avec_old)) > tol) then
        write(7,*)
        write(7,*) 'ERROR: the size of the supercell conflicts'
        write(7,*) 'with the stored one'
        write(7,*) avec_old + pbc%latt_vec
        write(7,*) pbc%latt_vec
        write(7,*) 'STOP in restart_run.'
        ierr = 365
        goto 14
    endif
else
    kpold = 1

    if (hold(1) /= grid%step(1)) then
        if (parallel%iammaster) then
            write(7,*)
            write(7,*) 'ERROR: stored grid spacing conflicts with'
            write(7,*) 'current grid spacing'
            write(7,*) hold(1), grid%step(1)
            write(7,*) 'STOP in restart_run.'
            ierr = 366
        end if
        goto 14
    endif
endif

allocate(kpts(3,kpold))

call h5pcreate_f(h5p_dataset_xfer_f, plist_id, hdferr)
call h5pset_dxpl_mpio_f(plist_id, h5fd_mpio_independent_f, hdferr)

fdims(1) = int(3, HSIZE_T)
fdims(2) = int(kpold, HSIZE_T)
call h5dopen_f(file_id, '/elec_st/elec_st%kpts(:,:)', dset_id, hdferr)
call h5dread_f(dset_id, h5t_native_double, kpts(:,:), fdims, hdferr, &
    xfer_prp=plist_id)
call h5dclose_f(dset_id, hdferr)

call h5pclose_f(plist_id, hdferr)

! ----------------------

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/grid', 'grid%ndim', attr_id, &
    hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, ndimold, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/grid', 'grid%nwedge', attr_id, &
    hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, nwold, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/elec_st', 'elec_st%nrep', attr_id, &
    hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, nrold, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, '/elec_st', 'elec_st%efermi', attr_id, &
    hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_double, elec_st%efermi, adims, hdferr)
call h5aclose_f(attr_id, hdferr)


if (mixer%name == ANDERSON) then
        mixer%istart = .true.

        adims(1) = int(1, hsize_t)
        call h5aopen_by_name_f(file_id, '/mixer', 'mixer%stored_memory', &
                attr_id, hdferr, h5p_default_f, h5p_default_f)
        call h5aread_f(attr_id, h5t_native_integer, &
                mixer%old_stored_memory, adims, hdferr)
        call h5aclose_f(attr_id, hdferr)
endif



!  If the trend of the Hamiltonian size is inconsistent with the
!  trend of the sphere size - complain and quit.
if (pbc%per == 3) then
    rmax = rmaxold
end if

if ((rmax == rmaxold) .and. &
    ((ndim /= ndimold) .or. (nwedge /= nwold))) then
    if (parallel%iammaster) then
        write(7,*) 'ERROR: Despite using the same grid spacing'
        write(7,*) 'and sphere size, the stored Hamiltonian size is'
        write(7,*) 'incompatible with the current one. Something'
        write(7,*) 'is seriously wrong. Good luck!'
        write(7,*) 'STOP in restart_run.'
        write(7,*) rmax,rmaxold,ndim,ndimold,nwedge,nwold
    end if
    ierr = 367
    goto 14
elseif ((rmax > rmaxold) .and. &
        ((ndim < ndimold) .or. (nwedge < nwold))) then
    if (parallel%iammaster) then
        write(7,*) 'ERROR: Despite using the same grid spacing'
        write(7,*) 'and a larger sphere size, the stored Hamiltonian'
        write(7,*) 'size is smaller than the current one. Something'
        write(7,*) 'is seriously wrong. Good luck!'
        write(7,*) 'STOP in restart_run.'
        write(7,*) rmax,rmaxold,ndim,ndimold,nwedge,nwold
    end if
    ierr = 368
    goto 14
endif

!  Check if number of representations matches.
if (nrold /= nrep) then
    if (parallel%iammaster) then
        write(7,*)
        write(7,*) 'ERROR: number of irreducible representations'
        write(7,*) 'does not match. ',nrold,nrep
        write(7,*) 'STOP in restart_run.'
    end if
    ierr = 369
    goto 14
endif


!  Read previous character table and compares it with the current
!  one; skip additional information about symmetries.
do irp = 1, nrold
    WRITE(irp_STRING, '(I5.5)') irp

    adims(1) = int(size(chiold(:,irp),1), hsize_t)
    call h5aopen_by_name_f(file_id, '/rsymm/irp'//irp_string, &
        'rsymm%chi(:,irp)', attr_id, hdferr, h5p_default_f, h5p_default_f)
    call h5aread_f(attr_id, h5t_native_integer, chiold(:,irp), adims, &
        hdferr)
    call h5aclose_f(attr_id, hdferr)
end do

chiold = chiold - elec_st%chi
ii = minval(chiold)
jj = maxval(chiold)
if (ii /= 0 .or. jj /= 0) then
    if (parallel%iammaster) then
        write(7,*)
        write(7,*) 'ERROR: character table does not match'
        write(7,*) chiold
        write(7,*) elec_st%chi
    end if
    ierr = 370
    goto 14
endif

14 continue

!  Done with sanity checks, send flag to other PEs.
#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, masterid, comm_f08, mpinfo)
#endif
if (ierr /= 0) then
    return
end if

! If restarting from spin-orbit calculation, update flags and array sizes.
#ifdef MPI
call mpi_bcast(elec_st%is_so, 1, mpi_logical, masterid, comm_f08, mpinfo)
#endif

if (elec_st%is_so) then
    elec_st%cplx = .true.
    elec_st%so_pert = .false.
    elec_st%mxwd = 2
    nspin = 1

    if (parallel%iammaster) then
        if (allocated(parallel%zftmp)) deallocate(parallel%zftmp)

        allocate(parallel%zftmp(grid%nwedge*elec_st%mxwd),stat=alcstat)
        call alccheck('parallel%zftmp', grid%nwedge*elec_st%mxwd, alcstat)
    endif

    elec_st%nstate = 2 * elec_st%nstate
    jj = (solver%winsize + elec_st%nstate)*elec_st%nrep
    deallocate(elec_st%irep)
    allocate(elec_st%irep(jj,kpnum,elec_st%nspin))
endif

if (elec_st%cplx) then
    allocate(zwf(parallel%mydim*elec_st%mxwd),stat=alcstat)
    call alccheck('zwf', parallel%mydim*elec_st%mxwd, alcstat)
else
    !allocate(wf(nwedge),stat=alcstat)
    !call alccheck('wf', nwedge, alcstat)
endif

allocate(kxold(nwold),stat=alcstat)
call alccheck('kxold', nwold, alcstat)
allocate(kyold(nwold),stat=alcstat)
call alccheck('kyold', nwold, alcstat)
allocate(kzold(nwold),stat=alcstat)
call alccheck('kzold', nwold, alcstat)
allocate(map(nwold),stat=alcstat)
call alccheck('map', nwold, alcstat)
map(:) = 0

!allocate(fnold(nwold),stat=alcstat)
!call alccheck('fnold', nwold, alcstat)

if (elec_st%cplx) then
    allocate(zfnold(nwold*elec_st%mxwd),stat=alcstat)
    call alccheck('zfnold', nwold*elec_st%mxwd, alcstat)
endif

!rho(:,:) = zero
!vold(:,:) = zero

! === Read in grid%kx, grid%ky, and grid%kz ===

! Define the filespace (size of the dataset)
frank = 2
fdims(1) = int(nwold, hsize_t)
fdims(2) = int(1, hsize_t)
call h5screate_simple_f(frank, fdims, filespace, hdferr)

! Define the memspace (size of the data in memory (for each process))
chunk_rank = 2
chunk_dims(1) = int(nwold, hsize_t)
chunk_dims(2) = int(1, hsize_t)
call h5screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

offset(1) = int(0, hssize_t)
offset(2) = int(0, hssize_t)
count(1) = int(1, hsize_t)
count(2) = int(1, hsize_t)
block(1) = chunk_dims(1)
block(2) = chunk_dims(2)
stride(1) = int(1, hsize_t)
stride(2) = int(1, hsize_t)

call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, &
    hdferr, stride, block)

call h5pcreate_f(h5p_dataset_xfer_f, plist_id, hdferr)
call h5pset_dxpl_mpio_f(plist_id, h5fd_mpio_independent_f, hdferr)

call h5dopen_f(file_id, '/grid/grid%kx(:)', dset_id, hdferr)
call h5dread_f(dset_id, h5t_native_integer, kxold, fdims, hdferr, &
    file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
call h5dclose_f(dset_id, hdferr)

call h5dopen_f(file_id, '/grid/grid%ky(:)', dset_id, hdferr)
call h5dread_f(dset_id, h5t_native_integer, kyold, fdims, hdferr, &
    file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
call h5dclose_f(dset_id, hdferr)

call h5dopen_f(file_id, '/grid/grid%kz(:)', dset_id, hdferr)
call h5dread_f(dset_id, h5t_native_integer, kzold, fdims, hdferr, &
    file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
call h5dclose_f(dset_id, hdferr)

call h5pclose_f(plist_id, hdferr)
call h5sclose_f(memspace, hdferr)
call h5sclose_f(filespace, hdferr)

!  Set extrapolation flag to zero.
ixtrpflg = 0

if (rmax /= rmaxold) then
    ! If current sphere larger or smaller than stored one, extrapolation
    ! is necessary. Write a warning to parsec.out, and set the
    ! extrapolation flag to one.
    if (parallel%iammaster) then
        write(7,*)
        write(7,*) 'WARNING: Extrapolating an initial guess based on'
        write(7,*) 'stored data for a sphere of radius ', rmaxold, '.'
        write(7,*)
    end if
    ixtrpflg = 1
endif

!  Compute the map for converting the order in the stored vectors
!  to the order needed for the present vectors, by converting from
!  1d to 3d "old style" and converting back from 3d to 1d using
!  the current indexg map. Must skip grid points outside the boundary
!  sphere if old radius is bigger than current radius.
do ii = 1, nwold
    hold(1) = ( kxold(ii) + grid%shift(1) )*grid%step(1)
    hold(2) = ( kyold(ii) + grid%shift(2) )*grid%step(2)
    hold(3) = ( kzold(ii) + grid%shift(3) )*grid%step(3)
    hold(1:pbc%per) = zero
    rtmp = sqrt(dot_product(hold,hold))
    if (rtmp > rmax) cycle
    jj = grid%indexw(kxold(ii),kyold(ii),kzold(ii))
    if (jj > 0 .and. jj <= nwedge) map(ii) = jj
enddo

#ifdef MPI
call MPI_BCAST(ixtrpflg, 1, MPI_INTEGER, parallel%masterid, comm_f08, mpinfo)
!call MPI_BCAST(kpold, 1, MPI_INTEGER, parallel%masterid, &
!                parallel%comm, mpinfo)
#endif

adims(1) = int(1, hsize_t)
call h5aopen_by_name_f(file_id, "/elec_st", "elec_st%nstate", attr_id, &
    hdferr, h5p_default_f, h5p_default_f)
call h5aread_f(attr_id, h5t_native_integer, nstate_old, adims, hdferr)
call h5aclose_f(attr_id, hdferr)

!  Start the main loop over spin, where eigenvalues, eigenvectors,
!  representations and occupancy factors are read from each state.
!  If eigenstate structures are not defined, skip eigenvalues/vectors
!  and keep only potentials and charge density.

call h5pcreate_f(h5p_dataset_xfer_f, plist_id, hdferr)
call h5pset_dxpl_mpio_f(plist_id, h5fd_mpio_independent_f, hdferr)

!write(9,*) 'parallel%iam', parallel%iam
!write(9,*) 'is_isp_info_read(:,:,:)', is_isp_info_read(:,:,:)
!do isp = 1, nspin
!    do kplp = 1, kpold
!        do irp = 1, size(elec_st%eig(:,kplp,isp),1)
!            write(9,*) 'is_isp_info_read(irp,kplp,isp)', is_isp_info_read(irp,kplp,isp)
!        end do
!    end do
!end do

do isp = 1, nspin
        write(isp_string, '(I5.5)') isp

        jj = isp - 1 + nspin

        do kplp = 1, kpnum
                write(kplp_string, '(I5.5)') kplp

                !  If this k-point is not in the current set, skip eigenvalues etc.
                !kpt_mismatch = .false.
                !if (parallel%iammaster .and. elec_st%nkpt > 0 ) then
                !    kp_diff = kpts(:,kplp) - elec_st%kpts(:,kplp)
                !    if (maxval(abs(kp_diff)) > tol) then
                !        kpt_mismatch = .true.
                !        !read(iunit)
                !        !read(iunit)
                !        !read(iunit)
                !    else
                !        kpt_mismatch = .false.
                !    endif
                !endif
#ifdef MPI
                !call MPI_BCAST(kpt_mismatch, 1, MPI_LOGICAL, masterid, comm, mpinfo)
#endif
                !if (kpt_mismatch) then
                !    if (parallel%iammaster) then
                !        do ii = 1, 3
                !            read(iunit)
                !        enddo
                !    endif
                !    cycle
                !endif

                do irp = 1, size(elec_st%eig(:,kplp,isp), 1)
                        write(irp_string, '(I5.5)') irp

                        elec_st%eig(irp,kplp,isp)%nn = &
                                elec_st%nstate / elec_st%nrep
                        
                        if (elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                parallel%mytaskgroup) then
                                call eig_e_adj_size( &
                                        elec_st%eig(irp,kplp,isp), &
                                        elec_st%eig(irp,kplp,isp)%nn)
                                cycle
                        end if

                        !  Check if number of representations matches.
                        if (mod(elec_st%eig(irp,kplp,isp)%nn,parallel%npcol) /= 0) then
                            if (parallel%iammaster) then
                                write(7,*)
                                write(7,*) 'ERROR: number of states cannot be divided by npcol'
                                write(7,*) 'nstates', elec_st%eig(irp,kplp,isp)%nn, 'npcol', parallel%npcol
                                write(7,*) 'STOP in restart_run.'
                            endif
                            ierr = -1
                            goto 14
                        endif

                        call eig_adj_size(eigen=elec_st%eig(irp,kplp,isp), &
                                ldn=parallel%ldn, &
                                new_nstates_per_colgroup=&
                                        elec_st%eig(irp,kplp,isp)%nn/parallel%npcol, &
                                winsize=0, &
                                npcol=parallel%npcol, &
                                cplx=elec_st%cplx)



                        ! ========================
                        ! Real in mixer
                        ! ========================

                        if (mixer%name == ANDERSON) then
                                totdim = mixer%ndim*mixer%nspin

                                ! Create a selection on filespace
                                frank = 2
                                fdims(1) = int(nwold*mixer%nspin, hsize_t)
                                fdims(2) = int(mixer%old_stored_memory, &
                                        hsize_t)
                                call h5screate_simple_f(frank, fdims, &
                                        filespace, hdferr)

                                ! Create a selection on memspace
                                chunk_rank = 2
                                chunk_dims(1) = int(totdim, hsize_t)
                                chunk_dims(2) = int(1, hsize_t)
                                call h5screate_simple_f(chunk_rank, &
                                        chunk_dims, &
                                        memspace, hdferr)

                                ! Read in mixer%xinold(:,:)
                                count(1) = int(1, hsize_t)
                                count(2) = int(1, hsize_t)
                                block(1) = chunk_dims(1)
                                block(2) = chunk_dims(2)
                                stride(1) = int(1, hsize_t)
                                stride(2) = int(1, hsize_t)
                                offset(1) = &
int(mixer%nspin*(parallel%irows(parallel%colgroup_iam)-1), HSSIZE_T)

                                call h5dopen_f(file_id, &
                                        "/mixer/mixer%xinold(:,:)", &
                                        dset_id, hdferr)

                                do ii = 1, mixer%old_stored_memory
                                        offset(2) = int(ii-1, HSSIZE_T)

                                        call h5sselect_hyperslab_f( &
                                                filespace, &
                                                h5s_select_set_f, &
                                                offset, &
                                                count, hdferr, stride, block)
                                        call h5dread_f(dset_id, &
                                                h5t_native_double, &
                                                mixer%xinold(:,ii), &
                                                fdims, hdferr, &
                                                file_space_id=filespace, &
                                                mem_space_id=memspace, &
                                                xfer_prp=plist_id)
                                enddo

                                call h5dclose_f(dset_id, hdferr)



                                ! Read in mixer%xoutold(:,:)
                                call h5dopen_f(file_id, &
                                        "/mixer/mixer%xoutold(:,:)", &
                                        dset_id, hdferr)

                                do ii = 1, mixer%old_stored_memory
                                        offset(2) = int(ii-1, HSSIZE_T)

                                        call h5sselect_hyperslab_f( &
                                                filespace, &
                                                h5s_select_set_f, &
                                                offset, &
                                                count, hdferr, stride, block)
                                        call h5dread_f(dset_id, &
                                                h5t_native_double, &
                                                mixer%xoutold(:,ii), &
                                                fdims, hdferr, &
                                                file_space_id=filespace, &
                                                mem_space_id=memspace, &
                                                xfer_prp=plist_id)
                                enddo

                                call h5dclose_f(dset_id, hdferr)




                                call h5sclose_f(memspace, hdferr)
                                call h5sclose_f(filespace, hdferr)

                        endif

















                        ! Create a selection on filespace
                        frank = 2
                        fdims(1) = int(nwold, hsize_t)
                        fdims(2) = int(1, hsize_t)
                        call h5screate_simple_f(frank, fdims, &
                                filespace, hdferr)

                        ! Create a selection on memspace
                        chunk_rank = 2
                        chunk_dims(1) = int(mydim, hsize_t)
                        chunk_dims(2) = int(1, hsize_t)
                        call h5screate_simple_f(chunk_rank, chunk_dims, &
                                memspace, hdferr)

                        ! Read in pot%vhart(:)
                        offset(1) = int( &
                                parallel%irows(parallel%colgroup_iam)-1, &
                                hssize_t)
                        offset(2) = int(0, hssize_t)
                        count(1) = int(1, hsize_t)
                        count(2) = int(1, hsize_t)
                        block(1) = chunk_dims(1)
                        block(2) = chunk_dims(2)
                        stride(1) = int(1, hsize_t)
                        stride(2) = int(1, hsize_t)
                        call h5sselect_hyperslab_f(filespace, &
                                h5s_select_set_f, offset, &
                                count, hdferr, stride, block)
                        call h5dopen_f(file_id, "/pot/pot%vhart(:)", &
                                dset_id, hdferr)
                        call h5dread_f(dset_id, h5t_native_double, &
                                pot%vhart(:), fdims, hdferr, &
                                file_space_id=filespace, &
                                mem_space_id=memspace, xfer_prp=plist_id)
                        call h5dclose_f(dset_id, hdferr)

                        ! Read in pot%vold(:,:)
                        offset(1) = int( &
                                parallel%irows(parallel%colgroup_iam)-1, &
                                hssize_t)
                        offset(2) = int(isp-1, hssize_t)
                        count(1) = int(1, hsize_t)
                        count(2) = int(1, hsize_t)
                        block(1) = chunk_dims(1)
                        block(2) = chunk_dims(2)
                        stride(1) = int(1, hsize_t)
                        stride(2) = int(1, hsize_t)
                        call h5sselect_hyperslab_f(filespace, &
                                h5s_select_set_f, offset, &
                                count, hdferr, stride, block)
                        call h5dopen_f(file_id, "/pot/pot%vnew(:,:)", &
                                dset_id, hdferr)
                        call h5dread_f(dset_id, h5t_native_double, &
                                pot%vold(:,isp), fdims, hdferr, &
                                file_space_id=filespace, &
                                mem_space_id=memspace, xfer_prp=plist_id)
                        call h5dclose_f(dset_id, hdferr)

                        ! Read in elec_st%rho(:,:)
                        offset(1) = int( &
                                parallel%irows(parallel%colgroup_iam)-1, &
                                hssize_t)
                        offset(2) = int(jj-1, hssize_t)
                        count(1) = int(1, hsize_t)
                        count(2) = int(1, hsize_t)
                        block(1) = chunk_dims(1)
                        block(2) = int(1, hsize_t)
                        stride(1) = int(1, hsize_t)
                        stride(2) = int(1, hsize_t)
                        call h5sselect_hyperslab_f(filespace, &
                                h5s_select_set_f, offset, &
                                count, hdferr, stride, block)
                        call h5dopen_f(file_id, "/elec_st/elec_st%rho(:,:)", &
                            dset_id, hdferr)
                        call h5dread_f(dset_id, h5t_native_double, &
                                elec_st%rho(:,jj), &
                                fdims, hdferr, &
                                file_space_id=filespace, &
                                mem_space_id=memspace, xfer_prp=plist_id)
                        call h5dclose_f(dset_id, hdferr)

                        call h5sclose_f(memspace, hdferr)
                        call h5sclose_f(filespace, hdferr)

                        !write(9,*) 'rho(:,jj)', rho(:,jj)
                        !write(9,*) 'vold(:,isp)', vold(:,isp)

                        !call MPI_Barrier(comm, mpinfo)
                        !STOP

                        !is_isp_info_read(:,:,isp) = .TRUE.
                !end if

                        !(.not. is_kplp_isp_info_read(irp,kplp,isp))) then

                        fdims(1) = int(nstate_old, hsize_t)
                        call h5dopen_f(file_id, &
                                "/elec_st/isp"//isp_string//"/kplp"//kplp_string// &
                                '/elec%irep(:,kplp,isp)', dset_id, hdferr)
                        call h5dread_f(dset_id, h5t_native_integer, &
                                elec_st%irep(:,kplp,isp), fdims, hdferr, &
                                xfer_prp=plist_id)
                        call h5dclose_f(dset_id, hdferr)

                        !is_kplp_isp_info_read(:,kplp,isp) = .TRUE.
                !end if

                        !  Update the number of computed states per representation.

                        !  If this representation/spin is assigned to the group of this
                        !  processor, update size of wave-function array.

                        adims(1) = int(1, hsize_t)
                        call h5aopen_by_name_f(file_id, "/elec_st/isp"//isp_string// &
                            "/kplp"//kplp_string//"/irp"//irp_string, &
                            "elec_st%eig(irp,kplp,isp)%nec", attr_id, &
                            hdferr, h5p_default_f, h5p_default_f)
                        call h5aread_f(attr_id, h5t_native_integer, &
                            elec_st%eig(irp,kplp,isp)%nec, adims, hdferr)
                        call h5aclose_f(attr_id, hdferr)
                !end if

#if 0
                if (nspin*kpnum*nrep == 1 .and. parallel%groups_num > 1) then


                        fdims(1) = int(elec_st%eig(irp,kplp,isp)%nec, hsize_t)
                        call H5Dopen_f(file_id, "/elec_st/isp"//isp_string// &
                            "/kplp"//kplp_string//"/irp"//irp_string// &
                            "/elec_st%eig(irp,kplp,isp)%en(:)", dset_id, hdferr)
                        call h5dread_f(dset_id, h5t_native_double, &
                            elec_st%eig(irp,kplp,isp)%en(:), fdims, hdferr, &
                            xfer_prp=plist_id)
                        call h5dclose_f(dset_id, hdferr)

                        frank = 2
                        fdims(1) = int(nwold, hsize_t)
                        fdims(2) = int(elec_st%eig(irp,kplp,isp)%nec, hsize_t)
                        call h5screate_simple_f(frank, fdims, filespace, hdferr)

                        chunk_rank = 2
                        chunk_dims(1) = int(parallel%mydim, hsize_t)
                        chunk_dims(2) = int(1, hsize_t)
                        call h5screate_simple_f(chunk_rank, chunk_dims, memspace, &
                            hdferr)

                        if (elec_st%cplx) then
                        else
                            call h5dopen_f(file_id, &
                                "/elec_st/isp"//isp_string//"/kplp"//kplp_string// &
                                "/irp"//irp_string//"/wavefunctions(:,:)", dset_id, hdferr)

                            parallel%mygroup = parallel%iam / parallel%group_size
                            nstate_loc = elec_st%eig(irp,kplp,isp)%nec / parallel%groups_num
                            offset_nstate = parallel%mygroup * nstate_loc
                            !write(9,*) 'h5_restart_run', parallel%iam, &
                            !    nstate_loc, offset_nstate
                            do istate = 1, nstate_loc

                                offset(1) = int(parallel%irows(parallel%group_iam)-1, hssize_t)
                                offset(2) = int(offset_nstate+istate-1, hsize_t)
                                count(1) = int(1, hsize_t)
                                count(2) = int(1, hsize_t)
                                block(1) = chunk_dims(1)
                                block(2) = chunk_dims(2)
                                stride(1) = int(1, hsize_t)
                                stride(2) = int(1, hsize_t)
                                call h5sselect_hyperslab_f(filespace, h5s_select_set_f, &
                                    offset, count, hdferr, stride, block)

                                call h5dread_f(dset_id, h5t_native_double, &
                                    elec_st%eig(irp,kplp,isp)%wf(:,istate), fdims, hdferr, &
                                    file_space_id=filespace, mem_space_id=memspace, &
                                    xfer_prp=plist_id)
                            end do

                            call h5dclose_f(dset_id, hdferr)
                        end if

                        call h5sclose_f(memspace, hdferr)
                        call h5sclose_f(filespace, hdferr)




            else
#endif
                        if (elec_st%eig(irp,kplp,isp)%nec > 0) then

                                ! Read in elec_st%eig(irp,kplp,isp)%en(:)
                                fdims(1) = int(elec_st%eig(irp,kplp,isp)%nec, hsize_t)
                                call H5Dopen_f(file_id, &
                                        "/elec_st/isp"//isp_string// &
                                        "/kplp"//kplp_string// &
                                        "/irp"//irp_string// &
                                        "/elec_st%eig(irp,kplp,isp)%en(:)", &
                                        dset_id, hdferr)
                                call h5dread_f(dset_id, h5t_native_double, &
                                        elec_st%eig(irp,kplp,isp)%en(:), fdims, &
                                        hdferr, xfer_prp=plist_id)
                                call h5dclose_f(dset_id, hdferr)

                                ! Read in wavefunctions
                                nstates_loc = elec_st%eig(irp,kplp,isp)%nec / &
                                        parallel%npcol
                                offset_nstates = parallel%mycolgroup * nstates_loc

                                frank = 2
                                fdims(1) = int(nwold, hsize_t)
                                fdims(2) = int(elec_st%eig(irp,kplp,isp)%nec, hsize_t)
                                call h5screate_simple_f(frank, fdims, filespace, hdferr)

                                chunk_rank = 2
                                chunk_dims(1) = int(parallel%mydim, hsize_t)
                                chunk_dims(2) = int(1, hsize_t)
                                call h5screate_simple_f(chunk_rank, chunk_dims, &
                                        memspace, hdferr)

                                if (elec_st%cplx) then
                                        call h5dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions_re(:,:)", &
                                                dset_id, hdferr)

                                        call h5dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions_im(:,:)", &
                                                dset_id2, hdferr)

                                        do istate = 1, nstates_loc

                                                offset(1) = int( &
                                                        parallel%irows(parallel%colgroup_iam)-1, &
                                                        hssize_t)
                                                offset(2) = int( &
                                                        offset_nstates+istate-1, &
                                                        hsize_t)
                                                count(1) = int(1, hsize_t)
                                                count(2) = int(1, hsize_t)
                                                block(1) = chunk_dims(1)
                                                block(2) = chunk_dims(2)
                                                stride(1) = int(1, hsize_t)
                                                stride(2) = int(1, hsize_t)
                                                call h5sselect_hyperslab_f( &
                                                        filespace, h5s_select_set_f, &
                                                        offset, count, hdferr, &
                                                        stride, block)

                                                call h5dread_f(dset_id, &
                                                        h5t_native_double, &
                                                        wfn_re(:), fdims, hdferr, &
                                                        file_space_id=filespace, &
                                                        mem_space_id=memspace, &
                                                        xfer_prp=plist_id)

                                                call h5dread_f(dset_id2, &
                                                        h5t_native_double, &
                                                        wfn_im(:), fdims, hdferr, &
                                                        file_space_id=filespace, &
                                                        mem_space_id=memspace, &
                                                    xfer_prp=plist_id)

                                                elec_st%eig(irp,kplp,isp)%zwf(1:parallel%mydim,istate) = &
                                                        cmplx(wfn_re(1:parallel%mydim), wfn_im(1:parallel%mydim), dpc)
                                        end do

                                        call h5dclose_f(dset_id, hdferr)
                                        call h5dclose_f(dset_id2, hdferr)

                                else

                                        call h5dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions(:,:)", &
                                                dset_id, hdferr)

                                        do istate = 1, nstates_loc
                                                offset(1) = int( &
                                                        parallel%irows(parallel%colgroup_iam)-1, &
                                                        hssize_t)
                                                offset(2) = int(offset_nstates+istate-1, hsize_t)
                                                count(1) = int(1, hsize_t)
                                                count(2) = int(1, hsize_t)
                                                block(1) = chunk_dims(1)
                                                block(2) = chunk_dims(2)
                                                stride(1) = int(1, hsize_t)
                                                stride(2) = int(1, hsize_t)
                                                call h5sselect_hyperslab_f(filespace, &
                                                        h5s_select_set_f, &
                                                        offset, count, hdferr, &
                                                        stride, block)

                                                call h5dread_f(dset_id, &
                                                        h5t_native_double, &
                                                        elec_st%eig(irp,kplp,isp)%wf(:,istate), &
                                                        fdims, hdferr, &
                                                        file_space_id=filespace, &
                                                        mem_space_id=memspace, &
                                                        xfer_prp=plist_id)
                                        end do

                                        call h5dclose_f(dset_id, hdferr)
                                end if

                                call h5sclose_f(memspace, hdferr)
                                call h5sclose_f(filespace, hdferr)
                        endif
                end do  ! irp

                !elec_st%ntotal(isp) = sum(elec_st%eig(:,kplp,isp)%nec)
        end do   !do kplp = 1, kpnum
end do   !do isp = 1, nspin

call h5pclose_f(plist_id, hdferr)





!  If spin-orbit potential is present, then the potential and density
!  for the second spin component must be read separately. The loop above
!  goes only over the first spin component.
if (elec_st%is_so) then
    if (parallel%iammaster) then
        read(iunit) (fnold(irow),irow=1,nwold)
        parallel%ftmp(:) = zero
        do irow = 1, nwold
            if (map(irow) /= 0) parallel%ftmp(map(irow)) = fnold(irow)
        enddo
    endif
    call export_function(parallel, pot%vold(1:mydim,2))

    if (parallel%iammaster) then
        read(iunit) (fnold(irow),irow=1,nwold)
        parallel%ftmp(:) = zero
        do irow = 1, nwold
            if (map(irow) /= 0) parallel%ftmp(map(irow)) = fnold(irow)
        enddo
    endif
    call export_function(parallel, elec_st%rho(1:mydim,3))
    !call export_function(parallel, elec_st%rho(1,3))
endif

!elec_st%eig(:,:,:)%nec = 0
elec_st%ntotal(:) = 0

!  If the computation is spin-polarized, construct the total
!  charge density as the sum of the stored up and down charge
!  densities.
if (elec_st%nspin == 2) then
        do irow = 1, parallel%mydim
                elec_st%rho(irow,1) = elec_st%rho(irow,2) + elec_st%rho(irow,3)
        end do
end if

deallocate(kxold, kyold, kzold)
deallocate(map)
deallocate(kpts)

!deallocate(is_isp_info_read)
!deallocate(is_kplp_isp_info_read)

if (elec_st%cplx) then
    deallocate(zfnold)
    deallocate(zwf)
else
    !deallocate(wf)
endif


call h5fclose_f(file_id, hdferr)

call h5close_f(hdferr)
if (hdferr /= 0) then
        write(9, *) 'h5_restart_run: error in h5close_f'
        return
end if



#endif

end subroutine hdf5_restart_run
!===============================================================
