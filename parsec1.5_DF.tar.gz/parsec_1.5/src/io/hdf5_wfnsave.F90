!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  This subroutine saves grid, potential, wave function, energy
!  levels, etc, in parsec.dat file for restarting purposes.
!
!
!  To use this subroutine, one would need (1) HDF5 library and 
!  (2) to define symbol "USE_HDF5". Then you can turn on this feature
!  by turning on the flag "use_hdf5" in parsec.in.
!
!  (1)
!  To install HDF5 library in your working environment, download the 
!  source code (e.g. hdf5-1.10.5.tar.gz) first from the official 
!  website (https://www.hdfgroup.org/), decompress it, and follow the usual
!  procedure:
!
!       /> FC=mpiifort ./configure --enable-fortran --enable-parallel --disable-shared
!       /> make
!       /> make install
!
!  (2)
!  Add
!       WITH_HDF5 = 1
!       FFLAGS += -I${HDF5_INC}
!       LIBHDF5 = -Wl,--start-group ${HDF5_LIB}/libhdf5.a ${HDF5_LIB}/libhdf5_fortran.a -Wl,--end-group -lz" 
!
!  into your build makefile, where ${HDF5_LIB} and ${HDF5_INC} are where 
!  the HDF5 libraries and include files are.
!
!  (3)
!  Add "use_hdf5     true" into your parsec.in
!
!
!  If everything is done correctly, parsec_iter?????.h5 should be generated
!  after SCF calculations.
!  You can use HDF5 tools or HDFview to examine HDF5 files. Also you may 
!  want to check tools/plot_wfn_from_h5.py as an example of reading/writing 
!  HDF5 files using Python (h5py).
!
!
!---------------------------------------------------------------
subroutine hdf5_wfnsave(parallel, elec_st, grid, pbc, rsymm, pot, &
        clust, mixer, iter, current_move_num, spin3d)

use constants
use parallel_data_module
use electronic_struct_module
use grid_module
use pbc_module
use symmetry_module
use potential_module
use aux, only : custom_date_time, myflush
use cluster_module
use mixer_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_info_null
#else
use mpi
#endif
#endif

#ifdef USE_HDF5
use hdf5
#endif

implicit none

! ==============================================================
!                  Input/Output variables
! ==============================================================

type(parallel_data), intent(in) :: parallel
type(electronic_struct), intent(in) :: elec_st
type(grid_data), intent(in) :: grid
type(pbc_data), intent(in) :: pbc
type(symmetry), intent(in) :: rsymm
type(potential), intent(in) :: pot 
type(cluster), intent(in) :: clust
type(mixer_data), intent(in) :: mixer

real(dp), dimension(parallel%ldn,3), intent(in), optional :: spin3d

! iter - number of this iteration
integer, intent(in) :: iter

integer, intent(in) :: current_move_num

! ==============================================================
!                  Work variables
! ==============================================================

! irp - counters for representations
integer :: mydim, isp, kplp, irp, kpnum, istate, jj, spnum, &
        arank, chunk_rank, frank, hdferr, &
        nstates_loc, offset_nstates

#ifdef USE_HDF5
integer(HID_T) :: file_id, dset_id, plist_id, attr_id, aspace_id, &
        atype_id, group_id, filespace, memspace
integer(HSIZE_T), dimension(2) :: adims, fdims, chunk_dims, &
        count, stride, block
integer(HSSIZE_T), dimension(2) :: offset
#endif

! jrep(elec_st%nrep) - jrep keeps track of how many eigenstates are already 
!                      in each representation
integer, dimension(elec_st%nrep) :: jrep
integer, dimension(elec_st%nspin,elec_st%nstate) :: jrepinv

!  flags for type of system
!  stype(1) = nspin
!
!  stype(2) = 0 : real wavefunctions
!  stype(2) = 1 : complex wavefunctions
!  stype(2) = 2 : spin-orbit (complex doubled wavefunctions)
!  stype(2) = 3 : noncollinear (spin3d present)
!  stype(2) = 4 : spin-orbit and noncollinear (spin3d present)
!
!  stype(3) = 0 : confined system (cluster)
!  stype(3) = 1 : system periodic on all directions (bulk)
!  stype(3) = 2 : system periodic on x direction only (wire)
integer, dimension(10) :: stype



real(dp) :: tmp_real
integer :: totdim

! en_tmp(:), occ_tmp(:) - temporary arrays for eigenvalues/occupations, 
!                         before reshaping according to symmetry operations
! kpwt(:) - weight of each kpoint being examined
! kpts(:,:) - coordinates of each kpoint
real(dp), dimension(:), allocatable :: en_tmp, occ_tmp, kpwt
real(dp), dimension(:,:), allocatable :: kpts


! datelabel(:) - date/time tag
character(len=5) :: isp_string, kplp_string, irp_string, iter_string, &
        move_string
character(len=26) :: datelabel

logical :: save_wfns
integer :: internal_nec, progress_stride

! --------------------------------------------------------------

#ifdef USE_HDF5

!save_wfns = .true.
save_wfns = .false.
progress_stride = 100



mydim = parallel%mydim
spnum = elec_st%nspin / elec_st%mxwd

call custom_date_time(datelabel, tmp_real)

if (elec_st%nkpt > 0) then
        kpnum = elec_st%nkpt
        allocate(kpts(3,kpnum))
        kpts(:,:) = elec_st%kpts(:,:)
        allocate(kpwt(kpnum))
        kpwt(:) = elec_st%kpwt(:)
else
        kpnum = 1
        allocate(kpts(3,kpnum))
        kpts(:,:) = zero
        allocate(kpwt(kpnum))
        kpwt(1) = one
end if

!  Build system flags.
stype(:) = 0
stype(1) = elec_st%nspin

if (elec_st%cplx) then
        if (elec_st%mxwd == 2) then
                if(elec_st%is_so) then
                        if (present(spin3d)) then 
                                stype(2) = 4
                        else
                                stype(2) = 2
                        end if
                else
                        if (present(spin3d)) stype(2) = 3
                end if
        else
                stype(2) = 1
        end if
end if

select case(pbc%per)
case(0)
        stype(3) = 0
case(1)
        stype(3) = 2
case(2)
        stype(3) = 3
case(3)
        stype(3) = 1
end select

! Initialize the HDF5 library
call H5open_f(hdferr)
if (hdferr /= 0) then
        write(9, *) 'h5_wfnsave: error in H5open_f'
        return
end if

write(iter_string, '(I5.5)') iter
write(move_string, '(I5.5)') current_move_num

if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: creating output file for move ', &
                current_move_num, ' iter ', iter
        call myflush(7)
endif

! Create the output file collectively
call H5Pcreate_f(H5P_FILE_ACCESS_F, plist_id, hdferr)
#ifdef WITH_MPI_F08
call H5Pset_fapl_mpio_f(plist_id, parallel%comm, mpi_info_null%mpi_val, hdferr)
#else
call H5Pset_fapl_mpio_f(plist_id, parallel%comm, mpi_info_null, hdferr)
#endif
call H5Fcreate_f('parsec_move'//move_string// &
        '_iter'//iter_string//'.h5', H5F_ACC_TRUNC_F, &
        file_id, hdferr, access_prp=plist_id)
call H5Pclose_f(plist_id, hdferr)

! ==============================================================
!                     Details
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /details'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/details", group_id, hdferr)

! create /datalabel attribute
! The steps to create an attribute are as follows:
!     1. Obtain the object identifier that the attribute is to 
!        be attached to.
!     2. Define the characteristics of the attribute and specify the
!     attribute creation property list.
!     - Define the datatype.
!     - Define the dataspace.
!     - Specify the attribute creation property
!     list.
!     3. Create the attribute.
!     4. Close the attribute and
!     datatype, dataspace, and attribute
!     creation property list, if
!     necessary.
! ========================================
! Write a single line string attribute
! ========================================
arank = 1
adims(1) = int(1, HSIZE_T)
! create string-like variable
call H5Tcopy_f(H5T_NATIVE_CHARACTER, atype_id, hdferr)

! '+1' is for the null-terminator character. See the spec of H5Tset_size_f().
call H5Tset_size_f(atype_id, int(len(datelabel)+1, HSIZE_T), hdferr)

! create space size defintions and simple dataspace
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)

! create attribute attached to base group
call H5Acreate_f(group_id, 'date', atype_id, aspace_id, attr_id, hdferr)

! write /datalabel attribute
call H5Awrite_f(attr_id, atype_id, datelabel, adims, hdferr)

! close /datalabel attribute
call H5Aclose_f(attr_id, hdferr)
call H5Tclose_f(atype_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

!============
! write stype
!============
arank = 1
adims(1) = int(size(stype(:),1), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'stype(:)', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, stype(:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

call H5Gclose_f(group_id, hdferr)

write(9,*) 'end of details'
! ==============================================================
!                     End of Details
! ==============================================================




! ==============================================================
!                     Clust
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /clust'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/clust", group_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'clust%type_num', H5T_NATIVE_INTEGER, &
        aspace_id, attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, clust%type_num, &
        adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'clust%atom_num', H5T_NATIVE_INTEGER, &
        aspace_id, attr_id, hdferr)
call h5Awrite_f(attr_id, H5T_NATIVE_INTEGER, clust%atom_num, &
        adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)







! Define the filespace (size of the dataset)
frank = 2
fdims(1) = int(clust%type_num, HSIZE_T)
fdims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)

! Define the memspace (size of the data in memory (for each process))
chunk_rank = 2
chunk_dims(1) = int(clust%type_num, HSIZE_T)
chunk_dims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

! Define the selection, so that each process knows where and how many they
! should write out to the filespace
offset(1) = int(0, HSSIZE_T)
offset(2) = int(0, HSSIZE_T)
count(1) = 1
count(2) = 1
block(1) = chunk_dims(1)
block(2) = chunk_dims(2)
stride(1) = int(1, HSIZE_T)
stride(2) = int(1, HSIZE_T)
call H5Sselect_hyperslab_f(filespace, H5S_SELECT_SET_F, offset, &
        count, hdferr, stride, block)

! Define the property list for the writing out operation
call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)

! create character(len=2) type for clust%atype(:)
call H5Tcopy_f(H5T_NATIVE_CHARACTER, atype_id, hdferr)
call H5Tset_size_f(atype_id, int(2, HSIZE_T), hdferr)

call H5Dcreate_f(group_id, 'clust%name(:)', atype_id, &
        filespace, dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, atype_id, clust%name(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)
call H5Tclose_f(atype_id, hdferr)

call H5Dcreate_f(group_id, 'clust%natmi(:)', H5T_NATIVE_INTEGER, &
        filespace, dset_id, hdferr)
if (parallel%iammaster) then
        call h5dwrite_f(dset_id, H5T_NATIVE_INTEGER, clust%natmi(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Pclose_f(plist_id, hdferr)
call H5Sclose_f(memspace, hdferr)
call H5Sclose_f(filespace, hdferr)


! -----------
! Output xatm(:), yatm(:), zatm(:)
! -----------

! Define the filespace (size of the dataset)
frank = 2
fdims(1) = int(clust%atom_num, HSIZE_T)
fdims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)

! Define the memspace (size of the data in memory (for each process))
chunk_rank = 2
chunk_dims(1) = int(clust%atom_num, HSIZE_T)
chunk_dims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

! Define the selection, so that each process knows where and how many they
! should write out to the filespace
offset(1) = int(0, HSSIZE_T)
offset(2) = int(0, HSSIZE_T)
count(1) = 1
count(2) = 1
block(1) = chunk_dims(1)
block(2) = chunk_dims(2)
stride(1) = int(1, HSIZE_T)
stride(2) = int(1, HSIZE_T)
call H5Sselect_hyperslab_f(filespace, H5S_SELECT_SET_F, offset, &
        count, hdferr, stride, block)

! Define the property list for the writing out operation
call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)

call H5Dcreate_f(group_id, 'clust%xatm(:)', H5T_NATIVE_DOUBLE, &
        filespace, dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, clust%xatm(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Dcreate_f(group_id, 'clust%yatm(:)', H5T_NATIVE_DOUBLE, &
        filespace, dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, clust%yatm(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Dcreate_f(group_id, 'clust%zatm(:)', H5T_NATIVE_DOUBLE, &
        filespace, dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, clust%zatm(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)




call H5Pclose_f(plist_id, hdferr)
call H5Sclose_f(memspace, hdferr)
call H5Sclose_f(filespace, hdferr)



call H5Gclose_f(group_id, hdferr)

write(9,*) 'end of clust'
! ==============================================================
!                     End of Clust
! ==============================================================















! ==============================================================
!                     Grid
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /grid'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/grid", group_id, hdferr)

if (pbc%is_on) then
        arank = 1
        adims(1) = int(size(pbc%box_size(:),1), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'pbc%box_size(:)', H5T_NATIVE_DOUBLE, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, pbc%box_size(:), adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 2
        adims(:) = int(shape(pbc%latt_vec(:,:)), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'pbc%latt_vec(:,:)', H5T_NATIVE_DOUBLE, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, pbc%latt_vec(:,:), adims, &
                hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 1
        adims(1) = int(1, HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'kptmethod', H5T_NATIVE_INTEGER, aspace_id, &
                attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, elec_st%kptmethod, adims, &
                hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 1
        adims(1) = int(size(elec_st%mpgrid(:),1), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'elec_st%mpgrid(:)', h5t_native_integer, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, elec_st%mpgrid(:), adims, &
                hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 1
        adims(1) = int(size(elec_st%mpshift(:),1), hsize_t)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'elec_st%mpshift(:)', H5T_NATIVE_DOUBLE, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, elec_st%mpshift(:), adims, &
                hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)
end if

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%lap_dir_num', H5T_NATIVE_INTEGER, &
        aspace_id, attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, grid%lap_dir_num, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(size(grid%lap_dir(:),1), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%lap_dir(:)', H5T_NATIVE_INTEGER, &
        aspace_id, attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, grid%lap_dir(:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(size(grid%lap_dir_step(:),1), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%lap_dir_step(:)', H5T_NATIVE_DOUBLE, &
        aspace_id, attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, grid%lap_dir_step(:), &
        adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(size(grid%step(:),1), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%step(:)', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, grid%step(:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%rmax', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, grid%rmax, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%ndim', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, grid%ndim, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(size(grid%shift(:),1), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%shift(:)', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, grid%shift(:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'grid%nwedge', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, grid%nwedge, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

! === Write out grid%kx, grid%ky, and grid%kz ===

! Define the filespace (size of the dataset)
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)

! Define the memspace (size of the data in memory (for each process))
chunk_rank = 2
chunk_dims(1) = int(grid%nwedge, HSIZE_T)
chunk_dims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

! Define the selection, so that each process knows where and how many they
! should write out to the filespace
offset(1) = int(0, HSSIZE_T)
offset(2) = int(0, HSSIZE_T)
count(1) = 1
count(2) = 1
block(1) = chunk_dims(1)
block(2) = chunk_dims(2)
stride(1) = int(1, HSIZE_T)
stride(2) = int(1, HSIZE_T)
call H5Sselect_hyperslab_f(filespace, H5S_SELECT_SET_F, offset, &
        count, hdferr, stride, block)

! Define the property list for the writing out operation
call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)

call H5Dcreate_f(group_id, 'grid%kx(:)', H5T_NATIVE_INTEGER, filespace, &
        dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, H5T_NATIVE_INTEGER, grid%kx(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Dcreate_f(group_id, 'grid%ky(:)', H5T_NATIVE_INTEGER, filespace, &
        dset_id, hdferr)
if (parallel%iammaster) then
        call h5dwrite_f(dset_id, H5T_NATIVE_INTEGER, grid%ky(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Dcreate_f(group_id, 'grid%kz(:)', H5T_NATIVE_INTEGER, filespace, &
        dset_id, hdferr)
if (parallel%iammaster) then
        call H5Dwrite_f(dset_id, H5T_NATIVE_INTEGER, grid%kz(:), fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
end if
call H5Dclose_f(dset_id, hdferr)

call H5Pclose_f(plist_id, hdferr)
call H5Sclose_f(memspace, hdferr)
call H5Sclose_f(filespace, hdferr)

call H5Gclose_f(group_id, hdferr)

write(9,*) 'end of grid'
! ==============================================================
!                     End of Grid
! ==============================================================



! ==============================================================
!                       Rsymm
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /rsymm'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/rsymm", group_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'rsymm%ntrans', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, rsymm%ntrans, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 2
adims(:) = int(shape(rsymm%alatt(:,:)), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'rsymm%alatt(:,:)', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, rsymm%alatt(:,:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 2
adims(:) = int(shape(rsymm%invlat(:,:)), HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'rsymm%invlat(:,:)', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, rsymm%invlat(:,:), adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

call H5Gclose_f(group_id, hdferr)

do irp = 1, rsymm%ntrans
        write(irp_string, '(I5.5)') irp
        call H5Gcreate_f(file_id, "/rsymm/irp"//irp_string, group_id, hdferr)

        arank = 2
        adims(:) = int(shape(rsymm%rmtrx(:,:,irp)), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'rsymm%rmtrx(:,:,irp)', &
                H5T_NATIVE_INTEGER, aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, rsymm%rmtrx(:,:,irp), &
                adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 2
        adims(:) = int(shape(rsymm%trans(:,:,irp)), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'rsymm%trans(:,:,irp)', &
                H5T_NATIVE_DOUBLE, aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, rsymm%trans(:,:,irp), &
                adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 1
        adims(1) = int(size(rsymm%tnp(:,irp),1), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'rsymm%tnp(:,irp)', H5T_NATIVE_DOUBLE, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, rsymm%tnp(:,irp), &
                adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        arank = 1
        adims(1) = int(size(rsymm%chi(:,irp),1), HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'rsymm%chi(:,irp)', H5T_NATIVE_INTEGER, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, h5t_native_integer, rsymm%chi(:,irp), &
                adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)

        call H5Gclose_f(group_id, hdferr)
end do

write(9,*) 'end of rsymm'
! ==============================================================
!                     End of Rsymm
! ==============================================================





! ==============================================================
!                       Mixer
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /mixer'
        call myflush(7)
endif


if (mixer%name == ANDERSON) then
        call H5Gcreate_f(file_id, "/mixer", group_id, hdferr)


        arank = 1
        adims(1) = int(1, HSIZE_T)
        call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
        call H5Acreate_f(group_id, 'mixer%stored_memory', &
                H5T_NATIVE_INTEGER, &
                aspace_id, attr_id, hdferr)
        call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, &
                mixer%stored_memory, adims, hdferr)
        call H5Aclose_f(attr_id, hdferr)
        call H5Sclose_f(aspace_id, hdferr)









        totdim = mixer%ndim*mixer%nspin

        ! Create a bare dataset for xinold and xoutold
        frank = 2
        fdims(1) = int(grid%nwedge*mixer%nspin, HSIZE_T)
        fdims(2) = int(mixer%stored_memory, HSIZE_T)
        call H5Screate_simple_f(frank, fdims, filespace, hdferr)
        call H5Dcreate_f(group_id, 'mixer%xinold(:,:)', &
                H5T_NATIVE_DOUBLE, filespace, &
                dset_id, hdferr)
        call H5Dclose_f(dset_id, hdferr)
        call H5Sclose_f(filespace, hdferr)

        ! Create a bare dataset for xinold and xoutold
        frank = 2
        fdims(1) = int(grid%nwedge*mixer%nspin, HSIZE_T)
        fdims(2) = int(mixer%stored_memory, HSIZE_T)
        call H5Screate_simple_f(frank, fdims, filespace, hdferr)
        call H5Dcreate_f(group_id, 'mixer%xoutold(:,:)', &
                H5T_NATIVE_DOUBLE, filespace, &
                dset_id, hdferr)
        call H5Dclose_f(dset_id, hdferr)
        call H5Sclose_f(filespace, hdferr)

        call H5Gclose_f(group_id, hdferr)




        ! Output xinold and xoutold
        call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
        call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)


        ! Let only one column group to write out xinold and xoutold
        if (parallel%mytaskgroup == 0 .and. parallel%mycolgroup == 0) then
                ! ====================
                ! Write out xinold
                ! ====================
                chunk_rank = 2
                chunk_dims(1) = int(totdim, HSIZE_T)
                chunk_dims(2) = int(1, HSIZE_T)

                call H5Screate_simple_f(chunk_rank, &
                        chunk_dims, memspace, hdferr)
                call H5Dopen_f(file_id, "/mixer/mixer%xinold(:,:)", &
                        dset_id, hdferr)
                call H5Dget_space_f(dset_id, filespace, hdferr)

                fdims(1) = int(grid%nwedge*mixer%nspin, HSIZE_T)
                fdims(2) = int(mixer%stored_memory, HSIZE_T)
                count(1) = int(1, HSIZE_T)
                count(2) = int(1, HSIZE_T)
                block(1) = chunk_dims(1)
                block(2) = chunk_dims(2)
                stride(1) = int(1, HSIZE_T)
                stride(2) = int(1, HSIZE_T)
                offset(1) = &
int(mixer%nspin*(parallel%irows(parallel%colgroup_iam)-1), HSSIZE_T)

                do jj = 1, mixer%stored_memory
                        offset(2) = int(jj-1, HSSIZE_T)

                        call H5Sselect_hyperslab_f(filespace, &
                                H5S_SELECT_SET_F, &
                                offset, count, hdferr, stride, block)
                        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                mixer%xinold(1:totdim,jj), fdims, hdferr, &
                                file_space_id=filespace, &
                                mem_space_id=memspace, &
                                xfer_prp=plist_id)
                enddo

                call H5Sclose_f(filespace, hdferr)
                call H5Dclose_f(dset_id, hdferr)
                call H5Sclose_f(memspace, hdferr)


                ! ====================
                ! Write out xoutold
                ! ====================
                chunk_rank = 2
                chunk_dims(1) = int(totdim, HSIZE_T)
                chunk_dims(2) = int(1, HSIZE_T)

                call H5Screate_simple_f(chunk_rank, &
                        chunk_dims, memspace, hdferr)
                call H5Dopen_f(file_id, "/mixer/mixer%xoutold(:,:)", &
                        dset_id, hdferr)
                call H5Dget_space_f(dset_id, filespace, hdferr)

                fdims(1) = int(grid%nwedge*mixer%nspin, HSIZE_T)
                fdims(2) = int(mixer%stored_memory, HSIZE_T)
                count(1) = int(1, HSIZE_T)
                count(2) = int(1, HSIZE_T)
                block(1) = chunk_dims(1)
                block(2) = chunk_dims(2)
                stride(1) = int(1, HSIZE_T)
                stride(2) = int(1, HSIZE_T)
                offset(1) = &
int(mixer%nspin*(parallel%irows(parallel%colgroup_iam)-1), HSSIZE_T)

                do jj = 1, mixer%stored_memory
                        offset(2) = int(jj-1, HSSIZE_T)

                        call H5Sselect_hyperslab_f(filespace, &
                                H5S_SELECT_SET_F, &
                                offset, count, hdferr, stride, block)
                        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                mixer%xoutold(1:totdim,jj), fdims, hdferr, &
                                file_space_id=filespace, &
                                mem_space_id=memspace, &
                                xfer_prp=plist_id)
                enddo

                call H5Sclose_f(filespace, hdferr)
                call H5Dclose_f(dset_id, hdferr)
                call H5Sclose_f(memspace, hdferr)
        endif



        call H5Pclose_f(plist_id, hdferr)

endif

write(9,*) 'end of mixer'
! ==============================================================
!                     End of Mixer
! ==============================================================






























! ==============================================================
!                       Pot
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /pot'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/pot", group_id, hdferr)

! Create a bare dataset for vion
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'pot%vion(:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vxc
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(spnum, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'pot%vxc(:,:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vhart
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(1, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'pot%vhart(:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vnew
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(spnum, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'pot%vnew(:,:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vnew_before_mixing
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(spnum, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'pot%vnew_before_mixing(:,:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)


call H5Gclose_f(group_id, hdferr)

! Output vion, vxc, vhart, vnew
call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)

! Let only one column group to write out vhart(:)
if (parallel%mytaskgroup == 0 .and. parallel%mycolgroup == 0) then
        chunk_rank = 2
        chunk_dims(1) = int(mydim, HSIZE_T)
        chunk_dims(2) = int(1, HSIZE_T)
        fdims(1) = int(grid%nwedge, HSIZE_T)
        fdims(2) = int(1, HSIZE_T)
        offset(1) = int(parallel%irows(parallel%colgroup_iam)-1, HSSIZE_T)
        offset(2) = int(0, HSSIZE_T)
        count(1) = int(1, HSIZE_T)
        count(2) = int(1, HSIZE_T)
        block(1) = chunk_dims(1)
        block(2) = chunk_dims(2)
        stride(1) = int(1, HSIZE_T)
        stride(2) = int(1, HSIZE_T)

        call H5Screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)


        ! ==================
        ! output vion(:)
        ! ==================
        call H5Dopen_f(file_id, "/pot/pot%vion(:)", dset_id, hdferr)
        call H5Dget_space_f(dset_id, filespace, hdferr)
        call H5Sselect_hyperslab_f(filespace, H5S_SELECT_SET_F, &
                offset, count, hdferr, stride, block)
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pot%vion(1:mydim), &
                fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
        call H5Sclose_f(filespace, hdferr)
        call H5Dclose_f(dset_id, hdferr)




        ! ==================
        ! output vhart(:)
        ! ==================
        call H5Dopen_f(file_id, "/pot/pot%vhart(:)", dset_id, hdferr)
        call H5Dget_space_f(dset_id, filespace, hdferr)
        call H5Sselect_hyperslab_f(filespace, H5S_SELECT_SET_F, &
                offset, count, hdferr, stride, block)
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, pot%vhart(1:mydim), &
                fdims, &
                hdferr, file_space_id=filespace, mem_space_id=memspace, &
                xfer_prp=plist_id)
        call H5Sclose_f(filespace, hdferr)
        call H5Dclose_f(dset_id, hdferr)



        call H5Sclose_f(memspace, hdferr)
end if

do isp = 1, spnum
        ! For each isp, let only one column group in the taskgroup 
        ! (1,1,isp) to write out vnew(:,isp)
        if (elec_st%eig(1,1,isp)%taskgroup == parallel%mytaskgroup .and. &
                parallel%mycolgroup == 0) then

                chunk_rank = 2
                chunk_dims(1) = int(mydim, HSIZE_T)
                chunk_dims(2) = int(1, HSIZE_T)
                fdims(1) = int(grid%nwedge, HSIZE_T)
                fdims(2) = int(spnum, HSIZE_T)
                offset(1) = int( &
                    parallel%irows(parallel%colgroup_iam)-1, &
                    HSSIZE_T)
                offset(2) = int(isp-1, HSSIZE_T)
                count(1) = int(1, HSIZE_T)
                count(2) = int(1, HSIZE_T)
                block(1) = chunk_dims(1)
                block(2) = chunk_dims(2)
                stride(1) = int(1, HSIZE_T)
                stride(2) = int(1, HSIZE_T)

                call H5Screate_simple_f(chunk_rank, &
                        chunk_dims, memspace, hdferr)

                ! ==================
                ! output vxc(:,isp)
                ! ==================
                call H5Dopen_f(file_id, "/pot/pot%vxc(:,:)", &
                        dset_id, hdferr)
                call H5Dget_space_f(dset_id, filespace, hdferr)
                call H5Sselect_hyperslab_f(filespace, &
                        H5S_SELECT_SET_F, &
                        offset, count, hdferr, stride, block)
                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                        pot%vxc(1:mydim,isp), fdims, hdferr, &
                        file_space_id=filespace, &
                        mem_space_id=memspace, &
                        xfer_prp=plist_id)
                call H5Sclose_f(filespace, hdferr)
                call H5Dclose_f(dset_id, hdferr)

                ! ==================
                ! output vnew(:,isp)
                ! ==================
                call H5Dopen_f(file_id, "/pot/pot%vnew(:,:)", &
                        dset_id, hdferr)
                call H5Dget_space_f(dset_id, filespace, hdferr)
                call H5Sselect_hyperslab_f(filespace, &
                        H5S_SELECT_SET_F, &
                        offset, count, hdferr, stride, block)
                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                        pot%vnew(1:mydim,isp), fdims, hdferr, &
                        file_space_id=filespace, &
                        mem_space_id=memspace, &
                        xfer_prp=plist_id)
                call H5Sclose_f(filespace, hdferr)
                call H5Dclose_f(dset_id, hdferr)


                ! ==================
                ! output vnew_before_mixing(:,isp)
                ! ==================
                call H5Dopen_f(file_id, "/pot/pot%vnew_before_mixing(:,:)", &
                        dset_id, hdferr)
                call H5Dget_space_f(dset_id, filespace, hdferr)
                call H5Sselect_hyperslab_f(filespace, &
                        H5S_SELECT_SET_F, &
                        offset, count, hdferr, stride, block)
                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                        pot%vnew_before_mixing(1:mydim,isp), fdims, hdferr, &
                        file_space_id=filespace, &
                        mem_space_id=memspace, &
                        xfer_prp=plist_id)
                call H5Sclose_f(filespace, hdferr)
                call H5Dclose_f(dset_id, hdferr)



                call H5Sclose_f(memspace, hdferr)
        end if
end do

call H5Pclose_f(plist_id, hdferr)


write(9,*) 'end of pot'
! ==============================================================
!                     End of Pot
! ==============================================================



! ==============================================================
!                       Elec_st
! ==============================================================
if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: writing /elec_st'
        call myflush(7)
endif
call H5Gcreate_f(file_id, "/elec_st", group_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'elec_st%nstate', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, elec_st%nstate, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'elec_st%nrep', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, elec_st%nrep, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'elec_st%nkpt', H5T_NATIVE_INTEGER, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, elec_st%nkpt, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

arank = 1
adims(1) = int(1, HSIZE_T)
call H5Screate_simple_f(arank, adims, aspace_id, hdferr)
call H5Acreate_f(group_id, 'elec_st%efermi', H5T_NATIVE_DOUBLE, aspace_id, &
        attr_id, hdferr)
call H5Awrite_f(attr_id, H5T_NATIVE_DOUBLE, elec_st%efermi, adims, hdferr)
call H5Aclose_f(attr_id, hdferr)
call H5Sclose_f(aspace_id, hdferr)

! Create a bare dataset for kpts(:,:)
frank = 2
fdims(:) = int(shape(kpts(:,:)), HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'elec_st%kpts(:,:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for kpwt(:)
frank = 1
fdims(1) = int(size(kpwt(:),1), HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'elec_st%kpwt(:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vhart
!frank = 2
!fdims(1) = int(grid%nwedge, HSIZE_T)
!fdims(2) = int(1, HSIZE_T)
!call H5Screate_simple_f(frank, fdims, filespace, hdferr)
!call H5Dcreate_f(group_id, 'pot%vhart(:)', H5T_NATIVE_DOUBLE, filespace, &
!        dset_id, hdferr)
!call H5Dclose_f(dset_id, hdferr)
!call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for vnew
!frank = 2
!fdims(1) = int(grid%nwedge, HSIZE_T)
!fdims(2) = int(elec_st%nspin/elec_st%mxwd, HSIZE_T)
!call H5Screate_simple_f(frank, fdims, filespace, hdferr)
!call H5Dcreate_f(group_id, 'vnew(:,:)', H5T_NATIVE_DOUBLE, filespace, &
!        dset_id, hdferr)
!call H5Dclose_f(dset_id, hdferr)
!call H5Sclose_f(filespace, hdferr)

! Create a bare dataset for rho
frank = 2
fdims(1) = int(grid%nwedge, HSIZE_T)
fdims(2) = int(spnum-1+elec_st%nspin, HSIZE_T)
call H5Screate_simple_f(frank, fdims, filespace, hdferr)
call H5Dcreate_f(group_id, 'elec_st%rho(:,:)', H5T_NATIVE_DOUBLE, filespace, &
        dset_id, hdferr)
call H5Dclose_f(dset_id, hdferr)
call H5Sclose_f(filespace, hdferr)

call H5Gclose_f(group_id, hdferr)

do isp = 1, spnum
        write(isp_string, '(I5.5)') isp
        call H5Gcreate_f(file_id, "/elec_st/isp"//isp_string, group_id, hdferr)
        call H5Gclose_f(group_id, hdferr)

        do kplp = 1, kpnum
                write(kplp_string, '(I5.5)') kplp
                call H5Gcreate_f(file_id, &
                        "/elec_st/isp"//isp_string//"/kplp"//kplp_string, &
                        group_id, hdferr)

                frank = 1
                fdims(1) = int(elec_st%nstate, HSIZE_T)
                call H5Screate_simple_f(frank, fdims, filespace, hdferr)

                call H5Dcreate_f(group_id, 'elec%irep(:,kplp,isp)', &
                        H5T_NATIVE_INTEGER, filespace, dset_id, hdferr)
                call H5Dclose_f(dset_id, hdferr)

                call H5Dcreate_f(group_id, 'eigenvalues(:,kplp,isp)', &
                        H5T_NATIVE_DOUBLE, filespace, dset_id, hdferr)
                call H5Dclose_f(dset_id, hdferr)

                call H5Dcreate_f(group_id, 'occupancies(:,kplp,isp)', &
                        H5T_NATIVE_DOUBLE, filespace, dset_id, hdferr)
                call H5Dclose_f(dset_id, hdferr)

                call H5Sclose_f(filespace, hdferr)

                call H5Gclose_f(group_id, hdferr)

                do irp = 1, elec_st%nrep
                        write(irp_string, '(I5.5)') irp


                        if (save_wfns) then
                                internal_nec = elec_st%eig(irp,kplp,isp)%nec
                        else
                                internal_nec = 0
                        endif
                        write(9,*) 'in hdf5, orig_nec, internal_nec', &
                                elec_st%eig(irp,kplp,isp)%nec, internal_nec





                        call H5Gcreate_f(file_id, &
                                "/elec_st/isp"//isp_string//"/kplp"// &
                                kplp_string//"/irp"//irp_string, &
                                group_id, hdferr)

                        arank = 1
                        adims(1) = int(1, HSIZE_T)
                        call H5Screate_simple_f(arank, adims, aspace_id, &
                                hdferr)
                        call H5Acreate_f(group_id, &
                                'elec_st%eig(irp,kplp,isp)%nec', &
                                H5T_NATIVE_INTEGER, aspace_id, &
                                attr_id, hdferr)
                        call H5Awrite_f(attr_id, H5T_NATIVE_INTEGER, &
                                internal_nec, adims, hdferr)
                        call H5Aclose_f(attr_id, hdferr)
                        call H5Sclose_f(aspace_id, hdferr)

                        if (elec_st%cplx) then
                                frank = 2
                                fdims(1) = int(grid%nwedge, HSIZE_T)
                                fdims(2) = int(internal_nec, &
                                        HSIZE_T)
                                call H5Screate_simple_f(frank, fdims, &
                                        filespace, hdferr)
                                call H5Dcreate_f(group_id, &
                                        'wavefunctions_re(:,:)', &
                                        H5T_NATIVE_DOUBLE, filespace, &
                                        dset_id, hdferr)
                                call H5Dclose_f(dset_id, hdferr)
                                call H5Sclose_f(filespace, hdferr)

                                frank = 2
                                fdims(1) = int(grid%nwedge, HSIZE_T)
                                fdims(2) = int(internal_nec, &
                                        HSIZE_T)
                                call H5Screate_simple_f(frank, fdims, &
                                        filespace, hdferr)
                                call H5Dcreate_f(group_id, &
                                        'wavefunctions_im(:,:)', &
                                        H5T_NATIVE_DOUBLE, filespace, &
                                        dset_id, hdferr)
                                call H5Dclose_f(dset_id, hdferr)
                                call H5Sclose_f(filespace, hdferr)
                        else
                                frank = 2
                                fdims(1) = int(grid%nwedge, HSIZE_T)
                                fdims(2) = int(internal_nec, &
                                        HSIZE_T)
                                call H5Screate_simple_f(frank, fdims, &
                                        filespace, hdferr)
                                call H5Dcreate_f(group_id, &
                                        'wavefunctions(:,:)', &
                                        H5T_NATIVE_DOUBLE, filespace, &
                                        dset_id, hdferr)
                                call H5Dclose_f(dset_id, hdferr)
                                call H5Sclose_f(filespace, hdferr)
                        end if

                        frank = 1
                        fdims(1) = int(internal_nec, HSIZE_T)
                        call H5Screate_simple_f(frank, fdims, filespace, &
                                hdferr)
                        call H5Dcreate_f(group_id, &
                                'elec_st%eig(irp,kplp,isp)%en(:)', &
                                H5T_NATIVE_DOUBLE, filespace, dset_id, hdferr)
                        call H5Dclose_f(dset_id, hdferr)
                        call H5Sclose_f(filespace, hdferr)

                        call H5Gclose_f(group_id, hdferr)
                end do
        end do
end do


write(9,*) 'before writing out the content of elec_st'

! Go over (irp,kplp,isp) triplet
! Output vnew, rho, en, occ, wavefunctions

call H5Pcreate_f(H5P_DATASET_XFER_F, plist_id, hdferr)
call H5Pset_dxpl_mpio_f(plist_id, H5FD_MPIO_INDEPENDENT_F, hdferr)

if (parallel%iammaster) then
        fdims(1) = int(3, HSIZE_T)
        fdims(2) = int(kpnum, HSIZE_T)
        call H5Dopen_f(file_id, "/elec_st/elec_st%kpts(:,:)", dset_id, hdferr)
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                kpts(:,:), fdims, hdferr, xfer_prp=plist_id)
        call H5Dclose_f(dset_id, hdferr)

        fdims(1) = int(kpnum, HSIZE_T)
        call H5Dopen_f(file_id, "/elec_st/elec_st%kpwt(:)", dset_id, hdferr)
        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                kpwt(:), fdims, hdferr, xfer_prp=plist_id)
        call H5Dclose_f(dset_id, hdferr)
end if

jrepinv = 0
do isp = 1, spnum
        write(isp_string, '(I5.5)') isp

        jj = isp - 1 + elec_st%nspin

        do kplp = 1, kpnum
                write(kplp_string, '(I5.5)') kplp

                ! Print out eigenvalues and occupancies for all (kplp,isp)
                jrep = 0
                do istate = 1, elec_st%nstate
                        irp = elec_st%irep(istate,kplp,isp)
                        jrep(irp) = jrep(irp) + 1
                        if (kplp == 1) jrepinv(isp,istate) = jrep(irp)
                end do

                allocate(en_tmp(elec_st%nstate))
                allocate(occ_tmp(elec_st%nstate))

                jrep = 0
                do istate = 1, elec_st%nstate
                        irp = elec_st%irep(istate,kplp,isp)
                        jrep(irp) = jrep(irp) + 1
                        if (kplp == 1) jrepinv(isp,istate) = jrep(irp)
                        en_tmp(istate) = &
                                elec_st%eig(irp,kplp,isp)%en(jrep(irp))
                        occ_tmp(istate) = &
                                elec_st%eig(irp,kplp,isp)%occ(jrep(irp))
                end do

                do irp = 1, elec_st%nrep
                        write(irp_string, '(I5.5)') irp

                        if (elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                parallel%mytaskgroup) then
                                cycle
                        end if

                        ! Write out rho(:,:)
                        if (kplp == 1 .and. irp == 1 .and. &
                                parallel%mycolgroup == 0) then
                                chunk_rank = 2
                                chunk_dims(1) = int(mydim, HSIZE_T)
                                chunk_dims(2) = int(1, HSIZE_T)
                                call H5Screate_simple_f(chunk_rank, &
                                        chunk_dims, memspace, hdferr)
                                call H5Dopen_f(file_id, &
                                        "/elec_st/elec_st%rho(:,:)", &
                                        dset_id, hdferr)
                                call H5Dget_space_f(dset_id, filespace, hdferr)
                                fdims(1) = int(grid%nwedge, HSIZE_T)
                                fdims(2) = int(spnum-1+elec_st%nspin, HSIZE_T)
                                offset(1) = int( &
                                        parallel%irows(parallel%colgroup_iam)-1, &
                                        HSSIZE_T)
                                offset(2) = int(jj-1, HSSIZE_T)
                                count(1) = int(1, HSIZE_T)
                                count(2) = int(1, HSIZE_T)
                                block(1) = chunk_dims(1)
                                block(2) = chunk_dims(2)
                                stride(1) = int(1, HSIZE_T)
                                stride(2) = int(1, HSIZE_T)
                                call H5Sselect_hyperslab_f(filespace, &
                                        H5S_SELECT_SET_F, &
                                        offset, count, hdferr, stride, block)
                                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                        elec_st%rho(1:mydim,jj), fdims, &
                                        hdferr, &
                                        file_space_id=filespace, &
                                        mem_space_id=memspace, &
                                        xfer_prp=plist_id)
                                call H5Sclose_f(filespace, hdferr)
                                call H5Dclose_f(dset_id, hdferr)
                                call H5Sclose_f(memspace, hdferr)
                        end if

                        ! Let only parallel%iamtaskgroupmaster with irep == 1
                        ! writes out the irep, eigenvalues, occupancies
                        if (irp == 1 .and. parallel%iam_taskgroup_master) then
                                chunk_rank = 2
                                chunk_dims(1) = int(elec_st%nstate, HSIZE_T)
                                chunk_dims(2) = int(1, HSIZE_T)
                                call H5Screate_simple_f(chunk_rank, chunk_dims, &
                                        memspace, hdferr)

                                fdims(1) = int(elec_st%nstate, HSIZE_T)
                                offset(1) = int(0, HSSIZE_T)
                                offset(2) = int(0, HSSIZE_T)
                                count(1) = int(1, HSIZE_T)
                                count(2) = int(1, HSIZE_T)
                                block(1) = chunk_dims(1)
                                block(2) = chunk_dims(2)
                                stride(1) = int(1, HSIZE_T)
                                stride(2) = int(1, HSIZE_T)

                                call H5Dopen_f(file_id, &
                                        "/elec_st/isp"//isp_string//"/kplp"// &
                                        kplp_string//'/elec%irep(:,kplp,isp)', &
                                        dset_id, hdferr)
                                call H5Dget_space_f(dset_id, filespace, hdferr)
                                call H5Sselect_hyperslab_f(filespace, &
                                        H5S_SELECT_SET_F, &
                                        offset, count, hdferr, stride, block)
                                call H5Dwrite_f(dset_id, H5T_NATIVE_INTEGER, &
                                        elec_st%irep(1:elec_st%nstate,kplp,isp), &
                                        fdims, &
                                        hdferr, xfer_prp=plist_id)
                                call H5Sclose_f(filespace, hdferr)
                                call H5Dclose_f(dset_id, hdferr)

                                call H5Dopen_f(file_id, &
                                        "/elec_st/isp"//isp_string// &
                                        "/kplp"//kplp_string// &
                                        '/eigenvalues(:,kplp,isp)', dset_id, hdferr)
                                call H5Dget_space_f(dset_id, filespace, hdferr)
                                call H5Sselect_hyperslab_f(filespace, &
                                        H5S_SELECT_SET_F, &
                                        offset, count, hdferr, stride, block)
                                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                        en_tmp(:), fdims, &
                                        hdferr, xfer_prp=plist_id)
                                call H5Sclose_f(filespace, hdferr)
                                call H5Dclose_f(dset_id, hdferr)

                                call H5Dopen_f(file_id, &
                                        "/elec_st/isp"//isp_string// &
                                        "/kplp"//kplp_string// &
                                        '/occupancies(:,kplp,isp)', dset_id, hdferr)
                                call H5Dget_space_f(dset_id, filespace, hdferr)
                                call H5Sselect_hyperslab_f(filespace, &
                                        H5S_SELECT_SET_F, &
                                        offset, count, hdferr, stride, block)
                                call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                        occ_tmp(:), fdims, &
                                        hdferr, xfer_prp=plist_id)
                                call H5Sclose_f(filespace, hdferr)
                                call H5Dclose_f(dset_id, hdferr)

                                call H5Sclose_f(memspace, hdferr)

                                !is_kplp_isp_info_written(:,kplp,isp) = .TRUE.
                        end if


                        if (save_wfns) then
                                internal_nec = elec_st%eig(irp,kplp,isp)%nec
                        else
                                internal_nec = 0
                        endif
                        write(9,*) 'in hdf5, orig_nec, internal_nec', &
                                elec_st%eig(irp,kplp,isp)%nec, internal_nec





                        if (internal_nec > 0) then

                                !  Print out wave-functions. With many k-points, 
                                !  must do it for all k-points. Also, must print 
                                !  the irreducible wedge (different
                                !  k-points may have different wedges).
                                nstates_loc = elec_st%nstate / elec_st%nrep / parallel%npcol
                                offset_nstates = parallel%mycolgroup &
                                        * nstates_loc

                                fdims(1) = int(grid%nwedge, HSIZE_T)
                                fdims(2) = int(elec_st%nstate, HSIZE_T)

                                chunk_rank = 2
                                chunk_dims(1) = int(mydim, HSIZE_T)
                                chunk_dims(2) = int(1, HSIZE_T)
                                call H5Screate_simple_f(chunk_rank, &
                                        chunk_dims, memspace, hdferr)

                                write(9,*) 'h5', parallel%colgroup_iam, &
                                                nstates_loc, offset_nstates

                                if (parallel%iammaster) then
                                        write(7,*) '  HDF5 restart: writing wavefunctions ', &
                                                'spin ', isp, ' k-point ', kplp, &
                                                ' irrep ', irp, ' local states ', &
                                                nstates_loc
                                        call myflush(7)
                                endif

                                if (elec_st%cplx) then
                                        ! Write out the real part of
                                        ! wavefunctions
                                        call H5Dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions_re(:,:)", &
                                                dset_id, hdferr)
                                        call H5Dget_space_f(dset_id, &
                                                filespace, hdferr)
                                        do istate = 1, nstates_loc
                                                if (parallel%iammaster .and. &
                                                        mod(istate-1, progress_stride) == 0) then
                                                        write(7,*) '  HDF5 restart: writing real part state ', &
                                                                istate, ' of ', nstates_loc
                                                        call myflush(7)
                                                endif

                                                offset(1) = int( &
                                                    parallel%irows(parallel%colgroup_iam)-1, &
                                                    HSSIZE_T)
                                                offset(2) = int( &
                                                        offset_nstates+istate-1, &
                                                        HSIZE_T)
                                                count(1) = int(1, HSIZE_T)
                                                count(2) = int(1, HSIZE_T)
                                                block(1) = chunk_dims(1)
                                                block(2) = chunk_dims(2)
                                                stride(1) = int(1, HSIZE_T)
                                                stride(2) = int(1, HSIZE_T)
                                                call H5Sselect_hyperslab_f( &
                                                        filespace, &
                                                        H5S_SELECT_SET_F, &
                                                        offset, count, &
                                                        hdferr, stride, block)

                                            call H5Dwrite_f(dset_id, &
                                            H5T_NATIVE_DOUBLE, &
                                            real(elec_st%eig(irp,kplp,isp)%zwf(:,istate),dp), &
                                            fdims, hdferr, file_space_id=filespace, &
                                            mem_space_id=memspace, xfer_prp=plist_id)
                                        end do
                                        call H5Sclose_f(filespace, hdferr)
                                        call H5Dclose_f(dset_id, hdferr)

                                        ! Write out the imaginary part of
                                        ! wavefunctions
                                        call H5Dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions_im(:,:)", &
                                                dset_id, hdferr)
                                        call H5Dget_space_f(dset_id, &
                                                filespace, hdferr)
                                        do istate = 1, nstates_loc
                                                if (parallel%iammaster .and. &
                                                        mod(istate-1, progress_stride) == 0) then
                                                        write(7,*) '  HDF5 restart: writing imaginary part state ', &
                                                                istate, ' of ', nstates_loc
                                                        call myflush(7)
                                                endif

                                                offset(1) = int( &
                                                    parallel%irows(parallel%colgroup_iam)-1, &
                                                    HSSIZE_T)
                                                offset(2) = int( &
                                                        offset_nstates+istate-1, &
                                                        HSIZE_T)
                                                count(1) = int(1, HSIZE_T)
                                                count(2) = int(1, HSIZE_T)
                                                block(1) = chunk_dims(1)
                                                block(2) = chunk_dims(2)
                                                stride(1) = int(1, HSIZE_T)
                                                stride(2) = int(1, HSIZE_T)
                                                call H5Sselect_hyperslab_f( &
                                                        filespace, &
                                                        H5S_SELECT_SET_F, &
                                                        offset, count, &
                                                        hdferr, stride, block)

                                            call H5Dwrite_f(dset_id, &
                                            H5T_NATIVE_DOUBLE, &
                                            aimag(elec_st%eig(irp,kplp,isp)%zwf(:,istate)), &
                                            fdims, hdferr, file_space_id=filespace, &
                                            mem_space_id=memspace, xfer_prp=plist_id)
                                        end do
                                        call H5Sclose_f(filespace, hdferr)
                                        call H5Dclose_f(dset_id, hdferr)
                                else
                                        call H5Dopen_f(file_id, &
                                                "/elec_st/isp"//isp_string// &
                                                "/kplp"//kplp_string// &
                                                "/irp"//irp_string// &
                                                "/wavefunctions(:,:)", &
                                                dset_id, hdferr)
                                        call H5Dget_space_f(dset_id, &
                                                filespace, hdferr)

                                        do istate = 1, nstates_loc
                                                if (parallel%iammaster .and. &
                                                        mod(istate-1, progress_stride) == 0) then
                                                        write(7,*) '  HDF5 restart: writing state ', &
                                                                istate, ' of ', nstates_loc
                                                        call myflush(7)
                                                endif

                                                offset(1) = int( &
                                                    parallel%irows(parallel%colgroup_iam)-1, &
                                                    HSSIZE_T)
                                                offset(2) = int( &
                                                        offset_nstates+istate-1, &
                                                        HSIZE_T)
                                                count(1) = int(1, HSIZE_T)
                                                count(2) = int(1, HSIZE_T)
                                                block(1) = chunk_dims(1)
                                                block(2) = chunk_dims(2)
                                                stride(1) = int(1, HSIZE_T)
                                                stride(2) = int(1, HSIZE_T)
                                                call H5Sselect_hyperslab_f( &
                                                        filespace, &
                                                        H5S_SELECT_SET_F, &
                                                        offset, count, hdferr, &
                                                        stride, block)

                                                call H5Dwrite_f(dset_id, &
                                                    H5T_NATIVE_DOUBLE, &
                                                    elec_st%eig(irp,kplp,isp)%wf(:,istate), &
                                                    fdims, &
                                                    hdferr, file_space_id=filespace, &
                                                    mem_space_id=memspace, xfer_prp=plist_id)
                                        end do

                                        call H5Sclose_f(filespace, hdferr)
                                        call H5Dclose_f(dset_id, hdferr)
                                end if

                                call H5Sclose_f(memspace, hdferr)

                                if (parallel%iam_taskgroup_master) then
                                        fdims(1) = int( &
                                                internal_nec, &
                                                HSIZE_T)
                                        call H5Dopen_f(file_id, &
                                            "/elec_st/isp"//isp_string// &
                                            "/kplp"//kplp_string// &
                                            "/irp"//irp_string// &
                                            "/elec_st%eig(irp,kplp,isp)%en(:)", &
                                            dset_id, hdferr)
                                        call H5Dget_space_f(dset_id, filespace, hdferr)
                                        call H5Dwrite_f(dset_id, H5T_NATIVE_DOUBLE, &
                                                elec_st%eig(irp,kplp,isp)%en(:), fdims, &
                                                hdferr, xfer_prp=plist_id)
                                        call H5Sclose_f(filespace, hdferr)
                                        call H5Dclose_f(dset_id, hdferr)
                                end if
                        endif
                end do   ! irp

                deallocate(en_tmp, occ_tmp)
        end do   ! kplp
end do   ! isp

call H5Pclose_f(plist_id, hdferr)

write(9,*) 'end of elec_st'
! ==============================================================
!                     End of Elec_st
! ==============================================================

!  If spin-orbit potential is present or noncollinear states, then the 
!  potential and density for the second spin component must be printed out.
!  The loop above goes only over the first spin component.
!
if (elec_st%mxwd == 2) then
    isp = 2
    jj = 3
    WRITE(ISP_STRING, '(I5.5)') isp
    call h5gcreate_f(file_id, "/elec_st/isp"//isp_string, group_id, hdferr)

    frank = int(2, hsize_t)
    fdims(1) = int(grid%nwedge, hsize_t)
    fdims(2) = int(1, hsize_t)
    call h5screate_simple_f(frank, fdims, filespace, hdferr)

    chunk_rank = int(2, hsize_t)
    chunk_dims(1) = int(mydim, hsize_t)
    chunk_dims(2) = int(1, hsize_t)
    call h5screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

    offset(1) = parallel%irows(parallel%iam) - 1
    offset(2) = int(0, hsize_t)
    count(1) = chunk_dims(1)
    count(2) = int(1, hsize_t)
    stride(1) = int(1, hsize_t)
    stride(2) = int(1, hsize_t)

    call h5pcreate_f(h5p_dataset_xfer_f, plist_id, hdferr)
    call h5pset_dxpl_mpio_f(plist_id, h5fd_mpio_collective_f, hdferr)

    call h5dcreate_f(group_id, 'vnew', h5t_native_double, filespace, dset_id, &
        hdferr)
    call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, hdferr, &
        stride)
    call h5dwrite_f(dset_id, h5t_native_double, pot%vnew(1:mydim,isp), fdims, &
        hdferr, file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
    call h5dclose_f(dset_id, hdferr)

    call h5dcreate_f(group_id, 'rho', h5t_native_double, filespace, dset_id, &
        hdferr)
    call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, hdferr, &
        stride)
    call h5dwrite_f(dset_id, h5t_native_double, elec_st%rho(1:mydim,jj), fdims, &
        hdferr, file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
    call h5dclose_f(dset_id, hdferr)

    call h5pclose_f(plist_id, hdferr)
    call h5sclose_f(memspace, hdferr)
    call h5sclose_f(filespace, hdferr)

    call h5gclose_f(group_id, hdferr)

    if (stype(2) > 2) then
        call h5gcreate_f(file_id, "/spin3d", group_id, hdferr)

        frank = int(2, hsize_t)
        fdims(1) = int(grid%nwedge, hsize_t)
        fdims(2) = int(1, hsize_t)
        call h5screate_simple_f(frank, fdims, filespace, hdferr)

        chunk_rank = int(2, hsize_t)
        chunk_dims(1) = int(mydim, hsize_t)
        chunk_dims(2) = int(1, hsize_t)
        call h5screate_simple_f(chunk_rank, chunk_dims, memspace, hdferr)

        offset(1) = parallel%irows(parallel%iam) - 1
        offset(2) = int(0, hsize_t)
        count(1) = chunk_dims(1)
        count(2) = int(1, hsize_t)
        stride(1) = int(1, hsize_t)
        stride(2) = int(1, hsize_t)

        call h5pcreate_f(h5p_dataset_xfer_f, plist_id, hdferr)
        call h5pset_dxpl_mpio_f(plist_id, h5fd_mpio_collective_f, hdferr)

        call h5dcreate_f(group_id, 'channel_1', h5t_native_double, filespace, dset_id, &
            hdferr)
        call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, hdferr, &
            stride)
        call h5dwrite_f(dset_id, h5t_native_double, spin3d(1:mydim,1), fdims, &
            hdferr, file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
        call h5dclose_f(dset_id, hdferr)

        call h5dcreate_f(group_id, 'channel_2', h5t_native_double, filespace, dset_id, &
            hdferr)
        call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, hdferr, &
            stride)
        call h5dwrite_f(dset_id, h5t_native_double, spin3d(1:,2), fdims, &
            hdferr, file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)
        call h5dclose_f(dset_id, hdferr)

        call h5dcreate_f(group_id, 'channel_3', h5t_native_double, filespace, dset_id, &
            hdferr)
        call h5sselect_hyperslab_f(filespace, h5s_select_set_f, offset, count, hdferr, &
            stride)
        call h5dwrite_f(dset_id, h5t_native_double, spin3d(:,3), fdims, &
            hdferr, file_space_id=filespace, mem_space_id=memspace, xfer_prp=plist_id)

        call h5dclose_f(dset_id, hdferr)
        call h5pclose_f(plist_id, hdferr)
        call h5sclose_f(memspace, hdferr)
        call h5sclose_f(filespace, hdferr)

        call h5gclose_f(group_id, hdferr)
    end if
end if


if (parallel%iammaster) then
        write(7,*) '  HDF5 restart: closing output file'
        call myflush(7)
endif


CALL H5Fclose_f(file_id, hdferr)

call H5close_f(hdferr)
if (hdferr /= 0) then
        write(9, *) 'h5_wfnsave: error in h5close_f'
        return
end if

!deallocate(is_isp_info_written)
!deallocate(is_kplp_isp_info_written)

#endif

end subroutine hdf5_wfnsave
