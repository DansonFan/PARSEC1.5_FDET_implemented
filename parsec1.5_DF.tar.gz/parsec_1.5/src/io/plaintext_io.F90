module plaintext_io

contains




subroutine naive_ascii_out(elec_st, grid)

! inits v_basis(parallel%ldn,blksize) to constvec(blksize) so that
! v_basis(1:ndim,i) == const_vec(i) using openmp tasks(+dependencies later)
! v_basis(ndim+1:ldn,i) will be set to zero
! thus - needs grid explicitly,but uses parallel through the global_data
!
! note that this function does a lot of extra work
! to obtain the grid coordinates of each point
! this is because we intend to factor that part out and use it
! to evaluate functions with the same method

! todo - make specific only clauses for each module here
use constants
use electronic_struct_module
use parsec_global_data, only : parallel
use grid_module
use parallel_data_module
use flevel_module, only : homo_lumo_indices
use sfc_module

implicit none

type (electronic_struct), intent(in) :: elec_st
type (grid_data), intent(in) :: grid
integer iblock,ifold, ii, jj
!  offset for each processor
integer ioffset, rowptr, kk
integer, parameter :: foldsize = 8
integer, parameter :: chunksize = 1
integer :: leftover,mycrows
! temporary for coordinate calculation
integer, dimension(1:chunksize,3) :: lookup
integer, dimension(1:foldsize) :: fold_i,fold_j,fold_k
real(dp), dimension(1:foldsize) :: r0_x,r0_y,r0_z
!real(dp), dimension(1:foldsize) :: r1_x,r1_y,r1_z
!real(dp), dimension(1:foldsize) :: vhart_atom
!real(dp), dimension(1:foldsize) :: vtemp
!real(dp) :: xx, yy, zz
integer, pointer :: homo_indices(:) => null(), lumo_indices(:) =>null()
character(len=128) :: filename

! -----------------------------------------------------------------

ioffset = parallel%cirows(parallel%group_iam) - 1
leftover = mod(parallel%mycdim,chunksize)
mycrows = parallel%mycdim - leftover

if (parallel%iammaster) then
        open(42, file="data.visit", form="formatted", status="unknown")

        write(42,'("!NBLOCKS ",I5)') parallel%procs_num

        do jj = 0, parallel%procs_num - 1
                write(42,'("data_",I5.5,".txt")') jj
        enddo

        close(42)
endif



write(filename,'("data_",I5.5,".txt")') parallel%iam

open(42,file=trim(filename),status="unknown",form="formatted")

call homo_lumo_indices(elec_st%eig(1,1,1)%occ, homo_indices, &
        lumo_indices, elec_st%ifmax(1))

write(filename,'(A,I0,A,I0,A)') "(3(A6),A8,1X,3(A9,1X),A26,", &
        size(homo_indices), &
        '("    hs=",I5.5,",o=",E9.2,2X),', &
        size(lumo_indices), &
        '("    hs=",I5.5,",o=",E9.2,2X))'

write(9,'(A)') filename
write(42, filename) "kx_ii","ky_ii","kz_ii","ii","xx","yy","zz","rho_ii", &
        (homo_indices(kk),elec_st%eig(1,1,1)%occ(homo_indices(kk)), &
        kk=1,size(homo_indices)), &
        (lumo_indices(kk),elec_st%eig(1,1,1)%occ(lumo_indices(kk)), &
        kk=1,size(lumo_indices))

do iblock = parallel%cirows(parallel%group_iam), &
        parallel%cirows(parallel%group_iam+1)-1, chunksize

        ! btw these should be vectorized automatically by this notation
        ! verify this in optreport
        ! lookups are expensive, so we only look once per 32 points
        lookup(1:chunksize,1) = grid%kcx(iblock:iblock+chunksize-1)
        lookup(1:chunksize,2) = grid%kcy(iblock:iblock+chunksize-1)
        lookup(1:chunksize,3) = grid%kcz(iblock:iblock+chunksize-1)

        do ifold = 1, chunksize
                ! that was just the coordinate for that row, we need 
                ! the actual distances
                !broadcast
                fold_i = lookup(ifold,1)

                !add fold to get 8 unique coordinates
                fold_i = fold_i + grid%fold%foldx

                !convert to grid coordinates
                r0_x = real(fold_i,dp)

                ! add shift and multiply by grid spacing
                r0_x = (r0_x + grid%shift(1))*grid%step(1)

                ! do the same for y
                fold_j = lookup(ifold,2)
                fold_j =fold_j+grid%fold%foldy
                r0_y = real(fold_j,dp)
                r0_y = (r0_y + grid%shift(2)) * grid%step(2)

                ! do the same for z
                fold_k = lookup(ifold,3)
                fold_k=fold_k+grid%fold%foldz
                r0_z = real(fold_k,dp)
                r0_z = (r0_z + grid%shift(3)) * grid%step(3)

                ! we now have a bunch of coordinates that we are 
                ! going to check where does this data 
                ! go to (excuse the fortran indexing)
                ! but right now that does not matter since this function
                ! writes ascii
                rowptr = 1+(iblock-ioffset-1)*foldsize

                ! accumulate (because of tasks there will be no clash etc.)
                do jj = 1, foldsize
                        ii = jj + rowptr - 1

                        write(42,'(3(I6),I8,1X,3(F9.3,1X),*(E26.16))') &
                                fold_i(jj), fold_j(jj), fold_k(jj), ii, &
                                r0_x(jj), r0_y(jj), r0_z(jj), &
                                elec_st%rho(ii,1), &
                                (elec_st%eig(1,1,1)%wf(ii,homo_indices)), &
                                (elec_st%eig(1,1,1)%wf(ii,lumo_indices))
                enddo
        enddo !ifold
enddo !iblock


write(9,*) "iblock after loop,vec_index", iblock

if (leftover > 0) then
        write(9,*) "my crows", parallel%mycdim
        write(9,*) "so there are leftovers, chunksize was wrong", chunksize
endif

close(42)

if (associated(homo_indices)) deallocate(homo_indices)
if (associated(lumo_indices)) deallocate(lumo_indices)

end subroutine naive_ascii_out







subroutine naive_ascii_out_unconv(elec_st, pot, grid, &
        in_usewfn, in_usepotentials, in_kiter)

! inits v_basis(parallel%ldn,blksize) to constvec(blksize) so that
! v_basis(1:ndim,i) == const_vec(i) using openmp tasks(+dependencies later)
! v_basis(ndim+1:ldn,i) will be set to zero
! thus - needs grid explicitly,but uses parallel through the global_data
!
! note that this function does a lot of extra work
! to obtain the grid coordinates of each point
! this is because we intend to factor that part out and use it
! to evaluate functions with the same method

! todo - make specific only clauses for each module here
use constants
use electronic_struct_module
use parsec_global_data, only : parallel
use potential_module, only : potential
use grid_module
use parallel_data_module
use flevel_module, only : homo_lumo_indices
use sfc_module

implicit none

type (electronic_struct), intent(in) :: elec_st
type (potential), intent(in) :: pot
type (grid_data), intent(in) :: grid
logical, intent (in), optional :: in_usewfn !< print wavefunctions near fermilevel
logical, intent (in), optional :: in_usepotentials !< print potentials
integer, intent (in), optional :: in_kiter !< iteration number
integer iblock,ifold, ii, jj
!  offset for each processor
integer ioffset, rowptr, kk
integer, parameter :: foldsize = 8
integer, parameter :: chunksize = 1
integer :: isrp !< spin representation - someone else can add this
integer :: leftover,mycrows
logical :: usewfn !< print wavefunctions near fermilevel
logical :: usepotentials !< print potentials
! temporary for coordinate calculation
integer, dimension(1:chunksize,3) :: lookup
integer, dimension(1:foldsize) :: fold_i,fold_j,fold_k
real(dp), dimension(1:foldsize) :: r0_x,r0_y,r0_z
!real(dp), dimension(1:foldsize) :: r1_x,r1_y,r1_z
!real(dp), dimension(1:foldsize) :: vhart_atom
!real(dp), dimension(1:foldsize) :: vtemp
!real(dp) :: xx, yy, zz
integer, pointer :: homo_indices(:) => null(), lumo_indices(:) =>null()
character(len=128) :: filename

! -----------------------------------------------------------------

isrp = 0

usewfn = .true.
usepotentials = .true.

if (present(in_usewfn)) usewfn = in_usewfn
if (present(in_usepotentials)) usepotentials = in_usepotentials

ioffset = parallel%cirows(parallel%group_iam) - 1
leftover = mod(parallel%mycdim,chunksize)
mycrows = parallel%mycdim - leftover

if (parallel%iammaster) then
        open(42, file="data.visit", form="formatted", status="unknown")

        write(42,'("!NBLOCKS ",I5)') parallel%procs_num

        do jj = 0, parallel%procs_num-1
                write(42,'("data_",I5.5,".txt")') jj
        enddo

        close(42)
endif


if (present(in_kiter)) then
        write(filename,'("data_",I5.5,".txt-",I3.3)') parallel%iam, in_kiter
else
        write(filename,'("data_",I5.5,".txt")') parallel%iam
endif

open(42,file=trim(filename),status="unknown",form="formatted")

call homo_lumo_indices(elec_st%eig(1,1,1)%occ, homo_indices, &
        lumo_indices, elec_st%ifmax(1))

if (usewfn .and. usepotentials) then
        write(filename,'(A,I0,A,I0,A)') "(3(A6),A8,1X,3(A9,1X),4A26,", &
                size(homo_indices),&
                '("    hs=",I5.5,",o=",E9.2,2X),', &
                size(lumo_indices), &
                '("    hs=",I5.5,",o=",E9.2,2X))'

        write(42, filename) &
                "kx_ii","ky_ii","kz_ii","ii","xx","yy","zz","rho_ii", &
                "vion","vhart","vxc", &
                (homo_indices(kk),elec_st%eig(1,1,1)%occ(homo_indices(kk)), &
                kk=1,size(homo_indices)),&
                (lumo_indices(kk),elec_st%eig(1,1,1)%occ(lumo_indices(kk)), &
                kk=1,size(lumo_indices))

elseif (usepotentials) then
        write(42,'(3(A6),A8,1X,3(A9,1X),4A26)') &
                "kx_ii","ky_ii","kz_ii","ii","xx","yy","zz","rho_ii",&
                "vion","vhart","vxc"

elseif (usewfn) then
        write(filename,'(A,I0,A,I0,A)') "(3(A6),A8,1X,3(A9,1X),A26,", &
                size(homo_indices), &
                '("    hs=",I5.5,",o=",E9.2,2X),', &
                size(lumo_indices), &
                '("    hs=",I5.5,",o=",E9.2,2X))'

        write(42,filename) &
                "kx_ii","ky_ii","kz_ii","ii","xx","yy","zz","rho_ii",&
                (homo_indices(kk),elec_st%eig(1,1,1)%occ(homo_indices(kk)), &
                kk=1,size(homo_indices)),&
                (lumo_indices(kk),elec_st%eig(1,1,1)%occ(lumo_indices(kk)), &
                kk=1,size(lumo_indices))
else
        write(filename, '(A,I0,A,I0,A)') "(3(A6),A8,1X,3(A9,1X),A26)"
        write(42, filename) &
                "kx_ii","ky_ii","kz_ii","ii","xx","yy","zz","rho_ii"
endif


do iblock = parallel%cirows(parallel%group_iam), &
        parallel%cirows(parallel%group_iam+1)-1, chunksize

        ! btw these should be vectorized automatically by this notation
        ! verify this in optreport
        ! lookups are expensive, so we only look once per 32 points
        lookup(1:chunksize,1) = grid%kcx(iblock:iblock+chunksize-1)
        lookup(1:chunksize,2) = grid%kcy(iblock:iblock+chunksize-1)
        lookup(1:chunksize,3) = grid%kcz(iblock:iblock+chunksize-1)

        do ifold = 1, chunksize
                ! that was just the coordinate for that row, we need 
                ! the actual distances
                !broadcast
                fold_i = lookup(ifold,1)

                !add fold to get 8 unique coordinates
                fold_i = fold_i + grid%fold%foldx

                !convert to grid coordinates
                r0_x = real(fold_i,dp)

                ! add shift and multiply by grid spacing
                r0_x = (r0_x + grid%shift(1))*grid%step(1)

                ! do the same for y
                fold_j = lookup(ifold,2)
                fold_j =fold_j+grid%fold%foldy
                r0_y = real(fold_j,dp)
                r0_y = (r0_y + grid%shift(2)) * grid%step(2)

                ! do the same for z
                fold_k = lookup(ifold,3)
                fold_k=fold_k+grid%fold%foldz
                r0_z = real(fold_k,dp)
                r0_z = (r0_z + grid%shift(3)) * grid%step(3)

                !we now have a bunch of coordinates that we are going to check
                !where does this data go to (excuse the fortran indexing)
                !but right now that does not matter since this function
                !writes ascii
                rowptr = 1+(iblock-ioffset-1)*foldsize

                ! accumulate (because of tasks there will be no clash etc.)
                if (usewfn .and. usepotentials) then
                        do jj = 1, foldsize
                                ii = jj + rowptr - 1

write(42,'(3(I6),I8,1X,3(F9.3,1X),*(E26.16))') &
        fold_i(jj), fold_j(jj), fold_k(jj), ii, &
        r0_x(jj), r0_y(jj), r0_z(jj), &
        elec_st%rho(ii,1), pot%vion(ii), pot%vhart(ii), pot%vxc(ii,isrp), &
        (elec_st % eig(1,1,1) % wf(ii, homo_indices) ), &
        (elec_st % eig(1,1,1) % wf(ii, lumo_indices) )
                        enddo

                elseif (usepotentials) then
                        do jj = 1, foldsize
                                ii = jj + rowptr - 1

write(42,'(3(I6),I8,1X,3(F9.3,1X),*(E26.16))') &
        fold_i(jj), fold_j(jj), fold_k(jj), ii, &
        r0_x(jj), r0_y(jj), r0_z(jj), &
        elec_st%rho(ii,1), pot%vion(ii), pot%vhart(ii), pot%vxc(ii,isrp)
                        enddo

                elseif (usewfn) then
                        do jj = 1, foldsize
                                ii = jj + rowptr - 1
write(42, '(3(I6),I8,1X,3(F9.3,1X),*(E26.16))') &
        fold_i(jj), fold_j(jj), fold_k(jj), ii, &
        r0_x(jj), r0_y(jj), r0_z(jj), &
        elec_st%rho(ii,1), (elec_st%eig(1,1,1)%wf(ii,homo_indices)),&
        (elec_st%eig(1,1,1)%wf(ii,lumo_indices))
                        enddo
                else
                        do jj = 1, foldsize
                                ii = jj + rowptr - 1
write(42, '(3(I6),I8,1X,3(F9.3,1X),*(E26.16))') &
        fold_i(jj), fold_j(jj), fold_k(jj), ii, &
        r0_x(jj), r0_y(jj), r0_z(jj), &
        elec_st % rho(ii,1)
                        enddo
                endif
        enddo !ifold
enddo !iblock



write(9,*) "iblock after loop,vec_index", iblock

if (leftover > 0) then
        write(9,*) "my crows", parallel%mycdim
        write(9,*) "so there are leftovers, chunksize was wrong", chunksize
endif

close(42)

if(associated(homo_indices)) deallocate(homo_indices)
if(associated(lumo_indices)) deallocate(lumo_indices)

end subroutine naive_ascii_out_unconv




end module plaintext_io
