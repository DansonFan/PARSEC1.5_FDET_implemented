module hdf5_module

implicit none

interface
        subroutine hdf5_wfnsave(parallel, elec_st, grid, pbc, rsymm, pot, &
                        clust, mixer, iter, current_move_num, spin3d)
                use constants
                use parallel_data_module
                use electronic_struct_module
                use grid_module
                use pbc_module
                use symmetry_module
                use potential_module
                use aux, only : custom_date_time
                use cluster_module
                use mixer_module
                type(parallel_data), intent(in) :: parallel
                type(electronic_struct), intent(in) :: elec_st
                type(grid_data), intent(in) :: grid
                type(pbc_data), intent(in) :: pbc
                type(symmetry), intent(in) :: rsymm
                type(potential), intent(in) :: pot 
                type(cluster), intent(in) :: clust
                type(mixer_data), intent(in) :: mixer
                real(dp), dimension(parallel%ldn,3), intent(in), optional :: spin3d
                integer, intent(in) :: iter
                integer, intent(in) :: current_move_num
        end subroutine hdf5_wfnsave
end interface

end module hdf5_module
