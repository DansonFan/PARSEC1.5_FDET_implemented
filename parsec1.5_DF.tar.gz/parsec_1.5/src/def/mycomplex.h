#ifdef CPLX

#define SCALAR complex(dpc)
#define __Tadiag zadiag
#define __TCONJG 'C'
#define __TMPI_DOUBLE_SCALAR MPI_DOUBLE_COMPLEX
#define __Tdot zdotc
#define __Textedges complex_ghost_edges_222_depth6
#define __Tghost_edges_111_depth6 complex_ghost_edges_111_depth6
#define __Tfoldtype c_fold_type
#define __Tmy_syev my_zheev
#define __Tmyedges complex_internal_edges_222_depth6
#define __Tinternal_edges_111_depth6 complex_internal_edges_111_depth6
#define __Tspectrum_slicing_diag zspectrum_slicing_diag
#define __Tcheby_filter_chebyjack zcheby_filter_chebyjack

#else

#define SCALAR real(dp)
#define __Tadiag adiag
#define __TCONJG 'T'
#define __TMPI_DOUBLE_SCALAR MPI_DOUBLE_PRECISION
#define __Tdot ddot
#define __Textedges real_ghost_edges_222_depth6
#define __Tghost_edges_111_depth6 real_ghost_edges_111_depth6
#define __Tfoldtype c_fold_rho
#define __Tmy_syev my_dsyev
#define __Tmyedges real_internal_edges_222_depth6
#define __Tinternal_edges_111_depth6 real_internal_edges_111_depth6
#define __Tspectrum_slicing_diag dspectrum_slicing_diag
#define __Tcheby_filter_chebyjack dcheby_filter_chebyjack

#endif
