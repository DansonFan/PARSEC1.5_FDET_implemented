module forcnloc_module
   implicit none
   contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! Updated August 2017 to selectively communicate (NERSC):
! Note: Requires MPI_THREAD_MULTIPLE
! Compared to 'forcnloc' update in July:
! * Each MPI process only contributes to the force calc if
!     there are non-zero components available to contribute.
! * Each MPI process creates a list of MPI comms, one for
!     each atom.
! * Comms are NULL if no local information is available
!     and loop is cycled.
! * Comms are built with MPI_COMM_SPLIT to only communicate
!     with MPI processes that have informatin to add to the calc.
!     (Based on mnloc, number of non-local MPI grid points. Could
!     likely be further improved by adding additional limiting
!     checks.)
! * Calculation proceeds over each atom type separately in
!     numerical order. (Could possibly further improve with a smarter
!     ordering technique, although such a technique would require
!     it's own calculation time.)
! * Final force answers locally stored, ALL_REDUCEd and only stored
!     outside the main loop. Must be stored in MPImaster clust object. 
!
! http://link.aps.org/doi/10.1103/PhysRevB.50.12234
!
!---------------------------------------------------------------
subroutine forcnloc_mt(clust,elec_st,p_pot,nloc_p_pot,symm,rsymm, &
        parallel,is_pbc,ipr,ierr,pot)

  use constants
  use potential_module
  use cluster_module
  use electronic_struct_module
  use pseudo_potential_module
  use non_local_psp_module
  use symmetry_module
  use parallel_data_module
  use psum_module
  use spin_orbit_module, only : forcso
  use symm_forces_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_comm_split, mpi_undefined, &
        mpi_comm_null, mpi_comm_size, mpi_reduce, mpi_real, mpi_sum, &
        mpi_comm_free
#else
use mpi
#endif
#endif

  use aux, only : mysecond

#ifdef _OPENMP
  use omp_lib
#endif

  use file_units, only : f_parsec
  implicit none
  !
  ! Input variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! pseudopotential related data
  type (pseudo_potential), intent(in) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(inout) :: nloc_p_pot
  ! symmetry operations
  type (symmetry), intent(in) :: symm, rsymm
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel
  type (potential), intent(in) :: pot

  ! PBC flag
  logical, intent(in) :: is_pbc
  ! output error
  integer, intent(out) :: ierr
  ! print flag
  integer, intent(in) :: ipr
  !
  ! Work variables:
  !
  ! working arrays
  !
  ! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
  ! - index "0" - and its derivative projections, for the non-local
  ! region around each atom - indices "1:3".
  real(dp) :: vylmd(1:nloc_p_pot%maxnloc,7,0:3)

  ! vylm*(actual wave function), for each state's non-local
  ! region around each atom
  complex(dpc), allocatable :: zvywf(:,:,:,:,:)
  real(dp), allocatable :: vywf(:,:,:,:,:)

  ! vylm*(actual wave function), for each state's derivative
  ! projections (indices "1:3" = i,j,k)
  complex(dpc), allocatable :: zdiv_proj(:,:,:,:,:,:)
  real(dp), allocatable :: div_proj(:,:,:,:,:,:)

  ! total forces, total forces per atom
  real(dp) :: fsum(3),fatom(3)

  ! temporary variables:
  ! holders of # of non-local components, local component, # of
  ! atoms for each atom type       
  integer nlp,local,nat,nat_max
  ! holder of non-local forces on a given atom
  real(dp) :: fnloc(3)
  ! holder of # of non-local grid points around each atom
  integer mnloc
  ! holder of change in forces
  ! held to apply to clust after all atoms completed
  real(dp), allocatable :: del_force(:,:)

  ! counters
  integer m,mg,itran,m_vdw
  ! atom counter all atoms and spin-orbit corrected ones, respectively
  integer ja, js, ja_vdw
  ! atom counter over previous types for index calculations
  integer sosum, nasum, ilmpa, ilmsum
  ! non-local projector counter
  integer ilm
  ! loop counters
  integer i,isp,j,k,ity,iat,ist,l,lp,locpnt,irp

  ! local aliases of variables contained in structures
  integer nspin, nstate, nrep, mydim

  ! total torque, non-PBC only
  real(dp) :: xmom, ymom, zmom
  integer offset, jj

  ! kpoint variables
  integer kplp, kpnum
  ! weight of each kpoint being examined
  real(dp), allocatable :: weight(:)
  real (dp) :: vdw_forces_t(3,clust%atom_num)

#ifdef MPI
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: tmp_comm_f08
#else
integer :: comm_f08
integer :: tmp_comm_f08
#endif
#endif

  ! MPI comms & error output
  integer, allocatable :: comm(:)
  integer err

  ! temporary variables for vectorization
  real(dp), allocatable :: occu(:)
  real(dp), allocatable :: dwf(:)
  complex(dpc), allocatable :: zwf(:)
  integer eigencount, omp_threads, omp_num 

  ! communication variables
  integer local_rank, commsize
  integer atom_groups, group_size, group, this_group, last_group
  integer max_group_size

  integer, allocatable :: local_list(:), total_list(:)
  integer atoms_comm, atoms_local, atoms_total
  !---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

#ifdef _OPENMP
    omp_threads = OMP_GET_MAX_THREADS()
#else
    omp_threads = 1
#endif

  ! Maximum number of atoms tested at a time.
  ! Used to limit maximum number of concurrent communicators.
  ! In extremely large test cases.
  max_group_size = 4000 

  kpnum = max(elec_st%nkpt,1)
  allocate(weight(kpnum))
  if (elec_st%nkpt > 0) then 
     weight = elec_st%kpwt
  else
     weight = one
  endif

  nspin = elec_st%nspin/elec_st%mxwd
  nrep = elec_st%nrep
  mydim = parallel%mydim

  ! Get maximum number of converged eigenstates per representation
  ! and allocate arrays accordingly.
  nstate = 0
  do isp = 1, nspin
     do kplp = 1, kpnum
        do irp = 1, nrep
           if (elec_st%eig(irp,kplp,isp)%nec > nstate) nstate = &
                elec_st%eig(irp,kplp,isp)%nec
        enddo
     enddo
  enddo

  ! Calc size of comm array
  group_size = 0
  do ity = 1,clust%type_num
     nat = clust%natmi(ity)
     if (nat > group_size)&
         group_size = nat
  enddo
  if (group_size > max_group_size)&
     group_size = max_group_size

  if (elec_st%cplx) then
     allocate( zvywf(nstate,16,nrep,kpnum,elec_st%nspin) )
     allocate( zdiv_proj(nstate,16,nrep,kpnum,elec_st%nspin,3) ) 
     allocate( zwf(nstate) )
  else
     allocate( vywf(nstate,16,nrep,kpnum,nspin) )
     allocate( div_proj(nstate,16,nrep,kpnum,nspin,3) )
     allocate( dwf(nstate) )
  endif
  allocate( del_force(3, clust%atom_num) )
  allocate( comm(group_size) )
  allocate( occu(nstate) )
#ifdef SORTEDFORCE
  allocate( local_list(group_size) )
  allocate( total_list(group_size) )
#endif

  if (parallel%iammaster) then
     ! header, if printing
     if (ipr >= 1) then
        write(7,*)
        write(7,*) 'Starting Thread-Multiple non-local force calculation' 
        write(7,*)
        write(7,*) 'Coordinates and local force components'
        write(7,*) '======================================'
        if (is_pbc) write(7,*) '(Ewald forces included)'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(:,j)
        enddo
        write(7,*)
        write(7,*)
        write(7,*) 'Reporting non-local force components'
        write(7,*) '===================================='
        write(7,41)
     endif
  endif

  ! if spin-orbit correction is done, 
  ! calculate the forces of spin-orbit potentials
  if (elec_st%is_so) then
     call forcso(clust,elec_st,nloc_p_pot,parallel)
     if (.not. elec_st%scf_so .and. parallel%iammaster) then
        write(7,*) 'WARNING! spin-orbit is calculated as a perturbation'
        write(7,*) 'Spin-orbit forces may be inacurate!'
     endif
     if (parallel%iammaster) &
     write(7,*) 'Adding spin-orbit contribution to forces'
  endif

  ! atom index, ja
  ! spin atom index, js	
  ja = 0
  js = 0
  ! non-local projector index
  ilm = 0
  del_force = 0
  
  ! sums over atom type for total atom count and spin-orbit atoms
  ! used to eliminate incremental counting (a=a+1) that
  !   inhibits threading implementations
  sosum = 0
  nasum = 0
  ilmpa = 0
  ilmsum = 0

  ! for all atom types...
  do ity = 1,clust%type_num
     nlp = p_pot%nlocp(ity)
     local = p_pot%loc(ity)
     nat = clust%natmi(ity) 

     ! increment previous atom type counters
     if (ity > 1) then
     nasum = nasum + clust%natmi(ity-1)
     ilmsum = ilmsum + clust%natmi(ity-1)*ilmpa
        if (p_pot%so(ity-1)) then
           sosum = sosum + clust%natmi(ity-1)
        endif
     endif
     ! calculate non-local electron pairs for atom type
     ! used to increment counter accurately for access
     ! to nloc_p_pot%anloc & nloc_p_pot%vylmd
     ilmpa = 0
     do lp = 1,nlp
        if (local == lp) cycle
        ilmpa = ilmpa + 2*lp - 1
     enddo

     ! No local orbitals, so atom type has no non-zero data. Skip it.
     ! Usually with small atoms (e.g. hydrogen). 
     if (ilmpa == 0) cycle

     ! Calc number of atom groups to solve. Loop broken down by 'group_size'
     !     to prevent breaking max limit of MPI communicators.
     atom_groups = nat/group_size
     last_group = mod(nat,group_size)
     if (last_group > 0)&
        atom_groups = atom_groups + 1

     do group = 1, atom_groups
        ! Define the size of the left-over group, if applicable
        if ((group == atom_groups) .AND. (last_group /= 0)) then
           this_group = last_group
        else
           this_group = group_size
        endif

        ! Build comm based on mnloc.
        ! If MPI has data to contribute to atom, color=1 & store newcomm in the comm array
        !     else, color=MPI_UNDEFINED to create no comm (returns MPI_COMM_NULL).
        ! Add in more complex contribution checks as found to ensure max speed, less overlap. 
        ! IMPROVEMENT?:
        !     Unorder ranks to randomize which comms are doing the final storage to reduce overlap?
        !     MAY be significant on extremely large problems. (Randomize key instead of = 0)
        !
        ! Variations: Standard - Loops through atoms, cycles to next atom if comm doesn't exist. 
        !             WORLDFORCE  - All comms are reset to 'MPI_COMM_WORLD'.
        !                           All atoms complete full calculation.
        !                           Primarily for testing purposes.
        !             SORTEDFORCE - Builds array of atoms to work on.
        !                           Comms are kept in numerical order, with atoms that need 
        !                             communication preceeding local atoms.
        !                           May reduce wasted time by eliminating local calculations when
        !                             other ranks are waiting for data.
        ! ===================================================

#ifdef SORTEDFORCE
        atoms_local = 0
        atoms_comm = 0
        atoms_total = 0
        local_list(:) = -1
        total_list(:) = -1
#endif

#ifdef MPI
        do iat = 1, this_group
#ifdef WORLDFORCE
           call MPI_COMM_DUP(MPI_COMM_WORLD, comm(iat), err)
#else
           ja = nasum + (group-1)*group_size + iat
           if (nloc_p_pot%nlatom(ja) /= 0) then
              call MPI_COMM_SPLIT(comm_f08, 1, 0, tmp_comm_f08, err)
#ifdef WITH_MPI_F08
              comm(iat) = tmp_comm_f08%mpi_val
#else
              comm(iat) = tmp_comm_f08
#endif
           else
              call MPI_COMM_SPLIT(comm_f08, MPI_UNDEFINED, 0, tmp_comm_f08, err)
#ifdef WITH_MPI_F08
              comm(iat) = tmp_comm_f08%mpi_val
#else
              comm(iat) = tmp_comm_f08
#endif
           endif
#ifdef SORTEDFORCE

#ifdef WITH_MPI_F08
           if (comm(iat) /= MPI_COMM_NULL%mpi_val) then
#else
           if (comm(iat) /= MPI_COMM_NULL) then
#endif

#ifdef WITH_MPI_F08
             tmp_comm_f08%mpi_val = comm(iat)
#else
             tmp_comm_f08 = comm(iat)
#endif
             call MPI_COMM_SIZE(tmp_comm_f08, commsize, err)

             if (commsize == 1) then
               atoms_local = atoms_local + 1
               local_list(atoms_local) = iat 
             else if (commsize > 1) then
               atoms_comm = atoms_comm + 1
               total_list(atoms_comm) = iat
             endif
           endif
#endif
#endif
        enddo
#ifdef SORTEDFORCE
        atoms_total = atoms_local + atoms_comm
        do iat = 1, atoms_local
           total_list(atoms_comm + iat) = local_list(iat)
        enddo
#endif
!ifdef MPI
#else
        comm(:) = 0
! Sorted force is irrelevant if everything is local (no mpi), so undefine to run the appropriate loop below.
#undef SORTEDFORCE    
#endif

     ! ===================================================
     ! Loop over each group

     write(9,*) 'Starting force loop: ', group
     ! Change Scheduling + Monotonic??
     !$OMP PARALLEL DO DEFAULT(NONE)&
     !$OMP& SHARED(parallel, rsymm, p_pot, clust, nloc_p_pot, elec_st, nat, nasum, omp_threads, group, group_size)&
     !$OMP& SHARED(local, ipr, mydim, kpnum, nstate, nrep, nspin, weight, ity, nlp, ilmpa, ilmsum, comm, del_force)&
     !$OMP& SHARED(this_group, atoms_total, total_list)&
#ifdef WITH_MPI_F08
     !$omp& shared(mpi_comm_null, mpi_real, mpi_sum) &
#endif
     !$OMP& SHARED(tmp_comm_f08)&
     !$OMP& PRIVATE(zvywf, vywf, div_proj, zdiv_proj)&
     !$OMP& PRIVATE(iat, ilm, ja, mnloc, l, jj, offset, mg, itran, vylmd, eigencount, dwf, zwf, fnloc)&
     !$OMP& PRIVATE(occu, isp, kplp, irp, i, ist, local_rank, commsize, err)
     ! for all atoms within this group.... 
#ifdef SORTEDFORCE
     do k = 1, atoms_total       ! dummy loop variable over atoms found with work
        iat = total_list(k)      ! immediately converted to the proper 'iat'
#else
     do iat = 1, this_group 
        ! write(9,*) ' doing atom ', iat
#endif
#ifdef MPI
#ifdef WITH_MPI_F08
        if ( comm(iat) == MPI_COMM_NULL%mpi_val ) cycle
#else
        if ( comm(iat) == MPI_COMM_NULL ) cycle
#endif

#ifdef WITH_MPI_F08
        tmp_comm_f08%mpi_val = comm(iat)
#else
        tmp_comm_f08 = comm(iat)
#endif

        call MPI_COMM_SIZE(tmp_comm_f08, commsize, err)
#endif
        ja = nasum + (group-1)*group_size + iat

        ! initialize non-local forces on each atom to zero
        fnloc(:) = zero
        occu(:) = zero
        ! initialize arrays to zero
        if (elec_st%cplx) then
           zvywf(:,:,:,:,:) = zzero
           zdiv_proj(:,:,:,:,:,:) = zzero
           zwf(:) = zzero
        else
           vywf(:,:,:,:,:) = zero
           div_proj(:,:,:,:,:,:) = zero
           dwf(:) = zero
        endif

        !index for atoms with spin-orbit forces
        !if (nloc_p_pot%so(ja)) js = sosum + iat
        ! determine size of non-local region around the atom (# of
        ! nonlocal grid points around each atom)
        mnloc = nloc_p_pot%nlatom(ja)
        ! determine starting ilm counter for this atom
        ilm = ilmsum + ilmpa*(ja-nasum-1)

        do lp = 1, nlp !{{{
           l = lp - 1
           ! skip it this is the local component
           if (lp == local) cycle
           if (ipr >= 0) then
           write(9,*) ' I received L = ',l,' for atom #',ja, &
                ' with mnloc = ',mnloc
           endif
           do i = 1, 2*lp - 1
              do locpnt = 1, mnloc
                 vylmd(locpnt,i,0) = nloc_p_pot%anloc(locpnt, ilm+i)
                 vylmd(locpnt,i,1) = nloc_p_pot%vylmd(1,locpnt, ilm+i)
                 vylmd(locpnt,i,2) = nloc_p_pot%vylmd(2,locpnt, ilm+i)
                 vylmd(locpnt,i,3) = nloc_p_pot%vylmd(3,locpnt, ilm+i)
              enddo
           enddo
           ilm = ilm + 2*lp - 1
           do isp = 1, elec_st%nspin
              jj = isp
              if (elec_st%cplx) then !{{{
                 if (elec_st%is_so) then
                    jj = 1
                    offset = (isp-1)*parallel%ndim
                 else
                    offset = 0
                 endif
                 do m = 1, mnloc
                    mg = nloc_p_pot%indw(m,ja) + offset
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    if (elec_st%nkpt > 0) then
                       do kplp = 1, kpnum
                          do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,jj)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,kplp,jj)%nec
                          zwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%zwf(mg,1:eigencount)
                             do i = l*l + 1, lp*lp
                                do ist = 1, eigencount
                                   zvywf(ist,i,irp,kplp,isp) = zvywf(ist,i,irp,kplp,isp) &
                                        + vylmd(m,i-l*l,0) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja) * p_pot%ekbi(lp,ity)

                                   zdiv_proj(ist,i,irp,kplp,isp,1) = zdiv_proj(ist,i,irp,kplp,isp,1) &
                                        + vylmd(m,i-l*l,1) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

                                   zdiv_proj(ist,i,irp,kplp,isp,2) = zdiv_proj(ist,i,irp,kplp,isp,2) &
                                        + vylmd(m,i-l*l,2) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

                                   zdiv_proj(ist,i,irp,kplp,isp,3) = zdiv_proj(ist,i,irp,kplp,isp,3) &
                                        + vylmd(m,i-l*l,3) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)
                                enddo
                             enddo
                          enddo
                       enddo
                    else
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,1,jj)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,1,jj)%nec
                          zwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%zwf(mg,1:eigencount)
                          do i = l*l + 1, lp*lp
                             do ist = 1, eigencount
                                zvywf(ist,i,irp,1,isp) = zvywf(ist,i,irp,1,isp) &
                                     + vylmd(m,i-l*l,0) * zwf(ist) &
                                     * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

                                zdiv_proj(ist,i,irp,1,isp,1) = zdiv_proj(ist,i,irp,1,isp,1) &
                                     + vylmd(m,i-l*l,1) * zwf(ist) &
                                     * rsymm%chi(irp,itran)

                                zdiv_proj(ist,i,irp,1,isp,2) = zdiv_proj(ist,i,irp,1,isp,2) &
                                     + vylmd(m,i-l*l,2) * zwf(ist) &
                                     * rsymm%chi(irp,itran)

                                zdiv_proj(ist,i,irp,1,isp,3) = zdiv_proj(ist,i,irp,1,isp,3) &
                                     + vylmd(m,i-l*l,3) * zwf(ist) &
                                     * rsymm%chi(irp,itran)
                             enddo
                          enddo
                       enddo
                    endif
                 enddo
              else !}}} !{{{
                 do m = 1,mnloc
                    mg = nloc_p_pot%indw(m,ja)
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,isp)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,kplp,jj)%nec
                          dwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%wf(mg,1:eigencount)
                          do i = l*l + 1, lp*lp
                             do ist = 1, eigencount 
                                   vywf(ist,i,irp,kplp,isp) = vywf(ist,i,irp,kplp,isp) &
                                        + vylmd(m,i-l*l,0) * dwf(ist) &
                                        * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

                                   div_proj(ist,i,irp,kplp,isp,1) = div_proj(ist,i,irp,kplp,isp,1) &
                                        + vylmd(m,i-l*l,1) * dwf(ist) &
                                        * rsymm%chi(irp,itran)

                                   div_proj(ist,i,irp,kplp,isp,2) = div_proj(ist,i,irp,kplp,isp,2) &
                                        + vylmd(m,i-l*l,2) * dwf(ist) &
                                        * rsymm%chi(irp,itran)

                                   div_proj(ist,i,irp,kplp,isp,3) = div_proj(ist,i,irp,kplp,isp,3) &
                                        + vylmd(m,i-l*l,3) * dwf(ist) &
                                        * rsymm%chi(irp,itran)
                             enddo
                          enddo
                       enddo
                    enddo
                 enddo
              endif !}}}
           enddo
        enddo               !lp = 1, nlp !}}}
      ! write(9,*) 'forcnloc debug print 1, iat ity',iat, ity

      ! All reduce of non-directional component only.
      ! Changes calculation from:
      !       sum(x) * sum(y)
      !   on master rank to
      !       sum( sum(x) * (y1 + y2 + y3) )
      !   to substantially reduce communication and
      !   utilize all available processes.
      if (elec_st%cplx) then
         call zpsum(zvywf(1:nstate,1,1,1,1),nstate*nrep*kpnum*16*elec_st%nspin,commsize,comm(iat))
      else
         call psum(vywf(1,1,1,1,1),nstate*nrep*kpnum*16*nspin,commsize,comm(iat))
      endif
           do isp = 1, nspin
              do kplp = 1, kpnum
                 do irp = 1, nrep
                    eigencount = elec_st%eig(irp,kplp,isp)%nec
                    occu(1:eigencount) = elec_st%eig(irp,kplp,isp)%occ(1:eigencount)
                    if (elec_st%cplx) then
                       do i = 1, nlp*nlp 
                          do ist = 1, eigencount
                             fnloc(:) = fnloc(:) + real(zvywf(ist,i,irp,kplp,isp) &
                                  *conjg(zdiv_proj(ist,i,irp,kplp,isp,1:3)))* &
                                  occu(ist)*weight(kplp)
                          enddo
                       enddo
                    else
                       do i = 1, nlp*nlp
                          do ist = 1, eigencount
                             fnloc(:) = fnloc(:) + vywf(ist,i,irp,kplp,isp) &
                                  *div_proj(ist,i,irp,kplp,isp,1:3)* &
                                  occu(ist)*weight(kplp) !AJB TODO: understand why the force is weighted
                          enddo
                       enddo
                    endif
                 enddo
              enddo
           enddo

           ! Multiply the forces - 2 for a pre-factor existing in the
           ! implemented formula, an extra 2 for the spin degeneracy of each
           ! state if NOT polarized.
           !
           fnloc = four * fnloc / real(nspin,dp)
           !
           ! report forces explicitly, if asked (only for debugging)

           ! Store the final delta force (in just one time place) on the local 0 rank.
           ! Will send to the master rank after all calculations are completed.
!         call psum(fnloc(1),3,commsize,comm(iat))
#ifdef MPI
#ifdef WITH_MPI_F08
          tmp_comm_f08%mpi_val = comm(iat)
#else
          tmp_comm_f08 = comm(iat)
#endif
          call MPI_Reduce(fnloc(1), del_force(1,ja), 3, MPI_REAL, MPI_SUM, 0, tmp_comm_f08, err)
#endif


!        ! The local master performs the storage.
!        ! Do we need to randomize the ordering of the comms to 
!        !     reduce the chances of a single comm choking on the storage?
!#ifdef MPI
!        call MPI_COMM_RANK(comm(iat), local_rank, err)
!#else
!        local_rank = 0
!#endif

!        if (local_rank == 0) then
           ! The final force must be stored in the parallel%iammaster
           !    clust object. So, need to temporarily store during
           !    the loop and reduce + store on the master rank
           !    after completion.
!           del_force(:,ja) = fnloc(:) 
!        endif     ! local_rank


     enddo        ! iat = 1, nat
     !$OMP END PARALLEL DO

#ifdef MPI
     ! Free the non-null communicators for reuse
     !   in calculations with extremely large numbers of atoms
     do iat = 1, this_group
#ifdef WITH_MPI_F08
        if ( comm(iat) /= MPI_COMM_NULL%mpi_val )&
#else
        if ( comm(iat) /= MPI_COMM_NULL )&
#endif
#ifdef WITH_MPI_F08
           tmp_comm_f08%mpi_val = comm(iat)
#else
           tmp_comm_f08 = comm(iat)
#endif
           call MPI_COMM_FREE(tmp_comm_f08, err)
     enddo
#endif

  enddo                     ! group = 1, atom_grps
  enddo                     ! ity = 1,clust%type_num
  !      write(9,*) ' forcnloc reports: done'
  !
  ! Report coordinates, net forces, net forces relative to center
  ! of mass, net total torque
  !

  ! Put all changes to forces on the master
  call psum(del_force(1,1),3*clust%atom_num,parallel%procs_num,parallel%comm)
!  if (parallel%iammaster) then
!    call MPI_Reduce(MPI_IN_PLACE, del_force(1,1), 3*clust%atom_num, MPI_REAL, MPI_SUM, parallel%masterid, parallel%comm)
!  else
!    call MPI_Reduce(del_force(1,1), del_force(1,1), 3*clust%atom_num, MPI_REAL, MPI_SUM, parallel%masterid, parallel%comm)
!  endif

  if (parallel%iammaster) then

     do iat=1, clust%atom_num 
       if (ipr >= 1) then
          write(7,40)  iat,clust%xatm(iat),clust%yatm(iat), &
            clust%zatm(iat), del_force(:,iat)
       endif
     enddo

     ! If VDW, prep the array for vectorization
     ! (Is this an improvement? The vdw force is applied as a simple
     !   addition, so is the time of doing this realignment ever made
     !   up during the reduction?) 
     if (elec_st%do_vdw) then
        do ja_vdw=1,clust%atom_num
           do m_vdw=1,3
              ! and that is the price you pay 10110!
              vdw_forces_t(m_vdw,ja_vdw)=clust%vdw_forces(ja_vdw,m_vdw)
           enddo
        enddo
     endif

     nasum = 0
     sosum = 0
     do ity = 1,clust%type_num
        nat = clust%natmi(ity) 
        ! increment previous atom type counters
        if (ity > 1) then
           nasum = nasum + clust%natmi(ity-1)
           if (p_pot%so(ity-1)) then
              sosum = sosum + clust%natmi(ity-1) 
           endif
        endif

        !$OMP PARALLEL DO DEFAULT(NONE)&
        !$OMP& SHARED(nat, nasum, sosum, del_force, elec_st, vdw_forces_t)&
        !$OMP& SHARED(nloc_p_pot, clust)&
        !$OMP& PRIVATE(ja, js)
        ! Adjust forces due to non-local, vdW and spin contributions
        do iat = 1, nat
           ja = nasum + iat
           if (nloc_p_pot%so(ja)) js = sosum + iat

           ! write(9,*) ' updating total force array for iat ', iat
           ! update TOTAL force array
           clust%force(:,ja) = clust%force(:,ja) + del_force(:,ja)

           ! add vdW forces
           if (elec_st%do_vdw) then
              ! factor of 2 to convert from Ha/bohr to Ry/bohr
              clust%force(:,ja)=clust%force(:,ja)+two*vdw_forces_t(:,ja)
           endif

           ! add spin forces
           if(nloc_p_pot%so(ja)) &
              clust%force(:,ja) = clust%force(:,ja) - real(clust%force_so(:,js))
        enddo
        !$OMP END PARALLEL DO
     enddo

     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'Coordinates, forces, torque'
     write(7,*) '============================'
     write(7,*)
     endif

     if (symm%ntrans > 1) then
        !
        ! symmetrize forces
        !
        if (ipr == 1) then
           write(7,*) 'coordinates and tot. forces (no symmetrization)'
           write(7,41)
           do  j = 1,clust%atom_num
              write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                   clust%force(1,j),clust%force(2,j),clust%force(3,j)
           enddo
        endif
        !
        ! if there are symmetry operations, perform symmetrization
        !
        if (symm%use_symm) then
           write(7,*) ' symmetrizing forces according to symmetry operations '
           call symm_forces(clust,symm,ierr)
        endif
     endif

     ! report coordinates and forces, accumulate and report total force
     fsum = sum( clust%force, dim=2 )
     if (ipr >= 1) then
        write(7,*) 'coordinates and symmetrized tot. forces'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(1,j),clust%force(2,j),clust%force(3,j)
        enddo
        write(7,*)
     endif
     if (ipr >= 0) then
         !AJB - don't know if this should be printed in averbose mode
     write(7,42) fsum
     endif

     ! net total force per atom
     fatom = fsum/real(clust%atom_num,dp)

     ! compute and report net force per atom (after subtracting the
     ! mean) and the net torque on the cluster (relevant only if
     ! periodic boundary conditions are not used)
     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'coordinates and tot. forces (after setting net force to zero)'
     write(7,41)
     do  j = 1,clust%atom_num
        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
             clust%force(:,j) - fatom
     enddo
     endif

     if (.not. is_pbc) then
        xmom = zero
        ymom = zero
        zmom = zero
        do  j = 1,clust%atom_num
           xmom = xmom+clust%yatm(j)*clust%force(3,j) - clust%zatm(j)*clust%force(2,j)
           ymom = ymom+clust%zatm(j)*clust%force(1,j) - clust%xatm(j)*clust%force(3,j)
           zmom = zmom+clust%xatm(j)*clust%force(2,j) - clust%yatm(j)*clust%force(1,j)
        enddo
        if (ipr >= 0) then
           write(7,*)
           write(7,43) xmom, ymom, zmom
           write(7,*)
        endif
     endif

     if (.not. pot%fex_is) then
        do j = 1,clust%atom_num
           clust%force(:,j) = clust%force(:,j) - fatom
        enddo
     elseif (ipr >= 0) then
        write(7,*) 'Net forces not removed in FDET.'
     endif
  endif

  if (elec_st%cplx) then
     deallocate(zvywf)
     deallocate(zdiv_proj)
     deallocate(zwf)
  else
     deallocate(vywf)
     deallocate(div_proj)
     deallocate(dwf)
  endif

  if (allocated(weight)) deallocate(weight)
  deallocate(del_force)
  deallocate(occu)
  deallocate(comm)

  ! format statements
40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)
42 format(13x,'tot.  (net) force [Ry/bohr]:',3x,3(f11.6,1x))
43 format(' tot. torque [Ry/radian] :',2x,3(f11.6,1x))

end subroutine forcnloc_mt
















!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! Updated August 2017 to selectively communicate (NERSC):
! Note: Requires MPI_THREAD_MULTIPLE
! Compared to 'forcnloc' update in July:
! * Each MPI process only contributes to the force calc if
!     there are non-zero components available to contribute.
! * Each MPI process creates a list of MPI comms, one for
!     each atom.
! * Comms are NULL if no local information is available
!     and loop is cycled.
! * Comms are built with MPI_COMM_SPLIT to only communicate
!     with MPI processes that have informatin to add to the calc.
!     (Based on mnloc, number of non-local MPI grid points. Could
!     likely be further improved by adding additional limiting
!     checks.)
! * Calculation proceeds over each atom type separately in
!     numerical order. (Could possibly further improve with a smarter
!     ordering technique, although such a technique would require
!     it's own calculation time.)
! * Final force answers locally stored, ALL_REDUCEd and only stored
!     outside the main loop. Must be stored in MPImaster clust object. 
!
! http://link.aps.org/doi/10.1103/PhysRevB.50.12234
!
!---------------------------------------------------------------
subroutine forcnloc_comm(clust,elec_st,p_pot,nloc_p_pot,symm,rsymm, &
        parallel,is_pbc,ipr,ierr,pot)

  use constants
  use potential_module
  use cluster_module
  use electronic_struct_module
  use pseudo_potential_module
  use non_local_psp_module
  use symmetry_module
  use parallel_data_module
  use psum_module
  use spin_orbit_module, only : forcso
  use symm_forces_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_comm_split, mpi_undefined, &
        mpi_comm_null, mpi_comm_size, mpi_reduce, mpi_real, mpi_sum, &
        mpi_comm_dup, mpi_comm_world
#else
use mpi
#endif
#endif

  use aux, only : mysecond

#ifdef _OPENMP
  use omp_lib
#endif

  use file_units, only : f_parsec
  implicit none
  !
  ! Input variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! pseudopotential related data
  type (pseudo_potential), intent(in) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(inout) :: nloc_p_pot
  ! symmetry operations
  type (symmetry), intent(in) :: symm, rsymm
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel
  type (potential), intent(in) :: pot

  ! PBC flag
  logical, intent(in) :: is_pbc
  ! output error
  integer, intent(out) :: ierr
  ! print flag
  integer, intent(in) :: ipr
  !
  ! Work variables:
  !
  ! working arrays
  !
  ! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
  ! - index "0" - and its derivative projections, for the non-local
  ! region around each atom - indices "1:3".
  real(dp) :: vylmd(1:nloc_p_pot%maxnloc,7,0:3)

  ! vylm*(actual wave function), for each state's non-local
  ! region around each atom
  complex(dpc), allocatable :: zvywf(:,:,:,:,:)
  real(dp), allocatable :: vywf(:,:,:,:,:)

  ! vylm*(actual wave function), for each state's derivative
  ! projections (indices "1:3" = i,j,k)
  complex(dpc), allocatable :: zdiv_proj(:,:,:,:,:,:)
  real(dp), allocatable :: div_proj(:,:,:,:,:,:)

  ! total forces, total forces per atom
  real(dp) :: fsum(3),fatom(3)

  ! temporary variables:
  ! holders of # of non-local components, local component, # of
  ! atoms for each atom type       
  integer nlp,local,nat,nat_max
  ! holder of non-local forces on a given atom
  real(dp) :: fnloc(3)
  ! holder of # of non-local grid points around each atom
  integer mnloc
  ! holder of change in forces
  ! held to apply to clust after all atoms completed
  real(dp), allocatable :: del_force(:,:)

  ! counters
  integer m,mg,itran,m_vdw
  ! atom counter all atoms and spin-orbit corrected ones, respectively
  integer ja, js, ja_vdw
  ! atom counter over previous types for index calculations
  integer sosum, nasum, ilmpa, ilmsum
  ! non-local projector counter
  integer ilm
  ! loop counters
  integer i,isp,j,k,ity,iat,ist,l,lp,locpnt,irp

  ! local aliases of variables contained in structures
  integer nspin, nstate, nrep, mydim

  ! total torque, non-PBC only
  real(dp) :: xmom, ymom, zmom
  integer offset, jj

  ! kpoint variables
  integer kplp, kpnum
  ! weight of each kpoint being examined
  real(dp), allocatable :: weight(:)
  real (dp) :: vdw_forces_t(3,clust%atom_num)

#ifdef MPI
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: tmp_comm_f08
#else
integer :: comm_f08
integer :: tmp_comm_f08
#endif
#endif

  ! MPI comms & error output
  integer, allocatable :: comm(:)
  integer err

  ! temporary variables for vectorization
  real(dp), allocatable :: occu(:)
  real(dp), allocatable :: dwf(:)
  complex(dpc), allocatable :: zwf(:)
  integer eigencount, omp_threads, omp_num 

  ! communication variables
  real(dp) :: rankperatom
  integer local_rank, commsize, local_count
  integer atom_groups, group_size, group, this_group, last_group
  integer max_group_size

  ! sorting variables
  integer, allocatable :: local_list(:), total_list(:)
  integer atoms_comm, atoms_local, atoms_total

  !---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

#ifdef _OPENMP
    omp_threads = OMP_GET_MAX_THREADS()
#else
    omp_threads = 1
#endif

  max_group_size = 4000 

  kpnum = max(elec_st%nkpt,1)
  allocate(weight(kpnum))
  if (elec_st%nkpt > 0) then 
     weight = elec_st%kpwt
  else
     weight = one
  endif

  nspin = elec_st%nspin/elec_st%mxwd
  nrep = elec_st%nrep
  mydim = parallel%mydim

  ! Get maximum number of converged eigenstates per representation
  ! and allocate arrays accordingly.
  nstate = 0
  do isp = 1, nspin
     do kplp = 1, kpnum
        do irp = 1, nrep
           if (elec_st%eig(irp,kplp,isp)%nec > nstate) nstate = &
                elec_st%eig(irp,kplp,isp)%nec
        enddo
     enddo
  enddo

  ! Calc size of comm array
  group_size = 0
  do ity = 1,clust%type_num
     nat = clust%natmi(ity)
     if (nat > group_size)&
         group_size = nat
  enddo
  if (group_size > max_group_size)&
     group_size = max_group_size

  if (elec_st%cplx) then
     allocate( zvywf(nstate,16,nrep,kpnum,elec_st%nspin) )
     allocate( zdiv_proj(nstate,16,nrep,kpnum,elec_st%nspin,3) ) 
     allocate( zwf(nstate) )
  else
     allocate( vywf(nstate,16,nrep,kpnum,nspin) )
     allocate( div_proj(nstate,16,nrep,kpnum,nspin,3) )
     allocate( dwf(nstate) )
  endif
  allocate( del_force(3, clust%atom_num) )
  allocate( comm(group_size) )
  allocate( occu(nstate) )
#ifdef SORTEDFORCE
  allocate( local_list(group_size) )
  allocate( total_list(group_size) )
#endif

  if (parallel%iammaster) then
     ! header, if printing
     if (ipr >= 1) then
        write(7,*)
        write(7,*) 'Starting Minimial Comm non-local force calculation' 
        write(7,*)
        write(7,*) 'Coordinates and local force components'
        write(7,*) '======================================'
        if (is_pbc) write(7,*) '(Ewald forces included)'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(:,j)
        enddo
        write(7,*)
        write(7,*)
        write(7,*) 'Reporting non-local force components'
        write(7,*) '===================================='
        write(7,41)
     endif
  endif

  ! if spin-orbit correction is done, 
  ! calculate the forces of spin-orbit potentials
  if (elec_st%is_so) then
     call forcso(clust,elec_st,nloc_p_pot,parallel)
     if (.not. elec_st%scf_so .and. parallel%iammaster) then
        write(7,*) 'WARNING! spin-orbit is calculated as a perturbation'
        write(7,*) 'Spin-orbit forces may be inacurate!'
     endif
     if (parallel%iammaster) &
     write(7,*) 'Adding spin-orbit contribution to forces'
  endif

  ! atom index, ja
  ! spin atom index, js	
  ja = 0
  js = 0
  ! non-local projector index
  ilm = 0
  del_force(:,:) = zero

  ! sums over atom type for total atom count and spin-orbit atoms
  ! used to eliminate incremental counting (a=a+1) that
  !   inhibits threading implementations
  sosum = 0
  nasum = 0
  ilmpa = 0
  ilmsum = 0
  local_count = 0
  rankperatom = 0

  ! for all atom types...
  do ity = 1,clust%type_num
     nlp = p_pot%nlocp(ity)
     local = p_pot%loc(ity)
     nat = clust%natmi(ity) 

     ! increment previous atom type counters
     if (ity > 1) then
     nasum = nasum + clust%natmi(ity-1)
     ilmsum = ilmsum + clust%natmi(ity-1)*ilmpa
        if (p_pot%so(ity-1)) then
           sosum = sosum + clust%natmi(ity-1)
        endif
     endif
     ! calculate non-local electron pairs for atom type
     ! used to increment counter accurately for access
     ! to nloc_p_pot%anloc & nloc_p_pot%vylmd
     ilmpa = 0
     do lp = 1,nlp
        if (local == lp) cycle
        ilmpa = ilmpa + 2*lp - 1
     enddo

     ! No local orbitals, so atom type has no non-zero data. Skip it.
     ! Usually with small atoms (e.g. hydrogen). 
     if (ilmpa == 0) cycle

     ! Calc number of atom groups to solve. Loop broken down by 'group_size'
     !     to prevent breaking max limit of MPI communicators.
     atom_groups = nat/group_size
     last_group = mod(nat,group_size)
     if (last_group > 0)&
        atom_groups = atom_groups + 1

     do group = 1, atom_groups
        ! Define the size of the left-over group, if applicable
        if ((group == atom_groups) .AND. (last_group /= 0)) then
           this_group = last_group
        else
           this_group = group_size
        endif

        ! Build comm based on mnloc.
        ! If MPI has data to contribute to atom, color=1 & store newcomm in the comm array
        !     else, color=MPI_UNDEFINED to create no comm (returns MPI_COMM_NULL).
        ! Add in more complex contribution checks as found to ensure max speed, less overlap. 
        ! IMPROVEMENT?:
        !     Unorder ranks to randomize which comms are doing the final storage to reduce overlap?
        !     MAY be significant on extremely large problems. (Randomize key instead of = 0)
        !
        ! Variations: Standard - Loops through atoms, cycles to next atom if comm doesn't exist. 
        !             WORLDFORCE  - All comms are reset to 'MPI_COMM_WORLD'.
        !                           All atoms complete full calculation.
        !                           Primarily for testing purposes.
        !             SORTEDFORCE - Builds array of atoms to work on.
        !                           Comms are kept in numerical order, with atoms that need 
        !                             communication preceeding local atoms.
        !                           May reduce wasted time by eliminating local calculations when
        !                             other ranks are waiting for data.
        ! ================================================

#ifdef SORTEDFORCE
        atoms_local = 0
        atoms_comm = 0
        atoms_total = 0
        local_list(:) = -1
        total_list(:) = -1
#endif

#ifdef MPI
        do iat = 1, this_group
#ifdef WORLDFORCE
           call MPI_COMM_DUP(MPI_COMM_WORLD, tmp_comm_f08, err)

#ifdef WITH_MPI_F08
           comm(iat) = tmp_comm_f08%mpi_val
#else
           comm(iat) = tmp_comm_f08
#endif

#else
           ja = nasum + (group-1)*group_size + iat
           if (nloc_p_pot%nlatom(ja) /= 0) then
              call MPI_COMM_SPLIT(comm_f08, 1, 0, tmp_comm_f08, err)

#ifdef WITH_MPI_F08
              comm(iat) = tmp_comm_f08%mpi_val
#else
              comm(iat) = tmp_comm_f08
#endif

              local_count = local_count + 1
           else
              call MPI_COMM_SPLIT(comm_f08, MPI_UNDEFINED, 0, tmp_comm_f08, err)

#ifdef WITH_MPI_F08
              comm(iat) = tmp_comm_f08%mpi_val
#else
              comm(iat) = tmp_comm_f08
#endif

           endif
#ifdef SORTEDFORCE

#ifdef WITH_MPI_F08
           if ( comm(iat) /= MPI_COMM_NULL%mpi_val ) then
#else
           if ( comm(iat) /= MPI_COMM_NULL ) then
#endif

#ifdef WITH_MPI_F08
             tmp_comm_f08%mpi_val = comm(iat)
#else
             tmp_comm_f08 = comm(iat)
#endif

             call MPI_COMM_SIZE(tmp_comm_f08, commsize, err)

             if (commsize == 1) then
               atoms_local = atoms_local + 1
               local_list(atoms_local) = iat 
             else if (commsize > 1) then
               atoms_comm = atoms_comm + 1
               total_list(atoms_comm) = iat
             endif
             rankperatom = rankperatom + commsize
           endif
#endif
#endif
        enddo
#ifdef SORTEDFORCE
        atoms_total = atoms_local + atoms_comm
        do iat = 1, atoms_local
           total_list(atoms_comm + iat) = local_list(iat)
        enddo
#endif
!ifdef MPI
#else
        comm(:) = 0
! Sorted force is irrelevant if everything is local (no mpi)
!   so undefine to run the appropriate loop below.
#undef SORTEDFORCE
#endif

     ! ===================================================
     ! Loop over each group.
     write(9,*) 'Starting force loop: ', group
#ifdef SORTEDFORCE
     do k = 1, atoms_total           ! dummy variable to convert to iat
        iat = total_list(k)
#else
     do iat = 1, this_group
        ! write(9,*) ' doing atom ', iat
#endif
#ifdef MPI
#ifdef WITH_MPI_F08
        if ( comm(iat) == MPI_COMM_NULL%mpi_val ) cycle
#else
        if ( comm(iat) == MPI_COMM_NULL ) cycle
#endif

#ifdef WITH_MPI_F08
        tmp_comm_f08%mpi_val = comm(iat)
#else
        tmp_comm_f08 = comm(iat)
#endif

        call MPI_COMM_SIZE(tmp_comm_f08, commsize, err)

        write(9,*) 'Loading comm ', iat, ' with commsize', commsize
        rankperatom = rankperatom + commsize
#endif
        ja = nasum + (group-1)*group_size + iat

        ! initialize non-local forces on each atom to zero
        fnloc(:) = zero
        occu(:) = zero
        ! initialize arrays to zero
        if (elec_st%cplx) then
           zvywf(:,:,:,:,:) = zzero
           zdiv_proj(:,:,:,:,:,:) = zzero
           zwf(:) = zzero
        else
           vywf(:,:,:,:,:) = zero
           div_proj(:,:,:,:,:,:) = zero
           dwf(:) = zero
        endif

        !index for atoms with spin-orbit forces
        !if (nloc_p_pot%so(ja)) js = sosum + iat
        ! determine size of non-local region around the atom (# of
        ! nonlocal grid points around each atom)
        mnloc = nloc_p_pot%nlatom(ja)
        ! determine starting ilm counter for this atom
        ilm = ilmsum + ilmpa*(ja-nasum-1)

        do lp = 1, nlp !{{{
           l = lp - 1
           ! skip it this is the local component
           if (lp == local) cycle
           if (ipr >= 0) then
           write(9,*) ' I received L = ',l,' for atom #',ja, &
                ' with mnloc = ',mnloc
           endif
           do i = 1, 2*lp - 1
              do locpnt = 1, mnloc
                 vylmd(locpnt,i,0) = nloc_p_pot%anloc(locpnt, ilm+i)
                 vylmd(locpnt,i,1) = nloc_p_pot%vylmd(1,locpnt, ilm+i)
                 vylmd(locpnt,i,2) = nloc_p_pot%vylmd(2,locpnt, ilm+i)
                 vylmd(locpnt,i,3) = nloc_p_pot%vylmd(3,locpnt, ilm+i)
              enddo
           enddo
           ilm = ilm + 2*lp - 1
           do isp = 1, elec_st%nspin
              jj = isp
              if (elec_st%cplx) then !{{{
                 if (elec_st%is_so) then
                    jj = 1
                    offset = (isp-1)*parallel%ndim
                 else
                    offset = 0
                 endif
                 !$OMP PARALLEL DO DEFAULT(SHARED)&
                 !$OMP PRIVATE(m, mg, itran, kplp, irp, ist, i, j, eigencount, zwf)&
                 !$OMP REDUCTION(+:zvywf,zdiv_proj)
                 do m = 1, mnloc
                    mg = nloc_p_pot%indw(m,ja) + offset
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    if (elec_st%nkpt > 0) then
                       do kplp = 1, kpnum
                          do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,jj)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,kplp,jj)%nec
                          zwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%zwf(mg,1:eigencount)
                             do i = l*l + 1, lp*lp
                                do ist = 1, eigencount
                                   zvywf(ist,i,irp,kplp,isp) = zvywf(ist,i,irp,kplp,isp) &
                                        + vylmd(m,i-l*l,0) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja) * p_pot%ekbi(lp,ity)

                                   zdiv_proj(ist,i,irp,kplp,isp,1) = zdiv_proj(ist,i,irp,kplp,isp,1) &
                                        + vylmd(m,i-l*l,1) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

                                   zdiv_proj(ist,i,irp,kplp,isp,2) = zdiv_proj(ist,i,irp,kplp,isp,2) &
                                        + vylmd(m,i-l*l,2) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

                                   zdiv_proj(ist,i,irp,kplp,isp,3) = zdiv_proj(ist,i,irp,kplp,isp,3) &
                                        + vylmd(m,i-l*l,3) * zwf(ist) &
                                        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)
                                enddo
                             enddo
                          enddo
                       enddo
                    else
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,1,jj)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,1,jj)%nec
                          zwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%zwf(mg,1:eigencount)
                          do i = l*l + 1, lp*lp
                             do ist = 1, eigencount
                                zvywf(ist,i,irp,1,isp) = zvywf(ist,i,irp,1,isp) &
                                     + vylmd(m,i-l*l,0) * zwf(ist) &
                                     * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

                                zdiv_proj(ist,i,irp,1,isp,1) = zdiv_proj(ist,i,irp,1,isp,1) &
                                     + vylmd(m,i-l*l,1) * zwf(ist) &
                                     * rsymm%chi(irp,itran)

                                zdiv_proj(ist,i,irp,1,isp,2) = zdiv_proj(ist,i,irp,1,isp,2) &
                                     + vylmd(m,i-l*l,2) * zwf(ist) &
                                     * rsymm%chi(irp,itran)

                                zdiv_proj(ist,i,irp,1,isp,3) = zdiv_proj(ist,i,irp,1,isp,3) &
                                     + vylmd(m,i-l*l,3) * zwf(ist) &
                                     * rsymm%chi(irp,itran)
                             enddo
                          enddo
                       enddo
                    endif
                 enddo
                 !$OMP END PARALLEL DO
              else !}}} !{{{
                 !$OMP PARALLEL DO DEFAULT(SHARED)&
                 !$OMP PRIVATE(m, mg, itran, kplp, irp, ist, i, j, eigencount, dwf)&
                 !$OMP REDUCTION(+:vywf,div_proj)
                 do m = 1,mnloc
                    mg = nloc_p_pot%indw(m,ja)
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,isp)%taskgroup /= parallel%mygroup ) cycle
                          eigencount = elec_st%eig(irp,kplp,jj)%nec
                          dwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%wf(mg,1:eigencount)
                          do i = l*l + 1, lp*lp
                             do ist = 1, eigencount 
                                   vywf(ist,i,irp,kplp,isp) = vywf(ist,i,irp,kplp,isp) &
                                        + vylmd(m,i-l*l,0) * dwf(ist) &
                                        * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

                                   div_proj(ist,i,irp,kplp,isp,1) = div_proj(ist,i,irp,kplp,isp,1) &
                                        + vylmd(m,i-l*l,1) * dwf(ist) &
                                        * rsymm%chi(irp,itran)

                                   div_proj(ist,i,irp,kplp,isp,2) = div_proj(ist,i,irp,kplp,isp,2) &
                                        + vylmd(m,i-l*l,2) * dwf(ist) &
                                        * rsymm%chi(irp,itran)

                                   div_proj(ist,i,irp,kplp,isp,3) = div_proj(ist,i,irp,kplp,isp,3) &
                                        + vylmd(m,i-l*l,3) * dwf(ist) &
                                        * rsymm%chi(irp,itran)
                             enddo
                          enddo
                       enddo
                    enddo
                 enddo
                 !$OMP END PARALLEL DO
              endif !}}}
           enddo
        enddo               !lp = 1, nlp !}}}
      ! write(9,*) 'forcnloc debug print 1, iat ity',iat, ity

      ! All reduce of non-directional component only.
      ! Changes calculation from:
      !       sum(x) * sum(y)
      !   on master rank to
      !       sum( sum(x) * (y1 + y2 + y3) )
      !   to substantially reduce communication and
      !   utilize all available processes.
      if (elec_st%cplx) then
         call zpsum(zvywf(1:nstate,1,1,1,1),nstate*nrep*kpnum*16*elec_st%nspin,commsize,comm(iat))
      else
         call psum(vywf(1,1,1,1,1),nstate*nrep*kpnum*16*nspin,commsize,comm(iat))
      endif
        !$OMP PARALLEL DO DEFAULT(SHARED)&
        !$OMP PRIVATE(isp,kplp,irp,ist,i, eigencount, occu)&
        !$OMP REDUCTION(+:fnloc)
           do isp = 1, nspin
              do kplp = 1, kpnum
                 do irp = 1, nrep
                    eigencount = elec_st%eig(irp,kplp,isp)%nec
                    occu(1:eigencount) = elec_st%eig(irp,kplp,isp)%occ(1:eigencount)
                    if (elec_st%cplx) then
                       do i = 1, nlp*nlp 
                          do ist = 1, eigencount
                             fnloc(:) = fnloc(:) + real(zvywf(ist,i,irp,kplp,isp) &
                                  *conjg(zdiv_proj(ist,i,irp,kplp,isp,1:3)))* &
                                  occu(ist)*weight(kplp)
                          enddo
                       enddo
                    else
                       do i = 1, nlp*nlp
                          do ist = 1, eigencount
                             fnloc(:) = fnloc(:) + vywf(ist,i,irp,kplp,isp) &
                                  *div_proj(ist,i,irp,kplp,isp,1:3)* &
                                  occu(ist)*weight(kplp) !AJB TODO: understand why the force is weighted
                          enddo
                       enddo
                    endif
                 enddo
              enddo
           enddo
        !$OMP END PARALLEL DO

           ! Multiply the forces - 2 for a pre-factor existing in the
           ! implemented formula, an extra 2 for the spin degeneracy of each
           ! state if NOT polarized.
           !
           fnloc = four * fnloc / real(nspin,dp)
           !
           ! report forces explicitly, if asked (only for debugging)

!        call psum(fnloc(1),3,commsize,comm(iat))
#ifdef MPI
#ifdef WITH_MPI_F08
        tmp_comm_f08%mpi_val = comm(iat)
#else
        tmp_comm_f08 = comm(iat)
#endif
        call MPI_Reduce(fnloc(1), del_force(1,ja), 3, MPI_REAL, MPI_SUM, 0, tmp_comm_f08, err)
#endif

        ! The local master performs the storage.
        ! Do we need to randomize the ordering of the comms to 
        !     reduce the chances of a single comm choking on the storage?
!#ifdef MPI
!        call MPI_COMM_RANK(comm(iat), local_rank, err)
!#else
!        local_rank = 0
!#endif
!        if (local_rank == 0) then
           ! The final force must be stored in the parallel%iammaster
           !    clust object. So, need to temporarily store during
           !    the loop and reduce + store on the master rank
           !    after completion.
!           del_force(:,ja) = fnloc(:) 
!        endif     ! local_rank

     enddo        ! iat = 1, nat

#ifdef MPI
     ! Free the non-null communicators for reuse
     !   in calculations with extremely large numbers of atoms
     do iat = 1, this_group
!        if ( comm(iat) /= MPI_COMM_NULL )&
!          call MPI_COMM_FREE(comm(iat), err)
     enddo
#endif

  enddo                     ! group = 1, atom_grps
  enddo                     ! ity = 1,clust%type_num
  !      write(9,*) ' forcnloc reports: done'
  !
  ! Report coordinates, net forces, net forces relative to center
  ! of mass, net total torque
  !

  ! Retrieve all force results
  call psum(del_force(1,1),3*clust%atom_num,parallel%procs_num,parallel%comm)
!  if (parallel%iammaster) then
!    call MPI_Reduce(MPI_IN_PLACE, del_force(1,1), 3*clust%atom_num, MPI_REAL, MPI_SUM, parallel%masterid, parallel%comm, err)
!  else
!    call MPI_Reduce(del_force(1,1), del_force(1,1), 3*clust%atom_num, MPI_REAL, MPI_SUM, parallel%masterid, parallel%comm, err)
!  endif

  rankperatom = rankperatom / local_count
  write(9,*) 'Local number of atoms = ', local_count
  write(9,*) 'Ranks per atom solved locally = ', rankperatom

  if (parallel%iammaster) then

     do iat=1, clust%atom_num 
       if (ipr >= 1) then
          write(7,40)  iat,clust%xatm(iat),clust%yatm(iat), &
            clust%zatm(iat), del_force(:,iat)
       endif
     enddo

     ! If VDW, prep the array for vectorization
     ! (Is this an improvement? The vdw force is applied as a simple
     !   addition, so is the time of doing this realignment ever made
     !   up during the reduction?) 
     if (elec_st%do_vdw) then
        do ja_vdw=1,clust%atom_num
           do m_vdw=1,3
              ! and that is the price you pay 10110!
              vdw_forces_t(m_vdw,ja_vdw)=clust%vdw_forces(ja_vdw,m_vdw)
           enddo
        enddo
     endif

     nasum = 0
     sosum = 0
     do ity = 1,clust%type_num
        nat = clust%natmi(ity) 
        ! increment previous atom type counters
        if (ity > 1) then
           nasum = nasum + clust%natmi(ity-1)
           if (p_pot%so(ity-1)) then
              sosum = sosum + clust%natmi(ity-1) 
           endif
        endif

        !$OMP PARALLEL DO DEFAULT(NONE)&
        !$OMP& SHARED(nat, nasum, sosum, del_force, elec_st, vdw_forces_t)&
        !$OMP& SHARED(nloc_p_pot, clust)&
        !$OMP& PRIVATE(ja, js)
        ! Adjust forces due to non-local, vdW and spin contributions
        do iat = 1, nat
           ja = nasum + iat
           if (nloc_p_pot%so(ja)) js = sosum + iat

           ! write(9,*) ' updating total force array for iat ', iat
           ! update TOTAL force array
           clust%force(:,ja) = clust%force(:,ja) + del_force(:,ja)

           ! add vdW forces
           if (elec_st%do_vdw) then
              ! factor of 2 to convert from Ha/bohr to Ry/bohr
              clust%force(:,ja)=clust%force(:,ja)+two*vdw_forces_t(:,ja)
           endif

           ! add spin forces
           if(nloc_p_pot%so(ja)) &
              clust%force(:,ja) = clust%force(:,ja) - real(clust%force_so(:,js))
        enddo
        !$OMP END PARALLEL DO
     enddo

     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'Coordinates, forces, torque'
     write(7,*) '============================'
     write(7,*)
     endif

     if (symm%ntrans > 1) then
        !
        ! symmetrize forces
        !
        if (ipr == 1) then
           write(7,*) 'coordinates and tot. forces (no symmetrization)'
           write(7,41)
           do  j = 1,clust%atom_num
              write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                   clust%force(1,j),clust%force(2,j),clust%force(3,j)
           enddo
        endif
        !
        ! if there are symmetry operations, perform symmetrization
        !
        if (symm%use_symm) then
           write(7,*) ' symmetrizing forces according to symmetry operations '
           call symm_forces(clust,symm,ierr)
        endif
     endif

     ! report coordinates and forces, accumulate and report total force
     fsum = sum( clust%force, dim=2 )
     if (ipr >= 1) then
        write(7,*) 'coordinates and symmetrized tot. forces'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(1,j),clust%force(2,j),clust%force(3,j)
        enddo
        write(7,*)
     endif
     if (ipr >= 0) then
         !AJB - don't know if this should be printed in averbose mode
     write(7,42) fsum
     endif

     ! net total force per atom
     fatom = fsum/real(clust%atom_num,dp)

     ! compute and report net force per atom (after subtracting the
     ! mean) and the net torque on the cluster (relevant only if
     ! periodic boundary conditions are not used)
     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'coordinates and tot. forces (after setting net force to zero)'
     write(7,41)
     do  j = 1,clust%atom_num
        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
             clust%force(:,j) - fatom
     enddo
     endif

     if (.not. is_pbc) then
        xmom = zero
        ymom = zero
        zmom = zero
        do  j = 1,clust%atom_num
           xmom = xmom+clust%yatm(j)*clust%force(3,j) - clust%zatm(j)*clust%force(2,j)
           ymom = ymom+clust%zatm(j)*clust%force(1,j) - clust%xatm(j)*clust%force(3,j)
           zmom = zmom+clust%xatm(j)*clust%force(2,j) - clust%yatm(j)*clust%force(1,j)
        enddo
        if (ipr >= 0) then
           write(7,*)
           write(7,43) xmom, ymom, zmom
           write(7,*)
        endif
     endif

     if (.not. pot%fex_is) then
        do j = 1,clust%atom_num
           clust%force(:,j) = clust%force(:,j) - fatom
        enddo
     elseif (ipr >= 0) then
        write(7,*) 'Net forces not removed in FDET.'
     endif
  endif

  if (elec_st%cplx) then
     deallocate(zvywf)
     deallocate(zdiv_proj)
     deallocate(zwf)
  else
     deallocate(vywf)
     deallocate(div_proj)
     deallocate(dwf)
  endif

  if (allocated(weight)) deallocate(weight)
  deallocate(del_force)
  deallocate(occu)
  deallocate(comm)

  ! format statements
40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)
42 format(13x,'tot.  (net) force [Ry/bohr]:',3x,3(f11.6,1x))
43 format(' tot. torque [Ry/radian] :',2x,3(f11.6,1x))

end subroutine forcnloc_comm













!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! Updated July 2017 to add thread scaling (NERSC):
! * Calculation distributed over all MPI ranks. Now, only
!      storage of fnloc result restricted to master rank. 
! * Wavefunction variable split to reduce communication time.
!      (vywf -> vywf & div_proj)
! * Temporary wavefunction variable on master rank removed.
! * Combined p_pot_ekbi loop with wavefunction calculation
! * Data structures rearranged and data cut to local storage
!      to optimize calculations for unit stride vectorization.
! * OpenMP added to inner loops to scale calc with threads.
!
! http://link.aps.org/doi/10.1103/PhysRevB.50.12234
!
!---------------------------------------------------------------
subroutine forcnloc(clust, elec_st, p_pot, nloc_p_pot, symm, rsymm, &
        parallel, is_pbc, ipr, ierr, pot)

use constants
use potential_module
use cluster_module
use electronic_struct_module
use pseudo_potential_module
use non_local_psp_module
use symmetry_module
use parallel_data_module
use psum_module
use spin_orbit_module, only : forcso
use symm_forces_module
use aux, only : alccheck

implicit none

! Input variables:

! the cluster
type(cluster), intent(inout) :: clust

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! pseudopotential related data
type(pseudo_potential), intent(in) :: p_pot

! non local pseudopotential related data
type(nonloc_pseudo_potential), intent(inout) :: nloc_p_pot

! symmetry operations
type(symmetry), intent(in) :: symm, rsymm

! parallel computation related data
type(parallel_data), intent(in) :: parallel
type(potential), intent(in) :: pot

! PBC flag
logical, intent(in) :: is_pbc

! output error
integer, intent(out) :: ierr

! print flag
integer, intent(in) :: ipr




! Work variables:

!
! working arrays
!
! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
! - index "0" - and its derivative projections, for the non-local
! region around each atom - indices "1:3".
!real(dp) :: vylmd(1:nloc_p_pot%maxnloc,7,0:3)
real(dp), dimension(:,:,:), allocatable :: vylmd

! vylm*(actual wave function), for each state's non-local
! region around each atom
complex(dpc), dimension(:,:,:,:,:), allocatable :: zvywf
real(dp), dimension(:,:,:,:,:), allocatable :: vywf

! vylm*(actual wave function), for each state's derivative
! projections (indices "1:3" = i,j,k)
complex(dpc), dimension(:,:,:,:,:,:), allocatable :: zdiv_proj
real(dp), dimension(:,:,:,:,:,:), allocatable :: div_proj

! total forces, total forces per atom
real(dp), dimension(3) :: fsum, fatom

! temporary variables:
! holders of # of non-local components, local component, # of
! atoms for each atom type       
integer :: nlp, local, nat

! holder of non-local forces on a given atom
real(dp), dimension(3) :: fnloc

! holder of # of non-local grid points around each atom
integer :: mnloc

! counters
integer m,mg,itran,m_vdw

! atom counter all atoms and spin-orbit corrected ones, respectively
integer ja, js, ja_vdw

! non-local projector counter
integer ilm

! loop counters
integer i,isp,j,ity,iat,ist,l,lp,locpnt,irp,lm

! local aliases of variables contained in structures
integer spnum, nstate, comm, nrep, mydim

! total torque, non-PBC only
real(dp) :: xmom, ymom, zmom
integer offset, jj

! kpoint variables
integer kplp, kpnum

! weight of each kpoint being examined
real(dp), dimension(:), allocatable :: weight
real (dp) :: vdw_forces_t(3,clust%atom_num)

! temporary variables for vectorization
real(dp), dimension(:), allocatable :: occu
real(dp), dimension(:), allocatable :: dwf
complex(dpc), dimension(:), allocatable :: zwf
integer eigencount
integer alcstat !< holds memory error code
integer memcheck(2) !< holds memory, signals checking stats

integer :: colgroup_of_this_state
integer :: jcol_local
integer :: max_nstates_per_colgroup

!---------------------------------------------------------------

kpnum = max(elec_st%nkpt,1)

allocate(weight(kpnum))

if (elec_st%nkpt > 0) then 
        weight(:) = elec_st%kpwt(:)
else
        weight(:) = one
endif

spnum = elec_st%nspin/elec_st%mxwd
nrep = elec_st%nrep
comm = parallel%comm
mydim = parallel%mydim




! Get maximum number of converged eigenstates per representation
! and allocate arrays accordingly.
nstate = 0
max_nstates_per_colgroup = 0
do isp = 1, spnum
do kplp = 1, kpnum
do irp = 1, nrep
        if (elec_st%eig(irp,kplp,isp)%nec > nstate) then
                nstate = elec_st%eig(irp,kplp,isp)%nec
        endif

        ! KHL: For the size of dwf and zwf.
        !      Each taskgroup calculates nstates_per_colgroup states
        !      (which may be larger than nec if CHEBDAV is used, and
        !      be equal to nec if CHEBFF is used)
        if (elec_st%eig(irp,kplp,isp)%nstates_per_colgroup > &
                max_nstates_per_colgroup) then
                max_nstates_per_colgroup = &
                        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup
        endif
enddo
enddo
enddo

if (elec_st%cplx) then
        allocate(zvywf(nstate,16,nrep,kpnum,elec_st%nspin))
        allocate(zdiv_proj(nstate,16,nrep,kpnum,elec_st%nspin,3)) 
        allocate(zwf(max_nstates_per_colgroup))
else
        allocate(vywf(nstate,16,nrep,kpnum,spnum))
        allocate(div_proj(nstate,16,nrep,kpnum,spnum,3))
        allocate(dwf(max_nstates_per_colgroup))
endif

allocate(occu(nstate))
occu = zero  
allocate(vylmd(1:nloc_p_pot%maxnloc,7,0:3), stat=alcstat)
#ifdef WITH_CAUX
call alccheck('vylmd', nloc_p_pot%maxnloc*7*4, alcstat, memcheck)
#else
call alccheck('vylmd', nloc_p_pot%maxnloc*7*4, alcstat)
#endif
vylmd(:,:,:)= zero

! initialize arrays to zero
! these are double touched right now - we can change it later
if (elec_st%cplx) then
        zvywf(:,:,:,:,:) = zzero
        zdiv_proj(:,:,:,:,:,:) = zzero
        zwf(:) = zzero
else
        vywf(:,:,:,:,:) = zero
        div_proj(:,:,:,:,:,:) = zero
        dwf(:) = zero
endif




if (parallel%iammaster) then
        ! header, if printing
        if (ipr >= 1) then
                write(7,*)
                write(7,*) 'Coordinates and local force components'
                write(7,*) '======================================'

                if (is_pbc) write(7,*) '(Ewald forces included)'

                write(7,41)

                do j = 1,clust%atom_num
                        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                                clust%force(:,j)
                enddo

                write(7,*)
                write(7,*)
                write(7,*) 'Reporting non-local force components'
                write(7,*) '===================================='
                write(7,41)
        endif
endif



! if spin-orbit correction is done, 
! calculate the forces of spin-orbit potentials
if (elec_st%is_so) then
        call forcso(clust, elec_st, nloc_p_pot, parallel)

        if (.not. elec_st%scf_so .and. parallel%iammaster) then
                write(7,*) 'WARNING! spin-orbit is calculated as a perturbation'
                write(7,*) 'Spin-orbit forces may be inaccurate!'
        endif

        if (parallel%iammaster) then
                write(7,*) 'Adding spin-orbit contribution to forces'
        endif
endif





! atom index, ja		
ja = 0
js = 0
! non-local projector index
ilm = 0
! for all atom types...
do ity = 1, clust%type_num
        nlp = p_pot%nlocp(ity)
        local = p_pot%loc(ity)
        nat = clust%natmi(ity)

        ! for all atoms within each type...
        do iat = 1, nat
                !write(9,*) ' doing atom ', iat
                ja = ja + 1

                !index for atoms with spin-orbit forces
                if (nloc_p_pot%so(ja)) js = js + 1

                ! determine size of non-local region around the atom (# of
                ! nonlocal grid points around each atom)
                mnloc = nloc_p_pot%nlatom(ja)

                ! initialize non-local forces on each atom to zero
                fnloc(:) =  zero

                ! initialize arrays to zero
                if (elec_st%cplx) then
                        zvywf(:,:,:,:,:) = zzero
                        zdiv_proj(:,:,:,:,:,:) = zzero
                        zwf(:) = zzero
                else
                        vywf(:,:,:,:,:) = zero
                        div_proj(:,:,:,:,:,:) = zero
                        dwf(:) = zero
                endif

                occu(:) = zero  

                ! add contributions from all non-local components...
                lm = 0

                !write(9,*) ' forcnloc reports: '

                do lp = 1, nlp
                        l = lp - 1

                        ! skip it this is the local component
                        if (lp == local) cycle

                        if (ipr >= 0) then
                                write(9,*) ' I received L = ',l,' for atom #',ja, &
                                        ' with mnloc = ',mnloc
                        endif

                        do i = 1, 2*lp - 1
                        do locpnt = 1, mnloc
                                vylmd(locpnt,i,0) = nloc_p_pot%anloc(locpnt, ilm+i)
                                vylmd(locpnt,i,1) = nloc_p_pot%vylmd(1,locpnt, ilm+i)
                                vylmd(locpnt,i,2) = nloc_p_pot%vylmd(2,locpnt, ilm+i)
                                vylmd(locpnt,i,3) = nloc_p_pot%vylmd(3,locpnt, ilm+i)
                        enddo
                        enddo

                        lm = lm + 2*lp - 1
                        ilm = ilm + 2*lp - 1

                        do isp = 1, elec_st%nspin
                                jj = isp

                                if (elec_st%cplx) then
                                        if (elec_st%is_so) then
                                                jj = 1
                                                offset = (isp -1)*parallel%ndim
                                        else
                                                offset = 0
                                        endif

                                        !$OMP PARALLEL DO DEFAULT(SHARED) &
                                        !$OMP PRIVATE(m, mg, itran, kplp, irp, eigencount, &
                                        !$OMP   i, ist, zwf, colgroup_of_this_state, jcol_local)
                                        !!$OMP REDUCTION(+:zvywf,zdiv_proj)
                                        do m = 1, mnloc
                                                mg = nloc_p_pot%indw(m,ja) + offset
                                                itran = nloc_p_pot%tran(m,ja)

                                                if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row

                                                if (elec_st%nkpt > 0) then
                                                        do kplp = 1, kpnum
                                                        do irp = 1, nrep

if ( elec_st%eig(irp,kplp,jj)%taskgroup /= parallel%mygroup ) cycle

eigencount = elec_st%eig(irp,kplp,jj)%nec
zwf(1:elec_st%eig(irp,kplp,jj)%nstates_per_colgroup) = &
        elec_st%eig(irp,kplp,jj)%zwf(mg,1:elec_st%eig(irp,kplp,jj)%nstates_per_colgroup)
!zwf(1:eigencount) = elec_st%eig(irp,kplp,jj)%zwf(mg,1:eigencount)

                                                                do i = l*l + 1, lp*lp
                                                                do ist = 1, eigencount

colgroup_of_this_state = (ist-1) / elec_st%eig(irp,kplp,jj)%nstates_per_colgroup
jcol_local = mod((ist-1), elec_st%eig(irp,kplp,jj)%nstates_per_colgroup) + 1

                                                                        if (colgroup_of_this_state == parallel%mycolgroup) then
!$OMP ATOMIC
zvywf(ist,i,irp,kplp,isp) = zvywf(ist,i,irp,kplp,isp) &
        + vylmd(m,i-l*l,0) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,0) * zwf(ist) &
        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja) * p_pot%ekbi(lp,ity)

!$OMP ATOMIC
zdiv_proj(ist,i,irp,kplp,isp,1) = zdiv_proj(ist,i,irp,kplp,isp,1) &
        + vylmd(m,i-l*l,1) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,1) * zwf(ist) &
        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

!$OMP ATOMIC
zdiv_proj(ist,i,irp,kplp,isp,2) = zdiv_proj(ist,i,irp,kplp,isp,2) &
        + vylmd(m,i-l*l,2) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,2) * zwf(ist) &
        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)

!$OMP ATOMIC
zdiv_proj(ist,i,irp,kplp,isp,3) = zdiv_proj(ist,i,irp,kplp,isp,3) &
        + vylmd(m,i-l*l,3) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,3) * zwf(ist) &
        * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)
                                                                        endif
                                                                enddo
                                                                enddo
                                                        enddo
                                                        enddo
                                                else  !if (elec_st%nkpt > 0) then
                                                        do irp = 1, nrep
if ( elec_st%eig(irp,1,jj)%taskgroup /= parallel%mygroup ) cycle

eigencount = elec_st%eig(irp,1,jj)%nec
zwf(1:elec_st%eig(irp,1,jj)%nstates_per_colgroup) = &
        elec_st%eig(irp,1,jj)%zwf(mg,1:elec_st%eig(irp,1,jj)%nstates_per_colgroup)
!zwf(1:eigencount) = elec_st%eig(irp,1,jj)%zwf(mg,1:eigencount)

                                                                do i = l*l + 1, lp*lp
                                                                do ist = 1, eigencount

                                                                        colgroup_of_this_state = (ist-1) / &
                                                                                elec_st%eig(irp,1,jj)%nstates_per_colgroup
                                                                        jcol_local = mod((ist-1), &
                                                                                elec_st%eig(irp,1,jj)%nstates_per_colgroup) + 1

                                                                        if (colgroup_of_this_state == parallel%mycolgroup) then
zvywf(ist,i,irp,1,isp) = zvywf(ist,i,irp,1,isp) &
        + vylmd(m,i-l*l,0) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,0) * zwf(ist) &
        * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

zdiv_proj(ist,i,irp,1,isp,1) = zdiv_proj(ist,i,irp,1,isp,1) &
        + vylmd(m,i-l*l,1) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,1) * zwf(ist) &
        * rsymm%chi(irp,itran)

zdiv_proj(ist,i,irp,1,isp,2) = zdiv_proj(ist,i,irp,1,isp,2) &
        + vylmd(m,i-l*l,2) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,2) * zwf(ist) &
        * rsymm%chi(irp,itran)

zdiv_proj(ist,i,irp,1,isp,3) = zdiv_proj(ist,i,irp,1,isp,3) &
        + vylmd(m,i-l*l,3) * zwf(jcol_local) &
        !+ vylmd(m,i-l*l,3) * zwf(ist) &
        * rsymm%chi(irp,itran)
                                                                        endif
                                                                enddo
                                                                enddo
                                                        enddo
                                                endif  !if (elec_st%nkpt > 0) then
                                        enddo     !do m = 1, mnloc
                                        !$OMP END PARALLEL DO

                                else !if (elec_st%cplx) then

                                        !$OMP PARALLEL DO DEFAULT(SHARED)&
                                        !$OMP PRIVATE(m, mg, itran, kplp, irp, ist, i, j, dwf)&
                                        !$OMP REDUCTION(+:vywf,div_proj)
                                        do m = 1, mnloc
                                                mg = nloc_p_pot%indw(m,ja)
                                                itran = nloc_p_pot%tran(m,ja)

                                                if (mg <= 0 .or. mg > mydim) cycle ! non-local row

                                                do kplp = 1, kpnum
                                                do irp = 1, nrep

if (elec_st%eig(irp,kplp,isp)%taskgroup /= parallel%mytaskgroup) cycle

dwf(1:elec_st%eig(irp,kplp,jj)%nstates_per_colgroup) = &
        elec_st%eig(irp,kplp,jj)%wf(mg,1:elec_st%eig(irp,kplp,jj)%nstates_per_colgroup)

                                                        do i = l*l+1, lp*lp
                                                        do ist = 1, elec_st%eig(irp,kplp,jj)%nec

                                                                colgroup_of_this_state = (ist-1) / &
                                                                        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup
                                                                jcol_local = mod((ist-1), &
                                                                        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup) + 1

                                                                if (colgroup_of_this_state == parallel%mycolgroup) then
vywf(ist,i,irp,kplp,isp) = vywf(ist,i,irp,kplp,isp) + &
        vylmd(m,i-l*l,0) * dwf(jcol_local) * rsymm%chi(irp,itran) * p_pot%ekbi(lp,ity)

div_proj(ist,i,irp,kplp,isp,1) = div_proj(ist,i,irp,kplp,isp,1) + &
        vylmd(m,i-l*l,1) * dwf(jcol_local) * rsymm%chi(irp,itran)

div_proj(ist,i,irp,kplp,isp,2) = div_proj(ist,i,irp,kplp,isp,2) + &
        vylmd(m,i-l*l,2) * dwf(jcol_local) * rsymm%chi(irp,itran)

div_proj(ist,i,irp,kplp,isp,3) = div_proj(ist,i,irp,kplp,isp,3) + &
        vylmd(m,i-l*l,3) * dwf(jcol_local) * rsymm%chi(irp,itran)
                                                                endif
                                                        enddo
                                                        enddo
                                                enddo
                                                enddo
                                        enddo
                                        !$OMP END PARALLEL DO
                                endif  !if (elec_st%cplx) then
                        enddo  !do isp = 1, elec_st%nspin
                enddo  !lp = 1, nlp !}}}

                ! write(9,*) 'forcnloc debug print 1, iat ity',iat, ity

                ! All reduce of non-directional component only.
                ! Changes calculation from:
                !       sum(x) * sum(y)
                !   on master rank to 
                !       sum( sum(x) * (y1 + y2 + y3) )
                !   to substantially reduce communication and
                !   utilize all available processes.
                if (elec_st%cplx) then
                        call zpsum(zvywf(1:nstate,1,1,1,1),nstate*nrep*kpnum*16*elec_st%nspin,parallel%procs_num,comm)
                else
                        call psum(vywf(1,1,1,1,1),nstate*nrep*kpnum*16*spnum,parallel%procs_num,comm)
                endif     

                !$OMP PARALLEL DO DEFAULT(SHARED)&
                !$OMP PRIVATE(isp,kplp,irp,ist,i, eigencount, occu)&
                !$OMP REDUCTION(+:fnloc)
                do isp = 1, spnum
                do kplp = 1, kpnum
                do irp = 1, nrep
                        eigencount = elec_st%eig(irp,kplp,isp)%nec
                        occu(1:eigencount) = elec_st%eig(irp,kplp,isp)%occ(1:eigencount)

                        if (elec_st%cplx) then
                                do i = 1, nlp*nlp 
                                do ist = 1, eigencount
                                        fnloc = fnloc + real(zvywf(ist,i,irp,kplp,isp) &
                                                *conjg(zdiv_proj(ist,i,irp,kplp,isp,1:3)))* &
                                                occu(ist)*weight(kplp)
                                enddo
                                enddo
                        else
                                do i = 1, nlp*nlp
                                do ist = 1, eigencount
                                        fnloc(:) = fnloc(:) + vywf(ist,i,irp,kplp,isp)* &
                                                div_proj(ist,i,irp,kplp,isp,1:3)* &
                                                occu(ist)*weight(kplp) !AJB TODO: understand why the force is weighted
                                enddo
                                enddo
                        endif
                enddo
                enddo
                enddo
                !$OMP END PARALLEL DO

                ! Multiply the forces - 2 for a pre-factor existing in the
                ! implemented formula, an extra 2 for the spin degeneracy of each
                ! state if NOT polarized.
                !
                fnloc(:) = four * fnloc(:) / real(spnum,dp)

                call psum(fnloc(1), 3, parallel%procs_num, comm)

                if (parallel%iammaster) then

                        ! report forces explicitly, if asked (only for debugging)
                        if (ipr >= 1) then
                                write(7,40) ja, clust%xatm(ja), clust%yatm(ja), clust%zatm(ja), fnloc(:)
                        endif

                        ! write(9,*) ' updating total force array for iat ', iat
                        ! update TOTAL force array
                        clust%force(:,ja) = clust%force(:,ja) + fnloc
           
                        ! add vdW forces
                        if (elec_st%do_vdw) then
                                do ja_vdw=1,clust%atom_num
                                do m_vdw=1,3
                                        ! and that is the price you pay 10110!
                                        vdw_forces_t(m_vdw,ja_vdw)=clust%vdw_forces(ja_vdw,m_vdw)
                                enddo
                                enddo

                                ! factor of 2 to convert from Ha/bohr to Ry/bohr
                                clust%force(:,ja)=clust%force(:,ja)+two*vdw_forces_t(:,ja)
                        endif

                        if(nloc_p_pot%so(ja)) then
                                clust%force(:,ja) = clust%force(:,ja) - real(clust%force_so(:,js))
                        endif
                endif

                ! write(9,*) 'forcnloc debug print 2, iat, ity', iat, ity
        enddo ! iat = 1, nat
enddo  ! ity = 1,clust%type_num





!      write(9,*) ' forcnloc reports: done'
!
! Report coordinates, net forces, net forces relative to center
! of mass, net total torque
!

if (parallel%iammaster) then
        if (ipr >= 0) then
                write(7,*)
                write(7,*) 'Coordinates, forces, torque'
                write(7,*) '============================'
                write(7,*)
        endif

        if (symm%ntrans > 1) then
                !
                ! symmetrize forces
                !
                if (ipr == 1) then
                        write(7,*) 'coordinates and tot. forces (no symmetrization)'
                        write(7,41)

                        do j = 1, clust%atom_num
                                write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                                        clust%force(1,j),clust%force(2,j),clust%force(3,j)
                        enddo
                endif

                ! if there are symmetry operations, perform symmetrization
                if (symm%use_symm) then
                        write(7,*) ' symmetrizing forces according to symmetry operations '

                        call symm_forces(clust,symm,ierr)
                endif
        endif

        ! report coordinates and forces, accumulate and report total force
        fsum = sum( clust%force, dim=2 )

        if (ipr >= 1) then
                write(7,*) 'coordinates and symmetrized tot. forces'
                write(7,41)

                do j = 1,clust%atom_num
                        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                                clust%force(1,j),clust%force(2,j),clust%force(3,j)
                enddo

                write(7,*)
        endif

        if (ipr >= 0) then
                !AJB - don't know if this should be printed in averbose mode
                write(7,42) fsum
        endif

        ! net total force per atom
        fatom = fsum/real(clust%atom_num,dp)

        ! compute and report net force per atom (after subtracting the
        ! mean) and the net torque on the cluster (relevant only if
        ! periodic boundary conditions are not used)
        if (ipr >= 0) then
                write(7,*)
                write(7,*) 'coordinates and tot. forces (after setting net force to zero)'
                write(7,41)

                do j = 1, clust%atom_num
                        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                                clust%force(:,j) - fatom
                enddo
        endif

        if (.not. is_pbc) then
                xmom = zero
                ymom = zero
                zmom = zero

                do j = 1,clust%atom_num
                        xmom = xmom+clust%yatm(j)*clust%force(3,j) - clust%zatm(j)*clust%force(2,j)
                        ymom = ymom+clust%zatm(j)*clust%force(1,j) - clust%xatm(j)*clust%force(3,j)
                        zmom = zmom+clust%xatm(j)*clust%force(2,j) - clust%yatm(j)*clust%force(1,j)
                enddo

                if (ipr >= 0) then
                        write(7,*)
                        write(7,43) xmom, ymom, zmom
                        write(7,*)
                endif
        endif

        if (.not. pot%fex_is) then
                do j = 1,clust%atom_num
                        clust%force(:,j) = clust%force(:,j) - fatom
                enddo
        elseif (ipr >= 0) then
                write(7,*) 'Net forces not removed in FDET.'
        endif
endif

if (elec_st%cplx) then
        deallocate(zvywf)
        deallocate(zdiv_proj)
        deallocate(zwf)
else
        deallocate(vywf)
        deallocate(div_proj)
        deallocate(dwf)
endif



if (allocated(weight)) deallocate(weight)
if (allocated(vylmd)) deallocate(vylmd)
if (allocated(occu)) deallocate(occu)




40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)
42 format(13X,'tot.  (net) force [Ry/bohr]:',3X,3(F11.6,1X))
43 format(' tot. torque [Ry/radian] :',2X,3(F11.6,1X))

end subroutine forcnloc














!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! ---------------------------------------------------------------
subroutine forcnloc_u(clust,elec_st,p_pot,u_pot,symm,rsymm, &
     parallel,ipr,ierr)

  use constants
  use cluster_module
  use electronic_struct_module
  use pseudo_potential_module
  use non_local_psp_module
  use symmetry_module
  use symm_forces_module
  use parallel_data_module
  use psum_module

  implicit none
  !
  ! Input variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(in) :: elec_st
  ! pseudopotential related data
  type (pseudo_potential), intent(in) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(in) :: u_pot
  ! symmetry operations
  type (symmetry), intent(in) :: symm, rsymm
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel

  ! output error
  integer, intent(out) :: ierr
  ! print flag
  integer, intent(in) :: ipr
  !
  ! Work variables:
  !
  complex(dpc), allocatable :: ztvywd(:,:,:,:,:,:)
  real(dp), allocatable :: tvywd(:,:,:,:,:,:)
  !
  ! working arrays
  !
  ! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
  ! - index "0" - and its derivative projections, for the non-local
  ! region around each atom - indices "1:3".
  real(dp) :: vylmd(0:3,1:u_pot%maxnloc,7)
  ! vylm*(actual wave function), for each state, for the non-local
  ! region around each atom (index "0"), and its derivative
  ! projections (indices "1:3")
  complex(dpc), allocatable :: zvywd(:,:,:,:,:,:)
  real(dp), allocatable :: vywd(:,:,:,:,:,:)

  ! temporary variables:
  ! holders of # of non-local components, # of atoms for each atom type       
  integer nlp,nat
  ! holder for the product of density potential and projectors
  ! (only d channel is assumed!)
  complex(dpc) :: zvyd(5)
  real(dp) :: vyd(5)
  ! holder of non-local forces on a given atom
  real(dp) :: fnloc(3)
  ! holder of # of non-local grid points around each atom
  integer mnloc

  ! counters
  integer m,mg,itran
  ! atom counter
  integer ja,jja
  ! non-local projector counter
  integer ilm
  ! loop counters
  integer i,isp,j,ity,iat,ist,l,lp,locpnt,irp,lm

  ! local aliases of variables contained in structures
  integer nspin, nstate, comm, nrep, mydim

  integer offset, jj

  ! kpoint variables
  integer kplp, kpnum
  ! weight of each kpoint being examined
  real(dp), dimension(:), allocatable :: weight

  ! ---------------------------------------------------------------

  kpnum = max(elec_st%nkpt,1)
  allocate(weight(kpnum))
  if (elec_st%nkpt > 0) then 
     weight = elec_st%kpwt
  else
     weight = one
  endif

  nspin = elec_st%nspin/elec_st%mxwd
  nrep = elec_st%nrep
  comm = parallel%comm
  mydim = parallel%mydim

  ! Get maximum number of converged eigenstates per representation
  ! and allocate arrays accordingly.
  nstate = 0
  do isp = 1, nspin
     do kplp = 1, kpnum
        do irp = 1, nrep
           if (elec_st%eig(irp,kplp,isp)%nec > nstate) nstate = &
                elec_st%eig(irp,kplp,isp)%nec
        enddo
     enddo
  enddo
  if (elec_st%cplx) then
     allocate( ztvywd(nstate,0:3,nrep,kpnum,16,elec_st%nspin) )
  else
     allocate( tvywd(nstate,0:3,nrep,kpnum,16,nspin) )
  endif

  if (parallel%iammaster) then
     if (elec_st%cplx) then
        allocate( zvywd(0:3,nstate,nrep,kpnum,16,elec_st%nspin) )
     else
        allocate( vywd(0:3,nstate,nrep,kpnum,16, nspin) )
     endif
     ! header, if printing
     if (ipr >= 1) then
        write(7,*)
        write(7,*)
        write(7,*) 'Reporting force components from U potential'
        write(7,*) '==========================================='
        write(7,41)
     endif
  endif

  ! atom index, ja		
  ja = 0
  ! non-local projector index
  ilm = 0
  ! for all atom types...
  do ity = 1,clust%type_num
     nlp = p_pot%nlocp(ity)
     nat = clust%natmi(ity)
     ! for all atoms within each type...
     do iat = 1, nat
        ja = ja + 1
        ! determine size of non-local region around the atom (# of
        ! nonlocal grid points around each atom)
        jja = u_pot%so_indx(ja)
        if (jja == 0) cycle
        mnloc = u_pot%nlatom(jja)

        if (parallel%iammaster) then
           ! initialize non-local forces on each atom to zero
           fnloc(:) =  zero
           ! initialize vywd array to zero
           if (elec_st%cplx) then
              zvywd(:,:,:,:,:,:) = zzero
           else
              vywd(:,:,:,:,:,:) = zero
           endif
        endif               ! (parallel%iammaster)

        ! add contributions from all non-local components...
        lm = 0
        do lp = 1, nlp
           l = lp - 1
           ! skip components without U potential
        if ( abs(p_pot%uu(lp,ity)) < twomach_eps .or. abs(p_pot%jj(lp,ity)) < twomach_eps ) cycle
           write(9,*) ' I received L = ',l,' for atom #',jja, &
                ' with mnloc = ',mnloc
           do locpnt = 1, mnloc
              do i = 1, 2*lp - 1
                 vylmd(0,locpnt,i) = u_pot%anloc(locpnt, ilm+i)
                 do j=1,3
                    vylmd(j,locpnt,i) = u_pot%vylmd(j,locpnt, ilm+i)
                 enddo
              enddo
           enddo
           lm = lm + 2*lp - 1
           ilm = ilm + 2*lp - 1
           if(elec_st%cplx) then
              ztvywd(:,:,:,:,:,:) = zzero
           else
              tvywd(:,:,:,:,:,:) = zero
           endif
           do isp = 1, elec_st%nspin
              jj = isp
              if (elec_st%cplx) then
                 if (elec_st%is_so) then
                    jj = 1
                    offset = (isp -1)*parallel%ndim
                 else
                    offset = 0
                 endif
                 do m = 1,mnloc
                    mg = u_pot%indw(m,jja) + offset
                    itran = u_pot%tran(m,jja)
                    if ( mg >= 0  .or.  mg > mydim ) cycle ! non-local row
                    if (elec_st%nkpt > 0) then
                       do kplp = 1, kpnum
                          do irp = 1, nrep
                             if ( elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                  parallel%mygroup ) cycle
                             do ist = 1, elec_st%eig(irp,kplp,jj)%nec
                                do i = l*l + 1, lp*lp
                                   do j = 0,3
                                      ztvywd(ist,j,irp,kplp,i,isp) = &
                                           ztvywd(ist,j,irp,kplp,i,isp) &
                                           + vylmd(j,m,i-l*l) &
                                           * elec_st%eig(irp,kplp,isp)%zwf(mg,ist) &
                                           * rsymm%chi(irp,itran) *  &
                                           u_pot%right(m,kplp,jja)
                                   enddo
                                enddo
                             enddo
                          enddo
                       enddo
                    else
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,1,isp)%taskgroup /= &
                               parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,1,jj)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   ztvywd(ist,j,irp,1,i,isp) = &
                                        ztvywd(ist,j,irp,1,i,isp) &
                                        + vylmd(j,m,i-l*l) &
                                        * elec_st%eig(irp,1,isp)%zwf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    endif
                 enddo
                 write(9,*) ' calling zpsum2 for tvywd, iat ity:',iat, ity
                 call zpsum(ztvywd(1,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum*2,parallel%procs_num,comm)
                  write(9,*) ' done zpsum2'
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   zvywd(j,ist,irp,kplp,i,isp) = &
                                        zvywd(j,ist,irp,kplp,i,isp) &
                                        + ztvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif
              else
                 do m = 1,mnloc
                    mg = u_pot%indw(m,jja)
                    itran = u_pot%tran(m,jja)
                    if ( mg >= 0  .or.  mg > mydim ) cycle ! non-local row
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,isp)%taskgroup /= &
                               parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   tvywd(ist,j,irp,kplp,i,isp) = &
                                        tvywd(ist,j,irp,kplp,i,isp) &
                                        + vylmd(j,m,i-l*l) &
                                        * elec_st%eig(irp,kplp,isp)%wf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 enddo 
                 write(9,*) ' calling psum1 for tvywd, iat ity:',iat, ity
                 call psum(tvywd(1,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum,parallel%procs_num,comm)
                  write(9,*) 'done'
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   vywd(j,ist,irp,kplp,i,isp) = &
                                        vywd(j,ist,irp,kplp,i,isp) &
                                        + tvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif
              endif
           enddo

           if (parallel%iammaster) then
              do isp = 1, nspin
                 do kplp = 1, kpnum
                    do irp = 1, nrep
                       if (elec_st%cplx) then
                          zvyd = zzero
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec 
                             do j = 1, 2*lp - 1
                                zvyd(i) = zvyd(i) + &
                                     u_pot%zdenmat(i,j,jja,isp)* &
                                     zvywd(0,ist,irp,kplp,j,isp)
                             enddo
                           enddo
                          enddo
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec 
                             zvywd(0,ist,irp,kplp,i,isp) = half*zvyd(i) + &
                                  (p_pot%uu(lp,ity) - p_pot%jj(lp,ity))/four* &
                                  zvywd(0,ist,irp,kplp,j,isp)
                           enddo
                          enddo
                          
                       else
                          vyd = zero
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do j = 1, 2*lp - 1
                                vyd(i) = vyd(i) + u_pot%denmat(i,j,jja,isp)* &
                                     vywd(0,ist,irp,kplp,j,isp)
                             enddo
                           enddo
                          enddo
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             vywd(0,ist,irp,kplp,i,isp) = half*vyd(i) + &
                                  (p_pot%uu(lp,ity) - p_pot%jj(lp,ity))/four* &
                                  vywd(0,ist,irp,kplp,j,isp)
                           enddo
                          enddo
                       endif
                    enddo
                 enddo
              enddo
           endif

        enddo               !lp = 1, nlp

        if (parallel%iammaster) then
           do isp = 1, nspin
              do kplp = 1, kpnum
                 do irp = 1, nrep
                    do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                       if (elec_st%cplx) then
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + real(zvywd(0,ist,irp,kplp,i,isp) &
                                  *conjg(zvywd(1:3,ist,irp,kplp,i,isp)))* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)* &
                                  weight(kplp)
                          enddo
                       else
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + vywd(0,ist,irp,kplp,i,isp) &
                                  *vywd(1:3,ist,irp,kplp,i,isp)* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)* &
                                  weight(kplp)
                          enddo
                       endif
                    enddo
                 enddo
              enddo
           enddo
           !
           ! multiply the forces - 2 for a pre-factor existing in the
           ! implemented formula, an extra 2 for the spin degeneracy of each
           ! state if NOT polarized.
           !
           fnloc = four * fnloc / real(nspin,dp)
           !
           ! report forces explicitly, if asked (only for debugging)
           if (ipr >= 1) then
              write(7,40)  ja,clust%xatm(ja),clust%yatm(ja), &
                   clust%zatm(ja),fnloc
           endif

           ! update TOTAL force array
           clust%force(:,ja) = clust%force(:,ja) + fnloc
        endif               ! (parallel%iammaster)
     enddo                  ! iat = 1, nat
  enddo                     ! ity = 1,clust%type_num
  !
  ! if there are symmetry operations, perform symmetrization
  !
  if (parallel%iammaster .and. (symm%ntrans > 1) .and. symm%use_symm) &
       call symm_forces(clust,symm,ierr)

  if (elec_st%cplx) then
     deallocate(ztvywd)
     if (parallel%iammaster) deallocate(zvywd)
  else
     deallocate(tvywd)
     if (parallel%iammaster) deallocate(vywd)
  endif

  if (allocated(weight)) deallocate(weight)

  ! format statements
40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)

end subroutine forcnloc_u
! ===============================================================
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! http://link.aps.org/doi/10.1103/PhysRevB.50.12234
!
!---------------------------------------------------------------
subroutine forcnloc_old(clust,elec_st,p_pot,nloc_p_pot,symm,rsymm, &
        parallel,is_pbc,ipr,ierr,pot)

  use constants
  use potential_module
  use cluster_module
  use electronic_struct_module
  use pseudo_potential_module
  use non_local_psp_module
  use symmetry_module
  use parallel_data_module
  use psum_module
  use spin_orbit_module, only : forcso
  use symm_forces_module

  implicit none
  !
  ! Input variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! pseudopotential related data
  type (pseudo_potential), intent(in) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(inout) :: nloc_p_pot
  ! symmetry operations
  type (symmetry), intent(in) :: symm, rsymm
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel
  type (potential), intent(in) :: pot

  ! PBC flag
  logical, intent(in) :: is_pbc
  ! output error
  integer, intent(out) :: ierr
  ! print flag
  integer, intent(in) :: ipr
  !
  ! Work variables:
  !
  complex(dpc), allocatable :: ztvywd(:,:,:,:,:,:)
  complex(dpc), dimension(1):: ztvywdvec
  real(dp), allocatable :: tvywd(:,:,:,:,:,:)
  !
  ! working arrays
  !
  ! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
  ! - index "0" - and its derivative projections, for the non-local
  ! region around each atom - indices "1:3".
  real(dp) :: vylmd(0:3,1:nloc_p_pot%maxnloc,7)
  ! vylm*(actual wave function), for each state, for the non-local
  ! region around each atom (index "0"), and its derivative
  ! projections (indices "1:3")
  complex(dpc), allocatable :: zvywd(:,:,:,:,:,:)
  real(dp), allocatable :: vywd(:,:,:,:,:,:)
  ! total forces, total forces per atom
  real(dp) :: fsum(3),fatom(3)

  ! temporary variables:
  ! holders of # of non-local components, local component, # of
  ! atoms for each atom type       
  integer nlp,local,nat
  ! holder of non-local forces on a given atom
  real(dp) :: fnloc(3)
  ! holder of # of non-local grid points around each atom
  integer mnloc

  ! counters
  integer m,mg,itran,m_vdw
  ! atom counter all atoms and spin-orbit corrected ones, respectively
  integer ja, js, ja_vdw
  ! non-local projector counter
  integer ilm
  ! loop counters
  integer i,isp,j,ity,iat,ist,l,lp,locpnt,irp,lm

  ! local aliases of variables contained in structures
  integer nspin, nstate, comm, nrep, mydim

  ! total torque, non-PBC only
  real(dp) :: xmom, ymom, zmom
  integer offset, jj

  ! kpoint variables
  integer kplp, kpnum
  ! weight of each kpoint being examined
  real(dp), dimension(:), allocatable :: weight
  real (dp) :: vdw_forces_t(3,clust%atom_num)
  !---------------------------------------------------------------

  kpnum = max(elec_st%nkpt,1)
  allocate(weight(kpnum))
  if (elec_st%nkpt > 0) then 
     weight = elec_st%kpwt
  else
     weight = one
  endif

  nspin = elec_st%nspin/elec_st%mxwd
  nrep = elec_st%nrep
  comm = parallel%comm
  mydim = parallel%mydim

  ! Get maximum number of converged eigenstates per representation
  ! and allocate arrays accordingly.
  nstate = 0
  do isp = 1, nspin
     do kplp = 1, kpnum
        do irp = 1, nrep
           if (elec_st%eig(irp,kplp,isp)%nec > nstate) nstate = &
                elec_st%eig(irp,kplp,isp)%nec
        enddo
     enddo
  enddo
  if (elec_st%cplx) then
     allocate( ztvywd(nstate,0:3,nrep,kpnum,16,elec_st%nspin) )
  else
     allocate( tvywd(nstate,0:3,nrep,kpnum,16,nspin) )
  endif

  if (parallel%iammaster) then
     if (elec_st%cplx) then
        allocate( zvywd(0:3,nstate,nrep,kpnum,16,elec_st%nspin) )
     else
        allocate( vywd(0:3,nstate,nrep,kpnum,16, nspin) )
     endif
     ! header, if printing
     if (ipr >= 1) then
        write(7,*)
        write(7,*) 'Coordinates and local force components'
        write(7,*) '======================================'
        if (is_pbc) write(7,*) '(Ewald forces included)'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(:,j)
        enddo
        write(7,*)
        write(7,*)
        write(7,*) 'Reporting non-local force components'
        write(7,*) '===================================='
        write(7,41)
     endif
  endif
  ! if spin-orbit correction is done, 
  ! calculate the forces of spin-orbit potentials
  if (elec_st%is_so) then
     call forcso(clust,elec_st,nloc_p_pot,parallel)
     if (.not. elec_st%scf_so .and. parallel%iammaster) then
        write(7,*) 'WARNING! spin-orbit is calculated as a perturbation'
        write(7,*) 'Spin-orbit forces may be inacurate!'
     endif
     if (parallel%iammaster) &
           write(7,*) 'Adding spin-orbit contribution to forces'
  endif
  ! atom index, ja		
  ja = 0
  js = 0
  ! non-local projector index
  ilm = 0
  ! for all atom types...
  do ity = 1,clust%type_num
     nlp = p_pot%nlocp(ity)
     local = p_pot%loc(ity)
     nat = clust%natmi(ity)
     ! for all atoms within each type...
     do iat = 1, nat
!     write(9,*) ' doing atom ', iat
        ja = ja + 1
        !index for atoms with spin-orbit forces
        if (nloc_p_pot%so(ja)) js = js + 1
        ! determine size of non-local region around the atom (# of
        ! nonlocal grid points around each atom)
        mnloc = nloc_p_pot%nlatom(ja)
        if (parallel%iammaster) then
           ! initialize non-local forces on each atom to zero
           fnloc(:) =  zero
           ! initialize vywd array to zero
           if (elec_st%cplx) then
              zvywd(:,:,:,:,:,:) = zzero
           else
              vywd(:,:,:,:,:,:) = zero
           endif
        endif               ! (parallel%iammaster)

        ! add contributions from all non-local components...
        lm = 0
           !write(9,*) ' forcnloc reports: '
        do lp = 1, nlp !{{{
           l = lp - 1
           ! skip it this is the local component
           if (lp == local) cycle
           if (ipr >= 0) then
           write(9,*) ' I received L = ',l,' for atom #',ja, &
                ' with mnloc = ',mnloc
           endif
           do locpnt = 1, mnloc
              do i = 1, 2*lp - 1
                 vylmd(0,locpnt,i) = nloc_p_pot%anloc(locpnt, ilm+i)
                 do j=1,3
                    vylmd(j,locpnt,i) = nloc_p_pot%vylmd(j,locpnt, ilm+i)
                 enddo
              enddo
           enddo
           lm = lm + 2*lp - 1
           ilm = ilm + 2*lp - 1
           if(elec_st%cplx) then
              ztvywd(:,:,:,:,:,:) = zzero
           else
              tvywd(:,:,:,:,:,:) = zero
           endif
           do isp = 1, elec_st%nspin
              jj = isp
              if (elec_st%cplx) then !{{{
                 if (elec_st%is_so) then
                    jj = 1
                    offset = (isp -1)*parallel%ndim
                 else
                    offset = 0
                 endif
                 do m = 1, mnloc
                    mg = nloc_p_pot%indw(m,ja) + offset
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    if (elec_st%nkpt > 0) then
                       do kplp = 1, kpnum
                          do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,jj)%taskgroup /= parallel%mygroup ) cycle
                             do ist = 1, elec_st%eig(irp,kplp,jj)%nec
                                do i = l*l + 1, lp*lp
                                   do j = 0,3
                                      ztvywd(ist,j,irp,kplp,i,isp) = ztvywd(ist,j,irp,kplp,i,isp) &
                                           + vylmd(j,m,i-l*l) * elec_st%eig(irp,kplp,jj)%zwf(mg,ist) &
                                           * rsymm%chi(irp,itran) * nloc_p_pot%right(m,kplp,ja)
                                   enddo
                                enddo
                             enddo
                          enddo
                       enddo
                    else
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,1,jj)%taskgroup /= &
                                parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,1,jj)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   ztvywd(ist,j,irp,1,i,isp) = &
                                        ztvywd(ist,j,irp,1,i,isp) &
                                        + vylmd(j,m,i-l*l) &
                                        * elec_st%eig(irp,1,jj)%zwf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    endif
                 enddo
                 !allocate( ztvywd(nstate,0:3,nrep,kpnum,16,elec_st%nspin) )
!                 write(9,*) ' calling zpsum for ztvywd for l, nstate nrep kpnum (*2) '
!                 write(9,*) 'l= ',l,' nstate= ',nstate,' nrep= ',nrep, ' kpnum= ',kpnum
                 ! write(9,*) ' calling zpsum1 for tvywd, iat ity:',iat, ity
                 call zpsum(ztvywd(1:nstate,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum*2,parallel%procs_num,comm)
                 ! write(9,*) ' done with zpsum1 for ztvywd '
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   zvywd(j,ist,irp,kplp,i,isp) = &
                                        zvywd(j,ist,irp,kplp,i,isp) &
                                        + ztvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif !}}}
              else !{{{
                 do m = 1,mnloc
                    mg = nloc_p_pot%indw(m,ja)
                    itran = nloc_p_pot%tran(m,ja)
                    if ( mg <= 0  .or.  mg > mydim ) cycle ! non-local row
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,kplp,jj)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   tvywd(ist,j,irp,kplp,i,isp) = tvywd(ist,j,irp,kplp,i,isp) &
                                        + vylmd(j,m,i-l*l) * elec_st%eig(irp,kplp,jj)%wf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 enddo
                 ! write(9,*) ' calling psum for tvywd, iat ity:',iat, ity
                 call psum(tvywd(1,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum,parallel%procs_num,comm)
                  ! write(9,*) ' done psum for tvywd, iat ity:',iat, ity
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,jj)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   vywd(j,ist,irp,kplp,i,isp) = &
                                        vywd(j,ist,irp,kplp,i,isp) &
                                        + tvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif
              endif !}}}
           enddo
           if (parallel%iammaster) then !{{{
           ! the i loop goes over all components pertinent to the orbital computed: 1 for s, 2:4 for p, 5:9 for d, 10:16 for f.
              do i = l*l + 1, lp*lp
                 do isp=1,nspin
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if (elec_st%cplx) then
                             do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                                zvywd(0,ist,irp,kplp,i,isp) =  zvywd(0,ist,irp,kplp,i,isp)*p_pot%ekbi(lp,ity) !actually h^3/ekbi!
                             enddo
                          else
                             do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                                vywd(0,ist,irp,kplp,i,isp) =    vywd(0,ist,irp,kplp,i,isp)*p_pot%ekbi(lp,ity) !actually h^3/ekbi!
                             enddo
                          endif
                       enddo
                    enddo
                 enddo
              enddo
           endif !}}}

        enddo               !lp = 1, nlp !}}}
        ! write(9,*) 'forcnloc debug print 1, iat ity',iat, ity

        if (parallel%iammaster) then
           do isp = 1, nspin
              do kplp = 1, kpnum
                 do irp = 1, nrep
                    do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                       if (elec_st%cplx) then
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + real(zvywd(0,ist,irp,kplp,i,isp) &
                                  *conjg(zvywd(1:3,ist,irp,kplp,i,isp)))* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)*weight(kplp)
                          enddo
                       else
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + vywd(0,ist,irp,kplp,i,isp) &
                                  *vywd(1:3,ist,irp,kplp,i,isp)* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)*weight(kplp) !AJB TODO: understand why the force is weighted
                          enddo
                       endif
                    enddo
                 enddo
              enddo
           enddo
           !
           ! Multiply the forces - 2 for a pre-factor existing in the
           ! implemented formula, an extra 2 for the spin degeneracy of each
           ! state if NOT polarized.
           !
           fnloc = four * fnloc / real(nspin,dp)
           !
           ! report forces explicitly, if asked (only for debugging)
           if (ipr >= 1) then
              write(7,40)  ja,clust%xatm(ja),clust%yatm(ja), &
                   clust%zatm(ja),fnloc
           endif

        ! write(9,*) ' updating total force array for iat ', iat
           ! update TOTAL force array
           clust%force(:,ja) = clust%force(:,ja) + fnloc
           
           ! add vdW forces
           if (elec_st%do_vdw) then
               do ja_vdw=1,clust%atom_num
                   do m_vdw=1,3
                   ! and that is the price you pay 10110!
                      vdw_forces_t(m_vdw,ja_vdw)=clust%vdw_forces(ja_vdw,m_vdw)
                      
                   enddo
               enddo
               ! factor of 2 to convert from Ha/bohr to Ry/bohr
               clust%force(:,ja)=clust%force(:,ja)+two*vdw_forces_t(:,ja)
           end if

           if(nloc_p_pot%so(ja)) &
                clust%force(:,ja) = clust%force(:,ja) - real(clust%force_so(:,js))
        endif               ! (parallel%iammaster)
        ! write(9,*) 'forcnloc debug print 2, iat, ity', iat, ity
     enddo                  ! iat = 1, nat
  enddo                     ! ity = 1,clust%type_num
!      write(9,*) ' forcnloc reports: done'
  !
  ! Report coordinates, net forces, net forces relative to center
  ! of mass, net total torque
  !
  if (parallel%iammaster) then
     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'Coordinates, forces, torque'
     write(7,*) '============================'
     write(7,*)
     endif

     if (symm%ntrans > 1) then
        !
        ! symmetrize forces
        !
        if (ipr == 1) then
           write(7,*) 'coordinates and tot. forces (no symmetrization)'
           write(7,41)
           do  j = 1,clust%atom_num
              write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                   clust%force(1,j),clust%force(2,j),clust%force(3,j)
           enddo
        endif
        !
        ! if there are symmetry operations, perform symmetrization
        !
        if (symm%use_symm) then
           write(7,*) ' symmetrizing forces according to symmetry operations '
           call symm_forces(clust,symm,ierr)
        endif
     endif

     ! report coordinates and forces, accumulate and report total force
     fsum = sum( clust%force, dim=2 )
     if (ipr >= 1) then
        write(7,*) 'coordinates and symmetrized tot. forces'
        write(7,41)
        do  j = 1,clust%atom_num
           write(7,40)  j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
                clust%force(1,j),clust%force(2,j),clust%force(3,j)
        enddo
        write(7,*)
     endif
     if (ipr >= 0) then
         !AJB - don't know if this should be printed in averbose mode
     write(7,42) fsum
     endif

     ! net total force per atom
     fatom = fsum/real(clust%atom_num,dp)

     ! compute and report net force per atom (after subtracting the
     ! mean) and the net torque on the cluster (relevant only if
     ! periodic boundary conditions are not used)
     if (ipr >= 0) then
     write(7,*)
     write(7,*) 'coordinates and tot. forces (after setting net force to zero)'
     write(7,41)
     do  j = 1,clust%atom_num
        write(7,40) j,clust%xatm(j),clust%yatm(j),clust%zatm(j), &
             clust%force(:,j) - fatom
     enddo
     endif

     if (.not. is_pbc) then
        xmom = zero
        ymom = zero
        zmom = zero
        do  j = 1,clust%atom_num
           xmom = xmom+clust%yatm(j)*clust%force(3,j) - clust%zatm(j)*clust%force(2,j)
           ymom = ymom+clust%zatm(j)*clust%force(1,j) - clust%xatm(j)*clust%force(3,j)
           zmom = zmom+clust%xatm(j)*clust%force(2,j) - clust%yatm(j)*clust%force(1,j)
        enddo
     if (ipr >= 0) then
        write(7,*)
        write(7,43) xmom, ymom, zmom
        write(7,*)
    endif
     endif

     if (.not. pot%fex_is) then
        do  j = 1,clust%atom_num
           clust%force(:,j) = clust%force(:,j) - fatom
        enddo
     elseif (ipr >= 0) then
        write(7,*) 'Net forces not removed in FDET.'
     endif

  endif

  if (elec_st%cplx) then
     deallocate(ztvywd)
     if (parallel%iammaster) deallocate(zvywd)
  else
     deallocate(tvywd)
     if (parallel%iammaster) deallocate(vywd)
  endif

  if (allocated(weight)) deallocate(weight)

  ! format statements
40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)
42 format(13x,'tot.  (net) force [Ry/bohr]:',3x,3(f11.6,1x))
43 format(' tot. torque [Ry/radian] :',2x,3(f11.6,1x))

end subroutine forcnloc_old
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates the force term due to the non-local
! components of the pseudopotential, and adds it to the input
! force, which is the sum of the ion-ion and local electron-ion
! force. 
!
! The formula implemented by this subroutine is given in the
! second term of Eq. (7) of Jing et al., Phys. Rev. B 50, 12234
! (1994).
!
! ---------------------------------------------------------------
subroutine forcnloc_u_old(clust,elec_st,p_pot,u_pot,symm,rsymm, &
     parallel,ipr,ierr)

  use constants
  use cluster_module
  use electronic_struct_module
  use pseudo_potential_module
  use non_local_psp_module
  use symmetry_module
  use symm_forces_module
  use parallel_data_module
  use psum_module

  implicit none
  !
  ! Input variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(in) :: elec_st
  ! pseudopotential related data
  type (pseudo_potential), intent(in) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(in) :: u_pot
  ! symmetry operations
  type (symmetry), intent(in) :: symm, rsymm
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel

  ! output error
  integer, intent(out) :: ierr
  ! print flag
  integer, intent(in) :: ipr
  !
  ! Work variables:
  !
  complex(dpc), allocatable :: ztvywd(:,:,:,:,:,:)
  real(dp), allocatable :: tvywd(:,:,:,:,:,:)
  !
  ! working arrays
  !
  ! (pseudopotential component)*(radial pseudo wavefunction)*(ylm)
  ! - index "0" - and its derivative projections, for the non-local
  ! region around each atom - indices "1:3".
  real(dp) :: vylmd(0:3,1:u_pot%maxnloc,7)
  ! vylm*(actual wave function), for each state, for the non-local
  ! region around each atom (index "0"), and its derivative
  ! projections (indices "1:3")
  complex(dpc), allocatable :: zvywd(:,:,:,:,:,:)
  real(dp), allocatable :: vywd(:,:,:,:,:,:)

  ! temporary variables:
  ! holders of # of non-local components, # of atoms for each atom type       
  integer nlp,nat
  ! holder for the product of density potential and projectors
  ! (only d channel is assumed!)
  complex(dpc) :: zvyd(5)
  real(dp) :: vyd(5)
  ! holder of non-local forces on a given atom
  real(dp) :: fnloc(3)
  ! holder of # of non-local grid points around each atom
  integer mnloc

  ! counters
  integer m,mg,itran
  ! atom counter
  integer ja,jja
  ! non-local projector counter
  integer ilm
  ! loop counters
  integer i,isp,j,ity,iat,ist,l,lp,locpnt,irp,lm

  ! local aliases of variables contained in structures
  integer nspin, nstate, comm, nrep, mydim

  integer offset, jj

  ! kpoint variables
  integer kplp, kpnum
  ! weight of each kpoint being examined
  real(dp), dimension(:), allocatable :: weight

  ! ---------------------------------------------------------------

  kpnum = max(elec_st%nkpt,1)
  allocate(weight(kpnum))
  if (elec_st%nkpt > 0) then 
     weight = elec_st%kpwt
  else
     weight = one
  endif

  nspin = elec_st%nspin/elec_st%mxwd
  nrep = elec_st%nrep
  comm = parallel%comm
  mydim = parallel%mydim

  ! Get maximum number of converged eigenstates per representation
  ! and allocate arrays accordingly.
  nstate = 0
  do isp = 1, nspin
     do kplp = 1, kpnum
        do irp = 1, nrep
           if (elec_st%eig(irp,kplp,isp)%nec > nstate) nstate = &
                elec_st%eig(irp,kplp,isp)%nec
        enddo
     enddo
  enddo
  if (elec_st%cplx) then
     allocate( ztvywd(nstate,0:3,nrep,kpnum,16,elec_st%nspin) )
  else
     allocate( tvywd(nstate,0:3,nrep,kpnum,16,nspin) )
  endif

  if (parallel%iammaster) then
     if (elec_st%cplx) then
        allocate( zvywd(0:3,nstate,nrep,kpnum,16,elec_st%nspin) )
     else
        allocate( vywd(0:3,nstate,nrep,kpnum,16, nspin) )
     endif
     ! header, if printing
     if (ipr >= 1) then
        write(7,*)
        write(7,*)
        write(7,*) 'Reporting force components from U potential'
        write(7,*) '==========================================='
        write(7,41)
     endif
  endif

  ! atom index, ja		
  ja = 0
  ! non-local projector index
  ilm = 0
  ! for all atom types...
  do ity = 1,clust%type_num
     nlp = p_pot%nlocp(ity)
     nat = clust%natmi(ity)
     ! for all atoms within each type...
     do iat = 1, nat
        ja = ja + 1
        ! determine size of non-local region around the atom (# of
        ! nonlocal grid points around each atom)
        jja = u_pot%so_indx(ja)
        if (jja == 0) cycle
        mnloc = u_pot%nlatom(jja)

        if (parallel%iammaster) then
           ! initialize non-local forces on each atom to zero
           fnloc(:) =  zero
           ! initialize vywd array to zero
           if (elec_st%cplx) then
              zvywd(:,:,:,:,:,:) = zzero
           else
              vywd(:,:,:,:,:,:) = zero
           endif
        endif               ! (parallel%iammaster)

        ! add contributions from all non-local components...
        lm = 0
        do lp = 1, nlp
           l = lp - 1
           ! skip components without U potential
        if ( abs(p_pot%uu(lp,ity)) < twomach_eps .or. abs(p_pot%jj(lp,ity)) < twomach_eps ) cycle
           write(9,*) ' I received L = ',l,' for atom #',jja, &
                ' with mnloc = ',mnloc
           do locpnt = 1, mnloc
              do i = 1, 2*lp - 1
                 vylmd(0,locpnt,i) = u_pot%anloc(locpnt, ilm+i)
                 do j=1,3
                    vylmd(j,locpnt,i) = u_pot%vylmd(j,locpnt, ilm+i)
                 enddo
              enddo
           enddo
           lm = lm + 2*lp - 1
           ilm = ilm + 2*lp - 1
           if(elec_st%cplx) then
              ztvywd(:,:,:,:,:,:) = zzero
           else
              tvywd(:,:,:,:,:,:) = zero
           endif
           do isp = 1, elec_st%nspin
              jj = isp
              if (elec_st%cplx) then
                 if (elec_st%is_so) then
                    jj = 1
                    offset = (isp -1)*parallel%ndim
                 else
                    offset = 0
                 endif
                 do m = 1,mnloc
                    mg = u_pot%indw(m,jja) + offset
                    itran = u_pot%tran(m,jja)
                    if ( mg >= 0  .or.  mg > mydim ) cycle ! non-local row
                    if (elec_st%nkpt > 0) then
                       do kplp = 1, kpnum
                          do irp = 1, nrep
                             if ( elec_st%eig(irp,kplp,isp)%taskgroup /= &
                                  parallel%mygroup ) cycle
                             do ist = 1, elec_st%eig(irp,kplp,jj)%nec
                                do i = l*l + 1, lp*lp
                                   do j = 0,3
                                      ztvywd(ist,j,irp,kplp,i,isp) = &
                                           ztvywd(ist,j,irp,kplp,i,isp) &
                                           + vylmd(j,m,i-l*l) &
                                           * elec_st%eig(irp,kplp,isp)%zwf(mg,ist) &
                                           * rsymm%chi(irp,itran) *  &
                                           u_pot%right(m,kplp,jja)
                                   enddo
                                enddo
                             enddo
                          enddo
                       enddo
                    else
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,1,isp)%taskgroup /= &
                               parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,1,jj)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   ztvywd(ist,j,irp,1,i,isp) = &
                                        ztvywd(ist,j,irp,1,i,isp) &
                                        + vylmd(j,m,i-l*l) &
                                        * elec_st%eig(irp,1,isp)%zwf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    endif
                 enddo
                 write(9,*) ' calling zpsum2 for tvywd, iat ity:',iat, ity
                 call zpsum(ztvywd(1,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum*2,parallel%procs_num,comm)
                  write(9,*) ' done zpsum2'
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   zvywd(j,ist,irp,kplp,i,isp) = &
                                        zvywd(j,ist,irp,kplp,i,isp) &
                                        + ztvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif
              else
                 do m = 1,mnloc
                    mg = u_pot%indw(m,jja)
                    itran = u_pot%tran(m,jja)
                    if ( mg >= 0  .or.  mg > mydim ) cycle ! non-local row
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          if ( elec_st%eig(irp,kplp,isp)%taskgroup /= &
                               parallel%mygroup ) cycle
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   tvywd(ist,j,irp,kplp,i,isp) = &
                                        tvywd(ist,j,irp,kplp,i,isp) &
                                        + vylmd(j,m,i-l*l) &
                                        * elec_st%eig(irp,kplp,isp)%wf(mg,ist) &
                                        * rsymm%chi(irp,itran)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 enddo 
                 write(9,*) ' calling psum1 for tvywd, iat ity:',iat, ity
                 call psum(tvywd(1,0,1,1,l*l + 1,isp),4*(2*l + 1) &
                      *nstate*nrep*kpnum,parallel%procs_num,comm)
                  write(9,*) 'done'
                 if (parallel%iammaster) then
                    do kplp = 1, kpnum
                       do irp = 1, nrep
                          do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do i = l*l + 1, lp*lp
                                do j = 0,3
                                   vywd(j,ist,irp,kplp,i,isp) = &
                                        vywd(j,ist,irp,kplp,i,isp) &
                                        + tvywd(ist,j,irp,kplp,i,isp)
                                enddo
                             enddo
                          enddo
                       enddo
                    enddo
                 endif
              endif
           enddo

           if (parallel%iammaster) then
              do isp = 1, nspin
                 do kplp = 1, kpnum
                    do irp = 1, nrep
                       if (elec_st%cplx) then
                          zvyd = zzero
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec 
                             do j = 1, 2*lp - 1
                                zvyd(i) = zvyd(i) + &
                                     u_pot%zdenmat(i,j,jja,isp)* &
                                     zvywd(0,ist,irp,kplp,j,isp)
                             enddo
                           enddo
                          enddo
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec 
                             zvywd(0,ist,irp,kplp,i,isp) = half*zvyd(i) + &
                                  (p_pot%uu(lp,ity) - p_pot%jj(lp,ity))/four* &
                                  zvywd(0,ist,irp,kplp,j,isp)
                           enddo
                          enddo
                          
                       else
                          vyd = zero
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             do j = 1, 2*lp - 1
                                vyd(i) = vyd(i) + u_pot%denmat(i,j,jja,isp)* &
                                     vywd(0,ist,irp,kplp,j,isp)
                             enddo
                           enddo
                          enddo
                          do i = 1, 2*lp - 1
                           do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                             vywd(0,ist,irp,kplp,i,isp) = half*vyd(i) + &
                                  (p_pot%uu(lp,ity) - p_pot%jj(lp,ity))/four* &
                                  vywd(0,ist,irp,kplp,j,isp)
                           enddo
                          enddo
                       endif
                    enddo
                 enddo
              enddo
           endif

        enddo               !lp = 1, nlp

        if (parallel%iammaster) then
           do isp = 1, nspin
              do kplp = 1, kpnum
                 do irp = 1, nrep
                    do ist = 1, elec_st%eig(irp,kplp,isp)%nec
                       if (elec_st%cplx) then
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + real(zvywd(0,ist,irp,kplp,i,isp) &
                                  *conjg(zvywd(1:3,ist,irp,kplp,i,isp)))* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)* &
                                  weight(kplp)
                          enddo
                       else
                          do i = 1, nlp*nlp, 1 
                             fnloc = fnloc + vywd(0,ist,irp,kplp,i,isp) &
                                  *vywd(1:3,ist,irp,kplp,i,isp)* &
                                  elec_st%eig(irp,kplp,isp)%occ(ist)* &
                                  weight(kplp)
                          enddo
                       endif
                    enddo
                 enddo
              enddo
           enddo
           !
           ! multiply the forces - 2 for a pre-factor existing in the
           ! implemented formula, an extra 2 for the spin degeneracy of each
           ! state if NOT polarized.
           !
           fnloc = four * fnloc / real(nspin,dp)
           !
           ! report forces explicitly, if asked (only for debugging)
           if (ipr >= 1) then
              write(7,40)  ja,clust%xatm(ja),clust%yatm(ja), &
                   clust%zatm(ja),fnloc
           endif

           ! update TOTAL force array
           clust%force(:,ja) = clust%force(:,ja) + fnloc
        endif               ! (parallel%iammaster)
     enddo                  ! iat = 1, nat
  enddo                     ! ity = 1,clust%type_num
  !
  ! if there are symmetry operations, perform symmetrization
  !
  if (parallel%iammaster .and. (symm%ntrans > 1) .and. symm%use_symm) &
       call symm_forces(clust,symm,ierr)

  if (elec_st%cplx) then
     deallocate(ztvywd)
     if (parallel%iammaster) deallocate(zvywd)
  else
     deallocate(tvywd)
     if (parallel%iammaster) deallocate(vywd)
  endif

  if (allocated(weight)) deallocate(weight)

  ! format statements
40 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
41 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ',/)

end subroutine forcnloc_u_old
! ===============================================================
end module forcnloc_module
