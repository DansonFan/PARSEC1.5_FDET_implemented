module force_loc_pb_module

contains

!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Computes the local potential contribution to the Hellmann-
! Feynman forces. It uses the previous charge density (vsc_chg)
! and potential (vsc). Calculations are done in reciprocal space.
!
! Adapted from plane-wave programs written by S. Froyen and
! J. L. Martins.
!
!---------------------------------------------------------------

subroutine force_loc_pb(clust, pbc, vsc, vsc_chg)

use constants
use cluster_module
use pbc_module
use aux, only : matvec3

implicit none

!
! Input/Output variables:
!

! the cluster
type(cluster), intent(inout) :: clust

! pbc related data
type(pbc_data), intent(inout) :: pbc

! charge density and potential
complex(dpc), dimension(pbc%nstar), intent(in) :: vsc
complex(dpc), dimension(pbc%nstar), intent(in) :: vsc_chg

!
! Work variables:
!

integer :: i
integer :: j
integer :: k
integer :: l
integer :: kadd
integer :: jj
integer :: idx_atom_full
integer :: ntype
integer :: natoms
integer, dimension(clust%type_num) :: natom
real(dp) :: fi
real(dp) :: exp1
real(dp) :: vdgr
real(dp) :: vdgi
real(dp), dimension(:,:), allocatable :: floc
real(dp), dimension(:,:), allocatable :: ftmp
complex(dpc) :: vds
integer, dimension(:), allocatable :: itype_atom
integer, dimension(:), allocatable :: iatom_atom
integer, dimension(:), allocatable :: kadd_list


! ---------------------------------------------------------------

natoms = clust%atom_num
natom(:) = clust%natmi(:)
ntype = clust%type_num

allocate(floc(3,natoms))
allocate(ftmp(3,natoms))
allocate(itype_atom(natoms))
allocate(iatom_atom(natoms))
allocate(kadd_list(natoms))


floc(:,:) = zero
ftmp(:,:) = zero
kadd_list(:) = pbc%ng + 1


idx_atom_full = 0
! Loop over atomic types
do i = 1, ntype
        ! Loop over atoms of same type.
        do j = 1, natom(i)
                idx_atom_full = idx_atom_full + 1
                itype_atom(idx_atom_full) = i
                iatom_atom(idx_atom_full) = j
        enddo
enddo




!$omp parallel do default(none) &
!$omp& private(idx_atom_full,i,jj,j,vds,k,kadd,vdgr,vdgi,l,fi,exp1) &
!$omp& shared(natoms,itype_atom,pbc,vsc_chg,vsc,kadd_list,iatom_atom,floc)
do idx_atom_full = 1, natoms
        i = itype_atom(idx_atom_full)

        ! Loop over stars.
        !kadd = pbc%ng + 1

        do jj = 2, pbc%nstar
                j = pbc%nstar - jj + 2
                vds =  conjg( pbc%vql(i,j)*vsc_chg(j) + vsc(j)*pbc%dnc(i,j) )

                ! Loop over g vectors in star.
                do k = 1, pbc%mstar(j)
                        kadd_list(idx_atom_full) = &
                                kadd_list(idx_atom_full) - 1
                        kadd = kadd_list(idx_atom_full)
                        vdgr = real(vds)  * real(pbc%phase(kadd),dp) - &
                               aimag(vds) * aimag(pbc%phase(kadd))
                        vdgi = pbc%conj(kadd) * ( &
                                aimag(vds)   * real(pbc%phase(kadd),dp) + &
                                real(vds,dp) * aimag(pbc%phase(kadd)) )

                        l = iatom_atom(idx_atom_full)
                        fi = dot_product( real(pbc%kgv(:,kadd),dp), &
                                          pbc%rat(:,l,i) )
                        exp1 = sin(fi)*vdgr - cos(fi)*vdgi

                        ! Add to forces.
                        floc(:,idx_atom_full) = floc(:,idx_atom_full) + &
                                real(pbc%kgv(:,kadd),dp) * exp1
                enddo
        enddo
enddo
!$omp end parallel do


!$omp parallel do simd default(none) &
!$omp& shared(natoms,pbc,floc,ftmp)
do idx_atom_full = 1, natoms
        call matvec3('N', pbc%bvec, floc(:,idx_atom_full), &
                ftmp(:,idx_atom_full))
enddo
!$omp end parallel do simd

!$omp parallel do simd default(none) &
!$omp& shared(natoms,clust,ftmp)
do idx_atom_full = 1, natoms
        clust%force(:,idx_atom_full) = clust%force(:,idx_atom_full) + &
                two*ftmp(:,idx_atom_full)
enddo
!$omp end parallel do simd

deallocate(floc)
deallocate(ftmp)
deallocate(itype_atom)
deallocate(iatom_atom)
deallocate(kadd_list)




end subroutine force_loc_pb
!===============================================================
end module force_loc_pb_module
