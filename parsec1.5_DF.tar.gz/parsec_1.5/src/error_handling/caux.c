#include<sys/time.h>
#include<sys/resource.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<inttypes.h>
#include<stdio.h>
#include<errno.h>
int get_memory_usage(uint64_t * current, uint64_t * memmax)
{
    errno=0; // defined in errno.h
    pid_t pid = getpid();
    struct rusage usage;
    char filename[128];
    getrusage(RUSAGE_SELF, &usage);
    *memmax = (usage.ru_maxrss*1024)/1e6; // Max memory in MB
    int ierr = sprintf(filename,"/proc/%d/statm",pid);
    uint64_t trash;
    *current = 0;
    FILE* statm = fopen(filename,"r");
    if(statm){
        ierr = fscanf(statm,"%" SCNu64 " %" SCNu64 ,&trash,current); 
        fclose(statm);
    } else {
        ierr = sprintf(filename,"can't open /proc/%d/statm : code %d\n",pid,errno);
        fprintf(stderr,"%s",filename);
    }
    *current = (((*current * (long)(sysconf(_SC_PAGESIZE)))/1024)/1024); // Current memory in MB
    // printf("mem(%d|%d) caux.c : %" PRIu64 " %" PRIu64 "\n",pid,ierr,*current,*memmax);
    return 0;
}
int get_memory_avail(uint64_t * current, uint64_t * total)
{
    errno=0; // defined in errno.h
    int ierr = 0;
    *current = 0;
    *total = 0;

    FILE* statm = fopen("/proc/meminfo","r");
    char key[64];
    char unit[32];
    uint64_t value;
    uint64_t memfree = 0;

    if(statm){
        while(fscanf(statm, "%63s %" SCNu64 " %31s", key, &value, unit) == 3){
            if(strcmp(key, "MemTotal:") == 0){
                *total = value / 1024;
            } else if(strcmp(key, "MemAvailable:") == 0){
                *current = value / 1024;
            } else if(strcmp(key, "MemFree:") == 0){
                memfree = value / 1024;
            }

            if(*total > 0 && *current > 0){
                break;
            }
        }
        fclose(statm);
        if(*current == 0){
            *current = memfree;
        }
    } else {
        char filename[128];
        ierr = sprintf(filename,"can't open /proc/meminfo : code %d\n",errno);
        fprintf(stderr,"%s",filename);
    }
    return ierr;
}
