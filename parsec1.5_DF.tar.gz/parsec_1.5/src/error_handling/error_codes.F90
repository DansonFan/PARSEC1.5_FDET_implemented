!> \brief provides modular enumerator for error codes
!! \author Charles Lena
!! \date 2017-01-20 : written 
!! \date 2017-01-22 : changed to parameters to support doxygen parsing
!! \note Enumerations aren't support by doxygen, and since integer,
!!  parameters work just as well for our purpose, we should stick with them
!!  for now instead of enumerations. 
!!  
!! What we really want are
!! enumerations in the C++ sense, which is to say classes of codes that
!! error out a function if given the wrong code (e.g. `int foo(enum ErrorCode)`
!! errors out if given a raw integer, because that's not an `enum
!! Error Code`
module error_codes
      integer, parameter :: ERR_NOERROR = 0 !< no error

      integer, parameter :: ERR_MALFORMED_FILE_INPUT = 100 !< specific bad file input
      integer, parameter :: ERR_IMPOSSIBLE_FILE_INPUT = 101 !< specific bad file input

      integer, parameter :: &
         ERR_OOB_H_PROJ_I_LOW = 1000,& !< out of bounds (low) index I H_projection matrix
         ERR_OOB_H_PROJ_J_LOW = 1001,& !< out of bounds (low) index J H_projection matrix
         ERR_OOB_H_WORK_I_LOW = 1002,& !< out of bounds (low) index J H_work matrix
         ERR_OOB_H_PROJ_I_HIGH = 1003,& !< out of bounds (high) index I H_projection matrix
         ERR_OOB_H_PROJ_J_HIGH = 1004,& !< out of bounds (high) index J H_projection matrix
         !< \callergraph
         ERR_OOB_H_WORK_I_HIGH = 1005  !< out of bounds (high) index J H_work matrix
      !! \callergraph

      integer, parameter :: &
         ERR_PEIGZ_JOB_SPEC = 200 ,& !< jobz must be either 'N' or 'V'
         ERR_RR_RANK_DEFICIENT_JOB1 = 201 ,& !< more eigenvalues than columns requested \see <rayleigh_ritz.f90z>
         ERR_RR_RANK_DEFICIENT_JOB2 = 202 !< more eigenvalues than columns 
                                          !  requested \see <rayleigh_ritz.f90z> \note this is okay i guess

      integer, parameter :: &
         ERR_BAD_MATRIX_SHAPE = 8000 !< indicates a bad matrix shape for <new_file_template.f90>

#if 0

ierr = 0        !< Normal status
ierr = 9
ierr = 23       !< In pseudo.f90, 
ierr = 40
ierr = 74
ierr = 81
ierr = 86       !< In pseudo.f90, 

ierr = 101      !< In usrinputfile.F90, 
ierr = 102      !< In usrinputfile.F90, 
ierr = 103      !< In usrinputfile.F90, 
ierr = 104      !< In usrinputfile.F90, 
ierr = 105      !< In usrinputfile.F90, 
ierr = 106      !< In usrinputfile.F90, 
ierr = 107      !< In usrinputfile.F90, 
ierr = 108      !< In usrinputfile.F90, 
ierr = 109      !< In usrinputfile.F90, 
ierr = 110      !< In usrinputfile.F90, 
ierr = 111      !< In usrinputfile.F90, 
ierr = 112      !< In usrinputfile.F90, 
ierr = 113      !< In usrinputfile.F90, 
ierr = 114      !< In usrinputfile.F90, 
ierr = 115      !< In usrinputfile.F90, 
ierr = 116      !< In usrinputfile.F90, 
ierr = 117      !< In usrinputfile.F90, 
ierr = 118      !< In usrinputfile.F90, 
ierr = 119      !< In usrinputfile.F90, 
ierr = 120      !< In usrinputfile.F90, 
ierr = 121      !< In usrinputfile.F90, 
ierr = 122      !< In usrinputfile.F90, 
ierr = 123      !< In usrinputfile.F90, 
ierr = 124      !< In usrinputfile.F90, 
ierr = 125      !< In usrinputfile.F90, 
ierr = 126      !< In usrinputfile.F90, 
ierr = 127      !< In usrinputfile.F90, 
ierr = 128      !< In usrinputfile.F90, 
ierr = 129      !< In usrinputfile.F90, 
ierr = 130      !< In usrinputfile.F90, 
ierr = 131      !< In usrinputfile.F90, 
ierr = 132      !< In usrinputfile.F90, 
ierr = 133      !< In usrinputfile.F90, 
ierr = 134      !< In usrinputfile.F90, 
ierr = 135      !< In usrinputfile.F90, 
ierr = 136      !< In usrinputfile.F90, 
ierr = 137      !< In usrinputfile.F90, 
ierr = 138      !< In usrinputfile.F90, 
ierr = 139      !< In usrinputfile.F90, 
ierr = 140      !< In usrinputfile.F90, 
ierr = 141      !< In usrinputfile.F90, 
ierr = 142      !< In usrinputfile.F90, 
ierr = 143      !< In usrinputfile.F90, 
ierr = 144      !< In usrinputfile.F90, 
ierr = 145      !< In usrinputfile.F90, 
ierr = 146      !< In usrinputfile.F90, 
ierr = 147      !< In usrinputfile.F90, 
ierr = 148      !< In usrinputfile.F90, 
ierr = 149      !< In usrinputfile.F90, 
ierr = 150      !< In usrinputfile.F90, 
ierr = 151      !< In usrinputfile.F90, 
ierr = 152      !< In usrinputfile.F90, 
ierr = 153      !< In usrinputfile.F90, 
ierr = 154      !< In usrinputfile.F90, 
ierr = 155      !< In usrinputfile.F90, 
ierr = 156      !< In usrinputfile.F90, 
ierr = 157      !< In usrinputfile.F90, 
ierr = 158      !< In usrinputfile.F90, 
ierr = 159      !< In usrinputfile.F90, 
ierr = 160      !< In usrinputfile.F90, 
ierr = 161      !< In usrinputfile.F90, 

ierr = 201      !< In ptable.f90, 
ierr = 202      !< In pseudo.f90, 
ierr = 203      !< In pseudo.f90, 
ierr = 204      !< In pseudo.f90, 
ierr = 205      !< In pseudo.f90, 
ierr = 206      !< In pseudo.f90, 
ierr = 207      !< In pseudo.f90, 
ierr = 208      !< In pseudo.f90, 
ierr = 209      !< In pseudo.f90, 
ierr = 210      !< In pseudo.f90, 
ierr = 211      !< In pseudo.f90, 
ierr = 212      !< In pseudo.f90, 
ierr = 213      !< In pseudo.f90, 
ierr = 214      !< In pseudo.f90, 
ierr = 216      !< In pseudo.f90, 
ierr = 231
ierr = 232
ierr = 233
ierr = 234
ierr = 241
ierr = 251
ierr = 261
ierr = 266      !< ERROR in adjust_step! Could not find a commensurate grid spacing.
ierr = 271      !< Grid point displaced from image. Irreducible wedge may be wrong!
ierr = 272      !< Grid points in irreducible wedge have weights different 
                !<      from the order of the reduced group
ierr = 291

ierr = 301
ierr = 311
ierr = 312
ierr = 321      !< In restart.F90, 
ierr = 322      !< In restart.F90, 
ierr = 323      !< In restart.F90, 
ierr = 324      !< In restart.F90, 
ierr = 325      !< In restart.F90, 
ierr = 326      !< In restart.F90, 
ierr = 327      !< In restart.F90, 
ierr = 328      !< In restart.F90, 
ierr = 329      !< In restart.F90, 
ierr = 361      !< In restart_run, stored number of spins is incorrect
ierr = 362      !< In restart_run, complex algebra incorrect
ierr = 363      !< In restart_run, boundary conditions are incorrect
ierr = 364      !< In restart_run, stored grid spacing conflicts with current grid spacing
ierr = 365      !< In restart_run, the size of the supercell conflicts with the stored one
ierr = 366      !< In restart_run, stored grid spacing conflicts with current grid spacing
ierr = 367      !< In restart_run, despite using the same grid spacing and sphere size, 
                !<      the stored Hamiltonian size is incompatible with the current one. 
ierr = 368      !< In restart_run, despite using the same grid spacing and a 
                !       larger sphere size, the stored Hamiltonian size is smaller 
                !       than the current one. 
ierr = 369      !< In restart_run, number of irreducible representations does not match.
ierr = 370      !< In restart_run, character table does not match
ierr = 371      !< In restart_run, restart.h5 file not found.
ierr = 381

ierr = 401      !< In eigval, error from eigen solvers
ierr = 402      !< In eigval, not enough converged eigenpairs
ierr = 403      !< In eigval,
ierr = 404      !< In eigval,
ierr = 411
ierr = 421      !< In eigval
ierr = 422
ierr = 441
ierr = 451
ierr = 452
ierr = 453
ierr = 454

ierr = 502      !< In forceion_wire, radial distance between ions is too small.
ierr = 541
ierr = 542
ierr = 555
ierr = 567      !< Too many SCF fails. aborting molecular dynamics run!

ierr = 1001     !< In usrinputfile.F90, 

ierr = 9987     !< DOS: kpoint map is not set up!

ierr = 80085    !< Can't use tile filling because unexpected blocksizes in fold





#endif


end module error_codes

