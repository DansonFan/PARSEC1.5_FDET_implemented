!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine terminates the procs and closes the parsec.out
! file if exiting upon an error.
!
!---------------------------------------------------------------
module error_handlers

contains

subroutine exit_err(clust, elec_st, grid, pot, p_pot, nloc_p_pot, u_pot, &
        move, mol_dynamic, pbc, mixer, solver, symm, rsymm, parallel, &
        ierr_in)

use constants
use cluster_module
use electronic_struct_module
use grid_module
use potential_module
use pseudo_potential_module
use non_local_psp_module
use movement_module
use molecular_dynamic_module
use pbc_module
use mixer_module
use eigen_solver_module
use symmetry_module
use parallel_data_module
use stencil_things
use parsec_global_data, only : vecgen, moldyngen
use prandom_module
use aux, only : myflush

#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
use fftw3_module, only : fftw_cleanup
#elif defined(USEFFTW3)
use fftw3_module, only : dfftw_cleanup
#endif

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_allreduce, mpi_in_place, &
        mpi_integer, mpi_max, mpi_finalize
#else
use mpi
#endif
#endif

implicit none



! Input/Output variables:

! Structures to destroy

! the cluster
type(cluster), intent(inout) :: clust

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! grid related data
type(grid_data), intent(inout) :: grid

! potential related data
type(potential), intent(inout) :: pot

! pseudopotential related data
type(pseudo_potential), intent(inout) :: p_pot

! non local pseudopotential related data
type(nonloc_pseudo_potential), intent(inout) :: nloc_p_pot

! on-site Coulomb interaction related data
type (nonloc_pseudo_potential), intent(inout) :: u_pot

! molecular dynamic related data
type(molecular_dynamic), intent(inout) :: mol_dynamic

! movement step for lbfgs
type(movement), intent(inout) :: move

! periodic boundary conditions data
type(pbc_data), intent(inout) :: pbc

! mixer related data
type(mixer_data), intent(inout) :: mixer

! solver related data
type(eigen_solver), intent(inout) :: solver

! symmetry operations
type(symmetry), intent(inout) :: symm, rsymm

! parallel computation related data
type(parallel_data), intent(inout) :: parallel

! error flag
integer, intent(in) :: ierr_in



! Work variables:

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

! temporary variable for error flag
integer ::  ierr_tmp

! temporary variable to deal with negative errors being less than 0
integer, dimension(2) :: ierr_red

! file unit numbers
integer :: iunit
integer, dimension(22) :: units = (/ &
         4,  6,  7,  8, 10, &
        11, 13, 15, 16, 20, &
        45, 46, 61, 66, 67, &
        76, 78, 79, 88, 90, &
        91, 92 &
        /)
!close(unit=6)  ! parsec.out
!close(unit=7)  ! fort.7 in most cases..?
!close(unit=45) ! relax_restart.dat
!close(unit=46) ! bfgs.dat
!close(unit=61) ! eigen.dat
!close(unit=66) ! atom.cor
!close(unit=67) ! manual.dat
!close(unit=76) ! mdinit.dat
!close(unit=78) ! md_nrg.dat
!close(unit=79) ! md_mech.dat
!close(unit=90) ! occup.in
!close(unit=91) ! polar.dat
!close(unit=92) ! movie.xyz

! whether or not a file is open
logical :: lopen

! ---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

ierr_red = [ ierr_in, -ierr_in ]

! share error flag
#ifdef MPI
call mpi_allreduce(mpi_in_place, ierr_red(:), 2, &
        mpi_integer, mpi_max, comm_f08, mpinfo)
#endif

ierr_tmp = max(ierr_red(1), ierr_red(2))

#ifdef DEBUG
write(9,*) ' Error check ', ierr_tmp, ierr_in
call myflush(9)
#endif

if (ierr_tmp /= 0) then
        write(9,*) ' Error code ierr = ', ierr_tmp
        write(9,*) ' End of Program '

        ! destroy all the structures
        write(9,*) "begin memory cleanup"
        call myflush(9)

        call destroy_cluster(clust)
        call destroy_electronic_struct(elec_st)
        call destroy_grid(grid)
        call destroy_potential(pot)
        call destroy_pseudo_potential(p_pot)
        call destroy_movement(move)
        call destroy_molecular_dynamic(mol_dynamic)
        call destroy_nonloc_pseudo_pot(nloc_p_pot)
        call destroy_nonloc_pseudo_pot(u_pot)
        if (pbc%is_on) call destroy_pbc(pbc)
        call destroy_mixer(mixer)
        call destroy_eigen_solver(solver)
        call destroy_symmetry(symm)
        call destroy_symmetry(rsymm)
        call destroy_parallel_data(parallel)
        call my_sten_edges%destroy()
        call ext_sten_edges%destroy()
        !> \bug causes crash at very end of program
        call vecgen % destroy(errcode=ierr_tmp)
        call moldyngen % destroy(errcode=ierr_tmp)

#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
        ! release all allocated memory from fftw
        call fftw_cleanup()
#elif defined(USEFFTW3)
        ! release all allocated memory from fftw
        call dfftw_cleanup()
#endif

        write(9,*) "cleanup complete"
        call myflush(9)

        ! close all files
        ! close parsec.out
        if (parallel%iammaster) then
                do iunit = 1, size(units)
                        inquire(unit=units(iunit),opened=lopen)
                        if (lopen) close(unit=units(iunit))
                enddo
        endif

#ifdef MPI
        call mpi_finalize(mpinfo)
#endif

        ! \note AJB: intel inspector still says ierr_tmp is uninitialized
        ! commenting here to follow in the future
        stop
endif

end subroutine exit_err
end module error_handlers
