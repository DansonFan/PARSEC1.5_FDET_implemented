!=============================================================================!
! FDET HR-AFM: tip calculation in a small sphere centred on the tip
! (input keyword boundary_sphere_around_tip true, default false).
!
! Without the keyword nothing in this module is used and PARSEC runs as before.
!
! With the keyword the tip run uses its own cluster sphere (boundary_sphere_radius
! of the tip input, for example 7.5 bohr of vacuum around the tip atoms) instead of
! the large sphere of the sample (spot) run:
!   1. The tip atoms are moved by a whole number of grid steps S so that the tip
!      centre lies within half a grid step of the origin. The sample point charges
!      are moved by the same vector. When the tip moves (minimization manual), S is
!      updated instead, so the tip keeps its place on the grid and the previous
!      density and orbitals are reused as they are.
!   2. pot.dat of the spot run (same grid spacing, no grid shift) is read once.
!      Tip grid point k takes the sample potential and density of spot grid point
!      k + S (an exact copy, no interpolation). Points outside the spot sphere get
!      zero sample potential and density.
!   3. Energy terms that do not cancel when the sphere moves are changed in totnrg:
!      - E_xc[rho_sample] on the tip grid is subtracted, so only the non-additive
!        part remains (its integrand vanishes where the tip density is zero),
!      - the sample-only terms (sample Hartree, sample electron-ion, sample
!        kinetic energy) are left out: they are constants, so the total energy
!        is shifted by a constant and only energy differences are meaningful,
!      - the attraction between the tip ions and the sample electrons outside
!        the tip sphere is added from the whole spot grid (point ions -2Z/r,
!        exact there because those points are more than 7 bohr from the tip).
!   The non-additive kinetic energy needs no change: T[rho_tot] - T[rho_sample]
!   - T[rho_tip] vanishes point by point where the tip density is zero.
!
! Approximations that the large sphere does not make:
!   - Every scan point has the vacuum of the tip sphere around the tip (the large
!     sphere gives more vacuum to points near the scan centre).
!   - The tip Hartree boundary values come from the multipole expansion on the
!     small sphere.
!   - The local forces miss the sample electrons outside the tip sphere (forces
!     are not used by the HR-AFM workflow).
!   - Sample potential and density beyond the spot sphere are taken as zero.
!
! Periodic slab samples (pot.dat of a slab spot run, 2026-10-20, testing):
!   - pot.dat must have an orthogonal cell with the lattice vectors along x and y
!     and the same grid spacing in x, y and z as the tip run (choose the grid
!     spacing as the cell length divided by an even number). Tip grid points are
!     mapped to spot grid points k + S with x and y taken modulo the cell, so the
!     tip sphere may reach past the cell boundary. Points beyond the slab box in z
!     get zero, as for clusters.
!   - The tip input keeps the sample point charges (they give the sample ion
!     positions and charges). For a slab the energy of the tip ions in the
!     field of the sample outside the tip sphere is
!       E_long = sum_t Z_t V'(R_t)
!     where V' is the periodic (2D) potential of the sample ions (point
!     charges) and of the sample valence density of pot.dat (grid charges),
!     less the density inside the tip sphere, which the grid term already
!     treats with the true tip pseudopotential. V' is summed with the 2D Ewald
!     method (two splitting parameters are used and both results printed as a
!     check). These are the same grid sums as the cluster outside sum, so for
!     one cell E_long would be the cluster outside sum plus the point-charge
!     energy. PARSEC's single-cell point-charge energy is taken out again, so
!     tipsphere_eout = E_long - E_ii(one cell).
!=============================================================================!
module fdet_tipsphere_module

use constants, only : dp, zero, one, two, pi
implicit none
private

public :: tipsphere_on, tipsphere_shift, tipsphere_excb, tipsphere_eout
public :: tipsphere_recenter, tipsphere_field, tipsphere_sample_exc

! Set from the input keyword boundary_sphere_around_tip.
logical, save :: tipsphere_on = .false.
! Whole grid steps between the spot frame and the tip frame.
integer, save :: tipsphere_shift(3) = 0
! E_xc[rho_sample] on the tip grid and tip-ion / sample-electron energy outside
! the tip sphere, both in Ry.
real(dp), save :: tipsphere_excb = zero
real(dp), save :: tipsphere_eout = zero

! pot.dat of the spot run, kept on the master after the first read.
logical, save :: loaded = .false.
integer, save :: nws = 0
integer, save :: lo(3) = 0, hi(3) = 0
integer, allocatable, save :: ks(:,:), idx3(:,:,:)
real(dp), allocatable, save :: vions(:), vharts(:), rhos(:)
real(dp), save :: stepspot = zero, oldks = zero
! Slab pot.dat: periodic in x and y with nper grid points per cell.
logical, save :: spot_slab = .false.
integer, save :: nper(2) = 0
real(dp), save :: cell(2) = zero
! 2D Ewald: reciprocal vectors |m1|,|m2| <= mg and plane structure factors
! of the sample density, sum over points in plane kz of rho h^3 exp(-i G.r).
integer, parameter :: mg = 12
complex(dp), allocatable, save :: sgz(:,:,:)

contains

!-----------------------------------------------------------------------------!
! Put the tip centre within half a grid step of the origin (master only).
! first = .true.: atoms and point charges are in the spot frame (input file).
! first = .false.: atoms were just set by domove (spot frame), point charges
! are still in the tip frame of the previous point.
!-----------------------------------------------------------------------------!
subroutine tipsphere_recenter(clust, h, first)

use cluster_module
implicit none
type(cluster), intent(inout) :: clust
real(dp), intent(in) :: h
logical, intent(in) :: first

integer :: snew(3), dpt(3), ia
real(dp) :: centre(3)

centre(1) = sum(clust%xatm(1:clust%atom_num))/real(clust%atom_num, dp)
centre(2) = sum(clust%yatm(1:clust%atom_num))/real(clust%atom_num, dp)
centre(3) = sum(clust%zatm(1:clust%atom_num))/real(clust%atom_num, dp)
snew(:) = nint(centre(:)/h)

do ia = 1, clust%atom_num
        clust%xatm(ia) = clust%xatm(ia) - snew(1)*h
        clust%yatm(ia) = clust%yatm(ia) - snew(2)*h
        clust%zatm(ia) = clust%zatm(ia) - snew(3)*h
enddo

if (first) then
        dpt(:) = snew(:)
else
        dpt(:) = snew(:) - tipsphere_shift(:)
endif
if (clust%has_ptchrg) then
        do ia = 1, clust%nptchrg
                clust%xpt(ia) = clust%xpt(ia) - dpt(1)*h
                clust%ypt(ia) = clust%ypt(ia) - dpt(2)*h
                clust%zpt(ia) = clust%zpt(ia) - dpt(3)*h
        enddo
endif
tipsphere_shift(:) = snew(:)

write(7,'(a,3i6,a)') ' FDET tip sphere: tip moved by', snew, &
        ' grid steps to the centre of its own sphere'
if (first) then
        write(7,*) 'FDET tip sphere: coordinates below are in the tip frame (spot frame minus'
        write(7,*) '  the grid offset). Total energies leave out sample-only constants, so'
        write(7,*) '  only energy differences are meaningful. Forces miss the sample electrons'
        write(7,*) '  outside the tip sphere.'
endif

end subroutine tipsphere_recenter

!-----------------------------------------------------------------------------!
! Sample potential and density on the tip grid for the current shift, and the
! tip-ion / sample-electron energy outside the tip sphere.
!-----------------------------------------------------------------------------!
subroutine tipsphere_field(grid, parallel, clust, zion, f_name, iunit, &
        v_exi, v_exh, rho0, oldk, ierr)

use grid_module
use cluster_module
use parallel_data_module
#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, mpi_double_precision
#else
use mpi
#endif
#endif
implicit none
type(grid_data), intent(in) :: grid
type(parallel_data), intent(inout) :: parallel
type(cluster), intent(in) :: clust
real(dp), intent(in) :: zion(:)
character(len=*), intent(in) :: f_name
integer, intent(in) :: iunit
real(dp), intent(inout) :: v_exi(parallel%mydim)
real(dp), intent(inout) :: v_exh(parallel%mydim)
real(dp), intent(inout) :: rho0(parallel%mydim)
real(dp), intent(out) :: oldk
integer, intent(out) :: ierr

real(dp), allocatable :: ti(:), th(:), tr(:)
real(dp) :: h, r(3), d, vpt, eout, elong, el2, eii, vsi, vsh, rp(3)
real(dp) :: vin(clust%atom_num)
real(dp), allocatable :: xq(:,:), qq(:)
real(dp), allocatable :: ra(:,:), qa(:)
integer :: i, j, k(3), ity, ia, iat, nmiss, nout, ip
#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

ierr = 0
oldk = zero
v_exi(:) = zero
v_exh(:) = zero
rho0(:) = zero
#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

if (parallel%iammaster) then
        if (.not. loaded) call read_spot_field(f_name, iunit, ierr)
        if (ierr == 0) then
                if (abs(stepspot - grid%step(1)) > 1.d-10 .or. &
                    abs(grid%step(2) - grid%step(1)) > 1.d-10 .or. &
                    abs(grid%step(3) - grid%step(1)) > 1.d-10) then
                        write(7,*) 'ERROR: FDET tip sphere: grid spacing differs from pot.dat.'
                        ierr = 621
                endif
                if (any(abs(grid%shift(:)) > 1.d-10)) then
                        write(7,*) 'ERROR: FDET tip sphere needs an unshifted grid.'
                        ierr = 622
                endif
                if (spot_slab .and. .not. clust%has_ptchrg) then
                        write(7,*) 'ERROR: FDET tip sphere with a slab pot.dat needs the sample point charges'
                        write(7,*) '  in the tip input (positions and charges of the sample ions).'
                        ierr = 630
                endif
        endif
endif
#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, parallel%masterid, comm_f08, mpinfo)
#endif
if (ierr /= 0) return

eout = zero
if (parallel%iammaster) then
        h = grid%step(1)
        oldk = oldks
        allocate(ti(grid%nwedge), th(grid%nwedge), tr(grid%nwedge))
        ti(:) = zero
        th(:) = zero
        tr(:) = zero
        nmiss = 0
        ! Tip grid point i <- spot grid point k + S.
        do i = 1, grid%nwedge
                k(1) = grid%kx(i) + tipsphere_shift(1)
                k(2) = grid%ky(i) + tipsphere_shift(2)
                k(3) = grid%kz(i) + tipsphere_shift(3)
                if (spot_slab) then
                        k(1) = lo(1) + modulo(k(1) - lo(1), nper(1))
                        k(2) = lo(2) + modulo(k(2) - lo(2), nper(2))
                endif
                j = 0
                if (all(k(:) >= lo(:)) .and. all(k(:) <= hi(:))) j = idx3(k(1), k(2), k(3))
                if (j > 0) then
                        ti(i) = vions(j)
                        th(i) = vharts(j)
                        tr(i) = rhos(j)
                else
                        nmiss = nmiss + 1
                endif
        enddo

        ! Tip ions in the spot frame.
        allocate(ra(3,clust%atom_num), qa(clust%atom_num))
        iat = 0
        do ity = 1, clust%type_num
                do ia = 1, clust%natmi(ity)
                        iat = iat + 1
                        ra(1,iat) = clust%xatm(iat) + tipsphere_shift(1)*h
                        ra(2,iat) = clust%yatm(iat) + tipsphere_shift(2)*h
                        ra(3,iat) = clust%zatm(iat) + tipsphere_shift(3)*h
                        qa(iat) = zion(ity)
                enddo
        enddo

        ! Sample electrons outside the tip sphere attract the tip ions:
        ! sum over spot grid points that are not tip grid points (clusters).
        nout = 0
        if (.not. spot_slab) then
        do j = 1, nws
                k(:) = ks(:,j) - tipsphere_shift(:)
                if (k(1) >= grid%nxmin .and. k(1) <= grid%nxmax .and. &
                    k(2) >= grid%nymin .and. k(2) <= grid%nymax .and. &
                    k(3) >= grid%nzmin .and. k(3) <= grid%nzmax) then
                        i = grid%indexw(k(1), k(2), k(3))
                        if (i >= 1 .and. i <= grid%nwedge) cycle
                endif
                if (rhos(j) == zero) cycle
                nout = nout + 1
                r(:) = real(ks(:,j), dp)*h
                vpt = zero
                do iat = 1, clust%atom_num
                        d = sqrt(sum((r(:) - ra(:,iat))**2))
                        vpt = vpt - two*qa(iat)/d
                enddo
                eout = eout + vpt*rhos(j)
        enddo
        endif
        eout = eout*grid%hcub

        ! Sample density inside the tip sphere seen by each tip ion (point ion,
        ! same quadrature as below).
        vin(:) = zero
        do iat = 1, clust%atom_num
                do i = 1, grid%nwedge
                        r(1) = real(grid%kx(i) + tipsphere_shift(1), dp)*h
                        r(2) = real(grid%ky(i) + tipsphere_shift(2), dp)*h
                        r(3) = real(grid%kz(i) + tipsphere_shift(3), dp)*h
                        if (tr(i) /= zero) vin(iat) = vin(iat) + two*tr(i)*inv_dist_cell(r, ra(:,iat), h)
                enddo
        enddo
        vin(:) = vin(:)*grid%hcub

        ! Point-charge energy of the tip ions with the sample ions in one cell,
        ! as PARSEC adds it to the ion-ion energy.
        eii = zero
        do iat = 1, clust%atom_num
                ip = 0
                do ity = 1, clust%npttyp
                        do ia = 1, clust%nptt(ity)
                                ip = ip + 1
                                rp(1) = clust%xpt(ip) + tipsphere_shift(1)*h
                                rp(2) = clust%ypt(ip) + tipsphere_shift(2)*h
                                rp(3) = clust%zpt(ip) + tipsphere_shift(3)*h
                                eii = eii + two*qa(iat)*clust%qpt(ity)/sqrt(sum((rp(:) - ra(:,iat))**2))
                        enddo
                enddo
        enddo

        if (spot_slab) then
                ! 2D Ewald sum of the sample ions and density (see the header).
                allocate(xq(3,max(clust%nptchrg,1)), qq(max(clust%nptchrg,1)))
                ip = 0
                do ity = 1, clust%npttyp
                        do ia = 1, clust%nptt(ity)
                                ip = ip + 1
                                xq(1,ip) = clust%xpt(ip) + tipsphere_shift(1)*h
                                xq(2,ip) = clust%ypt(ip) + tipsphere_shift(2)*h
                                xq(3,ip) = clust%zpt(ip) + tipsphere_shift(3)*h
                                qq(ip) = clust%qpt(ity)
                        enddo
                enddo
                call slab_sfac(h)
                write(7,'(a,2f16.8)') ' FDET tip sphere: sample ion and electron charge per cell', &
                        sum(qq(1:ip)), sum(real(sgz(0,0,:), dp))
                elong = zero
                el2 = zero
                do iat = 1, clust%atom_num
                        vsi = ewald_slab_pot(ra(:,iat), 5.0_dp/cell(1), h, ip, qq, xq)
                        vsh = ewald_slab_pot(ra(:,iat), 6.5_dp/cell(1), h, ip, qq, xq)
                        ! take out the density inside the tip sphere (the point on
                        ! top of the ion was left out in the Ewald real-space sum)
                        d = zero
                        do i = 1, grid%nwedge
                                if (tr(i) == zero) cycle
                                r(1) = real(grid%kx(i) + tipsphere_shift(1), dp)*h
                                r(2) = real(grid%ky(i) + tipsphere_shift(2), dp)*h
                                r(3) = real(grid%kz(i) + tipsphere_shift(3), dp)*h
                                vpt = sqrt(sum((r(:) - ra(:,iat))**2))
                                if (vpt > 1.0d-8) d = d + two*tr(i)/vpt
                        enddo
                        d = d*grid%hcub
                        write(7,'(a,i3,3f20.10)') ' FDET tip sphere: atom, V''(R_t) two Ewald params, inside [Ry]', &
                                iat, vsi + d, vsh + d, d
                        elong = elong + qa(iat)*(vsi + d)
                        el2 = el2 + qa(iat)*(vsh + d)
                enddo
                deallocate(xq, qq)
                eout = elong - eii
                write(7,'(a,4f20.10)') ' FDET tip sphere: E_long (two Ewald params), E_ii(one cell), added [Ry]', &
                        elong, el2, eii, eout
        else
                ! Cluster: compare with the long-range form from the pot.dat potentials.
                elong = zero
                do iat = 1, clust%atom_num
                        vsi = spot_value(vions, ra(:,iat), h)
                        vsh = spot_value(vharts, ra(:,iat), h)
                        elong = elong - qa(iat)*(vsi + vsh - vin(iat))
                enddo
                write(7,'(a,3f20.10)') ' FDET tip sphere: check pot.dat form, eout + E_ii, diff [Ry]', &
                        elong, eout + eii, elong - eout - eii
        endif
        deallocate(ra, qa)

        write(7,'(a,3i6)') ' FDET tip sphere: spot grid offset', tipsphere_shift
        write(7,'(a,i9,a,i9)') ' FDET tip sphere: tip grid points without pot.dat data', &
                nmiss, ' of', grid%nwedge
        write(7,'(a,f20.10,a,i9,a)') ' FDET tip sphere: tip-ion/sample-elec. energy outside', &
                eout, ' Ry (', nout, ' spot points)'
endif

if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = tr(:)
call export_function(parallel, rho0)
if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = ti(:)
call export_function(parallel, v_exi)
if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = th(:)
call export_function(parallel, v_exh)
if (parallel%iammaster) deallocate(ti, th, tr)

#ifdef MPI
call mpi_bcast(eout, 1, mpi_double_precision, parallel%masterid, comm_f08, mpinfo)
call mpi_bcast(oldk, 1, mpi_double_precision, parallel%masterid, comm_f08, mpinfo)
#endif
tipsphere_eout = eout

end subroutine tipsphere_field

!-----------------------------------------------------------------------------!
! E_xc[rho_sample] on the tip grid (spin-unpolarized runs only).
!-----------------------------------------------------------------------------!
subroutine tipsphere_sample_exc(grid, parallel, elec_st, rho0, ierr)

use grid_module
use parallel_data_module
use electronic_struct_module
use exc_module
implicit none
type(grid_data), intent(in) :: grid
type(parallel_data), intent(inout) :: parallel
type(electronic_struct), intent(in) :: elec_st
real(dp), intent(in) :: rho0(parallel%mydim)
integer, intent(out) :: ierr

real(dp), allocatable :: tmp(:), wvec(:)
real(dp) :: excb

ierr = 0
if (elec_st%nspin /= 1) then
        if (parallel%iammaster) write(7,*) &
                'ERROR: boundary_sphere_around_tip supports spin-unpolarized runs only.'
        ierr = 623
        return
endif
allocate(tmp(parallel%mydim), wvec(parallel%nwedge + 1))
tmp(:) = rho0(:)
call exc_nspn(grid, parallel, elec_st%nrep, elec_st%icorr, elec_st%dioniz, &
        tmp, wvec, excb)
deallocate(tmp, wvec)
tipsphere_excb = excb
if (parallel%iammaster) write(7,'(a,f20.10,a)') &
        ' FDET tip sphere: Exc[rho_sample] on the tip grid', excb, ' Ry'

end subroutine tipsphere_sample_exc

!-----------------------------------------------------------------------------!
! Read pot.dat of the spot run (cluster, no symmetry) once.
!-----------------------------------------------------------------------------!
subroutine read_spot_field(f_name, iunit, ierr)

implicit none
character(len=*), intent(in) :: f_name
integer, intent(in) :: iunit
integer, intent(out) :: ierr

integer :: natm, ia, ios, stype(10), ndim, nwedge, ntrans, j
real(dp) :: rmax, shift(3), step3(3), box(3), latt(3,3)
real(dp), allocatable :: vxcs(:)

ierr = 0
open(iunit, file=trim(f_name), form='unformatted', status='old', iostat=ios)
if (ios /= 0) then
        write(7,*) 'ERROR: cannot open FDET potential field file: ', trim(f_name)
        ierr = 611
        return
endif
read(iunit, iostat=ios) oldks
if (ios == 0) read(iunit, iostat=ios) natm
do ia = 1, natm
        if (ios == 0) read(iunit, iostat=ios)
enddo
if (ios == 0) read(iunit, iostat=ios) stype
if (ios == 0 .and. stype(3) /= 0 .and. stype(3) /= 3) then
        write(7,*) 'ERROR: FDET tip sphere needs a cluster or slab pot.dat.'
        ierr = 624
        close(iunit)
        return
endif
spot_slab = (stype(3) == 3)
if (.not. spot_slab) then
        if (ios == 0) read(iunit, iostat=ios) stepspot, rmax
else
        if (ios == 0) read(iunit, iostat=ios) step3(:)
        if (ios == 0) read(iunit, iostat=ios) box(:)
        if (ios == 0) read(iunit, iostat=ios) latt(:,:)
        if (ios == 0) then
                stepspot = step3(1)
                if (abs(step3(2) - step3(1)) > 1.d-10 .or. abs(step3(3) - step3(1)) > 1.d-10) then
                        write(7,'(a,3f16.10)') ' ERROR: FDET tip sphere: slab pot.dat grid spacings differ:', step3
                        write(7,*) '  Choose the grid spacing as the cell length divided by an even number.'
                        ierr = 626
                endif
                if (abs(latt(2,1)) + abs(latt(3,1)) + abs(latt(1,2)) + abs(latt(3,2)) > 1.d-8*box(1)) then
                        write(7,*) 'ERROR: FDET tip sphere: slab cell must be orthogonal along x and y.'
                        ierr = 627
                endif
                cell(1:2) = box(1:2)
                nper(1) = nint(box(1)/step3(1))
                nper(2) = nint(box(2)/step3(2))
                if (abs(nper(1)*step3(1) - box(1)) > 1.d-8 .or. abs(nper(2)*step3(2) - box(2)) > 1.d-8) then
                        write(7,*) 'ERROR: FDET tip sphere: cell length is not a whole number of grid steps.'
                        ierr = 628
                endif
                if (ierr /= 0) then
                        close(iunit)
                        return
                endif
        endif
endif
if (ios == 0) read(iunit, iostat=ios) ndim
if (ios == 0) read(iunit, iostat=ios) shift
if (ios == 0) read(iunit, iostat=ios) nwedge, ntrans
if (ios == 0 .and. (ntrans /= 1 .or. any(abs(shift) > 1.d-10))) then
        write(7,*) 'ERROR: FDET tip sphere needs a pot.dat without symmetry and grid shift.'
        ierr = 625
        close(iunit)
        return
endif
do j = 1, 5
        if (ios == 0) read(iunit, iostat=ios)
enddo
if (ios /= 0) then
        ierr = 612
        close(iunit)
        return
endif
nws = nwedge
allocate(ks(3,nws), vions(nws), vharts(nws), vxcs(nws), rhos(nws))
read(iunit, iostat=ios) (ks(1,j), ks(2,j), ks(3,j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vions(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vharts(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vxcs(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (rhos(j), j=1,nws)
close(iunit)
deallocate(vxcs)
if (ios /= 0) then
        ierr = 612
        return
endif
lo(1) = minval(ks(1,:)); hi(1) = maxval(ks(1,:))
lo(2) = minval(ks(2,:)); hi(2) = maxval(ks(2,:))
lo(3) = minval(ks(3,:)); hi(3) = maxval(ks(3,:))
allocate(idx3(lo(1):hi(1), lo(2):hi(2), lo(3):hi(3)))
idx3 = 0
do j = 1, nws
        idx3(ks(1,j), ks(2,j), ks(3,j)) = j
enddo
if (spot_slab) then
        if (hi(1) - lo(1) + 1 /= nper(1) .or. hi(2) - lo(2) + 1 /= nper(2)) then
                write(7,'(a,4i6)') ' ERROR: FDET tip sphere: slab grid index range does not match the cell', &
                        lo(1), hi(1), lo(2), hi(2)
                ierr = 629
                return
        endif
        write(7,'(a,2i6,a,f10.4,a)') ' FDET tip sphere: slab pot.dat, cell', nper, &
                ' grid steps, z up to', hi(3)*stepspot, ' bohr'
endif
loaded = .true.
write(7,'(a,i9,a,f14.10,a)') ' FDET tip sphere: read', nws, &
        ' spot grid points (spacing', stepspot, ' bohr)'

end subroutine read_spot_field

!-----------------------------------------------------------------------------!
! 1/|r - a| for the grid cell (side h) around grid point r: the plain value
! away from a, the cell average (8^3 midpoints) within 4.5 grid steps of a, so
! a tip atom on or near a grid point does not give an infinite term and the
! sum stays accurate where 1/r changes fast.
!-----------------------------------------------------------------------------!
function inv_dist_cell(r, a, h) result(v)
implicit none
real(dp), intent(in) :: r(3), a(3), h
real(dp) :: v, d(3), q(3)
integer :: i1, i2, i3
integer, parameter :: m = 8
d(:) = r(:) - a(:)
if (sqrt(sum(d**2)) > 4.5d0*h) then
        v = 1.d0/sqrt(sum(d**2))
        return
endif
v = zero
do i1 = 1, m
        do i2 = 1, m
                do i3 = 1, m
                        q(1) = d(1) + h*((i1 - 0.5d0)/m - 0.5d0)
                        q(2) = d(2) + h*((i2 - 0.5d0)/m - 0.5d0)
                        q(3) = d(3) + h*((i3 - 0.5d0)/m - 0.5d0)
                        v = v + 1.d0/sqrt(sum(q**2))
                enddo
        enddo
enddo
v = v/real(m**3, dp)
end function inv_dist_cell

!-----------------------------------------------------------------------------!
! Value of a pot.dat array at position x (spot frame, bohr): tricubic Lagrange
! interpolation on the spot grid, x and y modulo the cell for slabs. Exact on
! grid points.
!-----------------------------------------------------------------------------!
function spot_value(arr, x, h) result(v)
implicit none
real(dp), intent(in) :: arr(:), x(3), h
real(dp) :: v, u(3), t, w(-1:2,3)
integer :: i0(3), a, b, c, k(3), j, dd
do dd = 1, 3
        u(dd) = x(dd)/h
        i0(dd) = floor(u(dd) + 1.d-9)
        t = u(dd) - i0(dd)
        if (abs(t) < 1.d-9) t = zero
        w(-1,dd) = -t*(t - 1.d0)*(t - 2.d0)/6.d0
        w(0,dd) = (t + 1.d0)*(t - 1.d0)*(t - 2.d0)/2.d0
        w(1,dd) = -(t + 1.d0)*t*(t - 2.d0)/2.d0
        w(2,dd) = (t + 1.d0)*t*(t - 1.d0)/6.d0
enddo
v = zero
do a = -1, 2
        do b = -1, 2
                do c = -1, 2
                        k(1) = i0(1) + a
                        k(2) = i0(2) + b
                        k(3) = i0(3) + c
                        if (spot_slab) then
                                k(1) = lo(1) + modulo(k(1) - lo(1), nper(1))
                                k(2) = lo(2) + modulo(k(2) - lo(2), nper(2))
                        endif
                        j = 0
                        if (all(k(:) >= lo(:)) .and. all(k(:) <= hi(:))) j = idx3(k(1), k(2), k(3))
                        if (j > 0) v = v + w(a,1)*w(b,2)*w(c,3)*arr(j)
                enddo
        enddo
enddo
end function spot_value

!-----------------------------------------------------------------------------!
! Plane structure factors of the slab pot.dat density, computed once:
! sgz(m1,m2,kz) = sum over points j in plane kz of rho_j h^3 exp(-i G.r_j).
!-----------------------------------------------------------------------------!
subroutine slab_sfac(h)
real(dp), intent(in) :: h
complex(dp) :: e1(-mg:mg), e2(-mg:mg), w1, w2
real(dp) :: g1, g2
integer :: j, m
if (allocated(sgz)) return
allocate(sgz(-mg:mg, -mg:mg, lo(3):hi(3)))
sgz = (zero, zero)
g1 = two*pi/cell(1)
g2 = two*pi/cell(2)
do j = 1, nws
        if (rhos(j) == zero) cycle
        w1 = exp(cmplx(zero, -g1*ks(1,j)*h, dp))
        w2 = exp(cmplx(zero, -g2*ks(2,j)*h, dp))
        e1(0) = (one, zero)
        e2(0) = (one, zero)
        do m = 1, mg
                e1(m) = e1(m-1)*w1
                e2(m) = e2(m-1)*w2
                e1(-m) = conjg(e1(m))
                e2(-m) = conjg(e2(m))
        enddo
        do m = -mg, mg
                sgz(m,:,ks(3,j)) = sgz(m,:,ks(3,j)) + rhos(j)*h**3*e1(m)*e2(:)
        enddo
enddo
end subroutine slab_sfac

!-----------------------------------------------------------------------------!
! 2D Ewald potential in Ry at rt of the sample ions (charges qq at xq) and of
! the sample valence density (charges -rho h^3 on the pot.dat grid), periodic
! in x and y. A grid point on top of rt is left out (its real-space term is
! replaced by the finite part, so that the caller removes it with the other
! points inside the tip sphere).
!-----------------------------------------------------------------------------!
function ewald_slab_pot(rt, alpha, h, nq, qq, xq) result(v)
real(dp), intent(in) :: rt(3), alpha, h
integer, intent(in) :: nq
real(dp), intent(in) :: qq(nq), xq(3,nq)
real(dp) :: v
real(dp) :: area, tv(3), d, rc, g1, g2, gx, gy, g, z, f, phi, sre
complex(dp) :: ph
integer :: n1, n2, j, m1, m2, kz, ia
area = cell(1)*cell(2)
rc = 6.0_dp/alpha
g1 = two*pi/cell(1)
g2 = two*pi/cell(2)
sre = zero
do n1 = -2, 2
        do n2 = -2, 2
                tv(1) = n1*cell(1)
                tv(2) = n2*cell(2)
                tv(3) = zero
                do ia = 1, nq
                        d = sqrt(sum((xq(:,ia) + tv(:) - rt(:))**2))
                        if (d < rc) sre = sre + qq(ia)*erfc(alpha*d)/d
                enddo
                do j = 1, nws
                        if (rhos(j) == zero) cycle
                        d = sqrt(sum((real(ks(:,j), dp)*h + tv(:) - rt(:))**2))
                        if (d >= rc) cycle
                        if (d > 1.0d-8) then
                                sre = sre - rhos(j)*h**3*erfc(alpha*d)/d
                        else
                                sre = sre + rhos(j)*h**3*two*alpha/sqrt(pi)
                        endif
                enddo
        enddo
enddo
phi = sre
! reciprocal space, G /= 0
do m1 = -mg, mg
        do m2 = -mg, mg
                if (m1 == 0 .and. m2 == 0) cycle
                gx = m1*g1
                gy = m2*g2
                g = sqrt(gx*gx + gy*gy)
                ph = exp(cmplx(zero, gx*rt(1) + gy*rt(2), dp))
                do kz = lo(3), hi(3)
                        if (sgz(m1,m2,kz) == (zero, zero)) cycle
                        z = rt(3) - kz*h
                        phi = phi - pi/(area*g)*ewf(g, z, alpha)*real(ph*sgz(m1,m2,kz), dp)
                enddo
                do ia = 1, nq
                        z = rt(3) - xq(3,ia)
                        phi = phi + pi/(area*g)*ewf(g, z, alpha)*qq(ia)* &
                                cos(gx*(rt(1) - xq(1,ia)) + gy*(rt(2) - xq(2,ia)))
                enddo
        enddo
enddo
! G = 0
do kz = lo(3), hi(3)
        if (sgz(0,0,kz) == (zero, zero)) cycle
        z = rt(3) - kz*h
        phi = phi + two*sqrt(pi)/area*(exp(-(alpha*z)**2)/alpha + sqrt(pi)*z*erf(alpha*z))*real(sgz(0,0,kz), dp)
enddo
do ia = 1, nq
        z = rt(3) - xq(3,ia)
        phi = phi - two*sqrt(pi)/area*(exp(-(alpha*z)**2)/alpha + sqrt(pi)*z*erf(alpha*z))*qq(ia)
enddo
v = two*phi
end function ewald_slab_pot

! exp(g z) erfc(g/2a + a z) + exp(-g z) erfc(g/2a - a z), without overflow.
function ewf(g, z, a) result(f)
real(dp), intent(in) :: g, z, a
real(dp) :: f, x
x = g/(two*a) + a*z
if (x > zero) then
        f = exp(-(g/(two*a))**2 - (a*z)**2)*erfc_scaled(x)
else
        f = exp(g*z)*erfc(x)
endif
x = g/(two*a) - a*z
if (x > zero) then
        f = f + exp(-(g/(two*a))**2 - (a*z)**2)*erfc_scaled(x)
else
        f = f + exp(-g*z)*erfc(x)
endif
end function ewf

end module fdet_tipsphere_module
