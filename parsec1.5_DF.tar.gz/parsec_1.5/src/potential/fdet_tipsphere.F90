!=============================================================================!
! FDET HR-AFM: tip calculation in a small sphere centred on the tip
! (input keyword boundary_sphere_around_tip true, default false).
!
! Without the keyword nothing in this module is used and PARSEC runs as before.
!
! With the keyword the tip run uses its own cluster sphere (boundary_sphere_radius
! of the tip input, for example 7.5 bohr of vacuum around the tip atoms) instead of
! the large sphere of the sample (spot) run:
!   1. The tip atoms are moved by a whole number of grid steps S so that the tip
!      centre lies within half a grid step of the origin. The sample point charges
!      are moved by the same vector. When the tip moves (minimization manual), S is
!      updated instead, so the tip keeps its place on the grid and the previous
!      density and orbitals are reused as they are.
!   2. pot.dat of the spot run (same grid spacing, no grid shift) is read once.
!      Tip grid point k takes the sample potential and density of spot grid point
!      k + S (an exact copy, no interpolation). Points outside the spot sphere get
!      zero sample potential and density.
!   3. Energy terms that do not cancel when the sphere moves are changed in totnrg:
!      - E_xc[rho_sample] on the tip grid is subtracted, so only the non-additive
!        part remains (its integrand vanishes where the tip density is zero),
!      - the sample-only terms (sample Hartree, sample electron-ion, sample
!        kinetic energy) are left out: they are constants, so the total energy
!        is shifted by a constant and only energy differences are meaningful,
!      - the attraction between the tip ions and the sample electrons outside
!        the tip sphere is added from the whole spot grid (point ions -2Z/r,
!        exact there because those points are more than 7 bohr from the tip).
!   The non-additive kinetic energy needs no change: T[rho_tot] - T[rho_sample]
!   - T[rho_tip] vanishes point by point where the tip density is zero.
!
! Approximations that the large sphere does not make:
!   - Every scan point has the vacuum of the tip sphere around the tip (the large
!     sphere gives more vacuum to points near the scan centre).
!   - The tip Hartree boundary values come from the multipole expansion on the
!     small sphere.
!   - The local forces miss the sample electrons outside the tip sphere (forces
!     are not used by the HR-AFM workflow).
!   - Sample potential and density beyond the spot sphere are taken as zero.
!=============================================================================!
module fdet_tipsphere_module

use constants, only : dp, zero, two
implicit none
private

public :: tipsphere_on, tipsphere_shift, tipsphere_excb, tipsphere_eout
public :: tipsphere_recenter, tipsphere_field, tipsphere_sample_exc

! Set from the input keyword boundary_sphere_around_tip.
logical, save :: tipsphere_on = .false.
! Whole grid steps between the spot frame and the tip frame.
integer, save :: tipsphere_shift(3) = 0
! E_xc[rho_sample] on the tip grid and tip-ion / sample-electron energy outside
! the tip sphere, both in Ry.
real(dp), save :: tipsphere_excb = zero
real(dp), save :: tipsphere_eout = zero

! pot.dat of the spot run, kept on the master after the first read.
logical, save :: loaded = .false.
integer, save :: nws = 0
integer, save :: lo(3) = 0, hi(3) = 0
integer, allocatable, save :: ks(:,:), idx3(:,:,:)
real(dp), allocatable, save :: vions(:), vharts(:), rhos(:)
real(dp), save :: stepspot = zero, oldks = zero

contains

!-----------------------------------------------------------------------------!
! Put the tip centre within half a grid step of the origin (master only).
! first = .true.: atoms and point charges are in the spot frame (input file).
! first = .false.: atoms were just set by domove (spot frame), point charges
! are still in the tip frame of the previous point.
!-----------------------------------------------------------------------------!
subroutine tipsphere_recenter(clust, h, first)

use cluster_module
implicit none
type(cluster), intent(inout) :: clust
real(dp), intent(in) :: h
logical, intent(in) :: first

integer :: snew(3), dpt(3), ia
real(dp) :: centre(3)

centre(1) = sum(clust%xatm(1:clust%atom_num))/real(clust%atom_num, dp)
centre(2) = sum(clust%yatm(1:clust%atom_num))/real(clust%atom_num, dp)
centre(3) = sum(clust%zatm(1:clust%atom_num))/real(clust%atom_num, dp)
snew(:) = nint(centre(:)/h)

do ia = 1, clust%atom_num
        clust%xatm(ia) = clust%xatm(ia) - snew(1)*h
        clust%yatm(ia) = clust%yatm(ia) - snew(2)*h
        clust%zatm(ia) = clust%zatm(ia) - snew(3)*h
enddo

if (first) then
        dpt(:) = snew(:)
else
        dpt(:) = snew(:) - tipsphere_shift(:)
endif
if (clust%has_ptchrg) then
        do ia = 1, clust%nptchrg
                clust%xpt(ia) = clust%xpt(ia) - dpt(1)*h
                clust%ypt(ia) = clust%ypt(ia) - dpt(2)*h
                clust%zpt(ia) = clust%zpt(ia) - dpt(3)*h
        enddo
endif
tipsphere_shift(:) = snew(:)

write(7,'(a,3i6,a)') ' FDET tip sphere: tip moved by', snew, &
        ' grid steps to the centre of its own sphere'
if (first) then
        write(7,*) 'FDET tip sphere: coordinates below are in the tip frame (spot frame minus'
        write(7,*) '  the grid offset). Total energies leave out sample-only constants, so'
        write(7,*) '  only energy differences are meaningful. Forces miss the sample electrons'
        write(7,*) '  outside the tip sphere.'
endif

end subroutine tipsphere_recenter

!-----------------------------------------------------------------------------!
! Sample potential and density on the tip grid for the current shift, and the
! tip-ion / sample-electron energy outside the tip sphere.
!-----------------------------------------------------------------------------!
subroutine tipsphere_field(grid, parallel, clust, zion, f_name, iunit, &
        v_exi, v_exh, rho0, oldk, ierr)

use grid_module
use cluster_module
use parallel_data_module
#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, mpi_double_precision
#else
use mpi
#endif
#endif
implicit none
type(grid_data), intent(in) :: grid
type(parallel_data), intent(inout) :: parallel
type(cluster), intent(in) :: clust
real(dp), intent(in) :: zion(:)
character(len=*), intent(in) :: f_name
integer, intent(in) :: iunit
real(dp), intent(inout) :: v_exi(parallel%mydim)
real(dp), intent(inout) :: v_exh(parallel%mydim)
real(dp), intent(inout) :: rho0(parallel%mydim)
real(dp), intent(out) :: oldk
integer, intent(out) :: ierr

real(dp), allocatable :: ti(:), th(:), tr(:)
real(dp) :: h, r(3), d, vpt, eout
real(dp), allocatable :: ra(:,:), qa(:)
integer :: i, j, k(3), ity, ia, iat, nmiss, nout
#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

ierr = 0
oldk = zero
v_exi(:) = zero
v_exh(:) = zero
rho0(:) = zero
#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

if (parallel%iammaster) then
        if (.not. loaded) call read_spot_field(f_name, iunit, ierr)
        if (ierr == 0) then
                if (abs(stepspot - grid%step(1)) > 1.d-10 .or. &
                    abs(grid%step(2) - grid%step(1)) > 1.d-10 .or. &
                    abs(grid%step(3) - grid%step(1)) > 1.d-10) then
                        write(7,*) 'ERROR: FDET tip sphere: grid spacing differs from pot.dat.'
                        ierr = 621
                endif
                if (any(abs(grid%shift(:)) > 1.d-10)) then
                        write(7,*) 'ERROR: FDET tip sphere needs an unshifted grid.'
                        ierr = 622
                endif
        endif
endif
#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, parallel%masterid, comm_f08, mpinfo)
#endif
if (ierr /= 0) return

eout = zero
if (parallel%iammaster) then
        h = grid%step(1)
        oldk = oldks
        allocate(ti(grid%nwedge), th(grid%nwedge), tr(grid%nwedge))
        ti(:) = zero
        th(:) = zero
        tr(:) = zero
        nmiss = 0
        ! Tip grid point i <- spot grid point k + S.
        do i = 1, grid%nwedge
                k(1) = grid%kx(i) + tipsphere_shift(1)
                k(2) = grid%ky(i) + tipsphere_shift(2)
                k(3) = grid%kz(i) + tipsphere_shift(3)
                j = 0
                if (all(k(:) >= lo(:)) .and. all(k(:) <= hi(:))) j = idx3(k(1), k(2), k(3))
                if (j > 0) then
                        ti(i) = vions(j)
                        th(i) = vharts(j)
                        tr(i) = rhos(j)
                else
                        nmiss = nmiss + 1
                endif
        enddo

        ! Tip ions in the spot frame.
        allocate(ra(3,clust%atom_num), qa(clust%atom_num))
        iat = 0
        do ity = 1, clust%type_num
                do ia = 1, clust%natmi(ity)
                        iat = iat + 1
                        ra(1,iat) = clust%xatm(iat) + tipsphere_shift(1)*h
                        ra(2,iat) = clust%yatm(iat) + tipsphere_shift(2)*h
                        ra(3,iat) = clust%zatm(iat) + tipsphere_shift(3)*h
                        qa(iat) = zion(ity)
                enddo
        enddo

        ! Sample electrons outside the tip sphere attract the tip ions:
        ! sum over spot grid points that are not tip grid points.
        nout = 0
        do j = 1, nws
                k(:) = ks(:,j) - tipsphere_shift(:)
                if (k(1) >= grid%nxmin .and. k(1) <= grid%nxmax .and. &
                    k(2) >= grid%nymin .and. k(2) <= grid%nymax .and. &
                    k(3) >= grid%nzmin .and. k(3) <= grid%nzmax) then
                        i = grid%indexw(k(1), k(2), k(3))
                        if (i >= 1 .and. i <= grid%nwedge) cycle
                endif
                if (rhos(j) == zero) cycle
                nout = nout + 1
                r(:) = real(ks(:,j), dp)*h
                vpt = zero
                do iat = 1, clust%atom_num
                        d = sqrt(sum((r(:) - ra(:,iat))**2))
                        vpt = vpt - two*qa(iat)/d
                enddo
                eout = eout + vpt*rhos(j)
        enddo
        eout = eout*grid%hcub
        deallocate(ra, qa)

        write(7,'(a,3i6)') ' FDET tip sphere: spot grid offset', tipsphere_shift
        write(7,'(a,i9,a,i9)') ' FDET tip sphere: tip grid points without pot.dat data', &
                nmiss, ' of', grid%nwedge
        write(7,'(a,f20.10,a,i9,a)') ' FDET tip sphere: tip-ion/sample-elec. energy outside', &
                eout, ' Ry (', nout, ' spot points)'
endif

if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = tr(:)
call export_function(parallel, rho0)
if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = ti(:)
call export_function(parallel, v_exi)
if (parallel%iammaster) parallel%ftmp(1:grid%nwedge) = th(:)
call export_function(parallel, v_exh)
if (parallel%iammaster) deallocate(ti, th, tr)

#ifdef MPI
call mpi_bcast(eout, 1, mpi_double_precision, parallel%masterid, comm_f08, mpinfo)
call mpi_bcast(oldk, 1, mpi_double_precision, parallel%masterid, comm_f08, mpinfo)
#endif
tipsphere_eout = eout

end subroutine tipsphere_field

!-----------------------------------------------------------------------------!
! E_xc[rho_sample] on the tip grid (spin-unpolarized runs only).
!-----------------------------------------------------------------------------!
subroutine tipsphere_sample_exc(grid, parallel, elec_st, rho0, ierr)

use grid_module
use parallel_data_module
use electronic_struct_module
use exc_module
implicit none
type(grid_data), intent(in) :: grid
type(parallel_data), intent(inout) :: parallel
type(electronic_struct), intent(in) :: elec_st
real(dp), intent(in) :: rho0(parallel%mydim)
integer, intent(out) :: ierr

real(dp), allocatable :: tmp(:), wvec(:)
real(dp) :: excb

ierr = 0
if (elec_st%nspin /= 1) then
        if (parallel%iammaster) write(7,*) &
                'ERROR: boundary_sphere_around_tip supports spin-unpolarized runs only.'
        ierr = 623
        return
endif
allocate(tmp(parallel%mydim), wvec(parallel%nwedge + 1))
tmp(:) = rho0(:)
call exc_nspn(grid, parallel, elec_st%nrep, elec_st%icorr, elec_st%dioniz, &
        tmp, wvec, excb)
deallocate(tmp, wvec)
tipsphere_excb = excb
if (parallel%iammaster) write(7,'(a,f20.10,a)') &
        ' FDET tip sphere: Exc[rho_sample] on the tip grid', excb, ' Ry'

end subroutine tipsphere_sample_exc

!-----------------------------------------------------------------------------!
! Read pot.dat of the spot run (cluster, no symmetry) once.
!-----------------------------------------------------------------------------!
subroutine read_spot_field(f_name, iunit, ierr)

implicit none
character(len=*), intent(in) :: f_name
integer, intent(in) :: iunit
integer, intent(out) :: ierr

integer :: natm, ia, ios, stype(10), ndim, nwedge, ntrans, j
real(dp) :: rmax, shift(3)
real(dp), allocatable :: vxcs(:)

ierr = 0
open(iunit, file=trim(f_name), form='unformatted', status='old', iostat=ios)
if (ios /= 0) then
        write(7,*) 'ERROR: cannot open FDET potential field file: ', trim(f_name)
        ierr = 611
        return
endif
read(iunit, iostat=ios) oldks
if (ios == 0) read(iunit, iostat=ios) natm
do ia = 1, natm
        if (ios == 0) read(iunit, iostat=ios)
enddo
if (ios == 0) read(iunit, iostat=ios) stype
if (ios == 0 .and. stype(3) /= 0) then
        write(7,*) 'ERROR: FDET tip sphere needs a cluster pot.dat.'
        ierr = 624
        close(iunit)
        return
endif
if (ios == 0) read(iunit, iostat=ios) stepspot, rmax
if (ios == 0) read(iunit, iostat=ios) ndim
if (ios == 0) read(iunit, iostat=ios) shift
if (ios == 0) read(iunit, iostat=ios) nwedge, ntrans
if (ios == 0 .and. (ntrans /= 1 .or. any(abs(shift) > 1.d-10))) then
        write(7,*) 'ERROR: FDET tip sphere needs a pot.dat without symmetry and grid shift.'
        ierr = 625
        close(iunit)
        return
endif
do j = 1, 5
        if (ios == 0) read(iunit, iostat=ios)
enddo
if (ios /= 0) then
        ierr = 612
        close(iunit)
        return
endif
nws = nwedge
allocate(ks(3,nws), vions(nws), vharts(nws), vxcs(nws), rhos(nws))
read(iunit, iostat=ios) (ks(1,j), ks(2,j), ks(3,j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vions(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vharts(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (vxcs(j), j=1,nws)
if (ios == 0) read(iunit, iostat=ios) (rhos(j), j=1,nws)
close(iunit)
deallocate(vxcs)
if (ios /= 0) then
        ierr = 612
        return
endif
lo(1) = minval(ks(1,:)); hi(1) = maxval(ks(1,:))
lo(2) = minval(ks(2,:)); hi(2) = maxval(ks(2,:))
lo(3) = minval(ks(3,:)); hi(3) = maxval(ks(3,:))
allocate(idx3(lo(1):hi(1), lo(2):hi(2), lo(3):hi(3)))
idx3 = 0
do j = 1, nws
        idx3(ks(1,j), ks(2,j), ks(3,j)) = j
enddo
loaded = .true.
write(7,'(a,i9,a,f8.4,a)') ' FDET tip sphere: read', nws, &
        ' spot grid points (spacing', stepspot, ' bohr)'

end subroutine read_spot_field

end module fdet_tipsphere_module
