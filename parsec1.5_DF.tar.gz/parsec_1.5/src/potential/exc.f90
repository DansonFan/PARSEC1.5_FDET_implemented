module exc_module

use constants
implicit none
contains

!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine computes the exchange correlation potential,
! Vxc, and the exchange correlation energy, Exc, both in Rydbergs,
! based on an input charge density given in e/(bohr^3).
!
! NOTE: Extra factor of two in formulas is due to conversion from
! Hartree to Rydberg!
!
! The following exchange-correlation functionals are implemented:
!
! Local density functionals:
! Ceperley-Alder - D. M. Ceperley and B. J. Alder, Phys. Rev.
! Lett., 45, 566 (1980).
!
! PL = PW92 = PWLDA - J. P. Perdew and Y. Wang, 
!                     Phys. Rev. B 45, 13244 (1992). 
!
! Gradient-corrected functionals:
! PBE - Perdew, Burke, Ernzerhof - J. P. Perdew, K. Burke, 
! and M. Ernzerhof, Phys. Rev. Lett., 77, 3865 (1996).
!
! PW(91) = PWGGA : J. Perdew et. al., PRB 46, 6671 (1992)
!
!---------------------------------------------------------------
subroutine exc_spn(grid, parallel, nrep, nspin, icorr, dioniz, vxc, &
        wvec, exc)

use constants
use grid_module
use parallel_data_module
use dbuffer_module
use stencil_things
use psum_module
use gradmvs_module
use laplacian_ops_module, only : laplacian_fold, my_laplacian
use pbe_module
implicit none



!
! Input/Output variables:
!

! grid related data
type(grid_data), intent(in) :: grid

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! spin
integer, intent(in) :: nspin

! correlation type
character(len=2), intent(in) :: icorr

! ionization energy difference
! (used only if the correlation is of type cs)
real(dp), intent(in) :: dioniz

! order of the reduced group
integer, intent(in) :: nrep

! Input: charge density. Output: exchange-correlation potential
real(dp), dimension(parallel%mydim,nspin), intent(inout) :: vxc

! work array
real(dp), dimension(parallel%nwedge+1), intent(out) :: wvec

! total exchange-correlation energy
real(dp), intent(out) :: exc



!
! Work variables:
!

! multiplicity of grid points in irreducible wedge (equal to
! order of the reduced group)
real(dp) :: weight

! GGA variables:
! gradient - grad(n), where n is the charge density
! absgrad  - |grad(n)|
! grdgrd - components of grad(|grad(n)|
! laplac - laplacian(n)
! prod  -  grad(n) dot grad(|grad(n)|
! abs_total_grad - |grad(total rho)| 
real(dp), dimension(:,:,:), allocatable :: grad
real(dp), dimension(:,:), allocatable :: absgrad
real(dp), dimension(:,:), allocatable :: gradgrad
real(dp), dimension(:,:), allocatable :: laplac
real(dp), dimension(:,:), allocatable :: prod
real(dp), dimension(:), allocatable :: abs_total_grad

!  real(dp), dimension (nspin):: prod
real(dp) :: total_prod

! exchange energy and potential
real(dp), dimension(nspin) :: ex
real(dp), dimension(nspin) :: vx

! correlation energy and potential
real(dp) :: ec
real(dp), dimension(nspin) :: vc

! temporary holder for wb additional part
real(dp), dimension(3,nspin):: vxpbe
real(dp), dimension(3,nspin):: vcpbe

! temporary holder for gradient
real(dp), dimension(3,nspin):: tempgrad

! LDA variables:    
! rho,vx,vc temporarily store the charge,exchange and correlation 
! potentials at a given grid point
! factor of number of spins. density , absolute density, 
real(dp) :: fac
real(dp) :: rho
real(dp) :: agr
real(dp), dimension(2) :: rh
real(dp), dimension(2) :: dvc

! rs is the local value of the Wigner-Seitz radius
real(dp) :: rs

! Other parameters
real(dp), parameter :: p75vpi = 0.75d0/pi
real(dp), parameter :: thrd2 = two/three

! other temporary holders
real(dp) :: h
real(dp) :: d
real(dp) :: t

! spin channel relative accupancy
real(dp) :: zet
real(dp) :: g

! real(dp) :: temp_val
real(dp) :: dummy

! Asymptotic corrections parameters and temporary variables
real(dp), parameter :: betalb = 0.05d0
real(dp), parameter :: ac2 = four/three

real(dp) :: abstemp
real(dp), dimension(nspin) :: corrlb
real(dp) :: asinhx

! counters
integer :: i
integer :: isp 

! allocation check
integer :: alcstat

real(dp), dimension (3) :: temp1
real(dp), dimension (3) :: temp2

! local number of grid points
integer :: ndim

! communication buffer for lap/grad
type(lap_buffer) :: lap_buf
type(fold_buffer) :: fold_buf

! laplacian definition working copy (we strip symmetry in the lap/grad)
!  type (stencil_definitions) :: sten_def

! forcing use of intrinsic functions
intrinsic :: sqrt, abs, dot_product, log

! TIAN add for wb
real(dp), dimension(:,:,:), allocatable :: vxpbep2,vcpbep2

! divergence terms
real(dp), dimension(:), allocatable :: divv

! ---------------------------------------------------------------

ndim = parallel%mydim
weight = real(nrep,dp)

! factor for scaling exchange
fac = nspin

! initialize the total exchange-correlation energy to zero
exc = zero

write(9,*) icorr, nspin

if ( (icorr == 'pb') .or. (icorr == 'pw') .or. (icorr == 'wb') ) then

        ! using PBE - a gradient-corrected functional

        ! initialize working arrays:
        allocate(abs_total_grad(ndim), stat=alcstat)
        call alccheck('abs_total_grad', ndim, alcstat)

        allocate(absgrad(ndim,nspin), stat=alcstat)
        call alccheck('absgrad', ndim*nspin, alcstat)

        allocate(grad(3,ndim,nspin), stat=alcstat)
        call alccheck('grad', 3*ndim*nspin, alcstat)

        ! calculate the gradient of the charge density (rho==exc) at each
        ! grid point: for each spin channel
        do isp = 1, nspin
                call gradmvs(grid, parallel, vxc(1,isp), &
                        grad(:,:,isp), grid%coe1, grid%norder, wvec)
        enddo

        ! calculate absgrad(i,spin) -  the absolute value of the gradient
        ! |grad(rho(i,spin)|
        do isp = 1, nspin
        do i = 1, ndim
                temp1 = grad(:,i,isp)
                absgrad(i,isp)= sqrt(dot_product(temp1,temp1))
        enddo
        enddo

        ! calculate abs_total_grad
        ! (|grad(total rho)| = |grad(up)+grad(down)|)
        if (nspin == 2) then
                do i = 1, ndim
                        temp1 = grad(:,i,1) + grad(:,i,2)
                        abs_total_grad(i) = sqrt(dot_product(temp1,temp1))
                enddo
        endif
     


        if ( (icorr == 'pb') .or. (icorr == 'pw') ) then

                !initialize the pb, pw working arrays
                allocate(laplac(ndim,nspin), stat=alcstat)
                call alccheck('laplac', ndim*nspin, alcstat)

                allocate(gradgrad(3,ndim), stat=alcstat)
                call alccheck('gradgrad', 3*ndim, alcstat)

                allocate(prod(ndim,nspin), stat=alcstat)
                call alccheck('prod', ndim*nspin, alcstat)



                if (grid%sten_coeff%lap_dir_num > 0) then

                        if (parallel%nprow > 1) then
                                call init_lap_buffer(lap_buf)
                                call allocate_lap_buffer(lap_buf, parallel)
                        endif

                        do isp = 1, nspin
                                call my_laplacian(parallel, &
                                        grid%sten_coeff, &
                                        lap_buf, vxc(1,isp), &
                                        laplac(1,isp), wvec)
                        enddo

                        laplac = -laplac

                        if (parallel%nprow > 1) then
                                call destroy_lap_buffer(lap_buf)
                        endif

                else
                        ! Initialize lap buffers for communications
                        if (parallel%nprow > 1) then
                                call fold_buf%init()
                                call fold_buf%alloc( &
                                        parallel=parallel, &
                                        foldvol=grid%sten_coeff%foldsize)
                        endif

                        ! Calculate laplac(i,spin) - the Laplac of 
                        ! rho(spin) at each grid point.
                        do isp = 1, nspin
                                call laplacian_fold( &
                                        parallel=parallel, &
                                        sten_coeff=grid%sten_coeff, &
                                        fold_buff=fold_buf, &
                                        lap_in=vxc(1,isp), &
                                        lap_out=laplac(1,isp))
                        enddo

                        laplac = -laplac

                        ! destroy the buffer
                        if (parallel%nprow > 1) then
                                call fold_buf%destroy(parallel)
                        endif
                endif

                ! calculate gradgrad_spin = grad|grad(rho(i,spin))|
                ! hard to solve memmory problem here
                do isp = 1, nspin
                        call gradmvs(grid, parallel, absgrad(1,isp), &
                                gradgrad, grid%coe1, grid%norder, wvec)

                        do i = 1, ndim
                                temp1 = grad(:,i,isp)
                                temp2 = gradgrad(:,i)
                                prod(i,isp) = dot_product(temp1,temp2)
                        enddo
                enddo

                ! can reuse the gradgrad allocated array here because 
                ! it is not used again
                ! instead of allocating another total_gradgrad array
                ! calculate total_gradgrad(i) = grad|grad(rho(i))| 
                if (nspin == 2) then
                        call gradmvs(grid, parallel, abs_total_grad, &
                                gradgrad, grid%coe1, grid%norder, wvec)
                endif

                do i = 1, ndim
                        if (nspin == 2) then
                                temp1 = grad(:,i,1) + grad(:,i,2)
                                temp2 = gradgrad(:,i)
                                total_prod = dot_product(temp1,temp2)

                                ! do the rest in pbe module
                                call spn_pbe(nspin, icorr, vxc(i,:), &
                                        absgrad(i,:), prod(i,:), &
                                        laplac(i,:), abs_total_grad(i), &
                                        total_prod, ex, vx, ec, vc)

                        !else  ! (nspin == 1)
                                !call pbe(icorr,vxc(i,1),absgrad(i,1),prod,laplac(i,1), &
                                !ex,vx,ec,vc)
                        endif

                        !INTEGRATE
                        do isp = 1, nspin
                                exc = exc + &
                                        vxc(i,isp)*two*(ex(isp) + ec)*weight
                                vxc(i,isp) = two*(vx(isp) + vc(isp))
                        enddo
                enddo

                ! free up pb, pw memory
                deallocate(laplac)
                deallocate(gradgrad)
                deallocate(prod)
                !        deallocate(total_gradgrad)
        
                ! wb is done here, should I move to seperate subroutine?
                ! this is good for one or two spin channels

        elseif (icorr == 'wb') then
      
       !initialize the wb working arrays
        allocate(vxpbep2(3,ndim,nspin),stat=alcstat)
        call alccheck('vxpbep2',3*ndim*nspin,alcstat)

        allocate(vcpbep2(3,ndim,nspin),stat=alcstat)
        call alccheck('vcpbep2',3*ndim*nspin,alcstat)

        allocate(divv(ndim),stat=alcstat)
        call alccheck('divv',ndim,alcstat)

        ! if nspin == 1
        zet = zero
        g = one
        
        do i = 1,ndim
           !call new_pbe(nspin,vxc,absgrad(i,:),
           !,ex,vx,ec,vc,vxpbe,vcpbe)
           !exchange (tempgrad and agr initiated here also for correlation)
           do isp = 1, nspin 
              rh(isp) = vxc(i,isp)
              tempgrad(:,isp) = grad(:,i,isp)
              !scale for spin polarized
              rho = fac*rh(isp)
              agr = fac*absgrad(i,isp)
              if(rh(isp) < 1d-18)then
                 ex(isp) = zero
                 vx(isp) = zero
                 vxpbe(:,isp) = zero
              else
                 call new_exchpbe(rho,agr,tempgrad(:,isp),ex(isp),vx(isp),vxpbe(:,isp))                 
              endif
          enddo

           !correlation
           d = sum(rh)
           if (d < 1d-18)then
              ec = zero
              vc = zero
              vcpbe = zero   
           else
              rs = calc_rs(d)
              if (nspin == 2) then
                 zet=(rh(1)-rh(2))/d
                 g=((one+zet)**thrd2+(one-zet)**thrd2)/two
                 agr = abs_total_grad(i)
              endif
              !lsd correlation 
              ! last three outputs are used only for pbe, pw, so can use dummy here
              call corlsd(rs,zet,ec,vc,dummy, dummy)
              
              !pbe correlation   
              t = calc_t(agr,d,g)  
              call new_corpbe(nspin,d,zet,g,t,tempgrad,absgrad(i,:),ec,vc,h,dvc,vcpbe)
              ec = ec + h
              do isp = 1,2
                 vc(isp) = vc(isp) + dvc(isp)
              enddo
           endif
           do isp =1,nspin
              vxpbep2(:,i,isp) = vxpbe(:,isp)
              vcpbep2(:,i,isp) = vcpbe(:,isp)

              exc = exc + rh(isp)*two*(ex(isp) + ec)*weight
              vxc(i,isp) = two*(vx(isp) + vc(isp))
             
           enddo
        enddo
        
        ! clculate the second term
        do isp =1,nspin
           !x
           call divergence(grid,parallel,ndim,vxpbep2(:,:,isp),divv,wvec)
           do i = 1,ndim
              vxc(i,isp) = vxc(i,isp) - two*divv(i)
           enddo
           !c
           call divergence(grid,parallel,ndim,vcpbep2(:,:,isp),divv,wvec)
           do i = 1,ndim
              vxc(i,isp) = vxc(i,isp) - two*divv(i)
           enddo
        enddo
        ! deallocate wb specifics
        deallocate(vxpbep2)  
        deallocate(vcpbep2)
        deallocate(divv)
        ! finished wb 
        
     endif


        ! finished gga
        ! free up gga memory
        deallocate(abs_total_grad)
        deallocate(absgrad)
        deallocate(grad)



! lda functionals
elseif ( (icorr == 'pl') .or. (icorr == 'ca') ) then

        ! lsd exchange correlation
        do i = 1, ndim
                do isp = 1, nspin
                        rh(isp) = vxc(i,isp)
                enddo

                if (minval(rh) > zero) then
                        ! exchange
                        do isp = 1, nspin
                                rho = fac*rh(isp)

                                call exchlsd(rho, ex(isp), vx(isp))
                        enddo

                        ! local correlation
                        d = sum(rh)
                        rs = calc_rs(d)
                        zet = (rh(1)-rh(2))/d

                        if (icorr == 'pl') then
                                ! ecrs, eczet are used only for pbe, can 
                                ! put dummy here
                                call corlsd(rs, zet, ec, vc, dummy, dummy)

                                ! scale
                                ec = two*ec
                                vc = two*vc

                        else !if(icorr == 'ca') then
                                call corlsd_ca(rs, zet, ec, vc)
                        endif

                        ! integrate
                        do isp = 1, nspin
                                exc = exc + rh(isp)*(two*ex(isp) + ec)*weight
                                vxc(i,isp) = two*vx(isp) + vc(isp)
                        enddo
                endif
        enddo

elseif ( (icorr == 'lb') .or. (icorr == 'cs') ) then
        ! Asymptotically corrected Ceperly-Alder exchange correlation

        ! initialize working arrays:
     
        allocate(grad(3,ndim,nspin), stat=alcstat)
        call alccheck('grad', 3*ndim*nspin, alcstat)

        allocate(absgrad(ndim,nspin), stat=alcstat)
        call alccheck('absgrad', ndim*(nspin), alcstat)

        ! calculate |grad(rho)|/rho^(4/3) -- spinup & spindown
        do isp = 1, nspin
                call gradmvs(grid, parallel, vxc(1,isp), grad(:,:,isp), &
                        grid%coe1, grid%norder, wvec)

                do i = 1, ndim
                        temp1 = grad(:,i,isp)
                        abstemp = sqrt(dot_product(temp1,temp1))

                        if (vxc(i,isp) > zero) then
                                absgrad(i,isp) = abstemp/(vxc(i,isp)**ac2)
                        endif
                enddo
        enddo

        ! compute exchange-correlation potential and energy
        do i = 1, ndim
                do isp = 1, nspin
                        rh(isp) = vxc(i,isp)
                enddo

                if (minval(rh) > zero) then
                        ! compute exchange
                        do isp = 1, nspin
                                rho = fac*rh(isp)

                                call exchlsd(rho,ex(isp),vx(isp))
                        enddo

                        ! compute Ceperely-Alder term
                        d = sum(rh)
                        rs = calc_rs(d)
                        zet = (rh(1)-rh(2))/d

                        call corlsd_ca(rs, zet, ec, vc)

                        ! integrate
                        do isp = 1, nspin
                                exc = exc + rh(isp)*(two*ex(isp) + ec)*weight
                                vxc(i,isp) = two*vx(isp) + vc(isp)

                                ! Compute Leeuwen-Baerends correction to 
                                ! the potential.
                                abstemp = absgrad(i,isp)
                                asinhx = log(abstemp + &
                                        sqrt(abstemp*abstemp + one))
                                corrlb(isp) = two*betalb*(rh(isp)**third)* &
                                        abstemp*abstemp/ &
                                        (one + three*betalb*abstemp*asinhx)

                                ! If correcting for the ionization 
                                ! energy difference, shift the
                                ! correlation energy.
                                if (icorr == 'cs') then
                                        if (corrlb(isp) > dioniz) &
                                                corrlb(isp) = dioniz
                                endif

                                vxc(i,isp) = vxc(i,isp) - corrlb(isp)
                        enddo
                endif
        enddo

        ! free up memory
        deallocate(absgrad)
        deallocate(grad)
endif
  
! Scale the total energy integral by h^3 (factor necessary due to
! the expression of an integral as a summation over grid points) and
! sum it up over processors.
call psum(exc, 1, parallel%group_size, parallel%group_comm)

exc = exc * (grid%hcub)

!debuging outputs
write(9,*) 'final exc:'
write(9,*) exc

end subroutine exc_spn
!===============================================================



!===============================================================
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This suborutine computes the exchange correlation potential,
! Vxc, and the exchange correlation energy, Exc, both in Rydbergs,
! based on an input charge density given in e/bohr^3, for the
! case of a spin-unpolarized calculation.
!
! NOTE: Extra factor of two in formulas is due to conversion from
! Hartree to Rydberg!
!
! The following exchange-correlation functionals are implemented:
!
! Local density functionals:
! 1. Slater's x-alpha - J. C. Slater, Phys. Rev. 81, 385 (1951).
! 2. Wigner's interpolation - E. Wigner, Phys. Rev. 46, 1002
!           (1934).
! 3. Hedin-Lundqvist -  L. Hedin and B. I. Lundqvist, J. Phys. C,
!           4, 2064 (1971).
! 4. Ceperley-Alder - D. M. Ceperley and B. J. Alder, Phys. Rev.
!           Lett., 45, 566 (1980).
!
! Gradient-corrected functional:
! PBE - Perdew, Burke, Ernzerhof - J. P. Perdew, K. Burke, and 
!           M. Ernzerhof, Phys. Rev. Lett., 77, 3865 (1996).
!
! Asymptotically-corrected functionals:
! 1. Leeuwen-Baerends correction - Leeuwen and Baerends, 
!           Phys. Rev. 49, 2421 (1994).
! 2. Casida-Salahub correction - Casida and Salahub, J. Chem.
!           Phys., 113, 8918 (2000).
!
!---------------------------------------------------------------
subroutine exc_nspn(grid, parallel, nrep, icorr, dioniz, vxc, wvec, exc, pot)

use constants
use grid_module
use parallel_data_module
use potential_module
use kinetic_module
use dbuffer_module
use stencil_things
use psum_module
use gradmvs_module
use laplacian_ops_module, only : laplacian_fold, my_laplacian
use pbe_module
use fornberg_module, only : fornberg
implicit none


!
! Input/Output variables:
!


! grid related data
type (grid_data), intent(in) :: grid

! parallel computation related data
type (parallel_data), intent(in) :: parallel

! correlation type
character(len=2), intent(in) :: icorr

! ionization energy difference
! (used only if the correlation is of type cs)
real(dp), intent(in) :: dioniz

! order of the reduced group
integer, intent(in) :: nrep

! input charge density, overwritten by exchange-correlation potential
real(dp), dimension(parallel%mydim), intent(inout) :: vxc

! work array
real(dp), dimension(parallel%nwedge+1), intent(out) :: wvec

! total exchange-correlation energy
real(dp), intent(out) :: exc

! optional FDET potential data
type(potential), intent(inout), optional :: pot



!
! Work variables:
!

! multiplicity of grid points in irreducible wedge (equal to
! order of the reduced group)
real(dp) :: weight

! number of spin channels
integer ::  nspin = 1

! GGA variables:
! quantities fed to pbe.f:
! grad - grad(n), where n is the charge density
! absgrad  - |grad(n)|
! gradgrad - components of grad(|grad(n)|
! laplac - laplacian(n)
! prod  -  grad(n) dot grad(|grad(n)|
real(dp), dimension(:,:), allocatable :: grad
real(dp), dimension(:), allocatable :: absgrad
real(dp), dimension(:,:), allocatable :: gradgrad
real(dp), dimension(:), allocatable :: laplac
real(dp) :: prod

! energy and potentials
real(dp) :: ex
real(dp) :: vx
real(dp) :: ec
real(dp) :: vc
real(dp) :: zet
real(dp) :: g 

! LDA variables:
! various recurring parameters in the exchange-correlation
! formulas: 
! quantities common to all local density expressions:
! rs is the local value of the Wigner-Seitz radius
! rho temporarily stores the charge at a given grid point
real(dp) :: a0
real(dp) :: twovpia0
real(dp) :: p75vpi
real(dp) :: alpha
real(dp) :: rs
real(dp) :: rho
! calculated in corlsd and used for pb and pw correlation
real(dp) :: eurs

! Wigner parameters:
real(dp), parameter :: aw = -0.875529d0
real(dp), parameter :: bw = 7.8d0

! Hedin-Lundqvist parameters:
real(dp), parameter :: ah = 1.d0/21.d0
real(dp), parameter :: ch = 0.045d0

real(dp) :: x 

! Asymptotic corrections parameters and temporary variables
real(dp), parameter :: betalb = 0.05d0
real(dp) :: ac1
real(dp) :: ac2 
real(dp) :: abstemp
real(dp) :: corrlb
real(dp) :: asinhx

! actual number of grid points
integer :: ndim

! allocation check
integer :: alcstat

! temporary variables
real(dp), dimension(3) :: temp1
real(dp), dimension(3) :: temp2

real(dp) :: vxctmp !< threadprivate temp variable instead of using array
real(dp) :: dummy

! counters
integer :: i

! communication buffer for lap/grad
type (lap_buffer) :: lap_buf
type (fold_buffer) :: fold_buf

! laplacian definition working copy (we strip symmetry in the lap/grad)
!  type (stencil_definitions) :: sten_def

logical, parameter :: change_gradient_norder = .false.
! KHL: custom norder (actually should be less than 6, 
!      because the neighbor list was established up to
!      order 6)
!      1 <= tmp_norder <= 6
integer, parameter :: tmp_norder = 3
integer :: ierr
integer :: idirection
real(dp), dimension(:,:), allocatable :: tmp_coe1
real(dp), dimension(:), allocatable :: tmp_grad
real(dp), dimension(:,:), allocatable :: tmp_gradgrad

! TIAN add for new_pbe
!wb work
real(dp) :: t, vc1(2), h, dvc(2)
real(dp) :: vxpbe(3), vcpbe(3) 
real(dp), dimension(:,:), allocatable :: vxpbep2,vcpbep2
! divergence terms
real(dp), dimension(:), allocatable :: divv

! ---------------------------------------------------------------

! initialize arrays:

ndim = parallel%mydim
weight = real(nrep,dp)

allocate(grad(3,ndim), stat=alcstat)
call alccheck('grad', 3*ndim, alcstat)

allocate(absgrad(ndim), stat=alcstat)
call alccheck('absgrad', ndim, alcstat)

! and some more constants:
a0 = (four/(nine*pi))**third
twovpia0 = two/(pi*a0)
p75vpi = 0.75d0/pi

! initialize the total exchange-correlation energy to zero
exc = zero

if (present(pot)) then
        if (pot%fex_is) then
                call kinetic_energy(grid, parallel, pot%rho0, &
                        pot%kin_name, pot%vum, pot%vuk, weight, vxc, &
                        pot%tnadd, pot%vnadd, wvec)
        endif
endif




if (icorr == 'pw' .or. icorr == 'pb' .or. icorr == 'wb') then

        if (change_gradient_norder) then
                exc = dzero

                allocate(tmp_coe1(-tmp_norder:tmp_norder,3))
                call fornberg(1, tmp_norder, tmp_coe1(:,1), ierr)
                tmp_coe1(:,3) = tmp_coe1(:,1)/grid%step(3)
                tmp_coe1(:,2) = tmp_coe1(:,1)/grid%step(2)
                tmp_coe1(:,1) = tmp_coe1(:,1)/grid%step(1)

                ! =======================
                ! calculate |grad(rho)|
                ! =======================
                call gradmvs(grid, parallel, vxc(:), grad(:,:), &
                        tmp_coe1, tmp_norder, wvec(:))

                do i = 1, ndim
                        temp1(:) = grad(:,i)
                        absgrad(i) = sqrt(dot_product(temp1(:),temp1(:)))
                enddo
        else

                ! grad = grad(rho)
                call gradmvs(grid, parallel, vxc, grad, grid%coe1, &
                        grid%norder, wvec)

                ! absgrad = |grad(rho)|
                do i = 1, ndim
                        temp1 = grad(:,i)
                        absgrad(i) = sqrt(dot_product(temp1,temp1))
                enddo
        endif

        if ( (icorr == 'pb') .or. (icorr == 'pw') ) then

                allocate(laplac(ndim), stat=alcstat)
                call alccheck('laplac', ndim, alcstat)        

                allocate(gradgrad(3,ndim), stat=alcstat)
                call alccheck('gradgrad', 3*ndim, alcstat)

                if (change_gradient_norder) then

                        allocate(tmp_grad(ndim), stat=alcstat)
                        call alccheck('tmp_grad', ndim, alcstat)

                        allocate(tmp_gradgrad(3,ndim), stat=alcstat)
                        call alccheck('tmp_gradgrad', 3*ndim, alcstat)

                        call gradmvs(grid, parallel, absgrad(:), &
                                gradgrad(:,:), tmp_coe1, tmp_norder, wvec(:))

                        ! =======================
                        ! calculate laplacian(rho)
                        ! =======================
                        ! KHL: do gradmvs() twice to get the laplacian
                        !      (so that we can assign tmp_norder)
                        !      (right now laplacian_fold() fixes the norder)
                        laplac(:) = dzero
                   
                        do idirection = 1, 3
                                do i = 1, ndim
                                        tmp_grad(i) = grad(idirection,i)
                                enddo

                                call gradmvs(grid, parallel, tmp_grad(:), &
                                        tmp_gradgrad(:,:), &
                                        tmp_coe1, tmp_norder, wvec(:))

                                do i = 1, ndim
                                        laplac(i) = laplac(i) + &
                                                tmp_gradgrad(idirection,i)
                                enddo
                        enddo

                        laplac(:) = -laplac(:)

                        deallocate(tmp_coe1)
                        deallocate(tmp_grad)
                        deallocate(tmp_gradgrad)

                else
                        if (grid%sten_coeff%lap_dir_num > 0) then
                                ! KHL: for now we use lap_buff
                                !      to handle the case of non-ortho. grid
                                if (parallel%nprow > 1) then
                                        call init_lap_buffer(lap_buf)
                                        call allocate_lap_buffer(lap_buf, &
                                                parallel)
                                endif

                                call my_laplacian(parallel, &
                                        grid%sten_coeff, &
                                        lap_buf, vxc, laplac, wvec(:))

                                laplac = -laplac

                                if (parallel%nprow > 1) then
                                        call destroy_lap_buffer(lap_buf)
                                endif
                        else
                                ! Initialize lap buffers for communications
                                if (parallel%nprow > 1) then
                                        call fold_buf%init()
call fold_buf%alloc(parallel, foldvol=grid%sten_coeff%foldsize)
                                endif

                                ! Calculate the gradient and the 
                                ! Laplacian of 
                                ! the charge density at each grid point
                                call laplacian_fold(parallel, &
                                        grid%sten_coeff, fold_buf, &
                                        vxc, laplac)

                                laplac = -laplac

                                ! destroy lap buffers
                                if (parallel%nprow > 1) then
                                        call fold_buf%destroy(parallel)
                                endif
                        endif

                        ! calculate grad(rho)_dot_grad|grad(rho)| 
                        ! gradgrad = grad|grad(rho)|
                        call gradmvs(grid, parallel, absgrad, &
                                gradgrad, grid%coe1, grid%norder, wvec)

                endif

                do i = 1, ndim
                        !prod = grad(rho)_dot_grad|grad(rho)|
                        temp1 = grad(:,i)
                        temp2 = gradgrad(:,i)
                        prod = dot_product(temp1,temp2)

                        call pbe(icorr, vxc(i), absgrad(i), prod, &
                                laplac(i), ex, vx, ec, vc)

                        ! integrate
                        exc = exc + vxc(i)*two*(ex + ec)*weight
                        vxc(i) = two*vx + vc
                enddo

                deallocate(laplac)
                deallocate(gradgrad)
                ! finished pb and pw
        
        elseif (icorr == 'wb') then
        ! TIAN pbe with White and Bird method
        ! Noticing that vc only stores the first term of Vc, the 
        ! second term is -div*vpbep2

        !initialize the wb working arrays
        allocate(vxpbep2(3,ndim),stat=alcstat)
        call alccheck('vxpbep2',3*ndim,alcstat)
        
        allocate(vcpbep2(3,ndim),stat=alcstat)
        call alccheck('vcpbep2',3*ndim,alcstat)
        
        allocate(divv(ndim),stat=alcstat)
        call alccheck('divv',ndim,alcstat)

        !constant for no spin
        zet = zero
        g = one

        do i = 1,ndim
           
           rho = vxc(i)
           
           if(rho < 1d-18)then
              ex = zero
              vx = zero
              vxpbe = zero
              ec = zero
              vc = zero
              vcpbe = zero
           else
              !exchange           
              call new_exchpbe(rho,absgrad(i),grad(:,i),ex,vx,vxpbe)
                   
              !correlation
              rs = calc_rs(rho)
              !lsd correlation
              call corlsd(rs,zet,ec,vc1,dummy, dummy)

              !pbe correlation   
              t = calc_t(absgrad(i),rho,g)        
              call new_corpbe(nspin,rho,zet,g,t,grad(:,i),absgrad(i),ec,vc1,h,dvc,vcpbe)
              ec = ec + h
              vc = vc1(1) + dvc(1) + vc1(2) + dvc(2)

           endif
           vxpbep2(:,i) = vxpbe(:)
           vcpbep2(:,i) = vcpbe(:)

           exc = exc + rho*two*(ex + ec)*weight
           vxc(i) = two*(vx) + vc   
        enddo

        ! second term
        !x
        call divergence(grid,parallel,ndim,vxpbep2(:,:),divv,wvec)
        do i = 1,ndim
           vxc(i) = vxc(i) - two*divv(i)
        enddo
        !c
        call divergence(grid,parallel,ndim,vcpbep2(:,:),divv,wvec)
        do i = 1,ndim
           vxc(i) = vxc(i) - two*divv(i)
        enddo

        deallocate(vxpbep2)
        deallocate(vcpbep2)
        deallocate(divv)
        ! finished wb
        !finished gga functionals
     endif


! lda functionals
elseif (icorr == 'xa') then
        ! x-alpha correlation

        alpha = one

        ! Note: alpha = 2/3 is pure exchange
        write(7,10) alpha
10 format(' performed x-alpha correlation with alpha = ',f6.3)

        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        rs = calc_rs(rho)
                        vxc(i) = -1.5d0*twovpia0*alpha/rs
                        exc = exc + 0.75d0*rho*vxc(i)*weight
                endif
        enddo


elseif (icorr == 'wi') then
        ! Wigner correlation

        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        rs = calc_rs(rho)
                        vxctmp = -twovpia0/rs
                        exc = exc + 0.75d0*rho*vxctmp*weight + &
                                rho*aw/(rs + bw)
                        vxc(i) = vxctmp + &
                                aw*(four*rs*third+bw)/((rs+bw)*(rs+bw))
                endif
        enddo



elseif (icorr == 'hl') then
        ! Hedin-lundqvist exchange-correlation

        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        rs = calc_rs(rho)
                        vxctmp = -twovpia0/rs
                        exc = exc + 0.75d0*rho*vxctmp*weight
                        x = rs*ah
                        alpha = log(one+one/x)
                        vxc(i) = vxctmp - ch*alpha
                        exc = exc - &
                                rho*ch* &
                                ((one+x*x*x)*alpha+x*half-x*x-third)*weight
                endif
        enddo

elseif (icorr == 'ca') then
        ! Ceperly-Alder exchange correlation
        
        !!$OMP PARALLEL DO SIMD REDUCTION(+:exc) DEFAULT(FIRSTPRIVATE)&
        !!$OMP& SHARED(vxc)
        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        ! exchange
                        rs = calc_rs(rho)
                        vxctmp = -twovpia0/rs
                        exc = exc + 0.75d0*rho*vxctmp*weight

                        ! correlation
                        call corca_nspn(rs,ec,vc)

                        vxc(i) = vxctmp + vc
                        exc = exc + rho*ec*weight
                endif
        enddo


elseif (icorr == 'pl') then
        ! Perdew-Wang local exchange correlation

        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        rs = calc_rs(rho)
                        vxctmp = -twovpia0/rs
                        exc = exc + 0.75d0*rho*vxctmp*weight

                        call gcor(0.0310907d0, 0.21370d0, 7.5957d0, &
                                3.5876d0, 1.6382d0, 0.49294d0, rs, ec, eurs)

                        vxc(i) = vxctmp + two*( ec - rs*eurs/three )
                        exc = exc + rho*ec*weight*two
                endif
        enddo
        !!$OMP END PARALLEL DO SIMD



else  ! if (icorr == 'lb' .or. icorr == 'cs') then
        ! Asymptotically corrected Ceperly-Alder exchange correlation

        ! define parameters
        ac1 = two**third
        ac2 = four/three

        ! calculate 2^(1/3) * |grad(rho)|/rho^(4/3)
        call gradmvs(grid, parallel, vxc, grad, grid%coe1, grid%norder, wvec)

        do i = 1, ndim
                temp1 = grad(:,i)
                abstemp = sqrt(dot_product(temp1,temp1))

                if (vxc(i) > zero) then
                        absgrad(i) = ac1*abstemp/(vxc(i)**ac2)
                endif
        enddo

        ! compute exchange-correlation potential and energy
        do i = 1, ndim
                rho = vxc(i)
                vxc(i) = zero

                if (rho > zero) then
                        ! compute Ceperely-Alder term
                        rs = calc_rs(rho)
                        vxctmp = -twovpia0/rs
                        exc = exc + 0.75d0*rho*vxctmp*weight

                        call corca_nspn(rs, ec, vc)

                        vxc(i) = vxctmp + vc
                        exc = exc + rho*ec*weight

                        ! Compute Leeuwen-Baerends correction to 
                        ! the potential.
                        abstemp = absgrad(i)
                        asinhx = log(abstemp+sqrt(abstemp*abstemp+one))
                        corrlb = two*betalb*(rho**third)/ac1*abstemp* &
                                abstemp/(one + three*betalb*abstemp*asinhx)

                        ! If correcting for the ionization energy 
                        ! difference, shift the correlation energy.
                        if (icorr == 'cs') then
                                if (corrlb > dioniz) corrlb = dioniz
                        endif

                        vxc(i) = vxc(i) - corrlb
                endif
        enddo
endif






!
! Scale the total energy integral by h^3 (factor necessary due to the
! expression of an integral as a summation over grid points) and
! sum it up over processors.
!
call psum(exc, 1, parallel%group_size, parallel%group_comm)
exc  = exc * (grid%hcub)

! FDET: reduce and scale the non-additive kinetic energy the same way
! (PARSEC 1.4 exc_nspn did this with tvec).
if (present(pot)) then
        if (pot%fex_is) then
                call psum(pot%tnadd, 1, parallel%group_size, parallel%group_comm)
                pot%tnadd = pot%tnadd * (grid%hcub)
        endif
endif

!debuging outputs
write(9,*) 'final exc:'
write(9,*) exc

deallocate(absgrad)
deallocate(grad)

end subroutine exc_nspn





!====================================================================
! calculate the divergence term for wb pbe
!====================================================================
subroutine divergence(grid,parallel,ndim,vpbe2,divv,wvec)
  use gradmvs_module
  use grid_module
  use parallel_data_module

  
  implicit none
  ! Input/Output variables:
  !
  ! grid related data
  type (grid_data), intent(in) :: grid
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel
  ! local number of grid points
  integer, intent(in) :: ndim
  !term to take divergence
  real(dp),  intent(in) :: vpbe2(3,ndim)
  ! caculated divergence
  real(dp), intent(out) :: divv(ndim)
  ! work array
  real(dp), intent(out) :: wvec(parallel%nwedge + 1)
  
  
  !work variables
  ! counters
  integer::i
  integer :: alcstat
  real(dp), dimension(:,:), allocatable :: divvx, divvy, divvz

  allocate(divvx(3,ndim),stat=alcstat)
  call alccheck('divvx',3*ndim,alcstat)
  
  allocate(divvy(3,ndim),stat=alcstat)
  call alccheck('divvy',3*ndim,alcstat)
  
  allocate(divvz(3,ndim),stat=alcstat)
  call alccheck('divvz',3*ndim,alcstat)

  ! calculate the gradient in every direction
  call gradmvs(grid,parallel,vpbe2(1,:),divvx,grid%coe1,grid%norder,wvec)
  call gradmvs(grid,parallel,vpbe2(2,:),divvy,grid%coe1,grid%norder,wvec)
  call gradmvs(grid,parallel,vpbe2(3,:),divvz,grid%coe1,grid%norder,wvec)

  ! sum x,y,z
  do i = 1,ndim
     divv(i) = divvx(1,i) + divvy(2,i) + divvz(3,i)
  enddo
  
  deallocate(divvx)
  deallocate(divvy)
  deallocate(divvz)

end subroutine divergence









!======================================================
! Ceperley-adler correlation
! spin polarized case
!======================================================
subroutine corlsd_ca(rs, zet, ec, vc)
use constants
implicit none

! input/output variables
real(dp), intent(in) :: rs
real(dp), intent(in) :: zet

real(dp), intent(out) :: ec
real(dp), dimension(2), intent(out) :: vc

! work variables
real(dp) :: f
real(dp) :: fz
real(dp) :: eu

real(dp) :: lrs
real(dp) :: srs
real(dp) :: es
real(dp) :: vs

! High density (rs<1) contants, LDA
real(dp), parameter :: ca_c1 = 0.0622d0
real(dp), parameter :: ca_c2 = 0.0960d0
real(dp), parameter :: ca_c3 = 0.0040d0
real(dp), parameter :: ca_c4 = 0.0232d0
real(dp), parameter :: ca_c5 = 0.0192d0

real(dp), parameter :: ca_as =  0.0311d0
real(dp), parameter :: ca_bs = -0.0538d0
real(dp), parameter :: ca_cs =  0.0014d0
real(dp), parameter :: ca_ds = -0.0096d0
! Low density (rs>1) constants, LDA
real(dp), parameter :: ca_g = -0.2846d0
real(dp), parameter :: ca_b1 = 1.0529d0
real(dp), parameter :: ca_b2 = 0.3334d0
real(dp), parameter :: ca_gs = -0.1686d0
real(dp), parameter :: ca_b1s = 1.3981d0
real(dp), parameter :: ca_b2s = 0.2611d0

real(dp), parameter :: ac2 = four/three
real(dp), parameter :: gamma = 0.5198421d0
real(dp), parameter :: fzz = 1.709921d0

! -----------------------------------------------------------

f = ((one+zet)**ac2+(one-zet)**ac2-two)/gamma
fz = ac2*((one+zet)**third-(one-zet)**third)/gamma

if (rs < one) then
        ! correlation: high density
        lrs = log(rs)
        eu = ca_c1 * lrs - ca_c2 + (ca_c3 * lrs - ca_c4) * rs
        vc(1) = eu - (ca_c1 + (ca_c3 * lrs + ca_c3 - ca_c4) * rs) /3.d0
        es = ca_as * lrs + ca_bs + (ca_cs * lrs + ca_ds) * rs
        vs = es - (ca_as + (ca_cs * lrs + ca_cs + ca_ds) * rs) /3.d0
else !rs >= one
        ! correlation: low density
        srs = sqrt(rs)
        eu = ca_g / (1.d0 + ca_b1 * srs + ca_b2 * rs)
        vc(1) = eu * eu * (1.d0 + 7.0d0 * ca_b1 * srs / 6.d0 + &
                4.d0/3.d0 * ca_b2 * rs) / ca_g
        es = ca_gs / (1.d0 + ca_b1s * srs + ca_b2s * rs)
        vs = es * es * (1.d0 + 7.0d0 * ca_b1s * srs / 6.d0 + &
                4.d0/3.d0 * ca_b2s * rs) / ca_gs
endif

vc(2) = vc(1) + f*(vs - vc(1)) - (es - eu)*(1.d0 + zet)*fz
vc(1) = vc(1) + f*(vs - vc(1)) + (es - eu)*(1.d0 - zet)*fz
ec = eu + f*(es - eu)
end subroutine corlsd_ca












!======================================================
! ca correlation for the nonspinpolarized case
!======================================================
subroutine corca_nspn(rs, ec, vc)
implicit none

!input/output
real(dp), intent(in) :: rs

real(dp), intent(out):: ec
real(dp), intent(out):: vc

!work
real(dp) :: sqrs
real(dp) :: alpha

! Ceperley-Alder parameters
real(dp), parameter :: g =-0.2846d0
real(dp), parameter :: b1 = 1.0529d0
real(dp), parameter :: b2 = 0.3334d0
real(dp), parameter :: c1 = 0.0622d0
real(dp), parameter :: c2 = 0.096d0
real(dp), parameter :: c3 = 0.004d0
real(dp), parameter :: c4 = 0.0232d0
real(dp), parameter :: c5 = 0.0192d0

! -----------------------------------------------------------

if (rs >= one) then
        sqrs = sqrt(rs)
        ec = g/(one + b1*sqrs + b2*rs)
        vc = ec*ec*(one+3.5d0*b1*sqrs*third + four*b2*rs*third)/g
else
        alpha = log(rs)
        ec = c1*alpha - c2 + (c3*alpha - c4)*rs
        vc = ec - (c1 + (c3*alpha - c5)*rs)*third
endif
end subroutine corca_nspn




!===============================================================
end module exc_module
