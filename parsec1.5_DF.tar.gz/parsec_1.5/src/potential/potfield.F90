module potfield_module
   implicit none
   contains

!=============================================================================!
! Read a PARSEC pot.dat-style external field for FDET AFM simulations.
!=============================================================================!
subroutine potfield(grid, pbc, parallel, v_exi, v_exh, rho0, oldk, &
        f_name, iunit, ierr)

use constants, only : dp, zero
use grid_module
use pbc_module
use parallel_data_module
use aux, only : alccheck

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, &
        mpi_double_precision
#else
use mpi
#endif
#endif

implicit none

type(grid_data), intent(in) :: grid
type(pbc_data), intent(in) :: pbc
type(parallel_data), intent(inout) :: parallel
real(dp), intent(inout) :: v_exi(parallel%mydim)
real(dp), intent(inout) :: v_exh(parallel%mydim)
real(dp), intent(inout) :: rho0(parallel%mydim)
real(dp), intent(out) :: oldk
character(len=*), intent(in) :: f_name
integer, intent(in) :: iunit
integer, intent(out) :: ierr

integer :: natm, ia, i, j, idx, prev
integer :: ndim, nwedge, ntrans
integer :: stype(10)
integer :: nmin(3), nmax(3)
integer :: alcstat, iostat_open
real(dp) :: step(3), box_size(3), latt_vec(3,3), rmax, shift(3)
real(dp) :: alatt(3,3), invlat(3,3)
real(dp), allocatable :: xa(:), ya(:), za(:)
real(dp), allocatable :: trans(:,:,:)
integer, allocatable :: chi(:,:), rmtrx(:,:,:)
integer, allocatable :: kx(:), ky(:), kz(:)
real(dp), allocatable :: vion(:), vhart(:), vxc(:), srho(:)
real(dp), allocatable :: tmp(:), tmpi(:), tmph(:)

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

ierr = 0
oldk = zero
v_exi(:) = zero
v_exh(:) = zero
rho0(:) = zero

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

if (parallel%iammaster) then
        open(iunit, file=trim(f_name), form='unformatted', status='old', &
                iostat=iostat_open)
        if (iostat_open /= 0) then
                write(7,*) 'ERROR: cannot open FDET potential field file: ', &
                        trim(f_name)
                ierr = 611
        endif
endif

#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, parallel%masterid, comm_f08, mpinfo)
#endif
if (ierr /= 0) return

if (parallel%iammaster) then
        read(iunit) oldk
        read(iunit) natm
        allocate(xa(natm), ya(natm), za(natm), stat=alcstat)
        call alccheck('potfield atom coords', 3*natm, alcstat)
        do ia = 1, natm
                read(iunit) xa(ia), ya(ia), za(ia)
        enddo

        read(iunit) stype
        if (stype(3) == 0) then
                read(iunit) step(1), rmax
                step(2:3) = step(1)
        else
                read(iunit) (step(i), i=1,3)
                read(iunit) (box_size(i), i=1,3)
                read(iunit) ((latt_vec(i,j), i=1,3), j=1,3)
        endif

        read(iunit) ndim
        read(iunit) (shift(i), i=1,3)
        read(iunit) nwedge, ntrans

        allocate(rmtrx(3,3,ntrans), trans(3,3,ntrans), &
                chi(ntrans,ntrans), kx(nwedge), ky(nwedge), kz(nwedge), &
                stat=alcstat)
        call alccheck('potfield symmetry/grid metadata', &
                18*ntrans+ntrans*ntrans+3*nwedge, alcstat)
        read(iunit) rmtrx
        read(iunit) trans
        read(iunit)
        read(iunit) alatt, invlat
        read(iunit) ((chi(i,j), i=1,ntrans), j=1,ntrans)
        read(iunit) ((kx(i), ky(i), kz(i)), i=1,nwedge)

        allocate(vion(nwedge), vhart(nwedge), vxc(nwedge), &
                srho(nwedge), stat=alcstat)
        call alccheck('potfield data', 4*nwedge, alcstat)
        read(iunit) (vion(i), i=1,nwedge)
        read(iunit) (vhart(i), i=1,nwedge)
        read(iunit) (vxc(i), i=1,nwedge)
        read(iunit) (srho(i), i=1,nwedge)
        close(iunit)

        do i = 1, 3
                if (abs(grid%step(i) - step(i)) > 1.0d-10) then
                        write(7,*) 'ERROR: FDET field grid spacing mismatch.'
                        write(7,*) 'Current step:', grid%step
                        write(7,*) 'Field step  :', step
                        ierr = 601
                endif
        enddo

        if (nwedge /= grid%nwedge .or. ndim /= grid%ndim) then
                write(7,*) 'ERROR: FDET field grid size mismatch.'
                write(7,*) 'Current ndim/nwedge:', grid%ndim, grid%nwedge
                write(7,*) 'Field ndim/nwedge  :', ndim, nwedge
                ierr = 602
        endif

        nmin(1) = minval(kx)
        nmax(1) = maxval(kx)
        nmin(2) = minval(ky)
        nmax(2) = maxval(ky)
        nmin(3) = minval(kz)
        nmax(3) = maxval(kz)

        if (grid%nxmax < nmax(1) .or. grid%nxmin > nmin(1) .or. &
            grid%nymax < nmax(2) .or. grid%nymin > nmin(2) .or. &
            grid%nzmax < nmax(3) .or. grid%nzmin > nmin(3)) then
                write(7,*) 'ERROR: FDET field extends outside current grid.'
                ierr = 603
        endif
endif

#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, parallel%masterid, comm_f08, mpinfo)
call mpi_bcast(oldk, 1, mpi_double_precision, parallel%masterid, &
        comm_f08, mpinfo)
#endif
if (ierr /= 0) return

if (parallel%iammaster) then
        allocate(tmp(grid%nwedge), tmpi(grid%nwedge), tmph(grid%nwedge), &
                stat=alcstat)
        call alccheck('potfield mapped data', 3*grid%nwedge, alcstat)
        tmp(:) = zero
        tmpi(:) = zero
        tmph(:) = zero

        prev = 0
        do i = 1, grid%nwedge
                idx = 0
                if (prev < nwedge) then
                        if (grid%kx(i) == kx(prev+1) .and. &
                            grid%ky(i) == ky(prev+1) .and. &
                            grid%kz(i) == kz(prev+1)) then
                                idx = prev + 1
                        endif
                endif

                if (idx == 0) then
                        do j = 1, nwedge
                                if (grid%kx(i) == kx(j) .and. &
                                    grid%ky(i) == ky(j) .and. &
                                    grid%kz(i) == kz(j)) then
                                        idx = j
                                        exit
                                endif
                        enddo
                endif

                if (idx == 0) then
                        write(7,*) 'ERROR: FDET field grid point not found.'
                        write(7,*) grid%kx(i), grid%ky(i), grid%kz(i)
                        ierr = 604
                        exit
                endif

                tmpi(i) = vion(idx)
                tmph(i) = vhart(idx)
                tmp(i) = srho(idx)
                prev = idx
        enddo
endif

#ifdef MPI
call mpi_bcast(ierr, 1, mpi_integer, parallel%masterid, comm_f08, mpinfo)
#endif
if (ierr /= 0) return

if (parallel%iammaster) parallel%ftmp(:) = tmp(:)
call export_function(parallel, rho0)

if (parallel%iammaster) parallel%ftmp(:) = tmpi(:)
call export_function(parallel, v_exi)

if (parallel%iammaster) parallel%ftmp(:) = tmph(:)
call export_function(parallel, v_exh)

if (parallel%iammaster) then
        deallocate(xa, ya, za, rmtrx, trans, chi, kx, ky, kz)
        deallocate(vion, vhart, vxc, srho, tmp, tmpi, tmph)
endif

end subroutine potfield

end module potfield_module
