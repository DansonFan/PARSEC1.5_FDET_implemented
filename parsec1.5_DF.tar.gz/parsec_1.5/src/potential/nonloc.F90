module nonloc_module
   implicit none
   contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine calculates various quantities associated with
! the non-local components of the pseudopotential. They are used
! later for determining this non-local contribution to the
! Hamiltonian matrix and to the calculation of non-local forces.
!
! This subroutine handles both the case of a periodic system
! and a confined system.
!
!---------------------------------------------------------------
subroutine nonloc(clust, grid, p_pot, nloc_p_pot, pbc, parallel, ipr, ierr)

use constants
use aux, only : matvec3, mysecond, ylm_real, ylm_cplx, myflush
use cluster_module
use grid_module
use pseudo_potential_module
use non_local_psp_module
use pbc_module
use parallel_data_module
use psum_module
use spline_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_double_complex, &
        mpi_double_precision
#else
use mpi
#endif
#endif

implicit none
!
!  Input/Output variables:
!
!  the cluster
type (cluster), intent(in) :: clust
!  grid related data
type (grid_data), intent(in) :: grid
!  pseudo_potential related data
type (pseudo_potential), intent(in) :: p_pot
!  non local pseudo_potential related data
type (nonloc_pseudo_potential), intent(inout) :: nloc_p_pot
!  periodic boundary conditions data
type (pbc_data), intent(inout) :: pbc
!  parallel computation related data
type (parallel_data), intent(in) :: parallel
!  error flag, 300 < ierr < 311
integer, intent(in) :: ipr
integer, intent(out) :: ierr
integer, dimension(1):: ierrvec
!
!  Work variables:
!
!   counters for k-points
integer kplp, kpnum

!  temporary storage variables
integer npoint,npt
real(dp) :: rr(3), ylm(7), ylmd(3,7), rnorm, an_tmp(7), vylmd_tmp(3,7)
!  double grid parameters
integer idgx, idgy, idgz, ndouble
real(dp), allocatable :: fdouble(:)
real(dp) :: invd
!  true if this grid point is inside the non-local sphere
logical :: lnloc
! partial openmp work to make this faster
integer :: lnloc_count

!  true if this grid point is inside the Wigner-Seitz sphere
logical :: wslnloc
! partial openmp work to make this faster
integer :: wslnloc_count

!  inloc replaces rnloc and ratom
integer, dimension(:,:,:), allocatable :: inloc

real(dp) :: fact1,vwr,dvwr,x,y,z,xa,ya,za
real(dp), dimension(clust%type_num) :: rc, ainv, binv, rrmin
!  number of replicas of the periodic cell to be used in the
!  construction of non-local spheres around each atom
!  nreplica = 0 if .not. pbc%is_on
integer nreplica(3)
!  temporary counter of number of non-local points around each
!  atom
integer nloc, wsnloc
!  loop counters
integer i,iat,ity,ja,lm,lp,mg,icellx,icelly,icellz,im
!  transformation of non-local arrays
integer ioffset,itot,icur,icount,irow,itran,wsirow,wsitran,wsicur,wsitot,wsicount
!  local aliases of variables contained in structures
integer maxnloc,natom,nnodes,wsmaxnloc
!  counter for the number of non-local projectors
integer ilm, iatom
integer ilm_offset

real(dp) :: rr_tmp
real(dp) :: uvec(3), xvec(3), xholdvec(3)
real(dp) :: tmpmat(3,3), tmpnorm
!  spin-orbit vriables
real(dp) :: vwr_ion,vwr_so
real(dp) :: dvr_so, dvr_ion
complex(dpc), dimension(5) :: zylm, an_tmp_ion, an_tmp_so
complex(dpc), dimension(3,5) :: zylmd, zvylmd_tmpi, zvylmd_tmps
integer isy,solm,iso,sol

!timers galore
real(dp) :: time0, time1, tfind_nlnum0, tfind_nlnum1, tgetpoints0, tgetpoints1, tgetpots0, tgetpots1, trearrange0, trearrange1

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif

integer :: comm

! KHL: to split the psum of anloc and vylmd into multiple times
integer, parameter :: psum_split_num = 10
integer, dimension(psum_split_num) :: nlm_of_this_split
integer :: nlm_remainder

!---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif


call mysecond(time0)

npt = 0
fact1 = 0.d0
xholdvec(:) = 0.d0

kpnum = max(pbc%nkpt,1) !so that gamma point calculations still have a kpoint here
ierr = 0

! copy data
natom = clust%atom_num
nnodes = parallel%procs_num
comm = parallel%comm


!
! Initialize spin-orbit data.
!
nloc_p_pot%is_so = p_pot%is_so !possible code smell?
!


!  Initialize double grid data.
!  AJB: THIS IS ALREADY DONE IN init_var ????
!
ndouble = grid%ndouble !default ndouble = 1
allocate(fdouble(-ndouble+1:ndouble-1))
invd = one/real(ndouble,dp)
do idgx = -ndouble + 1, ndouble - 1
      fdouble(idgx) = (one - real(abs(idgx),dp)*invd)*invd
enddo

!  Define parameters for periodic boundary conditions.
nreplica = 0
if (pbc%per > 0) nreplica(1:pbc%per) = 1




!
!  Determine the spatial extent of the non-local contribution on
!  the radial grid and translate it to the size of the non-local
!  block around each atom.
!
!  Initialize the atom counter, ja, and arrays in nloc_p_pot structure.
call mysecond(tfind_nlnum0)
ja = 0
nloc_p_pot%wsnlatom(:) = 0
nloc_p_pot%nlatom(:) = 0
nloc_p_pot%nlmatm(:) = 0
nloc_p_pot%skbi(:) = zero
nloc_p_pot%so_num = 0
!  For each atom type
do ity = 1, clust%type_num
        !  Update temporary variables for number of points in
        !  pseudopotential, npoint, (inverse) radial grid parameters, ainv
        !  and binv, smallest distance from the atom recorded in
        !  psedupotential file (rrmin) and the smaller between the core
        !  -cutoff radius and the largest radius still available in the
        !  pseudopotential file, rc.
        npoint = p_pot%ns(ity)
        ainv(ity) = one / p_pot%par_a(ity)
        binv(ity) = one / p_pot%par_b(ity)
        rrmin(ity) = p_pot%rs(2,ity)
        rc(ity) = p_pot%rcore(ity)

        !AJB: this clause appears to be testing whether the next to last
        !     radial grid point is smaller than rc, and if so it is made rc.
        if (p_pot%rs(npoint-1, ity) < rc(ity)) then
                rc(ity) = p_pot%rs(npoint-1, ity)
        endif

        !  Initialize matrix for geometrical grid transformations
        !  in case of periodic boundary conditions.
        tmpmat = pbc%latt_vec
        !AJB: okay... is this the best way to do this?
        do i = 1, 3
                tmpnorm = sqrt(sum(tmpmat(:,i)**2))
                tmpmat(:,i) = tmpmat(:,i)/tmpnorm
        enddo
        !
        !  For each atom inside this given type...
        !
        !  Update atom # counter, ja, and temporary variables for storing
        !  the atomic position, xa, ya, za.
        !TODO: Start parallel region here, need to map first the ja's
        do iat = 1, clust%natmi(ity)
                ja = ja + 1 !AJB do we have to do it this way?

                !  Setting a boolean vector to indicate if the atom has
                !  spin-orbit correction psp.
                if(nloc_p_pot%is_so) then
                        nloc_p_pot%so(ja) = p_pot%so(ity)
                        if(p_pot%so(ity)) nloc_p_pot%so_num = nloc_p_pot%so_num + 1
                else
                        nloc_p_pot%so(ja) = .false.
                endif

                !  Distribute atoms round-robin around processors.
                if (mod(ja-1,nnodes) /= parallel%iam) cycle

                xa = clust%xatm(ja)
                ya = clust%yatm(ja)
                za = clust%zatm(ja)
                !
                !  Check if the grid point is within the core-cutoff radius around
                !  the atom. If it is not, it has no non-local contribution because
                !  outside the core all pseudopotential components are equal.
                !  If we are dealing with periodic boundary conditions, we
                !  also need to see whether a given grid point is inside the
                !  core-cutoff radius if shifted by the size of the box in the
                !  +x,-x,+y,-y,+z,-z directions (and any combination thereof). In
                !  theory, one would need to check for shifts of twice the size of
                !  the box, three times the size of the box, etc. In practice this
                !  is NOT required, because it would imply a core cutoff radius
                !  larger than the box - which makes for a very bad calculation
                !  anyway.

                !  Reset counter of non-local points per given atom.
                nloc = 0
                wsnloc = 0
                !  For each grid point in the full grid...
                !  AJB: THIS NEXT NESTED LOOP THING JUST CHECKS TO SEE THE AMOUNT OF NON LOCAL POINTS FOR EACH ATOM
                !  (make use of openmp)
                !$OMP PARALLEL DO &
                !$OMP& SCHEDULE(RUNTIME)  &
                !$OMP& DEFAULT(SHARED) &
                !$OMP& PRIVATE(mg,icellx,icelly,icellz,uvec,x,y,z,xvec,rr_tmp,lnloc_count,wslnloc_count,idgx,idgy,idgz) &
                !$OMP& REDUCTION(+:nloc,wsnloc)
                do mg = 1, grid%ndim
                        !  Allow each point to be shifted by the length of the box in each
                        !  direction.
                        do icellx = -nreplica(1),nreplica(1)
                        do icelly = -nreplica(2),nreplica(2)
                        do icellz = -nreplica(3),nreplica(3)
                                !  Compute distance between point (or its replica if PBC)
                                !  and atom and increase nloc if it is inside the
                                !  non-local range.
                                !wslnloc = .false.
                                !lnloc = .false.
                                wslnloc_count = 0
                                lnloc_count = 0
                                do idgx = -ndouble+1, ndouble-1
                                !write(9,*) "just checking: idgx in nonloc.F90: ",idgx
                                do idgy = -ndouble+1, ndouble-1
                                do idgz = -ndouble+1, ndouble-1
                                        !no need to keep looking if this is a nonloc point
                                        ! AJB: but is this the most efficent way to squrim out of the
                                        ! loop without breaking OMP specs?
                                        if((wslnloc_count == 0 ) .AND. ( lnloc_count == 0)) then
                                                !TODO: icell[xyz]*box_size to temporary variables
                                                uvec(1)=(grid%shift(1) + grid%fx(mg))* grid%step(1)+ real(icellx,dp)*pbc%box_size(1)
                                                uvec(2)=(grid%shift(2) + grid%fy(mg))* grid%step(2)+ real(icelly,dp)*pbc%box_size(2)
                                                uvec(3)=(grid%shift(3) + grid%fz(mg))* grid%step(3)+ real(icellz,dp)*pbc%box_size(3)
                                                !TODO: real idg[xyz] just after their do loop and store this number and add up here^
                                                uvec(1) = uvec(1) + real(idgx,dp)*grid%step(1)*invd
                                                uvec(2) = uvec(2) + real(idgy,dp)*grid%step(2)*invd
                                                uvec(3) = uvec(3) + real(idgz,dp)*grid%step(3)*invd

                                                call matvec3('N',pbc%avec_norm,uvec,xvec)

                                                 x = xvec(1) - xa
                                                 y = xvec(2) - ya
                                                 z = xvec(3) - za
                                                 rr_tmp = sqrt(x*x+y*y+z*z)

                                                !if (rr_tmp <= rc(ity)) lnloc = .true.
                                                if (rr_tmp <= rc(ity)) lnloc_count = lnloc_count+1
                                                ! AJB: TODO Check who (and where) needs the WZ radii check. Maybe can skip this check?

                                                !if (rr_tmp <= p_pot%rws(ity)) wslnloc = .true.
                                                if (rr_tmp <= p_pot%rws(ity)) wslnloc_count = wslnloc_count+1
                                        endif
                                enddo
                                enddo
                                enddo

                                if (lnloc_count > 0 ) nloc = nloc + 1
                                if (wslnloc_count > 0  ) wsnloc = wsnloc + 1
                        enddo
                        enddo
                        enddo
                enddo
                !$OMP END PARALLEL DO
                !  Update array of total number of non-local points per atom and
                !  maximum size of non-local block associated with any atom.
                !DEBUG:
                !write(9,*)'atom, nloc,wsnloc ', ja,nloc,wsnloc

                nloc_p_pot%nlatom(ja) = nloc
                nloc_p_pot%wsnlatom(ja) = wsnloc
        enddo                  ! iat = 1, clust%natmi(ity)
enddo                     ! ity = 1, clust%type_num }}}
! every PE will have the same data about {ws}nlatom
call mysecond(tfind_nlnum1)
call pisum(nloc_p_pot%wsnlatom,natom,nnodes,comm)
call pisum(nloc_p_pot%nlatom,natom,nnodes,comm)



#ifdef AJB_DEBUG
   if (parallel%iammaster) then
      write(7,*)
      write(7,*) ' now calling nonloc_pseudo_pot_set_maxnloc'
      write(7,*)
   endif
#endif


call nonloc_pseudo_pot_set_maxnloc(nloc_p_pot)


#ifdef AJB_DEBUG
   if (parallel%iammaster) then
      write(7,*)
      write(7,*) ' finished nonloc_pseudo_pot_set_maxnloc'
      write(7,*) ' check individual out files to see what happend'
      write(7,*)
   endif
#endif




maxnloc = nloc_p_pot%maxnloc
wsmaxnloc = nloc_p_pot%wsmaxnloc
allocate(inloc(4,maxnloc,natom))
!inloc = 0
do i = 1, 4
do mg = 1, maxnloc
do iat = 1, natom
        inloc(i,mg,iat) = 0
enddo
enddo
enddo
! AJB: From here on I am not sure why so much work is being redone, but this is the way it was since parsec 1.0
ja = 0
iso = 0
isy = 0
!  For each atom type
call mysecond(tgetpoints0)
do ity = 1, clust%type_num
        if (p_pot%so(ity)) isy = isy + 1

        !TODO: Start parallel region here, need to map first the ja's
        do iat = 1, clust%natmi(ity)
                ja = ja + 1

                !  Set some identifying arrays for atoms with spin-orbit coupling.
                if(nloc_p_pot%is_so) then
                    if (nloc_p_pot%so(ja)) then
                       iso = iso + 1
                       nloc_p_pot%so_indx(iso) = ja
                       nloc_p_pot%cc(:,iso) = p_pot%cc(:,isy)
                    endif
                endif

                !  Distribute atoms round-robin around processors.
                if (mod(ja-1,nnodes) /= parallel%iam) cycle

                 xa = clust%xatm(ja)
                 ya = clust%yatm(ja)
                 za = clust%zatm(ja)
                 nloc = 0
                 wsnloc = 0

                ! if this part is going to stay in here, might as well be with OMP
                ! !$OMP PARALLEL DO &
                ! !$OMP& SCHEDULE(RUNTIME)  &
                ! !$OMP& DEFAULT(SHARED) &
                ! !$OMP& PRIVATE() &
                ! !$OMP& REDUCTION(+:nloc,wsnloc)
                do mg = 1, grid%ndim
                do icellx = -nreplica(1),nreplica(1)
                do icelly = -nreplica(2),nreplica(2)
                do icellz = -nreplica(3),nreplica(3)
                        !  Compute (AGAIN) distance between point (or its replica if PBC) and atom.
                        !  If the point is inside non-local range:
                        !  1. Increase the non-local point counter, nloc, by one.
                        !  2. Update the output arrays, indw, inloc, with the grid point, (in
                        !     the irreducible wedge) and its location on the cell, respectively.

                        lnloc = .false.
                        wslnloc = .false.
                        do idgx = -ndouble + 1, ndouble - 1
                        do idgy = -ndouble + 1, ndouble - 1
                        do idgz = -ndouble + 1, ndouble - 1
                              !if this point is flagged, no need to keep comparing
                              if ( (.NOT. lnloc) .AND. (.NOT. wslnloc) ) then

                                 uvec(1)=(grid%shift(1) + grid%fx(mg))* grid%step(1)+ real(icellx,dp)*pbc%box_size(1)
                                 uvec(2)=(grid%shift(2) + grid%fy(mg))* grid%step(2)+ real(icelly,dp)*pbc%box_size(2)
                                 uvec(3)=(grid%shift(3) + grid%fz(mg))* grid%step(3)+ real(icellz,dp)*pbc%box_size(3)

                                 uvec(1) = uvec(1)  + real(idgx,dp)*grid%step(1)*invd
                                 uvec(2) = uvec(2)  + real(idgy,dp)*grid%step(2)*invd
                                 uvec(3) = uvec(3)  + real(idgz,dp)*grid%step(3)*invd

                                 call matvec3('N',pbc%avec_norm,uvec,xvec)

                                 x = xvec(1) - xa
                                 y = xvec(2) - ya
                                 z = xvec(3) - za

                                 !this part does not exist in the previous similar looking loop
                                 if ( (idgx == 0) .and. (idgy == 0)  .and. (idgz == 0) ) then
                                    xholdvec(1)=xvec(1)
                                    xholdvec(2)=xvec(2)
                                    xholdvec(3)=xvec(3)
                                 endif

                                 rr_tmp = sqrt(x*x+y*y+z*z)
                                 if (rr_tmp <= rc(ity)) lnloc = .true.
                                 !if (rr_tmp <= rc(ity)) lnloc_count = lnloc_count + 1
                                 if (rr_tmp <= p_pot%rws(ity)) wslnloc = .true.
                                 !if (rr_tmp <= p_pot%rws(ity)) wslnloc_count = wslnloc_count +1
                              endif
                        enddo
                        enddo
                        enddo

                        if (wslnloc) then
                                wsnloc = wsnloc + 1
                                nloc_p_pot%wsindw(wsnloc,ja) = grid%rindex(mg)
                                nloc_p_pot%wstran(wsnloc,ja) = grid%rtrans(mg)
                        endif

                        if (lnloc) then
                                nloc = nloc + 1
                                nloc_p_pot%indw(nloc,ja) = grid%rindex(mg)
                                nloc_p_pot%tran(nloc,ja) = grid%rtrans(mg)
                                inloc(:,nloc,ja) = (/ mg, icellx, icelly, icellz /)

                                if(pbc%nkpt > 0) then
                                   do kplp = 1, kpnum

                                      nloc_p_pot%right(nloc,kplp,ja)= exp( zi * &
                                         (pbc%kpts(1,kplp)*xholdvec(1)+ &
                                         pbc%kpts(2,kplp)*xholdvec(2)+ &
                                         pbc%kpts(3,kplp)*xholdvec(3)) )

                                      nloc_p_pot%left(nloc,kplp,ja)=  exp(-1*zi* &
                                         (pbc%kpts(1,kplp)*xholdvec(1)+ &
                                         pbc%kpts(2,kplp)*xholdvec(2)+ &
                                         pbc%kpts(3,kplp)*xholdvec(3)) )
                                   enddo
                                endif
                        endif
                enddo
                enddo
                enddo
                enddo
                ! !$OMP END PARALLEL DO

                if (nloc /= nloc_p_pot%nlatom(ja)) then
                        write(9,*) ' ERROR in nonloc ', &
                                nloc,iat,ja,ity,nloc_p_pot%nlatom(ja)
                        ierr = 301
                endif

                if (wsnloc /= nloc_p_pot%wsnlatom(ja)) then
                        write(9,*) ' ERROR in nonloc ', &
                                wsnloc,iat,ja,ity,nloc_p_pot%wsnlatom(ja)
                        ierr = 555
                endif
        enddo          ! iat = 1, clust%natmi(ity)
enddo          ! ity = 1, clust%type_num

call mysecond(tgetpoints1)
ierrvec = ierr
call pisum(ierrvec,1,nnodes,comm)
ierr = ierrvec(1)
if (ierr /= 0) then
      ierr = 301
      if (parallel%iammaster) write(9,*) ' ERROR in nonloc '
      return
endif
if (ipr >=0) then
        !
        !  Report non-local block sizes to file.
        !
        write(9,*)
        write(9,*) 'Non-local pseudopotential messages:'
        write(9,*) '-----------------------------------'
        write(9,*) 'Max # of nonlocal points for one atom = ',nloc_p_pot%maxnloc
        write(9,*)
        write(9,*) 'Sizes of all non-local blocks '
        write(9,'(12(1x,i5))') (nloc_p_pot%nlatom(i),i=1,clust%atom_num)

        if (nloc_p_pot%is_so) write(9,*) 'Tot. number of atoms with spin-orbit term =',nloc_p_pot%so_num

        write(9,*)

        if (parallel%iammaster) then
              write(7,*)
              write(7,*) 'Non-local pseudopotential messages:'
              write(7,*) '-----------------------------------'
              write(7,*) 'Max # of nonlocal points for one atom = ',nloc_p_pot%maxnloc
              write(7,*)
              write(7,*) 'Sizes of all non-local blocks '
              write(7,'(12(1x,i5))') (nloc_p_pot%nlatom(i),i=1,clust%atom_num)

              if (nloc_p_pot%is_so) write(7,*) 'Tot. number of atoms with spin-orbit term =',nloc_p_pot%so_num

              write(7,*)
        endif
endif




!
!  Calculate the non-local potential vector for each angular
!  component. The result is stored in anloc.
!  The non-local pseudopotential to the hamiltonian is
!  subsequently calculated as the outer product of these vectors,
!  summed over all angular components l,m.
!
ja = 0
!  Initialize the counter of non-local projectors.
ilm = 0
iso = 0
isy = 0

if (nloc_p_pot%is_so) then
        nloc_p_pot%v_so(:,:,:) = zzero
        nloc_p_pot%dv_so(:,:,:,:) = zzero
        nloc_p_pot%v_ion(:,:,:) = zzero
        nloc_p_pot%dv_ion(:,:,:,:) = zzero
endif
!
call mysecond(tgetpots0)
!  For each atom type, for each atom within each type
do ity = 1, clust%type_num
        npoint = p_pot%ns(ity)

        if (p_pot%so(ity)) isy = isy + 1

        do iat = 1, clust%natmi(ity)
                !  Again update temporary storage of atom # and position
                ja = ja + 1

                if (nloc_p_pot%so(ja)) iso = iso + 1

                !  Distribute atoms round-robin around processors
                if (mod(ja-1,nnodes) /= parallel%iam) then
                        do lp = 1, p_pot%nlocp(ity)
                                if (lp /= p_pot%loc(ity)) ilm = ilm + 2*lp - 1
                        enddo

                        cycle
                endif

                nloc = nloc_p_pot%nlatom(ja)
                !  Initialize angular momentum (l,m) count
                lm = 0
                !
                !  Loop over each angular momentum component, l (and within
                !  the loop calculate for different m's too).
                ! OMP DO REDUCTION(+:lm) from here...
                do lp = 1, p_pot%nlocp(ity)

                        !  Skip the local component of the pseudopotential!
                        if (lp == p_pot%loc(ity) .and. lp == 1) cycle

                        !  Calculate the multiplicand - (non-local pseudopotential)*
                        !  (radial pseudowavefunction)*(angular wave function), put the
                        !  results in anloc. That is, calculate explicitly |Vl-Vloc|phi_lm>.

                        do i = 1, nloc
                                an_tmp(:) = zero
                                vylmd_tmp(:,:) = zero

                                an_tmp_ion(:) = zzero
                                zvylmd_tmpi(:,:) = zzero

                                an_tmp_so(:) = zzero
                                zvylmd_tmps(:,:) = zzero

                                mg = inloc(1,i,ja)
                                icellx = inloc(2,i,ja)
                                icelly = inloc(3,i,ja)
                                icellz = inloc(4,i,ja)
                                do idgx = -ndouble + 1, ndouble - 1
                                do idgy = -ndouble + 1, ndouble - 1
                                do idgz = -ndouble + 1, ndouble - 1
                                        uvec(1)=(grid%shift(1) + grid%fx(mg))*grid%step(1) + real(icellx,dp)*pbc%box_size(1)
                                        uvec(2)=(grid%shift(2) + grid%fy(mg))*grid%step(2) + real(icelly,dp)*pbc%box_size(2)
                                        uvec(3)=(grid%shift(3) + grid%fz(mg))*grid%step(3) + real(icellz,dp)*pbc%box_size(3)
                                        uvec(1) = uvec(1) + real(idgx,dp)*grid%step(1)*invd
                                        uvec(2) = uvec(2) + real(idgy,dp)*grid%step(2)*invd
                                        uvec(3) = uvec(3) + real(idgz,dp)*grid%step(3)*invd

                                        call matvec3('N',pbc%avec_norm,uvec,xvec)
                                        rr(1) = xvec(1) - clust%xatm(ja)
                                        rr(2) = xvec(2) - clust%yatm(ja)
                                        rr(3) = xvec(3) - clust%zatm(ja)

                                        rnorm = sqrt(dot_product(rr,rr))
                                        !  In order to avoid dividing by zero:
                                        if (rnorm < rrmin(ity))  then
                                           rnorm = rrmin(ity)
                                        endif

                                        if (rnorm > rc(ity)) cycle

                                        if(lp /= p_pot%loc(ity)) then
                                           npt = idint(binv(ity) * log(one+ainv(ity)*rnorm))+1
                                           fact1 = (rnorm - p_pot%rs(npt,ity)) / (p_pot%rs(npt+1,ity) - p_pot%rs(npt,ity))

                                           vwr  = p_pot%vw (npt, ity, lp) + fact1*(p_pot%vw (npt+1,ity,lp)-p_pot%vw (npt,ity,lp))
                                           dvwr  = p_pot%dvw(npt, ity, lp) + fact1*(p_pot%dvw(npt+1,ity,lp)-p_pot%dvw(npt,ity,lp))
                                           if (p_pot%uspline(ity)) then
                                              call splint(p_pot%rs(-p_pot%norder:npoint,ity), &
                                                 p_pot%vw(-p_pot%norder:npoint,ity,lp), &
                                                 p_pot%d2vw(-p_pot%norder:npoint,ity,lp), &
                                                 npoint+1+p_pot%norder,rnorm,vwr,dvwr)
                                           endif

                                           vwr = vwr * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)
                                           dvwr = dvwr * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)

                                           call ylm_real(lp,rr,rnorm,ylm,ylmd)
                                           do im = 1, 2*lp - 1
                                              !AJB - you should also save the ylm^2 since we need to recalculate skbi per atom per m per l
                                              an_tmp(im) = an_tmp(im) + ylm(im)*vwr
                                              vylmd_tmp(:,im) = vylmd_tmp(:,im) + ylmd(:,im)*vwr + dvwr*ylm(im)*rr/rnorm
                                           enddo
                                        endif

                                        !   Do the same for the spin-orbit potentials, this
                                        !   time with complex arrays here s orbitals have no
                                        !   contribution to spin-orbit and local component has
                                        !   a contribution.
                                        if(nloc_p_pot%is_so .and. lp > 1) then
                                           if (nloc_p_pot%so(ja)) then
                                              sol = lp - 1

vwr_ion= p_pot%vionr  (npt,isy,sol) +fact1*(p_pot%vionr  (npt+1,isy,sol) -p_pot%vionr(npt,isy,sol))
dvr_ion= p_pot%dvr_ion(npt,isy,sol) +fact1*(p_pot%dvr_ion(npt+1,isy,sol) -p_pot%dvr_ion(npt,isy,sol))

vwr_so = p_pot%vsor  (npt,isy,sol) +fact1*(p_pot%vsor   (npt+1,isy,sol) -p_pot%vsor (npt,isy,sol))
dvr_so = p_pot%dvr_so(npt,isy,sol) +fact1*(p_pot%dvr_so (npt+1,isy,sol) -p_pot%dvr_so(npt,isy,sol))

                                              if (p_pot%uspline(ity)) then
                                                 call splint(p_pot%rs(-p_pot%norder:npoint,ity), &
                                                    p_pot%vionr(-p_pot%norder:npoint,isy,sol), &
                                                    p_pot%d2vr_ion(-p_pot%norder:npoint,isy,sol), &
                                                    npoint+1+p_pot%norder,rnorm,vwr_ion,dvr_ion)
                                                 call splint(p_pot%rs(-p_pot%norder:npoint,ity), &
                                                    p_pot%vsor(-p_pot%norder:npoint,isy,sol), &
                                                    p_pot%d2vr_so(-p_pot%norder:npoint,isy,sol), &
                                                    npoint+1+p_pot%norder,rnorm,vwr_so,dvr_so)
                                              endif

                                              vwr_ion =  vwr_ion * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)
                                              dvr_ion  = dvr_ion  * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)
                                              vwr_so  =  vwr_so  * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)
                                              dvr_so   = dvr_so   * fdouble(idgx)*fdouble(idgy)*fdouble(idgz)

                                              call ylm_cplx(sol,rr,rnorm,zylm,zylmd)
                                              rr = rr / rnorm

                                              do im = 1, 2*sol + 1
                                                 an_tmp_ion(im) = an_tmp_ion(im) + zylm(im) * vwr_ion
                                                 an_tmp_so(im) = an_tmp_so(im) + zylm(im) * vwr_so
                                                 zvylmd_tmps(:,im) = zvylmd_tmps(:,im) + zylmd(:,im)*vwr_so + dvr_so*zylm(im)*rr
                                                 zvylmd_tmpi(:,im) = zvylmd_tmpi(:,im) + zylmd(:,im)*vwr_ion + dvr_ion*zylm(im)*rr
                                              enddo

                                           endif !if(p_pot%spinorbit .and. ... .ne....) then
                                        endif !if (nloc_p_pot%so(ja))then
                                enddo !idgx = -ndouble + 1, ndouble - 1
                                enddo !idgy = -ndouble + 1, ndouble - 1
                                enddo !idgz = -ndouble + 1, ndouble - 1

                                if(nloc_p_pot%is_so .and. lp > 1) then
                                  if (nloc_p_pot%so(ja)) then
                                     sol = lp - 1
                                     do im = 1, 2*sol + 1
                                        solm = 3*(sol - 1) + im
                                        nloc_p_pot%v_so(i,solm,iso) = an_tmp_so(im)
                                        nloc_p_pot%v_ion(i,solm,iso) = an_tmp_ion(im)
                                        nloc_p_pot%dv_so(:,i,solm,iso) = zvylmd_tmps(:,im)
                                        nloc_p_pot%dv_ion(:,i,solm,iso) = zvylmd_tmpi(:,im)
                                     enddo
                                  endif
                                endif

                                if (lp /= p_pot%loc(ity)) then
                                  do im = 1, 2*lp - 1
                                     nloc_p_pot%anloc(i, ilm+im) = an_tmp(im)
                                     nloc_p_pot%vylmd(:, i, ilm+im) = vylmd_tmp(:,im)
                                  enddo
                                endif
                        enddo  ! do i = 1, nloc

                        if (lp == p_pot%loc(ity)) cycle

                        do im = 1, 2*lp-1
                               !AJB - note that the ekbi value is l' dep. only, through the delta_v_l in its calculation.
                               nloc_p_pot%skbi(ilm+im) = p_pot%ekbi(lp,ity)
                               !And so, this is a perfect spot to calculate the kb integral per atom, per l, per m.
                               !needs - deltavl, radialwf, ylm evaluated on the nonlocal points for this iat
                        enddo

                        lm =  lm + 2*lp - 1
                        ilm = ilm + 2*lp - 1

                enddo               ! lp = 1, p_pot%nlocp(ity)

                !  Update array with number of lm components for each atom.
                nloc_p_pot%nlmatm(ja) = lm

        enddo                  ! iat = 1, clust%natmi(ity)
enddo                     ! ity = 1, clust%type_num

call mysecond(tgetpots1)
deallocate(inloc)
deallocate(fdouble)
!
!  Share information. Follow the round-robin distribution of atoms.
!
call pisum(nloc_p_pot%indw,maxnloc*nloc_p_pot%atom_num,nnodes,comm)
call pisum(nloc_p_pot%tran,maxnloc*nloc_p_pot%atom_num,nnodes,comm)

if(wsmaxnloc>0) then
      call pisum(nloc_p_pot%wsindw,wsmaxnloc*nloc_p_pot%atom_num,nnodes,comm)
      call pisum(nloc_p_pot%wstran,wsmaxnloc*nloc_p_pot%atom_num,nnodes,comm)
endif
call pisum(nloc_p_pot%nlmatm,nloc_p_pot%atom_num,nnodes,comm)



nlm_remainder = mod(nloc_p_pot%nlm, psum_split_num)
nlm_of_this_split(1) = (nloc_p_pot%nlm - nlm_remainder)/psum_split_num
do i = 2, psum_split_num
        nlm_of_this_split(i) = nlm_of_this_split(1)
enddo
if (nlm_remainder /= 0) then
        do i = 1, psum_split_num
                nlm_of_this_split(i) = nlm_of_this_split(i) + 1
                nlm_remainder = nlm_remainder - 1
                if (nlm_remainder == 0) exit
        enddo
endif
!write(9,*) 'nlm_of_this_split', nlm_of_this_split

do i = 1, psum_split_num
        !write(9,*) 'sum(nlm_of_this_split(1:i-1))', sum(nlm_of_this_split(1:i-1))
        call psum(nloc_p_pot%anloc(1,1+sum(nlm_of_this_split(1:i-1))), &
                maxnloc*nlm_of_this_split(i), nnodes, comm)

        call psum(nloc_p_pot%vylmd(1,1,1+sum(nlm_of_this_split(1:i-1))), &
                3*maxnloc*nlm_of_this_split(i), nnodes, comm)
enddo



call psum(nloc_p_pot%skbi,nloc_p_pot%nlm,nnodes,comm)

if (pbc%nkpt > 0) then
        ! KHL: mpi allreduce may fail here when nkpt is large.
        !      For example, maxnloc=748, atom_num=12, nkpt=4096,
        !      then number of elements would be 36765696, 
        !      which is 588 MB per task. If there are 64 procs 
        !      per node, this allreduce would need around 38 GB
        !      for the temporary buffers on a node.
        !      For now we may use less procs and more threads to
        !      circumvent this issue.
      call zpsum(nloc_p_pot%right,maxnloc*pbc%nkpt*nloc_p_pot%atom_num, nnodes,comm)
      call zpsum(nloc_p_pot%left,maxnloc*pbc%nkpt*nloc_p_pot%atom_num, nnodes,comm)
endif

#ifdef MPI
do iso = 1, nloc_p_pot%so_num
      ja = nloc_p_pot%so_indx(iso)
      i = mod(ja-1,nnodes)
      call MPI_BCAST(nloc_p_pot%v_so(1,1,iso),maxnloc*8,   MPI_DOUBLE_COMPLEX,i,comm_f08, mpinfo)
      call MPI_BCAST(nloc_p_pot%v_ion(1,1,iso),maxnloc*8,  MPI_DOUBLE_COMPLEX,i,comm_f08, mpinfo)
      call MPI_BCAST(nloc_p_pot%cc(1,iso),2,  MPI_DOUBLE_PRECISION,i,comm_f08, mpinfo)
      call MPI_BCAST(nloc_p_pot%dv_so(1,1,1,iso),maxnloc*24,  MPI_DOUBLE_COMPLEX,i,comm_f08, mpinfo)
      call MPI_BCAST(nloc_p_pot%dv_ion(1,1,1,iso),maxnloc*24, MPI_DOUBLE_COMPLEX,i,comm_f08, mpinfo)
enddo
#endif





!
!  -------- Transformation of the non local arrays -------------
!  Transform the global "non-local" arrays into arrays containing
!  information about the local rows of the processor.i.e.,
!  For all atoms on my processor:
!  a) all rows of Anloc that are not my rows are removed.
!  b) my rows are shifted in adjacent positions.
!  c) indw is changed to include only the above local information
!     The offset is subtracted to yield the local row locations
!  d) nlatom contains the number of my rows in Anloc
!  e) nlmatm is the same since it does not depend on rows:
!
call mysecond(trearrange0)

if (ipr >= 0) then
        write(9,*) 'Number of atoms with non local points - ', &
                nloc_p_pot%atom_num
endif

ioffset = parallel%irows(parallel%colgroup_iam) - 1
icount = 0
itot = 0
iso = 0
ilm = 0

do ja = 1, nloc_p_pot%atom_num
        if(nloc_p_pot%so(ja)) iso = iso + 1

        !  ..for all atoms
        icur = 0
        nloc = nloc_p_pot%nlatom(ja)

        do i = 1, nloc
                !  ..for each row in Anloc
                irow = nloc_p_pot%indw(i,ja)
                itran = nloc_p_pot%tran(i,ja)

                if (parallel%irows(parallel%colgroup_iam) <= irow .and. &
                        irow < parallel%irows(parallel%colgroup_iam+1)) then

                        !  ..if irow on my processor shift it up
                        icur = icur + 1

                        do lm = 1, nloc_p_pot%nlmatm(ja)
                                nloc_p_pot%anloc(icur,ilm+lm) = &
                                        nloc_p_pot%anloc(i,ilm+lm)
                                nloc_p_pot%vylmd(:,icur,ilm+lm) = &
                                        nloc_p_pot%vylmd(:,i,ilm+lm)
                        enddo

                        do lm = 1, 8
                                if (nloc_p_pot%so(ja)) then
                                        nloc_p_pot%v_so(icur,lm,iso) = &
                                                nloc_p_pot%v_so(i,lm,iso)
                                        nloc_p_pot%v_ion(icur,lm,iso) = &
                                                nloc_p_pot%v_ion(i,lm,iso)
                                        nloc_p_pot%dv_so(:,icur,lm,iso) = &
                                                nloc_p_pot%dv_so(:,i,lm,iso)
                                        nloc_p_pot%dv_ion(:,icur,lm,iso) = &
                                                nloc_p_pot%dv_ion(:,i,lm,iso)
                                endif
                        enddo

                        if (pbc%nkpt > 0) then
                                nloc_p_pot%right(icur,:,ja) = nloc_p_pot%right(i,:,ja)
                                nloc_p_pot%left(icur,:,ja) = nloc_p_pot%left(i,:,ja)
                        endif

                        nloc_p_pot%indw(icur,ja) = irow - ioffset
                        nloc_p_pot%tran(icur,ja) = itran
                endif
        enddo

        ilm = ilm + nloc_p_pot%nlmatm(ja)
        !  ..new number of rows in Anloc for this atom.
        nloc_p_pot%nlatom(ja) = icur
        icount = icount + icur
        itot   = itot + nloc
enddo

if (ipr >=0) then
        write(9,*) 'My number of non-local rows: ', icount, ' of total ', itot
endif

call mysecond(trearrange1)




   !
   ! do the same to Wigner-Seitz spheres ...
   !
   ! AJB: BUT ONLY IF YOU NEED THEM?
   wsicount = 0
   wsitot = 0
   do ja = 1, nloc_p_pot%atom_num
      wsicur = 0
      wsnloc = nloc_p_pot%wsnlatom(ja)
      do i = 1, wsnloc
         !  ..for each row
         wsirow = nloc_p_pot%wsindw(i,ja)
         wsitran = nloc_p_pot%wstran(i,ja)
         if (parallel%irows(parallel%group_iam) <= wsirow .and. wsirow < &
            parallel%irows(parallel%group_iam+1)) then
            wsicur = wsicur + 1
            nloc_p_pot%wsindw(wsicur,ja) = wsirow - ioffset
            nloc_p_pot%wstran(wsicur,ja) = wsitran
         endif
      enddo
      nloc_p_pot%wsnlatom(ja) = wsicur
      wsicount = wsicount + wsicur
      wsitot   = wsitot + wsnloc
   enddo
   if (ipr >=0 ) then
   write(9,*) 'My number of rows in WS sphere: ',wsicount,' of total ',wsitot
   endif



! KHL: For now I put the initialization of nloc_p_pot%ilm_offset(:) here
ilm_offset = 0
do iatom = 1, nloc_p_pot%atom_num
        nloc_p_pot%ilm_offset(iatom) = ilm_offset
        ilm_offset = ilm_offset + nloc_p_pot%nlmatm(iatom)
enddo




call mysecond(time1)

if (ipr >= 0) then
        write(9,*) ""
        write(9,*) "Finished nonloc. Timing report:"
        write(9,*) ""
        write(9,1001) tfind_nlnum1-tfind_nlnum0
        write(9,1002) tgetpoints1-tgetpoints0
        write(9,1003) tgetpots1-tgetpots0
        write(9,1004) trearrange1-trearrange0
        write(9,*) '-----------------------'
        write(9,1005) time1-time0
        write(9,*) ''

        call myflush(9)
endif




1001 format('  NONLOC:GTNUM [sec]:',1x,f10.2)
1002 format('  NONLOC:GTPNT [sec]:',1x,f10.2)
1003 format('  NONLOC:GTPOT [sec]:',1x,f10.2)
1004 format('  NONLOC:TRIMP [sec]:',1x,f10.2)
1005 format('  NONLOC:TOTAL [sec]:',1x,f10.2)

end subroutine nonloc
end module nonloc_module
