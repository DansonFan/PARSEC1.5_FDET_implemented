module pbe_module
  use constants
   contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
! This is a slightly modified version of EASYPBE, a driver for
! the PBE subroutines, using simple inputs.
! author: K. Burke, May 14, 1996.
! Subroutines upgraded to the fortran 95 standard by M. Tiago,
! February 19, 2005.
!
!===============================================================
!
!spin-unpolarized functional, for pb and pw
!
!---------------------------------------------------------------

subroutine pbe(icorr,rho,agr,delgr,lap,ex,vx,ec,vc)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  character (len=2), intent(in) :: icorr
  real(dp), intent(in) :: &
       rho, &                 ! density
       agr, &                 ! |grad rho|
       delgr, &               ! (grad up).(grad |grad up|)
       lap                    ! grad^2 up=Laplacian of up
  real(dp), intent(out) :: &
       ex,vx,ec,vc
  ! Work variables:
  !
  real(dp) :: ecrs,eczet,fk,g,h, &
       rs,s,sk,twoksg,t,u,uu,vv,v,ww,zet
  real(dp) :: vc1(2),dvc(2)
  !

  ! constants: pi32=3 pi**2, alpha=(9pi/4)**thrd
  !
  real(dp), parameter :: thrd2 = two*third
  real(dp), parameter :: pi32 = three*pi*pi
  real(dp), parameter :: alpha = 1.91915829267751300662482032624669d0

  !---------------------------------------------------------------
  !
  if(rho < 1.d-18) then
     ex = zero
     vx = zero
     ec = zero
     vc = zero
     return
  end if   
  fk=(pi32*rho)**third 
  s=agr/(two*fk*rho)
  u=delgr/(rho*rho*(two*fk)**3)
  v=lap/(rho*(two*fk)**2)
  if (icorr == 'pb') then
     call exchpbe(rho,s,u,v,ex,vx)
  else
     call exchpw91(rho,s,two*u,v,ex,vx)
  endif

  !corelation
  zet=zero
  g=one
  rs=calc_rs(rho)
  sk=sqrt(four*fk/pi)
  twoksg=two*sk*g
  t=calc_t(agr,rho,g)
  uu=delgr/(rho*rho*twoksg**3)
  vv=lap/(rho*twoksg**2)
  ww=zero
  call corlsd(rs,zet,ec,vc1,ecrs,eczet)
  if (icorr == 'pb') then
     call corpbe (rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)
  else
     call corpw91(rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)
  endif
  ec=ec+h
  vc = vc1(1) + vc1(2) + dvc(1) + dvc(2)

end subroutine pbe
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
! This is a slightly modified version of EASYPBE, a driver for
! the PBE subroutines, using simple inputs.
! author: K. Burke, May 14, 1996.
! Subroutines upgraded to the fortran 95 standard by M. Tiago,
! February 19, 2005.
!
!---------------------------------------------------------------
 subroutine spn_pbe(nspin,icorr,rh,agr,delgr,lap, &
     tot_agr,tot_delgr,ex,vx,ec,vc)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  integer, intent(in) :: nspin  ! number of spin channels
  character (len=2), intent(in) :: icorr
    real(dp), intent(in) :: &
       rh(nspin), &            ! density
       agr(nspin), &           ! |grad up|
       delgr(nspin), &         ! (grad up).(grad |grad up|)
       lap(nspin), &           ! grad^2 up=Laplacian of up
       tot_agr, &              ! |grad rho|                  ! only for nspin == 2
       tot_delgr               ! (grad rho).(grad |grad rho|)! only for nspin ==2
  real(dp), intent(out) :: &
       ex(nspin), &               ! exchange energy density,
       vx(nspin), &        !exchange potential
       ec, &               ! correlation energy density
       vc(2)         ! correlation potential
  !
  ! Work variables:
  !
  ! scaling factor for exchange
  real(dp) :: fac
  !
  ! exchange
  real(dp) :: rho,fk,s,u,v
  ! correlation lsd
  real(dp) :: rs,zet,ecrs,eczet
  ! correlation gga
  real(dp) :: g,h,rholap, &
       sk,twoksg,t,uu,vv,ww
  real(dp) :: dvc(2)
  !counters
  integer  :: isp
  ! constants: pi32=3 pi**2, alpha=(9pi/4)**thrd
  !
  real(dp), parameter :: thrd2 = two*third
  real(dp), parameter :: pi32 = three*pi*pi
  real(dp), parameter :: alpha = 1.91915829267751300662482032624669d0

  !---------------------------------------------------------------
  !
  ! PBE exchange
  ! use  Ex[up,dn]=0.5*(Ex[2*up]+Ex[2*dn]) (i.e., exact spin-scaling)
  ! do up exchange
  ! fk=local Fermi wavevector for 2*up=(3 pi^2 (2up))^(1/3)
  ! s=dimensionless density gradient=|grad rho|/ (2*fk*rho)_(rho=2*up)
  ! u=delgrad/(rho^2*(2*fk)**3)_(rho=2*up) 
  ! v=Laplacian/(rho*(2*fk)**2)_(rho=2*up) 

  !scale for exchange
  
  fac = nspin
  
  do isp = 1, nspin 
     rho=fac*rh(isp) 
     if(rho > 1d-18)then
        fk = calc_fk(rho)
        s = fac*agr(isp)/(two*fk*rho)
        u = fac*two*delgr(isp)/(rho*rho*(two*fk)**3)
        v = fac*lap(isp)/(rho*(two*fk)**2)
        if (icorr == 'pb') then
           call exchpbe (rho,s,u,v,ex(isp),vx(isp))
        else !(icorr == 'pw')
           call exchpw91(rho,s,u,v,ex(isp),vx(isp))
        endif
     else
        ex(isp)=zero
        vx(isp)=zero
     endif
  enddo
  !
  ! Now do correlation 
  ! zet=(up-dn)/rho 
  ! g=phi(zeta) 
  ! rs=(3/(4pi*rho))^(1/3)=local Seitz radius=alpha/fk 
  ! sk=Ks=Thomas-Fermi screening wavevector=sqrt(4fk/pi) 
  ! twoksg=2*Ks*phi 
  ! t=correlation dimensionless gradient=|grad rho|/(2*Ks*phi*rho) 
  ! uu=delgrad/(rho^2*twoksg^3) 
  ! rholap=Laplacian 
  ! vv=Laplacian/(rho*twoksg^2) 
  ! ww=(|grad up|^2-|grad dn|^2-zet*|grad rho|^2)/(rho*twoksg)^2 
  ! ec=LSD correlation energy 
  ! vc=LSD 2 channal correlation potential 
  ! h=gradient correction to correlation energy 
  ! dvc=gradient correction to 2 channal correlation potential 
  !

  ! prepare the variables for correlation
  rho = sum(rh)
  if (rho < 1.d-18) return

 
  zet = (rh(1) - rh(2))/rho
  g = ((one+zet)**thrd2 + (one-zet)**thrd2)/two
  rholap = sum(lap)

  fk = calc_fk(rho)
  rs = calc_rs(rho)
  sk = sqrt(four*fk/pi)
  twoksg = two*sk*g
  t  = calc_t(tot_agr,rho,g)
  uu = tot_delgr/(rho*rho*twoksg**3)
  vv = rholap/(rho*twoksg**2)
  if (nspin == 2)then
     ww = (agr(1)**2-agr(2)**2-zet*tot_agr**2)/(rho*rho*twoksg**2)
  endif

  ! correlation is done combined for all channels
  ! lsd correlation
  call corlsd(rs,zet,ec,vc,ecrs,eczet)
  
  ! gga correlation
  if (icorr == 'pb')then
     call corpbe (rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)
  else !(icorr = 'pw')
     call corpw91(rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)
  endif

  ! sum the lsd and gga correlation energy
  ec = ec + h

  ! sum the lsd and gga correlation potential
  do isp = 1,2
     vc(isp) = vc(isp) + dvc(isp)
  enddo


end subroutine spn_pbe
!===============================================================
!
! PBE exchange 
! K Burke's modification of PW91 codes, May 14, 1996
! Modified again by K. Burke, June 29, 1996, with simpler Fx(s)
!
! References:
! [a]J.P.~Perdew, K.~Burke, and M.~Ernzerhof, PRL 77, 3865 (1996);
! [b]J.P. Perdew and Y. Wang, Phys. Rev.  B 33,  8800(1986);
! 40,  3399  (1989) (E).
!
! Formulas:
!      e_x[unif]=ax*rho^(4/3)  [LDA]
!      ax = -0.75*(3/pi)^(1/3)
!      e_x[PBE]=e_x[unif]*FxPBE(s)
!      FxPBE(s)=1+uk-uk/(1+ul*s*s)                 [a](13)
! uk, ul defined after [a](13) 
!
! for u,v, see PW86(24)
!
!---------------------------------------------------------------
subroutine exchpbe(rho,s,u,v,ex,vx)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       rho, &  ! density
       s, &    ! ABS(GRAD rho)/(2*KF*rho), where kf=(3 pi^2 rho)^(1/3)
       u, &    ! (GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*kf)**3)
       v       ! (LAPLACIAN rho)/(rho*(2*kf)**2)

  real(dp), intent(out) :: &
       ex, &   ! exchange energy per electron
       vx      ! potential
  !
  ! Work variables:
  !
  real(dp) :: exunif,fs,fss,fxpbe,p0,s2

  real(dp), parameter :: thrd4=four/three
  real(dp), parameter :: ax=-0.738558766382022405884230032680836d0
  real(dp), parameter :: um=0.2195149727645171d0
  real(dp), parameter :: uk=0.8040d0
  real(dp), parameter :: ul=um/uk
  !---------------------------------------------------------------
  !
  ! construct lda exchange energy density
  call exchlsd(rho,exunif,vx)
  !
  ! construct PBE enhancement factor
  s2 = s*s
  p0 = one + ul*s2
  fxpbe = one+uk-uk/p0
  ex = exunif*fxpbe
  !
  ! energy done. now the potential:
  ! find first and second derivatives of fx w.r.t s.
  !      fs=(1/s)*d fxpbe/ ds
  !      fss=d fs/ds
  !
  fs=two*uk*ul/(p0*p0)
  fss=-four*ul*s*fs/p0
  !
  ! calculate potential from [b](24) 
  vx = vx*fxpbe-exunif*((u-thrd4*s2*s)*fss+v*fs)
end subroutine exchpbe
!===============================================================
!
! Official PBE correlation code. K. Burke, May 14, 1996. 
!
! References: 
!   [a] J.P.~Perdew, K.~Burke, and M.~Ernzerhof, PRL 77, 3865 (1996)
!   [b] J. P. Perdew, K. Burke, and Y. Wang, {\sl Real-space cutoff 
!       construction of a generalized gradient approximation:  The PW91 
!       density functional}, submitted to Phys. Rev. B, Feb. 1996. 
!   [c] J. P. Perdew and Y. Wang, Phys. Rev. B {45, 13244 (1992). 
!
!---------------------------------------------------------------
subroutine corpbe(rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)
  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       rs, &    ! Seitz radius=(3/4pi rho)^(1/3)
       zet, &   ! relative spin polarization = (rhoup-rhodn)/rho
       g, &     !
       t, &     ! ABS(GRAD rho)/(rho*2.*KS*G)  -- only needed for PBE
       uu, &    ! (GRAD rho)*GRAD(ABS(GRAD rho))/(rho**2 * (2*KS*G)**3)
       vv, &    ! (LAPLACIAN rho)/(rho * (2*KS*G)**2)
       ww       ! (GRAD rho)*(GRAD ZET)/(rho * (2*KS*G)**2 
                ! uu,vv,ww, only needed for PBE potential
  real(dp), intent(in) :: & !everything calculatedin corlsd
       ec, &    ! LSD correlation energy from [a]
       ecrs,eczet
       
  real(dp), intent(out) :: &
       h, &     ! nonlocal part of correlation energy per electron
       dvc(2)   ! nonlocal correction to vc
      
  ! Work variables:
  !
  ! thrd*=various multiples of 1/3 
  ! numbers for use in LSD energy spin-interpolation formula, [c](9). 
  !        GAM= 2^(4/3)-2 
  !        FZZ=f''(0)= 8/(9*GAM) 
  ! numbers for construction of PBE 
  !        gamma=(1-log(2))/pi^2 
  !        bet=coefficient in gradient expansion for correlation, [a](4). 
  !        eta=small number to stop d phi/ dzeta from blowing up at 
  !            |zeta|=1. 
  !
  real(dp) :: b,b2,bec,bg,comm, &
       fac,fact0,fact1,fact2,fact3,fact5, &
       g3,g4,q5,gz,hb,hbt,hrs,hrst,ht,htt,hz,hzt,pon,pref, &
       q4,q8,q9,rsthrd,t2,t4,t6,rs2,rs3

  real(dp), parameter :: thrdm=-third
  real(dp), parameter :: thrd2=two*third
  real(dp), parameter :: sixthm=thrdm/two
  real(dp), parameter :: thrd4=four*third
  real(dp), parameter :: gam = 0.5198420997897463295344212145565d0
  real(dp), parameter :: fzz=8.d0/(9.d0*GAM)
  real(dp), parameter :: gamma = 0.03109069086965489503494086371273d0
  real(dp), parameter :: bet=0.06672455060314922d0
  real(dp), parameter :: delt=bet/gamma
  real(dp), parameter :: eta=1.d-12
  !---------------------------------------------------------------
  ! start with the lsd ec and vc

  ! PBE correlation energy 
  !     g=phi(zeta), given after [a](3) 
  !     delt=bet/gamma 
  !     b=a of [a](8)
  !
  !g=((one+zet)**thrd2+(one-zet)**thrd2)/two
  g3 = g**3
  pon=-ec/(g3*gamma)
  b = delt/(exp(pon)-one)
  b2 = b*b
  t2 = t*t
  t4 = t2*t2
  rs2 = rs*rs
  rs3 = rs2*rs
  q4 = one+b*t2
  q5 = one+b*t2+b2*t4
  h = g3*(bet/delt)*log(one+delt*q4*t2/q5)

  ! energy done. now the potential, using appendix E of [b]. 
  g4 = g3*g
  t6 = t4*t2
  rsthrd = rs/three
  gz=(((one+zet)**2+eta)**sixthm-((one-zet)**2+eta)**sixthm)/three
  fac = delt/b+one
  bg = -three*b2*ec*fac/(bet*g4)
  bec = b2*fac/(bet*g3)
  q8 = q5*q5+delt*q4*q5*t2
  q9 = one+two*b*t2
  hb = -bet*g3*b*t6*(two+b*t2)/q8
  hrs = -rsthrd*hb*bec*ecrs
  fact0 = two*delt-6.d0*b
  fact1 = q5*q9+q4*q9*q9
  hbt = two*bet*g3*t4*((q4*q5*fact0-delt*fact1)/q8)/q8
  hrst = rsthrd*t2*hbt*bec*ecrs
  hz = three*gz*h/g + hb*(bg*gz+bec*eczet)
  ht = two*bet*g3*q9/q8
  hzt = three*gz*ht/g+hbt*(bg*gz+bec*eczet)
  fact2 = q4*q5+b*t2*(q4*q9+q5)
  fact3 = two*b*q5*q9+delt*fact2
  htt = four*bet*g3*t*(two*b/q8-(q9*fact3/q8)/q8)
  comm = h+hrs+hrst+t2*ht/6.d0+7.d0*t2*t*htt/6.d0
  pref = hz-gz*t2*ht/g
  fact5 = gz*(two*ht+t*htt)/g
  comm = comm-pref*zet-uu*htt-vv*ht-ww*(hzt-fact5)
  dvc(1) = comm + pref 
  dvc(2) = comm - pref
  ! in single spin channel pref gets canceled out
  
end subroutine corpbe
!===============================================================
!
! uniform-gas correlation of Perdew and Wang 1991 
!
!---------------------------------------------------------------
subroutine corlsd(rs,zet,ec,vc,ecrs,eczet) 

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       zet, &        ! relative spin polarization
       rs            ! Seitz radius
  real(dp), intent(out) :: &
       ec, &         ! correlation energy per electron
       vc(2)  ! up- and down-spin potentials
  real(dp), intent(out) :: & ! things used for gga
       ecrs,&       ! derivative of ec w.r.t. rs
       eczet      ! derivative of ec w.r.t. zet

  ! Work variables:
  !
  !real(dp)
  real(dp) :: alfm,alfrsm,comm,ep,eprs,eu,eurs,f,z4,fz

  real(dp), parameter :: gam=0.5198421d0
  real(dp), parameter :: fzz=1.709921d0
  real(dp), parameter :: thrd4=four/three
  !---------------------------------------------------------------
    !
  ! find LSD energy contributions, using [c](10) and Table I[c]. 
  !   eu=unpolarized LSD correlation energy 
  !   eurs=deu/drs 
  !   ep=fully polarized LSD correlation energy 
  !   eprs=dep/drs 
  !   alfm=-spin stiffness, [c](3). 
  !   alfrsm=-dalpha/drs 
  !   f=spin-scaling factor from [c](9). 
  ! construct ec, using [c](8) 
  !
  call gcor(0.0310907d0,0.21370d0,7.5957d0,3.5876d0,1.6382d0, &
       0.49294d0,rs,eu,eurs)
  call gcor(0.01554535d0,0.20548d0,14.1189d0,6.1977d0,3.3662d0,&
       0.62517d0,rs,ep,eprs)
  call gcor(0.0168869d0,0.11125d0,10.357d0,3.6231d0,0.88026d0, &
       0.49671d0,rs,alfm,alfrsm)
  ! alfm is minus the spin stiffness alfc 
  !alfc = -alfm
  z4 = zet**4
  f = ((one+zet)**thrd4+(one-zet)**thrd4-two)/gam !nspin = 1 -> f = zero
  ec = eu*(one-f*z4)+ep*f*z4-alfm*f*(one-z4)/fzz !nspin = 1 -> ec = eu
  !  !
  ! LSD potential from [c](a1) 
  !      ecrs = dec/drs [c](a2) 
  !      eczet=dec/dzeta [c](a3) 
  !      fz = df/dzeta [c](a4) 

  ecrs = eurs*(one-f*z4)+eprs*f*z4-alfrsm*f*(one-z4)/fzz !nspin = 1 -> ecrs = eurs
  fz = thrd4*((one+zet)**third-(one-zet)**third)/gam
  eczet = four*(zet**3)*f*(ep-eu+alfm/fzz)+fz*(z4*ep-z4*eu &
       -(one-z4)*alfm/fzz) !nspin = 1 -> eczet = 0
  comm = ec - rs*ecrs/three - zet*eczet ! nspin = 1 -> vc = comm = ec -rs*ecrs/three
  vc(1) = comm + eczet
  vc(2) = comm - eczet
  
end subroutine corlsd
!===============================================================
!
! gga91 exchange for a spin-unpolarized electronic system 
!
!---------------------------------------------------------------
subroutine exchpw91(d,s,u,v,ex,vx) 

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       d, &    ! density
       s, &    ! ABS(GRAD d)/(2*kf*d)
       u, &    ! (GRAD d)*GRAD(ABS(GRAD d))/(d**2 * (2*kf)**3)
       v       ! (LAPLACIAN d)/(d*(2*kf)**2)

  real(dp), intent(out) :: &
       ex, &   ! exchange energy per electron
       vx      ! potential
  !
  ! Work variables:
  !
  real(dp) :: f,fac,fs,fss, &
       p0,p1,p2,p3,p4,p5,p6,p7,p8,p9,p10,p11,s2,s3,s4

  real(dp), parameter :: a1=0.19645d0
  real(dp), parameter :: a2=0.27430d0
  real(dp), parameter :: a3=0.15084d0
  real(dp), parameter :: a4=100.d0
  real(dp), parameter :: ax=-0.738558766382022405884230032680836d0
  real(dp), parameter :: a=7.7956d0
  real(dp), parameter :: b1=0.004d0
  real(dp), parameter :: thrd4 = four/three
  !---------------------------------------------------------------
  ! for Becke exchange, set a3=b1=0
  fac = ax*d**third
  s2 = s*s
  s3 = s2*s
  s4 = s2*s2
  p0 = one/sqrt(one+a*a*s2)
  p1 = log(a*s+one/p0)
  p2 = exp(-a4*s2)
  p3 = one/(one+a1*s*p1+b1*s4)
  p4 = one+a1*s*p1+(a2-a3*p2)*s2
  f = p3*p4
  ex = fac*f
  ! local exchange option 
!  ex = fac 
  ! energy done. now the potential: 
  p5 = b1*s2-(a2-a3*p2)
  p6 = a1*s*(p1+a*s*p0)
  p7 = two*(a2-a3*p2)+two*a3*a4*s2*p2-four*b1*s2*f
  fs = p3*(p3*p5*p6+p7)
  p8 = two*s*(b1-a3*a4*p2)
  p9 = a1*p1+a*a1*s*p0*(three-a*a*s2*p0*p0)
  p10 = four*a3*a4*s*p2*(two-a4*s2)-8.d0*b1*s*f-four*b1*s3*fs
  p11 = -p3*p3*(a1*p1+a*a1*s*p0+four*b1*s3)
  fss = p3*p3*(p5*p9+p6*p8)+two*p3*p5*p6*p11+p3*p10+p7*p11
  vx = fac*(thrd4*f-(u-thrd4*s3)*fss-v*fs)
  ! local exchange option: 
!  vx = fac*thrd4 

end subroutine exchpw91
!===============================================================
!
! PW91 correlation, modified by K. Burke to put all arguments 
! as variables in calling statement, rather than in common block 
! May, 1996. 
!
!---------------------------------------------------------------
subroutine corpw91(rs,zet,g,ec,ecrs,eczet,t,uu,vv,ww,h,dvc)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       rs, &        ! Seitz radius
       zet, &       ! relative spin polarization
       t, &         ! ABS(GRAD d)/(d*2.*ks*g)
       uu, &        ! (GRAD d)*GRAD(ABS(GRAD d))/(d**2 * (2*ks*g)**3)
       vv, &        ! (LAPLACIAN d)/(d * (2*ks*g)**2)
       ww, &        ! (GRAD d)*(GRAD zet)/(d * (2*ks*g)**2
       g,ec,ecrs,eczet

  real(dp), intent(out) :: &
       h, &         ! nonlocal part of correlation energy per el.
       dvc(2)  ! nonlocal parts of correlation potentials
  !
  ! Work variables:
  !
  real(dp) :: b,b2,bec,bet,bg,cc,ccrs,coeff,comm,delt, &
       fac,fact0,fact1,fact2,fact3,fact4,fact5,g3,g4,gz,h0b,h0bt, &
       h0rs,h0rst,h0t,h0tt,h0z,h0zt,h1,h1rs,h1rst,h1t,h1tt,h1z,h1zt, &
       hrs,hrst,ht,htt,hz,hzt,pon,pref,rs2,rs3,q4,q5,q6,q7,q8,q9, &
       r0,r1,h0,r2,r3,r4,rsthrd,t2,t4,t6

  real(dp), parameter :: xnu=15.75592d0
  real(dp), parameter :: cc0=0.004235d0
  real(dp), parameter :: cx=-0.001667212d0
  real(dp), parameter :: alf=0.09d0
  real(dp), parameter :: c1=0.002568d0
  real(dp), parameter :: c2=0.023266d0
  real(dp), parameter :: c3=7.389d-6
  real(dp), parameter :: c4=8.723d0
  real(dp), parameter :: c5=0.472d0
  real(dp), parameter :: c6=7.389d-2
  real(dp), parameter :: a4=100.d0
  real(dp), parameter :: thrdm=-third
  real(dp), parameter :: thrd2=two/three
  !---------------------------------------------------------------
  bet = xnu*cc0
  delt = two*alf/bet
  g3 = g**3
  g4 = g3*g
  pon = -delt*ec/(g3*bet)
  b = delt/(exp(pon)-one)
  b2 = b*b
  t2 = t*t
  t4 = t2*t2
  t6 = t4*t2
  rs2 = rs*rs
  rs3 = rs2*rs
  q4 = one+b*t2
  q5 = one+b*t2+b2*t4
  q6 = c1+c2*rs+c3*rs2
  q7 = one+c4*rs+c5*rs2+c6*rs3
  cc = -cx + q6/q7
  r0 = 0.663436444d0*rs
  r1 = a4*r0*g4
  coeff = cc-cc0-three*cx/7.d0
  r2 = xnu*coeff*g3
  r3 = exp(-r1*t2)
  h0 = g3*(bet/delt)*log(one+delt*q4*t2/q5)
  h1 = r3*r2*t2
  h = h0+h1
  ! local correlation option: 
!  h = 0.0d0 
  ! energy done. now the potential: 
  ccrs = (c2+2.*c3*rs)/q7 - q6*(c4+2.*c5*rs+3.*c6*rs2)/q7**2
  rsthrd = rs/three
  r4 = rsthrd*ccrs/coeff
  gz = ((one+zet)**thrdm - (one-zet)**thrdm)/three
  fac = delt/b+one
  bg = -three*b2*ec*fac/(bet*g4)
  bec = b2*fac/(bet*g3)
  q8 = q5*q5+delt*q4*q5*t2
  q9 = one+two*b*t2
  h0b = -bet*g3*b*t6*(two+b*t2)/q8
  h0rs = -rsthrd*h0b*bec*ecrs
  fact0 = two*delt-6.d0*b
  fact1 = q5*q9+q4*q9*q9
  h0bt = two*bet*g3*t4*((q4*q5*fact0-delt*fact1)/q8)/q8
  h0rst = rsthrd*t2*h0bt*bec*ecrs
  h0z = three*gz*h0/g + h0b*(bg*gz+bec*eczet)
  h0t = two*bet*g3*q9/q8
  h0zt = three*gz*h0t/g+h0bt*(bg*gz+bec*eczet)
  fact2 = q4*q5+b*t2*(q4*q9+q5)
  fact3 = two*b*q5*q9+delt*fact2
  h0tt = four*bet*g3*t*(two*b/q8-(q9*fact3/q8)/q8)
  h1rs = r3*r2*t2*(-r4+r1*t2/three)
  fact4 = two-r1*t2
  h1rst = r3*r2*t2*(two*r4*(one-r1*t2)-thrd2*r1*t2*fact4)
  h1z = gz*r3*r2*t2*(three-four*r1*t2)/g
  h1t = two*r3*r2*(one-r1*t2)
  h1zt = two*gz*r3*r2*(three-11.d0*r1*t2+four*r1*r1*t4)/g
  h1tt = two*r3*r2*r1*t*(-two+r1*t2)
  hrs = h0rs+h1rs
  hrst = h0rst+h1rst
  ht = h0t+h1t
  htt = h0tt+h1tt
  hz = h0z+h1z
  hzt = h0zt+h1zt
  comm = h+hrs+hrst+t2*ht/6.d0+7.d0*t2*t*htt/6.d0
  pref = hz-gz*t2*ht/g
  fact5 = gz*(two*ht+t*htt)/g
  comm = comm-pref*zet-uu*htt-vv*ht-ww*(hzt-fact5)
  dvc(1) = comm + pref
  dvc(2) = comm - pref
  
end subroutine corpw91
!===============================================================
! TIAN revised new_exchpbe and new_corpbe
! Need to separate rho, agr, and grad if used for spin polarized case
!===============================================================
! This subroutine returns d(neF)/dn (1) and d(neF)/dgrad_rho (2)
! To get the nonlocal potential, need to subtract numerical divergence of (2) from (1)
! which should be calculated after calling this subroutine at each grid point
subroutine new_exchpbe(rho,abs_grad,grad_n,ex,dedn1,dedn2)

  use constants
  !use file_units, only : f_parsec
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: &
       rho, &       ! density
       abs_grad, &  ! ABS(GRAD_rho)
       grad_n(3)    ! GRAD_rho

  real(dp), intent(out) :: &
       ex, &        ! exchange energy per electron
       dedn1, &     ! (1)
       dedn2(3)     ! (2)
  !
  ! Work variables:
  !

  ! lda energy, potential
  real(dp) :: exunif,vx
  ! temporary used for energy
  real(dp) ::p0,fxpbe,s,s2
  ! temporary for potetnial
  real(dp) :: ndedn,dfds,ndfdn

  real(dp), parameter :: thrd4=four/three
  real(dp), parameter :: ax=-0.738558766382022405884230032680836d0
  real(dp), parameter :: um=0.2195149727645171d0
  real(dp), parameter :: uk=0.8040d0
  real(dp), parameter :: ul=um/uk
  !---------------------------------------------------------------
  !
  ! construct lda exchange energy density
  !  make sure rho is scaled:
  call exchlsd(rho,exunif,vx)

  ! construct PBE enhancement factor
  s = calc_s(rho,abs_grad)
  s2 = s*s
  p0=one+ul*s2
  fxpbe = one+uk-uk/p0
  ex = exunif*fxpbe
  !
  ! energy done. now the potential:
  ndedn = exunif/three
   dfds = two*uk*uk*um*s/(uk+um*s2)**2
  ndfdn = -dfds*thrd4*s
  dedn1 = ex+ndedn*fxpbe+exunif*ndfdn
  dedn2 = rho*exunif*dfds*s/abs_grad**2 * grad_n
  if (abs_grad <1.d-18) then
     dedn2 = zero
  end if
end subroutine new_exchpbe

!===============================================================
! TIAN revised pbe for real space calculation
! This subroutine returns H+rho*dHdrho (1) and rho*dHdt*t/|grad_rho|^2*grad_rho (2)
! To get the nonlocal potential, need to subtract numerical divergence of (2) from (1)
! which should be calculated after calling this subroutine at each grid point
! better to make grad_rho an input
subroutine new_corpbe(nspin,rho,zet,g,t,grad,abs_grad,ec,vc,h,dfdrho1,dfdrho2)

  use constants
  !use file_units, only : f_parsec
  implicit none
  !
  ! Input/Output variables:
  !
  integer, intent(in) :: nspin
  real(dp), intent(in) :: &
       rho, &      ! sum density 
       zet, &      ! relative spin polarization = (rhoup-rhodn)/rho
       t, &        ! ABS(GRAD rho)/(rho*2.*ks*g)  -- only needed for PBE
       grad(3,nspin), &  ! gradient of rho ! or 1 for nspin == 1
       abs_grad(nspin),& ! |grad_rho|
       g,&
       ec,vc(2) ! outputs of corlsd
  real(dp), intent(out) :: &
       h, &        ! nonlocal part of correlation energy per electron
       dfdrho1(2), &
       dfdrho2(3,nspin)
  !
  ! Work variables:
  !
  real(dp) :: b,gz,pon,q0,q4,q5,w0
  ! b,g,t powers
  real(dp) :: b2,g3,g4,t2,t3,t4

  real(dp) :: dwda,dadg,dhda,dhdg,dhdz,dade,dhde,dwdt,dhdt 
  !counter
  integer :: isp

  ! numbers for construction of PBE
  !    gamma=(1-log(2))/pi^2
  !    bet=coefficient in gradient expansion for correlation, [a](4).
  !    eta=small number to stop d phi/ dzeta from blowing up at 
  !        |zeta|=1.
  !
  real(dp), parameter :: thrdm=-third
  real(dp), parameter :: sixthm=thrdm/two
  real(dp), parameter :: gamma=0.03109069086965489503494086371273d0
  real(dp), parameter :: bet=0.06672455060314922d0
  real(dp), parameter :: delt=bet/gamma
  real(dp), parameter :: eta=1.d-12
  !---------------------------------------------------------------
  !corlsd happens before
  !
  ! PBE correlation energy
  !     g=phi(zeta), given after [a](3)
  !     delt=bet/gamma
  !     b=a of [a](8)
  !
  ! this used to happen in pbe

  
  g3 = g**3
  pon=-ec/(g3*gamma)
  b = delt/(exp(pon)-one)
  b2 = b*b
  t2 = t*t
  t4 = t2*t2
  q4 = one+b*t2
  q5 = one+b*t2+b2*t4
  w0 = one+delt*q4*t2/q5
  h = g3*(bet/delt)*log(w0)
  ! till this line identical to spn_pbe, combine? or get_h subroutine
  !
  ! energy done. now the potential
  !
  ! calculate each term in dhdrho
  q0 = 2+b*t2
  dwda = -delt*t2*b*t4*q0/q5**2
  g4 = g3*g
  dadg = -three*b2*ec*exp(pon)/(bet*g4)
  dhda = gamma*g3*dwda/w0
  dhdg = three*h/g + dhda*dadg
  gz = (((one+zet)*(one+zet)+eta)**sixthm-((one-zet)*(one-zet)+eta)**sixthm)/three
  dhdz = dhdg*gz

  dade = b2*exp(pon)/(bet*g3)
  dhde = dhda*dade

  t3 = t2*t
  dwdt = two*delt*t*q4/q5-delt*t2*two*b2*t3*q0/q5**2
  dhdt = gamma*g3*dwdt/w0
  !
  !
  ! construct (1) and (2)
  dfdrho1(1) = h + ((zet-one)*(-dhdz+dhdt*t*gz/g)-seven/six*t*dhdt+dhde*(vc(1)-ec))
  dfdrho1(2) = h + ((zet+one)*(-dhdz+dhdt*t*gz/g)-seven/six*t*dhdt+dhde*(vc(2)-ec))
 
 ! grad_rho should be an input, dfdrho2 are vectors 
  do isp = 1,nspin
     dfdrho2(:,isp) = rho*dhdt*t*grad(:,isp)/abs_grad(isp)**2  
     ! patch for atom center singularity
     ! needed only in the non spin polarized case
     if (abs_grad(isp) <1.d-18) then
        dfdrho2 = zero
     end if
  enddo

end subroutine new_corpbe


!---------------------------------------------------------------
!
! Slimmed down version of gcor used in PW91 routines, to
! interpolate LSD correlation energy, as given by (10) of
! J. P. Perdew and Y. Wang, Phys. Rev. B 45, 13244 (1992).
! K. Burke, May 11, 1996.
!
!---------------------------------------------------------------
subroutine gcor(a,a1,b1,b2,b3,b4,rs,gg,ggrs)

  use constants
  implicit none
  !
  ! Input/Output variables:
  !
  real(dp), intent(in) :: a,a1,b1,b2,b3,b4,rs

  real(dp), intent(out) :: gg,ggrs
  !
  ! Work variables:
  !
  real(dp) :: rtrs,q0,q1,q2,q3
  !---------------------------------------------------------------
  rtrs = sqrt(rs)
  q0 = -two*a*(one+a1*rs)
  q1 = two*a*(b1*rtrs+b2*rs+b3*rs*rtrs+b4*rs*rs)
  q2 = log(one+one/q1)
  gg = q0*q2
  q3 = a*(b1/rtrs+two*b2+three*b3*rtrs+four*b4*rs)
  ggrs = -two*a*a1*q2-q0*q3/(q1*(one+q1))

end subroutine gcor



!==================================================
  !  local exchange subroutine
  ! ex = ax*(2*rho)^1/3
  ! vx = 4/3 * ex 
subroutine exchlsd(rho,ex,vx)
  implicit none
  !input/output variables
  real(dp), intent(in) :: rho ! density: scaled 
  real(dp), intent(out):: ex,vx ! exchange energy, potential

  ! work
  real(dp), parameter :: thrd4 = four/three
  real(dp), parameter :: ax = -0.738558766382022405884230032680836d0

  ex = ax*rho**third
  vx = ex*thrd4
  !always scaled in main as: ex = ex *rho

end subroutine exchlsd

!==================================================
! short calculation functions, 
! can add more short calculation function for (zet, g, etc...)



! calculates s dimensionless density gradient
! s = |grad rho|/ (2*fk*rho)
function calc_s(rho,agr) result(s)
  ! rho and agr are scaled x2 for every spin channel
  real(dp), intent(in) :: rho ! density
  real(dp), intent(in) :: agr ! abs_grad
  real(dp)             :: s   ! output
  !work
  real(dp) :: fk
  
  fk = calc_fk(rho)
  s=agr/(two*fk*rho)
end function calc_s



! calculates fk local Fermi wavevector 
! fk = (3 pi^2 (rho))^(1/3)  
function calc_fk(rho) result(fk)
  ! rho is scaled x2 for every spin channel
  ! or sum of both channels
  real(dp), intent(in) :: rho ! density
  real(dp) :: fk !output
  ! work variables
  real(dp), parameter :: pi32 = three*pi*pi
 
  fk=(pi32*rho)**third  
end function calc_fk



! calculates rs local Seitz radius
! rs = (3/(4pi*rho))^(1/3) = alpha/fk
function calc_rs(rho) result(rs)
  ! rho is sum of rho in all channels
  real(dp), intent(in) :: rho ! density
  real(dp) :: rs !output
  ! work variables
  real(dp), parameter :: p75vpi = three/(four * pi)

  rs=(p75vpi/rho)**third
end function calc_rs



! calculates t correlation dimensionless gradient
! t = |grad rho|/(2*Ks*phi*rho)
function calc_t(agr,rho,g) result(t)
  ! rho and agr or sum of both channel
  real(dp), intent(in) :: rho ! density
  real(dp), intent(in) :: agr ! abs_grad
  real(dp), intent(in) :: g ! 
  
  real(dp)             :: t   ! output
  !work
  real(dp) :: fk,sk,twoksg

  fk = calc_fk(rho)
  sk=sqrt(four*fk/pi)
  twoksg=two*sk*g
  t=agr/(twoksg*rho)  
end function calc_t
           

!===============================================================
end module pbe_module
