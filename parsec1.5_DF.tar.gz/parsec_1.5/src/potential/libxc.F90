module libxc_module

implicit none
contains

!================================================================
!> this subroutine uses the libxc interface to compute the 
! exchange correlation potential, Vxc, and the exchange 
! correlation energy, Exc, both in Rydbergs,
! based on an input charge density given in e/(bohr^3).
!
! the exchange correlation functional is recognized by 
! the func_id given as input.
! 
! NOTE: Extra factor of two in formulas is due to conversion from
! Hartree (libxc output) to Rydberg!
!
! gga uses everything in lda and adds on,
! mgga uses everyrhing in gga and adds on
!
! auther: Deena Roller
! date: April 2019
!============================================================
#ifdef USE_LIBXC
subroutine libxc(grid, parallel, nrep, nspin, func_id, &
        vxc, wvec, exc, elec_st)

use xc_f03_lib_m
use grid_module
use parallel_data_module
use psum_module

!gga 
use gradmvs_module
use laplacian_ops_module, only : laplacian_fold, my_laplacian
use dbuffer_module
use stencil_things  

!mgga
use electronic_struct_module



implicit none

! Input/Output variables:

! grid related data
type(grid_data), intent(in) :: grid

! parallel computation related data
type(parallel_data), intent(in) :: parallel

!spin polarization
integer, intent(in) :: nspin

! order of the reduced group: need for weighing
integer, intent(in) :: nrep

!libxc functional id
integer, intent(in) :: func_id(2)

! input charge density, output exchange-correlation potential
real(dp) , intent(inout) :: vxc(parallel%mydim,nspin)

! work array
real(dp), intent(out) :: wvec(parallel%nwedge + 1)

! total exchange-correlation energy
real(dp), intent(out) :: exc

! mgga
! electronic structure holding the orbital related data
! nstates, occupations
type(electronic_struct), intent(in) :: elec_st



!work variables

! excl: exc per grid point
real(dp), dimension(:), allocatable :: excl 

! rho temporarily stores the charge 
real(dp), dimension(:,:), allocatable :: rho

! vxcl: vxc per grid point aldo vrho 
real(dp), dimension(:,:), allocatable :: vxcl

! GGA  work variables, consider seperating subroutines
! sigma contracted gradient of density
! size [3*ndim] for spin polarized [ndim] for unpolarized
! lapl_rho laplacian of density used to calculate divergence
! vsigma   dexc/dsigma column array
! vsl vsigma in row array  
real(dp), dimension(:,:), allocatable :: sigma, vsl, vsigma, lapl_rho

! grad_rho gradint of chrage density
! grad vsigma gradient of vsigma: used to calculate divergence
real(dp), dimension(:,:,:), allocatable :: grad_rho, grad_vsigma

! divergence of vsigma
real(dp) :: divsigma(nspin)

! communication buffer for lap/grad
type(lap_buffer) :: lap_buf
type(fold_buffer) :: fold_buf


! mGGA work variables
! lapl_rho_tr transpose of lapl_rho for libxc row input
! tau kinetic energy density
! vlapl dexc/dlapl_rho in row array
! vtl dexc/dtau in row array
real(dp), dimension(:,:), allocatable :: lapl_rho_tr, tau,  vlapl ,vtl, grad_wf ! lap_phi,,lapl
! grad_wf gradient of the wf
! real(dp), dimension(:,:,:), allocatable ::   ! grad_vtau,  
!
real(dp) :: weight

! libxc pointers
TYPE(xc_f03_func_t) :: xc_func
TYPE(xc_f03_func_info_t) :: xc_info

! local number of grid points
integer ndim
! flag for input calculated, avoid calculating twice
logical :: is_input, is_gga, is_mgga
! counters
integer:: ipt, ifunc, isp

! forcing use of intrinsic functions
intrinsic :: dot_product

! ------------------------------------------------------------------

weight = real(nrep,dp)

allocate(rho(nspin,parallel%mydim))
allocate(excl(parallel%mydim))
allocate(vxcl(nspin,parallel%mydim))
   

! initialize the total exchange-correlation energy to zero
exc = zero
!
ndim = parallel%mydim

is_input = .true.
is_gga   = .false.
is_mgga  = .false.
write(9,*) 'entered libxc'


do ifunc = 1, 2
        if (func_id(ifunc) /= 0) then 
                ! initiate the libxc functional
                call xc_f03_func_init(xc_func, func_id(ifunc), nspin)
                xc_info = xc_f03_func_get_info(xc_func)
            
                select case (xc_f03_func_info_get_family(xc_info))
                case(XC_FAMILY_LDA)
                        !LDA 
                        !inputs: 
                        !ndim: number of points (size of rho and exc arrays) 
                        !rho[]: charge density
                        if (is_input) then
                                is_input = .false.
                                ! rho to store the charge density
                                rho = transpose(vxc)
                                !initialize vxc 
                                vxc(:,:)=zero
                        endif
        
                        call xc_f03_lda_exc_vxc(xc_func, ndim, &
                                rho(1,1), excl(1), vxcl(1,1))
        
                        ! need to make sure this is correct: 
                        ! intgrating the exc: exc =/int(d^3r /rho(r)*exc(/rho(r))
                        ! multiply by 2: units conversion hartree to rydberg
         
                        !parallel omp region
                        do isp = 1, nspin
                        do ipt = 1, ndim
                                vxc(ipt,isp) = vxc(ipt,isp) + &
                                        two*vxcl(isp,ipt)
                                exc = exc + two*excl(ipt)*rho(isp,ipt)
                        enddo
                        enddo

                case(XC_FAMILY_GGA, XC_FAMILY_HYB_GGA)
                        !GGA
                        ! inputs: 
                        ! ndim: number of points (size of rho and exc arrays) 
                        ! rho[]: charge density
                        ! sigma[]: contracted gradients of the density

                        !avoid calculating GGA the input twice
                        if (is_input) then
                                is_input = .false.
                                ! allocate only for gga 
                                allocate(sigma(2*nspin-1,parallel%mydim))
                                allocate(vsl(2*nspin-1,parallel%mydim))
                                allocate(vsigma(parallel%mydim,2*nspin-1))
                                allocate(grad_rho(3,parallel%mydim,nspin))
                                allocate(grad_vsigma(3,parallel%mydim,2*nspin-1))
                                allocate(lapl_rho(parallel%mydim,nspin))  

                                !deallocate gga flag
                                is_gga = .true.

! If the grid is non-orthogonal
if (grid%sten_coeff%lap_dir_num > 0) then
                                if (parallel%nprow > 1) then
                                        call init_lap_buffer(lap_buf)
                                        call allocate_lap_buffer(lap_buf, &
                                                parallel)
                                endif

                                do isp = 1, nspin
                                        call my_laplacian(parallel, &
                                                grid%sten_coeff, &
                                                lap_buf, vxc(1,isp), &
                                                lapl_rho(1,isp), wvec)
                                enddo

                                if (parallel%nprow > 1) then
                                        call destroy_lap_buffer(lap_buf)
                                endif
else  ! If the grid is orthogonal
                                ! itialize lap buffers for communications
                                if (parallel%nprow > 1) then
                                        call fold_buf%init()
                                        call fold_buf%alloc( &
                                            parallel=parallel, &
                                            foldvol=grid%sten_coeff%foldsize)
                                endif

                                do isp = 1, nspin
                                        ! the laplacian is used later to 
                                        ! calculate the divergence
                                        call laplacian_fold( &
                                                parallel=parallel, &
                                                sten_coeff=grid%sten_coeff, &
                                                fold_buff=fold_buf, &
                                                lap_in=vxc(:,isp), &
                                                lap_out=lapl_rho(:,isp))
                                        ! notice that the output laplacian 
                                        ! has a minus sign!, account for 
                                        ! that when its being used 
                                enddo

                                !destroy the buffer
                                if (parallel%nprow > 1) then
                                        call fold_buf%destroy(parallel)
                                endif
endif

                                do isp = 1, nspin
                                        call gradmvs( &
                                                grid=grid, &
                                                parallel=parallel, &
                                                func=vxc(:,isp), &
                                                gradf=grad_rho(:,:,isp), &
                                                coeke=grid%coe1, &
                                                norder=grid%norder, &
                                                vec=wvec)
                                enddo

                                call get_sigma(ndim, nspin, grad_rho, sigma)

                                ! rho to store the charge density
                                rho = transpose(vxc)

                                !initialize vxc 
                                vxc(:,:) = zero
                        endif

                        call xc_f03_gga_exc_vxc(xc_func, ndim, rho(1,1), &
                                sigma(1,1), excl(1), vxcl(1,1), vsl(1,1))

                        ! transpose vsigma for the sake of calculatng 
                        ! its gradient 
                        vsigma = transpose(vsl)

                        !calculate divergence of vsigma*grad_rho: using
                        ! divergence product rule
                        do isp = 1, 2*nspin-1
                                call gradmvs(grid, parallel, vsigma(:,isp), &
                                        grad_vsigma(:,:,isp), grid%coe1, &
                                        grid%norder, wvec)
                        enddo

                        do isp = 1, nspin
                                !parallel omp region
                                do ipt = 1, ndim
                                        if (nspin == 1) then 
                                        !laplacian has a minus sign, 
                                        ! therefor the minus here
divsigma(1) = two*dot_product(grad_vsigma(:,ipt,1),grad_rho(:,ipt,1)) &
        - two*lapl_rho(ipt,1)*vsigma(ipt,1)
                                        elseif(isp == 1)then
divsigma(1) = two*dot_product(grad_vsigma(:,ipt,1),grad_rho(:,ipt,1)) &
        - two*lapl_rho(ipt,1)*vsigma(ipt,1) &
        + dot_product(grad_vsigma(:,ipt,2),grad_rho(:,ipt,2)) &
        - lapl_rho(ipt,2)*vsigma(ipt,2)
                                        else
divsigma(2) = two*dot_product(grad_vsigma(:,ipt,3),grad_rho(:,ipt,2)) &
        - two*lapl_rho(ipt,2)*vsigma(ipt,3) &
        + dot_product(grad_vsigma(:,ipt,2),grad_rho(:,ipt,1)) &
        - lapl_rho(ipt,1)*vsigma(ipt,2)
                                        endif

                                        ! vxc = previous + 
                                        !       LDA contribution - 
                                        !       GGA contribution 
                                        vxc(ipt,isp) = vxc(ipt,isp) + &
                                                two*vxcl(isp,ipt) - &
                                                two*divsigma(isp)
                                        exc = exc + two*excl(ipt)*rho(isp,ipt)
                                enddo
                        enddo
        
                case(XC_FAMILY_mGGA)
                        !MetaGGA
                        ! write(9,*) 'I am not ready for mGGA family yet'
                        ! write(9,*) 'WARNING exchange correlation energy is not calculated, set to zero'
                        ! return
                        !mGGA
                        ! inputs: 
                        ! ndim: number of points (size of rho and exc arrays) 
                        ! rho[]: charge density
                        ! sigma[]: contracted gradients of the density
                        ! lap_rho[]: laplacian of the density
                        ! tau[]: kinetic energy density

                        !avoid calculating mGGA input twice
                        if (is_input) then
                                is_input = .false.
                                ! allocate only for gga 
                                allocate(sigma(2*nspin-1,parallel%mydim))
                                allocate(vsl(2*nspin-1,parallel%mydim))
                                allocate(vsigma(parallel%mydim,2*nspin-1))
                                allocate(grad_rho(3,parallel%mydim,nspin))
                                allocate(grad_vsigma(3,parallel%mydim,2*nspin-1))
                                allocate(lapl_rho(parallel%mydim,nspin))  
                                ! allocate only for mgga 
                                allocate(lapl_rho_tr(nspin,parallel%mydim))
                                allocate(tau(nspin,parallel%mydim))
                                allocate(vtl(nspin,parallel%mydim))
                                allocate(vlapl(nspin,parallel%mydim))
          
                                !deallocate gga flag
                                is_gga=.true.

                                !deallocate mgga flag
                                is_mgga=.true.

                                !itialize lap buffers for communications {{{ 
                                if (parallel%group_size > 1 ) then
                                       ! call init_lap_buffer(lap_buf)
                                       ! call allocate_lap_buffer(lap_buf,parallel)
                                       call fold_buf%init()
                                       call fold_buf%alloc(parallel,foldvol=grid%sten_coeff%foldsize)
                                endif

                                do isp=1,nspin
                                        call  gradmvs(grid, parallel, vxc(:,isp), grad_rho(:,:,isp), grid%coe1, grid%norder, wvec)
                                        ! the laplacian is used later to calculate the divergence
                                        call laplacian_fold(parallel,grid%sten_coeff,fold_buf,vxc(:,isp),lapl_rho(:,isp))
                                        !notice that the output laplacian has a minus sign!, acount for that when its being used 
                                enddo

                                !destroy the buffer
                                if (parallel%group_size > 1 ) then
                                        call fold_buf%destroy(parallel)
                                endif
                            
                                call get_sigma(ndim,nspin,grad_rho,sigma)
                            
                                ! mgga 
                                ! transpose laplacian for libxc input style and add the minus
                                lapl_rho_tr=-transpose(lapl_rho)

                                ! tau kinetic energy density.
                                call get_tau(grid,parallel,ndim,nspin,elec_st,tau,wvec)

                                ! rho to store the charge density
                                rho = transpose(vxc)
                                !initialize vxc 
                                vxc(:,:) = zero
                        endif

                        call xc_f03_mgga_exc_vxc(xc_func,ndim, rho(1,1), sigma(1,1), lapl_rho_tr(1,1) , tau(1,1) &
                              ,excl(1), vxcl(1,1), vsl(1,1), vlapl(1,1) ,vtl(1,1))
                         
                        ! transpose vsigma for the sake of calculatng its gradient 
                        vsigma=transpose(vsl)
                         
                        !calculate divergence of vsigma*grad_rho: using divergence product rule
                        do isp = 1,2*nspin - 1         
                                call gradmvs(grid, parallel, vsigma(:,isp), grad_vsigma(:,:,isp), grid%coe1, grid%norder, wvec)
                        enddo
                         
                        do isp=1,nspin
                        !parallel omp region
                        do ipt=1,ndim
                                if(nspin==1 )   then 
                                  !laplacian has a minus sign, therefor the minus here
                                  divsigma(1) = two*dot_product(grad_vsigma(:,ipt,1),grad_rho(:,ipt,1)) &
                                       - two*lapl_rho(ipt,1)*vsigma(ipt,1)
                                elseif(isp == 1)then
                                  divsigma(1) = two*dot_product(grad_vsigma(:,ipt,1),grad_rho(:,ipt,1))&
                                       - two*lapl_rho(ipt,1)*vsigma(ipt,1)&
                                       + dot_product(grad_vsigma(:,ipt,2),grad_rho(:,ipt,2))&
                                       - lapl_rho(ipt,2)*vsigma(ipt,2)
                                else
                                  divsigma(2) = two*dot_product(grad_vsigma(:,ipt,3),grad_rho(:,ipt,2))&
                                       - two*lapl_rho(ipt,2)*vsigma(ipt,3)&
                                       + dot_product(grad_vsigma(:,ipt,2),grad_rho(:,ipt,1))&
                                       - lapl_rho(ipt,1)*vsigma(ipt,2)
                                endif

                                ! mgga contribution to vxc is small and it involves a lot of work
                                ! that will be a project for another time
                                                      
                                ! vxc =         previous      + LDA  contribution  - GGA contribution - mGGA
                                vxc(ipt,isp) = vxc(ipt,isp) + two*vxcl(isp,ipt) - divsigma(isp)
                                exc = exc + two*excl(ipt)*rho(isp,ipt)
                        enddo
                        enddo 
                end select

                call xc_f03_func_end(xc_func)
        endif
enddo

! weighting should be added here
exc = exc*weight

! finally scale by h^3 and summation over all processors
call psum(exc, 1, parallel%group_size, parallel%group_comm)
exc  = exc * (grid%hcub)

!debuging outputs
write(9,*) 'final exc:'
write(9,*) exc

deallocate(rho)
deallocate(excl)
deallocate(vxcl)

if (is_gga) then
        deallocate(sigma)
        deallocate(vsl)
        deallocate(vsigma)
        deallocate(grad_rho)
        deallocate(grad_vsigma)
        deallocate(lapl_rho)
endif

if (is_mgga) then
        deallocate(tau)
        deallocate(lapl_rho_tr)
        deallocate(vtl)
        deallocate(vlapl) 
endif

end subroutine libxc

!================================
!> brief get_sigma calcultes the dot product of the density gradient
! spin polarized sigma(3,ndim)
            ! σ[1] = ∇n↑​ ⋅ ∇n↑
            ! σ[2] = ∇n↑ ⋅ ∇n↓
            ! σ[3] = ∇n↓ ⋅ ∇n↓
!spin unpolarized case
            ! σ = ∇n​ ⋅ ∇n 
!-----------------------------------
subroutine get_sigma(ndim,nspin,grad_rho,sigma)

use constants !need this to recognise type (dp)

implicit none

! Input/Output variables:

! local number of grid points
integer, intent(in) :: ndim 
! spin polarization
integer, intent(in) :: nspin
! grad_rho gradint of chrage density
 real(dp), intent(in) :: grad_rho(3,ndim,nspin)
! sigma contracted gradient of density
 real(dp), intent(out) :: sigma(2*nspin-1,ndim)

!work
! counters
integer:: ipt
!
intrinsic :: dot_product

  !TODO parallel omp region
  do ipt=1,ndim
     sigma(1,ipt) = dot_product(grad_rho(:,ipt,1),grad_rho(:,ipt,1))            
     if (nspin==2) then         
        sigma(2,ipt) = dot_product(grad_rho(:,ipt,1),grad_rho(:,ipt,2))
        sigma(3,ipt) = dot_product(grad_rho(:,ipt,2),grad_rho(:,ipt,2))
     end if
  end do
write(9,*) "shape of sigma "                  
write(9,*) shape(sigma)

end subroutine get_sigma

!===================================
!> brief get_tau returns the kinetic energy density
! tau= 1/2 sum |∇n|^2
!   sum only gradients of the occupied orbitals
!
! requires initialized wavefunctions, cant run in initial guess
!  
! TODO when symmetry gets fixed come back here to select right repr, and k point tau needs, or do I need to go over all of them for tau? and if so do I need to include here a PE sum for things calculated in the other PEs
!
!-----------------------------------
subroutine get_tau(grid,parallel,ndim,nspin,elec_st,tau,wvec)            

  use grid_module
  use parallel_data_module
  use electronic_struct_module
  use gradmvs_module
  use aux, only : mysecond

  implicit none

  ! Input/Output variables:
  !
  ! grid related data
  type (grid_data), intent(in) :: grid
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel
  ! local number of grid points
  integer, intent(in) :: ndim 
  ! spin polarization
  integer, intent(in) :: nspin
  type (electronic_struct), intent(in) :: elec_st
  ! kinetic energy density
  real(dp), intent(out) :: tau(nspin,ndim)
 ! work array
  real(dp), intent(out) :: wvec(parallel%nwedge + 1)

  !work variables
  real(dp), dimension(:,:), allocatable ::  grad_wf
  
  real(dp)::dotp  
  ! counters
  integer:: ipt ,isp, istate
  ! temporary timers
  real(dp) :: t0,t1,t2

  !ldn is ndim padded
   allocate(grad_wf(3, parallel%ldn))
  ! initializing tau
  tau(:,:)=zero
  !do irp = 1, elec_st%nrep
  do isp = 1,nspin
     do istate =1,elec_st%nstate
        if (elec_st%eig(1,1,isp)%occ(istate) > 0) then
           
           
 
          call mysecond(t0)
           call  gradmvs(grid, parallel, elec_st%eig(1,1,isp)%wf(:,istate), grad_wf(:,:), grid%coe1, grid%norder, wvec)
           call mysecond(t1)
  !TODO parallel omp region
           do ipt=1,ndim
              dotp=dot_product(grad_wf(:,ipt),grad_wf(:,ipt))   
              tau(isp,ipt)=tau(isp,ipt)+half*elec_st%eig(1,1,isp)%occ(istate)*dotp
           end do
           call mysecond(t2)
           !debug outputs

           write(9,*)"time to calc gradient", t1-t0
           write(9,*)"time to dot product", t2-t1
           

        end if
     end do
  end do



   deallocate(grad_wf)

end subroutine get_tau

#endif 

end module libxc_module
