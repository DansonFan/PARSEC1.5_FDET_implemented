module kinetic_module
   implicit none
   contains

!=============================================================================!
! Non-additive kinetic energy and potential for frozen-density embedding.
!=============================================================================!
subroutine kinetic_energy(grid, parallel, pot, weight, rhotot, tn, vn, wvec)

use constants
use grid_module
use parallel_data_module
use potential_module

implicit none

type(grid_data), intent(in) :: grid
type(parallel_data), intent(in) :: parallel
type(potential), intent(in) :: pot
real(dp), intent(in) :: weight
real(dp), intent(in) :: rhotot(parallel%mydim)
real(dp), intent(out) :: wvec(parallel%nwedge + 1)
real(dp), intent(out) :: tn
real(dp), intent(out) :: vn(parallel%mydim)

real(dp) :: ekin
real(dp) :: vkin(parallel%mydim)
real(dp) :: rhot(parallel%mydim)
integer :: i

vn(:) = zero
tn = zero

call compute_kin(grid, parallel, pot, weight, rhotot, ekin, vkin, wvec)
vn(:) = vn(:) + vkin(:)
tn = tn + ekin

call compute_kin(grid, parallel, pot, weight, pot%rho0, ekin, vkin, wvec)
tn = tn - ekin

do i = 1, parallel%mydim
        rhot(i) = rhotot(i) - pot%rho0(i)
enddo

call compute_kin(grid, parallel, pot, weight, rhot, ekin, vkin, wvec)
vn(:) = vn(:) - vkin(:)
tn = tn - ekin

end subroutine kinetic_energy


subroutine compute_kin(grid, parallel, pot, weight, rho, ekin, vkin, wv)

use constants
use grid_module
use parallel_data_module
use potential_module
use gradmvs_module
use dbuffer_module
use stencil_things
use laplacian_ops_module, only : laplacian_fold, my_laplacian
use aux, only : alccheck

implicit none

type(grid_data), intent(in) :: grid
type(parallel_data), intent(in) :: parallel
type(potential), intent(in) :: pot
real(dp), intent(in) :: rho(parallel%mydim)
real(dp), intent(in) :: weight
real(dp), intent(out) :: ekin
real(dp), intent(out) :: vkin(parallel%mydim)
real(dp), intent(out) :: wv(parallel%nwedge + 1)

real(dp), dimension(:), allocatable :: absgrad, laplac
real(dp), dimension(:,:), allocatable :: gradient, gradgrad
real(dp) :: prod
integer :: i
real(dp), dimension(3) :: temp1, temp2
real(dp) :: ek, vk
real(dp) :: ctf
integer :: nd
integer :: alcstat
real(dp) :: fk, u, v, s, pi32
type(lap_buffer) :: lap_buf
type(fold_buffer) :: fold_buf

nd = parallel%mydim
ekin = zero
vkin(:) = zero

allocate(gradient(3,nd), stat=alcstat)
call alccheck('kinetic gradient', 3*nd, alcstat)
allocate(absgrad(nd), stat=alcstat)
call alccheck('kinetic absgrad', nd, alcstat)
allocate(gradgrad(3,nd), stat=alcstat)
call alccheck('kinetic gradgrad', 3*nd, alcstat)
allocate(laplac(nd), stat=alcstat)
call alccheck('kinetic laplac', nd, alcstat)

ctf = 0.6d0 * (three * (pi ** 2)) ** (two / three)
pi32 = three*pi*pi

call gradmvs(grid, parallel, rho, gradient, grid%coe1, grid%norder, wv)

do i = 1, nd
        temp1(:) = gradient(:,i)
        absgrad(i) = sqrt(dot_product(temp1(:), temp1(:)))
enddo

if (grid%sten_coeff%lap_dir_num > 0) then
        if (parallel%nprow > 1) then
                call init_lap_buffer(lap_buf)
                call allocate_lap_buffer(lap_buf, parallel)
        endif

        call my_laplacian(parallel, grid%sten_coeff, lap_buf, rho, &
                laplac, wv)
        laplac(:) = -laplac(:)

        if (parallel%nprow > 1) call destroy_lap_buffer(lap_buf)
else
        if (parallel%nprow > 1) then
                call fold_buf%init()
                call fold_buf%alloc(parallel, foldvol=grid%sten_coeff%foldsize)
        endif

        call laplacian_fold(parallel, grid%sten_coeff, fold_buf, rho, laplac)
        laplac(:) = -laplac(:)

        if (parallel%nprow > 1) call fold_buf%destroy(parallel)
endif

call gradmvs(grid, parallel, absgrad, gradgrad, grid%coe1, grid%norder, wv)

do i = 1, nd
        if (rho(i) < 1.0d-18) cycle

        temp1(:) = gradient(:,i)
        temp2(:) = gradgrad(:,i)
        prod = dot_product(temp1(:), temp2(:))
        fk = (pi32*rho(i))**third
        s = absgrad(i)/(two*fk*rho(i))
        u = two*prod/(rho(i)*rho(i)*(two*fk)**3)
        v = laplac(i)/(rho(i)*(two*fk)**2)

        select case (pot%kin_name)
        case (1)
                call pw91k(rho(i), s, u, v, ek, vk)
        case (2)
                call pbek(rho(i), s, u, v, ek, vk, pot%vum, pot%vuk)
        case (3)
                vk = (five/three)*(rho(i)**(two/three))
                ek = rho(i)**(two/three)
        case (4)
                call tfwk(rho(i), absgrad(i), laplac(i), ek, vk)
        case (0)
                vk = zero
                ek = zero
        case default
                write(7,*) 'Invalid FDET kinetic energy functional.'
                stop 612
        end select

        vkin(i) = ctf * vk
        ekin = ekin + ctf * rho(i) * ek * weight
enddo

deallocate(gradient, absgrad, gradgrad, laplac)

end subroutine compute_kin


subroutine pw91k(d, s, u, v, ek, vk)

use constants
implicit none

real(dp), intent(in) :: d, s, u, v
real(dp), intent(out) :: ek, vk

real(dp) :: f, fac, fs, fss
real(dp) :: p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11
real(dp) :: s2, s3, s4
real(dp), parameter :: a1 = 0.093907d0
real(dp), parameter :: a2 = 0.26608d0
real(dp), parameter :: a3 = 0.0809615d0
real(dp), parameter :: a4 = 100.d0
real(dp), parameter :: a = 76.32d0
real(dp), parameter :: b1 = 0.000057767d0
real(dp), parameter :: thrd4 = four/three

if (d < 1.0d-18) then
        ek = zero
        vk = zero
else
        fac = d**(two/three)
        s2 = s*s
        s3 = s2*s
        s4 = s2*s2
        p0 = one/sqrt(one+a*a*s2)
        p1 = log(a*s+one/p0)
        p2 = exp(-a4*s2)
        p3 = one/(one+a1*s*p1+b1*s4)
        p4 = one+a1*s*p1+(a2-a3*p2)*s2
        f = p3*p4
        ek = fac*f
        p5 = b1*s2-(a2-a3*p2)
        p6 = a1*s*(p1+a*s*p0)
        p7 = two*(a2-a3*p2)+two*a3*a4*s2*p2-four*b1*s2*f
        fs = p3*(p3*p5*p6+p7)
        p8 = two*s*(b1-a3*a4*p2)
        p9 = a1*p1+a*a1*s*p0*(three-a*a*s2*p0*p0)
        p10 = four*a3*a4*s*p2*(two-a4*s2)-8.d0*b1*s*f-four*b1*s3*fs
        p11 = -p3*p3*(a1*p1+a*a1*s*p0+four*b1*s3)
        fss = p3*p3*(p5*p9+p6*p8)+two*p3*p5*p6*p11+p3*p10+p7*p11
        vk = fac*((five/three)*f-(u-thrd4*s3)*fss-v*fs-fs*s2/three)
endif

end subroutine pw91k


subroutine pbek(rho, s, u, v, ek, vk, vum, vuk)

use constants
implicit none

real(dp), intent(in) :: rho, s, u, v
real(dp), intent(out) :: ek, vk
real(dp), intent(in) :: vum, vuk

real(dp) :: exunif, fs, fss, fxpbe, p0, s2
real(dp), parameter :: thrd4 = four/three
real(dp) :: ul

if (rho < 1.0d-18) then
        ek = zero
        vk = zero
else
        exunif = rho**(two/three)
        ul = vum / vuk
        s2 = s*s
        p0 = one+ul*s2
        fxpbe = one+vuk-vuk/p0
        ek = exunif*fxpbe
        fs = two*vuk*ul/(p0*p0)
        fss = -four*ul*s*fs/p0
        vk = exunif*((five/three)*fxpbe-(u-thrd4*s2*s)*fss &
                - v*fs - fs*s2/three)
endif

end subroutine pbek


subroutine tfwk(rho, grad, lap, ek, vk)

use constants
implicit none

real(dp), intent(in) :: rho, grad, lap
real(dp), intent(out) :: ek, vk

real(dp) :: v72
real(dp) :: ctf

if (rho < 1.0d-18) then
        ek = zero
        vk = zero
else
        v72 = one / 72.d0
        ctf = 0.6d0 * (three * (pi ** 2)) ** (two / three)
        ek = rho**(two/three) + (v72*(grad*grad)/(rho*rho)) / ctf
        vk = (five/three)*rho**(two/three) + &
                (v72*(grad*grad/(rho*rho) - two*lap/rho)) / ctf
endif

end subroutine tfwk

end module kinetic_module
