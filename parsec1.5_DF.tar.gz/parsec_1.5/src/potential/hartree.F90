module hartree_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  FOR CONFINED SYSTEMS:
!  This subroutine computes an effective charge density that is
!  used as the source term in hpotcg for determining the Hartree
!  potential. It is based on a mutipole expansion of the boundary
!  potential in terms of the charge density, providing the
!  appropriate boundary condition. Finite difference terms
!  involving points outside the sphere are computed using the
!  boundary potential and added to the effective charge density.
!
!  For a general discussion of the theory of mutipole expansions,
!  see, e.g., Landau and Lifshitz, the classical theory of fields,
!  pp. 97-99.
!
!  This subroutine uses Eqs. (41.12) and (41.13) of Landau and
!  Lifshitz. However, the spherical harmonics and their properties
!  follow the definition given by Jackson, Classical
!  Electrodynamics, pp. 98-99.
!
!---------------------------------------------------------------
subroutine hartset(grid, rsymm, parallel, norder, lpole, coeke, &
        rho, clm, brho)

use constants
use aux, only : matvec3, bessel_k, setplm
use grid_module
use symmetry_module
use symmetry_routines, only : symop
use parallel_data_module
use psum_module
use exc_module
use hpot_g_module, only : hpot_g
use external_interfaces, only : dcopy
use init_vector, only : dzero_vector, zzero_vector

implicit none

! Input/Output variables:

! grid related data
type(grid_data), intent(in) :: grid

! symmetry operations in reduced group:
type(symmetry), intent(in) :: rsymm

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! number of neighbors used for derivation (on one side)
integer, intent(in) :: norder

! order of multipole expansion 
integer, intent(in) :: lpole

! coefficients for taking a second derivative
real(dp), dimension(-norder:norder,3), intent(in) :: coeke

! charge density on the 3-d grid
real(dp), dimension(parallel%ldn), intent(in) :: rho

! coefficient array: clm = (l-m)!/(l+m)!
real(dp), dimension(0:lpole,0:lpole), intent(in) :: clm

! effective charge density = original charge density augmented by
! appropriate boundary terms, to be used as the source term in hpotcg
real(dp), dimension(parallel%ldn), intent(out) :: brho



! Work variables:

! offset for each processor
integer :: ioffset

! grid spacing (atomic units)
real(dp) :: h

! temporary storage variables
! counters of total and z-axis angular momentum
integer :: l
integer :: m




! -------------------------------------
! for each grid point labeled by j,
! -------------------------------------

! rrho = rho(j)
real(dp) :: rrho

! grid point equiv. to (xx(j),yy(j),zz(j))
real(dp), dimension(3) :: rw
real(dp), dimension(3) :: rrw(3)

! xx2 = xx(j)^2
real(dp) :: xx2

! yy2 = yy(j)^2
real(dp) :: yy2

! zz2 = zz(j)^2
real(dp) :: zz2

! xy = sqrt(xx(j)^2 + yy(j)^2)
real(dp) :: xy

! r2 = xx(j)^2 + yy(j)^2 + zz(j)^2
real(dp) :: r2

! x = cos(theta_j)
real(dp) :: x

! y = sin(theta_j)
real(dp) :: y

! -------------------------------------




! -------------------------------------
! for (l,m) angular momentum quantum numbers
! -------------------------------------

! r(1) = sqrt(xx(j)^2 + yy(j)^2 + zz(j)^2)
! r(l) = r(1)^l
real(dp), dimension(0:lpole) :: r

! tmp1 = rrho*r(l)
real(dp) :: tmp1

! rinv(1) = 1/r(1)
real(dp), dimension(0:lpole) :: rinv

! -------------------------------------



! -------------------------------------
! For each grid point:
! -------------------------------------
! temporary storage of the associated Legendre polynom value
real(dp), dimension(0:lpole,0:lpole) :: plm

! The coefficient defined in Eq. (41,13) of Landau and Lifshitz
complex(dpc), dimension(0:lpole,0:lpole) :: qlm

! Coefficient array: e^{i m \phi_j} = cos(phi_j) + i*sin(phi_j)
complex(dpc), dimension(lpole) :: cxy
! -------------------------------------



! Contribution to the boundary potential (the contribution is the
! real part of this quantity).
complex(dpc) :: cpole

real(dp) :: cpole_deb
real(dp) :: r12

! Coordinates of relevant neighboring points outside 
! the boundary sphere.
real(dp) :: xh
real(dp) :: yh
real(dp) :: zh
!real(dp) :: xn
!real(dp) :: yn
!real(dp) :: zn
!real(dp) :: xh1
!real(dp) :: yh1
!real(dp) :: zh1

! square of grid spacing
real(dp) :: hsq

! 2*h^3
real(dp) :: two_hcub

! other counters
integer :: i, j, jshell, i_lap_dir, itrans
!integer :: i_deb
!integer :: j_deb
!integer :: alcstat
integer :: i_n, j_n, k_n
!integer :: j_tmp

! constants
real(dp), parameter :: pi8 = eight*pi

real(dp), dimension(:), allocatable :: boundary_pot

! ---------------------------------------------------------------

!  Assume that grid spacing is the same along all directions.
! AJB: I am putting a warning that is found down below right here so we can be sure to take care of that
!  WARNING: if the grid spacing h is not the same in the x, y, z
!  directions then coeke(jshell,1) needs to be changed in a way
!  that takes into account whether the neighboring point is an
!  x, y, or z neighbor!!
h = grid%step(1)

hsq = h*h
two_hcub = two*grid%hcub
ioffset = parallel%irows(parallel%colgroup_iam) - 1

call dzero_vector(brho(1:parallel%ldn), parallel%ldn)


if (grid%hartree_neibs_flag) then
        ! =================================
        ! Using explicit integration
        ! =================================
        call calculate_brho_using_explicit_integration()
else

        ! =================================
        ! Using multipole expansion
        ! =================================


        ! Zero out all of the qlm entries
        call dzero_vector(rinv(0:lpole), lpole+1)
        call dzero_vector(plm(0:lpole,0:lpole), (lpole+1)*(lpole+1))
        call zzero_vector(qlm(0:lpole,0:lpole), (lpole+1)*(lpole+1))

         




        !
        ! We need to populate the qlm entries by adding in the
        ! contribution from every grid point that we have data for.
        !
        ! qlm(l,m) is given by
        !
        ! \sum_{j=1}^{ndim}e_j r_j^l P_l^m(cos(\theta_j)) e^{i m \phi_j}
        !
        ! where l = 0 to lpole, m = -l to l, e_j is the given by rho(j),
        ! r_j is the position of the grid point calculated by
        ! sqrt(xx(j)^2 + yy(j)^2 + zz(j)^2), P_l^m is the associate
        ! Legendre polynomial and cos(theta_j) = zz(j)/r and
        ! sin(theta_j) = sqrt(xx(j)^2 + yy(j)^2)/r. We use the fact that
        ! e^{i m \phi_j} = cos(phi_j) + i*sin(phi_j) and we can then
        ! write this term (called cxy(m)) as
        ! ((xx(j) + i*yy(j))/sqrt(xx(j)^2 + yy(j)^2))^m.
        !
        ! We also exploit the fact that there is a simple relationship
        ! between -m and +m terms and we do not calculate any m < 0 
        ! terms. It ends up working out that the contribution to brho
        ! from -m elements is exactly equal to the contribution from +m
        ! terms, so later we just double qlm for m > 0, and eventually
        ! consider only the real part of the final result, and we dont
        ! have to do any other calculations for negative m's. 
        !
        ! This do loop adds in contributions to qlm(l,m) from each grid
        ! point.
        !
        do itrans = 1, rsymm%ntrans
        do j = parallel%irows(parallel%colgroup_iam), &
               parallel%irows(parallel%colgroup_iam+1)-1

                rrho = rho(j-ioffset)

                ! SFC note - this uses kx/ky/kz so it should be okay
                ! 
                ! Note: fx, fy, and fz are defined on the whole domain
                !       kx, ky, and kz are defined on the irreducible wedge
                rw(1) = (grid%shift(1) + grid%kx(j)) * h
                rw(2) = (grid%shift(2) + grid%ky(j)) * h
                rw(3) = (grid%shift(3) + grid%kz(j)) * h

                call symop(symm=rsymm, it=itrans, rin=rw(:), tr=rrw(:))

                rw(:) = rrw(:)
                r2 = dot_product(rw(:),rw(:))

                xx2 = rw(1) * rw(1)
                yy2 = rw(2) * rw(2)
                zz2 = rw(3) * rw(3)
                !
                !  r(1) = sqrt(xx(j)^2 + yy(j)^2 + zz(j)^2) 
                !
                r(1) = sqrt(r2)
                qlm(0,0) = qlm(0,0) + rrho

                if (r(1) > zero) then
                        !
                        ! r(l) = r^l (higher powers of r)
                        !
                        do l = 2, lpole
                                r(l) = r(l-1)*r(1)
                        enddo

                        rinv(1) = one/r(1)
                        xy = sqrt(xx2+yy2)
                        !
                        ! x = cos(theta_j), y = sin(theta_j)
                        !
                        x = rw(3) * rinv(1)
                        y = xy*rinv(1)
                        !
                        ! Evaluate associate Legendre polynomials 
                        ! for x and y with l from
                        ! 0 to lpole and m from 0 to l. store each in plm(l,m).
                        !
                        call setplm(x, y, lpole, plm)
                        !
                        ! First evaluate the contribution to 
                        ! the m=0 terms of qlm(l,m) as
                        ! they are simpler since cxy(0) would be 1. Don't bother
                        ! calculating cxy(0) or multiplying it into these terms.
                        !
                        do l = 1, lpole
                                qlm(l,0) = qlm(l,0) + rrho*plm(l,0)*r(l)
                        enddo

                        if (xy > zero) then
                                !
                                ! cxy(m) = exp(i*m*phi_j) 
                                !        = (cos(phi_j) + i*sin(phi_j))^m
                                !        = ((xx(j) + i*yy(j))/(sqrt(xx(j)^2 + yy(j)^2))^m
                                !
                                ! First calculate cxy(1).
                                !
                                cxy(1) = cmplx(rw(1),rw(2),dpc) / xy
                                !
                                ! Now calculate cxy(m) for m=2 to lpole.
                                !
                                do m = 2, lpole
                                        cxy(m) = cxy(m-1)*cxy(1)
                                enddo
                                !
                                ! Now we can calculate the contribution to 
                                ! the qlm(l,m) terms
                                ! for m non-zero. tmp1 is used to avoid 
                                ! calculating rrho*r(l) for each m iteration.
                                !
                                do l = 1, lpole
                                        tmp1 = rrho*r(l)

                                        do m = 1, l
                                                qlm(l,m) = qlm(l,m) + &
                                                        cxy(m)*plm(l,m)*tmp1
                                        enddo
                                enddo
                        endif
                endif  !if (r(1) > zero) then
        enddo !  %irows
        enddo !  itrans = 1, rsymm%ntrans






        !
        !  Global sum for colecting the qlms from each processor.
        call zpsum(qlm(:,:), (lpole+1)*(lpole+1), parallel%nprow, &
                parallel%colgroup_comm)




        !
        !  Once all of the contributions to qlm have been calculated we
        !  need to multiply each term by h^3. for the calculation we are
        !  performing it works out that the contributions from -m terms
        !  are equal to +m terms, so we also double the qlm(l,m) terms
        !  where m > 0. also, for the sake of simplicity we multiply in
        !  the clm(l,m) factor to simplify our work later.
        !
        !  First do m = 0 terms.
        !
        do l = 0, lpole
                qlm(l,0) = qlm(l,0)*clm(l,0)*grid%hcub
        enddo
        !
        !  Then do m > 0 terms (factor of 2 accounts for m < 0 terms).
        !
        do l = 1, lpole
        do m = 1, l, 1
                qlm(l,m) = qlm(l,m)*clm(l,m)*two_hcub
        enddo
        enddo








        !SFC note - this uses the neibs_f arrays
        ! if(grid%hartree_neibs_flag) then
        !  write(9,*) 'before boundary pot allocation'
        !  allocate(boundary_pot(grid%neibs_num),stat=alcstat)
        !  write(9,*) 'after allocation'
        !  do i_deb=1, grid%neibs_num
        !   xh = (grid%shift(1) + grid%neibs_fx(i_deb))*h
        !   yh = (grid%shift(2) + grid%neibs_fy(i_deb))*h
        !   zh = (grid%shift(3) + grid%neibs_fz(i_deb))*h
        !   if(mod(i_deb,1000) .eq. 0) write(9,*) 'done neib: ', i_deb 
        !   cpole_deb=0
        !   do j_deb = parallel%irows(parallel%group_iam), &
        !          parallel%irows(parallel%group_iam+1)-1

        !          xn = (grid%shift(1) + grid%kx(j_deb))*h
        !          yn = (grid%shift(2) + grid%ky(j_deb))*h
        !          zn = (grid%shift(3) + grid%kz(j_deb))*h

        !          r12=sqrt((xn-xh)**2+(yn-yh)**2+(zn-zh)**2)

        !          cpole_deb=cpole_deb+rho(j_deb-ioffset)/r12
        !   enddo

        !    !cpole_deb = cpole_deb * pi8 * grid%hcub / 4.0d0
        !  cpole_deb = cpole_deb * grid%hcub
        !  boundary_pot(i_deb)=cpole_deb
        ! end do
#ifdef MPI
        ! write(9,*) 'before boundary_pot psum'
        ! call psum(boundary_pot, grid%neibs_num, parallel%group_size, &
            ! parallel%group_comm)
        ! write(9,*) 'after boundary_pot  psum'
#endif
        ! end if







        !
        !  What we really want to calculate here is the boundary
        !  conditions for the determination of the Hartree contribution.
        !  This is based on a multipole expansion. We start with a
        !  boundary rho (brho) that is 8*pi*rho (4*pi with an extra factor
        !  of two for the Hartree->Rydberg conversion) and then find
        !  points which are OUTSIDE our sphere. Since the potential is not
        !  zero outside of the sphere the contribution of these points to
        !  rho must be included in order to produce an accurate Hartree
        !  potential. The contribution of a given point can be found by
        !  psi(l) = 1/R^{l +1} \sum_{m=-l}^{l}
        !           (\frac{(l-m)!}{l+m)!}*(\sum_{j=1}^{ndim}e_j r_j^l 
        !           P_l^m(cos(\theta_j)) e^{i m \phi_j})*
        !           P_l^m(cos(\theta)) e^{-i m \phi}).
        !  according to what we've done above this simplifies to
        !  psi(l) = 1/R^{l+1} qlm(l,m) P_l^m(cos(\theta)) e^{-i m \phi}.
        !  In this calculation R, theta, and phi are the spherical
        !  coordinates of the point outside the sphere which we are
        !  considering. This calculation looks much like the above, 
        !  however the contribution for l=0,lpole and m=0,l are summed to
        !  give the contribution of the particular point to the grid point
        !  which it neighbors. For simplicity we keep most of the
        !  temporary variables the same and this code is laid out pretty
        !  much identical to the above loop, but looking for any neighbors
        !  of grid points which fall outside of the sphere.
        !
        !  Notice that, since all charge densities have the full
        !  symmetry of the system, there is no need to include characters
        !  in the neighbor grid points (i.e., parallel%tneibs is not used).
        !
        !  Start with the boundary rho (brho) equal to 8*pi*rho.
        !

        do i = parallel%irows(parallel%colgroup_iam), &
               parallel%irows(parallel%colgroup_iam+1)-1

                brho(i-ioffset) = rho(i-ioffset)*pi8
        enddo
        !
        !  Go through each neighbour in all 6 directions
        !  (+/-x, +/-y, +/-z) for the order needed.
        !
        do i = parallel%irows(parallel%colgroup_iam), &
                parallel%irows(parallel%colgroup_iam+1)-1
        do jshell = 1, norder
        do i_lap_dir = 1, 6
                !
                !  If this neighbor is outside the sphere then its neibs value
                !  will be greater than myworkdim. we can then find the position of
                !  this point and calculate its contribution to brho.
                !
                if (parallel%neibs(i_lap_dir+(jshell-1)*6,i-ioffset) > &
                        parallel%myworkdim) then

                        xh = (grid%shift(1) + grid%kx(i))*h
                        yh = (grid%shift(2) + grid%ky(i))*h
                        zh = (grid%shift(3) + grid%kz(i))*h
                        i_n=grid%kx(i)
                        j_n=grid%ky(i)
                        k_n=grid%kz(i)
                        !write(7,*) ' i , j , k =',i_n,j_n,k_n
                        !write(7,*) 'x,y,z = ',xh,yh,zh
                        if (i_lap_dir == 1) then
                                xh = xh-h*jshell
                                i_n=i_n-jshell
                        elseif (i_lap_dir == 2) then
                                xh = xh+h*jshell
                                i_n=i_n+jshell
                        elseif (i_lap_dir == 3) then
                                yh = yh-h*jshell
                                j_n = j_n-jshell
                        elseif (i_lap_dir == 4) then
                                yh = yh+h*jshell
                                j_n = j_n+jshell
                        elseif (i_lap_dir == 5) then
                                zh = zh-h*jshell
                                k_n = k_n-jshell
                        elseif (i_lap_dir == 6) then
                                zh = zh+h*jshell
                                k_n = k_n + jshell
                        endif

                        !write(7,*) 'jshell=',jshell,',i_lap_dir=',i_lap_dir
                        !write(7,*) ' i , j , k =',i_n,j_n,k_n
                        !write(7,*) 'xh,yh,zh = ',xh,yh,zh
                        !if(grid%hartree_neibs_flag) then
                        !  j_tmp=grid%neibs_index(i_n,j_n,k_n)
                        !  if(j_tmp>0) then
                        !   xh1=(grid%shift(1)+grid%neibs_fx(j_tmp))*h
                        !   yh1=(grid%shift(2)+grid%neibs_fy(j_tmp))*h
                        !   zh1=(grid%shift(3)+grid%neibs_fz(j_tmp))*h
                        !write(7,*) 'xh1,yh1,zh1',xh1,yh1,zh1
                        !  endif
                        !endif

                        xx2 = xh*xh
                        yy2 = yh*yh
                        zz2 = zh*zh
                        r2 = xx2 + yy2 + zz2
                        r(1) = sqrt(r2)
                        !write(7,*) 'point radius is: ',r(1)
                        !
                        ! rinv(l) = 1/r^(l+1). calculate 1/r and higher powers
                        !
                        rinv(0) = one/r(1)
                        do l = 1, lpole
                                rinv(l) = rinv(l-1)*rinv(0)
                        enddo
                        xy = sqrt(xx2+yy2)
                        !
                        ! x = cos(theta), y = sin(theta)
                        !
                        x = zh*rinv(0)
                        y = xy*rinv(0)
                        !
                        ! Evaluate associate Legendre polynomials for x and y with l
                        ! from 0 to lpole and m from 0 to l. store each in plm(l,m).
                        !
                        call setplm(x, y, lpole, plm)
                      
                        ! Initialize cpole to zero.
                        !
                        cpole = zzero
                        ! Calculate the contribution of the m=0 terms.
                        !
                        do l = 0, lpole
                                cpole = cpole + qlm(l,0)*plm(l,0)*rinv(l)
                        enddo

                        if (xy > zero) then
                                cxy(1) = cmplx(xh,-yh,dpc)
                                cxy(1) = cxy(1)/xy

                                do m = 2, lpole, 1
                                        cxy(m) = cxy(m-1)*cxy(1)
                                enddo

                                ! Calculate the contribution of the m>0 terms.
                                !
                                do l = 1, lpole
                                do m = 1, l, 1
                                        cpole = cpole + &
                                                qlm(l,m)*plm(l,m)*cxy(m)*rinv(l)
                                enddo
                                enddo
                        endif

                        ! Add the contributions into brho, but scale by two
                        ! (hartree->rydberg) and by coeke.
                        !

                        ! DEBUG BOUNDARY CONDITIONS - Recalculating cpole according
                        !                             to the exact integral of rho/r .

                        !! AJB:: WARNING - THIS CAN ONLY BE DONE WITH 1 MPI/SERIAL

                        ! if(grid%hartree_neibs_flag) then
                        !     write(9,*) ' I am doing hartree_neibs things that are marked as debug'

                        !   j_deb=grid%neibs_index(i_n,j_n,k_n)
                        !   if(j_deb>0) then

                        !     cpole_deb=boundary_pot(j_deb)

                        !   else

                        !     write(7,*) 'ERROR found non existing neighbor..'
                        !     write(7,*) 'jshell=',jshell,',i_lap_dir=',i_lap_dir, &
                        !                ',i,j,k: ',i_n,j_n,k_n
                        !     write(7,*) 'indexg=',grid%indexg(i_n,j_n,k_n)
                        !     write(7,*) 'neib_index=',grid%neibs_index(i_n,j_n,k_n)
                        !     write(7,*) 'ndim=', grid%ndim,',nwedge=',grid%nwedge
                        !     if(grid%indexg(i_n,j_n,k_n) .ne. grid%ndim) then
                        !       j_deb=grid%indexg(i_n,j_n,k_n)
                        !       write(7,*) 'grid f indices', grid%fx(j_deb), &
                        !                  grid%fy(j_deb), grid%fz(j_deb)
                        !       write(7,*) 'grid k indices', grid%kx(j_deb), &
                        !                  grid%ky(j_deb), grid%kz(j_deb)

                        !   xh = (grid%shift(1) + grid%fx(j_deb))*h
                        !   yh = (grid%shift(2) + grid%fy(j_deb))*h
                        !   zh = (grid%shift(3) + grid%fz(j_deb))*h
                        !       write(7,*) 'x,y,z = ',xh,yh,zh
                        !       write(7,*) 'indices: ',grid%fx(j_deb), grid%fy(j_deb) &
                        !                   , grid%fz(j_deb)
                        !   xh = (grid%shift(1) + grid%kx(j_deb))*h
                        !   yh = (grid%shift(1) + grid%ky(j_deb))*h
                        !   zh = (grid%shift(1) + grid%kz(j_deb))*h
                        !     endif
                        !     stop 1

                        !   endif


                        ! brho(i-ioffset) = brho(i-ioffset) - &
                        !      two*coeke(jshell,1)*cpole_deb

                        !if(mod(i, 10000) .eq. 0) then
                        !   write(9,*) " *** ", i
                        !endif

                        ! if(abs(one - cpole_deb/real(cpole,dp)) > 1.0d-5) then
                        ! write(9,*) i, cpole_deb/real(cpole,dp)
                        ! endif

                        ! else ! grid%hartree_neibs_flag

                        brho(i-ioffset) = brho(i-ioffset) - &
                                two*coeke(jshell,1)*real(cpole,dp)

                        ! endif ! hartree_neibs_flag
                        !  WARNING: if the grid spacing h is not the same in the x, y, z
                        !  directions then coeke(jshell,1) needs to be changed in a way
                        !  that takes into account whether the neighboring point is an
                        !  x,y, or z neighbor!!
                endif
        enddo  ! i_lap_dir = 1,6
        enddo  ! jshell = 1,norder
        enddo  !do i = parallel%irows(parallel%colgroup_iam), parallel%irows(parallel%colgroup_iam+1)-1

        if (allocated(boundary_pot)) deallocate(boundary_pot)

endif


contains




subroutine calculate_brho_using_explicit_integration()

        if (parallel%nprow /= 1) then
                write(9,*) 'ERROR: For now the explicit calculation &
                        &of the boundary condition for Hartree is only &
                        &supported for 0d systems with nprow=1'
                stop
        endif


        do i = parallel%irows(parallel%colgroup_iam), &
               parallel%irows(parallel%colgroup_iam+1)-1

                brho(i-ioffset) = rho(i-ioffset)*pi8
        enddo




        do i = parallel%irows(parallel%colgroup_iam), &
               parallel%irows(parallel%colgroup_iam+1)-1
        do jshell = 1, norder
        do i_lap_dir = 1, 6

                if (parallel%neibs(i_lap_dir+(jshell-1)*6,i-ioffset) > &
                        parallel%myworkdim) then

                        ! KHL: If this neighbor point is outside of the
                        !      simulation domain, we explicitly calculate
                        !      the Hartree potential of this neighbor
                        !      point, and subtract this contribution 
                        !      from 8*pi*rho(i) (in unit of Ry)

                        cpole_deb = zero

                        i_n = grid%kx(i)
                        j_n = grid%ky(i)
                        k_n = grid%kz(i)

                        if (i_lap_dir == 1) then
                                i_n = i_n - jshell
                        elseif (i_lap_dir == 2) then
                                i_n = i_n + jshell
                        elseif (i_lap_dir == 3) then
                                j_n = j_n - jshell
                        elseif (i_lap_dir == 4) then
                                j_n = j_n + jshell
                        elseif (i_lap_dir == 5) then
                                k_n = k_n - jshell
                        elseif (i_lap_dir == 6) then
                                k_n = k_n + jshell
                        endif

                        do j = parallel%irows(parallel%colgroup_iam), &
                               parallel%irows(parallel%colgroup_iam+1)-1

                                xh = grid%kx(j) - i_n
                                yh = grid%ky(j) - j_n
                                zh = grid%kz(j) - k_n
                                r2 = xh*xh+ yh*yh + zh*zh
                                r12 = sqrt(r2)*h

                                cpole_deb = cpole_deb + &
                                        rho(j-ioffset)/r12

                        enddo

                        brho(i-ioffset) = brho(i-ioffset) - &
                                two*coeke(jshell,1)*grid%hcub*cpole_deb
                endif
        enddo
        enddo
        enddo



end subroutine calculate_brho_using_explicit_integration




end subroutine hartset













!===============================================================
!
!  Boundary conditions and builder of charge distribution for 1-dimensional
!  (wire) systems.
!
!---------------------------------------------------------------
subroutine hartset_wire(grid,pbc,rsymm,parallel,norder,lpole, &
     coeke,rho,brho)

  use constants
  use aux, only : matvec3, bessel_k, bessel_i
  use grid_module
  use pbc_module
  use symmetry_module
  use symmetry_routines, only : symop
  use parallel_data_module
  use psum_module
  use external_interfaces, only : dcopy
  implicit none
  !
  !  Input/Output variables:
  !
  !  grid related data
  type (grid_data), intent(in) :: grid
  !  periodic boundary conditions data
  type (pbc_data), intent(inout) :: pbc
  !  symmetry operations in reduced group:
  type (symmetry), intent(in) :: rsymm
  !  parallel computation related data
  type (parallel_data), intent(in) :: parallel

  !  number of neighbors used for derivation (on one side)
  integer, intent(in) :: norder
  !  order of multipole expansion 
  integer, intent(in) :: lpole
  !  coefficients for taking a second derivative
  real(dp), intent(in) :: coeke(-norder:norder,3+grid%lap_dir_num)
  !  charge density on the 3-d grid
  real(dp), intent(in) :: rho(parallel%ldn)
  !  effective charge density = original charge density augmented by
  !  appropriate boundary terms, to be used as the source term in hpotcg
  real(dp), intent(out) :: brho(parallel%ldn)
  !
  !  Work variables:
  !
  !  offset for each processor
  integer ioffset
#ifdef DEBUG
  real(dp), dimension (:,:), allocatable :: tmpmax,tmpmin
  real(dp) :: tmpp
#endif

  !  twopia = 2 * pi / latt_param, constant
  real(dp) :: twopia
  !  lap_neibs = 2*( 3 + grid%lap_dir_num )
  integer lap_neibs
  !  nnmax = latt_param/grid_spacing * 2
  integer nnmax

  real(dp) :: &     ! for each grid point labeled by j,
       rrho, &             ! = rho(j)
       rw(3),rrw(3), &     ! grid point equiv. to (xx(j),yy(j),zz(j))
       yz, &               ! = sqrt(yy(j)^2 + zz(j)^2)
       cc, &               ! = cos(theta_j) = y/yz
       ss, &               ! = sin(theta_j) = z/yz
       yzn                 ! = 2*pi*yz*n/latt_param
  !  phx = exp( +/- 2 * i * pi * xx(j) *n / latt_param )
  complex(dpc), dimension (:), allocatable :: phx
  complex(dpc) :: ypiz(0:lpole)       ! = exp( +/- i * theta_j * m)
  !  temporary storage of the modified Bessel functions and their
  !  degenerate limits
  real(dp) :: pmn(0:lpole)
  !  Multipoles
  complex(dpc), dimension (:,:), allocatable :: qmn

  !  Contribution to the boundary potential (the contribution is the
  !  real part of this quantity).
  complex(dpc) :: cpole

  !  other counters
  integer ii,mm,nn,jshell,jrow,itrans
  real(dp) :: tmp,tmp1
  !  constants
  real(dp), parameter :: pi8 = eight*pi
  ! ln2g = -Euler + ln(2) - Euler-Mascheroni constant
  real(dp), parameter :: ln2g = 0.1159315156584124488d0

  !---------------------------------------------------------------

  nnmax = lpole
  allocate(phx(0:nnmax))
  allocate(qmn(-lpole:lpole, 0:nnmax))
#ifdef DEBUG
  allocate(tmpmax(-lpole:lpole, 0:nnmax))
  allocate(tmpmin(-lpole:lpole, 0:nnmax))
#endif
  lap_neibs = 2*( 3 + grid%lap_dir_num )
  twopia = two * pi / pbc%latt_vec(1,1)
  brho(:) = zero
  ioffset = parallel%irows(parallel%group_iam) - 1
  !  Zero out all of the qmn entries.
  qmn(:,:) = zzero
  pmn(:) = zero
  !
  !  We need to populate the qlm entries by adding in the
  !  contribution from every grid point that we have data for.
  !
  do itrans = 1, rsymm%ntrans
     do ii = parallel%irows(parallel%group_iam) &
          ,parallel%irows(parallel%group_iam+1)-1
        rrho = rho(ii-ioffset)
        rw(1) = (grid%shift(1) + grid%kx(ii)) * grid%step(1)
        rw(2) = (grid%shift(2) + grid%ky(ii)) * grid%step(2)
        rw(3) = (grid%shift(3) + grid%kz(ii)) * grid%step(3)
        call matvec3('N',pbc%avec_norm,rw,rrw)
        call symop(rsymm,itrans,rrw,rw)

        yz = rw(2) * rw(2) + rw(3) * rw(3)
        if( yz == 0 ) then
            cycle
        end if
        if (yz > zero) yz = sqrt(yz)
        tmp1 = one / yz
        cc = rw(2) * tmp1
        ss = rw(3) * tmp1
        ypiz(0) = zone
        ypiz(1) = cmplx(cc,-ss,dpc)
        do mm = 2, lpole
           ypiz(mm) = ypiz(mm-1) * ypiz(1)
        enddo

        tmp = one
        do mm = 1, lpole
           tmp = tmp * yz
           qmn(mm,0) = qmn(mm,0) + rrho * ypiz(mm) * tmp
        enddo

        phx(0) = zone
        phx(1) = -zi * twopia * rw(1)
        phx(1) = exp(phx(1))
        do nn = 2, nnmax
           phx(nn) = phx(nn-1) * phx(1)
        enddo

        yzn = zero
        do nn = 1, nnmax
           yzn = yzn + twopia * yz
           call bessel_i(lpole,yzn,pmn(0:lpole))
           qmn(0,nn) = qmn(0,nn) + rrho * phx(nn) * pmn(0)
           do mm = 1, lpole
              qmn(mm,nn) = qmn(mm,nn) + rrho * ypiz(mm) * phx(nn) * pmn(mm)
              qmn(-mm,nn) = qmn(-mm,nn) + &
                   rrho * conjg(ypiz(mm)) * phx(nn) * pmn(mm)
           enddo
        enddo

     enddo                  !  %irows
  enddo                     !  itrans = 1, rsymm%ntrans

  qmn(0,0) = sum(rho(1:parallel%mydim))*real(rsymm%ntrans,dp)

  !
  !  Global sum for colecting the qlms from each processor.
  call zpsum(qmn,(2*lpole+1)*(nnmax+1),parallel%group_size,parallel%group_comm)

  tmp = four * grid%hcub / pbc%latt_vec(1,1)
  qmn = qmn * tmp
#ifdef DEBUG
  write(9,*) ' multipoles : '
  do nn = 0, nnmax
     do mm = -lpole, lpole
        write(9,*) mm,nn,real(qmn(mm,nn))
     enddo
  enddo
#endif
  !
  !  Start with the boundary rho (brho) equal to 8*pi*rho.
  !
  do ii = parallel%irows(parallel%group_iam), &
       parallel%irows(parallel%group_iam+1)-1
     brho(ii-ioffset) = rho(ii-ioffset)*pi8
  enddo
#ifdef DEBUG
  if (parallel%iammaster) then
     write(7,*)
     write(7,*) ' charge bounds in master PE = ',minval(brho),maxval(brho)
     write(7,*)
  endif
#endif
  !
  !  Go through each neighbour in all necessary directions
  !  (+/-x, +/-y, +/-z) for the order needed.
  !
#ifdef DEBUG_
  tmp1 = zero
  tmpmax = -one
  tmpmin = zero
#endif
  do ii = parallel%irows(parallel%group_iam), &
       parallel%irows(parallel%group_iam+1)-1
     do jshell = 1, norder
        do jrow = 1, lap_neibs
           !
           !  If this neighbor is outside the sphere then its neibs value
           !  will be greater than myworkdim . We can then find the position of
           !  this point and calculate its contribution to brho.
           !
           if (parallel%neibs(jrow+(jshell-1)*lap_neibs,ii-ioffset) > parallel%myworkdim) then
              rw(1) = (grid%shift(1) + grid%kx(ii)) * grid%step(1)
              rw(2) = (grid%shift(2) + grid%ky(ii)) * grid%step(2)
              rw(3) = (grid%shift(3) + grid%kz(ii)) * grid%step(3)

              select case(jrow)
              case (1)
                 rw(1) = rw(1) - grid%step(1)*jshell
              case (2)
                 rw(1) = rw(1) + grid%step(1)*jshell
              case (3)
                 rw(2) = rw(2) - grid%step(2)*jshell
              case (4)
                 rw(2) = rw(2) + grid%step(2)*jshell
              case (5)
                 rw(3) = rw(3) - grid%step(3)*jshell
              case (6)
                 rw(3) = rw(3) + grid%step(3)*jshell
              case (7)
                 rw(1) = rw(1) - grid%step(1)*jshell
                 rw(2) = rw(2) - grid%step(2)*jshell* &
                      grid%lap_dir(1)
              case (8)
                 rw(1) = rw(1) + grid%step(1)*jshell
                 rw(2) = rw(2) + grid%step(2)*jshell* &
                      grid%lap_dir(1)
              case (9)
                 rw(1) = rw(1) - grid%step(1)*jshell
                 rw(3) = rw(3) - grid%step(3)*jshell* &
                      grid%lap_dir(2)
              case (10)
                 rw(1) = rw(1) + grid%step(1)*jshell
                 rw(3) = rw(3) + grid%step(3)*jshell* &
                      grid%lap_dir(2)
              case (11)
                 rw(2) = rw(2) - grid%step(2)*jshell
                 rw(3) = rw(3) - grid%step(3)*jshell* &
                      grid%lap_dir(3)
              case (12)
                 rw(2) = rw(2) + grid%step(2)*jshell
                 rw(3) = rw(3) + grid%step(3)*jshell* &
                      grid%lap_dir(3)
              end select

              yz = rw(2) * rw(2) + rw(3) * rw(3)
              if (yz > zero) yz = sqrt(yz)
              tmp1 = one / yz
              cc = rw(2) * tmp1
              ss = rw(3) * tmp1
              ypiz(0) = zone
              ypiz(1) = cmplx(cc,ss,dpc)
              do mm = 2, lpole
                 ypiz(mm) = ypiz(mm-1) * ypiz(1)
              enddo

              cpole = zzero
              tmp = half
              tmp1 = one / yz
              do mm = 1, lpole
                 tmp = tmp * tmp1
                 cpole = cpole + qmn(mm,0) * ypiz(mm) * tmp / real(mm,dp)
#ifdef DEBUG_
                 tmpp = tmp / real(mm,dp)
                 if (tmpmax(mm,0) < zero) tmpmin(mm,0) = tmpp
                 if (tmpmin(mm,0) > tmpp) tmpmin(mm,0) = tmpp
                 if (tmpmax(mm,0) < tmpp) tmpmax(mm,0) = tmpp
#endif
              enddo

              phx(0) = zone
              phx(1) = zi * twopia * rw(1)
              phx(1) = exp(phx(1))
              do nn = 2, nnmax
                 phx(nn) = phx(nn-1) * phx(1)
              enddo

              yzn = zero
              do nn = 1, nnmax
                 yzn = yzn + twopia * yz
                 call bessel_k(lpole,yzn,pmn(0:lpole))
                 cpole = cpole + qmn(0,nn) * phx(nn) * pmn(0)
#ifdef DEBUG_
                    tmpp = pmn(0)
                    if (tmpmax(0,nn) < zero) tmpmin(0,nn) = tmpp
                    if (tmpmin(0,nn) > tmpp) tmpmin(0,nn) = tmpp
                    if (tmpmax(0,nn) < tmpp) tmpmax(0,nn) = tmpp
#endif
                 do mm = 1, lpole
                    cpole = cpole + phx(nn) * pmn(mm) * &
                         (qmn(mm,nn) * ypiz(mm) + &
                         qmn(-mm,nn) * conjg(ypiz(mm)))
#ifdef DEBUG_
                    tmpp = pmn(mm)
                    if (tmpmax(mm,nn) < zero) tmpmin(mm,nn) = tmpp
                    if (tmpmin(mm,nn) > tmpp) tmpmin(mm,nn) = tmpp
                    if (tmpmax(mm,nn) < tmpp) tmpmax(mm,nn) = tmpp
#endif
                 enddo
              enddo

              cpole = cpole + qmn(0,0) * (ln2g - &
                      log(yz/pbc%latt_vec(1,1)))*half


              !
              !  Add the contributions into brho, but scale by two
              !  (sum over positive and negative m,n) and by coeke.
              !
              brho(ii-ioffset) = brho(ii-ioffset) - &
                   two*coeke(jshell,(jrow+1)/2)*real(cpole,dp)
#ifdef DEBUG_
              tmp1 = tmp1 - two*coeke(jshell,(jrow+1)/2)*real(cpole,dp)
              do mm = -lpole, lpole
              enddo
#endif
           endif
        enddo               ! jrow = 1, lap_neibs
     enddo                  ! jshell = 1, norder
  enddo
#ifdef DEBUG_
  ! Check charge neutrality
  call psum(tmp1,1,parallel%group_size,parallel%group_comm)
  if (parallel%iammaster) then
     write(7,*) ' charge bounds in master PE = ',minval(brho),maxval(brho)
     write(7,*) ' net boundary correction = ',tmp1/pi8
     write(7,*)
  endif
#endif
#ifdef DEBUG_
  write(9,*) ' bounds : '
  do nn = 0, nnmax
     do mm = 0, lpole
        write(9,*) mm,nn,tmpmin(mm,nn)*real(qmn(mm,nn)), &
             tmpmax(mm,nn)*real(qmn(mm,nn))
     enddo
  enddo
#endif

  deallocate(phx)
  deallocate(qmn)
#ifdef DEBUG
  deallocate(tmpmax)
  deallocate(tmpmin)
#endif

end subroutine hartset_wire













!===============================================================
!
!  Boundary conditions and builder of charge distribution for 
!  2-dimensional (slab) systems.
!
!  Generaly based on the calculation of the potential outside a sheet
!  of periodic charges, as described by Lenard-Jones & Dent, 
!  "Cohesion at a crystal surface", Trans. Faraday Soc, 1927
!
! author: Ayelet Mor (2007)
! 
!---------------------------------------------------------------
subroutine hartset_slab(grid, pbc, parallel, norder, lpole, &
        coeke, rho, brho)

use constants
use grid_module
use pbc_module
use parallel_data_module
use psum_module
use aux, only : cos_lm, sin_lm, alccheck
use external_interfaces, only : dcopy
implicit none
  
!
!  Input/Output variables:
!  -----------------------
  
!  grid related data
type (grid_data), intent(in) :: grid

!  periodic boundary conditions data
type (pbc_data), intent(inout) :: pbc

!  parallel computation related data
type (parallel_data), intent(in) :: parallel

!  number of neighbors used for derivation (on one side)
integer, intent(in) :: norder

!  order of multipole expansion
integer, intent(in) :: lpole

!  coefficients for taking a second derivative
real(dp), intent(in) :: coeke(-norder:norder,3+grid%lap_dir_num)

!  charge density on the 3-d grid
real(dp), intent(in) :: rho(parallel%ldn)

!  effective charge density = original charge density augmented by
!  appropriate boundary terms, to be used as the source term in hpotcg
real(dp), intent(out) :: brho(parallel%ldn)
  
!
!  Work variables:
!  ---------------

!  offset for each processor
integer :: ioffset

!  deta = det(latt_vec)
real(dp) :: deta

!  twopia = 2 * pi / deta
real(dp) :: twopia

! nzmax = grid%nzmax - grid%norder
integer :: nzmax

! nzmin = grid%nzmin + grid%norder
integer :: nzmin

!  nz = nzmax - nzmin + 1
integer :: nz

! nzneighs = grid%nzmax - grid%nzmin + 1
integer :: nzneighs

!  lap_neibs = 2*( 3 + grid%lap_dir_num)
integer :: lap_neibs

!  Variables for each grid point (labeled by j)
real(dp) :: &    
        rrho, &         ! = rho(j)
        rr(2)           ! vector of (u(j), v(j))

! index variables
integer :: &
        izz, &          ! = z(j)/grid%step(3)
        izdiff          ! = abs(z(j) - Z(neighbor(j))/grid%step(3)
 
!  Vectors of the fourier expansion
!  klm(l,m) = l*b1 + m*b2  where b1,b2 are the reciprocal lattice vectors
!  kklm(l,m) = |klm(l,m)|
!  so that klm(l,m) = -klm(-l,-m); klm(-l,m) = -klm(l,-m)
!
!  in practice, since klm is used only to be multiplied by r,
!  klm(l,m) is set to be (l,m) and r is (u,v) instead of the 
!  correct form where klm = (l,m)*(b1,b2), r = (u,v)*(a1,a2)
!  since b_i*a_j = 2pi*delta_ij

real(dp) :: klm(-lpole:lpole, 0:lpole, 2)
real(dp) :: kklm(-lpole:lpole, 0:lpole)

!  Temporary storage of the sine and cosine functions
real(dp) :: clm(-lpole:lpole, 0:lpole)
real(dp) :: slm(-lpole:lpole, 0:lpole)

!  Multipoles (one for the sine part and one for the cosine part)
!  qslm(izz) = sum(rho(j) * slm(j,l,m)) on all points j with height zz
!  qclm(izz) = sum(rho(j) * clm(j,l,m)) on all points j with height zz

real(dp), allocatable :: qslm(:,:,:),qclm(:,:,:)

!  Z axis exponents
!  tlm(l,m,zdiff) = exp(-kklm(l,m)*zdiff)

real(dp), allocatable :: tlm(:,:,:)

!  Contribution to the boundary potential (the contribution should
!  be real, since the summation is over real functions).
real(dp) :: cpole

!  Average charge density for each xy plane in the slab

real(dp), allocatable :: sigma(:), sig_counter(:)

!  other counters
integer ii,ll,mm,zindex,i_lap_dir,jshell

!  temporarly variables
real(dp) :: tmp(3)
!real(dp) :: rs(3)
real(dp) :: tmp2
real(dp) :: vect1(2), vect2(2)
character(len=4) :: idstring
integer :: memcount, alcstat

!  constants
real(dp), parameter :: pi8 = eight*pi
real(dp), parameter :: pi2 = two*pi

! --------------------------------------------------------------


!
! initialize variables
!
write(idstring,'(I4.4)') parallel%iam
!open(unit=15, file='cpole.dat.'//idstring, form='formatted')
!open(unit=16, file='qclm.dat.'//idstring, form='formatted')

lap_neibs = 2*( 3 + grid%lap_dir_num )
deta = abs(pbc%latt_vec(1,1)*pbc%latt_vec(2,2) - &
        pbc%latt_vec(2,1)*pbc%latt_vec(1,2))
twopia = pi2 / deta

nzmax = grid%nzmax - grid%norder 
nzmin = grid%nzmin + grid%norder + 1
nz = nzmax - nzmin + 1
nzneighs = grid%nzmax - grid%nzmin + 1

ioffset = parallel%irows(parallel%group_iam) - 1
  
!  Allocate arrays that need to be allocated
memcount =(lpole-(-lpole)+1) * (lpole-0+1) * &
        ((grid%nzmax-grid%norder)-(grid%nzmin+grid%norder)+1)
allocate(qslm(-lpole:lpole, 0:lpole, & 
        grid%nzmin+grid%norder:grid%nzmax-grid%norder), &
        stat=alcstat)
call alccheck('qslm',memcount,alcstat)

memcount =(lpole-(-lpole)+1) * (lpole-0+1) * &
        ((grid%nzmax-grid%norder)-(grid%nzmin+grid%norder)+1)
allocate(qclm(-lpole:lpole, 0:lpole, & 
        grid%nzmin+grid%norder:grid%nzmax-grid%norder), &
        stat=alcstat)
call alccheck('qclm',memcount,alcstat)

memcount =(lpole-(-lpole)+1) * (lpole-0+1) * (grid%nzmax-grid%nzmin+2)
allocate(tlm(-lpole:lpole, 0:lpole, 0:(grid%nzmax-grid%nzmin+1)), &
        stat=alcstat)
call alccheck('tlm',memcount,alcstat)

memcount = ((grid%nzmax-grid%norder)-(grid%nzmin+grid%norder)+1)
allocate(sigma(grid%nzmin+grid%norder:grid%nzmax-grid%norder), &
        stat=alcstat)
call alccheck('sigma',memcount,alcstat)

memcount = ((grid%nzmax-grid%norder)-(grid%nzmin+grid%norder)+1)
allocate(sig_counter(grid%nzmin+grid%norder:grid%nzmax-grid%norder), &
        stat=alcstat)
call alccheck('sig_counter', memcount, alcstat)
  
!
!  Zero out all the arrays
!

brho(:) = zero
klm(:,:,:) = zzero
kklm(:,:) = zzero
clm(:,:) = zzero
slm(:,:) = zzero
qclm(:,:,:) = zzero
qslm(:,:,:) = zzero
tlm(:,:,:) = zzero
sigma(:) = zero
sig_counter(:) = zero

!
! Define the klm and kklm tables.
!

vect1 = (/1,0/) * pi2/(sqrt(dot_product(pbc%latt_vec(:,1), pbc%latt_vec(:,1))))
vect2 = (/0,1/) * pi2/(sqrt(dot_product(pbc%latt_vec(:,2), pbc%latt_vec(:,2))))

do ll = -lpole, lpole
do mm = 1, lpole
        klm(ll,mm,:) = ll*vect1 + mm*vect2 
        tmp = ll*pbc%bvec(:,1) + mm*pbc%bvec(:,2)
        kklm(ll,mm) = sqrt(dot_product(tmp,tmp))
enddo
enddo

do ll = 1, lpole
        tmp = ll*pbc%bvec(:,1)
        tmp2 = sqrt(dot_product(tmp,tmp))
        klm(ll,0,:) = ll*vect1
        kklm(ll,0) = tmp2
enddo


!
!  Build the qclm and qslm tables.
!  add in the contribution of every grid point we have data for.
!  build the tables for each izz height.

do ii = parallel%irows(parallel%group_iam), &
        parallel%irows(parallel%group_iam+1)-1

        rrho = rho(ii-ioffset)

        ! Convert from 1d indexing to 3d indexing (u,v,z)
        rr(1) = (grid%shift(1) + grid%kx(ii)) * grid%step(1)
        rr(2) = (grid%shift(2) + grid%ky(ii)) * grid%step(2)
        izz = grid%kz(ii)

        ! Initiate the clm and slm tables for the given grid point
        call cos_lm(rr,lpole,klm,clm(-lpole:lpole, 0:lpole))
        call sin_lm(rr,lpole,klm,slm(-lpole:lpole, 0:lpole))


        ! Fill in the qslm & qclm tables, without the case of (ll,mm)=(0,0)
        do ll = -lpole, lpole
        do mm = 1, lpole
                qclm(ll,mm,izz) = qclm(ll,mm,izz) + rrho * clm(ll,mm)
                qslm(ll,mm,izz) = qslm(ll,mm,izz) + rrho * slm(ll,mm)
        enddo
        enddo

        do ll = 1, lpole
                qclm(ll,0,izz) = qclm(ll,0,izz) + rrho * clm(ll,0)
                qslm(ll,0,izz) = qslm(ll,0,izz) + rrho * slm(ll,0)
        enddo
enddo


! 
! Global sum for colecting the qclms and qslms from each processor.
!  
call psum(qclm,(2*lpole+1)*(lpole+1)*(nz), &
        parallel%group_size,parallel%group_comm)
call psum(qslm,(2*lpole+1)*(lpole+1)*(nz), &
        parallel%group_size,parallel%group_comm)

  !
  ! Multiply each qslm, qclm by twopia/kklm(ll,mm)
  ! 

  do ll = -lpole, lpole
     do mm = 1, lpole
    tmp2 = one / kklm(ll,mm)
    qclm(ll,mm,:) = qclm(ll,mm,:) * tmp2
    qslm(ll,mm,:) = qslm(ll,mm,:) * tmp2
     enddo
  enddo

  do ll = 1, lpole
     tmp2 = one / kklm(ll,0)
     qclm(ll,0,:) = qclm(ll,0,:) * tmp2
     qslm(ll,0,:) = qslm(ll,0,:) * tmp2
  enddo

  qclm = qclm * twopia 
  qslm = qslm * twopia


  
  !
  ! Build the average charge density table

  do ii = parallel%irows(parallel%group_iam), &
       parallel%irows(parallel%group_iam+1)-1
     izz = grid%kz(ii)
     rrho = rho(ii-ioffset)
     if (izz > (nzmin-1) .and. izz < (nzmax+1)) then
    sig_counter(izz) = sig_counter(izz) + 1
    sigma(izz) = sigma(izz) + rrho
     endif
  enddo

  !
  ! Global sum for colecting the sigmas from each processor.
  ! and calculate the average on each zz.

  call psum(sigma,nz,parallel%group_size,parallel%group_comm)
  call psum(sig_counter,nz,parallel%group_size,parallel%group_comm)

  ! The potential created by the average desity equals -2pi*avg_sigma*zdiff
  ! and that should be multiplied by the z axis grid step.

  do zindex = nzmin, nzmax
     if (sig_counter(zindex) > 0) then
        sigma(zindex) = -pi2*grid%step(3)*sigma(zindex)/sig_counter(zindex)
     endif
  enddo


  !
  ! Build the tlm table for zdiff exponents
  ! add in all the coefficients for the potential - 2*hcub
  
  do ll = -lpole, lpole
      do mm = 1, lpole
 do zindex = 1, nzneighs-1
    tlm(ll,mm,zindex) = exp(-kklm(ll,mm)*zindex*grid%step(3))
 enddo
 tlm(ll,mm,0) = 1
      enddo
  enddo

  do ll = 1, lpole
     do zindex = 1, nzneighs-1
tmp2 = exp(-kklm(ll,0)*zindex*grid%step(3)) ! kklm(-ll,0) = kklm(ll,0)
tlm(ll,0,zindex) = tmp2
tlm(-ll,0,zindex) = tmp2
     enddo
     tlm(ll,0,0) = 1
     tlm(-ll,0,0) = 1
  enddo

  tlm = tlm * grid%hcub * two

  !
  ! Start with the boundary rho (brho) that equals 8*pi*rho
  ! (4pi because of the poisson's equation 
  ! and 2 to transfer from Hartree to Rydberg)
  do ii = parallel%irows(parallel%group_iam), &
       parallel%irows(parallel%group_iam+1)-1
     brho(ii-ioffset) = rho(ii-ioffset)*pi8
  enddo

  !
  !  Theoreticaly, We need to go through each neighbour in all 
  !  necessary directions (+/-x, +/-y, +/-z) for the order needed.
  !  In practice, only the +/-z directions are of interest in this case. 
  !
  
do ii = parallel%irows(parallel%group_iam), &
        parallel%irows(parallel%group_iam+1)-1
do jshell = 1, norder
do i_lap_dir = 5, 6  
        !
        !  If this neighbor is outside the sphere then its neibs value
        !  will be greater than ndim. We can then find the position of
        !  this point and calculate its contribution to brho.
        !
        if (parallel%neibs(i_lap_dir+(jshell-1)*lap_neibs,ii-ioffset) > &
                parallel%myworkdim) then

                rr(1) = (grid%shift(1) + grid%kx(ii)) * grid%step(1)
                rr(2) = (grid%shift(2) + grid%ky(ii)) * grid%step(2)
                izz = grid%kz(ii)

                select case(i_lap_dir)
                case (5)
                        izz = izz - jshell
                case (6)
                        izz = izz + jshell
                end select

                cpole = zero

                ! Initiate the clm and slm tables for the given grid point
                call cos_lm(rr,lpole,klm,clm(-lpole:lpole, 0:lpole))
                call sin_lm(rr,lpole,klm,slm(-lpole:lpole, 0:lpole))

                do zindex = nzmin, nzmax
                        izdiff = abs(izz - zindex)
                        cpole = cpole + sigma(zindex)*izdiff*grid%step(3)

                        do ll = -lpole, lpole
                        do mm = 1, lpole
                                tmp2 = clm(ll,mm)*qclm(ll,mm,zindex) + &
                                slm(ll,mm)*qslm(ll,mm,zindex)
                                cpole = cpole + tlm(ll,mm,izdiff)*tmp2
                        enddo
                        enddo

                        do ll = 1, lpole
                                tmp2 = clm(ll,0)*qclm(ll,0,zindex) + &
                                        slm(ll,0)*qslm(ll,0,zindex)
                                cpole = cpole + tlm(ll,0,izdiff)*tmp2
                        enddo
                enddo


                !
                !  Add the contributions into brho, but scale by 2 for Rydberg
                !  and by coeke (second derivative of the potential-
                !  to obtain the denity)
                !
                brho(ii-ioffset) = brho(ii-ioffset) - &
                        two*coeke(jshell,(i_lap_dir+1)/2)*cpole

                !rs(1) = (grid%shift(1) + grid%kx(ii)) * grid%step(1)
                !rs(2) = (grid%shift(2) + grid%ky(ii)) * grid%step(2)
                !rs(3) = (grid%shift(3) + grid%kz(ii)) * grid%step(3)
                ! write(15,106) rs(1), rs(2), rs(3), jshell,   cpole
        endif

enddo ! i_lap_dir
enddo ! jshell
enddo ! ii




! deallocate temp work arrays

if (allocated(qslm)) deallocate(qslm)
if (allocated(qclm)) deallocate(qclm)
if (allocated(tlm)) deallocate(tlm)
if (allocated(sigma)) deallocate(sigma)
if (allocated(sig_counter)) deallocate(sig_counter)


!106 format(3(f15.2,1x),(i,1x),3(f15.9,1x))
!107 format(f15.2, 1x, 2(i,1x), 2(e15.7,1x))
!close(15)
!close(16)

end subroutine hartset_slab







!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  This subroutine calls subroutines to set up the Hartree
!  potential and solve Poisson's equation from a known charge
!  density.
!
!---------------------------------------------------------------
subroutine rho_hart(grid, pot, rsymm, parallel, elec_st, pbc, lpole, ipr, iswf, exc)

use constants
use grid_module
use potential_module
use symmetry_module
use stencil_things
use parallel_data_module
use electronic_struct_module
use pbc_module
use psum_module
use exc_module
use libxc_module
use paux, only : potshift
use external_interfaces, only : dcopy
use hpot_g_module, only : hpot_g

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_allreduce, mpi_double_precision, &
        mpi_max, mpi_min
#else
use mpi
#endif
#endif

implicit none

!  Input/Output variables:

!  grid related data
type(grid_data), intent(in) :: grid

!  potential related data
type(potential), intent(inout) :: pot

!  symmetry operations in reduced group:
type(symmetry), intent(in) :: rsymm

!  parallel computation related data
type(parallel_data), intent(inout) :: parallel

!  electronic structure
type(electronic_struct), intent(inout) :: elec_st

!  periodic boundary conditions data
type(pbc_data), intent(inout) :: pbc

!  order of multipole expansion
integer, intent(in) :: lpole

!  print flag
integer, intent(in) :: ipr

!  are wf functions initialsed flag
integer, intent(in) :: iswf

!  total exchange-correlation energy
real(dp), intent(out) :: exc

!  Work variables:

!  counters
integer :: isp, i, idx

!  temporary variables
real(dp) :: rhoav, vxcav
!real(dp) :: rhoav_test

!  maximum and minimum values of charge density, in [e/bohr^3]
real(dp), dimension(elec_st%nspin) :: dmax, dmin, dtmp

!  work array
real(dp), dimension(:), allocatable :: rho

!  spin descriptor
character(len=2) :: idsp(elec_st%nspin)

!  boundary rho from multipole expansion
real(dp), allocatable :: brho(:)

!  work array for Hartree CG - and gradients in exc! fix this!!!
real(dp), allocatable :: vect(:)

!  allocation check
integer alcstat

!  printout flag
logical :: prflag

#ifdef USE_LIBXC 
!  func_id for pbe mgga (initial guess)
integer :: func_pbe(2)
#endif

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif
#endif

! ---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

allocate(rho(parallel%ldn))
rho(:) = dzero



! Retrieve the current charge density
call dcopy(int(parallel%mydim, mymklint), elec_st%rho(:,1), 1_mymklint, rho(:), 1_mymklint)

! Set spin identifier
do isp = 1, elec_st%nspin
        if (isp-1+elec_st%nspin == 1) idsp(isp) = '  '
        if (isp-1+elec_st%nspin == 2) idsp(isp) = 'up'
        if (isp-1+elec_st%nspin == 3) idsp(isp) = 'dn'
enddo



allocate(vect(parallel%myworkdim+1), stat=alcstat)
call alccheck('vect', parallel%myworkdim+1, alcstat)
vect(:) = zero
allocate(brho(parallel%ldn), stat=alcstat)
call alccheck('brho', parallel%ldn, alcstat)
brho(:) = zero



select case(pbc%per)
case (0)
        !  For confined systems, set boundary condition for Hartree
        !  potential.
        call hartset(grid, rsymm, parallel, grid%norder, lpole, &
                grid%coe2(:,:), rho(:), pot%clm, brho(:))
case (1)
     !  For wire/tube systems, set boundary condition for Hartree
     !  potential. Include the monopole contribution but ignore the
     !  logarithmic divergence (it will be cancelled by the ion-ion
     !  energy and local pseudopotentials).
     call hartset_wire(grid,pbc,rsymm,parallel,grid%norder,lpole &
          ,grid%coe2,rho,brho)
case (2)
     !  For slab systems, set boundry condition for Hartree potential.
     !  Include the dipole contribution.
     call hartset_slab(grid,pbc,parallel,grid%norder,lpole &
        ,grid%coe2,rho,brho)
case (3)
        if (elec_st%explicit_hartree_pbc) then
                ! for testing purposes - obtain the hartree potential using FFT
                ! do I use rho or brho?
                write(9,*) ' Oh boy, obtaining the Hartree potential in reciprocal space '
                call hpot_G(elec_st,grid,pbc,parallel,elec_st%rho,rho)
                ! rho now contains v_hart on the grid
        else
                ! Do it numerically

                !  For periodic system, find the average charge density and
                !  subtract it out to make the average zero.

                rhoav = elec_st%xele/(grid%hcub*parallel%ndim)

                ! write(9,*) ' 3D periodic system, setting the average of the charge density to zero '
                ! write(9,*) ' straightforward rhoav =',rhoav

                ! write(9,*) ' testing via averaging over rho '

#ifdef AJB_DEBUG
               rhoav_test = sum(rho(1:parallel%mydim))
               call psum(rhoav_test,1,parallel%group_size,parallel%group_comm)
               write(9,*) ' is this the correct total charge?=',rhoav_test
               rhoav_test = rhoav_test/real(parallel%ndim)
               write(9,*) ' average charge total*vcell =',rhoav_test*pbc%vcell
#endif

                !     brho(:) = zero !since it was commented above, it should be
                !     !noted that brho is not initalized anymore,
                !     !so it is proper that we make sure the last remaining elements are zeroed out
                brho(parallel%mydim+1:parallel%ldn) = zero

             !  Also, multiply the result by 8*pi in preparation for the
             !  Poisson solver (4*pi coming from the form of the equation, 2
             !  from changing Hartree to Rydberg).

             brho(1:parallel%mydim) =  &
                  (rho(1:parallel%mydim) - rhoav)*pi*eight

              ! write(9,*) ' now testing via averaging over b-rho '

              ! rhoav_test = sum(brho(1:parallel%mydim))
              ! call psum(rhoav_test,1,parallel%group_size,parallel%group_comm)
              ! write(9,*) ' is this the correct new total charge?=',rhoav_test
              ! rhoav_test = rhoav_test/real(parallel%ndim)
              ! write(9,*) ' is this the correct average?=',rhoav_test
        endif
end select






if (.not. elec_st%explicit_hartree_pbc) then
        !  Retrieve the current Hartree potential and use it as initial
        !  guess for the Poisson solver. If there is no available Hartree
        !  potential, use the negative of the local pseudopotential.
        !
        !  AJB: this check is wasteful. should be a flag.
        if (abs(sum(pot%vhart(:))) < twomach_eps) then
                write(9,*) ' init Hartree guess, starting from Vlocal '

                call dcopy(parallel%mydim, pot%vion(:), 1, rho(:), 1)

                ! wouldn't it be better to start form the laplacian of vion?
                rho(:) = -rho(:)
        else
                call dcopy(parallel%mydim, pot%vhart(:), 1, rho(:), 1)
        endif
      
        if (ipr >= 0) write(9,*) ' hpotcg start'

        !call hpotcg(parallel,brho,rho,grid%norder,grid%coe2, grid%lap_dir_num,vect)
        !call hpotcg(parallel,brho,rho,grid%sten_def,grid%sten_coeff)
        call hpotcg(parallel, brho(:), rho(:), grid%sten_coeff, ipr)

        if (ipr >= 0) write(9,*) ' done hpotcg'
!else
        ! rho already contains hartree potential done explicitly
endif

deallocate(brho)





!  Store the Hartree potential.
call dcopy(parallel%mydim, rho(:), 1, pot%vhart(:), 1)

if (allocated(rho)) deallocate(rho)





!  Although this subroutine is called rho_har...
!
!  Compute the exchange-correlation potential.
!
! start by adding rhoc to rho and storing as vxc.
!
!  "Vxc is used as core-corrected charge on input"
!   try not to be confused by the use of vxc as charge density
!
!  and exchange-correlation potential on output.
!
! there should be a check here like in corecd, so this won't happen
! all the time
if (elec_st%nspin == 1) then
        do i = 1, parallel%mydim
                pot%vxc(i,1) = elec_st%rho(i,1) + elec_st%rhoc(i)
                if (pot%fex_is) pot%vxc(i,1) = pot%vxc(i,1) + pot%rho0(i)
        enddo
else
        do isp = 1, elec_st%nspin
                idx = isp + 1

                do i = 1, parallel%mydim
                        pot%vxc(i,isp) = elec_st%rho(i,idx) + half*elec_st%rhoc(i)
                enddo
        enddo
endif





!  Find max and min values of the charge density and report
!  warn (but do not kill) if negative values found.
dmax(:) = maxval(pot%vxc(:,:), 1)
dmin(:) = minval(pot%vxc(:,:), 1)

#ifdef MPI
call mpi_allreduce(dmax(:), dtmp(:), elec_st%nspin, mpi_double_precision, &
        mpi_max, colgroup_comm_f08, mpinfo)
dmax(:) = dtmp(:)

call mpi_allreduce(dmin(:), dtmp(:), elec_st%nspin, mpi_double_precision, &
        mpi_min, colgroup_comm_f08, mpinfo)
dmin(:) = dtmp(:)
#endif

if (parallel%iammaster) then
        if (ipr >= 0) then
                do isp = 1, elec_st%nspin
                        write(7,12) dmax(isp), dmin(isp), idsp(isp)
12 format(/,' Max and min values of charge density [e/bohr^3]:',2x,e11.4,2x,e11.4,3x,a2)
                enddo
        endif

        if (minval(dmin(:)) < zero) then
                write(7,*) 'WARNING : NEGATIVE CHARGE DENSITY FOUND!'
        endif
endif



!calculate the xc using libxc or the parsec implemented one
if (elec_st%use_libxc) then
#ifdef USE_LIBXC 
 !if its an orbital functional (meanwhile only mgga) and its first iteration do pbe instead
        if(iswf == 0)then ! .and. (xc_f03_func_info_get_family(xc_info) == XC_FAMILY_mGGA) then
               func_pbe = (/101,130/)
               call libxc(grid,parallel,elec_st%nrep,elec_st%nspin,func_pbe,pot%vxc,vect,exc,elec_st)
        else  
               call libxc(grid,parallel,elec_st%nrep,elec_st%nspin,elec_st%func_id,pot%vxc,vect,exc,elec_st)
        endif

#endif

     else
        if (elec_st%nspin == 1) then
           call exc_nspn(grid, parallel, elec_st%nrep, elec_st%icorr, &
                elec_st%dioniz, pot%vxc(:,1), vect(:), exc, pot)
        else
           call exc_spn (grid, parallel, elec_st%nrep, elec_st%nspin,elec_st%icorr, &
                elec_st%dioniz, pot%vxc(:,:), vect(:), exc)
        endif
endif





!
!  If periodic boundary conditions are used, shift vxc uniformly so that
!  its average is set to zero; do the same for vhart.
!
if (pbc%per == 3) then
        prflag = .false.

        if (ipr >= 0 .and. parallel%iammaster) prflag = .true.
        !if (ipr >= 1 .and. parallel%iammaster) prflag = .true.

        do isp = 1, elec_st%nspin
                call potshift(pbc%vcell, grid%hcub, elec_st%nrep, &
                        parallel%mydim, parallel%nprow, &
                        parallel%colgroup_comm, pot%vxc(:,isp), vxcav)

                if (prflag) then
                        write(7,'(/,a,2x,f20.8,2x,a2)') &
                                ' Average exchange-correlation potential [Ry]:', &
                                vxcav, idsp(isp)
                endif
        enddo

        call potshift(pbc%vcell, grid%hcub, elec_st%nrep, parallel%mydim, &
                parallel%nprow, parallel%colgroup_comm, pot%vhart(:), vxcav)

        if (prflag) then
                write(7,'(a,2x,f20.8,/,a)') &
                        ' Average Hartree potential [Ry]:', vxcav, &
                        ' Attention: Average potentials reset to zero.'
        endif
endif

if (allocated(vect)) deallocate(vect)

end subroutine rho_hart














!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  Use Conjugate Gradient method to compute the Hartree Potential.
!  Input is the charge distribution rho(r) and an initial guess for
!  the output potential.
!  Output is the Hartree potential V(r), defined as:
!
!      Laplacian[ V(r) ] = -4*pi * 2 * rho(r)
!                        = integral_r' 2 * rho(r')/|r - r'|
!
!      4*pi factor comes from the Laplace equation.
!      Factor of 2 comes from the hartrees -> rydbergs unit conversion.
!
!---------------------------------------------------------------
subroutine hpotcg(parallel, rho, pot, sten_coeff, ipr)

use constants
use parallel_data_module
use stencil_things
use dbuffer_module
use aux, only : mysecond, alccheck
use cg_module, only : cg
use laplacian_ops_module, only : laplacian_fold, my_laplacian
use external_interfaces, only : dcopy

implicit none



!  Input/Output variables:

!  parallel computation related data
type(parallel_data), intent(in) :: parallel

!!!  type (stencil_definitions), intent(in) :: true_sten_def
type(fold_stencil), intent(in) :: sten_coeff
integer, intent(in) :: ipr

!  the input eletron distribution
!real(dp), intent(in) :: rho(parallel%mydim)
real(dp), dimension(parallel%ldn), intent(in) :: rho

!  pot == on entry it contains the initial guess of the potential;
!         on output it contains the solution found.
real(dp), dimension(parallel%ldn), intent(inout) :: pot



!  Work variables:

integer, parameter :: kss0 = 6

integer :: i, ipar(16), numlap
!integer :: numcg

!  allocation check
integer :: alcstat

real(dp), dimension(:), allocatable :: wk, wk2, wktest
real(dp) :: fpar(16)
real(dp) :: hpotcg_t1 !< end time
real(dp) :: hpotcg_t0 !< start time

!type(stencil_definitions) :: sten_def
type(fold_buffer) :: fold_buf

#ifdef DEBUG
!
!  External functions:
!
real(dp), external :: dnrm2
#endif


type(lap_buffer) :: lap_buf
real(dp), allocatable :: vect(:)


! ---------------------------------------------------------------

!
!  Set up the parameter arrays.
!
! write(9,*) "hello from hpotcg, mydim:",parallel%mydim
numlap = 0 !debug
! numcg = 0 !debug



ipar(1) = 0 !init solver 
ipar(2) = 0 !no preconditioning
ipar(3) = 1 !stopping criteria
ipar(4) = kss0*parallel%mydim !number of elements in w array (CG=5*n)
ipar(5) = 5 !size of krylov subspsace (not needed for CG)
ipar(6) = 2400 !new max num matvec operations (was:800, was:1600)

!fpar(1) = 1.0d-6 !relative tolerance
!fpar(1) = 1.0d-7 !relative tolerance
fpar(1) = 1.0d-13 !relative tolerance
!fpar(2) = 1.0d-12 !absolute tolerance
fpar(2) = 1.0d-13 !absolute tolerance
fpar(11) = zero !initialization for correct flops count, I think it should be integer



call mysecond(hpotcg_t0)

allocate(wk(kss0*parallel%mydim), stat=alcstat)
call alccheck('hpotcg_wk', kss0*parallel%mydim, alcstat)
allocate(wk2(parallel%ldn+1), stat=alcstat)
call alccheck('hpotcg_wk2', parallel%ldn+1, alcstat)

if (sten_coeff%lap_dir_num > 0) then
        allocate(vect(parallel%myworkdim+1), stat=alcstat)
        call alccheck('vect', parallel%myworkdim+1, alcstat)
        vect(:) = zero
endif





!$OMP PARALLEL SHARED(wk,wk2)

!$OMP DO SIMD
do i = 1, kss0*parallel%mydim
        wk(i) = zero
enddo
!$OMP END DO SIMD

!$OMP DO SIMD
do i = 1, parallel%ldn+1
        wk2(i) = zero
enddo
!$OMP END DO SIMD

!$OMP END PARALLEL




!Initialize lap buffers for communications
#ifdef DEBUG
if (parallel%nprow > 1) then
        call init_lap_buffer(lap_buf)
        call allocate_lap_buffer(lap_buf, parallel)
endif
#endif

if (parallel%nprow > 1) then
        if (sten_coeff%lap_dir_num > 0) then
                call init_lap_buffer(lap_buf)
                call allocate_lap_buffer(lap_buf, parallel)
        else
                call fold_buf%init()
                call fold_buf%alloc(parallel, foldvol=sten_coeff%foldsize)
        endif
endif




! make a copy of true_sten_def because we strip symmetry out in the laplacian call
!!!  sten_def = true_sten_def

do ! main cg loop
        !calls cg from sparskit 
        !write(9,*) "into cg call, ipar(10)", ipar(10)
        if (sten_coeff%lap_dir_num > 0) then
                ! KHL: Let us use parallel%colgroup_comm_topo for now since
                !      I have not created parallel%colgroup_comm_c_topo yet
                call cg(parallel%mydim, kss0, rho(:), pot(:), ipar(:), fpar(:), &
                        wk(:), parallel%nprow, parallel%colgroup_comm_topo)
        else
                call cg(parallel%mydim, kss0, rho(:), pot(:), ipar(:), fpar(:), &
                        wk(:), parallel%nprow, parallel%colgroup_comm_c_topo)
        endif
        !write(9,*) "done cg , ipar(1):",ipar(1)


        if (ipar(1) == 1) then
                ! write(9,*) "doing dcopy, ipar(8):",ipar(8)
                call dcopy(parallel%mydim, wk(ipar(8)), 1, wk2, 1)
                ! write(9,*) "done dcopy"

                numlap = numlap + 1

                !write(9,'("going into laplacian",x,I7,x,"ipar(9)",x,I7)') numlap,ipar(9)
                if (sten_coeff%lap_dir_num > 0) then
                        call my_laplacian(parallel, sten_coeff, &
                                lap_buf, wk2(:), wk(ipar(9)), vect(:))
                else
                        call laplacian_fold(parallel, sten_coeff, &
                                fold_buf, wk2(:), wk(ipar(9)))
                endif

                fpar(11) = fpar(11) + 74*parallel%mydim !why 74 ?
                !write(9,'("Done laplacian",x,I7)') numlap

                cycle
        !elseif (ipar(1) < 0) then !AJB: this prevented the printing of the convergence msg
        elseif (ipar(1) < 1) then
                if (ipar(1) == 0) then !how was this going to happen?
                        if (ipr >= 0) then
                                write(9,*) '# Iterative possion solver has satisfied convergence test.'
                        endif
                elseif (ipar(1) == -1) then
                        write(9,*) '# WARNING: possion solver exceeded max iterations'
                elseif (ipar(1) == -2) then
                        write(9,*) '# Oops: Iterative poisson solver was not given enough work space.'
                        write(9,*) '# The work space should at least have ', ipar(4), &
                                ' elements.'
                elseif (ipar(1) == -3) then
                        write(9,*) '# Iterative solver is facing a (nervous) break-down.'
                else
                        write(9,*) '# Iterative solver was somehow terminated. code =', ipar(1)
                endif
        endif

        exit
enddo



call mysecond(hpotcg_t1)



if (ipr >= 0) then
        write(9,'(a,i3,a,g12.4)') '# Poisson solver, return code = ', &
                ipar(1), '  convergence rate = ', fpar(7)
        ! write (9, *) '# the residual norm ', &
        !      real(dnrm2(parallel%mydim,wk,1),dp),real(fpar(5),dp)
        write(9,*) '# reported residual norm: ', real(fpar(5),dp)
        write(9,*) '# total laplacian calls:', numlap
endif

if (parallel%iammaster) write(7,'("hpotcg time [sec] :",1x,f10.2)') hpotcg_t1-hpotcg_t0




!!!#ifdef DEBUG
!!!if (parallel%group_size == 1) then
!!!    write(9,*) "verifying laplacian vs old laplacian now"
!!!  ! AJB: no point in calculating this regularly,
!!!  ! this is only correct if you are on a single core.
!!!  ! Might consider doing an allreduce and then sqrt...
!!!  !
!!!  !  Check the error.
!!!  !
!!!        numlap = numlap + 1
!!!  call laplacian(parallel,sten_def,lap_buf,pot,wk)
!!!  write(9,*) "done final laplacian, total laps:",numlap
!!!
!!!  do i = 1, parallel%mydim
!!!     wk(i) = wk(i) - rho(i)
!!!  enddo
!!!   write (9, *) '# euclidean norm of old lap(pot): ', &
!!!        real(dnrm2(parallel%mydim,wk,1),dp)
!!!
!!!  allocate(wktest(parallel%mydim),stat=alcstat)
!!!  call alccheck('hpotcg_wktest',parallel%mydim,alcstat)
!!!  write(9,*) "calling new laplacian here"
!!!  call laplacian_fold(parallel,sten_coeff,fold_buf,pot,wktest)
!!!  do i = 1, parallel%mydim
!!!     wktest(i) = wktest(i) - rho(i)
!!!  enddo
!!!   write (9, *) '# euclidean norm of new lap(pot): ', &
!!!        real(dnrm2(parallel%mydim,wktest,1),dp)
!!!
!!!        call destroy_lap_buffer(lap_buf)
!!!
!!!  endif !lap testing
!!!#endif


if (sten_coeff%lap_dir_num > 0) then
        deallocate(vect)
endif




if (allocated(wk)) deallocate(wk)
if (allocated(wktest)) deallocate(wktest)
if (allocated(wk2)) deallocate(wk2)

if (parallel%nprow > 1) then

        if (sten_coeff%lap_dir_num > 0) then
                call destroy_lap_buffer(lap_buf)
        else
                !    call destroy_lap_buffer(lap_buf)
                !  write(9,*) "done final laplacian, total laps:",numlap
                !  write(9,*) "now destroying buffer.."
                !      call myflush(9)
                call fold_buf%destroy(parallel)
                !   write(9,*) "done"
        endif
endif

end subroutine hpotcg
end module hartree_module
