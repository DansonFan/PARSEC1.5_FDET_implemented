module newrho_module

implicit none
contains

!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Updates the charge density based on the new wave functions that
! has been found after a self-consistency iteration.
!
! AJB 2015: NEEDS WORK.
!---------------------------------------------------------------
subroutine newrho(elec_st, parallel, two_invhcub)

use constants, only : dp, dpc, done, zone
use electronic_struct_module
use parallel_data_module
use external_interfaces, only : zscal, dscal, dcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_bcast, mpi_double_precision, mpi_integer, &
        mpi_comm, mpi_barrier, mpi_in_place
#else
use mpi
#endif
#endif

implicit none



! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! 2/(grid spacing)**3
real(dp), intent(in) :: two_invhcub




! 2/(h^3) if nspin=1, 1/(h^3) if nspin=2 (to account for two
! electrons or one electron in a filled state, respectively)
real(dp) :: factor

! charge density
real(dp), dimension(:,:), allocatable :: rho

! counters
integer :: irow
integer :: irow2
integer :: jcol
integer :: irp
integer :: kplp
integer :: isp
integer :: jj

integer :: kpnum
integer :: spnum
integer :: wfn_size
integer :: offset_jcol
integer :: jbegloc
integer :: jendloc

real(dp) :: dnorm
complex(dpc) :: znorm

#ifdef MPI
integer :: nelems
integer :: mpinfo
real(dp) :: rtmp
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: comm_f08
integer :: colgroup_comm_f08
#endif
#endif
 
! ---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
comm_f08 = parallel%comm
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

allocate(rho(parallel%ldn,2*elec_st%nspin-1))
rho(:,:) = zero

spnum = elec_st%nspin/elec_st%mxwd
kpnum = max(elec_st%nkpt, 1)
factor = two_invhcub/real(elec_st%nspin,dp)







#ifdef MPI
do isp = 1, spnum
        call mpi_bcast(elec_st%totel(isp), 1, mpi_double_precision, &
                parallel%masterid, comm_f08, mpinfo)

        call mpi_bcast(elec_st%ifmax(isp), 1, mpi_integer, &
                parallel%masterid, comm_f08, mpinfo)

        if (.not.elec_st%ncl)then
                do kplp = 1, kpnum
                do irp = 1, elec_st%nrep
                        nelems = elec_st%eig(irp,kplp,isp)%nn

                        if (nelems == 0) cycle

                        call mpi_bcast(elec_st%eig(irp,kplp,isp)%occ, &
                                nelems, mpi_double_precision, &
                                parallel%masterid, comm_f08, mpinfo)
                enddo
                enddo
        endif
enddo

call mpi_bcast(elec_st%totel, elec_st%nspin, mpi_double_precision, &
        parallel%masterid, comm_f08, mpinfo)
#endif








! Update charge density for both spin orientations.
! If elec_st%nspin = 1, update the total charge density.
! Also, rescale eigenvectors: norm of each vector over the *full*
! grid is 1, but eigensolvers use norm = 1 over the irreducible
! wedge. Must divide that by the ratio of volumes full/wedge.
!
do isp = 1, spnum
        jj = isp - 1 + elec_st%nspin

        do kplp = 1, kpnum
        do irp = 1, elec_st%nrep
                !
                ! Only processors belonging to the group in charge of this
                ! representation/k-point/spin should work.
                !
                if ( elec_st%eig(irp,kplp,isp)%taskgroup /= parallel%mytaskgroup ) cycle
 
                if (elec_st%cplx) then
                        znorm = zone/sqrt( real(elec_st%nrep,dp) )
                        wfn_size = size(elec_st%eig(irp,kplp,isp)%zwf)

                        call zscal(wfn_size, znorm, elec_st%eig(irp,kplp,isp)%zwf(1,1), 1)

                        if (elec_st%mxwd == 2) then

                                !AMIR - have to check this change with Doron..

                                !if (elec_st%is_so) then

                                do jcol = 1, elec_st%eig(irp,kplp,isp)%nstates_per_colgroup
                                        offset_jcol = parallel%mycolgroup*elec_st%eig(irp,kplp,isp)%nstates_per_colgroup

                                        do irow = 1, parallel%mydim
                                                ! KHL: Spin-up channel
                                                rho(irow,2) = rho(irow,2) + &
                                                        elec_st%eig(irp,kplp,1)%occ(jcol+offset_jcol)* &
                                                        abs(elec_st%eig(irp,kplp,1)%zwf(irow,jcol))**2* &
                                                        elec_st%kpwt(kplp)


                                                ! KHL: Spin-down channel
                                                irow2 = irow + parallel%mydim
                                                       
                                                rho(irow,3) = rho(irow,3) + &
                                                        elec_st%eig(irp,kplp,1)%occ(jcol+offset_jcol)* &
                                                        abs(elec_st%eig(irp,kplp,1)%zwf(irow2,jcol))**2* &
                                                        elec_st%kpwt(kplp)
                                        enddo
                                enddo
                        else

                                jbegloc = 1 + elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*parallel%mycolgroup
                                jendloc =     elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*(parallel%mycolgroup + 1)
 
                                do jcol = 1, elec_st%nstate/elec_st%nrep
                                        if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                                            elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then
 
                                                do irow = 1, parallel%mydim
                                                        rho(irow,jj) = rho(irow,jj) + &
                                                                elec_st%eig(irp,kplp,isp)%occ(jcol) * &
abs(elec_st%eig(irp,kplp,isp)%zwf(irow,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1))**2 * elec_st%kpwt(kplp)
                                                enddo
                                        endif
                                enddo
                        endif

                else   !if (elec_st%cplx) then

                        dnorm = done/sqrt( real(elec_st%nrep,dp) )
                        wfn_size = size(elec_st%eig(irp,kplp,isp)%wf)

                        call dscal(wfn_size, dnorm, elec_st%eig(irp,kplp,isp)%wf(1,1), 1)

                        ! KHL: jbegloc is the starting eigenvector of my column group in the global eigenvector array.
                        !      For example, if nstates = 80 and npcol = 8, then nstates_per_colgroup = 10.
                        !      If mycolgroup = 1 (the second column group), my jbegloc would be 11 and jendloc would be 20.
                        !
                        !      Note that in cases other than spectrum slicing, jcol_in_evec_full would be just filled with
                        !      an increasing integer, i.e., jcol_in_evec_full(1:80) = [1, 2, 3, ..., 80].
                        !      However when spectrum slicing is used, jcol_in_evec_full(:) would have a length longer than
                        !      80 (because nstates_per_colgroup of each colgroup might have been changed), and 
                        !      jcol_in_evec_full(jcol) would map the state jcol from the global index in jcol_in_evec_full 
                        !      to the original one in nstates. For example, jcol_in_evec_full(78) = 203 means that 
                        !      the state 78 in nstates is the 203rd state in the virtual global temporary array.
                        jbegloc = 1 + elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*parallel%mycolgroup
                        jendloc =     elec_st%eig(irp,kplp,isp)%nstates_per_colgroup*(parallel%mycolgroup + 1)

                        do jcol = 1, elec_st%nstate/elec_st%nrep

                                if (elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) >= jbegloc .and. &
                                    elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol) <= jendloc) then

                                        do irow = 1, parallel%mydim
                                                rho(irow,jj) = rho(irow,jj) + &
                                                        elec_st%eig(irp,kplp,isp)%occ(jcol)* &
                                                        (elec_st%eig(irp,kplp,isp)%wf(irow,elec_st%eig(irp,kplp,isp)%jcol_in_evec_full(jcol)-jbegloc+1))**2
                                        enddo
                                endif
                        enddo
                endif
        enddo
        enddo
enddo

if (elec_st%ncl) then
        do irow = 1, parallel%mydim
                rho(irow,1) = rho(irow,2) + rho(irow,3)
                rho(irow,2) = half*( rho(irow,1)+elec_st%spin3dn(irow) )
                rho(irow,3) = half*( rho(irow,1)-elec_st%spin3dn(irow) )
        enddo
endif

do jj = 1, 2*elec_st%nspin-1
        do irow = 1, parallel%mydim
                rho(irow,jj) = factor*rho(irow,jj)
        enddo

        ! Perform reduction across groups
        !
        ! KHL: Sum up and sync the electron density rho(1:mydim,jj) over 
        !      myrowgroup among all taskgroups ((irp,kplp,isp) pairs).
        !      That is, to perform allreduce(sum_op) over myoverallrowgroup.
        call group_reduction(parallel, rho(1,jj))
enddo

! update the total charge density, if elec_st%nspin = 2
if (elec_st%nspin == 2 .and. (.not. elec_st%ncl)) then
        do irow = 1, parallel%mydim
                rho(irow,1) = rho(irow,2) + rho(irow,3)
        enddo
endif

do jj = 1, 2*elec_st%nspin-1
        ! KHL: Now all arrays are of length parallel%mydim except for
        !      the wave functions
        !      rho(1,jj) was allocated of length ldn because we want to
        !      perform allreduce(sum_op). However, elec_st%rho(1,jj) is
        !      of length mydim.
        call dcopy(parallel%mydim, rho(1,jj), 1, elec_st%rho(1,jj), 1)

#ifdef MPI
        rtmp = dzero
        do irow = 1, parallel%mydim
                rtmp = rtmp + elec_st%rho(irow,jj)
        enddo
        call mpi_allreduce(mpi_in_place, rtmp, 1, mpi_double_precision, &
                mpi_sum, colgroup_comm_f08, mpinfo)
        write(9,*) "newrho: jj, sum", jj, rtmp
#endif
enddo

deallocate(rho)




end subroutine newrho













!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Symmetrize a scalar function according to symmetry
! operations.
!
! Author: Murilo Tiago (2005)
!
!---------------------------------------------------------------
subroutine symm_scalar(grid, rsymm, symm, parallel, fr, is_pbc)

use constants
use grid_module
use symmetry_module
use symmetry_routines, only : symop, symop_relative
use parallel_data_module
use aux, only : mysecond
use grid_partition_module, only : Part
use external_interfaces, only : dcopy

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_integer, &
        mpi_double_precision, mpi_allreduce, mpi_sum, mpi_max
#else
use mpi
#endif
#endif

implicit none
!
! Input/Output variables:
!
! grid related data
type (grid_data), intent(inout) :: grid
! symmetry operations
type (symmetry), intent(in) :: rsymm,symm
! parallel computation related data
type (parallel_data), intent(inout) :: parallel
! function to be symmetrized
real(dp), intent(inout) :: fr(parallel%mydim) 
! true if this system is periodic
logical, intent(in) :: is_pbc
!
! Work variables:
!
! tolerance in the position of one atom and its equivalent by
! symmetry
real(dp), parameter :: tol = 1.d-6
! buffer function
real(dp) :: ftmp(parallel%ldn)
! symmetrized function
real(dp) :: fsym(parallel%ldn)
! counters
integer :: ii,jj,igrid,isym,ipe,jpe,ngrid,ioffset,ir(3),joffset
real(dp) :: fin,dmax,rw(3),rrw(3),favg,tmp
! timers
real(dp) t0,t1,t2

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: colgroup_comm_f08
#else
integer :: colgroup_comm_f08
#endif
#endif

! ---------------------------------------------------------------

#ifdef MPI
#ifdef WITH_MPI_F08
colgroup_comm_f08%mpi_val = parallel%colgroup_comm
#else
colgroup_comm_f08 = parallel%colgroup_comm
#endif
#endif

call mysecond(t0)
!AJB: why is this even called here? 
! Isn't it a little bit weird?
!AJB: commenting this out, if this breaks anything let me know
write(9,*) "from symm_scalar: did not call grid_set_ist, if your results seems wrong let AJB know "
!call grid_set_ist(grid,parallel%group_size)




! AJB: I am trying to comment this subroutine, 
!  let me see if I understand what is going on here
fsym(:) = zero !init my end product

do ipe = 0, parallel%group_size - 1 !loop over id's
        ftmp(:) = zero !every time, zero this vector

        if (ipe == parallel%group_iam) then !if and only if the loop arrived to my "turn"
                call dcopy(parallel%mydim,fr,1,ftmp,1) !copy my portion to the buffer

                ngrid = parallel%mydim !grab the size of this portion
        endif

#ifdef MPI
        ! then - send everyone my portion, first the size - 
        call mpi_bcast(ngrid, 1, mpi_integer, ipe, colgroup_comm_f08, mpinfo)
        ! then, since max size is ldn send the entire vector to all of the mpi group members
        call mpi_bcast(ftmp, parallel%ldn, mpi_double_precision, &
                ipe, colgroup_comm_f08, mpinfo)
#endif

        ! I know where the data starts on the distributed vector using irows:
        ioffset = parallel%irows(ipe) - 1
        joffset = parallel%irows(parallel%group_iam) - 1

        ! on each grid point on this portion, 
        do ii = 1, ngrid
                fin = ftmp(ii)

                !get the coordinates for the point
                !find out why we dont use the step size for pbc,
                !probably has to do with symop_relative and the lattice vec.
                if (is_pbc) then
                        rw(1) = (grid%shift(1) + grid%kx(ii+ioffset)) / real(grid%n1,dp)
                        rw(2) = (grid%shift(2) + grid%ky(ii+ioffset)) / real(grid%n2,dp)
                        rw(3) = (grid%shift(3) + grid%kz(ii+ioffset)) / real(grid%n3,dp)
                else
                        rw(1) = (grid%shift(1) + grid%kx(ii+ioffset)) * grid%step(1)
                        rw(2) = (grid%shift(2) + grid%ky(ii+ioffset)) * grid%step(2)
                        rw(3) = (grid%shift(3) + grid%kz(ii+ioffset)) * grid%step(3)
                endif

                ! for each symmetry operation
                do isym = 1, symm%ntrans
                        if (is_pbc) then
                                call symop_relative(symm, isym, rw, rrw)

                                ! MT: Must make sure that ir is in the right cell:
                                !   -n/2 <= ir < n/2
                                ir(1) = nint(rrw(1)*real(grid%n1,dp) - grid%shift(1))
                                ir(2) = nint(rrw(2)*real(grid%n2,dp) - grid%shift(2))
                                ir(3) = nint(rrw(3)*real(grid%n3,dp) - grid%shift(3))
                                ! AJB: why on earth *15/2 ? This is probably arbitray.
                                ir(1) = mod( ir(1) + grid%n1*15/2, grid%n1) - grid%n1/2
                                ir(2) = mod( ir(2) + grid%n2*15/2, grid%n2) - grid%n2/2
                                ir(3) = mod( ir(3) + grid%n3*15/2, grid%n3) - grid%n3/2
                        else
                                call symop(symm,isym,rw,rrw)

                                do jj = 1, 3
                                        ir(jj)=nint(rrw(jj)/grid%step(jj)-grid%shift(jj))
                                enddo
                        endif

                        jpe = Part(grid,parallel,parallel%group_size,ir(1), ir(2),ir(3),.false.)

                        ! if I own this grid point or one of its images
                        if (jpe == parallel%group_iam) then
                                ! AJB: This is probably the only place where indexw is used on non-master nodes
                                igrid = grid%indexw(ir(1),ir(2),ir(3))
                                ! add the contents of this grid point to the place
                                ! where the original ipe point would have gone to
                                fsym(igrid-joffset) = fsym(igrid-joffset) + fin
                        endif
                enddo
        enddo

! AJB: no need for a barrier here.
! #ifdef MPI
!      call MPI_Barrier(parallel%group_comm,mpinfo)
! #endif

enddo



call mysecond(t1)

write(9,*) 
write(9,101) t1-t0
101 format(' symm_scalar fsym collection [sec]:',1x,f10.2)





  ! guess this is normalization 
  fsym = fsym / real(symm%ntrans,dp) * real(rsymm%ntrans,dp)
  !why are we copying this again?
  call dcopy(parallel%mydim,fr,1,ftmp,1)
  dmax = maxval(abs(fsym-ftmp))
  favg = sum(fr)
#ifdef MPI
!perhaps this is a regular reduce?
  call MPI_ALLREDUCE(favg,tmp,1,MPI_DOUBLE_PRECISION,MPI_SUM, &
          colgroup_comm_f08, mpinfo)
  favg = tmp
  call MPI_ALLREDUCE(dmax,tmp,1,MPI_DOUBLE_PRECISION,MPI_MAX, &
          colgroup_comm_f08, mpinfo)
  dmax = tmp
#endif
  if (parallel%iammaster) then !why did we go to master and not gmaster?
     write(7,1) dmax/favg*100.0
     write(7,2) favg*grid%hcub*real(rsymm%ntrans,dp)
  endif
  call dcopy(parallel%mydim,fsym,1,fr,1)

  favg = sum(fr)
#ifdef MPI
  call MPI_ALLREDUCE(favg,tmp,1,MPI_DOUBLE_PRECISION,MPI_SUM, colgroup_comm_f08, mpinfo)
  favg = tmp
#endif
  if (parallel%iammaster) then
     write(7,3) favg*grid%hcub*real(rsymm%ntrans,dp)
  endif
     call mysecond(t2)
     write(9,*) 
     write(9,102) t2-t0
102  format(' symm_scalar total time [sec]:',1x,f10.2)

1 format(' maximum deviation after symmetrization: ',f10.4,' %')
2 format(' electron charge before symmetrization: ',f10.4)
3 format(' electron charge after symmetrization: ',f10.4)

end subroutine symm_scalar
!===============================================================
end module newrho_module
