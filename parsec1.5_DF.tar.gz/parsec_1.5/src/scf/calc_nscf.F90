module calc_nscf_module

implicit none
contains

subroutine calc_nscf(nscf, elec_st, pbc, pot, u_pot, solver, parallel, &
        grid, nloc_p_pot, clust, p_pot, ipr, ierr)

use constants, only : dp, dzero, zzero
use cluster_module
use electronic_struct_module
use potential_module
use non_local_psp_module
use eigen_solver_module
use eigval_module, only : eigval, initeigval
use parallel_data_module
use pseudo_potential_module
use nscf_module
use pbc_module
use grid_module
use aux, only : matvec3, mysecond, myflush
use nonloc_module
use flevel_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_allreduce, mpi_integer, mpi_max
#else
use mpi
#endif
#endif

implicit none

!
! Input/Output variables:
!


! non selfconsistent data
type(nscf_data), intent(inout) :: nscf

! electronic structure
type(electronic_struct), intent(inout) :: elec_st

! grid
type(grid_data), intent(inout) :: grid

! pbc
type(pbc_data), intent(inout) :: pbc

! potential related data
type(potential), intent(in) :: pot

! on-site Coulomb interaction related data
type(nonloc_pseudo_potential), intent(inout) :: u_pot

! solver related data
type(eigen_solver), intent(inout) :: solver

! parallel computation related data
type(parallel_data), intent(in) :: parallel

! non local pseudo potential part
type(nonloc_pseudo_potential), intent(inout) :: nloc_p_pot

! pseudo_potential related data
type(pseudo_potential), intent(in) :: p_pot

! cluster data
type(cluster), intent(in) :: clust

! printout flag
integer, intent(in) :: ipr

! error flag, 400 < ierr < 421
integer, intent(out) :: ierr



!
! Work variables:
!

integer :: irp
integer :: kplp
integer :: isp
integer :: spnum
integer :: nrep
integer :: nmax
integer :: i
integer :: jj
integer :: ii

real(dp), dimension(3) :: ktmp

! Diagonalization timers
real(dp) :: tdiag0
real(dp) :: tdiag1
real(dp) :: tdiag_sum 

#ifdef MPI
integer :: mpinfo
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm_f08
#else
integer :: comm_f08
#endif
#endif


! -------------------------------------------------------


#ifdef MPI
#ifdef WITH_MPI_F08
comm_f08%mpi_val = parallel%comm
#else
comm_f08 = parallel%comm
#endif
#endif

tdiag_sum = dzero
spnum = elec_st%nspin/elec_st%mxwd  

!until we figure out what to do with symmetry
nrep = 1




! ==============================================
!  Destroy the old eigen_solver and eigenstates (wfns)
! ==============================================

call destroy_eigen_solver(solver)

do isp = 1, spnum
do kplp =1, max(elec_st%nkpt,1)
do irp = 1, elec_st%nrep
        call destroy_eigenstate(elec_st%eig(irp,kplp,isp))
enddo
enddo
enddo




! Set the number of k-points and number of states to the new ones
! After this, we will use elec_st%nkpt rather than nscf%nkpt
elec_st%nkpt = nscf%nkpt
elec_st%nstate = nscf%nstate
elec_st%nrep = 1

! Now change variables to fill nscf data in elec_st structure
pbc%nkpt = elec_st%nkpt
nloc_p_pot%nkpt = elec_st%nkpt






! some array initializations...

if (allocated(elec_st%kpts)) deallocate(elec_st%kpts)
allocate(elec_st%kpts(3,elec_st%nkpt))
elec_st%kpts(:,:) = nscf%kpts(:,:)

if (allocated(pbc%kpts)) deallocate(pbc%kpts)
allocate(pbc%kpts(3,pbc%nkpt))
pbc%kpts(:,:) = elec_st%kpts(:,:)

if (allocated(nloc_p_pot%kpts)) deallocate(nloc_p_pot%kpts)
allocate(nloc_p_pot%kpts(3,nloc_p_pot%nkpt))
nloc_p_pot%kpts(:,:) = elec_st%kpts(:,:)

if (allocated(elec_st%kpwt)) deallocate(elec_st%kpwt)
allocate(elec_st%kpwt(elec_st%nkpt))
elec_st%kpwt(:) = nscf%kpwt(:)

if (allocated(elec_st%magmom)) deallocate(elec_st%magmom)
allocate(elec_st%magmom(2*elec_st%nstate,elec_st%nkpt))

if (allocated(elec_st%eig)) deallocate(elec_st%eig)
allocate(elec_st%eig(elec_st%nrep,elec_st%nkpt,elec_st%nspin))

nmax = (solver%winsize + elec_st%nstate) * elec_st%nrep
allocate(elec_st%irep(nmax,elec_st%nkpt,elec_st%nspin))
elec_st%irep(:,:,:) = 1




! ==============================================
!    Calculate the FD coefficients of each k-point
! ==============================================
if (allocated(grid%kecoe1)) deallocate(grid%kecoe1)

allocate(grid%kecoe1(elec_st%nkpt,6,0:grid%norder))

grid%kecoe1(:,:,:) = zzero

do kplp = 1, elec_st%nkpt
do jj = 0, grid%norder
        call matvec3(op='T', mat=grid%grad_bvec_norm, &
                vec=elec_st%kpts(:,kplp), mvec=ktmp)

        grid%kecoe1(kplp,1:3,jj) = -2*zi*grid%coe1(jj,1:3)*ktmp
enddo
enddo



! ==============================================
!   Create the eigen_solver
!   (which will also copy grid%kecoe1 to solver%kecoe1)
! ==============================================

call create_eigen_solver(solver, grid, parallel%ldn, nrep, &
        elec_st%nspin, elec_st%nstate, elec_st%nkpt, elec_st%cplx, &
        elec_st%mxwd)




! ==============================================
!   Create the eigenstates
! ==============================================

ii = 0
do isp = 1, spnum
do kplp =1, max(elec_st%nkpt,1)
do irp = 1, elec_st%nrep
        elec_st%eig(irp,kplp,isp)%nstates = &
                elec_st%nstate + solver%winsize
        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup = &
                elec_st%nstate + solver%winsize
        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup_max = &
                elec_st%nstate + solver%winsize

        call create_eigenstate(eigen=elec_st%eig(irp,kplp,isp), &
                ldn=parallel%ldn*elec_st%mxwd, &
                nstates_per_colgroup=elec_st%nstate, &
                winsize=solver%winsize, &
                npcol=parallel%npcol, &
                cplx=elec_st%cplx)

        elec_st%eig(irp,kplp,isp)%taskgroup = ii

        ii = ii + 1

        if (mod(ii,parallel%groups_num) == 0) ii = 0

enddo
enddo
enddo




if (.not. solver%fix_num_eig) then
        call initeigval(elec_st)
endif

elec_st%eig(:,:,:)%mm = -1
elec_st%eig(:,:,:)%nn = elec_st%nstate!+solver%winsize
elec_st%eig(:,:,:)%nec = -1



if (allocated(elec_st%occ_in)) deallocate(elec_st%occ_in)
allocate(elec_st%occ_in(elec_st%nstate,spnum))




solver%maxmv = max(solver%maxmv,parallel%ldn*elec_st%nstate/elec_st%nrep)
if (parallel%iammaster) then
        write(7,*)
        write(7,*) ' Maximum number of matrix-vector operations = ', &
                solver%maxmv
        write(7,*)
endif






call nonloc(clust, grid, p_pot, nloc_p_pot, pbc, parallel, ipr, ierr)





call mysecond(tdiag0)
call eigval(elec_st, pot, u_pot, solver, parallel, ipr, ierr)
call mysecond(tdiag1)






! Report diagonlization timing.
write(9,*)
write(9,42) tdiag1-tdiag0, tdiag_sum
write(9,*)

call myflush(9)

tdiag_sum = tdiag_sum + (tdiag1-tdiag0)

if (parallel%iammaster) then
        write(7,*)
        write(7,42) tdiag1-tdiag0, tdiag_sum
        write(7,*)
        call myflush(7)
endif
42 format(' Diagonalization time [sec] :',1x,f10.2,',', &
        4x,'  tdiag_sum =',f12.2)









#ifdef MPI
i = size(elec_st%irep)
call mpi_allreduce(elec_st%irep, i, 1, mpi_integer, mpi_max, comm_f08, mpinfo)
#endif







! Finally call flevel for occupations
!
! KHL: Seems that when nscf_on is true, flevel() will do one-shot calc.
!      of the occupancy (no iterations). Need check.
if (parallel%iammaster) then
        call flevel(elec_st, pbc%latt_vec, nscf, ipr, ierr)
endif

end subroutine calc_nscf 
end module calc_nscf_module
