!>===============================================================
!! \brief Serves as an external inteface checker.
!!
!! If you use an external interface, please add it here in the
!! same style as depicted e.g. `!> \brief Interface to THING'
!!
!! This file serves as module for explicit interfaces for objects
!! that we may not have access to, usually because they don't
!! exist (F77 routines like BLAS and LAPACk)
!!
!! By keeping these separate we can add a separate layer to go
!!  between our called functions and the actual functions
!!
!! \author: Charles Lena 
!! \date 20161103
!!===============================================================
module external_interfaces

use constants, only : dp, dpc, mymklint
! BLAS
!! Level 1
!!! real*8 functions

interface



subroutine zaxpy(N, DA, DX, INCX, DY, INCY)
import :: dpc, mymklint
integer(mymklint) :: N
complex(dpc) ::  DA
complex(dpc), dimension(*) ::  DX
integer(mymklint) :: INCX
complex(dpc), dimension(*) ::  DY
integer(mymklint) :: INCY
end subroutine zaxpy

subroutine daxpy(N, DA, DX, INCX, DY, INCY)
import :: dp, mymklint
integer(mymklint) :: N
real(dp) ::  DA
real(dp), dimension(*) ::  DX
integer(mymklint) :: INCX
real(dp), dimension(*) ::  DY
integer(mymklint) :: INCY
end subroutine daxpy

subroutine dcopy(N, X, INCX, Y, INCY)
import :: dp, mymklint
integer(mymklint) :: N
real(dp), dimension(*) :: X
integer(mymklint) :: INCX
real(dp), dimension(*) :: Y
integer(mymklint) :: INCY
end subroutine dcopy

real(dp) function ddot(N, X, INCX, Y, INCY)
import :: dp, mymklint
integer(mymklint) :: N
real(dp), dimension(*) :: X
integer(mymklint) :: INCX
real(dp), dimension(*) :: Y
integer(mymklint) :: INCY
end function ddot

real(dp) function dsdot(N, X, INCX, Y, INCY)
import :: dp, mymklint
integer(mymklint) :: N
real, dimension(*) :: X
integer(mymklint) :: INCX
real, dimension(*) :: Y
integer(mymklint) :: INCY
end function dsdot

subroutine dscal(N, DA, X, INCX)
import :: dp, mymklint
integer(mymklint) :: N
real(dp) :: DA
real(dp), dimension(*) :: X
integer(mymklint) :: INCX
end subroutine




!! Level 2

subroutine dgemv(TRANS, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY)
import :: dp, mymklint
character :: TRANS
integer(mymklint) :: M
integer(mymklint) ::  N
real(dp) :: ALPHA
real(dp), dimension(lda,*) :: A
integer(mymklint) :: LDA
real(dp), dimension(*) :: X
integer(mymklint) :: INCX
real(dp) :: BETA
real(dp), dimension(*) :: Y
integer(mymklint) :: INCY
end subroutine

subroutine dgemm(TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC)
import :: dp, mymklint
character :: TRANSA
character :: TRANSB
integer(mymklint) :: M
integer(mymklint) :: N
integer(mymklint) :: K
real(dp) :: ALPHA
real(dp), dimension(lda,*) :: A
integer(mymklint) :: LDA
real(dp), dimension(ldb,*) :: B
integer(mymklint) :: LDB
real(dp) :: BETA
real(dp), dimension(ldc,*) :: C
integer(mymklint) :: LDC
end subroutine




! BLAS

!! Level 1

!!! complex*16 functions

subroutine zcopy(N, ZX, INCX, ZY, INCY)
import :: dpc, mymklint
integer(mymklint) :: N
complex(dpc), dimension(*) :: ZX
integer(mymklint) :: INCX
complex(dpc), dimension(*) :: ZY
integer(mymklint) :: INCY
end subroutine zcopy

complex(dpc) function zdotu(N, ZX, INCX, ZY, INCY)
import :: dpc, mymklint
integer(mymklint) :: N
complex(dpc), dimension(*) :: ZX
integer(mymklint) :: INCX
complex(dpc), dimension(*) :: ZY
integer(mymklint) :: INCY
end function zdotu

complex(dpc) function zdotc(N, ZX, INCX, ZY, INCY)
import :: dpc, mymklint
integer(mymklint) :: N
complex(dpc), dimension(*) :: ZX
integer(mymklint) :: INCX
complex(dpc), dimension(*) :: ZY
integer(mymklint) :: INCY
end function zdotc

subroutine zscal(N, DA, ZX, INCX)
import :: dpc, mymklint
integer(mymklint) :: N
complex(dpc) :: DA
complex(dpc), dimension(*) :: ZX
integer(mymklint) :: INCX
end subroutine

subroutine zdscal(N, DA, ZX, INCX)
import :: dp, dpc, mymklint
integer(mymklint) :: N
real(dp) :: DA
complex(dpc), dimension(*) :: ZX
integer(mymklint) :: INCX
end subroutine

subroutine zgemv(TRANS, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY)
import :: dpc, mymklint
character :: TRANS
integer(mymklint) :: M
integer(mymklint) :: N
complex(dpc) :: ALPHA
complex(dpc), dimension(lda,*) :: A
integer(mymklint) :: LDA
complex(dpc), dimension(*) :: X
integer(mymklint) :: INCX
complex(dpc) :: BETA
complex(dpc), dimension(*) :: Y
integer(mymklint) :: INCY
end subroutine

subroutine zgemm(TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC)
import :: dpc, mymklint
character :: TRANSA
character :: TRANSB
integer(mymklint) :: M
integer(mymklint) :: N
integer(mymklint) :: K
complex(dpc) :: ALPHA
complex(dpc), dimension(lda,*) :: A
integer(mymklint)  LDA
complex(dpc), dimension(ldb,*) :: B
integer(mymklint)  LDB
complex(dpc) :: BETA
complex(dpc), dimension(ldc,*) :: C
integer(mymklint) :: LDC
end subroutine

subroutine zheevd(JOBZ, UPLO, N, A, LDA, W, WORK, LWORK, RWORK, LRWORK, &
                IWORK, LIWORK, INFO)
import :: dp, dpc, mymklint
character :: JOBZ
character :: UPLO
integer(mymklint) :: N
complex(dpc), dimension( lda, * ) :: A
integer(mymklint) :: LDA
real(dp), dimension( * ) :: W
complex(dpc), dimension( * ) :: WORK
integer(mymklint) :: LWORK
real(dp), dimension( * ) :: RWORK
integer(mymklint) :: LRWORK
integer(mymklint), dimension( * ) :: IWORK
integer(mymklint) :: LIWORK
integer(mymklint) :: INFO
end subroutine

! LAPACK
subroutine dgetri  ( N, A, LDA, IPIV, WORK, LWORK, INFO)
import :: dp, mymklint
integer(mymklint)  N
real(dp), dimension( lda, * ) ::  A
integer(mymklint)  LDA
integer(mymklint), dimension( * ) ::  IPIV
real(dp), dimension( * ) ::  WORK
integer(mymklint)  LWORK
integer(mymklint)  INFO
end subroutine dgetri

subroutine dgetrf(M, N, A, LDA, IPIV, INFO)
import :: dp, mymklint
integer(mymklint) :: M
integer(mymklint) :: N
real(dp), dimension( lda, * ) ::  A
integer(mymklint) :: LDA
integer(mymklint), dimension( * ) ::  IPIV
integer(mymklint) :: INFO
end subroutine dgetrf

subroutine dgeqp3  ( M, N, A, LDA, JPVT, TAU, WORK, LWORK, INFO )
import :: dp, mymklint
integer(mymklint) :: M
integer(mymklint) :: N
real(dp), dimension( lda, * ) :: A
integer(mymklint) :: LDA
integer(mymklint), dimension( * ) :: JPVT
real(dp), dimension( * ) :: TAU
real(dp), dimension( * ) :: WORK
integer(mymklint) :: LWORK
integer(mymklint) :: INFO
end subroutine

subroutine dgesv  ( N, NRHS, A, LDA, IPIV, B, LDB, INFO )
import :: dp, mymklint
integer(mymklint)   N
integer(mymklint)  NRHS
real(dp), dimension( lda, * ) :: A
integer(mymklint)  LDA
integer(mymklint), dimension( * ) :: IPIV
real(dp), dimension( ldb, * ) :: B
integer(mymklint)  LDB
integer(mymklint)  INFO
end subroutine

subroutine dstemr ( JOBZ, RANGEC, N, D, E, VL, VU, &
        IL, IU, M, W, Z, LDZ, NZC,&
        ISUPPZ, TRYRAC, WORK, LWORK,&
        IWORK, LIWORK, INFO)
import :: dp, mymklint
character :: JOBZ
character :: RANGEC
integer(mymklint) :: N
real(dp) :: D(N)
real(dp) :: E(N)
real(dp) :: VL
real(dp) :: VU
integer(mymklint) :: IL
integer(mymklint) :: IU
integer(mymklint) :: M ! resulting num eigenvalues
real(dp) :: W(N) ! resulting eigenvalues
real(dp), dimension(LDZ, *) :: Z ! returned orthonormal eigenvectors
integer(mymklint) :: LDZ
integer(mymklint) :: NZC
integer(mymklint), dimension(*) :: ISUPPZ
logical :: TRYRAC
real(dp), dimension(*) :: work
integer(mymklint) :: lwork ! dimension of work
integer(mymklint), dimension(*) :: iwork
integer(mymklint) :: liwork ! dimension of iwork
integer(mymklint) :: info
end subroutine dstemr

subroutine dsyev(JOBZ, UPLO, N, A, LDA, W, WORK, LWORK, INFO)
import :: dp, mymklint
character :: JOBZ
character :: UPLO
integer(mymklint) :: N
real(dp), dimension( lda, * ) :: A
integer(mymklint) :: LDA
real(dp), dimension( * ) :: W
real(dp), dimension( * ) :: WORK
integer(mymklint) :: LWORK
integer(mymklint) :: INFO
end subroutine dsyev

subroutine zheev(JOBZ, UPLO, N, A, LDA, W, WORK, LWORK, RWORK, INFO)
import :: dpc, dp, mymklint
character :: JOBZ
character :: UPLO
integer(mymklint)  N
complex(dpc), dimension( lda, * ) :: A
integer(mymklint)  LDA
real(dp), dimension( * ) ::  W
complex(dpc), dimension( * ) ::  WORK
integer(mymklint)  LWORK
real(dp), dimension( * ) ::  RWORK
integer(mymklint) :: INFO
end subroutine zheev




#ifdef WITH_ELPA
#ifndef USE_SCALAPACK
#error "USE_SCALAPACK not defined but trying to use WITH_ELPA will not work."
#endif
#endif




! Scalapack interface
#ifdef USE_SCALAPACK


!> \brief Interface to Scalapack::numroc
integer(mymklint) function numroc(N, NB, IPROC, IPROC_OFFSET, NPROCS)
import :: mymklint
integer(mymklint), intent(in) :: N
integer(mymklint), intent(in) :: NB
integer(mymklint), intent(in) :: IPROC
integer(mymklint), intent(in) :: IPROC_OFFSET
integer(mymklint), intent(in) :: NPROCS
end function numroc




!> \brief Interface to Scalapack::pdgemm
subroutine pdgemm(TRANSA, TRANSB, M, N, K, ALPHA, &
        A, IA, JA, DESC_A, &
        B, IB, JB, DESC_B, &
        BETA, &
        C, IC, JC, DESC_C)
import :: dp, mymklint
character(*) :: TRANSA
character(*) :: TRANSB
integer(mymklint), intent(in) :: M
integer(mymklint), intent(in) :: N
integer(mymklint), intent(in) :: K
real(dp), intent(in) :: ALPHA
real(dp), intent(in) :: A(*)
integer(mymklint), intent(in) :: IA, JA
integer(mymklint), dimension(9), intent(in) :: DESC_A
real(dp), intent(in) :: B(*)
integer(mymklint), intent(in) :: IB, JB
integer(mymklint), dimension(9), intent(in) :: DESC_B
real(dp), intent(in) :: BETA
real(dp), intent(inout) :: C(*)
integer(mymklint), intent(in) :: IC, JC
integer(mymklint), dimension(9), intent(in) :: DESC_C
end subroutine pdgemm



subroutine pzheevx(jobz, my_range, uplo, n, &
        a, ia, ja, desca, &
        vl, vu, il, iu, &
        abstol, m, nz, &
        w, &
        orfac, &
        z, iz, jz, descz, &
        work, lwork, rwork, lrwork, iwork, liwork, &
        ifail, iclustr, gap, info)
import :: dp, dpc, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: my_range
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
complex(dpc), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), intent(in) :: vl
real(dp), intent(in) :: vu
integer(mymklint), intent(in) :: il
integer(mymklint), intent(in) :: iu
real(dp), intent(in) :: abstol
integer(mymklint), intent(inout) :: m
integer(mymklint), intent(inout) :: nz
real(dp), dimension(*), intent(inout) :: w
real(dp), intent(in) :: orfac
complex(dpc), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
complex(dpc), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
real(dp), dimension(*), intent(inout) :: rwork
integer(mymklint), intent(in) :: lrwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), dimension(*), intent(inout) :: ifail
integer(mymklint), dimension(*), intent(inout) :: iclustr
real(dp), dimension(*), intent(inout) :: gap
integer(mymklint), intent(inout) :: info
end subroutine pzheevx



subroutine pdsyevx(jobz, my_range, uplo, n, &
        a, ia, ja, desca, &
        vl, vu, il, iu, &
        abstol, m, nz, &
        w, &
        orfac, &
        z, iz, jz, descz, &
        work, lwork, iwork, liwork, &
        ifail, iclustr, gap, info)
import :: dp, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: my_range
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
real(dp), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), intent(in) :: vl
real(dp), intent(in) :: vu
integer(mymklint), intent(in) :: il
integer(mymklint), intent(in) :: iu
real(dp), intent(in) :: abstol
integer(mymklint), intent(inout) :: m
integer(mymklint), intent(inout) :: nz
real(dp), dimension(*), intent(inout) :: w
real(dp), intent(in) :: orfac
real(dp), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
real(dp), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), dimension(*), intent(inout) :: ifail
integer(mymklint), dimension(*), intent(inout) :: iclustr
real(dp), dimension(*), intent(inout) :: gap
integer(mymklint), intent(inout) :: info
end subroutine pdsyevx






subroutine pzheevd(jobz, uplo, n, &
        a, ia, ja, desca, &
        w, &
        z, iz, jz, descz, &
        work, lwork, rwork, lrwork, iwork, liwork, info)
import :: dp, dpc, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
complex(dpc), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), dimension(*), intent(inout) :: w
complex(dpc), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
complex(dpc), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
real(dp), dimension(*), intent(inout) :: rwork
integer(mymklint), intent(in) :: lrwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), intent(inout) :: info
end subroutine pzheevd



subroutine pdsyevd(jobz, uplo, n, &
        a, ia, ja, desca, &
        w, &
        z, iz, jz, descz, &
        work, lwork, iwork, liwork, info)
import :: dp, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
real(dp), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), dimension(*), intent(inout) :: w
real(dp), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
real(dp), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), intent(inout) :: info
end subroutine pdsyevd



subroutine pzheevr(jobz, my_range, uplo, n, &
        a, ia, ja, desca, &
        vl, vu, il, iu, &
        m, nz, &
        w, &
        z, iz, jz, descz, &
        work, lwork, rwork, lrwork, iwork, liwork, &
        info)
import :: dp, dpc, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: my_range
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
complex(dpc), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), intent(in) :: vl
real(dp), intent(in) :: vu
integer(mymklint), intent(in) :: il
integer(mymklint), intent(in) :: iu
integer(mymklint), intent(inout) :: m
integer(mymklint), intent(inout) :: nz
real(dp), dimension(*), intent(inout) :: w
complex(dpc), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
complex(dpc), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
real(dp), dimension(*), intent(inout) :: rwork
integer(mymklint), intent(in) :: lrwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), intent(inout) :: info
end subroutine pzheevr



subroutine pdsyevr(jobz, my_range, uplo, n, &
        a, ia, ja, desca, &
        vl, vu, il, iu, &
        m, nz, &
        w, &
        z, iz, jz, descz, &
        work, lwork, iwork, liwork, &
        info)
import :: dp, mymklint
integer(mymklint), parameter :: dlen_ = 9
character, intent(in) :: jobz
character, intent(in) :: my_range
character, intent(in) :: uplo
integer(mymklint), intent(in) :: n
real(dp), dimension(*), intent(inout) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(dlen_), intent(in) :: desca
real(dp), intent(in) :: vl
real(dp), intent(in) :: vu
integer(mymklint), intent(in) :: il
integer(mymklint), intent(in) :: iu
integer(mymklint), intent(inout) :: m
integer(mymklint), intent(inout) :: nz
real(dp), dimension(*), intent(inout) :: w
real(dp), dimension(*), intent(inout) :: z
integer(mymklint), intent(in) :: iz
integer(mymklint), intent(in) :: jz
integer(mymklint), dimension(dlen_), intent(in) :: descz
real(dp), dimension(*), intent(inout) :: work
integer(mymklint), intent(in) :: lwork
integer(mymklint), dimension(*), intent(inout) :: iwork
integer(mymklint), intent(in) :: liwork
integer(mymklint), intent(inout) :: info
end subroutine pdsyevr




!> \brief Interface to Scalapack::pzgemm
subroutine pzgemm(TRANSA, TRANSB, M, N, K, ALPHA, &
                A, IA, JA, DESC_A, &
                B, IB, JB, DESC_B, &
                BETA, &
                C, IC, JC, DESC_C)
import :: dpc, mymklint
character(*) :: TRANSA
character(*) :: TRANSB
integer(mymklint), intent(in) :: M
integer(mymklint), intent(in) :: N
integer(mymklint), intent(in) :: K
complex(dpc), intent(in) :: ALPHA
complex(dpc), intent(in) :: A(*)
integer(mymklint), intent(in) :: IA, JA
integer(mymklint), dimension(9), intent(in) :: DESC_A
complex(dpc), intent(in) :: B(*)
integer(mymklint), intent(in) :: IB, JB
integer(mymklint), dimension(9), intent(in) :: DESC_B
complex(dpc), intent(in) :: BETA
complex(dpc), intent(inout) :: C(*)
integer(mymklint), intent(in) :: IC, JC
integer(mymklint), dimension(9), intent(in) :: DESC_C
end subroutine pzgemm


!!> \brief Interface to Scalapack::dgsum2D
!subroutine dgsum2d(icontxt, scope, top, m, n, A, lda, rdest, cdest)
!integer(mymklint), intent(in) :: icontxt !< blacs context
!character(1), intent(in) :: scope !< 'R', 'C' or 'A'
!character(1), intent(in) :: top
!integer(mymklint), intent(in) :: m !< number of matrix rows to be combined
!integer(mymklint), intent(in) :: n !< number of matrix cols to be combined
!integer(mymklint), intent(in) :: lda !< lead dimension of A
!double precision, intent(inout) :: A(lda, *) !< matrix to be added to produce the sum
!integer(mymklint), intent(in) :: rdest !< process row coordinate to receive result
!integer(mymklint), intent(in) :: cdest !< process column coordinate to receive result
!end subroutine

!subroutine zgsum2d(icontxt, scope, top, m, n, A, lda, rdest, cdest)
!integer(mymklint), intent(in) :: icontxt
!character(1), intent(in) :: scope
!character(1), intent(in) :: top
!integer(mymklint), intent(in) :: m
!integer(mymklint), intent(in) :: n
!double complex, intent(inout) :: A(lda, *)
!integer(mymklint), intent(in) :: lda
!integer(mymklint), intent(in) :: rdest
!integer(mymklint), intent(in) :: cdest
!end subroutine



!subroutine blacs_gridinit(ICNTXT, ORDER, NP_ROWS, NP_COLS)
!integer(mymklint), intent(inout) :: ICNTXT
!character(*), intent(in) :: ORDER
!integer(mymklint), intent(in) :: NP_ROWS
!integer(mymklint), intent(in) :: NP_COLS
!end subroutine

subroutine blacs_gridinfo(ICNTXT, NP_ROWS, NP_COLS, IPROW, IPCOL)
import :: mymklint
integer(mymklint), intent(in) :: ICNTXT
integer(mymklint), intent(out) :: NP_ROWS
integer(mymklint), intent(out) :: NP_COLS
integer(mymklint), intent(out) :: IPROW
integer(mymklint), intent(out) :: IPCOL
end subroutine

subroutine blacs_gridexit(ICNTXT)
import :: mymklint
integer(mymklint), intent(inout) :: ICNTXT
end subroutine


real(dp) function pdlamch(ictxt, cmach)
import :: dp, mymklint
integer(mymklint), intent(in) :: ictxt
character, intent(in) :: cmach
end function pdlamch


integer(mymklint) function indxg2p(indxglob, nb, iproc, isrcproc, nprocs)
import :: mymklint
integer(mymklint), intent(in) :: indxglob
integer(mymklint), intent(in) :: nb
integer(mymklint), intent(in) :: iproc
integer(mymklint), intent(in) :: isrcproc
integer(mymklint), intent(in) :: nprocs
end function indxg2p



real(dp) function pzlange(norm, m, n, a, ia, ja, desca, work)
import :: dp, dpc, mymklint
character, intent(in) :: norm
integer(mymklint), intent(in) :: m
integer(mymklint), intent(in) :: n
complex(dpc), intent(in) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(9), intent(in) :: desca
complex(dpc), dimension(*), intent(inout) :: work
end function pzlange

real(dp) function pdlange(norm, m, n, a, ia, ja, desca, work)
import :: dp, mymklint
character, intent(in) :: norm
integer(mymklint), intent(in) :: m
integer(mymklint), intent(in) :: n
real(dp), intent(in) :: a
integer(mymklint), intent(in) :: ia
integer(mymklint), intent(in) :: ja
integer(mymklint), dimension(9), intent(in) :: desca
real(dp), dimension(*), intent(inout) :: work
end function pdlange








#endif


end interface

end module external_interfaces







module fftw3_module
#if defined(USEFFTW3)
   use, intrinsic :: iso_c_binding
   use constants, only : dp, dpc
#if defined(CREATE_FFTW3_MODULE)
   include 'fftw3.f03'
#else
   ! FFTW3+ Interface
   ! CML:TODO add in threaded FFTW calls
   interface
      subroutine dfftw_cleanup()
      end subroutine dfftw_cleanup
   end interface
   interface
      subroutine dfftw_plan_dft_3d(plan, n1, n2, n3,chd_in,chd_out,fftw_direction_in,fftw_flags)
         import :: dp, dpc
         integer(kind=8) :: plan
         integer :: n1
         integer :: n2
         integer :: n3
         complex(dpc), dimension(*) :: chd_in
         complex(dpc), dimension(*) :: chd_out
         integer :: fftw_direction_in
         integer :: fftw_flags
      end subroutine dfftw_plan_dft_3d
   end interface
   interface
      subroutine dfftw_execute(plan)
         integer(kind=8) :: plan
      end subroutine dfftw_execute
   end interface
   interface
      subroutine dfftw_destroy_plan(plan)
         integer(kind=8) :: plan
      end subroutine dfftw_destroy_plan
   end interface
#endif
#endif
end module fftw3_module
