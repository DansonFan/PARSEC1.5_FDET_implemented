module init_var_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  Define a series of quantities over the processors.
!  Coefficients for the numerical derivatives are also defined.
!
!---------------------------------------------------------------

subroutine init_var(clust, band_st, elec_st, mixer, solver, rritz, &
        symm, rsymm, parallel, nloc_p_pot, grid, p_pot, pbc, &
        mol_dynamic, move, ipr, export_griddata_flag, nscf, &
        outputgw, enable_data_out, readwfndat, chsym, &
        istart, iswf, mxiter, outflag, outevflag, npolflg, ifield, &
        vconv, vconv_approach, field, ierr)

use constants
use aux, only : matvec3
use cluster_module
use electronic_struct_module
use mixer_module
use eigen_solver_module
use rritz_data_module
use parallel_data_module
use non_local_psp_module
use grid_module
use pseudo_potential_module
use pbc_module
use symmetry_module
use bandstruc_module
use nscf_module
use pbc_grid_coefs_module
use molecular_dynamic_module
use irrbz_module, only : irrbz
use fornberg_module, only : fornberg
use parsec_global_data, only : vecgen, moldyngen, inputs, tests
use prandom_module
use movement_module

#ifdef MPI
#ifdef WITH_MPI_F08
use mpi_f08, only : mpi_comm, mpi_bcast, mpi_logical, mpi_integer, &
        mpi_double_precision, mpi_character, &
        mpi_allreduce, mpi_integer, mpi_max
#else
use mpi
#endif
#endif

implicit none

!
!  Input/Output variables:
!

!  the cluster
type(cluster), intent(inout) :: clust

!  electronic structure
type(electronic_struct), intent(inout) :: elec_st

!  mixer related data
type(mixer_data), intent(inout) :: mixer

! bandstructure structure
type(bandstruc), intent(inout) :: band_st

!  eigen solver data
type(eigen_solver), intent(inout) :: solver

!  eigen solver data
type(rritz_data), intent(inout) :: rritz

!  parallel data
type(parallel_data), intent(inout) :: parallel

!  non local pseudopotential related data
type(nonloc_pseudo_potential), intent(inout) :: nloc_p_pot 

!  grid related data
type(grid_data), intent(inout) :: grid

!  pseudopotential related data
type(pseudo_potential), intent(inout) :: p_pot 

!  periodic boundary conditions data
type(pbc_data), intent(inout) :: pbc

!  molecular dynamics conditions data
type(molecular_dynamic), intent(inout) :: mol_dynamic

type(movement), intent(inout) :: move

!  symmetry operations in the reduced group
type(symmetry), intent(inout) :: symm,rsymm

!  printing flag
integer, intent(inout) :: ipr

!  print/export flag
integer, dimension(MAX_EXPORT_OPTS), intent(inout) :: export_griddata_flag

! nscf data structure
type(nscf_data), intent(inout) :: nscf

!  logical flag for whether gwoutput is written
logical, intent(inout) :: outputgw

!  logical flag for whether raw data is written
logical, intent(inout) :: enable_data_out

!  error flag
integer, intent(out) :: ierr


logical, intent(inout) :: readwfndat
logical, intent(inout) :: chsym

integer, intent(inout) :: istart
integer, intent(inout) :: mxiter
integer, intent(inout) :: outflag
integer, intent(inout) :: outevflag
integer, intent(inout) :: npolflg
integer, intent(inout) :: ifield
integer, intent(inout) :: iswf

real(dp), intent(inout) :: vconv
real(dp), intent(inout) :: vconv_approach
real(dp), intent(inout) :: field

!
!  Work variables:
!

#ifdef MPI
#ifdef WITH_MPI_F08
type(mpi_comm) :: comm
#else
integer :: comm
#endif
#endif

!  rank of the master in the above communicator
integer :: masterid

!  exit code for mpi calls
integer :: mpinfo

!  counters
integer :: ii
integer :: jj
integer :: ity
integer :: irp
integer :: nmax
integer :: kpnum
integer :: kplp
integer :: isp

real(dp) :: kpnorm
real(dp), dimension(3) :: ktmp



! ---------------------------------------------------------------


masterid = parallel%masterid

#ifdef MPI
#ifdef WITH_MPI_F08
comm%mpi_val = parallel%comm
#else
comm = parallel%comm
#endif
#endif


! KHL: TODO: move all variables/parameters in def.h to parsec_global_module
#ifdef MPI
call MPI_BCAST(readwfndat    ,1,MPI_LOGICAL, parallel%masterid,comm,mpinfo)
call MPI_BCAST(chsym         ,1,MPI_LOGICAL,  parallel%masterid,comm,mpinfo)

call MPI_BCAST(istart        ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(iswf          ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(mxiter        ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(outflag       ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(outevflag     ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(npolflg       ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(ifield        ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)

call MPI_BCAST(vconv         ,1,MPI_DOUBLE_PRECISION, parallel%masterid,comm,mpinfo)
call MPI_BCAST(vconv_approach,1,MPI_DOUBLE_PRECISION, parallel%masterid,comm,mpinfo)
call MPI_BCAST(field         ,1,MPI_DOUBLE_PRECISION, parallel%masterid,comm,mpinfo)

call MPI_BCAST(move%is_on          ,1,MPI_LOGICAL, parallel%masterid,comm,mpinfo)
call MPI_BCAST(move%mxmove         ,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(move%restart_cheb_after_n, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_Bcast(move%remained_times_atomic_chrg_den, 1, MPI_INTEGER, &
        parallel%masterid, comm, mpinfo)
call MPI_Bcast(move%restart_cheb_remained_times, 1, MPI_INTEGER, &
        parallel%masterid, comm, mpinfo)

call MPI_BCAST(mol_dynamic%is_on   ,1,MPI_LOGICAL, parallel%masterid,comm,mpinfo)
call MPI_BCAST(mol_dynamic%step_num,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)
call MPI_BCAST(mol_dynamic%rng_seed,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)

call MPI_BCAST(elec_st%mxwd , 1,MPI_INTEGER,parallel%masterid,comm,mpinfo)
call MPI_BCAST(elec_st%nspin, 1,MPI_INTEGER,parallel%masterid,comm,mpinfo)
call MPI_BCAST(elec_st%ncl  , 1,MPI_LOGICAL,parallel%masterid,comm,mpinfo)

call MPI_BCAST(clust%type_num,1,MPI_INTEGER, parallel%masterid,comm,mpinfo)

if (.not. parallel%iammaster)  then
        allocate(p_pot%rws(clust%type_num))
        p_pot%rws(:) = zero
endif
call MPI_BCAST(p_pot%rws    ,clust%type_num,MPI_DOUBLE_PRECISION, parallel%masterid,comm,mpinfo)
#endif


! KHL: elec_st%mxwd does not exist in matvec9001, so I added back 
!      parallel%mxwd in order to use mxwd in matvec9001()
parallel%mxwd = elec_st%mxwd






! SO stuff, notice that this is being setup only for master, then
! sent to others, while it should be done for everyone, no?
if (parallel%iammaster) then
        if (elec_st%ncl) then
                solver%ncl = .true.
                elec_st%mxwd = 2

                if (nloc_p_pot%is_so) elec_st%is_so = .true.

        elseif (nloc_p_pot%is_so) then
                if (elec_st%mxwd == 1) then
                        elec_st%is_so = .false.
                elseif (elec_st%mxwd == 2) then
                        elec_st%is_so = .true.
                endif
        endif
endif





#ifdef MPI
call MPI_BCAST(elec_st%mxwd,    1,MPI_LOGICAL,parallel%masterid,comm,mpinfo)
call MPI_BCAST(elec_st%is_so,   1,MPI_LOGICAL,parallel%masterid,comm,mpinfo)
call MPI_BCAST(nloc_p_pot%is_so,1,MPI_LOGICAL,parallel%masterid,comm,mpinfo)
call MPI_BCAST(solver%ncl,      1,MPI_LOGICAL,parallel%masterid,comm,mpinfo)
call MPI_BCAST(solver%use_scalapack, 1, MPI_LOGICAL, parallel%masterid, comm, mpinfo)
call MPI_BCAST(solver%use_elpa, 1, MPI_LOGICAL, parallel%masterid, comm, mpinfo)
#endif


























!
!  Master updates some variables.
!
if (parallel%iammaster) then
        !  Change ekbi into h^3/ekbi, to be used from now on.
        do ity = 1, clust%type_num
        do ii = 1, p_pot%nlocp(ity)
                if (ii /= p_pot%loc(ity)) then
                        p_pot%ekbi(ii,ity) =  grid%hcub/p_pot%ekbi(ii,ity)
                endif
        enddo
        enddo

        !  For confined system, define grid%step; grid%step(1) will be
        !  used in place of grid%stepin.
        if (.not. pbc%is_on) then
                grid%step(:) = grid%stepin

                grid%n1 = idint(two*grid%rmax/grid%stepin) + 2
                grid%n2 = grid%n1
                grid%n3 = grid%n1

                pbc%latt_vec(:,:) = zero

                do ii = 1, 3
                        pbc%latt_vec(ii,ii) = one
                enddo

                pbc%avec_norm(:,:) = pbc%latt_vec(:,:)
                pbc%box_size(:) = zero

                write(7,*)
                write(7,*)  'Initial grid cube (to be truncated)'
                write(7,21) grid%stepin
                write(7,22) grid%step
                write(7,24) grid%n1, grid%n2, grid%n3
                write(7,*)

21 format(' Input grid spacing:',1x,f6.3,1x,'bohr')
22 format(' Final grid spacing:',1x,3(f6.3,1x),'bohr')
24 format(' Number of grid points along each direction:',3(1x,i3))

        endif

        !  Transport important information from rsymm to elec_st.
        ! TODO: if ever want to use symmetry in pbc - need to move these
        elec_st%nrep = rsymm%ntrans
        allocate(elec_st%chi(elec_st%nrep,elec_st%nrep))
        elec_st%chi(:,:) = rsymm%chi(:,:)
endif



#ifdef MPI
call MPI_Bcast(grid%shift(:), 3, MPI_DOUBLE_PRECISION, &
        parallel%masterid, comm, mpinfo)
call MPI_Bcast(grid%n1, 1, MPI_INTEGER, &
        parallel%masterid, comm, mpinfo)
call MPI_Bcast(grid%n2, 1, MPI_INTEGER, &
        parallel%masterid, comm, mpinfo)
call MPI_Bcast(grid%n3, 1, MPI_INTEGER, &
        parallel%masterid, comm, mpinfo)
#endif






#ifdef MPI

call MPI_Bcast(parallel%groups_num, 1, MPI_INTEGER, masterid, &
        comm, mpinfo)
call MPI_Bcast(elec_st%nstate, 1, MPI_INTEGER, masterid, &
        comm, mpinfo)
  !
  !  Broadcast info to all PEs.
  !
  ! printing flag
  call MPI_BCAST(ipr,1,MPI_INTEGER,masterid,comm,mpinfo)
  !  Send the step sizes. NOTE: grid%stepin is not broadcasted.
  call MPI_BCAST(grid%step          , 3,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(grid%rmax          , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(grid%h_2           , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(grid%hcub          , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
call mpi_bcast(grid%two_invhcub, 1, &
        mpi_double_precision, masterid, comm, mpinfo)
  call MPI_BCAST(grid%d_shape_param , 3,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(grid%i_shape_param , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(grid%domain_shape  , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(grid%norder        , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(grid%ndouble       , 1,MPI_INTEGER,masterid,comm,mpinfo)

  call MPI_Bcast(grid%use_sfc, 1, MPI_LOGICAL, masterid, comm, mpinfo)

  call MPI_BCAST(parallel%max_lap_buffers,  1,MPI_LOGICAL,masterid,comm,mpinfo)

  call MPI_BCAST(clust%atom_num         , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(clust%recenter_atoms_in_aperiodic_directions, 1, &
          MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(clust%has_ptchrg       , 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(clust%has_charged_sheet, 1,MPI_LOGICAL,masterid,comm,mpinfo)

  call MPI_BCAST(pbc%is_on    , 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%per      , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%box_size , 3,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%latt_vec , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%bvec     , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%adot     , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%bdot     , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%avec_norm, 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%vcell          , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(pbc%a_surface_cell , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(grid%grad_bvec_norm, 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)

  call MPI_BCAST(rsymm%ntrans, 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST( symm%ntrans, 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(rsymm%alatt , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST( symm%alatt , 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(rsymm%invlat, 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST( symm%invlat, 9,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%cplx  , 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%scf_so, 1,MPI_LOGICAL,masterid,comm,mpinfo)

  call MPI_BCAST(elec_st%nsave , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%nstate, 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%nspin , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%nrep  , 1,MPI_INTEGER,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%nkpt  , 1,MPI_INTEGER,masterid,comm,mpinfo)

  call MPI_BCAST(elec_st%dioniz , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%icorr  , 2,MPI_CHARACTER,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%use_libxc , 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%func_id  , 2,MPI_INTEGER,masterid,comm,mpinfo)


  call MPI_BCAST(elec_st%ncl, 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(solver%ncl , 1,MPI_LOGICAL,masterid,comm,mpinfo)

  call MPI_BCAST(elec_st%use_plain_sre       , 1,MPI_LOGICAL,masterid,comm,mpinfo)
  call MPI_BCAST(elec_st%explicit_hartree_pbc, 1,MPI_LOGICAL,masterid,comm,mpinfo)

  call inputs % bcast( masterid, parallel%comm, mpinfo )
  call tests % bcast( masterid, parallel%comm, mpinfo )
#endif

parallel%npcol = parallel%groups_num




!
! Now that data has arrived, all PEs (except master) 
! define/allocate variables.
!
if (.not. parallel%iammaster) then
        !  Allocate arrays and define structures.
        call create_electronic_struct(elec_st%nspin, elec_st%nstate, &
                elec_st, elec_st%mxwd)

        if (elec_st%nsave > 0) then
                allocate(elec_st%indxsave(elec_st%nsave))
        endif

        allocate(elec_st%chi(elec_st%nrep,elec_st%nrep))

        call create_symmetry(rsymm%ntrans, rsymm)
        call create_symmetry(symm%ntrans, symm)
endif



#ifdef MPI
! Let us continue:
call MPI_BCAST(elec_st%ncharge      , 1,MPI_DOUBLE_PRECISION,masterid,comm, mpinfo)
call MPI_BCAST(elec_st%xele         , 1,MPI_DOUBLE_PRECISION,masterid,comm, mpinfo)
call MPI_BCAST(elec_st%tfermi       , 1,MPI_DOUBLE_PRECISION,masterid,comm, mpinfo)


call MPI_BCAST(elec_st%do_vdw             , 1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(elec_st%hirsh_3d_cell      , 3,MPI_INTEGER,masterid,comm,mpinfo)

call MPI_BCAST(rsymm%gmtrx,3*3*rsymm%ntrans  ,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST( symm%gmtrx, 3*3*symm%ntrans  ,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(rsymm%rmtrx,3*3*rsymm%ntrans  ,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST( symm%rmtrx, 3*3*symm%ntrans  ,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(rsymm%trans,3*3*rsymm%ntrans  ,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
call MPI_BCAST( symm%trans, 3*3*symm%ntrans  ,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
call MPI_BCAST(rsymm%tnp,    3*rsymm%ntrans  ,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
call MPI_BCAST( symm%tnp,     3*symm%ntrans  ,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)

call MPI_BCAST(rsymm%chi,   rsymm%ntrans*rsymm%ntrans,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(elec_st%chi, elec_st%nrep**2          ,MPI_INTEGER,masterid,comm,mpinfo)

call MPI_BCAST(grid%hartree_neibs_flag    , 1,MPI_LOGICAL,masterid,comm,mpinfo)

call MPI_BCAST(grid%fold%side_length, 1, MPI_INTEGER, masterid, comm, mpinfo)

call MPI_BCAST(rritz % forced_logic, 1,MPI_INTEGER,masterid,comm,mpinfo)



! ====================================================
!      Solver
! ====================================================
call MPI_BCAST(solver%full_hartree_flag   , 1,MPI_LOGICAL, &
        masterid,comm,mpinfo)
call MPI_BCAST(solver%use_smart_bound_in_subspace   , 1,MPI_LOGICAL, &
        masterid,comm,mpinfo)
call MPI_BCAST(solver%toler   , 1,MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
call MPI_BCAST(solver%name    , 6,MPI_CHARACTER,masterid,comm,mpinfo)
call MPI_BCAST(solver%maxmv   , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%lpole   , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%scalapack_block_size, 1, MPI_INTEGER, &
        masterid, comm, mpinfo)
call MPI_BCAST(solver%elpa_block_size, 1, MPI_INTEGER, &
        masterid, comm, mpinfo)
call MPI_BCAST(solver%polym0        , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%ff_maxiter    , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%bands_ff_maxiter,  1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%polym         , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%polym_t       , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%dpm           , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%mv_blksize    , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%dyntol        , 1,MPI_LOGICAL,masterid,comm,mpinfo)

call MPI_BCAST(solver%spectrum_slicing,  1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(solver%use_krylov_subspace_method, 1, MPI_LOGICAL, masterid, comm, mpinfo)
call MPI_BCAST(solver%use_lanczos_dos_estimation, 1, MPI_LOGICAL, masterid, comm, mpinfo)
call MPI_BCAST(solver%spectrum_slicing_cycles_early_quit, 1, MPI_LOGICAL, masterid, comm, mpinfo)
call MPI_BCAST(solver%spectrum_slicing_max_cycles, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%spectrum_slicing_max_cycles_first, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%num_of_iter_still_using_chebyshev, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%polym_first_ss_iter, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%polym_ss, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%num_of_copied_groups, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%num_of_slice1_filtering, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%nslices, 1, MPI_INTEGER, masterid, comm, mpinfo)
call MPI_BCAST(solver%spectrum_slicing_ratio, 1, MPI_DOUBLE_PRECISION, masterid, comm, mpinfo)

call MPI_BCAST(solver%scaledcheb    , 1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(solver%fix_num_eig   , 1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(solver%do_subsp      , 1,MPI_LOGICAL,masterid,comm,mpinfo)
!threading support
! call MPI_BCAST(solver%max_mkl_threads     , 1,MPI_LOGICAL,masterid,comm,mpinfo)
! call MPI_BCAST(solver%matvec_mkl_threads     , 1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(solver%rng_seed     , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%randommp     , 1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(solver%boundsmethod , 1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(solver%num_lancz_bound, 1,MPI_INTEGER,masterid,comm,mpinfo)



! ====================================================
!      Mixer
! ====================================================
call mpi_bcast(mixer%name          , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%memory        , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%restart       , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%block         , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%en_stage      , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%group_size    , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%preferred_type, 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%update_type   , 1,mpi_integer,masterid,comm,mpinfo)
call mpi_bcast(mixer%restart_factor, 1,mpi_double_precision, &
        masterid,comm,mpinfo)
call mpi_bcast(mixer%expand_factor , 1,mpi_double_precision, &
        masterid,comm,mpinfo)
call mpi_bcast(mixer%param         , 1,mpi_double_precision, &
        masterid,comm,mpinfo)







if (elec_st%nsave > 0) then
        call mpi_bcast(elec_st%indxsave, elec_st%nsave, mpi_integer, &
                masterid, comm, mpinfo)
endif




! ====================================================
!     Band structure calculation related variables
! ====================================================

call mpi_bcast(band_st%bands_on, 1, mpi_logical, masterid, comm, mpinfo)

if (band_st%bands_on) then 
        call mpi_bcast(band_st%npoints, 1, mpi_integer, &
                masterid, comm, mpinfo)
        call mpi_bcast(band_st%nlines , 1, mpi_integer, &
                masterid, comm, mpinfo)

        if (.not. parallel%iammaster) then
                allocate(band_st%blines(band_st%nlines))
        endif

        do ii = 1, band_st%nlines
                call mpi_bcast(band_st%blines(ii)%start, 3, &
                        mpi_double_precision, masterid, comm, mpinfo)
                call mpi_bcast(band_st%blines(ii)%end  , 3, &
                        mpi_double_precision, masterid, comm, mpinfo)
        enddo
endif










! ====================================================
!     Non-self-consistent-field calculation related variables
! ====================================================

call mpi_bcast(nscf%nscf_on,  1,MPI_LOGICAL,masterid,comm,mpinfo)

if (nscf%nscf_on) then 
        call MPI_BCAST(nscf%nkpt  , 1,MPI_INTEGER,masterid,comm,mpinfo)
        call MPI_BCAST(nscf%nstate, 1,MPI_INTEGER,masterid,comm,mpinfo)
        call MPI_BCAST(nscf%kgrid , 3,MPI_INTEGER,masterid,comm,mpinfo)
        call MPI_BCAST(nscf%kshift, 3,MPI_DOUBLE_PRECISION, &
                masterid,comm,mpinfo)

        if (.not. parallel%iammaster) then
                allocate(nscf%kpts(3,nscf%nkpt))
                allocate(nscf%kpwt(nscf%nkpt))
        endif

        call MPI_BCAST(nscf%kpts , 3*nscf%nkpt, MPI_DOUBLE_PRECISION, &
                masterid,comm,mpinfo)
        call MPI_BCAST(nscf%kpwt ,   nscf%nkpt, MPI_DOUBLE_PRECISION, &
                masterid,comm,mpinfo)
endif





call MPI_BCAST(outputgw,  1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(enable_data_out,  1,MPI_LOGICAL,masterid,comm,mpinfo)
call MPI_BCAST(export_griddata_flag,MAX_EXPORT_OPTS,MPI_INTEGER,masterid,comm,mpinfo)
#endif









! ====================================================
!     k-grid
! ====================================================

!  If a Monkhorst-Pack grid is input, construct the irreducible
!  Brillouin zone. Otherwise, distribute k-points.
if (elec_st%nkpt /= 0) then

#ifdef MPI
        call mpi_bcast(elec_st%kptmethod, 1, mpi_integer, &
                masterid, comm, mpinfo)
#endif

        if (elec_st%kptmethod == MONKHORST_PACK) then

#ifdef MPI
                call mpi_bcast(elec_st%mpgrid, 3, mpi_integer, &
                        masterid, comm, mpinfo)
                call mpi_bcast(elec_st%mpshift, 3, mpi_double_precision, &
                        masterid, comm, mpinfo)
#endif

                call irrbz(elec_st, symm, pbc, parallel%iammaster, ierr)

                if (ierr /= 0) return
        else
                if (.not. parallel%iammaster) then
                        allocate(elec_st%kpts(3,elec_st%nkpt))
                        allocate(elec_st%kpwt(elec_st%nkpt))
                endif

#ifdef MPI
                call mpi_bcast(elec_st%kpts(:,:), 3*elec_st%nkpt, &
                        mpi_double_precision, masterid, comm, mpinfo)
                call mpi_bcast(elec_st%kpwt(:), elec_st%nkpt, &
                        mpi_double_precision, masterid, comm, mpinfo)
#endif

        endif
endif









!
!  Define kpnum = max(1,elec_st%nkpt).
!
kpnum = max(elec_st%nkpt, 1)
kpnorm = zero







!
!  Get coefficients for numerical first derivative based on the
!  order specified by the user. These coefficients are used only
!  for GGA purposes.
!
!  AJB: ...and for the kinetic energy operator if k-points are used
!
allocate(grid%coe1(-grid%norder:grid%norder,3))

call fornberg(1, grid%norder, grid%coe1(:,1), ierr)

#ifdef MPI
call mpi_allreduce(ierr, ii, 1, mpi_integer, mpi_max, comm, mpinfo)
ierr = ii
#endif

if (ierr /= 0) then
        write(9,*) ' ERROR: Wrong parameter in call of Fornberg'
        write(9,*) ' STOP in init_var'
        return
endif

!  Renormalize coes with respect to the grid spacing.
grid%coe1(:,3) = grid%coe1(:,1)/grid%step(3)
grid%coe1(:,2) = grid%coe1(:,1)/grid%step(2)
grid%coe1(:,1) = grid%coe1(:,1)/grid%step(1)








! ====================================================
!  Create coefficients for the gradient term of 
!  kpoint kinetic energy.
! ====================================================

pbc%nkpt = elec_st%nkpt
nloc_p_pot%nkpt = elec_st%nkpt

if (elec_st%nkpt /= 0) then
        allocate(pbc%kpts(3,elec_st%nkpt))
        pbc%kpts(:,:) = elec_st%kpts(:,:)

        allocate(nloc_p_pot%kpts(3,elec_st%nkpt))
        nloc_p_pot%kpts(:,:) = elec_st%kpts(:,:)

        allocate(grid%kecoe1(elec_st%nkpt,6,0:grid%norder))
        grid%kecoe1(:,:,:) = zero

        do kplp = 1, elec_st%nkpt
        do jj = 0, grid%norder
                call matvec3('T', grid%grad_bvec_norm(:,:), &
                        elec_st%kpts(:,kplp), ktmp(:))

                grid%kecoe1(kplp,1:3,jj) = -2*zi*grid%coe1(jj,1:3)*ktmp(1:3)
        enddo
        enddo

        do kplp = 1, kpnum
                kpnorm = kpnorm + elec_st%kpwt(kplp)
        enddo

        elec_st%kpwt(:) = elec_st%kpwt(:)/kpnorm

else
        allocate(elec_st%kpwt(1))
        elec_st%kpwt(1) = one
endif









! ====================================================
!  Calculate coefficients for the laplacian in case of
!  non-orthogonal grid.
! ====================================================

if (pbc%is_on .and. pbc%per > 1) then
        call pbc_grid_coefs(pbc, grid, parallel%iammaster, 1.d-9)
else
        grid%lap_dir_num = 0
        grid%lap_dir = 0
        grid%b_lap(1:3) = one
        grid%b_lap(4:6) = zero
endif

write(9,'(a,i2)') ' Laplacian number of (EXTRA) directions: ', &
        grid%lap_dir_num
write(9,*) "Laplacian coefficients data:"
write(9,'(6(f5.2,1x))') grid%b_lap(:)









! ====================================================
!  Get coefficients for numerical second derivative based on the 
!  order specified by the user.
! ====================================================

allocate(grid%coe2(-grid%norder:grid%norder,3+grid%lap_dir_num))

call fornberg(2, grid%norder, grid%coe2(:,1), ierr)

#ifdef MPI
call mpi_allreduce(ierr, ii, 1, mpi_integer, mpi_max, comm, mpinfo)
ierr = ii
#endif

if (ierr /= 0) then
        write(9,*) ' ERROR: Wrong parameter in call of Fornberg'
        write(9,*) ' STOP in init_var'
        return
endif



!  Renormalize coekes with respect to the grid spacing. First to the
!  new directions for non-orthogonal grid.
if (grid%lap_dir_num > 0) then
        write(9,*) ' grid%lap_dir_num > 0'

        do ii = 1,grid%lap_dir_num
                grid%coe2(:,3+ii) = -grid%b_lap(3+ii)* &
                        grid%coe2(:,1)/(grid%lap_dir_step(ii)**2)
        enddo
endif

grid%coe2(:,3) = -grid%b_lap(3)*grid%coe2(:,1)/(grid%step(3)**2)
grid%coe2(:,2) = -grid%b_lap(2)*grid%coe2(:,1)/(grid%step(2)**2)
grid%coe2(:,1) = -grid%b_lap(1)*grid%coe2(:,1)/(grid%step(1)**2)













! ====================================================
!  Get coefficients for double-grid interpolation. If there are
!  not interpolating point between neighbors in the grid (that is,
!  grid%ndouble = 1), then the coefficients are 1.
!
!  \note AJB: need explanation on the double grid method's purpose here.
!             i'm not sure this was a good thing to do in parsec btw.
! ====================================================

allocate(grid%fdouble(-grid%ndouble+1:grid%ndouble-1))

grid%invd = one/real(grid%ndouble,dp)

do ii = -grid%ndouble+1, grid%ndouble-1
        grid%fdouble(ii) = (one - real(abs(ii),dp)*grid%invd)*grid%invd
enddo















#ifdef MPI

! ====================================================
!  Distribute cluster structure (except clust%name).
! ====================================================

call mpi_bcast(clust%type_num, 1,mpi_integer  ,masterid,comm,mpinfo)

if (.not. parallel%iammaster) then
        call create_cluster(clust%atom_num,clust)

        allocate (clust%natmi (clust%type_num))

! #ifdef AJB_DEBUG
!      write(9,*) ' created cluster because I am not master'
! #endif
endif

call MPI_BCAST(clust%natmi, clust%type_num,MPI_INTEGER ,masterid,comm,mpinfo)
call MPI_BCAST(clust%mvat, clust%atom_num,MPI_INTEGER ,masterid,comm,mpinfo)
call MPI_BCAST(clust%xatm, clust%atom_num,MPI_DOUBLE_PRECISION ,masterid,comm,mpinfo)
call MPI_BCAST(clust%yatm, clust%atom_num,MPI_DOUBLE_PRECISION ,masterid,comm,mpinfo)
call MPI_BCAST(clust%zatm, clust%atom_num,MPI_DOUBLE_PRECISION ,masterid,comm,mpinfo)
call MPI_BCAST(clust%amass, clust%atom_num,MPI_DOUBLE_PRECISION ,masterid,comm,mpinfo)
call MPI_BCAST(clust%force, clust%atom_num*3,MPI_DOUBLE_PRECISION ,masterid,comm,mpinfo)
! #ifdef AJB_DEBUG
!      write(9,*) ' just BCASTed the first batch of clust data'
! #endif




! ====================================================
!    Variables for explicit extra charges
! ====================================================

if (clust%has_ptchrg) then
        call mpi_bcast(clust%npttyp, 1, mpi_integer, masterid, comm, mpinfo)
        call mpi_bcast(clust%nptchrg, 1, mpi_integer, masterid, comm, mpinfo)

        if (.not. parallel%iammaster) then
                allocate(clust%nptt(clust%npttyp))
                allocate(clust%qpt(clust%npttyp))
                allocate(clust%xpt(clust%nptchrg))
                allocate(clust%ypt(clust%nptchrg))
                allocate(clust%zpt(clust%nptchrg))
        endif

        call mpi_bcast(clust%nptt, clust%npttyp, mpi_integer, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%qpt, clust%npttyp, mpi_double_precision, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%xpt, clust%nptchrg, mpi_double_precision, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%ypt, clust%nptchrg, mpi_double_precision, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%zpt, clust%nptchrg, mpi_double_precision, &
                masterid, comm, mpinfo)
endif

if (clust%has_charged_sheet) then
        call mpi_bcast(clust%number_charged_sheet_type, 1, mpi_integer, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%number_charged_sheets, 1, mpi_integer, &
                masterid, comm, mpinfo)

        if (.not. parallel%iammaster) then
                allocate(clust%number_charged_sheets_per_type( &
                        clust%number_charged_sheet_type))
                allocate(clust%sheet_charge_of_type( &
                        clust%number_charged_sheet_type))
                allocate(clust%z_charged_sheets( &
                        clust%number_charged_sheets))
        endif

        call mpi_bcast(clust%number_charged_sheets_per_type, &
                clust%number_charged_sheet_type, mpi_integer, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%sheet_charge_of_type, &
                clust%number_charged_sheet_type, mpi_double_precision, &
                masterid, comm, mpinfo)
        call mpi_bcast(clust%z_charged_sheets, clust%number_charged_sheets, &
                mpi_double_precision, masterid, comm, mpinfo)
endif










! ====================================================
!
!  Distribute entire p_pot structure.
!
! ====================================================

call mpi_bcast(p_pot%type_num, 1, mpi_integer, masterid, comm, mpinfo)
call mpi_bcast(p_pot%norder, 1, mpi_integer, masterid, comm, mpinfo)

if (.not. parallel%iammaster) then
        ! KHL: allocate some arrays in this function (including p_pot%ns)
        call create_pseudo_potential(p_pot%type_num, p_pot%norder, p_pot)
endif

call mpi_bcast(p_pot%ns, p_pot%type_num, mpi_integer, masterid, comm, mpinfo)

if (.not. parallel%iammaster) then
        nmax = maxval(p_pot%ns)

        ! KHL: also allocate some arrays in this function
        call pseudo_potential_set_mxpot(nmax, p_pot)
endif

call mpi_bcast(p_pot%is_so   , 1, mpi_logical  ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%oldinpformat, 1, mpi_logical  ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%nlocp  ,   p_pot%type_num,mpi_integer , &
        masterid, comm, mpinfo)
call mpi_bcast(p_pot%loc    ,   p_pot%type_num,mpi_integer , &
        masterid, comm, mpinfo)
call mpi_bcast(p_pot%icore  ,   p_pot%type_num,mpi_integer , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%rcore  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%eleatm , p_pot%type_num*4,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%spol   ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%zion   ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%ekbi   , p_pot%type_num*4,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%par_a  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%par_b  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%par_c  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%alpha  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%beta1  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%acore  ,   p_pot%type_num,mpi_double_precision , &
        masterid,comm,mpinfo)
call mpi_bcast(p_pot%uspline,   p_pot%type_num,mpi_logical ,masterid, &
        comm,mpinfo)




nmax = (p_pot%mxpot + p_pot%norder + 1) * p_pot%type_num
call mpi_bcast(p_pot%rs      ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%denc    ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%vion    ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%rho_r   ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%drhodr  ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2rhodr ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%dvion   ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2vion  ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%ddenc   ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2denc  ,   nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%vw      , nmax*4,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%dvw     , nmax*4,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2vw    , nmax*4,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%wfspd   , nmax*4,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%dvr_ion , 2*nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2vr_ion, 2*nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%dvr_so  , 2*nmax,mpi_double_precision ,masterid,comm,mpinfo)
call mpi_bcast(p_pot%d2vr_so , 2*nmax,mpi_double_precision ,masterid,comm,mpinfo)

if (p_pot%is_so) then
        call mpi_bcast(p_pot%so, p_pot%type_num, mpi_logical, &
                masterid, comm, mpinfo)
        call mpi_bcast(p_pot%cc, 2*p_pot%type_num, mpi_double_precision, &
                masterid, comm, mpinfo)

        nmax = (p_pot%mxpot + p_pot%norder + 1)*p_pot%type_num*2

        call mpi_bcast(nmax, 1, mpi_integer, masterid, comm, mpinfo)
        call mpi_bcast(p_pot%vsor, nmax, mpi_double_precision, &
                masterid,comm,mpinfo)
        call mpi_bcast(p_pot%vionr, nmax,mpi_double_precision  , &
                masterid,comm,mpinfo)
else
        p_pot%so = .false.
endif

if (elec_st%ncl) then
        if (.not. parallel%iammaster) then
             allocate(elec_st%init_mag(3,clust%atom_num))
        endif

        call MPI_BCAST(elec_st%init_mag,3*clust%atom_num, &
                MPI_DOUBLE_PRECISION,masterid,comm,mpinfo)
endif

allocate(elec_st%magmom(2*elec_st%nstate,kpnum))


write(9,*) ' survived BCASTS'
#endif











! ====================================================
!  Set up random number generators
! ====================================================

call vecgen%settype(inputs%vecgen_rng_type, ierr=ierr)
call vecgen%init(seed=solver%rng_seed)
call vecgen%alloc(errcode=ierr)

write(9,*) 'alloc_random_generator shape=', shape(vecgen%stream)

call vecgen%create(ierr)
write(9,*) 'createStream err=', ierr
ierr = 0

!
! one of these should be used for moldyn as well
call moldyngen % settype(inputs % vecgen_rng_type,ierr)

! KHL: Be careful that for a simple implementation of 
!      init_random_generator_pure() (i.e., using the Fortran intrinsic 
!      function random_seed()) I guess there is 
!      only one global random seed within the same process, and 
!      the initialization here
!      of the random seed will affect the one of vecgen.
!      That is, to keep consistent it is better to set 
!      vector_rng_seed and mol_rng_seed the same in parsec.in.
call moldyngen % init(seed=mol_dynamic % rng_seed)

call moldyngen % alloc()
call moldyngen % create(ierr)












! ====================================================
!  Create nloc_p_pot structure.
! ====================================================

nmax = 0
do ity = 1, clust%type_num
do ii = 1, p_pot%nlocp(ity)
        if (ii /= p_pot%loc(ity)) nmax = nmax + (2*ii - 1)*clust%natmi(ity)
enddo
enddo
call create_nonloc_pseudo_pot(nmax, clust%atom_num, nloc_p_pot)
















allocate(elec_st%eig(elec_st%nrep,kpnum,elec_st%nspin))

nmax = (solver%winsize + elec_st%nstate) * elec_st%nrep
allocate(elec_st%irep(nmax,kpnum,elec_st%nspin))

elec_st%irep(:,:,:) = 1










! ====================================================
!    Create eigenstate structures with empty arrays
! ====================================================

do isp  = 1, elec_st%nspin
do kplp = 1, kpnum
do irp  = 1, elec_st%nrep
        elec_st%eig(irp,kplp,isp)%nstates = -1
        elec_st%eig(irp,kplp,isp)%nstates_max = -1
        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup = -1
        elec_st%eig(irp,kplp,isp)%nstates_per_colgroup_max = -1
        elec_st%eig(irp,kplp,isp)%mm = -1
        elec_st%eig(irp,kplp,isp)%nn = -1
        elec_st%eig(irp,kplp,isp)%nec = -1
        elec_st%eig(irp,kplp,isp)%homo = -1
        elec_st%eig(irp,kplp,isp)%lumo = -1
enddo
enddo
enddo

end subroutine init_var
!===============================================================
end module init_var_module
