module ewald_module
   implicit none
   contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Computes the Ewald contribution to the total energy and forces
! for slab geometry by performing two convergent summations, 
! one over lattice vectors and the other over reciprocal lattice vectors.
!
! Full description and equations can be found in the book 
! "First-Principles Calculations In Real-Space Formalism"
! by Tomoya Ono and Kikuji Hirose, Appendix A.
!
! Author: Ayelet Mor (2007) 
!
!---------------------------------------------------------------
subroutine ewald_slab(clust,pbc,eewald,ipr,zv)

  use constants
  use cluster_module
  use pbc_module
  use aux, only : matvec3, fplus, fminus, my_erfc
  use force_charged_sheet_module, only : force_charged_sheet
  implicit none
  
  !
  ! Input/Output variables:
  !
 
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! pbc related data
  type (pbc_data), intent(inout) :: pbc
  ! Ewald energy summation
  real(dp), intent(out) :: eewald
  ! print flag
  integer, intent(in) :: ipr
  ! Vector of Electric charge for each chemical element
  real(dp), intent(in) :: zv(clust%type_num)


  !
  ! Work variables:
  !
  
  ! number of G vectors in the reciprocal space
  integer :: ng
  ! area of one unit cell
  real(dp) :: latt_area
  ! pia = pi/latt_area
  real(dp) :: pia
  ! sqrtpi = sqrt(pi)
  real(dp) :: sqrtpi
  ! inveta = 1 / eta, 
  ! eta is the partitioning constant between the real and reciprocal space
  real(dp) :: inveta
  ! eta_sqrtpi = eta / sqrt(pi)
  real(dp) :: eta_sqrtpi
  ! rmax - the maximum for real space P vectors
  real(dp) :: rmax
  ! maximum P vector values in each direction (u & v)
  integer :: imx, jmx
  ! Charged-sheet energy
  real(dp) :: enucsh

  ! Vector quantities:
  real(dp) :: &
       ratom(3, pbc%atom_num*pbc%type_num), &   ! ratom(ia) = coordinates for atom no. ia
       zz(pbc%atom_num*pbc%type_num)            ! zz(ia) = the electric charge on atom ia

  ! Reciprocal space variables:
  real(dp) :: &
       gvec(3), &        ! the G vector
       gvec_size, &      ! gvec_size = |G|
       zdiff, &          ! Z(ja) - Z(ia)
       foutput1, &       ! foutput1 = fplus(G(ig),Z(ja)-Z(ia))
       foutput2, &       ! foutput2 = fminus(G(ig),Z(ja)-Z(ia))
       gmultri, &        ! gmultri = G*R(ia)
       cosi,    &        ! cos(gmultri), cos(gmultrj)
       sini              ! sin(gmultri), sin(gmultrj)
       
  ! General summation variables
  real(dp) :: &
       rrz , &           ! rrz = abs(ratom(3,ja) - ratom(3,ia))
       rrz_sign, &       ! rrz_sign = (Z(ja) - Z(ia))/|Z(ja) - Z(ia)|
       zdiff_eta, &      ! zdiff_eta = eta * rrz
       erf_output        ! erf_output = erf(zdiff_eta)

  ! Real space variables:
  real(dp) :: &
       adot(3,3), &      ! adot = pbc%adot
       bdot(3,3), &      ! bdot = pbc%bdot
       rp(3), &          ! real space coefficients of vector P
       pvec(3), &        ! the vector (P + R(ja) - R(ia))
       rmod, &           ! rmod = |P + R(ja) - R(ia)|
       arg, &            ! arg = eta * rmod
       tmp, tmp2  

  ! Counters:
  integer :: i, j, ia, ja, ig, natom, ii, jj, n

  ! Summing variables
  real(dp) :: &
       esumr, &          ! energy sum over real-space
       esumg, &          ! energy sum over the reciprocal space
       esum0, &          ! energy sum over ia == ja
       esumm, &          ! general energy sum over ia and ja
       esub              ! energy sub-summation in real-space

  real(dp), dimension(3,pbc%atom_num) :: &
       fsumr, &          ! force sum over real-space
       fsumg, &          ! force sum over reciprocal space
       fsumm             ! general force sum over ia and ja

  !real(dp), dimension(3,pbc%atom_num) :: &
  !     tau               ! total force in latt vec coordinates
  
  real(dp) :: fsub(3)    ! force sub-summationn in real-space

  real(dp) :: &
       sum_fact, &       ! multipliance factor
       sum_fact2, &      ! multipliance factor
       sum_fact3         ! multipliance factor

  ! Convergenace check
  real(dp) :: prevesumg, prevfsumg(3)

  ! Constants
  real(dp), parameter :: eta = 0.5d0     ! Determines the border between the two summations
  real(dp), parameter :: twopio = 0.5d0/pi
  real(dp), parameter :: small = 1.d-9
  real(dp), parameter :: small2 = 6.5d0
  real(dp), parameter :: tol = 200.d0

  ! Temporal variables
  real(dp) :: tmpvec(3), rtmp(3)
    
  !---------------------------------------------------------------

  !
  ! Initialize variables
  !
  latt_area = abs( pbc%latt_vec(1,1) * pbc%latt_vec(2,2) - &
       pbc%latt_vec(2,1) * pbc%latt_vec(1,2) )
  pia = pi / latt_area
  sqrtpi = sqrt(pi)
  inveta = one / eta
  eta_sqrtpi = eta / sqrtpi

  ng = pbc%ng
  adot = pbc%adot
  bdot = pbc%bdot

  gvec(:) = zero
  rp(:) = zero
  pvec(:) = zero
  ratom(:,:) = zero

  rmax = sqrt(tol/eta)
  !AJB: I wish someone had commented about these lines.
  imx = int(rmax*sqrt(bdot(1,1))*twopio) + 1
  jmx = int(rmax*sqrt(bdot(2,2))*twopio) + 1

  write(9,*) 'ewald real space limits ', imx, jmx

  ! Define coordinates of all atoms with respect to the corner of the
  ! periodic cell.


  natom = 0
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        natom = natom + 1

        tmpvec(1)=clust%xatm(natom)
        tmpvec(2)=clust%yatm(natom)
        tmpvec(3)=clust%zatm(natom)

        ! Multiplying by the bvec matrix to find
        ! the coordinates relative to lattice vec.
        ! Since (u,v,w) = (x,y,z) * A^-1 = (x,y,z) * B' /twopi
        call matvec3('T',pbc%bvec,tmpvec,pbc%rat(1:3,j,i))
     enddo
  enddo




  ! Build the Z table (electric charge) for all atoms
  ! and fill in their coordinates
  natom = 0
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        natom = natom + 1
        zz(natom) = zv(i)
        ratom(1:3,natom) = pbc%rat(1:3,j,i)*twopio
        write(9,*) 'ratom(',natom,')=',ratom(1:3,natom)
        do n = 1, 3
           if (ratom(n,natom) >= one) &
                ratom(n,natom) = modulo(ratom(n,natom) + eight,one)
           if (ratom(n,natom) < zero) &
                ratom(n,natom) = modulo(ratom(n,natom),one)
        enddo
     enddo
  enddo

  !
  ! Sum over the G-space (reciprocal space)
  ! stop when convergence is reached
  esumg = zero
  fsumg(:,:) = zero
  prevesumg = zero
  prevfsumg(:) = zero

  write(9,*) 'ng=',ng

  ng=min(ng,1000)

  do ig = 2, ng
     gvec = pbc%kgv(:,ig)
     gvec(3) = 0
     tmpvec=gvec(1)*pbc%bvec(:,1)+gvec(2)*pbc%bvec(:,2)
     gvec_size = sqrt(dot_product(tmpvec,tmpvec))
     sum_fact = one / gvec_size
     
     do ja = 1, natom

        do ia = 1, natom
           rtmp=ratom(:,ja)-ratom(:,ia)
           gmultri = twopi*dot_product(gvec,rtmp)
           cosi = cos(gmultri)
           sini = sin(gmultri)
           
           zdiff = clust%zatm(ja) - clust%zatm(ia)
           call fplus(gvec_size,zdiff,eta,foutput1)
           call fminus(gvec_size,zdiff,eta,foutput2)


           sum_fact2 = zz(ja)*zz(ia)*sum_fact*foutput1
           sum_fact3 = zz(ja)*zz(ia)*foutput2

           esumg = esumg + sum_fact2 * cosi
           fsumg(1,ia) = fsumg(1,ia) + tmpvec(1) * sum_fact2 * sini
           fsumg(2,ia) = fsumg(2,ia) + tmpvec(2) * sum_fact2 * sini
           fsumg(3,ia) = fsumg(3,ia) + sum_fact3 * cosi
        enddo
     enddo
     
     ! Check if convergence is reached.
     ! This part should be checked again for better convergence parameters. AYELET


  enddo

  esumg = esumg * pia
  fsumg = -fsumg * pia


  !
  ! Sum the general summation
  !
  esumm = zero
  fsumm(:,:) = zero

  do ja = 1, natom
     sum_fact = zz(ja)
     do ia = 1, natom
        rrz = abs(clust%zatm(ja) - clust%zatm(ia))
        if(rrz>0) then
           rrz_sign = (clust%zatm(ja) - clust%zatm(ia))/rrz
        else
           rrz_sign = 1
        endif
        zdiff_eta = rrz*eta
        erf_output=1-my_erfc(zdiff_eta)
!        call erf(zdiff_eta,erf_output)

        esumm = esumm + sum_fact*zz(ia) * (inveta*exp(-(zdiff_eta**2)) + sqrtpi*rrz*erf_output)
        fsumm(3,ia) = fsumm(3,ia) + sum_fact*zz(ia) * erf_output * rrz_sign
     enddo
  enddo

  esumm = esumm * (-two*sqrtpi/latt_area)
  fsumm = fsumm * (-two*pia)

  !
  ! Sum over the real space  
  ! the summation is devided into two to avoid the rmod==0 case 

  esum0 = zero
  esumr = zero
  fsumr(:,:) = zero

!  esum0 = esum0 - two*eta_sqrtpi

  do ja = 1, natom
     esumr = esumr - zz(ja)*zz(ja)*two*eta_sqrtpi
  enddo


  ! Sum over ia \= ja. 

  esub = zero

  do ja = 1, natom
     do ia = 1, natom
        esub = zero
        fsub = zero
        sum_fact = zz(ja) * zz(ia)
        rp(3) = clust%zatm(ja) - clust%zatm(ia)

        do ii = -imx, imx          
           rp(1) = real(ii,dp) + ratom(1,ja) - ratom(1,ia) 
           do jj = -jmx, jmx
              rp(2) = real(jj,dp) + ratom(2,ja) - ratom(2,ia)
                          
              call matvec3('N',adot,rp,pvec)
              call matvec3('N',pbc%latt_vec,rp,tmpvec)
              rmod = sqrt(dot_product(rp,pvec))
              
              ! avoid rmod = 0
              if (rmod == 0) cycle
              
              arg = rmod * eta
              if (arg < small2) then
                 tmp = my_erfc(arg) / rmod
                 tmp2 = (tmp + two*eta_sqrtpi*exp(-arg*arg))/(rmod*rmod)
                 esub = esub + tmp
                 fsub = fsub + tmpvec * tmp2
              endif
           enddo
        enddo

        esum0 = esum0 + sum_fact * esub
        fsumr(:,ia) = fsumr(:,ia) - sum_fact * fsub
!        fsumr(:,ja) = fsumr(:,ja) - sum_fact * fsub

     enddo
  enddo

  ! The Ewald energy is the sum of all the above summations

  write(9,*) 'ewald terms', esumg, esumm, esum0, esumr

  eewald = esumg + esumm + esum0 + esumr

  !eewald = eewald/2
 
  !
  ! Set the ionic forces and print if flaged
  ! note - returned force is in units of real space lattice vectors
  ! printed force is in cartesian coordinates

  do ii = 1, 3
     clust%force(ii,:) = 2*(fsumr(ii,:)+fsumm(ii,:)+fsumg(ii,:))
!     do jj = 1, 3
!        clust%force(ii,:) = clust%force(ii,:) + &
!             pbc%bdot(ii,jj)*fsumg(jj,:)*twopio
!     enddo
  enddo

!  do i = 1, clust%atom_num
!     call matvec3('N',pbc%latt_vec,clust%force(1,i),tau(1,i))
!     clust%force(:,i)=tau(:,i)
!  enddo


  ! Calculate forces and energy from sheet-nuclei interaction
  ! when charged sheets are present.
  if (clust%has_charged_sheet) then
     call force_charged_sheet(clust,pbc,zv,ipr,enucsh)
     eewald = eewald + enucsh
  endif


  ! if print flag on, print the ion-ion forces
  if(ipr >= 1) then
     write(7,*)
     write(7,*) 'Forces from ion-ion interaction:'
     write(7,*) '================================'
     write(7,22)
     write(7,*)
     do i = 1, clust%atom_num
        write(7,20) i,clust%xatm(i),clust%yatm(i),clust%zatm(i),clust%force(:,i)
     enddo
     write(7,*)
     write(7,*) 'fsumg'
     do i=1, clust%atom_num
        write(7,*) fsumg(:,i)
     enddo
     write(7,*) 'fsumr'
     do i=1, clust%atom_num
        write(7,*) fsumr(:,i)
     enddo
     write(7,*) 'fsumm'
     do i=1, clust%atom_num
        write(7,*) fsumm(:,i)
     enddo
  endif


20 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
22 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ')



end subroutine ewald_slab
!===============================================================
!
! Slab Ewald contribution including external point charges.
! This is used by FDET AFM slab calculations where sample point
! charges must contribute to ion-ion energy and forces.
!
!---------------------------------------------------------------
subroutine ewald_slab_pt(clust,pbc,eewald,ipr,zv,zvpt)

  use constants
  use cluster_module
  use pbc_module
  use aux, only : matvec3, fplus, fminus, my_erfc, alccheck
  use force_charged_sheet_module, only : force_charged_sheet
  implicit none

  type(cluster), intent(inout) :: clust
  type(pbc_data), intent(inout) :: pbc
  real(dp), intent(out) :: eewald
  integer, intent(in) :: ipr
  real(dp), intent(in) :: zv(clust%type_num)
  real(dp), intent(in) :: zvpt(clust%npttyp)

  integer :: ng
  integer :: imx, jmx
  integer :: i, j, ia, ja, ig, natom, natom2, ii, jj, n
  integer :: total_charges
  integer :: alcstat

  real(dp) :: latt_area
  real(dp) :: pia
  real(dp) :: sqrtpi
  real(dp) :: inveta
  real(dp) :: eta_sqrtpi
  real(dp) :: rmax
  real(dp) :: enucsh

  real(dp) :: gvec(3)
  real(dp) :: gvec_size
  real(dp) :: zdiff
  real(dp) :: foutput1
  real(dp) :: foutput2
  real(dp) :: gmultri
  real(dp) :: cosi
  real(dp) :: sini
  real(dp) :: rrz
  real(dp) :: rrz_sign
  real(dp) :: zdiff_eta
  real(dp) :: erf_output
  real(dp) :: adot(3,3)
  real(dp) :: bdot(3,3)
  real(dp) :: rp(3)
  real(dp) :: pvec(3)
  real(dp) :: rmod
  real(dp) :: arg
  real(dp) :: tmp
  real(dp) :: tmp2
  real(dp) :: esumr
  real(dp) :: esumg
  real(dp) :: esum0
  real(dp) :: esumm
  real(dp) :: esub
  real(dp) :: fsub(3)
  real(dp) :: sum_fact
  real(dp) :: sum_fact2
  real(dp) :: sum_fact3
  real(dp) :: prevesumg
  real(dp) :: prevfsumg(3)
  real(dp) :: tmpvec(3)
  real(dp) :: rtmp(3)

  real(dp), allocatable :: ratpt(:,:,:)
  real(dp), allocatable :: ratom(:,:)
  real(dp), allocatable :: zz(:)
  real(dp), allocatable :: zatpt(:)
  real(dp), allocatable :: fsumr(:,:)
  real(dp), allocatable :: fsumg(:,:)
  real(dp), allocatable :: fsumm(:,:)

  real(dp), parameter :: eta = 0.5d0
  real(dp), parameter :: twopio = 0.5d0/pi
  real(dp), parameter :: small2 = 6.5d0
  real(dp), parameter :: tol = 200.d0

  if (clust%npttyp <= 0 .or. clust%nptchrg <= 0) then
     call ewald_slab(clust,pbc,eewald,ipr,zv)
     return
  endif

  total_charges = clust%atom_num + clust%nptchrg

  allocate(ratpt(3,clust%nptchrg,clust%npttyp), stat=alcstat)
  call alccheck('ratpt', 3*clust%nptchrg*clust%npttyp, alcstat)
  allocate(ratom(3,total_charges), zz(total_charges), &
       zatpt(total_charges), stat=alcstat)
  call alccheck('slab point charge arrays', 5*total_charges, alcstat)
  allocate(fsumr(3,total_charges), fsumg(3,total_charges), &
       fsumm(3,total_charges), stat=alcstat)
  call alccheck('slab point charge force arrays', 9*total_charges, alcstat)

  latt_area = abs(pbc%latt_vec(1,1) * pbc%latt_vec(2,2) - &
       pbc%latt_vec(2,1) * pbc%latt_vec(1,2))
  pia = pi / latt_area
  sqrtpi = sqrt(pi)
  inveta = one / eta
  eta_sqrtpi = eta / sqrtpi

  ng = pbc%ng
  adot = pbc%adot
  bdot = pbc%bdot

  gvec(:) = zero
  rp(:) = zero
  pvec(:) = zero
  ratom(:,:) = zero
  ratpt(:,:,:) = zero
  zz(:) = zero
  zatpt(:) = zero

  rmax = sqrt(tol/eta)
  imx = int(rmax*sqrt(bdot(1,1))*twopio) + 1
  jmx = int(rmax*sqrt(bdot(2,2))*twopio) + 1

  write(9,*) 'ewald real space limits ', imx, jmx

  natom = 0
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        natom = natom + 1
        tmpvec(1) = clust%xatm(natom)
        tmpvec(2) = clust%yatm(natom)
        tmpvec(3) = clust%zatm(natom)
        call matvec3('T',pbc%bvec,tmpvec,pbc%rat(1:3,j,i))
     enddo
  enddo

  natom2 = 0
  do i = 1, clust%npttyp
     do j = 1, clust%nptt(i)
        natom2 = natom2 + 1
        tmpvec(1) = clust%xpt(natom2)
        tmpvec(2) = clust%ypt(natom2)
        tmpvec(3) = clust%zpt(natom2)
        call matvec3('T',pbc%bvec,tmpvec,ratpt(1:3,j,i))
     enddo
  enddo

  natom = 0
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        natom = natom + 1
        zz(natom) = zv(i)
        ratom(1:3,natom) = pbc%rat(1:3,j,i)*twopio
        write(9,*) 'ratom(',natom,')=',ratom(1:3,natom)
        do n = 1, 3
           if (ratom(n,natom) >= one) &
                ratom(n,natom) = modulo(ratom(n,natom) + eight,one)
           if (ratom(n,natom) < zero) &
                ratom(n,natom) = modulo(ratom(n,natom),one)
        enddo
     enddo
  enddo

  do i = 1, clust%npttyp
     do j = 1, clust%nptt(i)
        natom = natom + 1
        zz(natom) = zvpt(i)
        ratom(1:3,natom) = ratpt(1:3,j,i)*twopio
        write(9,*) 'ratom(',natom,')=',ratom(1:3,natom)
        do n = 1, 3
           if (ratom(n,natom) >= one) &
                ratom(n,natom) = modulo(ratom(n,natom) + eight,one)
           if (ratom(n,natom) < zero) &
                ratom(n,natom) = modulo(ratom(n,natom),one)
        enddo
     enddo
  enddo

  natom2 = 0
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        natom2 = natom2 + 1
        zatpt(natom2) = clust%zatm(natom2)
     enddo
  enddo

  ii = 0
  do i = 1, clust%npttyp
     do j = 1, clust%nptt(i)
        natom2 = natom2 + 1
        ii = ii + 1
        zatpt(natom2) = clust%zpt(ii)
     enddo
  enddo

  esumg = zero
  fsumg(:,:) = zero
  prevesumg = zero
  prevfsumg(:) = zero

  write(9,*) 'ng=',ng
  ng = min(ng,1000)

  do ig = 2, ng
     gvec = pbc%kgv(:,ig)
     gvec(3) = zero
     tmpvec = gvec(1)*pbc%bvec(:,1) + gvec(2)*pbc%bvec(:,2)
     gvec_size = sqrt(dot_product(tmpvec,tmpvec))
     sum_fact = one / gvec_size

     do ja = 1, total_charges
        do ia = 1, total_charges
           rtmp = ratom(:,ja) - ratom(:,ia)
           gmultri = twopi*dot_product(gvec,rtmp)
           cosi = cos(gmultri)
           sini = sin(gmultri)

           zdiff = zatpt(ja) - zatpt(ia)
           call fplus(gvec_size,zdiff,eta,foutput1)
           call fminus(gvec_size,zdiff,eta,foutput2)

           sum_fact2 = zz(ja)*zz(ia)*sum_fact*foutput1
           sum_fact3 = zz(ja)*zz(ia)*foutput2

           esumg = esumg + sum_fact2 * cosi
           fsumg(1,ia) = fsumg(1,ia) + tmpvec(1) * sum_fact2 * sini
           fsumg(2,ia) = fsumg(2,ia) + tmpvec(2) * sum_fact2 * sini
           fsumg(3,ia) = fsumg(3,ia) + sum_fact3 * cosi
        enddo
     enddo
  enddo

  esumg = esumg * pia
  fsumg = -fsumg * pia

  esumm = zero
  fsumm(:,:) = zero

  do ja = 1, total_charges
     sum_fact = zz(ja)
     do ia = 1, total_charges
        rrz = abs(zatpt(ja) - zatpt(ia))
        if (rrz > zero) then
           rrz_sign = (zatpt(ja) - zatpt(ia))/rrz
        else
           rrz_sign = one
        endif
        zdiff_eta = rrz*eta
        erf_output = one - my_erfc(zdiff_eta)

        esumm = esumm + sum_fact*zz(ia) * &
             (inveta*exp(-(zdiff_eta**2)) + sqrtpi*rrz*erf_output)
        fsumm(3,ia) = fsumm(3,ia) + sum_fact*zz(ia) * &
             erf_output * rrz_sign
     enddo
  enddo

  esumm = esumm * (-two*sqrtpi/latt_area)
  fsumm = fsumm * (-two*pia)

  esum0 = zero
  esumr = zero
  fsumr(:,:) = zero

  do ja = 1, total_charges
     esumr = esumr - zz(ja)*zz(ja)*two*eta_sqrtpi
  enddo

  esub = zero
  do ja = 1, total_charges
     do ia = 1, total_charges
        esub = zero
        fsub = zero
        sum_fact = zz(ja) * zz(ia)
        rp(3) = zatpt(ja) - zatpt(ia)

        do ii = -imx, imx
           rp(1) = real(ii,dp) + ratom(1,ja) - ratom(1,ia)
           do jj = -jmx, jmx
              rp(2) = real(jj,dp) + ratom(2,ja) - ratom(2,ia)

              call matvec3('N',adot,rp,pvec)
              call matvec3('N',pbc%latt_vec,rp,tmpvec)
              rmod = sqrt(dot_product(rp,pvec))

              if (rmod == zero) cycle

              arg = rmod * eta
              if (arg < small2) then
                 tmp = my_erfc(arg) / rmod
                 tmp2 = (tmp + two*eta_sqrtpi*exp(-arg*arg))/(rmod*rmod)
                 esub = esub + tmp
                 fsub = fsub + tmpvec * tmp2
              endif
           enddo
        enddo

        esum0 = esum0 + sum_fact * esub
        fsumr(:,ia) = fsumr(:,ia) - sum_fact * fsub
     enddo
  enddo

  write(9,*) 'ewald terms', esumg, esumm, esum0, esumr

  eewald = esumg + esumm + esum0 + esumr

  do ii = 1, 3
     clust%force(ii,1:clust%atom_num) = &
          two*(fsumr(ii,1:clust%atom_num) + &
          fsumm(ii,1:clust%atom_num) + fsumg(ii,1:clust%atom_num))
  enddo

  if (clust%has_charged_sheet) then
     call force_charged_sheet(clust,pbc,zv,ipr,enucsh)
     eewald = eewald + enucsh
  endif

  if (ipr >= 1) then
     write(7,*)
     write(7,*) 'Forces from ion-ion and point-charge interaction:'
     write(7,*) '================================================'
     write(7,22)
     write(7,*)
     do i = 1, clust%atom_num
        write(7,20) i, clust%xatm(i), clust%yatm(i), &
             clust%zatm(i), clust%force(:,i)
     enddo
     write(7,*)
  endif

  deallocate(ratpt, ratom, zz, zatpt, fsumr, fsumg, fsumm)

20 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
22 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ')

end subroutine ewald_slab_pt
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Computes the Ewald contribution to the total energy and forces
! by performing two convergent summations, one over lattice
! vectors and the other over reciprocal lattice vectors.
!
! Adapted from plane-wave programs written by S. Froyen and
! J. L. Martins.
!
!---------------------------------------------------------------
subroutine ewald_sum(clust,pbc,eewald,ipr,zv)

  use constants
  use cluster_module
  use pbc_module
  use aux, only : matvec3, my_erfc
  implicit none
  !
  ! Input/Output variables:
  !
  ! the cluster
  type (cluster), intent(inout) :: clust
  ! pbc related data
  type (pbc_data), intent(inout) :: pbc
  ! print flag
  integer, intent(in) :: ipr
  ! Ewald summation
  real(dp), intent(out) :: eewald

  real(dp), intent(in) :: zv(clust%type_num)
  !
  ! Work variables:
  !
  ! allocation check
  integer alcstat

  integer :: i, j, k, n, imx, jmx, kmx, ii, jj, ngg, nss
  real(dp) :: vcell,arg,bdot(3,3),adot(3,3)

  real(dp) :: fsub(3),rp(3),tt(3)
  real(dp) :: eps,seps,sepi,rmax,fpiv,fpiv2
  real(dp) :: esumg,esumr,esum0,ztemp,rmod,exp1,exp2
  real(dp) :: esub,sumc,sumr,gdr,cosg
  real(dp) :: sing,expgc,expgr
  real(dp), dimension(3,pbc%atom_num) ::  &
       fsumg, fcg, fsg, fsumr, tau, rc

  real(dp), allocatable :: expg(:)
  real(dp) :: zz(pbc%atom_num*pbc%type_num)
  real(dp) :: pi_dev_eps_v
  ! constants
  real(dp), parameter :: twopio = 0.5d0/pi
  real(dp), parameter :: small = 1.d-20
  real(dp), parameter :: p25 = 0.25d0
  real(dp), parameter :: tol = 200.d0, small2 = 6.5d0

  !---------------------------------------------------------------

  bdot = pbc%bdot

  adot = pbc%adot

  allocate(expg(pbc%nstar),stat=alcstat)
  call alccheck('expg',pbc%nstar,alcstat)

  vcell = pbc%vcell
  eps = p25*two*pbc%ek(pbc%nstar)/tol
  seps = sqrt(eps)
  sepi = two*seps/sqrt(pi)
  rmax = sqrt(tol/eps)
  fpiv = four*pi/vcell
  fpiv2 = two*fpiv

  imx = int(rmax*sqrt(bdot(1,1))*twopio) + 1
  jmx = int(rmax*sqrt(bdot(2,2))*twopio) + 1
  kmx = int(rmax*sqrt(bdot(3,3))*twopio) + 1

  ! Store data for atoms into new arrays and fold into first cell:
  ! prevents errors in sums from too small a real space sum.
  k = 0
  if(ipr >= 0) then
  write(7,*) 'Reciprocal lattice atom data'
  endif
  do i = 1, clust%type_num
     do j = 1, clust%natmi(i)
        k = k + 1
        zz(k) = zv(i)
        rc(1:3,k) =  pbc%rat(1:3,j,i)*twopio
    if(ipr >= 0) then
        write(7,'(3(3x,f11.6))') pbc%rat(:,j,i)
    endif
        do n = 1, 3
           if (rc(n,k) >= one) &
                rc(n,k) = modulo(rc(n,k) + eight,one)
           if (rc(n,k) < zero) &
                rc(n,k) = modulo(rc(n,k),one)
        enddo
     enddo
  enddo

  esumg = zero
  esumr = zero

  fsumg(:,:) = zero
  fsumr(:,:) = zero

  ! start sum in g space
  esum0 = zero
  ztemp = -p25/eps
  do i = 2, pbc%nstar
     expg(i) = exp(ztemp*two*pbc%ek(i))/(two*pbc%ek(i))
     if (expg(i) < small) exit
  enddo
  nss = i - 1
  ngg = pbc%ng 

  ngg = ngg - sum(pbc%mstar(nss+1:pbc%nstar))

  ztemp = half/eps
  do i = 2, ngg
     sumc=zero
     sumr=zero

     ! start loop over atoms in cell
     do j = 1, clust%atom_num
        gdr = twopi * dot_product(real(pbc%kgv(:,i),dp),rc(:,j))
        cosg = zz(j)*cos(gdr)
        sing = zz(j)*sin(gdr)
        sumc = sumc + cosg
        sumr = sumr + sing
        fcg(:,j) = -real(pbc%kgv(:,i),dp)*cosg
        fsg(:,j) =  real(pbc%kgv(:,i),dp)*sing
     enddo
     expgc = expg(pbc%inds(i))*sumc
     expgr = expg(pbc%inds(i))*sumr
     esumg = esumg + expgc*sumc+expgr*sumr
     do j = 1, clust%atom_num
        fsumg(:,j) = fsumg(:,j) + expgc*fsg(:,j) + expgr*fcg(:,j)
     enddo
  enddo

  esumg = fpiv*esumg
  fsumg = fpiv2*fsumg

  pi_dev_eps_v =  pi/(eps*vcell)

  ! end g sum
  !
  ! start sum in r space
  !
  ! AMIR: the different summations are repeated several times
  ! to avoid the situation of rmod=0. perhaps there is
  ! a problem here when working with a general metric. 
  !
  esum0 = zero
  do i = -imx, imx
     rp(1) = i
     do j = -jmx, jmx
        rp(2) = j
        do k = -kmx, kmx
           rp(3) = k
           ! computation of the metric.
           call matvec3('N',adot,rp,tt)
           rmod = sqrt(dot_product(rp,tt))
           ! skip point rp = (0,0,0)
           if (rp(1) == 0 .and. rp(2) == 0 .and. rp(3) == 0 ) cycle
           arg = seps*rmod
           if (arg < small2) then
              exp1 = my_erfc(arg) / rmod
              esum0 = esum0 + exp1
           endif
        enddo
     enddo
  enddo

  esum0 = esum0 - pi/(eps*vcell) - sepi     

  ! start loop over atoms in cell
  ! term with a=b (atom 1)
  ztemp = zz(1)*zz(1)
  esumr = esumr + ztemp*esum0

  do i = 2, clust%atom_num

     ! term with a=b (atom >1)
     ztemp = zz(i)*zz(i)
     esumr = esumr + ztemp*esum0

     ! terms with a#b
     do j=1,i-1

        ! loop over lattice points
        esub = zero
        fsub(:) = zero
        do ii = -imx, imx
           rp(1) = real(ii,dp) + rc(1,i) - rc(1,j)
           do jj = -jmx, jmx
              rp(2) = real(jj,dp) + rc(2,i) - rc(2,j)
              do k = -kmx, kmx
                 rp(3) = real(k,dp) + rc(3,i) - rc(3,j)
                 call matvec3('N',adot,rp,tt)
                 rmod = sqrt(dot_product(rp,tt))
                 arg = seps*rmod
                 if (arg < small2) then
                    exp1 = my_erfc(arg) / rmod
                    exp2 = (exp1+sepi*exp(-arg*arg))/(rmod*rmod)
                    esub = esub + exp1
                    tt = rp * exp2
                    fsub = fsub + tt
                 endif
              enddo
           enddo
        enddo
        esub = esub - pi_dev_eps_v
        ztemp = two*zz(i)*zz(j)
        esumr = esumr + ztemp*esub
        tt = ztemp*fsub
        fsumr(:,i) = fsumr(:,i) + tt
        fsumr(:,j) = fsumr(:,j) - tt
     enddo
  enddo

  ! end r sum
  eewald = esumg + esumr

  ! force
  ! note - returned force is in units of real space lattice vectors
  ! printed force is in cartesian coordinates
  do ii = 1, 3
     clust%force(ii,:) = fsumr(ii,:)
     do jj = 1, 3
        clust%force(ii,:) = clust%force(ii,:) + &
             pbc%bdot(ii,jj)*fsumg(jj,:)*twopio
     enddo
  enddo
  if (allocated(expg)) deallocate(expg)

  ! if print flag on, print the ion-ion forces
  do i = 1, clust%atom_num
     call matvec3('N',pbc%latt_vec,clust%force(:,i),tau(:,i))
     clust%force(:,i)=tau(:,i)
  enddo
  if(ipr >= 1) then
     write(7,*)
     write(7,*) 'Forces from ion-ion interaction:'
     write(7,*) '================================'
     write(7,22)
     write(7,*)
     do i = 1, clust%atom_num
        write(7,20) i,clust%xatm(i),clust%yatm(i),clust%zatm(i),tau(:,i)
     enddo
     write(7,*)
  endif

20 format(i6,1x,3(f11.6,1x),1x,3(f11.6,1x))
22 format('-atom-  ----x----   ----y----   ----z-----' &
        ,'   ----Fx----  ----Fy----   ----Fz---',/ &
        '                       [bohr]           ' &
        ,'                  [Ry/bohr]            ')

end subroutine ewald_sum
!===============================================================

end module ewald_module
