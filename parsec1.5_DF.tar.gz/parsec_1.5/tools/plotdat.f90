!
! =====================================================================================
!
!   Extracts electronic density, self-consistent potential and/or
!   wavefunctions from a parsec.dat. Available formats are .dx (OpenDX,
!   VMD) and .dat ({x1,x2,x3; f}, where the x's are the grid coordinates). 
!
!                                                  \m/ Jaime 2013 \m/
!                                                      @Austin,TX
!
! =====================================================================================
!
! .....................................................................................
module constants
  integer,parameter:: dp = kind(1.0d0)
  integer,parameter:: dpc = kind((1.0d0,1.0d0))
end module constants
! .....................................................................................
!
program plotdat
use constants
  implicit none
  integer :: &
     pbcflag,                   & ! Boundary conditions 
                                  ! 0: cluster, 1: bulk
                                  ! 2: wire,    3: slab
     ncplx,                     & ! Complex or Real wavefunctions
     ndim,                      & ! Hamiltonian dimension 
     ndim_full,                 & ! ndim after symmetry unfolding
     ntrans,                    & ! Number of symmetry operations
     nspin,                     & ! Number of spin
     nstate,                    & ! Number of states
     nkpt,                      & ! Number of kpoints
     rmin(3),                   & ! First or minimum grid corner  
     rmax(3),                   & ! Last or maximum grid corner
     nw(3),                     & ! Grid points indices
     nlist,                     & ! Number of wanted wavefunction
     ! Menu options
     spinflag,                  & ! 1: up, 2: down
                                  ! (3: total, 4: spin density; only for rho)
     sd,                        & ! 0: one file, 1: many files
     op,                        & ! 1: rho, 2: pot, 3: wfn
     for,                       & ! 1: .dx, 2: .dat
     wfnrep                       ! 1: real, 2: imaginary, 3: abs squared
  integer, allocatable :: &
     ngrid(:,:),                & ! Grid points (before symmetry unfolding)
     ngrid_full(:,:),           & ! Grid points (after symmetry unfolding)
     indxsave(:),               & ! Wavefunctions saved in parsec.dat
     listspn(:),                & ! List of wanted spins
     listkpt(:),                & ! List of wanted kpoints
     listeig(:),                & ! List of wanted states
     irep(:,:,:),               & ! States representations
     chi(:,:),                  & ! Character table
     istate(:,:),               & ! States saved for every (kp,sp)
     imtrx(:,:,:)                 ! Rotation matrix of each symmetry operation
  real(dp) :: &
     hh(3),                     & ! Grid spacing
     shift(3),                  & ! Shift of grid points 
     box(3),                    & ! Length of system along periodic dimensions
     radio,                     & ! Length along non-periodic dimensions
     avec(3,3),                 & ! Lattice matrix
     anorm(3,3),                & ! Normalized avec
     dvol,                      & ! Elemental volume
     spin,                      & ! Auxiliar variable for spin density calculation
     suma,                      & ! Function integral
     vec(3)
  real(dp), allocatable:: &
     kw(:),                     & ! Kpoints weight
     kpt(:,:),                  & ! Kpoints coordinates
     wfn(:),                    & ! Wavefunctions
     eigen(:,:,:),              & ! Electronic states
     occup(:,:,:),              & ! States occupations
     trans(:,:,:),              & ! Rotation matrix for every symmetry
     plotbox(:,:,:),            & ! Container where the wanted function is poured out
     potrho(:)                    ! Holds the either rho or pot variable after addbox
  complex(dpc),allocatable:: &
     zwfn(:)                      ! Wavefunctions for complex case
  character :: &
     label*26,                  & ! Data and time in parsec.dat
     outfile*30                   ! Name for the output file 
  ! Counters and temporals
  integer :: ii,jj,kk,is,ikp,jr
  real(dp):: rtmp
  !
  !====================================================================================
   
      ! Starts parsec.dat reading ----------------------------------------------
      ! ------------------------------------------------------------------------
      open(20,file='parsec.dat',form='unformatted',status='old')
      read(20) label
      read(20) nspin, ncplx, pbcflag

      ! Cell and k-points
      ! ------------------------------------------------------------------------
      if (pbcflag.GE.1) then
        read(20) hh(:),box(:),radio
        read(20) avec(:,:)
        do ii = 1, 3
          read(20)
        enddo
        read(20) nkpt
        do ii = 1, 3
          read(20)
        enddo
        if (nkpt .ne. 0) then
          allocate(kw(nkpt))
          allocate(kpt(3,nkpt))
          read(20) ((kpt(ii,jj),ii=1,3),jj=1,nkpt)
          read(20) (kw(ii), ii=1,nkpt)
          else
            read(20)
            read(20)
        end if
      else if (pbcflag.EQ.0)then
        read(20) hh(1),radio
        hh(2) = hh(1)
        hh(3) = hh(1)
        nkpt = 1
        avec = 0.d0
        avec(1,1) = radio + 2.d0 * hh(1)
        avec(2,2) = radio + 2.d0 * hh(2)
        avec(3,3) = radio + 2.d0 * hh(3)
      endif

      ! Mesh and symmetries. Assumes tnp = 0.d0
      ! ------------------------------------------------------------------------
      read(20)
      read(20) shift
      read(20) ndim, ntrans
      allocate(imtrx(3,3,ntrans))
      read(20) imtrx
      allocate(trans(3,3,ntrans))
      read(20) trans
      read(20)
      read(20)
      allocate(chi(ntrans,ntrans))
      read(20) ((chi(ii,jj),ii=1,ntrans),jj=1,ntrans)
 
      ! Unfold grid ------------------------------------------------------------
      ! ------------------------------------------------------------------------
      ndim_full = ndim * ntrans
      allocate(ngrid(3,ndim))
      allocate(ngrid_full(3,ndim_full))
      read(20) ( (ngrid(ii,jr),ii=1,3), jr=1,ndim )
      call unfoldgrid(ngrid,ngrid_full,ndim,ntrans,shift,trans)
      rmin = minval(ngrid_full,2)
      rmax = maxval(ngrid_full,2)
      nw = rmax - rmin + 1

      anorm = avec
      do ii = 1, 3
        rtmp = sqrt( dot_product(anorm(:,ii),anorm(:,ii)) )
        anorm(:,ii) = anorm(:,ii)/rtmp
      end do
      dvol = anorm(1,1) * anorm(2,2) * anorm(3,3) + anorm(2,1) * anorm(3,2) * anorm(1,3) + &
             anorm(3,1) * anorm(1,2) * anorm(2,3) - anorm(3,1) * anorm(2,2) * anorm(1,3) - &
             anorm(2,1) * anorm(1,2) * anorm(3,3) - anorm(1,1) * anorm(3,2) * anorm(2,3) 
      dvol = dvol * hh(1) * hh(2) * hh(3)

      allocate(plotbox(nw(1),nw(2),nw(3)))
      plotbox = 0.d0

      ! Menu -------------------------------------------------------------------
      ! ------------------------------------------------------------------------
      write(*,*) 
      write(*,*) "Select:"
      write(*,*) "Density(1), Potential(2), Wavefunction(3)"
      read(*,*) op

      do while (op .LE. 0 .OR. op .GT. 3)
        write(*,*) "Invalid option"
        write(*,*) " -try again, please"
        read(*,*) op
      end do

      write(*,*) " Output Format?"
      write(*,*) " OUT.dx (1), OUT.dat (2) "
      read(*,*) for
      do while (for .LE. 0 .OR. for .GT. 2)
        write(*,*) "Invalid option"
        write(*,*) " -try again, please"
        read(*,*) for
      end do

      spinflag = 1
      if (nspin .GT. 1 .AND. op .EQ. 1) then
        write(*,*) "Spin Up (1), Spin Dn (2)"
        write(*,*) "Total Charge (3), Spin Density (4)?"
        read(*,*) spinflag 
        do while (spinflag .LT. 1 .OR. spinflag .GT. 4) 
          write(*,*) "Invalid spin"
          write(*,*) " -Try again, please"
          read(*,*) spinflag
        end do
      end if
      if (nspin .GT. 1 .AND. op .EQ. 2) then
        spinflag = 1
        write(*,*) "Which component? Up (1) or Down (2)?"
        read(*,*) spinflag 
        do while (spinflag .LT. 1 .OR. spinflag .GT. 2) 
          write(*,*) "Invalid spin"
          write(*,*) " -Try again, please"
          read(*,*) spinflag
        end do
      end if
      if (op .EQ. 3) then
        write(*,*) "WFN selected..."
        write(*,*) "REAL part(1), IMAGINARY part (2), o ABSOLUTE VALUE SQUARED (3)?"
        read(*,*) wfnrep
        do while (wfnrep .LT. 1 .OR. wfnrep .GT. 3)
          write(*,*) "Invalid option"
          write(*,*) " -Try again, please"
          read(*,*) wfnrep
        end do
        if (ncplx .EQ. 0 .AND. wfnrep .EQ. 2) then
          write(*,*) "WARNING!"
          write(*,*) "Wavefunctions are REAL!"
          write(*,*) "You will get a zero function on the grid"
          write(*,*) "Hit ENTER to proceed anyway and waste some delicious time"
          read(*,*) 
        end if
        write(*,*) "Do you want the output in one file (0) or into separate files (1)?"
        read(*,*) sd
        do while (sd .LT. 0 .OR. sd .GT. 1)
           write(*,*) "Invalid option"
           write(*,*) " -Try again, please"
           read(*,*) sd
        end do
      end if

      ! Build output file name -------------------------------------------------
      ! ------------------------------------------------------------------------
      allocate(potrho(ndim))

      if (op .EQ. 1) then
        outfile = "RHO"
        if (spinflag .EQ. 1 .AND. nspin .GT. 1) then
          outfile = trim(outfile) // "_up"
        else if (spinflag .EQ. 2) then
          outfile = trim(outfile) // "_dn"
        else if (spinflag .EQ. 3) then
          outfile = trim(outfile) // "_tt"
        else if (spinflag .EQ. 4) then
          outfile = trim(outfile) // "_sp"
        end if
      else if (op .EQ. 2) then
        outfile = "POT"
        if (spinflag .EQ. 1) then
          outfile = trim(outfile) // "_up"
        else if (spinflag .EQ. 2) then
          outfile = trim(outfile) // "_dn"
        end if
      else if (op .EQ. 3 .AND. sd .EQ. 0) then
        outfile = "WFN"
      end if
      if (for .EQ. 1) then
        outfile = trim(outfile) // ".dx"
      else if (for .EQ. 2) then
        outfile = trim(outfile) // ".dat"
      end if

      ! Electronic states ------------------------------------------------------
      ! ------------------------------------------------------------------------
      do is = 1, nspin
        do ikp = 1, nkpt
          read(20) nstate
          if (is .eq. 1 .and. ikp .eq. 1) then
            allocate(irep(nstate,nkpt,nspin))
            allocate(istate(nkpt,nspin))
            allocate(eigen(nstate,nkpt,nspin))
            allocate(occup(nstate,nkpt,nspin))
          endif
          read(20) (irep(jj,ikp,is), jj=1,nstate)
          read(20) (eigen(jj,ikp,is),jj=1,nstate)
          read(20) (occup(jj,ikp,is),jj=1,nstate)
        enddo ! ikp

        ! Density and potential, trivial representation ------------------------
        ! ----------------------------------------------------------------------
        chi = 1
        read(20) (potrho(jr), jr=1,ndim)
        if (op .EQ. 2 .AND. is .EQ. spinflag)      &
          call addbox(ndim,ntrans,nw,rmin,imtrx,   &
               ngrid,chi(1,1),shift,potrho,plotbox)
        read(20) (potrho(jr), jr=1,ndim)
        if (op .EQ. 1 .AND. is .EQ. spinflag)      &
          call addbox(ndim,ntrans,nw,rmin,imtrx,   &
               ngrid,chi(1,1),shift,potrho,plotbox)
        if (op .EQ. 1 .AND. spinflag .EQ. 3)       &
          call addbox(ndim,ntrans,nw,rmin,imtrx,   &
               ngrid,chi(1,1),shift,potrho,plotbox)
        spin = 3.d0 - 2.d0 * is
        if (op .EQ. 1 .AND. spinflag .EQ. 4)       &
          call addbox(ndim,ntrans,nw,rmin,imtrx,   &
               ngrid,chi(1,1),shift,spin*potrho,plotbox)
      enddo ! is
 
      if (op .EQ. 3) deallocate(chi,imtrx) ! JSC - mira este if..

      ! Origin and Lattice for .dx header --------------------------------------
      ! ------------------------------------------------------------------------
      if (for .EQ. 1) then
        do ii = 1, 3
          vec(ii) = ( minval(ngrid_full(ii,:)) + shift(ii) ) * hh(ii)
          anorm(:,ii) = anorm(:,ii) * hh(ii)
        end do
      end if

      if (op .EQ. 3) then ! (until line 403)

        ! Selection of states --------------------------------------------------
        ! ----------------------------------------------------------------------
        allocate(listeig(nstate*nkpt*nspin))
        allocate(listkpt(nstate*nkpt*nspin))
        allocate(listspn(nstate*nkpt*nspin))
        call seleccion_wfn(nspin,nkpt,nstate,listspn,listkpt,listeig,nlist,occup)

        deallocate(ngrid)
        deallocate(trans)

        ! Wavefunctions --------------------------------------------------------
        ! ----------------------------------------------------------------------
        allocate(wfn(ndim))
        if (ncplx .EQ. 1) then
          allocate(zwfn(ndim))
        end if
 
        kk = 1 ! Controls list of wanted states
        do is = 1, nspin
          do ikp = 1, nkpt
            read(20) ndim, ntrans

            if (ikp .EQ. 1 .AND. is .EQ. 1) then
              allocate(imtrx(3,3,ntrans))
              allocate(trans(3,3,ntrans))
              allocate(chi(ntrans,ntrans))
              allocate(ngrid(3,ndim))
            end if

            irep = 1 ! Solo si (op .EQ. 3) ¿?
            read(20) imtrx
            read(20) trans
            read(20)
            read(20)
            read(20) ((chi(ii,jj),ii=1,ntrans),jj=1,ntrans)
            ndim_full = ndim * ntrans
            read(20) ( (ngrid(ii,jr),ii=1,3), jr=1,ndim )
  
            read(20) istate(ikp,is)
            allocate(indxsave(istate(ikp,is)))
            indxsave = -1 ! Penso que xa non fai falla, pero non vaia ser o demo
            read(20) (indxsave(ii), ii=1,istate(ikp,is))

            do ii = 1, istate(ikp,is)
 
              ! If the state has been selected...
              if ( (listeig(kk) .EQ. indxsave(ii)) .AND. &
                   (listkpt(kk) .EQ. ikp)          .AND. &
                   (listspn(kk) .EQ. is) ) then
                ! Read wavefunction from parsec.dat
                if (ncplx .EQ. 0) then
                  read(20) (wfn(jr), jr=1,ndim)
                else
                  read(20) (zwfn(jr), jr=1,ndim)
                end if
                ! Remember: wfnrep = 1: R
                !           wfnrep = 2: I
                !           wfnrep = 3: ||^2
                if (ncplx .EQ. 0) then
                  select case(wfnrep)
                    case(2)
                      wfn = 0.d0
                    case(3)
                      do jr = 1, ndim
                        wfn(jr) = wfn(jr) * wfn(jr)
                      end do
                    end select
                else ! wfn complex
                  select case(wfnrep)
                    case(1)
                      wfn = real(zwfn,dp)
                    case(2)
                      wfn = aimag(zwfn)
                    case(3)
                      do jr = 1, ndim
                        wfn(jr) = abs(zwfn(jr))**2
                      end do
                  end select
                end if
      
                ! Add wfn to output container, plotbox.
                ! In case of many files, we also write them out.
                if (sd .EQ. 0) then
                  call addbox(ndim,ntrans,nw,rmin,imtrx,   &
                       ngrid,chi(1:ntrans,irep(ii,ikp,is)),&
                       shift,wfn,plotbox)
                else 
                  open(15,status="SCRATCH")
                  if (for .EQ. 1) then
                    write(15,150) ii,ikp,is
                  else
                    write(15,151) ii,ikp,is
                  end if
                  rewind(15)
                  read(15,*) outfile
                  close(15)
150               format("wfn",I4.4,"kp",I3.3,"sp",I1,".dx")
151               format("wfn",I4.4,"kp",I3.3,"sp",I1,".dat")
                  plotbox = 0.d0
                  call addbox(ndim,ntrans,nw,rmin,imtrx,   &
                       ngrid,chi(1:ntrans,irep(ii,ikp,is)),&
                       shift,wfn,plotbox)
                  if (for .EQ. 1) then
                    call outputfile_dx(op,nw,vec,anorm,label,plotbox,outfile, &
                           spinflag,wfnrep,nlist,listeig,listkpt,listspn,nspin,nkpt)
                  else if (for .EQ. 2) then
                    call outputfile_dat(ndim_full,ntrans,nw,ngrid_full,imtrx, &
                                           rmin,chi(1:ntrans,irep(ii,ikp,is)),hh,&
                                           shift,plotbox,outfile,avec)
                  end if ! for 
                end if   ! sd

                ! If the wanted list is exhausted,
                ! exit the triple-(eig/kpt/spn)-loop
                if (kk .EQ. nlist) go to 77 ! (is this still bad practice?)

                kk = kk+1 ! go to next element in wanted list

              else ! state not found

                ! If the state is not in the wanted list, 
                ! move the reading cursor in the parsec.dat 
                ! to the next wavefunction
                read(20) 

              end if ! state-found if

            end do ! ii
            deallocate(indxsave)
          
          end do   !ikp
        end do     !is

      end if ! (op .EQ. 3)

77    continue

      ! Write output -----------------------------------------------------------
      !--------------------------------------------------------------------------
      if (.NOT.(op .EQ. 3 .AND. sd .EQ. 1)) then
        if (for .EQ. 1) then
          call outputfile_dx(op,nw,vec,anorm,label,plotbox,outfile, &
                                spinflag,wfnrep,nlist,listeig,listkpt, &
                                listspn,nspin,nkpt)
        else if (for .EQ. 2) then
          chi = 1
          call outputfile_dat(ndim_full,ntrans,nw,ngrid_full,imtrx, &
                                 rmin,chi(1:ntrans,1),hh,shift,plotbox,&
                                 outfile,avec)
        end if
      end if

      close(20) ! sayounara, parsec.dat
      !-------------------------------------------------------------------------
 

      ! Info printed out -------------------------------------------------------
      !-------------------------------------------------------------------------
      write(*,*)
      write(*,*) "======================================================="
      write(*,*)
      write(*,*) ' parsec.dat file created on ',label
      write(*,100) nspin,ncplx,pbcflag
100   format(3x,'nspin ',I1,3x,'ncplx ',I1,3x,'pbcflag ',I1,/)

      if (ncplx .EQ. 0) then
        write(*,*) " REAL wavefunctions"
      else if (ncplx .EQ. 1) then
        write(*,*) " COMPLEX wavefunctions"
      end if

      if (pbcflag.GT.0.AND.nkpt.NE.0) then
        write(*,*) ' K-point coordinates and weights : '
        do ii = 1, nkpt
          write(*,'(3f10.4,3x,f10.4)') kpt(:,ii),kw(ii)
        enddo
      end if

      write(*,*)
      write(*,*) ' Hamiltonian dimension:',ndim
      if (ntrans.GT.1) write(*,200) ntrans
      if (ntrans.EQ.1) write(*,201) ntrans
      write(*,*)

      select case(pbcflag)
        case(0)
          write(*,*) ' Cluster'
          write(*,'(A,f8.4)') '   r =',radio
        case(2)
          write(*,*) ' Wire'
          write(*,'(A,f8.4)') '   L =',avec(1,1)
          write(*,'(A,f8.4,/)') '   r =',radio
        case(3)
          write(*,*) ' Slab'
          write(*,'(A,f8.4)')      '   h =',2*radio
          write(*,'(A,2(f8.4),A)') '   A = | ',avec(1,1),avec(2,1),' |'
          write(*,'(A,2(f8.4),A,/)') '       | ',avec(1,2),avec(2,2),' |'
        case(1)
          write(*,*) ' Bulk'
          write(*,'(A,3(f8.4),A)')   '   A = | ',avec(1,1),avec(2,1),avec(3,1),' |'
          write(*,'(A,3(f8.4),A)')   '       | ',avec(1,2),avec(2,2),avec(3,2),' |'
          write(*,'(A,3(f8.4),A,/)') '       | ',avec(1,3),avec(2,3),avec(3,3),' |'
      end select

      write(*,*) 
      if (.NOT.(op .EQ. 3 .AND. sd .EQ. 1)) then
        suma = sum(plotbox) * dvol
        if (abs(log10(suma)) .GE. 3 .OR. isnan(log10(suma))) then
          write(*,202) "Suma: ",suma
        else 
          write(*,203) "Suma: ",suma
        end if
        write(*,*) 
        write(*,*) " Output: ",outfile
      else 
        if (for .EQ. 1) then
          write(*,*) " Output: wfn[eig][kpt][spn].dx"
        else if (for .EQ. 2) then
          write(*,*) " Output: wfn[eig][kpt][spn].dat"
        end if 
      end if
      if (op .EQ. 3) then
        write(*,*)
        write(*,204) " |   Eig   |   Kpt   |   Spn   |"
        do jj = 1, nlist
          write(*,205) listeig(jj),listkpt(jj),listspn(jj)
        end do
      end if
      write(*,*) 
      write(*,*) "======================================================="
200   format(2x,'...with ',I1,' symmetry operations')
201   format(2x,'...with ',I1,' symmetry operation')
202   format(2x,A6,E11.3) 
203   format(2x,A6,F10.5)
204   format(4x,A)
205   format(8x,I4,7x,I3,9x,I1)
      !---------------------------------------------------------------------------------
      !---------------------------------------------------------------------------------

      write(*,*)
      write(*,*)
      write(*,*) "DONE ^___^"
      write(*,*)
      
end program plotdat
!======================================================================================
!--------------------------------------------------------------------------------------
!======================================================================================
subroutine unfoldgrid(ngrid,ngrid_full,ndim,ntrans,shift,trans)
! Takes the grid right from parsec.dat and unfolds it 
! accordingly to the present symmetry operations.
use constants
  implicit none
  integer, intent(in) :: ndim,ntrans
  real(dp), intent(in) :: shift(3),trans(3,3,ntrans)
  integer, intent(in) :: ngrid(3,ndim)
  integer, intent(out) :: ngrid_full(3,ntrans*ndim)

  integer ir, jr, kt, ii
  real(dp) :: rvec(3), tvec(3)

      do ir = 1, ndim
         do kt = 1, ntrans
            jr = kt + (ir-1)*ntrans
            rvec = ngrid(:,ir) + shift
            do ii = 1, 3
               tvec(ii) = dot_product(rvec,trans(:,ii,kt))
            enddo
            tvec = tvec - shift
            ngrid_full(:,jr) = nint(tvec)
         enddo
      enddo

end subroutine unfoldgrid
!======================================================================================
subroutine addbox(ndim,ntrans,nw,rmin,imtrx,ngrid,chi,shift,wfn,plotbox)
! Takes the selected function and pours it out to plotbox.
! If there are symmetries, the function is unfolded.
use constants
  implicit none

  integer, intent(in) :: ndim,ntrans,nw(3),rmin(3)
  integer, intent(in) :: imtrx(3,3,ntrans),ngrid(3,ndim),chi(ntrans)
  real(dp), intent(in) :: shift(3),wfn(ndim)
  real(dp), intent(inout) :: plotbox(nw(1),nw(2),nw(3))
  integer ir, kt, i1, i2, i3, ii
  real(dp) :: wfn_tmp
  real(dp) :: rtmp(3),gridpt(3),rmtrx(3,3,ntrans)

      rmtrx = imtrx
      do ir = 1, ndim
         do kt = 1, ntrans
            gridpt = real(ngrid(:,ir),dp) + shift
            do ii = 1, 3
               rtmp(ii) = dot_product(rmtrx(ii,:,kt),gridpt)
            enddo
            gridpt = rtmp - shift
            i1 = nint(gridpt(1)) - rmin(1) + 1
            i2 = nint(gridpt(2)) - rmin(2) + 1
            i3 = nint(gridpt(3)) - rmin(3) + 1
            if (i1 .lt. 1 .or.i1 .gt. nw(1)) then
              write(6,*) ' ERROR i1 ',i1,ir,kt,ngrid(:,ir)
            endif
            if (i2 .lt. 1 .or.i2 .gt. nw(2)) then
              write(6,*) ' ERROR i2 ',i2,ir,kt,ngrid(:,ir)
            endif
            if (i3 .lt. 1 .or.i3 .gt. nw(3)) then
              write(6,*) ' ERROR i3 ',i3,ir,kt,ngrid(:,ir)
            endif
            wfn_tmp = wfn(ir) * real(chi(kt),dp)
            plotbox(i1,i2,i3) = plotbox(i1,i2,i3) + wfn_tmp
         enddo
      enddo

end subroutine addbox
!======================================================================================
subroutine outputfile_dx(op,nw,vec,anorm,label,plotbox,outfile,&
            spinflag,wfnrep,nlist,listeig,listkpt,listspn,nspin,nkpt)
! Writes the .dx file 
use constants
  implicit none
  integer:: op,ii,jj,kk,nlist,nspin,nkpt
  integer:: nw(3),spinflag,wfnrep
  integer,dimension(nlist):: listeig,listkpt,listspn
  real(dp):: vec(3),anorm(3,3)
  real(dp):: plotbox(nw(1),nw(2),nw(3))
  character(len=30):: outfile,label

      open(30,file=trim(outfile),form="formatted")

      write(30, 10) nw(3), nw(2), nw(1)
10    format('object 1 class gridpositions counts',3i4 )

      write(30,'(a,3f20.10)') 'origin',vec
            
      write(30,50) anorm(:,3)
      write(30,50) anorm(:,2)
      write(30,50) anorm(:,1)
50    format('delta ', 3f20.10)  
      write(30, 20) nw(3), nw(2),  nw(1)
20    format('object 2 class gridconnections counts',3i4)
                                !     write header for gridpositions
      write(30, 30) nw(1) * nw(2) * nw(3)
30    format('object 3 class array type float rank 0 items ',i8,' data follows')
      write(30,'(3g15.7)') (((plotbox(ii,jj,kk),ii=1,nw(1)),jj=1,nw(2)),kk=1,nw(3))

                                !     write header for field object
      write(30, 60)  
60    format(/'object 4 class field',/'component "positions"   value 1', &
             /'component "connections" value 2',/'component "data"        value 3')
      write(30,*)
      write(30,'(2a)') '# Date label : ',label

      if (op .eq. 1) then
         if (nspin .eq. 2 .and. spinflag .eq. 4) then
            write(30,'(a)') '# spin density'
         elseif (nspin .eq. 2 .and. spinflag .eq. 3) then
            write(30,'(a)') '# electron density, total'
         elseif (nspin .eq. 2 .and. spinflag .eq. 2) then
            write(30,'(a)') '# electron density, spin up component'
         elseif (nspin .eq. 2 .and. spinflag .eq. 1) then
            write(30,'(a)') '# electron density, spin down component'
         endif
      elseif (op .eq. 2) then
         write(30,'(a)') '# self-consistent potential'
         if (nspin .eq. 2 .and. spinflag .eq. 1) then
            write(30,'(a)') '# spin up component'
         elseif (nspin .eq. 2 .and. spinflag .eq. 2) then
            write(30,'(a)') '# spin down component'
         endif
      elseif (op .eq. 3) then
         write(30,'(a)') '# electron wave-functions'
         if (wfnrep .eq. 1) then
            write(30,'(a)') '# real part'
         elseif (wfnrep .eq. 2) then
            write(30,'(a)') '# real part'
         elseif (wfnrep .eq. 3) then
            write(30,'(a)') '# absolute value squared'
         endif
         if (nkpt .eq. 1) then
            if (nspin .eq. 1) then
               write(30,'(a)') '# printed eigenstates : '
               write(30,70) (listeig(ii),ii=1,nlist)
            elseif (nspin .eq. 2) then
               write(30,'(a)') '# printed eigenstates (eig,isp): '
               write(30,75) (listeig(ii),listspn(ii),ii=1,nlist)
            endif
         else
            if (nspin .eq. 1) then
               write(30,'(a)') '# printed eigenstates (eig,ikp): '
               write(30,80) (listeig(ii),listkpt(ii),ii=1,nlist)
            elseif (nspin .eq. 2) then
               write(30,'(a)') '# printed eigenstates (eig,ikp,isp): '
               write(30,85) (listeig(ii),listkpt(ii),listspn(ii),ii=1,nlist)
            endif
         endif
      endif
      
      if (op .EQ. 1) then
        close(10)
      else if (op .EQ. 2) then
        close(20)
      else if (op .EQ. 3) then
        close(30)
      end if
      
70    format('# ',10i4)
75    format(10('# ',3('( ',i4,' , ',i1,' ) '),/))
80    format(10('# ',3('( ',i4,' , ',i4,' ) '),/))
85    format(10('# ',3('( ',i4,' , ',i4,' , ',i1,' ) '),/))

100   format('wfn',i4.4,'kp',i3.3,'sp',i1,'.dx')

end subroutine outputfile_dx
!======================================================================================
subroutine outputfile_dat(ndim_full,ntrans,nw,ngrid_full,imtrx, &
                             rmin,chi,hh,shift,wfn,outfile,avec)
  ! Writes the .dat file, its format being {x,y,z; f}. 
  ! Useful to build contour plots and so.
  ! Beware the unsorted grid. 
  use constants
  implicit none
  integer, intent(in):: ndim_full, ntrans
  integer, intent(in):: ngrid_full(3,ndim_full), imtrx(3,3,ntrans)
  integer, intent(in):: chi(ntrans), nw(3), rmin(3)
  real(dp), intent(in):: hh(3), shift(3),avec(3,3)
  real(dp):: wfn(nw(1),nw(2),nw(3)),anorm(3,3)
  character(len=30), intent(in):: outfile
  real(dp):: rtmp(3), rgrid_full(3,ndim_full),rmtrx(3,3,ntrans)
  integer:: ir,i1,i2,i3,ii

        ! Calculate this again (bsts)
        anorm = avec
        do ii = 1, 3
          rtmp = sqrt( dot_product(anorm(:,ii),anorm(:,ii)) )
          anorm(:,ii) = anorm(:,ii)/rtmp
        end do
        open(40,file=trim(outfile))
        rmtrx = imtrx
        do ir = 1, ndim_full
          rtmp = real(ngrid_full(:,ir),dp) - rmin + 1
          i1 = nint(rtmp(1))
          i2 = nint(rtmp(2))
          i3 = nint(rtmp(3))
          ! Transformation from point grid to real-space grid here! 
          rtmp = hh * (ngrid_full(:,ir) + shift)
          rtmp = matmul(anorm,rtmp)
          wfn(i1,i2,i3) = wfn(i1,i2,i3) * real(chi(mod(ir-1,ntrans)+1),dp)
          write(40,333) rtmp(1),rtmp(2),rtmp(3), wfn(i1,i2,i3) 
        enddo !ir
        close(40)
333     format(4x,3(f7.3,2x),2x,e13.6)

end subroutine outputfile_dat
!======================================================================================
subroutine seleccion_wfn(nspin,nkpt,nstate,listspn,listkpt,listeig,nlist,occup)
  ! Menu that selects the set of wavefunctions to write.
  use constants 
  implicit none
  integer, intent(in):: nspin,nkpt,nstate
  integer, intent(out):: listspn(nstate*nkpt*nspin), &
                         listkpt(nstate*nkpt*nspin), &
                         listeig(nstate*nkpt*nspin)
  integer:: nlist,ii,jj
  real(dp):: occup(nstate,nkpt,nspin)

        listspn = 1
        listkpt = 1
        listeig = 1

        if (nspin .EQ. 1 .AND. nkpt .EQ. 1) then
          write(*,*) " Eigenstates for output?"
        write(*,*) "   (enter 0 for wrapping up)"
        write(*,981) "   Eig < :",nstate
        else if (nspin .EQ. 1 .AND. nkpt .GT. 1) then
          write(*,*) " Eigenstates/k-points for output?"
        write(*,*) "   (enter 0 0 for wrapping up)"
        write(*,981) "   Eig < :",nstate
        write(*,981) "   Kpt < :",nkpt
        else if (nspin .GT. 1 .AND. nkpt .EQ. 1) then
          write(*,*) " Eigenstates/spin for output?"
        write(*,*) "   (enter 0 0 for wrapping up)"
        write(*,981) "   Eig < :",nstate
        write(*,981) "   Spn < :",nspin
        else if (nspin .GT. 1 .AND. nkpt .GT. 1) then
          write(*,*) " Eigenstates/k-points/spin for output?"
          write(*,*) "   (enter 0 0 0 for wrapping up)"
          write(*,981) "   Eig < :",nstate
          write(*,981) "   Kpt < :",nkpt
          write(*,981) "   Spn < :",nspin
        end if
981     format(A12,I4)
        
        nlist = 0
        do 
          nlist = nlist + 1
          if (nspin .EQ. 1 .AND. nkpt .EQ. 1) then
            read(*,*) listeig(nlist)
          else if (nspin .EQ. 1 .AND. nkpt .GT. 1) then
            read(*,*) listeig(nlist),listkpt(nlist)
          else if (nspin .GT. 1 .AND. nkpt .EQ. 1) then
            read(*,*) listeig(nlist),listspn(nlist)
          else if (nspin .GT. 1 .AND. nkpt .GT. 1) then
            read(*,*) listeig(nlist),listkpt(nlist),listspn(nlist)
          end if

          ! User calls it a day
          if (listeig(nlist) .EQ. 0) exit 
          
          ! Pass if the state introduced is wrong for whatever reason 
          if (listeig(nlist) .GT. nstate .OR. listeig(nlist) .LT. 0) then
            write(*,*) "Nope! State not found!!"
            nlist = nlist -1
            cycle
          else if (listkpt(nlist) .GT. nkpt   .OR. listkpt(nlist) .LE. 0) then
            write(*,*) "Nope! Kpoint not found!!"
            nlist = nlist -1
            cycle
          else if (listspn(nlist) .GT. nspin  .OR. listspn(nlist) .LE. 0) then
            write(*,*) "Nope! Spin not found!!"
            nlist = nlist -1
            cycle
          else if (occup(listeig(nlist),listkpt(nlist),listspn(nlist)) .EQ. 0.d0)  then
            write(*,*) "Warning! The state is empty!!"
          !  nlist = nlist -1
          !  cycle
          end if
      
          ! Pass if the state is already in the list
          do jj = 1, nlist-1
            if ((listeig(jj) .EQ. listeig(nlist)) .AND. &
                (listspn(jj) .EQ. listspn(nlist)) .AND. &
                (listkpt(jj) .EQ. listkpt(nlist))) then
              nlist = nlist - 1
              exit
            end if
          end do
  
        end do
        nlist = nlist - 1

        ! Important: This list must be sorted!
        do ii = 1, nlist-1
          do jj = ii+1, nlist
            if(listspn(ii) .GT. listspn(jj))then
              call swap(nlist,listspn,listkpt,listeig,ii,jj)
            else if(listspn(ii) .EQ. listspn(jj))then
              if(listkpt(ii) .GT. listkpt(jj))then
                call swap(nlist,listspn,listkpt,listeig,ii,jj)
              else if(listkpt(ii) .EQ. listkpt(jj))then
                if(listeig(ii) .GT. listeig(jj))then
                  call swap(nlist,listspn,listkpt,listeig,ii,jj)
                end if
              end if
            end if
          end do
        end do


end subroutine seleccion_wfn
!======================================================================================
subroutine swap(n,a,b,c,i,j)
  implicit none
  integer:: n,i,j,x,a(n),b(n),c(n)
    x = a(i)
    a(i) = a(j)
    a(j) = x
    x = b(i)
    b(i) = b(j)
    b(j) = x
    x = c(i)
    c(i) = c(j)
    c(j) = x
end subroutine swap
!======================================================================================
