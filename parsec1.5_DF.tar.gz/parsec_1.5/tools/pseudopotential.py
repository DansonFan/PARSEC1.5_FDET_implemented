#!/usr/bin/env python
# Pseudopotential interface
# Enables the creation of pseudopotential input files, generation of pseudopotentials, and parsing of pseudopotential output files

import re

import pseudopotential_defaults

import subprocess as sp
import shutil as sh
import os
import numpy as np
import sys
import copy
import pseudopotential_binary_parse as fb, periodic_info

PSEUDOPOTENTIAL_PATH = os.environ['WORK']+'/atm'

def read_fnc( fnc, nlines, rem, f ):
    for i in range(nlines):
	l = f.readline()
	m = re.search( r'(\S+)+\s+(\S+)\s+(\S+)', l )
	fnc.append( float( m.group( 1) ) )
	fnc.append( float( m.group( 2) ) )
	fnc.append( float( m.group( 3) ) )
    if rem:
	l = f.readline()
	m = re.findall( r'(\S+)', l )
	for num in m:
	    fnc.append( float( num ) )
    f.readline()
    

def read_functions( r, aefnc, pfnc, ae_labels, p_labels ):
    f = open( 'ae_wav.out')
    npoints = int( f.readline() )
    nlines = npoints / 3
    rem = npoints %3

    read_fnc( r, nlines, rem, f )
    l = f.readline( )

    labels = ae_labels
    prefix = 'AE '
    fnc = aefnc
    n = 0
    labels.append( prefix + 'n=1,l=0' )
    while l:
	tf = []
	read_fnc( tf, nlines, rem, f )
	fnc.append( tf )
	l = f.readline( )
	m = re.search( r'n =\s*(\S+)\s+l =\s*(\S+)', l )
	if m:
	    n = int( m.group( 1 ) )
	if n == 1:
	    fnc = pfnc
	    labels = p_labels
	    prefix = 'P '
	if m:
	    if( prefix == 'AE ' ):
		labels.append( prefix + 'n=' + m.group(1) + ',l=' + m.group(2) )
	    else:
		labels.append( prefix + 'l=' + m.group(2) )

class pseudopotential:
# initialize
	def __init__(self,path=PSEUDOPOTENTIAL_PATH):
		self.configuration = 'default'
		self.text = ''
		self.path = path
	
	def get_default_ncore(self):
		return 3

	def get_default_valence(self):
		return '3s2 3p3'

# create input file
	def create(self,element,indexmod=0,atomdat=None,**kwargs):
		'''create(element,**kwargs):
		mode:
			ae  all electron calculation
			pg  pseudopotential generation w/o core correction
			pe  pseudopotential generation w/  core correction exchange
			ph  pseudopotential generation w/  core correction hartree/exc
			pt  pseudopotential test
			pm  pseudopotential test + valence charge modify

		pseudopotential_type:
			van Vanderbilt
			tam Troullier and Martins
			ker (yes) Kerker
			sc (no)  Hamann Schluter and Chiang
			min (oth) datafile made for minimization
			bhs Bachelet, Hamann and Schluter
			tm2 Improved Troullier and Martins

		icorr:
			'pb' - 
			'pw' - Perdew ... LDA
			'ca' - Ceperly Alder LDA

		spinflag:
			' ' - nonspin calculation
			's'  - spin polarized calculation
			'r'  - relativistic calculation
		'''



		self.nameat = '%2s' % (element)
		self.comments = '' if not kwargs.has_key('comments') else kwargs['comments']
		self.pseudopotential_type = 'tm2' if not kwargs.has_key('pseudopotential_type') else kwargs['pseudopotential_type']
		self.correlation = 'ca' if not kwargs.has_key('correlation') else kwargs['correlation']
		self.icorrt = self.correlation
		self.spinflag = ' ' if not kwargs.has_key('spinflag') else kwargs['spinflag']
		self.irel = self.spinflag
# in current pseudopotentials, values of < 1e-5 cause default values
		self.nuclear_charge = 0.0 if not kwargs.has_key('nuclear_charge') else kwargs['nuclear_charge']
		self.shell_charge = 0.0 if not kwargs.has_key('shell_charge') else kwargs['shell_charge']
		self.shell_radius = 0.0 if not kwargs.has_key('shell_radius') else kwargs['shell_radius']
 # r = exp(-aa)/nuclear * (exp(1/bb * (i-1))-1)
		self.grid_max = 0.0 if not kwargs.has_key('grid_max') else kwargs['grid_max']
		self.aa = 0.0 if not kwargs.has_key('aa') else kwargs['aa']
		self.bb = 0.0 if not kwargs.has_key('bb') else kwargs['bb']
		self.ncore = self.get_default_ncore() if not kwargs.has_key('ncore') else kwargs['ncore']
		self.valence_config = self.get_default_valence() if not kwargs.has_key('valence_config') else kwargs['valence_config']

		if 'configuration' in kwargs:
			self.configuration = kwargs['configuration']

		self.individuals = re.split(r'\n\n',pseudopotential_defaults.defaults)
		self.elements = [re.search(r'\n n=(\S+) ',entry).groups(0)[0] for entry in self.individuals if re.search(r'\n n=(\w+) ',entry) != re.search('a','b') ]
# HACKISH SO SORRY 
		self.index = self.elements.index(element)

		if atomdat:
			print "here",atomdat
			with open(atomdat,'r') as datafile:
				self.hack = datafile.read()
			self.working = re.split('\n',self.hack)[0:-2]
		else:
			self.working = re.split('\n',self.individuals[self.index])

		print self.working[-1]
		self.cutoffs = re.findall(r'(\W+)(\S+)',self.working[-1])
		print self.cutoffs

		if 's_cut' in kwargs: self.cutoffs[0] = (self.cutoffs[0][0],kwargs['s_cut'])
		if 'p_cut' in kwargs: self.cutoffs[1] = (self.cutoffs[1][0],kwargs['p_cut'])
		if 'd_cut' in kwargs: self.cutoffs[2] = (self.cutoffs[2][0],kwargs['d_cut'])

		self.text  = ''
		# replace mode

		# replace occupied orbitals num


		# replace cutoffs
		for string in self.working[0:-1]:
			self.text += string + '\n'
		for ituple in self.cutoffs:
			try:
				self.text += '   {:.3f}'.format(np.float64(ituple[1]))
			except:
				print ituple
				raise
				
		self.text += '\n\n' # makes the ATOM program happy


	def gentext(self):
		valid = {}
		valid['pseudopotential_type'] = ('tm2','bhs','oth','van','tbk','yes','no ',' no','hsc')
		valid['spinflag'] = ('s','r',' ')
		valid['icorr'] = ('pb','pw','ca')
		valid['mode'] = ('ae','pg','pe','ph','pt','pm')
		individuals = re.split(r'\n\n',pseudopotential_defaults.defaults)
		self.individuals = re.split(r'\n\n',pseudopotential_defaults.defaults)
		self.elements = [re.search(r'\n n=(\S+) ',entry).groups(0)[0] for entry in self.individuals if re.search(r'\n n=(\w+) ',entry) != re.search('a','b') ]
		self.index = self.elements.index(self.nameat)
		self.working = re.split('\n',individuals[self.index])
		self.cutoffs = re.findall('(\W+)(\S+)',self.working[-1])
		if 's_cut' in kwargs: self.cutoffs[0] = (self.cutoffs[0][0],kwargs['s_cut'])
		if 'p_cut' in kwargs: self.cutoffs[1] = (self.cutoffs[1][0],kwargs['p_cut'])
		if 'd_cut' in kwargs: self.cutoffs[2] = (self.cutoffs[2][0],kwargs['d_cut'])

		self.text  = ''
		for string in self.working[0:-1]:
			self.text += string + '\n'
		for ituple in self.cutoffs:
			try:
				self.text += ituple[0] + '%lf' % np.float64(ituple[1])
			except:
				print ituple
				raise
				
		self.text += '\n\n' # makes the ATOM program happy


# run input file

	def run(self,*args,**kwargs):
		'''.run(path=$WORK/atm,filename='psd.pot',**kwargs)
.run(*args,**kwargs), path=args[0], filename=args[1]
		Executes the ATOM application to get results. Note that this doesn't automatically parse the results. See parse() and parse_text() for that.'''
# input arguments
		path = self.path if not kwargs.has_key('path') else kwargs['path']
		filename = 'psd.pot' if not kwargs.has_key('filename') else kwargs['filename']
		Generation = True if not kwargs.has_key('Generation') else kwargs['Generation']

		if self.text != '':
			infile = open('atom.dat','w')
			infile.write(self.text)
			infile.close()
			try:
				atom = sp.Popen(path, shell=True, stdin=sp.PIPE, stdout=sp.PIPE)
				atom.wait()
			except:
				print 'Warning, failure to run the pseudopotential generator'

			if (Generation):
				try: sh.move('psd.pot',filename)
				except: print 'Warning, failure to finish the pseudopotential generator'

# parse output file
	def parse_text(self,**kwargs):
		'''.parse_text(filename='atom.out')
		fills structures Orbitals and Energy in pseudopotential structure'''
 		filename = 'atom.out' if not kwargs.has_key('filename') else kwargs['filename']

		F = open(filename,'r')
		textoutput = F.read()
		F.close()

		orbitals_info = re.findall('(\d[spdf])\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)',textoutput)
		self.Orbitals           = {}
		keys = [x[0] for x in orbitals_info]
		if len(keys) == 0: # then we know we didn't converge
			# still not sure what to do about it though...
			pass
		for key in keys:
			i = keys.index(key)
			self.Orbitals[key]      = {}
			self.Orbitals[key]['s'] = float(orbitals_info[i][1])
			self.Orbitals[key]['occ'] = float(orbitals_info[i][2])
			self.Orbitals[key]['eigenvalue'] = float(orbitals_info[i][3])
			self.Orbitals[key]['kinetic energy'] = float(orbitals_info[i][4])
			self.Orbitals[key]['pot energy'] = float(orbitals_info[i][5])

		self.Energy = dict()
		self.Energy['eigenvalues'] = float(re.search(r'sum of eigenvalues        =\s+(\S+)',textoutput).group(1))
		self.Energy['kinetic-ek']  = float(re.search(r'kinetic energy from ek    =\s+(\S+)',textoutput).group(1))
		self.Energy['el-ion']      = float(re.search(r'el-ion interaction energy =\s+(\S+)',textoutput).group(1))
		self.Energy['el-el']       = float(re.search(r'el-el  interaction energy =\s+(\S+)',textoutput).group(1))
		self.Energy['vxc']         = float(re.search(r'vxc    correction         =\s+(\S+)',textoutput).group(1))
		self.Energy['virial']      = float(re.search(r'virial correction         =\s+(\S+)',textoutput).group(1))
		self.Energy['exc+corr']    = float(re.search(r'exchange \+ corr energy    =\s+(\S+)',textoutput).group(1))
		self.Energy['kinetic-ev']  = float(re.search(r'kinetic energy from ev    =\s+(\S+)',textoutput).group(1))
		self.Energy['potential']   = float(re.search(r'potential energy          =\s+(\S+)',textoutput).group(1))
		self.Energy['total']       = float(re.search(r'total energy              =\s+(\S+)',textoutput).group(1))
 

	def parse(self,**kwargs):
		'''.parse(filename='psd.pot')
		reads in a pseudopotential formatted in PARSEC format.'''
		self.ppot   = {}
		self.ppotu  = {}
		self.aewave = {}
		self.wave   = {}
		self.zelect = {}
		self.rc     = {}

		filename = 'psd.pot' if not kwargs.has_key('filename') else kwargs['filename']

		F = open(filename,'r')
		l = F.readline()
		try:
			self.nameat, self.icorrt, self.irel, self.nicore = re.findall('\S+',l)
		except:
			print l
			raise
		self.nameat = '%-2s' % self.nameat
		self.icorrt = '%-2s' % self.icorrt
		self.irel   = '%-3s' % self.irel
		self.nicore = '%-4s' % self.nicore

		self.iray = []
		l = F.readline()
		for i in range(6): self.iray.append('%10s' % (l[1+10*i:11+10*i]))

		self.ititle = []
		l = F.readline()
		for i in range(7): self.ititle.append('%10s' % (l[1+10*i:11+10*i]))

		l = F.readline()
		nl, nls, nr, a, b, zion = re.findall('\S+',l)[0:6]

		nl = int(nl)
		nls = int(nls)
		nr = int(nr)
		
		self.npotd  = nl
		self.npotu  = nls
		self.nrm    = nr
		self.a      = float(a)
		self.b      = float(b)
		self.zion   = float(zion)

		F.readline() # trashed
		# Grid
		self.r = []
		for i in range((int(nr)+3)/4):
			l = F.readline()
			n1 = re.findall('\S+',l)
			for entry in n1:
				self.r.append(np.float64(entry))
		# Pseudopotentials - Spin Down
		for kl in range(self.npotd):
			l = F.readline()
			l = F.readline()
			il = int(re.findall('\S+',l)[0])
			self.ppot[il] = []
			for i in range((int(nr)+3)/4):
				l = F.readline()
				n1 = re.findall('\S+',l)
				for entry in n1:
					self.ppot[il].append(np.float64(entry))

		# Pseudopotentials - Spin Up
		for kl in range(self.npotu):
			l = F.readline()
			l = F.readline()
			il = int(re.findall('\S+',l)[0])
			self.ppotu[il] = []
			for i in range((int(nr)+3)/4):
				l = F.readline()
				n1 = re.findall('\S+',l)
				for entry in n1:
					self.ppotu[il].append(np.float64(entry))

		try:
			# Core charge
			l=F.readline() # Trash
			self.corecharge = []
			for i in range((int(nr)+3)/4):
				l = F.readline()
				n1 = re.findall('\S+',l)
				for entry in n1:
					self.corecharge.append(np.float64(entry))
		except:
			raise

		try:
			# valence charge
			l= F.readline() # Trash
			self.valencecharge = []
			for i in range((int(nr)+3)/4):
				l = F.readline()
				n1 = re.findall('\S+',l)
				try:
					for entry in n1:
						self.valencecharge.append(np.float64(entry))
				except:
					print "%s doesn't want to be converted to a string" % entry
		except:
			raise

		# Pseudowavefunctions
		for il in range(nl):
			lt = F.readline()
			l = F.readline()
			try:
				sl, szelect, src = re.findall('\S+',l)
			except:
				print lt
				print l
				raise
			sl = int(sl)
			self.zelect[sl] = np.float64(szelect)
			self.rc[sl] = np.float64(src)
			self.wave[sl] = []
			for i in range((int(nr)+3)/4):
				l = F.readline()
				n1 = re.findall('\S+',l)
				for entry in n1:
					self.wave[sl].append(np.float64(entry))
		for sl in self.ppot:
			for entry in self.r:
				i = self.r.index(entry)
				#self.ppot[sl][i] /= entry
				#self.wave[sl][i] /= entry

		for entry in self.r:
			i = self.r.index(entry)
			self.valencecharge[i] /= entry
			self.corecharge[i]    /= entry

		
		return copy.deepcopy(self)

	def plot(self,**kwargs):
		import pylab
		legend = []
		if kwargs.has_key('figure'): pylab.figure(kwargs['figure'])
		else: 
			ppot_figure = pylab.figure()
			wave_figure = pylab.figure()

		for l in self.ppot:
			pylab.figure(ppot_figure.number)
			pylab.plot(self.r,self.ppot[l])
			pylab.figure(wave_figure.number)
			pylab.plot(self.r,self.wave[l])
			legend.append('%d pot' % (l,))
			legend.append('%d wave' % (l,))
		if kwargs.has_key('xlim'): pylab.xlim(kwargs['xlim'])
		if kwargs.has_key('ylim'): pylab.ylim(kwargs['ylim'])
		if kwargs.has_key('legend'): legend = pylab.legend(kwargs['legend'])
		if kwargs.has_key('title'): pylab.title(kwargs['title'])
		pylab.figure(ppot_figure.number)
		pylab.plot(self.r,-2*self.zion * np.ones(len(self.r)),'--k')
		if kwargs.has_key('xlim'): pylab.xlim(kwargs['xlim'])
		if kwargs.has_key('ylim'): pylab.ylim(kwargs['ylim'])
		if kwargs.has_key('legend'): legend = pylab.legend(kwargs['legend'])
		if kwargs.has_key('title'): pylab.title(kwargs['title'])
		pylab.legend(legend[0::2])
		pylab.figure(wave_figure.number)
		pylab.legend(legend[1::2])

	def results(self,**kwargs):
		pass

	def clean(self,**kwargs):
            for file in ['psd.pot','plot.dat','plot.dat01','pseudo.dat01','atom.out']:
                    try:    os.remove(file)
                    except: pass

	def parsedat(self,**kwargs):
		return fb.readin(kwargs)

	def writeout(self,**kwargs):
		return fb.writeout(self,**kwargs)

	def test(self,**kwargs):
		self.writeout(**kwargs)
		self.text,n = re.subn('( +)(p[gt])',r'\1pt',self.text)
		if n == 0: raise Exception('not a pseudopotential generation setting.'+self.text)
		kwargs['Generation'] = False
		self.run(**kwargs)


if __name__ == '__main__':
	import pylab as plt
	import os
	Ppo = pseudopotential()
	xaxis = [1.0,2.0,3.0]
	yaxis = [1.0,2.0,2.5]
	for i in range(min(len(xaxis),len(yaxis))):
		s_cut = xaxis[i]
		p_cut = yaxis[i]
		Ppo.create('Si',s_cut=s_cut, p_cut=p_cut)
		Ppo.run(os.environ['WORK']+'/atom_v3/atm')
		Ppo.parse()
		#plt.plot(Ppo.r,Ppo.ppot[0],'--')
		#plt.plot(Ppo.r,Ppo.ppot[1],'-.',linewidth=2)
		#plt.xlim([0,5])
	
	Ppo.plot(ylim=[-35,5],xlim=[0,5])
	
	#curylim = plt.ylim()
	#plt.plot(Ppo.r,-14./numpy.array(Ppo.r),'b--')
	#plt.ylim(curylim)
	Ppo.writeout(filename='pseudo.dat')
	Ppo.run()
	Ppo.parse_text(filename='atom.out')
	#plt.legend(['s-1,1','p-1,1','s-2,2','p-2,2','s-3,2.5','p-3,2.5'])
	#plt.figure(3)
	#Ppo.plot(xlim=[0,5])

