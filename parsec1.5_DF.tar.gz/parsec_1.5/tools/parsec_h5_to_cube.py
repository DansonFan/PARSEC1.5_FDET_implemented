#!/usr/bin/env python3

"""
Demonstration of plotting wave functions from parsec.h5

Usage: python3 ./plot_wfn_from_h5.py

Description:
    1) Extract atoms coordinates from parsec.out
    2) Extract grids and wave functions from parsec.h5
    3) Output to wfn.cube (Gaussian cube format, can be opened by VMD and
       VESTA)
       Gaussian CUBE format:
           http://h5cube-spec.readthedocs.io/en/latest/cubeformat.html
           http://gaussian.com/cubegen/
    * Unit should be in Bohr. Please check whether the atom coordinates and
      grid spacing and lattice vectors are all in Bohr.
    ** If the lattice vectors have negative components, some tools may
       not be able to read it correctly (will assume the lattice vectors
       are orthogonal to each other. See more details at
       http://h5cube-spec.readthedocs.io/en/latest/cubeformat.html

Author: Kai-Hsin Liou (lioukaihsin@utexas.edu)
Date of latest update: March 2022
"""

# ==================================
#    User input
# ==================================

# Flag to output v_ion,local, v_xc, v_hart, v_new (v_new after mixing),
# and v_new_before_mixing (=v_ion,local+v_xc,v_hart)
write_out_potentials = True

write_out_electronic_charge_density = True

parsec_h5_path = "./parsec_move00000_iter00010.h5"
output_path = "./wfn.cube"
output_wfn = tuple((i,1,1,1) for i in range(1, 6))  # (istate,irp,kplp,isp)



# ==================================
#  Main program
# ==================================

import h5py
import re
import os
import numpy as np

class atom():
    def __init__(self, atomic_number, x, y, z):
        self.atomic_number = atomic_number
        self.x = x
        self.y = y
        self.z = z

atomic_number = {
    'H' : 1, 'He': 2, 'Li': 3, 'Be': 4, 'B' : 5,
    'C' : 6, 'N' : 7, 'O' : 8, 'F' : 9, 'Ne':10,
    'Na':11, 'Mg':12, 'Al':13, 'Si':14, 'P' :15,
    'S' :16, 'Cl':17, 'Ar':18, 'K' :19, 'Ca':20,
    'Sc':21, 'Ti':22, 'V' :23, 'Cr':24, 'Mn':25,
    'Fe':26, 'Co':27, 'Ni':28, 'Cu':29, 'Zn':30,
    'Ga':31, 'Ge':32, 'As':33, 'Se':34, 'Br':35,
    'Kr':36, 'Rb':37, 'Sr':38, 'Y' :39, 'Zr':40,
    'Nb':41, 'Mo':42, 'Tc':43, 'Ru':44, 'Rh':45,
    'Pd':46, 'Ag':47, 'Cd':48, 'In':49, 'Sn':50,
    'Sb':51, 'Te':52, 'I' :53, 'Xe':54, 'Cs':55,
    'Ba':56, 'La':57, 'Ce':58, 'Pr':59, 'Nd':60,
    'Pm':61, 'Sm':62, 'Eu':63, 'Gd':64, 'Tb':65,
    'Dy':66, 'Ho':67, 'Er':68, 'Tm':69, 'Yb':70,
    'Lu':71, 'Hf':72, 'Ta':73, 'W' :74, 'Re':75,
    'Os':76, 'Ir':77, 'Pt':78, 'Au':79, 'Hg':80,
    'Tl':81, 'Pb':82, 'Bi':83, 'Po':84, 'At':85,
    'Lv':116, 'Ts':117, 'Og':118
    }


if not os.path.exists(parsec_h5_path):
    raise ValueError('h5 file does not exist')


ifs = h5py.File(parsec_h5_path, 'r')

atoms = []
#wfns = []

stype = ifs['/details'].attrs['stype(:)']
type_num = ifs['/clust'].attrs['clust%type_num'][0]
atom_num = ifs['/clust'].attrs['clust%atom_num'][0]
atype_name = ifs['/clust/clust%name(:)'][0]
natmi = ifs['/clust/clust%natmi(:)'][0]
xatm = ifs['/clust/clust%xatm(:)'][0]
yatm = ifs['/clust/clust%yatm(:)'][0]
zatm = ifs['/clust/clust%zatm(:)'][0]
kx = ifs["/grid/grid%kx(:)"][0]
ky = ifs["/grid/grid%ky(:)"][0]
kz = ifs["/grid/grid%kz(:)"][0]



# rho(:,:) has a shape of (nspin, N_grid)
rho = ifs["/elec_st/elec_st%rho(:,:)"]
spnum = int((rho.shape[0] + 1)/2)



vion = ifs["/pot/pot%vion(:)"][0]
vxc = ifs["/pot/pot%vxc(:,:)"]
vhart = ifs["/pot/pot%vhart(:)"][0]
vnew_before_mixing = ifs["/pot/pot%vnew_before_mixing(:,:)"]
vnew = ifs["/pot/pot%vnew(:,:)"]

step = ifs["/grid"].attrs["grid%step(:)"]
shift = ifs["/grid"].attrs["grid%shift(:)"]


num_of_volume_data = 0



# ============
#  System type
# ============

if stype[1] == 0:
    is_complex = False
elif stype[1] == 1:
    is_complex = True
else:
    raise ValueError('the system type is not supported yet')

# stype[2] = 0: 0D
# stype[2] = 2: 1D
# stype[2] = 3: 2D
# stype[2] = 1: 3D
if stype[2] == 2:
    raise ValueError('the system type is not supported yet')


if stype[2] != 0:
    latt_vec = ifs["/grid"].attrs["pbc%latt_vec(:,:)"]



# ============
#  Putting in the volumetric datasets
# ============

volume_data = []


# charge density
if write_out_electronic_charge_density:
    for i in range(int(spnum*2 - 1)):
        volume_data.append(rho[i,:])

if write_out_potentials:
    # local part of the ionic potential energy
    volume_data.append(vion[:])

    # exchange-correlation potential energy
    for i in range(spnum):
        volume_data.append(vxc[i,:])

    # Hartree
    volume_data.append(vhart[:])

    # total potential before mixing
    for i in range(spnum):
        volume_data.append(vnew_before_mixing[i,:])

    # total potential after mixing
    for i in range(spnum):
        volume_data.append(vnew[i,:])




# ============
#  wave functions
# ============


if is_complex:
    for wfn in output_wfn:
        print("Reading in the wfn of state "+str(wfn[0]))
        wfn_re_dataset = ifs["/elec_st/isp" + str(wfn[3]).zfill(5) + \
                             "/kplp" + str(wfn[2]).zfill(5) + \
                             "/irp" + str(wfn[1]).zfill(5) + \
                             "/wavefunctions_re(:,:)"]
        wfn_im_dataset = ifs["/elec_st/isp" + str(wfn[3]).zfill(5) + \
                             "/kplp" + str(wfn[2]).zfill(5) + \
                             "/irp" + str(wfn[1]).zfill(5) + \
                             "/wavefunctions_im(:,:)"]

        my_re = wfn_re_dataset[wfn[0]-1,:]
        my_im = wfn_im_dataset[wfn[0]-1,:]

        volume_data.append(my_re)
        volume_data.append(my_im)
        volume_data.append(np.abs(my_re + 1j*my_im))
        #wfns.append(my_re + 1j*my_im)

else:
    for i, wfn in enumerate(output_wfn):
        print("Reading in the wfn of state "+str(wfn[0]))
        wfn_dataset = ifs["/elec_st/isp" + str(wfn[3]).zfill(5) + \
                          "/kplp" + str(wfn[2]).zfill(5) + \
                          "/irp" + str(wfn[1]).zfill(5) + \
                          "/wavefunctions(:,:)"]

        volume_data.append(wfn_dataset[wfn[0]-1,:]) # '-1' because wfns starts
        volume_data.append(np.abs(wfn_dataset[wfn[0]-1,:]))
        #wfns.append(wfn_dataset[wfn[0]-1,:])       # '-1' because wfns starts
        #                                           # from 0






ifs.close()




print("Number of volume data = {}".format(len(volume_data)))




# ============
#  Atom coordinates
# ============
iatom = 0
for itype in range(type_num):
    for jj in range(natmi[itype]):
        iatom += 1

        # Seems no need to strip the name string since decode()
        # will remove the whitespaces
        atoms.append(atom(atomic_number[atype_name[itype].decode('ascii')], \
                xatm[iatom-1], yatm[iatom-1], zatm[iatom-1]))

print('There should be {} atoms'.format(atom_num))
print('We read in {} atoms'.format(iatom))



# Prepare for outputting

# Calculate the number of grids along each axis
grid_points_number = (max(kx) - min(kx) + 1, \
                      max(ky) - min(ky) + 1, \
                      max(kz) - min(kz) + 1)

# Create the conversion list
#   For example, (kx[20], ky[20], kz[20]) = (-5, 0, 1) and
#   (min(kx), min(ky), min(kz)) = (-25, -25, -25), then
#   grid_points_1d[20][25][26] = 20
grid_points_1d = [[[-1 for k in range(grid_points_number[2])] \
                       for j in range(grid_points_number[1])] \
                       for i in range(grid_points_number[0])]

grid_min = (min(kx), min(ky), min(kz))

for igrid in range(len(kx)):
    i = kx[igrid] - grid_min[0]
    j = ky[igrid] - grid_min[1]
    k = kz[igrid] - grid_min[2]
    grid_points_1d[i][j][k] = igrid

latt_vec_per_step = []
if is_complex:
    if stype[2] == 1:
        for i in range(3):
            latt_vec_per_step.append([x/grid_points_number[i] for x in latt_vec[i]])
    elif stype[2] == 3:
        for i in range(2):
            latt_vec_per_step.append([x/grid_points_number[i] for x in latt_vec[i]])
        latt_vec_per_step.append([0, 0, step[2]])
    else:
        raise ValueError('unknown stype[2]')
else:
    latt_vec_per_step.append([step[0], 0, 0])
    latt_vec_per_step.append([0, step[1], 0])
    latt_vec_per_step.append([0, 0, step[2]])



# Calculate the origin (corner) of the box
grid_origin_cartesian = []
for jcol in range(3):
    grid_origin_cartesian.append( \
                        latt_vec_per_step[0][jcol] * (min(kx) + shift[0]) + \
                        latt_vec_per_step[1][jcol] * (min(ky) + shift[1]) + \
                        latt_vec_per_step[2][jcol] * (min(kz) + shift[2]))


# Start writing to the output file
ofs = open(output_path, 'w')

ofs.write("comment line 1\n")
ofs.write("comment line 2\n")
ofs.write("-" + str(len(atoms)) + " " + \
          str(grid_origin_cartesian[0]) + " " + \
          str(grid_origin_cartesian[1]) + " " + \
          str(grid_origin_cartesian[2]) + " " + \
          "\n")

# assume rectangular box
for jcol in range(3):
    print("%d %13.5e %13.5e %13.5e" % (grid_points_number[jcol], *latt_vec_per_step[jcol]), file=ofs)


# lengths of the lattice vectors
if stype[2] != 0:
    latt_size = [np.sqrt(np.sum(latt_vec[i]**2)) for i in range(3)]


for atom in atoms:
    # stype[2] = 0: 0D
    # stype[2] = 2: 1D
    # stype[2] = 3: 2D
    # stype[2] = 1: 3D
    if stype[2] == 1:
        for kk in range(2):
            tmp_atom_coord = np.array((atom.x, atom.y, atom.z))
            tmp_projection = tmp_atom_coord.dot(latt_vec[kk]) / latt_size[kk]
            multiple_outside_the_original_cell = np.floor(tmp_projection / latt_size[kk])
            tmp_atom_coord -= latt_vec[kk] * multiple_outside_the_original_cell
            atom.x = tmp_atom_coord[0]
            atom.y = tmp_atom_coord[1]
            atom.z = tmp_atom_coord[2]
        atom.x += grid_origin_cartesian[0]
        atom.y += grid_origin_cartesian[1]
        atom.z += grid_origin_cartesian[2]
    elif stype[2] == 3:
        for kk in range(2):
            tmp_atom_coord = np.array((atom.x, atom.y, 0))
            tmp_projection = tmp_atom_coord.dot(latt_vec[kk]) / latt_size[kk]
            multiple_outside_the_original_cell = np.floor(tmp_projection / latt_size[kk])
            tmp_atom_coord -= latt_vec[kk] * multiple_outside_the_original_cell
            atom.x = tmp_atom_coord[0]
            atom.y = tmp_atom_coord[1]
        atom.x += grid_origin_cartesian[0]
        atom.y += grid_origin_cartesian[1]
    elif stype[2] == 2:
        for kk in range(1):
            tmp_atom_coord = np.array((atom.x, 0, 0))
            tmp_projection = tmp_atom_coord.dot(latt_vec[kk]) / latt_size[kk]
            multiple_outside_the_original_cell = np.floor(tmp_projection / latt_size[kk])
            tmp_atom_coord -= latt_vec[kk] * multiple_outside_the_original_cell
            atom.x = tmp_atom_coord[0]
        atom.x += grid_origin_cartesian[0]
    elif stype[2] == 0:
        pass
    else:
        raise ValueError("stype[2] is wrong")


    ofs.write(str(atom.atomic_number) + " 0.0 " + \
              str(atom.x) + " " + \
              str(atom.y) + " " + \
              str(atom.z) + "\n")



if write_out_electronic_charge_density:
    num_of_volume_data += int(spnum*2 - 1)

if write_out_potentials:
    num_of_volume_data += 1
    num_of_volume_data += spnum
    num_of_volume_data += 1
    num_of_volume_data += spnum
    num_of_volume_data += spnum


if is_complex:
    # real(value), imag(value), and abs(value)
    num_of_volume_data += int(len(output_wfn)*3)
else:
    # value and abs(value)
    num_of_volume_data += int(len(output_wfn)*2)





ofs.write(str(num_of_volume_data) + " ")

if write_out_electronic_charge_density:
    for i in range(int(spnum*2 - 1)):
        ofs.write(str(i) + " ")

if write_out_potentials:
    for i in range(int(spnum*3 + 2)):
        ofs.write(str(i) + " ")

for wfn in output_wfn:
    # One for the value (two values if complex), while the other for the
    # absolute value
    # In this way we can plot colored isosurfaces on VMD
    if is_complex:
        ofs.write(str(wfn[0]) + " ")
    ofs.write(str(wfn[0]) + " ")
    ofs.write(str(wfn[0]) + " ")
ofs.write('\n')





for i in range(grid_points_number[0]):
    for j in range(grid_points_number[1]):
        counter = 6
        for k in range(grid_points_number[2]):
            for vol in volume_data:
                counter = counter - 1
                if grid_points_1d[i][j][k] != -1:
                    print("%13.5e" % vol[grid_points_1d[i][j][k]], \
                          file=ofs, end='')
                else:
                    print("%13.5e" % 0, file=ofs, end='')
                if counter == 0:
                    ofs.write("\n")
                    counter = 6
        if counter != 6:
            ofs.write("\n")

        ofs.write("\n")

ofs.close()


