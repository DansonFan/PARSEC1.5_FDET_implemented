#!/usr/bin/env python

"""
@brief This program is used to generate Si_X H_Y silicon nanocrystals / quantum dots / structures 
        20171208 - add the option to remove one-fold coordinated Si atoms
@detail For PARSEC or in XYZ format
@author Kai-Hsin Liou
@date 2017-12-08
"""

import argparse
import os.path
import scipy.constants
import numpy as np
import multiprocessing as mp
import math

### ======================================================================
#
# Example: python generate_silicon_nanocrystal.py Si_NC.xyz 20 0
#
### ======================================================================

parser = argparse.ArgumentParser(description=
                    'Generate atomic model of Si nanocrystal')
parser.add_argument('outfile', type=str, nargs=1, 
                    help='filename of the output file')
parser.add_argument('rcut', type=float, nargs=1,
        help='cutoff radius of the nanocrystal (unit: Bohr)')
parser.add_argument('outformat', type=int, nargs=1,
        help='0: xyz format, 1: parsec format')
parser.add_argument('--rm_onefold', type=int, nargs=1,
        help='remove one-fold coordinated Si atoms (0: no, 1: yes)')

args = parser.parse_args()

### ======================================================================

bohr_in_meter = scipy.constants.physical_constants["Bohr radius"][0]

### ======================================================================

def generate_Si(rcut, rm_onefold):
    """  INPUT: cutoff radius
        OUTPUT: a list of coordinates of Si atoms
                e.g. [atom1_coord, atom2_coord, ...]
                
                and a list of surface Si atoms
                e.g. [[atom1_coord, atom1_connected_1_coord, ...],
                      [atom2_coord, atom2_connected_1_coord, ...], ...]
    """
    # lattice constant of bulk silicon, in Bohr
    lat = 5.43 / (bohr_in_meter * 1e10)

    # radius within which neighbor Si atoms are detected 
    detection_radius = 5

    # lattice vectors of the conventional unit cell
    lat_vec = np.array([[lat, 0, 0],
                        [0, lat, 0],
                        [0, 0, lat]])

    basis = np.array([[0, 0, 0],
                      [lat/2, lat/2,     0],
                      [    0, lat/2, lat/2],
                      [lat/2,     0, lat/2],
                      [  lat/4,   lat/4,   lat/4],
                      [3*lat/4, 3*lat/4,   lat/4],
                      [  lat/4, 3*lat/4, 3*lat/4],
                      [3*lat/4,   lat/4, 3*lat/4]])

    # Number of unit cells along one direction. "5" is used to make sure the 
    # supercell will be large enough before removing atoms
    ncell = int(rcut / lat) + 5

    # Construct the unpassivated silicon nanocrystal
    Si_atoms = []
    is_saturated = []
    coordination = []
    coordinated_atoms = []
    for i in range(ncell*2):
        for j in range(ncell*2):
            for k in range(ncell*2):
                for m in basis:
                    coord = (i - ncell) * lat_vec[0] + \
                            (j - ncell) * lat_vec[1] + \
                            (k - ncell) * lat_vec[2] + m

                    # If the new Si atom is within the cutoff radius
                    if np.linalg.norm(coord) < rcut:
                        tmp_is_saturated = False
                        tmp_coordination = 0
                        tmp_coordinated_atoms = []

                        # Because the new Si atom will be pushed into the back 
                        # of Si_atoms after the connection detection, its index
                        # is always len(Si_atoms)
                        idx_atom_cur = len(Si_atoms)

                        # Search possible connected Si atoms from the current
                        # Si_atoms
                        for idx_atom in range(idx_atom_cur):
                            if is_saturated[idx_atom] == False:
                                distance = np.linalg.norm( \
                                                Si_atoms[idx_atom] - coord)
                                if distance < detection_radius:
                                    coordination[idx_atom] += 1
                                    coordinated_atoms[idx_atom].append( \
                                                                idx_atom_cur)
                                    if coordination[idx_atom] == 4:
                                        is_saturated[idx_atom] = True
                                    tmp_coordination += 1
                                    tmp_coordinated_atoms.append(idx_atom)

                        # Add its own coordinates such that we don't need 
                        # Si_atoms in generate_H()
                        tmp_coordinated_atoms.insert(0, idx_atom_cur)

                        coordinated_atoms.append(tmp_coordinated_atoms)
                        coordination.append(tmp_coordination)
                        if tmp_coordination == 4:
                            is_saturated.append(True)
                        else:
                            is_saturated.append(False)
                        Si_atoms.append(coord)

    # remove one-fold coordinated Si atoms and update Si_atoms, 
    # coordination, coordinated_atoms
    if rm_onefold == 1:
        for i in range(len(coordination)):
            if coordination[i] == 1:
                # remove the idx of the removed atom from the list of its
                # only one connected atom
                idx_connected_atom = coordinated_atoms[i][1]
                coordinated_atoms[idx_connected_atom].remove(i)
                if coordination[idx_connected_atom] != 4:
                    raise ValueError('Encounter special case? (very few atoms)')
                coordination[idx_connected_atom] -= 1
                coordination[i] -= 1

    surface_atoms = []
    for i in range(len(coordination)):
        if coordination[i] != 4:
            if coordination[i] in (1, 2, 3):
                surface_atoms.append([Si_atoms[j] for j in \
                                                        coordinated_atoms[i]])
            else:
                if rm_onefold == 1 and coordination[i] == 0:
                    pass
                else:
                    raise ValueError("There's an atom w/ strange coordination")

    if rm_onefold == 1:
        new_Si_atoms = []
        for i in range(len(coordination)):
            if coordination[i] != 0:
                new_Si_atoms.append(Si_atoms[i])
                if coordination[i] == 1:
                    raise ValueError( \
                            'Should not have Si atoms with coordination=1 now')
        Si_atoms = new_Si_atoms

    return Si_atoms, surface_atoms


def perpendicular_vector(v):
    """  INPUT: A 3D vector v
        OUTPUT: A 3D vector perpendicular to v
    """
    if v[1] == 0 and v[2] == 0:
        if v[0] == 0:
            raise ValueError('zero vector')
        else:
            return np.cross(v, [0, 1, 0])
    return np.cross(v, [1, 0, 0])


def generate_H(surface_atoms):
    """  INPUT: a list of lists of coordinates of surface Si atoms and their
                connected Si atoms
        OUTPUT: a list of coordinates of H atoms
    """
    # S-H bond length, in Bohr
    SH_len = 1.46 / (bohr_in_meter * 1e10)

    H_atoms = []
    for connection_list in surface_atoms:
        atom1 = connection_list[0]

        # -1 because the first atom in any connection_list is the Si atom itself
        coordination = len(connection_list) - 1

        if coordination == 1:
            print('CAUTION: There is Si with coordination # = 1')
            atom2 = connection_list[1]
            vec1 = atom2 - atom1
            vec2 = perpendicular_vector(vec1)
            vec2 = vec2 / np.linalg.norm(vec2) * SH_len * 0.94281
            pseudo_atom2 = atom1 + vec1 / np.linalg.norm(vec1) * SH_len
            triangle_center = atom1 + (atom1 - pseudo_atom2) / 3
            H1 = triangle_center + vec2
            vec3 = np.cross(vec1, vec2)
            edge_center = atom1 + (atom1 - (H1 + pseudo_atom2) / 2)
            H2 = edge_center + vec3 / np.linalg.norm(vec3) * SH_len * 0.8165
            H3 = edge_center - vec3 / np.linalg.norm(vec3) * SH_len * 0.8165
            H_atoms += [H1, H2, H3]

        elif coordination == 2:
            coord_atoms = []
            for atom2 in connection_list[1:]:
                coord_atoms.append(atom2)
            for i in range(2):
                coord_atoms[i] = atom1 + (coord_atoms[i] - atom1) / \
                            np.linalg.norm(coord_atoms[i] - atom1) * SH_len
            vec2 = np.cross(atom1-coord_atoms[0], atom1-coord_atoms[1])
            edge_center = atom1 + (atom1 - (coord_atoms[0]+coord_atoms[1]) / 2)
            H1 = edge_center + vec2 / np.linalg.norm(vec2) * SH_len * 0.8165
            H2 = edge_center - vec2 / np.linalg.norm(vec2) * SH_len * 0.8165
            H_atoms += [H1, H2]

        elif coordination == 3:
            coord_atoms = []
            for atom2 in connection_list[1:]:
                coord_atoms.append(atom2)
            for i in range(3):
                coord_atoms[i] = atom1 + (coord_atoms[i] - atom1) / \
                            np.linalg.norm(coord_atoms[i] - atom1) * SH_len
            H1 = atom1 * 4 - (coord_atoms[0] + coord_atoms[1] + coord_atoms[2])
            H_atoms += [H1]

        elif coordination == 0:
            print('!!CAUTION!!: There is Si with coordination # = 0')
            print("!!CAUTION!!: The system should have only one Si atom")
            H0 = atom1 + np.array([0, 0, SH_len])
            vec1 = H0 - atom1
            vec2 = perpendicular_vector(vec1)
            vec2 = vec2 / np.linalg.norm(vec2) * SH_len * 0.94281
            pseudo_atom2 = atom1 + vec1 / np.linalg.norm(vec1) * SH_len
            triangle_center = atom1 + (atom1 - pseudo_atom2) / 3
            H1 = triangle_center + vec2
            vec3 = np.cross(vec1, vec2)
            edge_center = atom1 + (atom1 - (H1 + pseudo_atom2) / 2)
            H2 = edge_center + vec3 / np.linalg.norm(vec3) * SH_len * 0.8165
            H3 = edge_center - vec3 / np.linalg.norm(vec3) * SH_len * 0.8165
            H_atoms += [H0, H1, H2, H3]

    return H_atoms

def output2file(Si_atoms, H_atoms, outformat, ofs):
    if outformat == 0:
        ofs.write('%i\n\n' % (len(Si_atoms) + len(H_atoms)))
        for atom in Si_atoms:
            ofs.write('Si %f %f %f\n' % tuple(atom))
        for atom in H_atoms:
            ofs.write('H %f %f %f\n' % tuple(atom))

    if outformat == 1:
        ofs.write('atom_type        Si\n')
        ofs.write('local_component  p\n')
        ofs.write('begin atom_coord\n')
        for atom in Si_atoms:
            ofs.write('%f %f %f\n' % tuple(atom))
        ofs.write('end atom_coord\n')

        ofs.write('\n')

        ofs.write('atom_type        H\n')
        ofs.write('local_component  s\n')
        ofs.write('begin atom_coord\n')
        for atom in H_atoms:
            ofs.write('%f %f %f\n' % tuple(atom))
        ofs.write('end atom_coord\n')

if __name__ == "__main__":

    if os.path.exists(args.outfile[0]):
        raise IOError('Outfile already exists.')

    with open(args.outfile[0], 'w') as ofs:
        rcut = args.rcut[0]
        outformat = args.outformat[0]
        rm_onefold = args.rm_onefold[0]

        # Generate a bare Si nanocrystal
        Si_atoms, surface_atoms = generate_Si(rcut, rm_onefold)

        # Generate H atoms according to the surface Si atoms
        H_atoms = generate_H(surface_atoms)

        output2file(Si_atoms, H_atoms, outformat, ofs)

        # Calculate the cluster radius from H atoms 
        # Note: the center of the cluster is (0,0,0) in this code.
        radius_max_squared = max([atom[0]**2 + atom[1]**2 + atom[2]**2 \
                                                    for atom in H_atoms])
        radius_max = np.sqrt(radius_max_squared)

        print('Number of silicon atoms: %i' % len(Si_atoms))
        print('Number of hydrogen atoms: %i' % len(H_atoms))
        print('Number of total atoms: %i' % (len(Si_atoms) + len(H_atoms)))
        print('Actual radius (in Bohr): %f' % (radius_max))
        print('Actual diameter (in nm): %f' %(radius_max*2*bohr_in_meter*1e9))
