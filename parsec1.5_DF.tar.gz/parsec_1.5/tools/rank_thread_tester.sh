#for dir in ../InP_wire ../naphthalene ../polyacetylene ../Si28H36 ../water ../ZnO \
	#../../new_test_suite/TierII/ClCH3-dipole \
	#../../new_test_suite/TierII/NO2CH3-dipole ;
for dir in  ../benchmarks/Si28H36 ;
do
	( cd $dir ; 
	module load intel impi
	ulimit -a unlimited
	gridspacing=$( grep "^\s*Grid_Spacing:" parsec.in | sed -r -e "s/Grid_Spacing:\s*(\S+)/\1/g" )
	for thread in 1 2 4 6 ; 
	do
		export OMP_NUM_THREADS=$thread
		export KMP_NUM_THREADS=$thread
		export NUM_PROCS=$(( 12 / $thread ))
		touch logerr.out
		mpiexec --errfile-pattern logerr.out -np $NUM_PROCS ~/parsec_1.4/branches/adventur*/parsec/src/parsec-intel17-*17.0.2*
		mv parsec.out parsec.${NUM_PROCS}.${OMP_NUM_THREADS}.out
		mv out.0000 out.${NUM_PROCS}.${OMP_NUM_THREADS}.out
		mv logerr.out logerr.${NUM_PROCS}.${OMP_NUM_THREADS}.out
	done
	)
done
