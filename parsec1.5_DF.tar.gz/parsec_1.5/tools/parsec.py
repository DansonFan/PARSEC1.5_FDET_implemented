#!/usr/bin/env python
# Parsec python interface
# Enables the creation of PARSEC input files, creation of PARSEC directories, job submission of PARSEC runs for said directories, parsing of PARSEC output files
import subprocess as sp, re, os, shutil
import numpy as np
import pseudopotential

class PException(Exception):
	pass
	

class Parsec_Interface:
#initialize
	def __init__(self, path, **kwargs):
		self.path = path
		self.parsecin =''
# test for executable location
# test for executable's execution
# assign various kwargs to object
		pass
	def export_run(self, **kwargs):
		exec_string = ''
		if kwargs.has_key('MPI'): 
			exec_string = 'mpiexec -n %d ' % (kwargs['MPI']) + self.path
		else:
			exec_string = self.path
		return exec_string

# create test directory
	def create_test(self, **kwargs):
		dialation = 1.0 if not kwargs.has_key('dialation') else kwargs['dialation']
		gridspacing = .31 if not 'gridspacing' in kwargs else kwargs['gridspacing']
		eigensolver = 'chebdav' if not 'eigensolver' in kwargs else kwargs['eigensolver']
		outname = 'parsec.out' if not 'outname' in kwargs else kwargs['outname']
		inname  = 'parsec.in'  if not 'inname'  in kwargs else kwargs['inname']
		boundary_sphere_radius = 12 if not 'boundary_sphere_radius' in kwargs else kwargs['boundary_sphere_radius']
		if not 'elements' in kwargs: raise PException('No elements are specified!') 
		if not 'states_num' in kwargs: raise PException('Number of states required!') 
		Net_charges = 0 if not 'Net_charges' in kwargs else kwargs['Net_charges']
		NAtomTypes = len(kwargs['elements'].keys())
		#for element in kwargs['elements'].keys(): print element, kwargs['elements'][element]['local_coordinate'], kwargs['elements'][element]['Atom_Coords']

		F = open(inname,'w')
		if kwargs.has_key('boundary_sphere_radius'): F.write('Boundary_Sphere_Radius: %lf\n' % boundary_sphere_radius)
		F.write('Grid_Spacing: %lf\n' % (dialation*gridspacing))
		F.write('eigensolver %s\n' % eigensolver)
		if kwargs.has_key('states_num'): F.write('States_Num: %d\n' % kwargs['states_num'])

		if kwargs.has_key('cell_shape'):
			F.write('Boundary_Conditions    bulk\n')
			F.write('begin cell_shape\n')
			xyz = [[1,0,0],[0,1,0],[0,0,1]] if not kwargs.has_key('cell_shape') else kwargs['cell_shape']
			for coord in xyz: F.write('%lf %lf %lf\n' % tuple(dialation * np.array(coord)))
			F.write('end cell_shape\n')
			F.write('Lattice_Vector_Scale %lf\n' % (kwargs['lattice_vector_scale']))

		if kwargs.has_key('Coordinate_Unit'): F.write('Coordinate_Unit  '+kwargs['Coordinate_Unit']+'\n')
		F.write('Atom_Types_Num: %d\n' % NAtomTypes)
		if kwargs.has_key('Monkhorst_Pack_Grid'): F.write('Kpoint_method        mp\nbegin Monkhorst_Pack_Grid\n%d %d %d\nend Monkhorst_Pack_Grid\n')
		if kwargs.has_key('extraflags'): F.write(kwargs['extraflags']+'\n')
		F.write('#-------begin new atom type------\n')
		for element in kwargs['elements'].keys():
			F.write('Atom_Type: %s\n' % element)
			F.write('Local_Component: %s\n' % kwargs['elements'][element]['local_coordinate'])
			F.write('begin Atom_Coord\n')
			if not hasattr(kwargs['elements'][element]['Atom_Coords'][0],'__len__'):
				F.write('\t%lf\t%lf\t%lf\n' % (tuple(dialation * np.array(kwargs['elements'][element]['Atom_Coords']))))
			else:
				for xyz in kwargs['elements'][element]['Atom_Coords']:
					F.write('\t%lf\t%lf\t%lf\n' % (tuple(dialation * np.array(xyz))))
			F.write('end Atom_Coord\n')
		F.write('#-------end atom type------------')
		F.close()
		

# default string op
	def __str__(self):
		outstr=''
		return outstr

# modify test directory
	def modify_test(self, **kwargs):
		pass

# run test directory
	def run_test(self, cwd=None,**kwargs):
		outname = 'parsec.out' if not 'outname' in kwargs else kwargs['outname']
		maxticks = 100
		maxbandwidth = 1000
		maxupdate = 1000
		path = self.path if not 'path' in kwargs else kwargs['path']
		parsec = sp.Popen(path,cwd=cwd,shell=True, stdin=sp.PIPE, stdout=sp.PIPE, stderr=sp.PIPE)
		self.outputs = parsec.wait()
# limitations on running - self killing jobs for bandwidth, minimum, energy tolerance, iteration

# parse output directory

	def Eigenvalues_fxn(x):
		v = [[int(k[0]) for k in x],[float(k[1]) for k in x],[float(k[2]) for k in x],[int(k[3]) for k in x]]
		numstate = max(v[0])
		eigenvalues_by_iteration = list()
		for j in range(0,len(v[0]),10):
			eigenvalues_by_iteration.append([v[0][j:j+numstate],v[1][j:j+numstate],v[2][j:j+numstate],v[3][j:j+numstate]])
		return eigenvalues_by_iteration

	def SRE_fxns(x):
		# separate the SRE returns into a list of [scf-loop, scf-iter, SRE]
		v = [[int(k[0]) for k in x],[int(k[1]) for k in x],[float(k[2]) for k in x]]
		return v

	IO_CONSTANTS = {'Eigenvalue_Energy':(r'Eigenvalue Energy\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Hartree_Energy': (     r'Hartree Energy\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Electron-Ion': (r'Electron-Ion Energy\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Ion-Ion': (     r'Ion-Ion Energy\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Energy_atom': ( r'Energy/atom\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Total_Energy': (r'Total Energy\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=float)),
			'Grid_Spacing': (r'grid spacing is\s+(\S+)\s+',re.IGNORECASE,lambda x: float(x[0])),
			'CPU_Runtime': (r'CPU time \[sec\]\s+:\s+(\S+)',re.IGNORECASE,lambda x: float(x[0])),
			'Runtime': (r'Wall-clock time \[sec\]\s+:\s+(\S+)',re.IGNORECASE,lambda x: float(x[0])),
			'Matvec': (r'cumulated\s+number\s+of\s+matrix-vector\s+mult[\.i]?p?l?i?c?a?t?i?o?n?s?\s+=\s+(\S+)',re.IGNORECASE,lambda x: np.array(x,dtype=int)),
			'Hamiltonian': (r'The Hamiltonian matrix size is\s+(\S+)',re.IGNORECASE,lambda x: int(x[0])),
			'SRE_pot':(r'(\S+)-\s+(\S+)\s+SRE of pot. & charge weighted pot =\s+(\S+)\s+\S+',re.IGNORECASE,SRE_fxns),
			'SRE_cwpot':(r'(\S+)-\s+(\S+)\s+SRE of pot. & charge weighted pot =\s+\S+\s+(\S+)',re.IGNORECASE,SRE_fxns),
			'Eigenvalues':(r'^\s+([0-9]+)\s+(\S+)\s+\S+\s+([0-9\.]+)\s+([0-9]+)$',re.MULTILINE+re.IGNORECASE,Eigenvalues_fxn)}
		# todo:
			# add force per atom
			# add net force
			# add torque


	def parse_errors(self, **kwargs):
		self.errors = re.findall(r'(ERROR.*error.*$)',self.parsecdata,re.MULTILINE+re.DOTALL)
		if len(self.errors) == 0:
			self.errors = re.findall(r'(ERROR.*STOP.*$)',self.parsecdata,re.MULTILINE+re.DOTALL)

	def parse_output(self, **kwargs):
		''' Finds the last mention of these pieces of data in the parsec.out file
		{:s}
		'''.format(*self.IO_CONSTANTS)

		self.parsecout = kwargs.get('parsecout','parsec.out')
		with open(self.parsecout,'r') as data:
			self.parsecdata = data.read()
		searchterm = kwargs.get('searchterm_',self.IO_CONSTANTS.keys())

 		#somewhat crafty way to get around the entire fact that
		# the user might not give a list
		if len(searchterm[0])==1: searchterm = [searchterm]

		errors = False
		for IO_KEY in searchterm:
			try:
				setattr( self, IO_KEY, self.IO_CONSTANTS[IO_KEY][2](re.findall( self.IO_CONSTANTS[IO_KEY][0] , self.parsecdata, self.IO_CONSTANTS[IO_KEY][1])))
			except KeyError as e:
				print searchterm
				raise e
			except Exception as e:
				print IO_KEY, re.findall( self.IO_CONSTANTS[IO_KEY][0] , self.parsecdata, self.IO_CONSTANTS[IO_KEY][1])
				errors = True
				setattr( self, IO_KEY, e)

		if errors: 
			self.parse_errors()
			print self.errors

		return self


# parse wavefunction data
	def parse_textoutput(self, **kwargs):
		pass

# parse wavefunction data
	def parse_wfnoutput(self, **kwargs):
		pass
class UnitCell():
	''' This too shall pass
	and this.
	and that.'''
	def define_zincblende(self):
		# require lattice constant a
		self.a = self.lattice_constants['a']
		self.primitive_vectors = .5*(np.array([[1,1,0],[1,0,1],[0,1,1]],dtype=np.float64))
		self.lattice_vector_scale = self.a
		# basis vectors
		self.basis_vectors = [None,None]
		self.basis_vectors[0] =     np.array([0,0,0],dtype=np.float64)
		self.basis_vectors[1] = .25*np.array([1,1,1],dtype=np.float64)
		# lattice vectors
		self.lattice_vectors = []
		self.lattice_vectors.append(self.basis_vectors[0])
		self.lattice_vectors.extend([self.basis_vectors[0]+primitive for primitive in self.primitive_vectors])
		#print self.lattice_vectors
		self.lattice_vectors.append(self.basis_vectors[1])
		self.lattice_vectors.extend([self.basis_vectors[1]+primitive for primitive in self.primitive_vectors])
		#print self.lattice_vectors

	def define_wurtzite(self):
		self.a = self.lattice_constants['a'] ; a = self.a
		self.c = self.lattice_constants['c'] ; c = self.c
		self.u = 3.0/8.0 if not self.lattice_constants.has_key('u') else self.lattice_constants['u'] ; u = self.u
		# primitive unit vectors
		self.primitive_vectors = np.array([[.5*a/c,-.5*sqrt(3)*a/c,0],[.5*a/c,.5*sqrt(3)*a/c,0],[0,0,1]],dtype=np.float64)
		self.lattice_vector_scale = c
		# basis vectors
		self.basis_vectors = [None,None]
		self.basis_vectors[0] = np.array([[1.0/3.0, 2.0/3.0, 0], [2.0/3.0, 1.0/3.0, 1.0/2.0]],dtype = np.float64)
		self.basis_vectors[1] = np.array([[1.0/3.0, 2.0/3.0, u], [2.0/3.0, 1.0/3.0, 1.0/2.0 + u]],dtype = np.float64)
		# unit number

	def define_all(self):
		available = []
		available.append('zincblende')
		available.append('wurtzite')
		return available

	def __init__(self,**kwargs):
		self.lattice_constants = kwargs['lattice_constants']
		self.structure = kwargs['structure']
		self.available_structures = self.define_all()
# zincblende
		if self.structure not in self.available_structures: raise Exception(str(self.structure) + ' not specified in class')
		eval('self.define_'+self.structure+'()')
		

def setup_parsec_in( dilation ):
	f = open( 'parsec.in' )
	fout = open( 'parsec.in-0', 'w' )
	reading_domain = False
	reading_atom_coord = False
	for l in f:
		overwritten = False
		m = re.match( r'\s*grid_spacing\s*\S?\s*(\S+)\s*', l, re.IGNORECASE )
		if m:
			fout.write( 'grid_spacing: ' + str( float( m.group(1) ) * dilation ) + '\n')
			overwritten = True
		m = re.match( r'\s*end\s*cell_shape.*', l, re.IGNORECASE )
		if m: reading_domain = False
		m = re.match( r'\s*end\s*atom_coord.*', l, re.IGNORECASE )
		if m: reading_atom_coord = False
		if reading_domain:
			overwritten = True
			m = re.findall( r'(\S+)', l )
			if m:
				for s in m:
					fout.write( '    ' + str( float( s ) * dilation ) )
				fout.write( '\n' )
		if reading_atom_coord:
			overwritten = True
			m = re.findall( r'(\S+)', l )
			if m:
				for s in m:
					fout.write( '    ' + str( float( s ) * dilation ) )
				fout.write( '\n' )
		m = re.match( r'\s*begin\s*cell_shape.*', l, re.IGNORECASE )
		if m: reading_domain = True
		m = re.match( r'\s*begin\s*atom_coord.*', l, re.IGNORECASE )
		if m: reading_atom_coord = True
		if not overwritten: fout.write( l )
	fout.flush( )
	fout.close( )
class param_list(object):
	def __init__(self,values,names):
		if len(values) != len(names) : raise Exception('Number of labels differs from number of values')
		self.values = values
		self.labels = names
	def __len__(self):
		return len(self.values)

	def __getitem__(self,y):
		return self.values[y]

	def __getslice__(self,i,j):
		return self.value[i:j] 
	def todict(self):
		returned_dict = {}
		for i in range(len(self)):
			returned_dict[self.labels[i]] = self[i]
		return returned_dict

compound_lookup = {'BN':{'a':4.3300},
'BP':{'a':4.5380},
'BAs':{'a':4.7777},
'BSb':{'a':5.12},
'AlN':{'a':4.3300},
'AlP':{'a':5.4635},
'AlAs':{'a':5.6605},
'GaP':{'a':5.4505},
'GaAs':{'a':5.65325},
'GaSb':{'a':6.12},
'InN':{'a':3.533},
'InP':{'a':5.8687},
'InAs': {'a':6.0583},
'InSb': {'a':6.479}}
def fxn_setup(paramset,paramsetnum,typeIIIs,typeVs,dialations):
	''' Help:
	paramset    is a tuple of input data.
	paramsetnum is the number that it was accessed for processing in
	typeIII     is the first element of the binary pairing
	typeV       is the second element of the binary pairing
	dialations  is a list of dilation constants to test'''
	name = 'paramset%05d' % (paramsetnum)
	elements_to_process = set(typeIIIs).union(set(typeVs))
	paramset_dict = paramset.todict()
	# create pseudopotentials for tests
	for element in elements_to_process:
		L = pseudopotential.pseudopotential()
		L.create(element,s_cut= paramset_dict[element+'.s_cut'],p_cut = paramset_dict[element+'.p_cut'])
		L.run(filename=element+'_POTRE.DAT')

	objnames = []
	dialnames = []

	P = Parsec_Interface('doesnt matter not running in this script')
	if (len(typeIIIs) != len(typeVs)): print "Warning: Length of list of type III components differs from type V components\n\tContinuing...\n"
	for i in range(min(len(typeIIIs),len(typeVs))):
		objname = os.path.join(name,'obj'+typeIIIs[i]+typeVs[i])
		objnames.append(objname) 
		for dialconstant in dialations:
			dialname = os.path.join(objname,'dialation-%5.3f' % (dialconstant))
			dialnames.append(dialname)
			os.makedirs(dialname)

			# copy pseudopotentials in 
			shutil.copy(typeIIIs[i]+'_POTRE.DAT', os.path.join(dialname,typeIIIs[i]+'_POTRE.DAT'))
			shutil.copy(typeVs[i]+'_POTRE.DAT', os.path.join(dialname,typeVs[i]+'_POTRE.DAT'))

			# create parsec.in file for this case
			Compound = UnitCell(**{'structure':'zincblende','lattice_constants' : compound_lookup[typeIIIs[i]+typeVs[i]]})
			print "WARNING: hardcoded states num?"
			P.create_test(outname='und.in',gridspacing=.31, extraflags='# test test test\n', states_num=64, elements={typeIIIs[i] : { 'local_coordinate' : 's', 'Atom_Coords' : Compound.lattice_vectors[0:4] },typeVs[i] : {'local_coordinate' : 's' , 'Atom_Coords' : Compound.lattice_vectors[4:]}},cell_shape=Compound.primitive_vectors,lattice_vector_scale=Compound.lattice_vector_scale,dialation=dialconstant)
			shutil.copy('parsec.in', os.path.join(dialname,'parsec.in')) 
			
	return dialnames

if __name__ == '__main__':
	L = pseudopotential.pseudopotential()
	P = Parsec_Interface('/workspace/parsec-stampede.intel16-ifort-16.0.3.mpi')
	s_cut=2.5
	p_cut=2.5
	L.create('Ga',s_cut=s_cut,p_cut=p_cut,correlation='car',spinflag=' ')
	L.run(outname='Ga_POTRE.DAT')
	L.create('As',s_cut=s_cut,p_cut=p_cut,correlation='car',spinflag=' ')
	L.run(outname='As_POTRE.DAT')

	shutil.copy('GaAs_parsec.in','parsec.in')
	#for dia in [.9,.95,.975,1.0,1.025,1.05,1.1]:
	for dia in [1.0]:
		shutil.copy('Ga_POTRE.DAT','paramset00001/objGaAs/dialation-%05.3f/Ga_POTRE.DAT' % (dia))
		shutil.copy('As_POTRE.DAT','paramset00001/objGaAs/dialation-%05.3f/As_POTRE.DAT' % (dia))
		setup_parsec_in(dia)
		shutil.copy('parsec.in-0','paramset00001/objGaAs/dialation-%05.3f/parsec.in' % (dia))
		#P.run_test(path='mpirun -np 12 /workspace/parsec.mpi',cwd='paramset00001/objGaAs/dialation-%05.3f' % (dia))
		P.parse_output(parsecout='paramset00001/objGaAs/dialation-%05.3f/parsec.out' % (dia))


	#A = param_list((2,2,2,2,2,2,2,2),['Al.s_cut','Al.p_cut','Ga.s_cut','Ga.p_cut','P.s_cut','P.p_cut','As.s_cut','As.p_cut'])
#	listobaddirs = []
#	listobaddirs.extend(fxn_setup(A,1,['Al','Ga','Ga'],['As','P','As'],[.9,.95,.975,1.0,1.025,1.05,1.1]))
#	listobaddirs.extend(fxn_setup(A,1,['Al'],['P'],[.9,.95,.975,1.0,1.025,1.05,1.1]))
#	listobaddirs.extend(fxn_setup(A,2,['Al','Al','Ga','Ga'],['P','As','P','As'],[.9,.95,.975,1.0,1.025,1.05,1.1])),
#	for idir in listobaddirs: 
#		print idir
