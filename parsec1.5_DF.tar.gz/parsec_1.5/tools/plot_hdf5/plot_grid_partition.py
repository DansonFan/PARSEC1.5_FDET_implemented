#!/usr/bin/env python3

import glob
import re
import argparse


parser = argparse.ArgumentParser(description="Plot the grid points")
parser.add_argument('ifs_name', type=str, nargs=1,
        help='the filename of the input HDF5 file (e.g., hdf5_grid_partition.h5)')
parser.add_argument('ofs_name', type=str, nargs=1,
        help='the filename of the output figure (e.g., my_grid_partition.pdf)')

args = parser.parse_args()

import h5py
import numpy as np

import matplotlib.pyplot as plt

# This import registers the 3D projection, but is otherwise unused.
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 unused import

my_colors = ('orange', 'r', 'c', 'g', 'm', 'y', 'b', 'olive')
fig = plt.figure(figsize=(8,8), tight_layout=True)
ax = fig.gca(projection='3d')

f = h5py.File(args.ifs_name[0], 'r')

num_of_ranks_per_colgroup = f['parallel'].attrs['parallel%nprow'][0]
print("The number of the row processes={}".format(num_of_ranks_per_colgroup))

H_size = f['grid'].attrs['grid%ndim'][0]
print("The size of the Hamiltonian (full, without symmetry)={}".format(H_size))

# coords[grid_point][(fx,fy,fz,rank)]
coords = np.empty((H_size, 4), dtype=int)
#print(coords)

fx = f['grid/grid%fx(:)'][0]
fy = f['grid/grid%fy(:)'][0]
fz = f['grid/grid%fz(:)'][0]
colgroup_iam = f['parallel/colgroup_iam'][0]

for irow in range(H_size):
    coords[irow][0:4] = np.array([
        fx[irow],
        fy[irow],
        fz[irow],
        colgroup_iam[irow],
        ])

f.close()

fx_min = np.min(coords[:,0])
fy_min = np.min(coords[:,1])
fz_min = np.min(coords[:,2])
fx_max = np.max(coords[:,0])
fy_max = np.max(coords[:,1])
fz_max = np.max(coords[:,2])
print("Range of fx(:)={} to {}".format(fx_min, fx_max))
print("Range of fy(:)={} to {}".format(fy_min, fy_max))
print("Range of fz(:)={} to {}".format(fz_min, fz_max))

total_idx_x = fx_max - fx_min + 1
total_idx_y = fy_max - fy_min + 1
total_idx_z = fz_max - fz_min + 1

shift_x = fx_min
shift_y = fy_min
shift_z = fz_min

coords[:,0] = coords[:,0] - shift_x
coords[:,1] = coords[:,1] - shift_y
coords[:,2] = coords[:,2] - shift_z


voxels = np.full((total_idx_x, total_idx_y, total_idx_z), -1, dtype=int)

for coord in coords:
    voxels[coord[0]][coord[1]][coord[2]] = coord[3]

colors = np.empty(voxels.shape, dtype=object)
for rank in range(num_of_ranks_per_colgroup):
    colors[voxels == rank] = my_colors[rank]

ax.voxels((voxels != -1), facecolors=colors, edgecolor='k')

my_margin = 2
ax.set_xlim3d(0-my_margin, total_idx_x+my_margin)
ax.set_ylim3d(0-my_margin, total_idx_y+my_margin)
ax.set_zlim3d(0-my_margin, total_idx_z+my_margin)

plt.savefig(args.ofs_name[0], transparent=True)
plt.show()
