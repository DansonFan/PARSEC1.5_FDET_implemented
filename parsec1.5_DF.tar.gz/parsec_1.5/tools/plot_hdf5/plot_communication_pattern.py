#!/usr/bin/env python3

import re
import glob
import argparse




parser = argparse.ArgumentParser(description="Plot the communication pattern")
parser.add_argument('ifs_name', type=str, nargs=1,
        help='the filename of the input HDF5 file (e.g., hdf5_communication_pattern.h5)')
parser.add_argument('ofs_name', type=str, nargs=1,
        help='the filename of the output figure (e.g., my_communication_pattern.pdf)')

args = parser.parse_args()

import h5py
import seaborn as sns
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

plt.figure(figsize=(8,6), tight_layout=True)




f = h5py.File(args.ifs_name[0], 'r')
dset = f['elements_sent_from_to(:,:)']
comm_amount = dset[:,:]
f.close()
nprow = comm_amount.shape[0]

max_value = int(np.max(comm_amount))
for sender in range(nprow):
    for receiver in range(nprow):
        if comm_amount[sender][receiver] == max_value:
            # Note here that the x-y directions and
            # the matrix row-col directions are different
            plt.text(receiver+0.5, sender+0.5, str(max_value),
                    ha='center', va='center', color='w')

df = pd.DataFrame(comm_amount)

#colorbar_min = 0
#colorbar_max = 2400

my_ax = plt.gca()
sns.heatmap(df, cmap="Blues",
#        vmin=colorbar_min, vmax=colorbar_max,
        ax=my_ax,
        xticklabels=range(nprow),
        yticklabels=range(nprow))
plt.ylim(0, nprow)
#plt.title('Simple ($H_{\mathrm{size}}=$17,077)')
#plt.text(8.5, -0.5, '# elements')
plt.xlabel('Receiver')
plt.ylabel('Sender')





plt.savefig(args.ofs_name[0], transparent=True)
plt.show()
