#!/usr/bin/env python
global defaults
defaults='''   pg      Polonium        Guess 
        tm2
 n=Po c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     4.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00

   pg      Actinium        Guess 
        tm2
 n=Ac c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     0.00      0.00
   3.00     4.00     3.00      3.00

   pg      Silver  	  Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local
        tm2
 n=Ag c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.60     2.70     2.60                                              

   pg      Aluminium   From Kocinski (ionic)   Ecut ~ 20Ry   l=0,1,2 as local
        tm2
 n=Al c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     1.00      0.00
    3    2     0.00      0.00
   2.28     2.28     2.28     

   pg      Aluminium     Ecut ~ 16Ry   l=0,1,2 as local
        tm2
 n=Al c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     1.00      0.00
    3    2     0.00      0.00
   2.60     2.60     2.60     

   pg      Argon      (who cares?) 
        tm2
 n=Ar c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     6.00      0.00 
    3    2     0.00      0.00
   3.05     3.05     3.05          

   pg      Arsenic    Guess   Ecut ~ 20Ry   l=2 (maybe 0,1) as local
        tm2
 n=As c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     3.00      0.00 
    4    2     0.00      0.00
   2.10     2.10     2.10                                             

   pg      Hydrogen  (try also Coulomb) Ecut ~ 36Ry local
        tm2
 n=H  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    0    1 
    1    0     1.00      0.00
   0.15                           
   pg      Helium   (Who cares?)  Ecut ~ 49Ry local
        tm2
 n=He c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    0    1 
    1    0     2.00      0.00
   0.15                           
   pg      Lithium      Guess   Ecut ~ 12Ry   l=0 as local
        tm2
 n=Li c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     1.00      0.00
    2    1     0.00      0.00
   2.45     2.45                  
   pg      Beryllium   PRB 51 13653 (1995)   Ecut ~ 20Ry  l=0 as local
        tm2
 n=Be c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     0.00      0.00
   2.10     2.10                  
   pg      Boron     Guess    Ecut ~ 36Ry  l=0 as local
        tm2
 n=B  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     1.00      0.00
   1.40     1.40                  
   pg      Boron     Hard Guess    Ecut ~ 49Ry  l=0 as local
        tm2
 n=B  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     1.00      0.00
   1.20     1.20                  
   pg      Carbon  PRB 43 1993 (1991)  Ecut ~ 49Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.50     1.54                  
   pg      Carbon   (For aromatics from Peter Schuster) Ecut ~ 55 Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.30     1.30                  
   pg      Carbon   Hard guess for triple bonds  Ecut ~ 64 Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.10     1.10                  
   pg      Nitrogen   From Piotr Kocinski Ecut ~ 64Ry  l=0 as local
        tm2
 n=N  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     3.00      0.00
   1.50     1.50                  
   pg      Nitrogen   Hard Guess for triple bonds   Ecut= 81Ry  l=0 as local
        tm2
 n=N  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     3.00      0.00
   1.00     1.00                  
   pg      Oxygen  PRB 43 1993 (1991)  Ecut ~ 64Ry  l=0 as local
        tm2
 n=O  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     4.00      0.00
   1.45     1.45                  
   pg      Oxygen    Hard guess for O2   Ecut ~ 81Ry  l=0 as local
        tm2
 n=O  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     4.00      0.00
   1.10     1.10                  
   pg      Fluorine    Guess   Ecut ~ 81Ry  l=0 as local
        tm2
 n=F  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     5.00      0.00
   1.30     1.30                  
   pg      Neon     (who cares)   Ecut ~ 36Ry  l=0 as local
        tm2
 n=Ne c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     6.00      0.00
   2.55     2.55                           
   pe      Sodium    Guess for metalic   Ecut ~ 9Ry   l=1 as local
        tm2
 n=Na c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    2 
    3    0     1.00      0.00
    3    1     0.00      0.00
   2.80     2.80                  
   pe      Sodium    PRB 54 2937 (1996) for ionic   Ecut ~ 16Ry   l=1 as local
        tm2
 n=Na c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    2 
    3    0     1.00      0.00
    3    1     0.00      0.00
   2.30     2.50                  
   pg      Magnesium   PRB 50 10358 (1994)   Ecut ~ 9Ry    l=0,1,2 as local
        tm2
 n=Mg c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     0.00      0.00
    3    2     0.00      0.00
   3.05     3.05     3.05         
   pe      Magnesium    Tested for oxides   Ecut ~ 12Ry   l=1,2 as local
        tm2
 n=Mg c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     0.00      0.00
    3    2     0.00      0.00
   2.80     2.80     2.80         
   pg      Aluminium     Ecut ~ 16Ry   l=0,1,2 as local
        tm2
 n=Al c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     1.00      0.00
    3    2     0.00      0.00
   2.60     2.60     2.60     
   pg      Aluminium   From Kocinski (ionic)   Ecut ~ 20Ry   l=0,1,2 as local
        tm2
 n=Al c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     1.00      0.00
    3    2     0.00      0.00
   2.28     2.28     2.28     
   pg      Silicon   PRB 52 13281 (1995)   Ecut ~ 16Ry    l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   2.50     2.50     2.50          
   pg      Silicon   Guess  Hard    Ecut ~ 20Ry    l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   2.00     2.00     2.00          
   pg      Silicon   PRB 44 489 (1991)  ionic    Ecut ~ 25Ry   l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   1.80     1.80     1.80          
   pg      Phosphorus      Guess   Ecut ~ 20Ry    l=0,1,2 as local
        tm2
 n=P  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     3.00      0.00 
    3    2     0.00      0.00
   1.95     1.95     1.95             
   pg      Sulfur       Guess   Ecut ~ 25Ry    l=0,1,2 as local
        tm2
 n=S  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     4.00      0.00 
    3    2     0.00      0.00
   1.70     1.70     1.70          
   pg      Clorine      Guess     Ecut ~ 25Ry    l=0,1,2 as local
        tm2
 n=Cl c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     5.00      0.00 
    3    2     0.00      0.00
   1.75     1.75     1.75          
   pg      Argon      (who cares?) 
        tm2
 n=Ar c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     6.00      0.00 
    3    2     0.00      0.00
   3.05     3.05     3.05          
   pe      Potassium     PRB 47 16101 (1993)  Ecut ~ 9 Ry    l=0 as local    
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2     0.00      0.00 
   3.51     3.76     3.76                                                  
   pe      Potassium     PRB 46 1766 (1992)   Ecut ~ 9 Ry     l=0 as local
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    2 
    4    0     1.00      0.00
    4    1     0.00      0.00 
   3.66     3.80                  
   pe      Potassium     Guess for metallic     Ecut ~ 9 Ry     l=0 as local
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    2 
    4    0     1.00      0.00
    4    1     0.00      0.00 
   3.60     3.60                             
   pe      Calcium       Guess      Ecut ~ 25 Ry     l=0 as local  (For high pressures include 3s and 3p in valence)
        tm2
 n=Ca c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     0.00      0.00
   3.30     3.30     3.30         
   pg      Scandium  	Guess      Ecut ~ 36 Ry     l=0 as local 
        tm2
 n=Sc c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     1.00      0.00
   2.80     2.80     2.80           
   pg      Titanium   PRB 46 1285 (1992)    Ecut ~ 36 Ry     l=0 as local
        tm2
 n=Ti c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3
    4    0     2.00      0.00
    4    1     0.00      0.00
    3    2     2.00      0.00
   2.54     2.96     2.25
   pe      Titanium   template for pccec    Ecut ~ 36 Ry     l=0 as local
        tm2
 n=Ti c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3
    4    0     2.00      0.00
    4    1     0.00      0.00
    3    2     2.00      0.00
   2.54      2.96      2.25      2.25      2.25      1.00      1.25
   pg      Vanadium  	  Guess    Ecut ~ 49 Ry     l=0 as local
        tm2
 n=V  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     3.00      0.00
   2.35     2.70     2.35         
   pg      Chromium      Guess	  Ecut ~ 49 Ry     l=0 as local
        tm2
 n=Cr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2     5.00      0.00
   2.25     2.55     2.25         
   pg      Manganese      Guess     Ecut ~ 55 Ry     l=0 as local                   
        tm2
 n=Mn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     5.00      0.00
   2.35     2.60     2.35                                 
   pg      Iron      Guess     Ecut ~ 55 Ry     l=0 as local                            
        tm2
 n=Fe c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     6.00      0.00
   2.20     2.40     2.20                                      
   pg      Cobalt       Guess     Ecut ~ 64 Ry     l=0 as local                   
        tm2
 n=Co c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     7.00      0.00
   2.20     2.35     2.20                                       
   pg      Nickel      Guess     Ecut ~ 64 Ry     l=0 as local                 
        tm2
 n=Ni c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     8.00      0.00
   2.20     2.30     2.20                                             
   pg      Copper  PRB 43 1993 (1991)  Ecut ~ 75Ry   l=0 as local
        tm2
 n=Cu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.08     2.30     2.08                                    
   pg      Copper    Guess    Ecut ~ 75Ry   l=0 as local
        tm2
 n=Cu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.25     2.25     2.25                                                   
   pg      Zinc     Guess    Ecut ~ 75Ry   l=0 as local
        tm2
 n=Zn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.30     2.30     2.30                                                        
   pe      Gallium   (d in the core...)  Guess	  Ecut ~ 81Ry   l=0 (maybe 1) as local
        tm2
 n=Ga c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     1.00      0.00 
    4    2     0.00      0.00
   2.05     2.45     2.05                                                          
   pg      Gallium   From Kocinski   Ecut ~ 81Ry   l=0 (maybe 1) as local
        tm2
 n=Ga c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     1.00      0.00 
    3    2    10.00      0.00
   2.10     2.10     2.10                                                
   pe      Germanium     PRB 52 13283 (1995)    Ecut ~ 16Ry   l=0,1 (maybe 2) as local  
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.68     2.68     2.68                                                     
   pe      Germanium     ZPD 40 182 (1997)    Ecut ~ 16Ry   l=1  as local
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.50     2.50     3.00                                             
   pe      Germanium    Hard  Guess   Ecut ~ 20Ry   l=1 (maybe 0) as local
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.10     2.10     2.10                                                    
   pg      Arsenic    Guess   Ecut ~ 20Ry   l=2 (maybe 0,1) as local
        tm2
 n=As c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     3.00      0.00 
    4    2     0.00      0.00
   2.10     2.10     2.10                                             
   pg      Selenium  	Guess   Ecut ~ 25Ry   l=2 (maybe 1) as local 
        tm2
 n=Se c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     4.00      0.00 
    4    2     0.00      0.00
   1.90     1.90     1.90                                                    
   pg      Bromine      Guess	 Ecut ~ 25Ry   l=2 (maybe 1) as local    
        tm2
 n=Br c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     5.00      0.00 
    4    2     0.00      0.00
   1.95     1.95     1.95                                                         
   pg      Krypton       Guess (who cares)
        tm2
 n=Kr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     6.00      0.00 
    4    2     0.00      0.00
   3.25     3.25     3.25                                                   
   pe      Rubidium   PRB 47 16101 (1993)   Ecut ~ 16Ry   l=0  as local
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     0.00      0.00
   3.82     3.82     3.72                  
   pe      Rubidium   PRB 51 872 (1995)    Ecut ~ 9Ry   l=0  (maybe l=1)  as local
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    2 
    5    0     1.00      0.00
    5    1     0.00      0.00 
   4.10     4.40                                                                                   
   pe      Rubidium   Guess   Ecut ~ 9Ry   l=0 as local     
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    2 
    5    0     1.00      0.00
    5    1     0.00      0.00 
   3.90     4.10                                                                                                      
   pe      Strontium     Guess   Ecut ~ 16Ry   l=0 as local 
        tm2
 n=Sr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     0.00      0.00
   3.60     3.80     3.60                                        
   pe      Yttrium    PRB 44 10339 (1991)  Ecut ~ 25Ry   l=0 (maybe l=1) as local 
        tm2
 n=Y  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     1.00      0.00
   3.05     3.45     2.50                                          
   pg      Yttrium   Guess   Ecut ~ 20Ry   l=0 as local 
        tm2
 n=Y  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     1.00      0.00
   3.20     3.40     3.20                                          
   pg      Zirconium  	  Guess   Ecut ~ 25Ry   l=0 as local
        tm2
 n=Zr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     2.00      0.00
   2.85     3.05     2.85                                               
   pg      Niobium     PRB 48 16987 (1993)   Ecut ~ 30Ry   l=0 (maybe l=1) as local
        tm2
 n=Nb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     4.00      0.00
   2.49     3.19     2.25                                                
   pg      Niobium   Guess   Ecut ~ 30Ry   l=0 as local 
        tm2
 n=Nb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     4.00      0.00
   2.55     2.75     2.55                                                
   pg      Molybdenum      Guess   Ecut ~ 36Ry   l=0 as local
        tm2
 n=Mo c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     5.00      0.00
   2.45     2.65     2.45                                         
   pg      Technetium     Guess  (Who cares)
        tm2
 n=Tc c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     5.00      0.00
   2.40     2.60     2.40                                      
   pg      Ruthenium    PRB 47 1732 (1993)   Ecut ~ 30Ry   l=0 (maybe l=1) as local
        tm2
 n=Ru c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     7.00      0.00
   2.70     2.70     2.70                                           
   pg      Ruthenium   Guess    Ecut ~ 36Ry   l=0 as local     
        tm2
 n=Ru c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     7.00      0.00
   2.40     2.60     2.40                                           
   pg      Rhodium  	 Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local   
        tm2
 n=Rh c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     8.00      0.00
   2.40     2.60     2.40                                       
   pg      Palladium      Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local
        tm2
 n=Pd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     0.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.45     2.60     2.45                                            
   pg      Silver  	  Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local
        tm2
 n=Ag c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.60     2.70     2.60                                              
   pg      Cadmium  	  Guess (check with 4d in core)   Ecut ~ 36Ry   l=0,1 as local
        tm2
 n=Cd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.65     2.65     2.65                                             
   pg      Indium  	Guess   Ecut ~ 20Ry   l=0,1 as local
        tm2
 n=In c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     1.00      0.00 
    5    2     0.00      0.00
   2.90     2.90     2.90                                        
   pg      Tin  	 Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=Sn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3 
    5    0     2.00      0.00
    5    1     2.00      0.00 
    5    2     0.00      0.00
   2.50     2.50     2.50                                            
   pg      Antimony  	    Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=Sb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3 
    5    0     2.00      0.00
    5    1     3.00      0.00 
    5    2     0.00      0.00
   2.60     2.60     2.60                                          
   pe      Tellurium    ZPD 40 182 (1997)   Ecut ~ 20Ry   l=0,1 as local  
        tm2
 n=Te c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     4.00      0.00 
    5    2     0.00      0.00
   2.80     2.80     2.80                                          
   pg      Tellurium    Guess   Ecut ~ 25Ry   l=0,1 as local 
        tm2
 n=Te c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     4.00      0.00 
    5    2     0.00      0.00
   2.60     2.60     2.60                                          
   pg      Iodine  	 Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=I  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     5.00      0.00 
    5    2     0.00      0.00
   2.40     2.40     2.40                                   
   pg      Xenon  	 Guess     (who cares)
        tm2
 n=Xe c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     6.00      0.00 
    5    2     0.00      0.00
   3.50     3.50     3.50                                       
   pe      Cesium  PRB 47 16101 (1993)  Check 5sp in valence  Ecut ~ 9Ry   l=0 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
   3.73     4.23     4.23                  
   pe      Cesium  PRB 51 872 (1995)     Ecut ~ 9Ry   l=0,1 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    2 
    6    0     1.00      0.00
    6    1     0.00      0.00 
   4.40     5.00                                                      
   pe      Cesium   Guess for metallic    Ecut ~ 9Ry   l=0 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    2 
    6    0     1.00      0.00
    6    1     0.00      0.00 
   4.40     4.60                                                              
   pe      Barium      Guess    Ecut ~ 16Ry   l=0 as local
        tm2
 n=Ba c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
   3.90     4.10     3.90          
   pe      Lanthanum         Guess    Ecut ~ 40Ry   l=0 as local        
        tm2
 n=La c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     0.00      0.00
   3.50     4.10     3.50     3.50
   pe      Cerium  PRB 43 1993 (1991)  Ecut = 55Ry  
        tm2
 n=Ce c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     1.00      0.00
   3.50     4.10     3.00     3.00
   pe      Cerium         Guess 
        tm2
 n=Ce c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     1.00      0.00
   3.25     3.75     3.25     3.25
   pe      Praseodymium          Guess  
        tm2
 n=Pr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     3.00      0.00
   3.25     3.75     3.25     3.25
   pe      Neodymium  	          Guess  
        tm2
 n=Nd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     4.00      0.00
   3.25     3.75     3.25     3.25
   pe      Promethium          Guess (who cares)  
        tm2
 n=Pm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     5.00      0.00
   3.25     3.65     3.25     3.25
   pe      Samarium          Guess  
        tm2
 n=Sm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     6.00      0.00
   3.25     3.65     3.25     3.25
   pe      Europium           Guess  
        tm2
 n=Eu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     7.00      0.00
   3.25     3.65     3.25     3.25
   pe      Gadolinium            Guess  
        tm2
 n=Gd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     7.00      0.00
   3.25     3.65     3.25     3.25
   pe      Terbium          Guess  
        tm2
 n=Tb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     9.00      0.00
   3.20     3.60     3.20     3.20
   pe      Dysprosium          Guess  
        tm2
 n=Dy c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    10.00      0.00
   3.20     3.60     3.20     3.20
   pe      Holmium          Guess  
        tm2
 n=Ho c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    11.00      0.00
   3.20     3.60     3.20     3.20
   pe      Erbium             Guess  
        tm2
 n=Er c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    12.00      0.00
   3.15     3.50     3.15     3.15
   pe      Thullium         Guess  
        tm2
 n=Tm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    13.00      0.00
   3.15     3.50     3.15     3.15
   pe      Ytterbium         Guess  
        tm2
 n=Yb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    14.00      0.00
   3.15     3.50     3.15     3.15
   pe      Lutetium           Guess  
        tm2
 n=Lu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00 
    4    3    14.00      0.00
   3.10     3.40     3.10     3.10
   pg      Lutetium           Guess  
        tm2
 n=Lu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00 
   3.10     3.40     3.10            
   pg      Hafnium          Guess   (try 4f in valence)
        tm2
 n=Hf c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     2.00      0.00 
   2.80     2.80     2.80           
   pg      Tantalum           Guess  
        tm2
 n=Ta c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     3.00      0.00 
   2.55     2.55     2.55          
   pg      Tungsten           Guess  
        tm2
 n=W  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     4.00      0.00 
   2.45     2.45     2.45          
   pg      Rhenium           Guess  
        tm2
 n=Re c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     5.00      0.00 
   2.45     2.45     2.45         
   pg      Osmium           Guess  
        tm2
 n=Os c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     6.00      0.00 
   2.40     2.40     2.40          
   pg      Iridium           Guess  
        tm2
 n=Ir c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     7.00      0.00 
   2.45     2.45     2.45          
   pg      Platinum        Guess   
        tm2
 n=Pt c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2     9.00      0.00 
   2.45     2.45     2.45          
   pg      Gold           Guess  
        tm2
 n=Au c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2    10.00      0.00 
   2.60     2.60     2.60          
   pg      Mercury         Guess 
        tm2
 n=Hg c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2    10.00      0.00 
   2.70     2.70     2.70         
   pg      Thallium        Guess 
        tm2
 n=Tl c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    3 
    6    0     2.00      0.00
    6    1     1.00      0.00 
    6    2     0.00      0.00 
   3.00     3.00     3.00           
   pe      Lead   PRB 54 2937 (1996) 
        tm2
 n=Pb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    2 
    6    0     2.00      0.00
    6    1     2.00      0.00 
   3.18     3.18                   
   pg      Lead            Guess 
        tm2
 n=Pb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    2 
    6    0     2.00      0.00
    6    1     2.00      0.00 
   3.15     3.15                   
   pg      Bismuth         Guess 
        tm2
 n=Bi c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     3.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   2.70     2.70     2.70      2.70
   pg      Polonium        Guess 
        tm2
 n=Po c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     4.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00
   pg      Astatine      Guess                           
        tm2
 n=At c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     5.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00                          
   pg      Radon          (who cares)                        
        tm2
 n=Rn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     6.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00
   pg      Francium  	   (who cares) 
        tm2
 n=Fr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    2 
    7    0     1.00      0.00
    7    1     0.00      0.00 
   5.00     5.00                       
   pg      Radium         Guess 
        tm2
 n=Ra c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    2 
    7    0     2.00      0.00
    7    1     0.00      0.00 
   4.50     4.50                   
   pg      Actinium        Guess 
        tm2
 n=Ac c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     0.00      0.00
   3.00     4.00     3.00      3.00
   pg      Thorium         Guess 
        tm2
 n=Th c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     1.00      0.00
   3.00     4.00     3.00      3.00
   pg      Protactinium        Guess 
        tm2
 n=Pa c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     2.00      0.00
   3.00     4.00     3.00      3.00
   pg      Uranium          Guess 
        tm2
 n=U  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     1.00      0.00
    5    3     3.00      0.00
   3.00     4.00     3.00      3.00
   pg      Neptunium        Guess 
        tm2
 n=Np c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     0.00      0.00
    5    3     5.00      0.00
   3.00     4.00     3.00      3.00
   pg      Plutonium        Guess 
        tm2
 n=Pu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     0.00      0.00
    5    3     6.00      0.00
   3.00     4.00     3.00      3.00

   pg      Astatine      Guess                           
        tm2
 n=At c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     5.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00                          

   pg      Gold           Guess  
        tm2
 n=Au c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2    10.00      0.00 
   2.60     2.60     2.60          

   pg      Boron     Hard Guess    Ecut ~ 49Ry  l=0 as local
        tm2
 n=B  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     1.00      0.00
   1.20     1.20                  

   pe      Barium      Guess    Ecut ~ 16Ry   l=0 as local
        tm2
 n=Ba c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
   3.90     4.10     3.90          

   pg      Beryllium   PRB 51 13653 (1995)   Ecut ~ 20Ry  l=0 as local
        tm2
 n=Be c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     0.00      0.00
   2.10     2.10                  

   pg      Bismuth         Guess 
        tm2
 n=Bi c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     3.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   2.70     2.70     2.70      2.70

   pg      Boron     Guess    Ecut ~ 36Ry  l=0 as local
        tm2
 n=B  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     1.00      0.00
   1.40     1.40                  

   pg      Bromine      Guess	 Ecut ~ 25Ry   l=2 (maybe 1) as local    
        tm2
 n=Br c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     5.00      0.00 
    4    2     0.00      0.00
   1.95     1.95     1.95                                                         

   pg      Carbon   (For aromatics from Peter Schuster) Ecut ~ 55 Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.30     1.30                  

   pg      Carbon   Hard guess for triple bonds  Ecut ~ 64 Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.10     1.10                  

   pe      Calcium       Guess      Ecut ~ 25 Ry     l=0 as local  (For high pressures include 3s and 3p in valence)
        tm2
 n=Ca c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     0.00      0.00
   3.30     3.30     3.30         

   pg      Cadmium  	  Guess (check with 4d in core)   Ecut ~ 36Ry   l=0,1 as local
        tm2
 n=Cd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.65     2.65     2.65                                             

   pe      Cerium         Guess 
        tm2
 n=Ce c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     1.00      0.00
   3.25     3.75     3.25     3.25

   pe      Cerium  PRB 43 1993 (1991)  Ecut = 55Ry  
        tm2
 n=Ce c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     1.00      0.00
   3.50     4.10     3.00     3.00

   pg      Clorine      Guess     Ecut ~ 25Ry    l=0,1,2 as local
        tm2
 n=Cl c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     5.00      0.00 
    3    2     0.00      0.00
   1.75     1.75     1.75          

   pg      Cobalt       Guess     Ecut ~ 64 Ry     l=0 as local                   
        tm2
 n=Co c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     7.00      0.00
   2.20     2.35     2.20                                       

   pg      Carbon  PRB 43 1993 (1991)  Ecut ~ 49Ry  l=0 as local
        tm2
 n=C  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     2.00      0.00
   1.50     1.54                  

   pg      Chromium      Guess	  Ecut ~ 49 Ry     l=0 as local
        tm2
 n=Cr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2     5.00      0.00
   2.25     2.55     2.25         

   pe      Cesium  PRB 51 872 (1995)     Ecut ~ 9Ry   l=0,1 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    2 
    6    0     1.00      0.00
    6    1     0.00      0.00 
   4.40     5.00                                                      

   pe      Cesium   Guess for metallic    Ecut ~ 9Ry   l=0 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    2 
    6    0     1.00      0.00
    6    1     0.00      0.00 
   4.40     4.60                                                              

   pe      Cesium  PRB 47 16101 (1993)  Check 5sp in valence  Ecut ~ 9Ry   l=0 as local
        tm2
 n=Cs c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
   3.73     4.23     4.23                  

   pg      Copper    Guess    Ecut ~ 75Ry   l=0 as local
        tm2
 n=Cu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.25     2.25     2.25                                                   

   pg      Copper  PRB 43 1993 (1991)  Ecut ~ 75Ry   l=0 as local
        tm2
 n=Cu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.08     2.30     2.08                                    

   pe      Dysprosium          Guess  
        tm2
 n=Dy c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    10.00      0.00
   3.20     3.60     3.20     3.20

   pe      Erbium             Guess  
        tm2
 n=Er c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    12.00      0.00
   3.15     3.50     3.15     3.15

   pe      Europium           Guess  
        tm2
 n=Eu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     7.00      0.00
   3.25     3.65     3.25     3.25

   pg      Iron      Guess     Ecut ~ 55 Ry     l=0 as local                            
        tm2
 n=Fe c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     6.00      0.00
   2.20     2.40     2.20                                      

   pg      Fluorine    Guess   Ecut ~ 81Ry  l=0 as local
        tm2
 n=F  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     5.00      0.00
   1.30     1.30                  

   pg      Francium  	   (who cares) 
        tm2
 n=Fr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    2 
    7    0     1.00      0.00
    7    1     0.00      0.00 
   5.00     5.00                       

   pg      Gallium   From Kocinski   Ecut ~ 81Ry   l=0 (maybe 1) as local
        tm2
 n=Ga c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     1.00      0.00 
    3    2    10.00      0.00
   2.10     2.10     2.10                                                

   pe      Gallium   (d in the core...)  Guess	  Ecut ~ 81Ry   l=0 (maybe 1) as local
        tm2
 n=Ga c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     1.00      0.00 
    4    2     0.00      0.00
   2.05     2.45     2.05                                                          

   pe      Gadolinium            Guess  
        tm2
 n=Gd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     7.00      0.00
   3.25     3.65     3.25     3.25

   pe      Germanium     ZPD 40 182 (1997)    Ecut ~ 16Ry   l=1  as local
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.50     2.50     3.00                                             

   pe      Germanium    Hard  Guess   Ecut ~ 20Ry   l=1 (maybe 0) as local
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.10     2.10     2.10                                                    

   pe      Germanium     PRB 52 13283 (1995)    Ecut ~ 16Ry   l=0,1 (maybe 2) as local  
        tm2
 n=Ge c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     2.00      0.00 
    4    2     0.00      0.00
   2.68     2.68     2.68                                                     

   pg      Helium   (Who cares?)  Ecut ~ 49Ry local
        tm2
 n=He c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    0    1 
    1    0     2.00      0.00
   0.15                           

   pg      Hafnium          Guess   (try 4f in valence)
        tm2
 n=Hf c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     2.00      0.00 
   2.80     2.80     2.80           

   pg      Mercury         Guess 
        tm2
 n=Hg c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2    10.00      0.00 
   2.70     2.70     2.70         

   pe      Holmium          Guess  
        tm2
 n=Ho c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    11.00      0.00
   3.20     3.60     3.20     3.20

   pg      Hydrogen  (try also Coulomb) Ecut ~ 36Ry local
        tm2
 n=H  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    0    1 
    1    0     1.00      0.00
   0.15                           

   pg      Indium  	Guess   Ecut ~ 20Ry   l=0,1 as local
        tm2
 n=In c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     1.00      0.00 
    5    2     0.00      0.00
   2.90     2.90     2.90                                        

   pg      Iodine  	 Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=I  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     5.00      0.00 
    5    2     0.00      0.00
   2.40     2.40     2.40                                   

   pg      Iridium           Guess  
        tm2
 n=Ir c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     7.00      0.00 
   2.45     2.45     2.45          

   pe      Potassium     PRB 46 1766 (1992)   Ecut ~ 9 Ry     l=0 as local
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    2 
    4    0     1.00      0.00
    4    1     0.00      0.00 
   3.66     3.80                  

   pe      Potassium     Guess for metallic     Ecut ~ 9 Ry     l=0 as local
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    2 
    4    0     1.00      0.00
    4    1     0.00      0.00 
   3.60     3.60                             

   pe      Potassium     PRB 47 16101 (1993)  Ecut ~ 9 Ry    l=0 as local    
        tm2
 n=K  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     1.00      0.00
    4    1     0.00      0.00 
    3    2     0.00      0.00 
   3.51     3.76     3.76                                                  

   pg      Krypton       Guess (who cares)
        tm2
 n=Kr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     6.00      0.00 
    4    2     0.00      0.00
   3.25     3.25     3.25                                                   

   pe      Lanthanum         Guess    Ecut ~ 40Ry   l=0 as local        
        tm2
 n=La c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00
    4    3     0.00      0.00
   3.50     4.10     3.50     3.50

   pg      Lithium      Guess   Ecut ~ 12Ry   l=0 as local
        tm2
 n=Li c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     1.00      0.00
    2    1     0.00      0.00
   2.45     2.45                  

   pg      Lutetium           Guess  
        tm2
 n=Lu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00 
   3.10     3.40     3.10            

   pe      Lutetium           Guess  
        tm2
 n=Lu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     1.00      0.00 
    4    3    14.00      0.00
   3.10     3.40     3.10     3.10

   pe      Magnesium    Tested for oxides   Ecut ~ 12Ry   l=1,2 as local
        tm2
 n=Mg c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     0.00      0.00
    3    2     0.00      0.00
   2.80     2.80     2.80         

   pg      Magnesium   PRB 50 10358 (1994)   Ecut ~ 9Ry    l=0,1,2 as local
        tm2
 n=Mg c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     0.00      0.00
    3    2     0.00      0.00
   3.05     3.05     3.05         

   pg      Manganese      Guess     Ecut ~ 55 Ry     l=0 as local                   
        tm2
 n=Mn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     5.00      0.00
   2.35     2.60     2.35                                 

   pg      Molybdenum      Guess   Ecut ~ 36Ry   l=0 as local
        tm2
 n=Mo c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     5.00      0.00
   2.45     2.65     2.45                                         

   pg      Nitrogen   Hard Guess for triple bonds   Ecut= 81Ry  l=0 as local
        tm2
 n=N  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     3.00      0.00
   1.00     1.00                  

   pe      Sodium    PRB 54 2937 (1996) for ionic   Ecut ~ 16Ry   l=1 as local
        tm2
 n=Na c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    2 
    3    0     1.00      0.00
    3    1     0.00      0.00
   2.30     2.50                  

   pe      Sodium    Guess for metalic   Ecut ~ 9Ry   l=1 as local
        tm2
 n=Na c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    2 
    3    0     1.00      0.00
    3    1     0.00      0.00
   2.80     2.80                  

   pg      Niobium   Guess   Ecut ~ 30Ry   l=0 as local 
        tm2
 n=Nb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     4.00      0.00
   2.55     2.75     2.55                                                

   pg      Niobium     PRB 48 16987 (1993)   Ecut ~ 30Ry   l=0 (maybe l=1) as local
        tm2
 n=Nb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     4.00      0.00
   2.49     3.19     2.25                                                

   pe      Neodymium  	          Guess  
        tm2
 n=Nd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     4.00      0.00
   3.25     3.75     3.25     3.25

   pg      Neon     (who cares)   Ecut ~ 36Ry  l=0 as local
        tm2
 n=Ne c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     6.00      0.00
   2.55     2.55                           

   pg      Nickel      Guess     Ecut ~ 64 Ry     l=0 as local                 
        tm2
 n=Ni c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     8.00      0.00
   2.20     2.30     2.20                                             

   pg      Neptunium        Guess 
        tm2
 n=Np c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     0.00      0.00
    5    3     5.00      0.00
   3.00     4.00     3.00      3.00

   pg      Nitrogen   From Piotr Kocinski Ecut ~ 64Ry  l=0 as local
        tm2
 n=N  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     3.00      0.00
   1.50     1.50                  

   pg      Oxygen    Hard guess for O2   Ecut ~ 81Ry  l=0 as local
        tm2
 n=O  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     4.00      0.00
   1.10     1.10                  

   pg      Oxygen  PRB 43 1993 (1991)  Ecut ~ 64Ry  l=0 as local
        tm2
 n=O  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    1    2 
    2    0     2.00      0.00
    2    1     4.00      0.00
   1.45     1.45                  

   pg      Osmium           Guess  
        tm2
 n=Os c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     6.00      0.00 
   2.40     2.40     2.40          

   pg      Protactinium        Guess 
        tm2
 n=Pa c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     2.00      0.00
   3.00     4.00     3.00      3.00

   pg      Lead            Guess 
        tm2
 n=Pb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    2 
    6    0     2.00      0.00
    6    1     2.00      0.00 
   3.15     3.15                   

   pe      Lead   PRB 54 2937 (1996) 
        tm2
 n=Pb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    2 
    6    0     2.00      0.00
    6    1     2.00      0.00 
   3.18     3.18                   

   pg      Palladium      Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local
        tm2
 n=Pd c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     0.00      0.00
    5    1     0.00      0.00 
    4    2    10.00      0.00
   2.45     2.60     2.45                                            

   pe      Promethium          Guess (who cares)  
        tm2
 n=Pm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     5.00      0.00
   3.25     3.65     3.25     3.25

   pg      Polonium        Guess 
        tm2
 n=Po c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     4.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00

   pg      Phosphorus      Guess   Ecut ~ 20Ry    l=0,1,2 as local
        tm2
 n=P  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     3.00      0.00 
    3    2     0.00      0.00
   1.95     1.95     1.95             

   pe      Praseodymium          Guess  
        tm2
 n=Pr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     3.00      0.00
   3.25     3.75     3.25     3.25

   pg      Platinum        Guess   
        tm2
 n=Pt c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     1.00      0.00
    6    1     0.00      0.00 
    5    2     9.00      0.00 
   2.45     2.45     2.45          

   pg      Plutonium        Guess 
        tm2
 n=Pu c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     0.00      0.00
    5    3     6.00      0.00
   3.00     4.00     3.00      3.00

   pg      Radium         Guess 
        tm2
 n=Ra c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    2 
    7    0     2.00      0.00
    7    1     0.00      0.00 
   4.50     4.50                   

   pe      Rubidium   PRB 51 872 (1995)    Ecut ~ 9Ry   l=0  (maybe l=1)  as local
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    2 
    5    0     1.00      0.00
    5    1     0.00      0.00 
   4.10     4.40                                                                                   

   pe      Rubidium   Guess   Ecut ~ 9Ry   l=0 as local     
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    2 
    5    0     1.00      0.00
    5    1     0.00      0.00 
   3.90     4.10                                                                                                      

   pe      Rubidium   PRB 47 16101 (1993)   Ecut ~ 16Ry   l=0  as local
        tm2
 n=Rb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     0.00      0.00
   3.82     3.82     3.72                  

   pg      Rhenium           Guess  
        tm2
 n=Re c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     5.00      0.00 
   2.45     2.45     2.45         

   pg      Rhodium  	 Guess   Ecut ~ 36Ry   l=0 (maybe l=1) as local   
        tm2
 n=Rh c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     8.00      0.00
   2.40     2.60     2.40                                       

   pg      Radon          (who cares)                        
        tm2
 n=Rn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    4 
    6    0     2.00      0.00
    6    1     6.00      0.00 
    6    2     0.00      0.00 
    5    3     0.00      0.00
   3.00     3.00     3.00      3.00

   pg      Ruthenium   Guess    Ecut ~ 36Ry   l=0 as local     
        tm2
 n=Ru c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     7.00      0.00
   2.40     2.60     2.40                                           

   pg      Ruthenium    PRB 47 1732 (1993)   Ecut ~ 30Ry   l=0 (maybe l=1) as local
        tm2
 n=Ru c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     1.00      0.00
    5    1     0.00      0.00 
    4    2     7.00      0.00
   2.70     2.70     2.70                                           

   pg      Antimony  	    Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=Sb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3 
    5    0     2.00      0.00
    5    1     3.00      0.00 
    5    2     0.00      0.00
   2.60     2.60     2.60                                          

   pg      Scandium  	Guess      Ecut ~ 36 Ry     l=0 as local 
        tm2
 n=Sc c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     1.00      0.00
   2.80     2.80     2.80           

   pg      Selenium  	Guess   Ecut ~ 25Ry   l=2 (maybe 1) as local 
        tm2
 n=Se c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    6    3 
    4    0     2.00      0.00
    4    1     4.00      0.00 
    4    2     0.00      0.00
   1.90     1.90     1.90                                                    

   pg      Silicon   Guess  Hard    Ecut ~ 20Ry    l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   2.00     2.00     2.00          

   pg      Silicon   PRB 44 489 (1991)  ionic    Ecut ~ 25Ry   l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   1.80     1.80     1.80          

   pg      Silicon   PRB 52 13281 (1995)   Ecut ~ 16Ry    l=0,1,2 as local
        tm2
 n=Si c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     2.00      0.00 
    3    2     0.00      0.00
   2.50     2.50     2.50          

   pe      Samarium          Guess  
        tm2
 n=Sm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     6.00      0.00
   3.25     3.65     3.25     3.25

   pg      Tin  	 Guess   Ecut ~ 25Ry   l=0,1 as local
        tm2
 n=Sn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3 
    5    0     2.00      0.00
    5    1     2.00      0.00 
    5    2     0.00      0.00
   2.50     2.50     2.50                                            

   pg      Sulfur       Guess   Ecut ~ 25Ry    l=0,1,2 as local
        tm2
 n=S  c=ca
       0.0       0.0       0.0       0.0       0.0       0.0
    3    3 
    3    0     2.00      0.00
    3    1     4.00      0.00 
    3    2     0.00      0.00
   1.70     1.70     1.70          

   pe      Strontium     Guess   Ecut ~ 16Ry   l=0 as local 
        tm2
 n=Sr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     0.00      0.00
   3.60     3.80     3.60                                        

   pg      Tantalum           Guess  
        tm2
 n=Ta c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     3.00      0.00 
   2.55     2.55     2.55          

   pe      Terbium          Guess  
        tm2
 n=Tb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00
    4    3     9.00      0.00
   3.20     3.60     3.20     3.20

   pg      Technetium     Guess  (Who cares)
        tm2
 n=Tc c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     5.00      0.00
   2.40     2.60     2.40                                      

   pg      Tellurium    Guess   Ecut ~ 25Ry   l=0,1 as local 
        tm2
 n=Te c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     4.00      0.00 
    5    2     0.00      0.00
   2.60     2.60     2.60                                          

   pe      Tellurium    ZPD 40 182 (1997)   Ecut ~ 20Ry   l=0,1 as local  
        tm2
 n=Te c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     4.00      0.00 
    5    2     0.00      0.00
   2.80     2.80     2.80                                          

   pg      Thorium         Guess 
        tm2
 n=Th c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00
    7    1     0.00      0.00 
    6    2     1.00      0.00 
    5    3     1.00      0.00
   3.00     4.00     3.00      3.00

   pe      Titanium   template for pccec    Ecut ~ 36 Ry     l=0 as local
        tm2
 n=Ti c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3
    4    0     2.00      0.00
    4    1     0.00      0.00
    3    2     2.00      0.00
   2.54      2.96      2.25      2.25      2.25      1.00      1.25

   pg      Titanium   PRB 46 1285 (1992)    Ecut ~ 36 Ry     l=0 as local
        tm2
 n=Ti c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3
    4    0     2.00      0.00
    4    1     0.00      0.00
    3    2     2.00      0.00
   2.54     2.96     2.25

   pg      Thallium        Guess 
        tm2
 n=Tl c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   13    3 
    6    0     2.00      0.00
    6    1     1.00      0.00 
    6    2     0.00      0.00 
   3.00     3.00     3.00           

   pe      Thullium         Guess  
        tm2
 n=Tm c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    13.00      0.00
   3.15     3.50     3.15     3.15

   pg      Uranium          Guess 
        tm2
 n=U  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   15    4 
    7    0     2.00      0.00 
    7    1     0.00      0.00 
    6    2     1.00      0.00
    5    3     3.00      0.00
   3.00     4.00     3.00      3.00

   pg      Vanadium  	  Guess    Ecut ~ 49 Ry     l=0 as local
        tm2
 n=V  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2     3.00      0.00
   2.35     2.70     2.35         

   pg      Tungsten           Guess  
        tm2
 n=W  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   12    3 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     4.00      0.00 
   2.45     2.45     2.45          

   pg      Xenon  	 Guess     (who cares)
        tm2
 n=Xe c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    9    3
    5    0     2.00      0.00
    5    1     6.00      0.00 
    5    2     0.00      0.00
   3.50     3.50     3.50                                       

   pg      Yttrium   Guess   Ecut ~ 20Ry   l=0 as local 
        tm2
 n=Y  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     1.00      0.00
   3.20     3.40     3.20                                          

   pe      Ytterbium         Guess  
        tm2
 n=Yb c=car
       0.0       0.0       0.0       0.0       0.0       0.0
   11    4 
    6    0     2.00      0.00
    6    1     0.00      0.00 
    5    2     0.00      0.00 
    4    3    14.00      0.00
   3.15     3.50     3.15     3.15

   pe      Yttrium    PRB 44 10339 (1991)  Ecut ~ 25Ry   l=0 (maybe l=1) as local 
        tm2
 n=Y  c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     1.00      0.00
   3.05     3.45     2.50                                          

   pg      Zinc     Guess    Ecut ~ 75Ry   l=0 as local
        tm2
 n=Zn c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    5    3 
    4    0     2.00      0.00
    4    1     0.00      0.00 
    3    2    10.00      0.00
   2.30     2.30     2.30                                                        

   pg      Zirconium  	  Guess   Ecut ~ 25Ry   l=0 as local
        tm2
 n=Zr c=car
       0.0       0.0       0.0       0.0       0.0       0.0
    8    3 
    5    0     2.00      0.00
    5    1     0.00      0.00 
    4    2     2.00      0.00
   2.85     3.05     2.85                                               

'''
