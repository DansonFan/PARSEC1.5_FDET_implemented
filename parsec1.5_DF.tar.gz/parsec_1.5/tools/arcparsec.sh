#!/bin/bash
#finds the common files that you would wish to archive between subsequent runs on the same directory
#also takes user input

if [[ -d arc ]]
then
ARCDIR='arc'
else
ARCDIR='.'
fi
FILELIST_COPY=" parsec.in md_nrg.dat atom.cor movie.xyz out.0000 parsec.out iterate.out"
FILELIST_ARC="$FILELIST_COPY"
FILELIST_USR=${@:-""}

for copyfile in $FILELIST_ARC
do
        if [[ -f $copyfile ]]
        then
                newname=$copyfile.$(date +%d%m%y-%H%M --reference $copyfile)
                if [[ -f $ARCDIR/$newname ]]
                then
                echo "WARNING: $newname already exists, did not move"
                else
                #mv -n $copyfile $newname not moving until I find out how to check if OUTCAR is being written to
                cp -n $copyfile $ARCDIR/$newname
                echo "copied $copyfile to $newname at $ARCDIR"
                fi
        else
                echo "WARNING: did not find file $copyfile"
        fi

done

for copyfile in $FILELIST_USR
do
        if [[ -f $copyfile ]]
        then
                newname=$copyfile.$(date +%d%m%y-%H%M --reference $copyfile)
                if [[ -f $ARCDIR/$newname ]]
                then
                echo "WARNING: $newname already exists, did not move"
                else
                        cp -n $copyfile $ARCDIR/$newname
                        echo "copied $copyfile to $newname at $ARCDIR"
                fi
        
        else
                echo "WARNING: did not find file $copyfile"
        fi
done
