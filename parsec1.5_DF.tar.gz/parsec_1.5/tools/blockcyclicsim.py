#!/usr/bin/env python
import numpy as np
import itertools
__docstring__ = """Helps understand and visualize distribution of block cyclic which is used in our distributed eigendecomp"""

def numroc(N, NB, IPROC, ISRCPROC, NPROCS):
      '''
#  NUMROC computes the NUMber of Rows Or Columns of a distributed
#  matrix owned by the process indicated by IPROC.
#
#  Arguments
#  =========
#
#  N         (global input) INTEGER
#            The number of rows/columns in distributed matrix.
#
#  NB        (global input) INTEGER
#            Block size, size of the blocks the distributed matrix is
#            split into.
#
#  IPROC     (local input) INTEGER
#            The coordinate of the process whose local array row or
#            column is to be determined.
#
#  ISRCPROC  (global input) INTEGER
#            The coordinate of the process that possesses the first
#            row or column of the distributed matrix.
#
#  NPROCS    (global input) INTEGER
#            The total number processes over which the matrix is
#            distributed.
#
#  =====================================================================
#
#     .. Local Scalars ..
'''
#     ..
#     .. Executable Statements ..
#
#     Figure PROC's distance from source process
#
      MYDIST = (NPROCS+IPROC-ISRCPROC) % ( NPROCS )
#
#     Figure the total number of whole NB blocks N is split up into
#
      NBLOCKS = N // NB
#
#     Figure the minimum number of rows/cols a process can have
#
      NUMROC = (NBLOCKS//NPROCS) * NB
#
#     See if there are any extra blocks
#
      EXTRABLKS = ( NBLOCKS % NPROCS )
#
#     If I have an extra block
#
      if ( MYDIST < EXTRABLKS ):
          NUMROC = NUMROC + NB
#
#         If I have last block, it may be a partial block
#
      elif( MYDIST == EXTRABLKS ):
          NUMROC = NUMROC + ( N % NB )
      
      return NUMROC
#
#     End of NUMROC
#
class fslice(object):
    def __init__(self, start, stop, step=1):
        pass
        

import matplotlib.pyplot as plt
from matplotlib.colors import Colormap, ListedColormap

na = 144
nwant = na
nblk = 16
<<<<<<< .mine
nprocs = 14
=======
nprocs = 10
>>>>>>> .r2866
uplo = 'L'
myid = 0
a_global_chars = map(lambda x: 'A(%03d,%03d)' % (x),[(x,y) for x in range(1,na+1) for y in range(1,na+1)])
a_global = np.array(a_global_chars)
a_global.shape = (na,na)
a_spy = dict()

<<<<<<< .mine
for np_cols in range(np.int(np.round(np.sqrt(nprocs))),0,-1):
=======
np_cols = np.int(np.round(np.sqrt(nprocs)))
for np_cols in range(np.int(np.round(np.sqrt(nprocs))),1,-1):
>>>>>>> .r2866
    if( nprocs % np_cols == 0 ): break

# at the end of the above loop, nprocs is always divisible by np_cols

np_rows = nprocs/np_cols
if 1:
 myid = 0
 data = dict()
 f, axarr = plt.subplots(int(np_rows),int(np_cols))
 for my_pcol in range(0,np_cols):
     for my_prow in range(0,np_rows):
         iofile = open('testloc_ass%03d.txt' % (myid),'w')
         na_rows = numroc(na, nblk, my_prow, 0, np_rows)
         na_cols = numroc(na, nblk, my_pcol, 0, np_cols)

         iofile.write(('%03d '*6 % (na_rows, na_cols, my_prow, my_pcol, np_rows, np_cols))[0:-1])
         iofile.write('\nl_col   i j   a,l_row(j),l_col(i) col(j)         A  i  j\n')
         data[(my_prow,my_pcol)] = (na_rows,na_cols)
         a_spy[(my_prow,my_pcol)] = np.zeros((na,na),dtype=int)

# local row counter
         lr = 0 
# local column counter
         lc = 0 

         l_row = np.zeros(na,dtype=int)
         l_col = np.zeros(na,dtype=int)
         for i in range(0,na):
             if( ((i)/nblk % np_rows) == my_prow):
                 # row i is on local processor
                 lr = lr+1
                 l_row[i] = lr

             if( ((i)/nblk % np_cols) == my_pcol):
                 # column i is on local processor
                 lc = lc+1
                 l_col[i] = lc
         data[(my_prow,my_pcol)] = {'l_col':l_col, 'l_row':l_row}

         col = np.zeros(na,dtype=type(a_global))
         a = np.zeros((na_rows,na_cols),dtype=type(a_global))
         if( uplo == 'L' ):
                 for i in range(0,na): # i = 1,na
# because of indexing behavior in python... annoying
                           if i==0 : col[0] = a_global[i,0]
                           else: col[0:i+1] = a_global[i,0:i+1]
                           
                           if(l_col[i] > 0):
                                    for j in range(0,i+1): # j= 1,i , (0,[0]),(1,[1,2])...(na,[1...na])
                                            if(l_row[j]>0): a[l_row[j]-1,l_col[i]-1] = col[j]
                                            if(l_row[j]>0): a_spy[(my_prow,my_pcol)][j,i] = 1
                                            if(l_row[j]>0): iofile.write("%5s  %03d %03d  %1s%03d %03d %26s  %1s %03d %03d\n" % ('l_col',i+1,j+1,'a',l_row[j],l_col[i],col[j],'A',i+1,j+1))

                           if(l_row[i] > 0):
                                    for j in range(0,i): # j= 1,i-1 , (0,[]),(1,[1])...(na-1,[1...na-2])
                                            if(l_col[j]>0): a[l_row[i]-1,l_col[j]-1] = col[j]
                                            if(l_col[j]>0): a_spy[(my_prow,my_pcol)][i,j] = 1
                                            if(l_col[j]>0): iofile.write("%5s  %03d %03d  %1s%03d %03d %26s  %1s %03d %03d\n" % ('l_row',i+1,j+1,'a',l_row[i],l_col[j],col[j],'A',i+1,j+1))
         data[(my_prow,my_pcol)]['a'] = a
         with open('final_%d_%d.txt' % (my_prow,my_pcol),'w') as final:
                 for l in a: 
                         final.write(len(tuple(l))*'%8s ' % tuple(l)+'\n')
         axarr[my_prow,my_pcol].spy(a_spy[(my_prow,my_pcol)])
         axarr[my_prow,my_pcol].plot((0,na),(0,na),'--k')
         axarr[my_prow,my_pcol].axis((0,na,na,0))
         axarr[my_prow,my_pcol].set_title('({0:d},{1:d})'.format(my_prow,my_pcol))
         myid = myid+1
         iofile.close()
 f.savefig('{0:04d}_{1:02d}_{2:02d}.eps'.format(nwant,np_rows,np_cols))

if 0:
    f, axarr = plt.subplots(int(np_rows),int(np_cols))
    a_dist_spy = dict()
    h_work = dict()
    h_dist = dict()
    myid = 0
    tile_rows = nblk
    tile_cols = nwant
    for my_pcol in range(0,np_cols):
        for my_prow in range(0,np_rows):
            me = (my_prow,my_pcol)
            # h_work[me][ 0 <= COLUMN < tile_rows, 0<= ROW < tile_cols ]
            h_work[me] = np.zeros((tile_rows, tile_cols),dtype=int)
            a_dist_spy[me] = np.zeros((na,na),dtype=int)
            h_dist[me] = np.zeros((numroc(na, nblk, my_prow, 0, np_rows),numroc(na, nblk, my_pcol, 0, np_cols)),dtype=int)
            for j_global in range(0, nwant, nblk):
                offset_lim = min(tile_rows,nwant-j_global)
                itile = (j_global/nblk)
                for j_offset in range(0,offset_lim):
                 jcol = j_global + j_offset
                 j_local = j_offset
                 h_work[me][ j_local, 0:j_global] = 0
                 # h_work[me][ COLUMN_I , COLUMN_I <= ROW < nwant ]
                 for ic in range(jcol,nwant):
                  h_work[me][ j_local, ic] = (jcol) * nwant + ic + 1
                 # handles the tops of the triangles
                 # h_work[me][ COLUMN_I <= ROW < J_GLOBAL + offset_lim , COLUMN_I ]
                 # jcol==0  : w[ 1:16, 0] = w[ 0, 1:16]
                 # jcol==1  : w[ 2:16, 1] = w[ 1, 2:16]
                 # jcol==15 : w[ 16:16, 15] = w[ 15, 16:16]
                 # jcol==16 : w[ 1:16, 16]  = w[  0, jcol+ 1:16]
                 # jcol==17 : w[ 2:16, 17]  = w[  1, jcol+ 2:16]
                 # jcol==31 : w[ 16:16, 31] = w[ 15, jcol+16:16]
                 #if (me==(0,0) and (j_global in [0,nblk,6*nblk])): 
                 # print((slice(j_offset+1, offset_lim), jcol),(j_offset, slice(jcol + 1, j_global + offset_lim)))
                 h_work[me][ slice(j_offset+1, offset_lim), jcol] = h_work[me][ 
                         j_offset, slice(jcol + 1, j_global + offset_lim)
                         ]

                procrow = itile % np_rows
                proccol = itile % np_cols
                
                # This represents the global matrix
                if 0:#(procrow==my_prow):
                    mod_col = (  my_prow - my_pcol + itile / np_rows ) % np_cols
                    for lblk in range( ( itile + np_cols - mod_col ) * nblk , nwant , np_cols * nblk ):
                        h_gi = slice( itile * nblk , ( itile + 1 ) * nblk )
                        h_gj = slice( lblk , lblk + min( nblk , nwant - lblk ) )
                        print myid, 'row', itile, h_gi, h_gj
                        try:
                            a_dist_spy[me][h_gi,h_gj] = 1 #h_work[me][h_wi, h_wj]
                        except:
                           print(lblk,j_global,j_offset)
                           print(h_gi)
                           print(h_gj)
                           raise

                # this represents the local work vectorspace that gets schlurped
                if (procrow==my_prow):
                    mod_col = (  my_prow - my_pcol + itile / np_rows ) % np_cols
                    l_i = (h_dist[me].shape[1] + nblk - 1) / nblk - ( (nwant - (itile + np_cols -  mod_col) * nblk - 1) / (np_cols * nblk) + 1)
                    print myid, me[0], me[1], 'l_i', l_i, (h_dist[me].shape[1] + nblk - 1) / nblk, ( (nwant - (itile + np_cols - mod_col) * nblk) / (np_cols * nblk) + 1), itile, np_cols, mod_col, nwant-(itile + np_cols - mod_col) * nblk
                    for lblk in range( ( itile + np_cols - mod_col ) * nblk , nwant , np_cols * nblk ):
                        h_gj = slice( itile * nblk , ( itile + 1 ) * nblk )
                        h_gi = slice( lblk , lblk + min( nblk , nwant - lblk ) )
                        print myid, ' row', itile, h_gi, h_gj
                        try:
                            a_dist_spy[me][h_gi,h_gj] = 1 #h_work[me][h_wi, h_wj]
                        except:
                           print(lblk,j_global,j_offset)
                           print(h_gi)
                           print(h_gj)
                           raise
                        try:
                            h_dist[me][slice((itile-my_prow)/np_rows * nblk, (itile-my_prow)/np_rows*nblk + min(nblk, offset_lim)),
                                    slice(l_i * nblk, l_i * nblk + min(nblk, nwant-lblk))
                                    ] = h_work[me][slice(0,min(nblk,offset_lim)), h_gi]
                        except:
                           print(lblk,j_global,j_offset)
                           raise
                        l_i = l_i + 1

                if (proccol==my_pcol):
                    mod_col = ( my_prow - my_pcol + itile / np_cols ) % np_rows
                    l_i = (h_dist[me].shape[0] + nblk - 1) / nblk - ( (nwant - (itile + mod_col) * nblk - 1) / (np_rows * nblk) + 1)
                    print me, 'l_i', (h_dist[me].shape[0] + nblk - 1) / nblk, ( (nwant - (itile + mod_col) * nblk) / (np_rows * nblk) + 1), l_i
                    for lblk in range((itile + mod_col) * nblk, nwant, np_rows * nblk):
                        h_gi = slice( lblk, lblk + min( nblk, nwant - lblk ) )
                        h_gj = slice( itile * nblk, (itile+1) * nblk)
                        print myid, ' col', itile, h_gi, h_gj
                        try:
                            a_dist_spy[me][h_gi,h_gj] = 1 #h_work[me][h_wi, h_wj]
                        except:
                           print(lblk,j_global,j_offset)
                           print(h_gi)
                           print(h_gj)
                           raise
                        try:
                            h_dist[me][slice(l_i * nblk, l_i * nblk + min(nblk, nwant-lblk)), 
                                    slice((itile-my_pcol)/np_cols * nblk, (itile-my_pcol)/np_cols*nblk + min(nblk, offset_lim))
                                    ] = np.transpose(h_work[me][slice(0,min(nblk,offset_lim)), h_gi])
                        except:
                           print(l_i, lblk,j_global,j_offset)
                           raise
                        l_i = l_i + 1



            axarr[my_prow,my_pcol].spy(a_dist_spy[me],cmap=ListedColormap(['w','k']))
            axarr[my_prow,my_pcol].plot((0,na),(0,na),'k--')
            axarr[my_prow,my_pcol].axis((0,na,na,0))
            axarr[my_prow,my_pcol].plot((0,na),(0,na),'--k')
            axarr[my_prow,my_pcol].axis((0,na,na,0))
            axarr[my_prow,my_pcol].set_title('({0:d},{1:d})'.format(*me))
            myid = myid+1
# Shows global ownership
    f.savefig('{0:04d}_{1:02d}_{2:02d}.eps'.format(nwant,np_rows,np_cols))

# Each should be a fully black box or alternatively a fully white box (spy error) - representing complete fill for his local matrix
    f, axarr = plt.subplots(int(np_rows),int(np_cols))
    for my_pcol in range(0,np_cols):
        for my_prow in range(0,np_rows):
            me = (my_prow,my_pcol)
            axarr[my_prow,my_pcol].spy(h_dist[me])
            axarr[my_prow,my_pcol].set_title('({0:d},{1:d})'.format(*me))
    plt.show()

#fortran offset is the 1
def g2l(i, n, np, nb):
  im1 = i#-1
  il  = (im1/(np*nb))*nb + (im1 % nb)# + 1
  return il

def Bg2l(i, n, np, nb):
  im1 = i#-1
  il  = (im1/(np)) # + 1
  return il

if 0:
    f, axarr = plt.subplots(int(np_rows),int(np_cols))
    a_dist_spy = dict()
    h_work = dict()
    h_dist = dict()
    myid = 0
    tile_rows = nblk
    tile_cols = nwant
    for my_pcol in range(0,np_cols):
        for my_prow in range(0,np_rows):
            me = (my_prow,my_pcol)
            # h_work[me][ 0 <= COLUMN < tile_rows, 0<= ROW < tile_cols ]
            h_work[me] = np.zeros((tile_rows, tile_cols),dtype=int)
            a_dist_spy[me] = np.zeros((na,na),dtype=int)
            h_dist[me] = np.zeros((numroc(na, nblk, my_prow, 0, np_rows),numroc(na, nblk, my_pcol, 0, np_cols)),dtype=int)
            for j_global in range(0, nwant, nblk):
                offset_lim = min(tile_rows,nwant-j_global)
                itile = (j_global/nblk)
                for j_offset in range(0,offset_lim):
                 jcol = j_global + j_offset
                 j_local = j_offset
                 h_work[me][ j_local, 0:j_global] = 0
                 # h_work[me][ COLUMN_I , COLUMN_I <= ROW < nwant ]
                 for ic in range(jcol,nwant):
                  h_work[me][ j_local, ic] = (jcol) * nwant + ic + 1
                 # handles the tops of the triangles
                 # h_work[me][ COLUMN_I <= ROW < J_GLOBAL + offset_lim , COLUMN_I ]
                 # jcol==0  : w[ 1:16, 0] = w[ 0, 1:16]
                 # jcol==1  : w[ 2:16, 1] = w[ 1, 2:16]
                 # jcol==15 : w[ 16:16, 15] = w[ 15, 16:16]
                 # jcol==16 : w[ 1:16, 16]  = w[  0, jcol+ 1:16]
                 # jcol==17 : w[ 2:16, 17]  = w[  1, jcol+ 2:16]
                 # jcol==31 : w[ 16:16, 31] = w[ 15, jcol+16:16]
                 #if (me==(0,0) and (j_global in [0,nblk,6*nblk])): 
                 # print((slice(j_offset+1, offset_lim), jcol),(j_offset, slice(jcol + 1, j_global + offset_lim)))
                 h_work[me][ slice(j_offset+1, offset_lim), jcol] = h_work[me][ 
                         j_offset, slice(jcol + 1, j_global + offset_lim)
                         ]

                procrow = itile % np_rows
                proccol = itile % np_cols
                
                Bgi0 = itile
                Bgj0 = itile
                Bli0 = (Bgi0 - my_prow) // np_rows
                Blj0 = (Bgj0 - my_pcol) // np_cols

                print('{:02d} {:02d} {:02d}  globals {:02d} {:02d} {:02d} {:02d}'.format(myid, me[0], me[1], itile, Bgi0, Bgj0, Bli0, Blj0))

                # this represents the local work vectorspace that gets schlurped
                if (procrow==my_prow):
                    mod_col = (  my_prow - my_pcol + itile / np_rows ) % np_cols
                    l_i = (h_dist[me].shape[1] + nblk - 1) / nblk - ( (nwant - (itile + np_cols -  mod_col) * nblk - 1) / (np_cols * nblk) + 1)
                    print myid, me[0], me[1], 'l_i', l_i, (h_dist[me].shape[1] + nblk - 1) / nblk, ( (nwant - (itile + np_cols - mod_col) * nblk) / (np_cols * nblk) + 1), itile, np_cols, mod_col, nwant-(itile + np_cols - mod_col) * nblk
                    for lblk in range( ( itile + np_cols - mod_col ) * nblk , nwant , np_cols * nblk ):
                        h_gj = slice( itile * nblk , ( itile + 1 ) * nblk )
                        h_gi = slice( lblk , lblk + min( nblk , nwant - lblk ) )
                        print myid, ' row', itile, h_gi, h_gj
                        try:
                            a_dist_spy[me][h_gi,h_gj] = 1 #h_work[me][h_wi, h_wj]
                        except:
                           print(lblk,j_global,j_offset)
                           print(h_gi)
                           print(h_gj)
                           raise
                        try:
                            h_dist[me][slice((itile-my_prow)/np_rows * nblk, (itile-my_prow)/np_rows*nblk + min(nblk, offset_lim)),
                                    slice(l_i * nblk, l_i * nblk + min(nblk, nwant-lblk))
                                    ] = h_work[me][slice(0,min(nblk,offset_lim)), h_gi]
                        except:
                           print(lblk,j_global,j_offset)
                           raise
                        l_i = l_i + 1

                if (proccol==my_pcol):
                    mod_col = ( my_prow - my_pcol + itile / np_cols ) % np_rows
                    l_i = (h_dist[me].shape[0] + nblk - 1) / nblk - ( (nwant - (itile + mod_col) * nblk - 1) / (np_rows * nblk) + 1)
                    print me, 'l_i', (h_dist[me].shape[0] + nblk - 1) / nblk, ( (nwant - (itile + mod_col) * nblk) / (np_rows * nblk) + 1), l_i
                    for lblk in range((itile + mod_col) * nblk, nwant, np_rows * nblk):
                        h_gi = slice( lblk, lblk + min( nblk, nwant - lblk ) )
                        h_gj = slice( itile * nblk, (itile+1) * nblk)
                        #print myid, me, ' col', itile, Bgi, Bgj, Bli, Blj, h_gi, h_gj
                        try:
                            a_dist_spy[me][h_gi,h_gj] = 1 #h_work[me][h_wi, h_wj]
                        except:
                           print(lblk,j_global,j_offset)
                           print(h_gi)
                           print(h_gj)
                           raise
                        try:
                            h_dist[me][slice(l_i * nblk, l_i * nblk + min(nblk, nwant-lblk)), 
                                    slice((itile-my_pcol)/np_cols * nblk, (itile-my_pcol)/np_cols*nblk + min(nblk, offset_lim))
                                    ] = np.transpose(h_work[me][slice(0,min(nblk,offset_lim)), h_gi])
                        except:
                           print(l_i, lblk,j_global,j_offset)
                           raise
                        l_i = l_i + 1



            axarr[my_prow,my_pcol].spy(a_dist_spy[me],cmap=ListedColormap(['w','k']))
            axarr[my_prow,my_pcol].plot((0,na),(0,na),'k--')
            axarr[my_prow,my_pcol].axis((0,na,na,0))
            axarr[my_prow,my_pcol].plot((0,na),(0,na),'--k')
            axarr[my_prow,my_pcol].axis((0,na,na,0))
            axarr[my_prow,my_pcol].set_title('({0:d},{1:d})'.format(*me))
            myid = myid+1
# Shows global ownership
    f.savefig('{0:04d}_{1:02d}_{2:02d}.eps'.format(nwant,np_rows,np_cols))

# Each should be a fully black box or alternatively a fully white box (spy error) - representing complete fill for his local matrix
    f, axarr = plt.subplots(int(np_rows),int(np_cols))
    for my_pcol in range(0,np_cols):
        for my_prow in range(0,np_rows):
            me = (my_prow,my_pcol)
            axarr[my_prow,my_pcol].spy(h_dist[me])
            axarr[my_prow,my_pcol].set_title('({0:d},{1:d})'.format(*me))
    plt.show()
