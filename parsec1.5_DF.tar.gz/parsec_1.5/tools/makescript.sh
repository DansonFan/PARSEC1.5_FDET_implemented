#!/bin/bash
source ./module_unload.sh
module load intel/2018.beta impi/2018.beta
for ARCHabbr in knl hsw ; do 
for MACHext in custfltr exitdcmp exitfltr exitorth exitproj exitupdt onlydcmp onlyfltr onlyorth onlyproj onlyupdt saveall ; do
make -C ../src MACH=cori.intel.${ARCHabbr}.noelpa.${MACHext} -j6
done
done
