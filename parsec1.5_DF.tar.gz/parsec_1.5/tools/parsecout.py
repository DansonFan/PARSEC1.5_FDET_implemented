import re
import sys
import numpy as np
__docstring__ = """tokens for the parsec.out style file"""
_static_patterns = {
        'sep':r'\s+',
        'firstchar':r'^',
        'lastchar':r'$',
        'BLE':r'\s*?'}
_var_patterns = {'float':'[0-9\.ED\-]+',
        'int':'[0-9\.]+',
        'entireline':'.*?',
        'paragraph':'".*?"',
        'string' : '"?.*?"?',
        'cin':'(',
        'cout':')'}

def searchterm(term, type, count, prepend, flags):
	return (lambda x: re.search(prepend+term+_var_patterns[type]))

def entireline(term=None):
	return _var_patterns['entireline']

def string(term=None):
	return _var_patterns['string']

def number(term=None, count=1, prepend="", flags=None):
	return _var_patterns['float']

def marker(flag):
	return (lambda x : ())

NONE=0b0
PHYSICAL=0b1
EXTRA=0b10
# entries
("SVN Revision", entireline)
("config file",  entireline)
("flags",        entireline)
("defines",      entireline)
("shift vector", number(count=3))
("rmax",         number(prepend="NOW - "))
("Grid spacing", number(flags=PHYSICAL))
("Atom data:", None, marker("Atom"))
("Atom coordinates input in", string, None)
("Chemical element :", string, marker("AtomType"))
("There are ", number(flags=EXTRA), None)

class parsecout():
	def __init__(self,ifile='parsec.out'):
		line_buffer = list()
		setattr(self, 'state', 'none')
		setattr(self,'atom',dict())
		infile = open(ifile,'r')
		for line in infile:
			line_buffer.append(line)
			if self.state=='in_atomcoords':
				m = re.search(r"^"+r"\s+([-]?[0-9][0-9.-DE]+)"*3+r"\s+[10]",line_buffer[-1])
				if( bool(m) ):
					try:
						self.atom[self.cur_atom].append(m.groups())
					except:
						try:
							self.atom[self.cur_atom] = [ m.groups() ]
						except:
							raise (m, self.cur_atom)
				else:
					self.cur_atom = None
					self.state='in_atom'
				
			if self.state=='in_atom' :
				m = re.search(r"^\s*Chemical element [:]\s*(\S+)", line_buffer[-1])
				if(m): self.cur_atom = m.group(1)
				m = re.search(r"\s*x \[([a-zA-Z]+)\]",line_buffer[-1])
				if(m): 
					self.coord_unit= m.group(1)
					self.state = 'in_atomcoords'
			if self.state=='in_grid' :
				m = re.search(r"^\s*Grid spacing is\s*(\S+)", line_buffer[-1])
				if(m): self.gridspacing = float(m.group(1))
				m = re.search(r"^\s*shift vector ="+r"\s+([.0-9-]+)"*3, line_buffer[-1])
				if(m): self.shiftvector = np.array(m.groups(),dtype=np.float64)
			if self.state=='in_symmetry':
				m = re.search(r"^\s*Final grid spacing:"+r"\s+([.0-9-]+)"*3, line_buffer[-1])
				if(m): self.hx, self.hy, self.hz = np.array(m.groups(),dtype=np.float64)
				m = re.search(r"^\s*Number of grid points.*:"+r"\s+([.0-9-]+)"*3, line_buffer[-1])
				if(m): self.num_points = np.array(m.groups(),dtype=int)
			if re.match(r"^\s*Symmetry Properties:", line_buffer[-1]): setattr(self,'state','in_symmetry')
			if re.match(r"^\s*Atom data:", line_buffer[-1]): setattr(self,'state','in_atom')
			if re.match(r"^\s*Correlation data:", line_buffer[-1]): setattr(self,'state','in_correlation')
			if re.match(r"^\s*Grid data:", line_buffer[-1]): setattr(self,'state','in_grid')
			if re.match(r"^\s*Eigenvalue data:", line_buffer[-1]): setattr(self,'state','in_eigenvalue')
			if re.match(r"^\s*Self-consistency data:", line_buffer[-1]): setattr(self,'state','in_selfconsistency')
			if re.match(r"^\s*Mixer data:", line_buffer[-1]): setattr(self,'state','in_mixer')
			m = re.search(r"^\s*Tot. number of atoms =\s*([0-9]+)", line_buffer[-1]) 
			if (m): self.num_atoms = int(m.group(1))
			# end condition
			if re.match(r"^\s*------", line_buffer[-1]) and re.search(r"^\s*Setup time \[", line_buffer[-3]):
				break
		# finalize
		infile.close()
		for elementIter in self.atom: 
			element = elementIter
			self.atom[element] = np.array(tuple(self.atom[element]),dtype=np.float64,ndmin=2)

	def gaussian_cube(self, orient_file, ofile=sys.stdout, voxelcol=list((7,)), skiplines=1, filetype='plaintext', dat_transform= lambda x: x):
		files = list()
		with open(orient_file,'r') as orienter:
			for line in orienter:
				if line[0] != '!' : 
					if line[-1]=='\n': files.append(os.path.join(os.path.dirname(orient_file),line[0:-1]))
					else: files.append(os.path.join(os.path.dirname(orient_file),line))

		limits_ijk = np.zeros((3,2),dtype=int)
		limits_xyz = np.zeros((3,2),dtype=np.float64)
		data = dict()
		voxeldata = {ivoxelcol:dict() for ivoxelcol in voxelcol}
		for filei in files: 
			if filetype=='plaintext': data = np.genfromtxt(filei, skip_header=skiplines)
			for i in [0,1,2] : 
				limits_ijk[i,0] = min(limits_ijk[i,0],int(min(data[:,i])))
				limits_ijk[i,1] = max(limits_ijk[i,1],int(max(data[:,i])))
				limits_xyz[i,0] = min(limits_xyz[i,0],min(data[:,i+4]))
				limits_xyz[i,1] = max(limits_xyz[i,1],max(data[:,i+4]))

			for x in data: 
				for ivoxelcol in voxelcol:
					voxeldata[ivoxelcol][(int(x[0]),int(x[1]),int(x[2]))]=dat_transform(x[ivoxelcol])
			del data
		import periodic_info
		for ivoxelcol in voxelcol:
			with open('datac-%04d.cube' % (ivoxelcol),'w') as gaussfile:
				gaussfile.write(
				   """CPMD CUBE FILE
OUTER LOOP: X, MIDDLE LOOP: Y, INNER LOOP: Z
{num_atoms:d} {SX:13.5f} {SY:13.5f} {SZ:13.5f}
{NX:d} {hx:8f} 0.000000 0.000000
{NY:d} 0.000000 {hy:8f} 0.000000
{NZ:d} 0.000000 0.000000 {hz:8f}\n""".format(
					SX=limits_xyz[0,0],
					SY=limits_xyz[1,0],
					SZ=limits_xyz[2,0],
					NX=int(limits_ijk[0,1]-limits_ijk[0,0]+1),
					NY=int(limits_ijk[1,1]-limits_ijk[1,0]+1),
					NZ=int(limits_ijk[2,1]-limits_ijk[2,0]+1),
					**self.__dict__))
				for eleIter in self.atom:
					eleIterNum = periodic_info.atomicNumber(eleIter)
					for coords in self.atom[eleIter]:
						gaussfile.write("{:4d} 0.0000000 {:11f} {:11f} {:11f}\n".format(eleIterNum,*coords))

				for ix in range(limits_ijk[0,0],limits_ijk[0,1]+1):
					for iy in range(limits_ijk[1,0],limits_ijk[1,1]+1):
						l = 0
						for iz in range(limits_ijk[2,0],limits_ijk[2,1]+1):
							gaussfile.write("%13.5e" % voxeldata[ivoxelcol].get((ix,iy,iz),0.0))
							if( l % 6 == 5 ): gaussfile.write("\n")
							l = l + 1
						if(iz % 6 != 5): gaussfile.write("\n")

if __name__ == "__main__":
	import argparse, os
	argparser = argparse.ArgumentParser()
	argparser.add_argument("infile",type=str,help='path/filename to parsec.out')
	argparser.add_argument("--col",type=int, default=list((7,)), nargs='+', help='column number list for multiple files in the data.visit subfiles to use for volume')
	argparser.add_argument("--transform",type=str, default="x", help='transformation function for the data')
	argparser.add_argument("--skiplines",type=int, default=1, help='number of lines to skip in the data.visit subfiles')
	argparser.add_argument("--type",type=str,default='plaintext',choices=('plaintext',),
			help='fileformat that the data.visit subfiles are in')
	parsed = argparser.parse_args()
	ret = parsecout(parsed.infile)
	ret.gaussian_cube(os.path.join(os.path.dirname(parsed.infile),'data.visit'), voxelcol=list(parsed.col),
			skiplines=parsed.skiplines, filetype=parsed.type, dat_transform=lambda x: eval(parsed.transform))
