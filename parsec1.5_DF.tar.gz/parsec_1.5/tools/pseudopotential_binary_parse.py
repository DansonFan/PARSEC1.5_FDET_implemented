#!/usr/bin/env python
import struct
import numpy as np
import sys, os
sys.path.append(os.environ['WORK']+'/scripts')

def writeout(ppot, **kwargs):
	accepted_keys = ['filename','nrmax','norbmax','lmax']
	for key in kwargs.keys(): 
		if key not in accepted_keys: raise KeyError
	filename = 'pseudo.dat' if not kwargs.has_key('filename') else kwargs['filename']
# yeah this was set this way...
	nrmax    = 2000  if not kwargs.has_key('nrmax') else kwargs['nrmax']
	norbmax  = 2000  if not kwargs.has_key('norbmax') else kwargs['norbmax']
	lmax     = 5     if not kwargs.has_key('lmax')  else kwargs['lmax']

	file = open(filename,'wb')
	outstr = ''
	outstr += struct.pack('1i',177)
	outstr += struct.pack('2s2s3s4s',ppot.nameat, ppot.icorrt, ppot.irel, ppot.nicore)
	outstr += struct.pack('10s'*6, *ppot.iray)
	outstr += struct.pack('10s'*7, *ppot.ititle)
	outstr += struct.pack('3i',ppot.npotd, ppot.npotu, ppot.nrm)
	outstr += struct.pack('3d', ppot.a, ppot.b, ppot.zion)
	outstr += struct.pack('1i', 177)

	recordsize = struct.calcsize(str(ppot.nrm)+'d')
	outstr += struct.pack('1i',recordsize)
	outstr += struct.pack('%id' % (ppot.nrm),*ppot.r)
	outstr += struct.pack('1i',recordsize)

	recordsize = 4+struct.calcsize(str(ppot.nrm)+'d')
	for key in ppot.ppot.keys():
		outstr += struct.pack('1i',recordsize)
		outstr += struct.pack('1i',key)
		outstr += struct.pack('%id' % (ppot.nrm),*(np.array(ppot.ppot[key])*np.array(ppot.r)))
		outstr += struct.pack('1i',recordsize)

	if ppot.npotu > 0:
		raise Exception('NO support for relativistic potentials in pseudopotential module yet!')
		for key in ppot.ppot.keys():
			outstr += struct.pack('1i',recordsize)
			outstr += struct.pack('1i',key)
			outstr += struct.pack('%id' % (ppot.nrm),*ppot.ppot[key])
			outstr += struct.pack('1i',recordsize)
	
	recordsize = struct.calcsize(str(ppot.nrm)+'d')
	if (ppot.nicore == 'nc  '):
		outstr += struct.pack('1i',recordsize)
		outstr += struct.pack('%id' % (ppot.nrm),*np.zeros((ppot.nrm,)))
		outstr += struct.pack('1i',recordsize)
	else: 
		outstr += struct.pack('1i',recordsize)
		outstr += struct.pack('%id' % (ppot.nrm),*(np.array(ppot.corecharge)*np.array(ppot.r)))
		outstr += struct.pack('1i',recordsize)
	
	outstr += struct.pack('1i',recordsize)
	outstr += struct.pack('%id' % (ppot.nrm),*(np.array(ppot.valencecharge)*np.array(ppot.r)))
	outstr += struct.pack('1i',recordsize)

	file.write(outstr)
	file.close()
	return outstr

def readin(**kwargs):
	filename = 'pseudo.dat' if not kwargs.has_key('filename') else kwargs['filename']
# yeah this was set this way...
	nrmax    = 2000  if not kwargs.has_key('nrmax') else kwargs['nrmax']
	norbmax  = 2000  if not kwargs.has_key('norbmax') else kwargs['norbmax']
	lmax     = 5     if not kwargs.has_key('lmax')  else kwargs['lmax']

# Opening File for pseudpotential data already gen'd
	F = open(filename,'rb')
	data = F.read()

# namet, icorrt, irel, nicore
	nameat, icorrt, irel, nicore = struct.unpack('4x2s2s3s4s',data[0:15])
	Debug = False
	if (Debug) :
		print 'nameat',nameat
		print 'icorrt',icorrt
		print 'irel',irel
		print 'nicore',nicore

	iray = struct.unpack('10s'*6,data[15:75])
	ititle = struct.unpack('10s'*7,data[75:145])
	if (Debug) :
		print 'iray',iray
		print 'ititle',ititle

	npotd, npotu, nrm = struct.unpack('3i',data[145:157])
	if (Debug) :
		print npotd,npotu,nrm

	a, b, zion = struct.unpack('3d',data[157:181])
	if (Debug) :
		print a,b,zion


	nr = nrm+1

	current = 181

	current+=4 # end of record offset
	current+=4 # beginning of record offset
# gridpoints - r
	r = struct.unpack(('%id' % (nr-1)),data[current:current+(nr-1)*8])
# in vionic.f90 it adds the first element of r to be zero. Not sure why, but we're going for a straight in and out

	current += + (nr-1)*8 + 4  # end of record , end of read

# Next read
	current += 4

# set in code
	npd = np.zeros((lmax,))

	viod = {}
	for i in np.r_[0:npotd]:
		loi = struct.unpack('1i',data[current:current+4])[0]
		current  +=  4
		viod[loi] =  struct.unpack('%id' % (nr-1),data[current:current+(nr-1)*8]) 
		current  +=  (nr-1)*8 +8
		npd[loi] = 1


# if the first down potential space is blank, use the next lowest one
	if npd[0] == 0:
		exitcond = False
		i = 0
		while exitcond != True:
			i+=1
			if npd[i] > 0:
				viod[0]=viod[i]
			if ( i > lmax or npd[i] > 0 ): exitcond = True

# not entirely sure what this does
	for i in np.r_[1:lmax]:
		if npd[i] == 0:
			viod[i]=viod[i-1]

# if there are spin orbit potentials
	if npotu > 0:
		npu = np.zeros((lmax,))
		for i in np.r_[0:npotu]:
			loi = struct.unpack('1i',data[current:current+4])[0]
			current  +=  4
			viou[loi] =  struct.unpack('%id' % (nr-1),data[current:current+(nr-1)*8]) 
			current  +=  (nr-1)*8 +8
			npd[loi] = 1


# if the first down potential space is blank, use the next lowest one
		if npd[0] == 0:
			exitcond = False
			i = 0
			while exitcond != True:
				i+=1
				if npd[i] > 0:
					viou[0]=viou[i]
				if ( i > lmax or npd[i] > 0 ): exitcond = True

# not entirely sure what this does
		for i in np.r_[1:lmax]:
			if npd[i] == 0:
				viou[i]=viou[i-1]
		
	cdc = struct.unpack(('%id' % (nr-1)),data[current:current+8*(nr-1)])
	current += 8*nr + 4

	'''
	if itype == 6:
		Something goes here not quite sure what it is... it's vionic.f line 140
	'''


if __name__ == '__main__':
	import pseudopotential
	ppot = pseudopotential.pseudopotential()
	ppot.create('N',s_cut=1.0,p_cut=1.0)
	ppot.run()
	readin(filename='pseudo.dat01')
	writeout(ppot)
	F1 = open('pseudo.dat','rb')
	F2 = open('pseudo.dat01','rb')
	d1 = F1.read()
	d2 = F2.read()
	F1.close()
	F2.close()
	print struct.unpack('1i',d1[0:4]),struct.unpack('1i',d2[0:4])
	print struct.unpack('1i',d1[181:185]),struct.unpack('1i',d2[181:185])
	# byte wise comparison

	# now compared as 4-byte ints
	step = 8
	#for i in range(189,250,step): print i,d1[i:i+step],d2[i:i+step],d1[i:i+step]==d2[i:i+step]
	for i in range(157,181,step): 
		c1 = struct.unpack('1d',d1[i:i+step])[0]
		c2 = struct.unpack('1d',d2[i:i+step])[0]
		#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)
		
	step = 4
	for i in range(181,185,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)
	print 'Header information checks out!\n'


	current = 185

	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)

	current+=4
	step = 8
	recordsize = struct.calcsize(str(ppot.nrm)+'d')
	for i in range(current,current+recordsize,step): 
		c1 = struct.unpack('1d',d1[i:i+step])[0]
		c2 = struct.unpack('1d',d2[i:i+step])[0]
		#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %25.17g %25.17g' % (c1,c2)

	current+=recordsize
	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)
	current+=4
	print 'Grid checks out!\n'

	# these are checked for less accuracy because they've had division done on them.
	for j in range(2):
		step = 4
		for i in range(current,current+step,step): 
			c1 = struct.unpack('1i',d1[i:i+step])[0]
			c2 = struct.unpack('1i',d2[i:i+step])[0]
			print i,c1,c2,c1==c2,c1-c2,(c1,c2)
			assert c1==c2,'c1 != c2: %d %d,j = %d' % (c1,c2,j)

		current+=4
		for i in range(current,current+step,step): 
			c1 = struct.unpack('1i',d1[i:i+step])[0]
			c2 = struct.unpack('1i',d2[i:i+step])[0]
			print i,c1,c2,c1==c2,c1-c2,(c1,c2)
			assert c1==c2,'c1 != c2: %d %d,j = %d' % (c1,c2,j)
		current+=4
		step = 8
		recordsize = struct.calcsize(str(ppot.nrm)+'d')
		for i in range(current,current+recordsize,step): 
			c1 = struct.unpack('1d',d1[i:i+step])[0]
			c2 = struct.unpack('1d',d2[i:i+step])[0]
			#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
			assert abs(c1-c2) < 4.45e-15,'c1 != c2: %25.17g %25.17g, j = %d, c1-c2=%25.17g' % (c1,c2,j,c1-c2)

		current+=recordsize
		step = 4
		for i in range(current,current+step,step): 
			c1 = struct.unpack('1i',d1[i:i+step])[0]
			c2 = struct.unpack('1i',d2[i:i+step])[0]
			print i,c1,c2,c1==c2,c1-c2,(c1,c2)
			assert c1==c2,'c1 != c2: %d %d, j = %d' % (c1,c2,j)
		current+=4
		print 'Potential(l=%d) checks out!\n' % (j)
	
# Check Core Charge
	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)

	current+=4
	step = 8
	recordsize = struct.calcsize(str(ppot.nrm)+'d')
	for i in range(current,current+recordsize,step): 
		c1 = struct.unpack('1d',d1[i:i+step])[0]
		c2 = struct.unpack('1d',d2[i:i+step])[0]
		#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert abs(c1-c2) < 4.45e-15,'c1 != c2: %25.17g %25.17g, j = %d, c1-c2=%25.17g' % (c1,c2,2,c1-c2)

	current+=recordsize
	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)
	current+=4
	print 'Core charge checks out!\n'

 # Check Valence
	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)

	current+=4
	step = 8
	recordsize = struct.calcsize(str(ppot.nrm)+'d')
	for i in range(current,current+recordsize,step): 
		c1 = struct.unpack('1d',d1[i:i+step])[0]
		c2 = struct.unpack('1d',d2[i:i+step])[0]
		#print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert abs(c1-c2) < 4.45e-15,'c1 != c2: %25.17g %25.17g, j = %d, c1-c2=%25.17g' % (c1,c2,3,c1-c2)

	current+=recordsize
	step = 4
	for i in range(current,current+step,step): 
		c1 = struct.unpack('1i',d1[i:i+step])[0]
		c2 = struct.unpack('1i',d2[i:i+step])[0]
		print i,c1,c2,c1==c2,c1-c2,(c1,c2)
		assert c1==c2,'c1 != c2: %d %d' % (c1,c2)
	current+=4
	print 'Valence checks out!'

