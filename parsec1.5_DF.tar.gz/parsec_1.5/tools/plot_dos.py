#!/usr/bin/env python

"""
@brief This program is used to plot density of states (DOS) from the output of 
PARSEC, i.e., parsec.out.
@author Grady Schofield - original version
@author Kai-Hsin Liou - rewrite kernel_density, support for output with multiple k-points
@date 2017-07-17
"""

### =========================================================================== 

import sys
import argparse
import re
import math
import matplotlib.pyplot as plt
import multiprocessing as mp

### =========================================================================== 

parser = argparse.ArgumentParser(description=
                                 'Plot density of state using parsec.out')

parser.add_argument('filename', type=str, nargs='?',
                    help='filepath to parsec.out')

help_str = 'the iteration you want to plot (there may be several SCF \
            in the parsec.out and one SCF may contain several iterations. \
            One has to count it to find the correct iteration number'
parser.add_argument('--iteration', type=int, nargs='?',
                    help=help_str)

parser.add_argument('--min', type=float, nargs='?',
                    help='minimum of the plot range in eV')

parser.add_argument('--max', type=float, nargs='?',
                    help='maximum of the plot range in eV')

parser.add_argument('--bin_size', type=float, nargs='?', default=0.01,
                    help='bin size of energy in eV')

parser.add_argument('--sigma', type=float, nargs='?', default=0.1,
                    help='the standard deviation of the gaussian function')

parser.add_argument('--procs', type=int, nargs='?', default=1,
                    help='the number of processes to calculate the density')

args = parser.parse_args()

### =========================================================================== 

def kernel_density(eig, occ, width, sigma, procs):

    def cidf(x, eig):
        integral1 = math.erf((x - eig + 0.5*width) / (sigma * 2**0.5))
        integral2 = math.erf((x - eig - 0.5*width) / (sigma * 2**0.5))
        return 0.5 * (integral1 - integral2)

    start = min(eig) - 5*sigma
    end = max(eig) + 5*sigma
    npnt = int(math.ceil((end - start)/width))
    xr = [(start + 0.5*width + width * i) for i in range(npnt)]
    chunk_size = int(math.ceil(len(xr)/procs))

    def density_cal(xr, d, proc):
        x_occ = []
        x_unocc = []
        y_occ = []
        y_unocc = []
        for x in xr:
            t_unocc = 0
            t_occ = 0
            for e, o in zip(eig, occ):
                if (x <= e + 5*sigma) and (x > e - 5*sigma):
                    # the factor "2" is due to two spin states per eigenvalue
                    t_occ += 2 * o * cidf(x, e) / width
                    t_unocc += 2 * (1 - o) * cidf(x, e) / width
            if t_occ > 0:
                x_occ.append(x)
                y_occ.append(t_occ)
            if t_unocc > 0:
                x_unocc.append(x)
                y_unocc.append(t_unocc)
        d[proc] = (x_occ, x_unocc, y_occ, y_unocc)

    d = mp.Manager().dict()
    p = []
    for i in range(procs):
        start = i * chunk_size
        end = start + chunk_size
        p.append(mp.Process(target=density_cal, args=(xr[start:end], d, i)))
        p[i].start()
    for i in range(procs):
        p[i].join()
    
    x_occ = []
    x_unocc = []
    y_occ = []
    y_unocc = []
    for i in range(procs):
        x_occ.extend(d[i][0])
        x_unocc.extend(d[i][1])
        y_occ.extend(d[i][2])
        y_unocc.extend(d[i][3])

    print("number of occupied states (integration) = %f" % (sum(y_occ)*width))
    print("number of unoccupied states (integration) = %f" % \
                                                    (sum(y_unocc)*width))
    print("total number of states (integration) = %f" % \
                                                    (sum(y_occ+y_unocc)*width))

    return x_occ, x_unocc, y_occ, y_unocc



def get_full_density(filename, iteration, min_eig, max_eig):
    
    # Find how many iterations there are
    total_iter = 0
    regex1 = 'SRE of pot. & charge weighted pot'
    with open(filename, 'r') as ifs:
        for line in ifs.readlines():
            if re.search(regex1, line):
                total_iter += 1
    print('There are %d iterations in total.' % total_iter)

    # Find the iteration block and add the eigenvalues and occupancies
    i = total_iter if iteration == None else iteration
    iteration_block_found = False
    eiglist = []
    occlist = []
    regex2 = 'State\s+Eigenvalue \[Ry\]\s+Eigenvalue \[eV\]\s+Occup.'
    with open(filename, 'r') as ifs:
        for line in ifs.readlines():
            if not iteration_block_found and re.search(regex2, line):
                i -= 1
                if i == 0:
                    iteration_block_found = True
            if iteration_block_found:
                m = re.search('^\s*\d+\s+\S+\s+(\S+)\s+(\S+)', line)
                if m:
                    eiglist.append(float(m.group(1)))
                    occlist.append(float(m.group(2)))
                    continue
                m = re.search('Max and min values', line)
                if m:
                    break

    # Find the Fermi level
    num_occ = sum([occ > 0.5 for occ in occlist])
    flevel = eiglist[num_occ-1]  # minus one here because Python starting 
                                 # from zero, but state # starting from 1
                                 # E.g., state 1 corresponds to eiglist[0]
    print('Fermi level at {} eV, eigenvalue number {}'.format(flevel, num_occ))
    print('(eigenvalue number is only for confined system)')

    # Shift the energy levels such that the Fermi level is at 0 eV
    shifted_eig = []
    for eig in eiglist:
        shifted_eig.append(eig - flevel)
    eiglist = shifted_eig

    return eiglist, occlist

### ===========================================================================

if __name__ == '__main__':

    filename = args.filename
    iteration = args.iteration
    min_eig = args.min
    max_eig = args.max
    bin_size = args.bin_size
    sigma = args.sigma
    procs = args.procs

    # Get the total charge
    data = open(filename, 'r').read()
    atom_type = []
    atom_number = []
    atom_charge = []
    for m in re.finditer('\s+There are\s+(\d+)\s+(\S+)\s+atoms', data):
        atom_type.append(m.group(2))
        atom_number.append(int(m.group(1)))
    for m in re.finditer('\s+ion charge\s+=\s+(\S+)', data):
        atom_charge.append(float(m.group(1)))
    m = re.search('\s+Number of states:\s+(\d+)', data)
    num_eigs = int(m.group(1))
    total_charge = sum([number * charge for (number, charge) \
                                            in zip(atom_number, atom_charge)])
    total_occ_states = total_charge / 2 * 2
    total_atoms = sum(atom_number)
    
    print("total_charge = %f" % total_charge)
    print("number of atoms = %d" % total_atoms)
    print("number of eigenvalues = %d" % num_eigs)
    print("number of states = %d" % (num_eigs*2))
    print("number of occupied states = %d" % total_occ_states)

    # eig = eigenvalues
    # occ = occupancies
    eig, occ = get_full_density(filename, iteration, min_eig, max_eig)
    x_occ, x_unocc, y_occ, y_unocc = kernel_density(eig, occ, bin_size,
                                                    sigma, procs)

    plt.plot(x_occ, [y/total_atoms for y in y_occ], color='r')
    plt.plot(x_unocc, [y/total_atoms for y in y_unocc], color='b')

    if min_eig != None:
        plt.xlim(xmin=min_eig) 
    if max_eig != None:
        plt.xlim(xmax=max_eig) 

    plt.ylim(ymin=0) 

    plt.xlabel('Energy (eV)')
    plt.ylabel('Density of States (states $\mathregular{atom^{-1}}$ $\mathregular{eV^{-1}}$)')
    #plt.savefig('output.png')
    plt.show()

