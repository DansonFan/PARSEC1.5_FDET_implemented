#!/bin/bash

# this is not recommended, experimental nesting
# for omp: use FLAGS_OMP.sh

NTHREADS=${1:-"17,4"}
SCHED=${2:-"Guided,256"} #need to tune this
#SCHED=${2:-"STATIC,256"} #need to tune this
AFFINITY=${3:-"spread,close"}
STACK_SET=${4:-"120M"} #dunno how much really
#KMP ONLY SETTINGS:
SLEEPTIME=${5:-"INFINITE"} #setting is intel only

export OMP_DYNAMIC=.FALSE.
export OMP_NUM_THREADS=$NTHREADS
export OMP_SCHEDULE=$SCHED
#settings from nersc: 
# intel mpi flags
export I_MPI_PIN_MODE=pm
export I_MPI_PIN_DOMEINA=auto:compact
# recommended omp 
# threads: Each place corresponds to a single hardware thread on the target machine.
# cores: Each place corresponds to a single core (having one or more hardware threads) on the target machine.
# sockets: Each place corresponds to a single socket (consisting of one or more cores) on the target machine.
export OMP_PLACES=threads
# Sets the thread affinity policy to be used for parallel regions at the
# corresponding nested level. Enables (true) or disables (false) the binding of
# threads to processor contexts. If enabled, this is the same as specifying
# KMP_AFFINITY=scatter. If disabled, this is the same as specifying
# KMP_AFFINITY=none.  Acceptable values: true, false, or a comma separated
# list, each element of which is one of the following values: master, close,
# spread.
# Default: false
export OMP_PROC_BIND=spread
# https://software.intel.com/en-us/node/522691 ::
export KMP_AFFINITY=noverbose,warnings,respect,granularity=fine,duplicates,scatter,0,0
#

# MKL only settings
# AJB: If you find that (finally) you don't need these, please let me know:
export MKL_NUM_THREADS=$NTHREADS
export MKL_DYNAMIC=false

export OMP_NESTED=.TRUE.
#export OMP_NESTED=.FALSE.
export KMP_HOT_TEAMS_MODE=1
export KMP_HOT_TEAMS_MAX_LEVEL=2
export OMP_MAX_ACTIVE_LEVELS=2

#note: KMP settings are for intel compilers only!

# Enables (1) or disables (0) the printing of OpenMP* run-time
# library environment variables during program execution. Two
# lists of variables are printed: user-defined environment
# variables settings and effective values of variables used by
# OpenMP* run-time library. 
export KMP_SETTINGS=1

# HOT TEAMS explanation !{{{
# intel compiler v>15.1
# HOT TEAMS EXPLANATION THANKS TO OUR KIND FRIENDS IN INTEL
# I could not find it anywhere else, maybe this will change with intel v16
# 
# “Hot Teams” is an extension to OpenMP supported by the Intel Runtimes that
# can substantially reduce the overhead of OpenMP parallelism. It works with
# standard OpenMP code but enhances performance. It is a logical extension that
# may inspire similar capabilities in other implementations.
# To understand “hot teams”, it is important to know that any modern implementation
# of OpenMP, in order to avoid the cost of creating and destroying
# pthreads, has the OpenMP runtime maintain a pool of OS threads (pthreads
# on Linux) that it has already created. This is standard practice in OpenMP
# runtimes because OS thread creation is normally quite expensive.
# However, OpenMP also has a concept of a thread team, which is the set of
# pthreads that will execute a given parallel region. The thread team is a set of
# internal data-structures that determine which pthreads will be used, what the
# enumeration is (value of ompgetthread − num()), values for OpenMP “internal
# control variables”, and how the runtime will communicate when performing
# barriers or fork/join using the team. Since its almost always the case that
# an OpenMP program will execute many parallel regions with the same set of
# parameters (number of threads), as well as keeping the threads themselves alive,
# we keep the team structure alive. Teams whose teams structure already exists
# are ”hot”, because we expect them to be reused, and we already have the data
# structure created, so avoid the cost of tearing it down at the end of a parallel
# region only to recreate it at the next.
# Traditionally, a runtime had only one hot team, for the top-level parallel
# region. Any teams used for nested parallel regions were created each time they
# were needed and destroyed again at the end of the parallel region.
# Since nested parallelism has become more important (for instance with people
# using 60 threads at the outer level, for a coprocessor, and then 60 four thread
# teams inside that), Intel implemented support for “nested hot teams”.
# These hot teams are controlled by the KMP HOT TEAMS environment variable.
# The value set will be the maximum depth for which hot teams will be maintained.
# The default is 1, which replicates the previous behaviour so that only
# the outermost parallel region is treated as a hot team.
# By setting KMP HOT TEAMS=2, the team structures will be maintained for
# two levels of parallelism. For this to make sense you also must have have



# Sets the number of bytes to allocate for each OpenMP* thread to use as the
# private stack for the thread. Recommended size is 16M.  Use the optional
# suffixes: B (bytes), K (Kilobytes), M (Megabytes), G (Gigabytes), or T
# (Terabytes) to specify the units. If only value is specified, the size is
# assumed to be K (Kilobytes).  This variable does not affect the native
# operating system threads created by the user program nor the thread executing
#
# NOTE: the thread stack is where all "private" type variables are allocated
export OMP_STACKSIZE=$STACK_SET
#export OMP_STACKSIZE="4M"

# Decides whether threads spin (active) or yield (passive) while
# they are waiting. OMP_WAIT_POLICY=ACTIVE is an alias for
# KMP_LIBRARY=turnaround, and OMP_WAIT_POLICY=PASSIVE is an alias
# for KMP_LIBRARY=throughtput.
#export OMP_WAIT_POLICY=active
export OMP_WAIT_POLICY=passive

# Sets the time, in milliseconds, that a thread should wait, after completing the
# execution of a parallel region, before sleeping.  Use the optional character
# suffixes: s (seconds), m (minutes), h (hours), or d (days) to specify the
# units.  Default: 200 milliseconds
#turning off for a while
export  KMP_BLOCKTIME=$SLEEPTIME
