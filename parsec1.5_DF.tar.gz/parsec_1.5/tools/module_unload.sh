#!/bin/bash
# gets a list of modules and unloads, in reverse order, all but the first one
# This is useful when avoiding the purge command, but does require support for
# the long form print (-l,--long) for modules. And standard pipes....
# @author charles lena, utaustin, center for computational materials
# @date   2017-07-25
echo "$*"
NUM_TO_KEEP=${1:-"1"}
echo ${NUM_TO_KEEP}
moduleslist=(`module -l list 2>&1 | awk 'NR >= 3 { print $1 }'`)
tLen=${#moduleslist[@]}
for(( i=0 ; i < $tLen ; i++ )) ; do
	echo $i, ${moduleslist[$i]}
done
# use CLI to stop this in the future
if (( 1 )) ; then
for offset_from_end in `seq 0 $(( ${tLen}-1-${NUM_TO_KEEP} ))` ; do
	echo "module unload ${moduleslist[$(( ${tLen} - 1 - ${offset_from_end} ))]}"
	module unload ${moduleslist[$(( ${tLen} - 1 - ${offset_from_end} ))]}
done
fi
