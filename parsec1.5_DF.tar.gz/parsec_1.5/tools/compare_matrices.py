#!/usr/bin/env python
__docstring__ = """This program serves to allow for a shortcut to "diffing" a matrix"""
import argparse, os, re, numpy, matplotlib.pyplot as plt
try:
    import scipy.io.FortranBinary as fortfile
    USEHACK=False
except Exception as err:
    from numpy import __version__ as numpyvers
    from scipy import __version__ as scipyvers
    print('your version of scipy is too old to use fortran binary files easily')
    print('numpy:', numpyvers)
    print('scipy:', scipyvers)
    import numpy as np
    USEHACK=True


parser = argparse.ArgumentParser()
parser.add_argument('files', nargs=2, type=argparse.FileType('r'))
parser.add_argument('-c','--comment', type=str, default='#')
parser.add_argument('-T','--textonly', action='store_true', default=False)
parser.add_argument('--digitround', type=int, default=14)
parser.add_argument('--binary', action='store_true', default=False)
parsed = parser.parse_args()
print(parsed)

def loading_mat(parserOpts,i_file):
    with parserOpts.files[i_file] as file1:
        if not parserOpts.binary:
            mat = np.loadtxt(file1)
        else:
            rank = np.fromfile(file1, dtype=np.int32, count=3)[1]
            shape = np.fromfile(file1, dtype=np.int32, count=2+rank)[1:1+rank]
            trashed = np.fromfile(file1, dtype=np.int32, count=1)
            mat = np.array(np.fromfile(file1, dtype=np.float64, count=np.product(shape)),order='F')
            mat.shape = shape[::-1]
            print shape
    return mat

mat1 = loading_mat(parsed, 0)
mat2 = loading_mat(parsed, 1)

# force a cutoff threshold in base 10 digits
matdiff = np.round(mat1-mat2, parsed.digitround)
if len(mat1.shape)==1:
    labels = np.array(['({0:07d}) : {1:26e} {2:26e} {3:26e}'.format(i, mat1[i], mat2[i], matdiff[i]) for i in range(matdiff.shape[0])],dtype=str)

if len(mat1.shape)==2:
    labels = np.array(['({0:04d},{1:04d}) : {2:16e} {3:16e} {4:16e}'.format(i,j, mat1[i,j], mat2[i,j], matdiff[i,j]) for j in range(matdiff.shape[1]) for i in range(matdiff.shape[0])],dtype=str, order='F')

def matinfo(mat): print('{min:f} {max:f} {range:f}'.format(min=np.min(mat1),max=np.max(mat),range=np.max(mat)-np.min(mat)))

matinfo(mat1)
matinfo(mat2)
labels.shape = matdiff.shape
labeldiff = labels[matdiff != 0]
for entry in labeldiff: print(entry)


if not parsed.textonly:
    f, axarr = plt.subplots(2,2)
    axarr[0,0].spy(np.transpose(mat1))
    axarr[0,1].spy(np.transpose(mat2))
    axarr[1,0].spy(np.transpose(matdiff))
    axarr[1,1].imshow(np.transpose(mat2),cmap=plt.cm.rainbow,interpolation='none')
    plt.show()
