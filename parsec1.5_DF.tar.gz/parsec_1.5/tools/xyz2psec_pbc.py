#!/usr/local/bin/python
# Script by Amir Natan to convert from xyz to parsec
# uses the wonderful ASE package
# added here a wrap to take a pbc ase to parsec
# can take also traj file
from ase import Atoms
from ase.io import read
from ase.io import write
from ase.units import Bohr

import sys, getopt
import numpy as np
import argparse


def main(argv):
   parser = argparse.ArgumentParser()
   inputfile = ''
   outputfile = ''
   parser.add_argument('-i',required=True,help='name of xyz file',dest='inputfile')
   parser.add_argument('-o',required=True,help='name of OUT file (parsec input)',dest='outputfile')

   args=parser.parse_args()
   
   atoms=read(args.inputfile)
   atoms.wrap(True)   
   #atoms=read(args.inputfile,0,'xyz');

   latt_param=atoms.cell[0][0]
   latt_param_bohr=latt_param/Bohr
   f=open(args.outputfile,'w');
   latt_form = ' %11.6f'
   cform = ' %9.6f'

   f.write('# system: %s\n\n\n' %atoms)

   f.write('Boundary_Conditions: bulk\n\n')
   f.write('Lattice_Vector_Scale:  %f\n'  %latt_param_bohr)
   f.write('begin Cell_shape\n')
   f.write('1.0  0.0 0.0  \n')
   f.write('0.0  1.0  0.0 \n')
   f.write('0.0  0.0  1.0 \n')
   f.write('end cell_shape\n\n\n')

   #f.write('Boundary_Sphere_Radius: %d\n\n'%radius)
   f.write('Coordinate_Unit: cartesian_ang\n\n')
   f.write('Grid_Spacing:  0.40\n');
   f.write('States_Num:  NUM_STATES\n')
   f.write('Fermi_Temp: 10\n')
   #f.write('Max_Iter:  66\n\n')
   f.write('Correlation_Type: ca\n\n')
   coord = atoms.get_positions()
   ind = np.argsort(atoms.get_chemical_symbols())
   symbols = np.array(atoms.get_chemical_symbols())[ind]
   coord = coord[ind]
   uu=len(symbols)
#   f.write('number of symbols is %d\n'%uu)
#   f.write('%s\n'%symbols[0])
   ij=0
   csym=symbols[0]
   usym=symbols[0]
   itype=1
   for iatom, atom in enumerate(coord):
       if ij==0:
         f.write('Atom_Type: %s\n'%usym)
         f.write('Local_Component: LOCAL_COMP\n\n')
         f.write('begin Atom_Coord\n')
       csym=usym
       usym=symbols[ij]
       if csym != usym:
         f.write('end Atom_Coord\n\n\n')
         f.write('Atom_Type: %s\n'%usym)
         f.write('Local_Component: LOCAL_COMP\n\n')
         f.write('begin Atom_Coord\n')
         itype=itype+1
       ij=ij+1
       for coord in atom:
           f.write(cform % coord)
       f.write('\n')
   f.write('end Atom_Coord\n\n\n')
   f.write('Atom_Types_Num: %d\n\n\n'%itype)



if __name__ == "__main__":
   main(sys.argv[1:])


