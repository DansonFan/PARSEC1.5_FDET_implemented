#!/usr/bin/env python3

"""
Generate the HDF5 file with the grid data extracted from PARSEC HDF5 files,
missing entries being filled with zeros.
Also the script will generate the corresponding XDMF file for Paraview.

NOTE: So far I have only tested 0D non-spin-polarized calculation.

Usage: python3 ./generate_h5array_xmf.py



Reference:

[1] Matlab 3D array to ParaView (via HDF5 + XDMF)
https://www.mathworks.com/matlabcentral/fileexchange/82043-matlab-3d-array-to-paraview-via-hdf5-xdmf
[2] https://www.xdmf.org/index.php/Main_Page

Author: Kai-Hsin Liou (lioukaihsin@utexas.edu)
Date of latest update: September 2021
"""

# ==================================
#    User input
# ==================================

# Arrays to plot (list the available arrays can be checked using HDF5 tools,
# for example,
# > h5ls -r parsec_move00000_iter00023.h5
#
# Here are some examples
#
# Hartree potential: vhart
# Ionic potential: vion
# Exchange-correlation potential: vxc
# Electron density: rho
# Wave function of (istate,irp,kplp,isp) = (10,1,1,1): wfn_10_1_1_1
# Note: the indii here start at 1
#
arrays_to_plot = [
        "vion",
        "vhart",
        "wfn_1_1_1_1",
        "wfn_2_1_1_1",
        "vxc",
        "rho",
        "wfn_3_1_1_1",
        "wfn_4_1_1_1",
        "wfn_76_1_1_1",
        "wfn_77_1_1_1",
        ]

# Path to the PARSEC HDF5 file
parsec_h5_path = "./parsec_move00000_iter00023.h5"

# Filename of the output files (output_name.h5 and output_name.xmf)
output_name = "my_grid_data"



# ==================================
#  Main program
# ==================================

import h5py
import re
import os
import numpy as np


if not os.path.exists(parsec_h5_path):
    raise ValueError('h5 file does not exist')


ifs = h5py.File(parsec_h5_path, 'r')


type_num = ifs['/clust'].attrs['clust%type_num'][0]
atom_num = ifs['/clust'].attrs['clust%atom_num'][0]
atype_name = ifs['/clust/clust%name(:)'][0]
natmi = ifs['/clust/clust%natmi(:)'][0]
xatm = ifs['/clust/clust%xatm(:)'][0]
yatm = ifs['/clust/clust%yatm(:)'][0]
zatm = ifs['/clust/clust%zatm(:)'][0]
kx = ifs["/grid/grid%kx(:)"][0]
ky = ifs["/grid/grid%ky(:)"][0]
kz = ifs["/grid/grid%kz(:)"][0]

step = ifs["/grid"].attrs["grid%step(:)"]
shift = ifs["/grid"].attrs["grid%shift(:)"]


my_labels = []

volume_data = []

for array_name in arrays_to_plot:
    if "rho" in array_name:
        # rho(:,:) has a shape of (nspin, N_grid)
        rho = ifs["/elec_st/elec_st%rho(:,:)"]
        spnum = int((rho.shape[0] + 1)/2)
        volume_data.append(rho[0,:])
        my_labels.append(array_name)

    elif "vion" in array_name:
        vion = ifs["/pot/pot%vion(:)"][0]
        volume_data.append(vion[:])
        my_labels.append(array_name)

    elif "vxc" in array_name:
        vxc = ifs["/pot/pot%vxc(:,:)"]
        volume_data.append(vxc[0,:])
        my_labels.append(array_name)

    elif "vhart" in array_name:
        vhart = ifs["/pot/pot%vhart(:)"][0]
        volume_data.append(vhart[:])
        my_labels.append(array_name)

    elif "wfn" in array_name:
        istate, irp, kplp, isp = \
                re.search("wfn"+"_(\d+)"*4, array_name).groups()

        print("Reading in the wfn of state {}".format(istate))
        wfn_dataset = ifs["/elec_st/isp" + isp.zfill(5) + \
                          "/kplp" + kplp.zfill(5) + \
                          "/irp" + irp.zfill(5) + \
                          "/wavefunctions(:,:)"]

        # '-1' because wfns starts at 0
        volume_data.append(wfn_dataset[int(istate)-1,:])
        my_labels.append(array_name)

    else:
        raise ValueError('unrecognizable array name {}'.format(array_name))





ifs.close()




print("Number of volume data = {}".format(len(volume_data)))





# ============
#  Atom coordinates
# ============
# Writing out the structure of the molecule
ofs = open(output_name+".xyz", 'x')
ofs.write('{}\n'.format(atom_num))
ofs.write('The coordinates are in bohrs.\n')

iatom = 0
for itype in range(type_num):
    for jj in range(natmi[itype]):
        iatom += 1

        ofs.write('{} {} {} {}\n'.format(atype_name[itype].decode('ascii'),
            xatm[iatom-1], yatm[iatom-1], zatm[iatom-1]))

ofs.close()

print('There should be {} atoms'.format(atom_num))
print('We read in {} atoms'.format(iatom))










# Prepare for outputting

# Calculate the number of grids along each axis
grid_points_number = (max(kx) - min(kx) + 1, \
                      max(ky) - min(ky) + 1, \
                      max(kz) - min(kz) + 1)

# Create the conversion list
#   For example, (kx[20], ky[20], kz[20]) = (-5, 0, 1) and
#   (min(kx), min(ky), min(kz)) = (-25, -25, -25), then
#   grid_points_1d[20][25][26] = 20
grid_points_1d = [[[-1 for k in range(grid_points_number[2])] \
                       for j in range(grid_points_number[1])] \
                       for i in range(grid_points_number[0])]

print(np.array(grid_points_1d).shape)

grid_min = (min(kx), min(ky), min(kz))

for igrid in range(len(kx)):
    i = kx[igrid] - grid_min[0]
    j = ky[igrid] - grid_min[1]
    k = kz[igrid] - grid_min[2]
    grid_points_1d[i][j][k] = igrid

fx = (np.array(range(grid_points_number[0])) + grid_min[0] + shift[0])*step[0]
fy = (np.array(range(grid_points_number[1])) + grid_min[1] + shift[1])*step[1]
fz = (np.array(range(grid_points_number[2])) + grid_min[2] + shift[2])*step[2]

print(fx)






# Start writing to the output file
ofs = open(output_name+".xmf", 'x')


ofs.write('<?xml version="1.0" ?>\n')
ofs.write('<!DOCTYPE Xdmf SYSTEM "Xdmf.dtd" []>\n')
ofs.write('<Xdmf Version="2.0">\n')
ofs.write('<Domain>')
ofs.write('<Grid Name="mesh" GridType="Uniform">\n')
ofs.write('<Topology TopologyType="3DRectMesh" ' + \
        'NumberOfElements="{} {} {}"/>\n'.format(*grid_points_number))

ofs.write('<Geometry GeometryType="VXVYVZ">\n')


ofs.write('<DataItem ' + \
        'Name="coordx" ' + \
        'Dimensions="{}" '.format(grid_points_number[0]) + \
        'NumberType="Float" Precision="8" Format="HDF">\n')
ofs.write(output_name + '.h5:/fx\n')
ofs.write('</DataItem>\n')

ofs.write('<DataItem ' + \
        'Name="coordy" ' + \
        'Dimensions="{}" '.format(grid_points_number[1]) + \
        'NumberType="Float" Precision="8" Format="HDF">\n')
ofs.write(output_name + '.h5:/fy\n')
ofs.write('</DataItem>\n')

ofs.write('<DataItem ' + \
        'Name="coordz" ' + \
        'Dimensions="{}" '.format(grid_points_number[2]) + \
        'NumberType="Float" Precision="8" Format="HDF">\n')
ofs.write(output_name + '.h5:/fz\n')
ofs.write('</DataItem>\n')




ofs.write('</Geometry>\n')

ofs.write('<Time TimeType="Single" Value="0"/>\n')

for my_label in my_labels:
    ofs.write('<Attribute ' + \
            'Name="{}" '.format(my_label) + \
            'AttributeType="Scalar" Center="Node">\n')
    ofs.write('<DataItem Dimensions="{} {} {}" '.format(
            *grid_points_number) + \
            'NumberType="Float" Precision="8" Format="HDF">\n')
    ofs.write(output_name + '.h5:/{}\n'.format(my_label))
    ofs.write('</DataItem>\n')
    ofs.write('</Attribute>\n')

ofs.write('</Grid>\n')
ofs.write('</Domain>\n')
ofs.write('</Xdmf>\n')



ofs.close()








f = h5py.File(output_name+'.h5', 'w')

dset = f.create_dataset("fx", (len(fx),), dtype='f')
dset[:] = fx
dset = f.create_dataset("fy", (len(fy),), dtype='f')
dset[:] = fy
dset = f.create_dataset("fz", (len(fz),), dtype='f')
dset[:] = fz

for kk, vol in enumerate(volume_data):
    print("outputting {}".format(my_labels[kk]))
    dset = f.create_dataset(arrays_to_plot[kk],
            (grid_points_number[2],
             grid_points_number[1],
             grid_points_number[0]), dtype='f')

    for i in range(grid_points_number[0]):
        for j in range(grid_points_number[1]):
            for k in range(grid_points_number[2]):
                    if grid_points_1d[i][j][k] != -1:
                        # Note that Python is column-major while HDF5 is
                        # row-major
                        dset[k,j,i] = vol[grid_points_1d[i][j][k]]
                    else:
                        dset[k,j,i] = 0


f.close()


