#!/usr/bin/env python
__docstring__ = """in charge of all the little functions that allow taking a parsec.out + data into various formats. the file should
focus on parsec.out"""

from parsecout import parsecout

import argparse
argparser = argparse.ArgumentParser()
argparser.add_argument("infile",type=str,help='path/filename to parsec.out')

if __name__ == "__main__":
	parsed = argparser.parse_args()
	with open(parsed.infile,'r') as infile:
		parsecout(parsed.infile)
