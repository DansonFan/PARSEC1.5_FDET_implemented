#!/bin/bash
#SBATCH --job-name=Si837
#SBATCH --output=myjob.o%j
#SBATCH --error=myjob.e%j
#SBATCH --qos=debug
#SBATCH --nodes=4
#SBATCH --tasks-per-node=8
#SBATCH --cpus-per-task=32
#SBATCH --time=30
#SBATCH -C knl

export OMP_PROC_BIND=true
export OMP_PLACES=threads
export OMP_NUM_THREADS=8

srun --cpu-bind=cores ../../src/parsec-cori_knl_intel-ftn-ifort-18.0.1.mpi
