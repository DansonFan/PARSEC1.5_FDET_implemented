#!/bin/bash

if [ $# -eq 0 ]
then
        echo "Please assign an output file"
        exit
fi

if [ ! -e $1 ]
then
        echo "File $1 doesn't exist"
        exit
fi

for step in FLTR ORTH PROJ DCMP UPDT
do
        cost=`grep $step $1 | awk '{sum += $3; n++} END { if (n > 0) printf "%8.2f", sum / n; }'`
        echo -e "$step took ${cost} secs"
done

cost=`grep LOOP $1 | awk '{sum += $3; n++} END { if (n > 0) printf "%8.2f", sum / n; }'`
echo -e "On average, each Chebyshev-filtered subspace iteration took ${cost} secs"
