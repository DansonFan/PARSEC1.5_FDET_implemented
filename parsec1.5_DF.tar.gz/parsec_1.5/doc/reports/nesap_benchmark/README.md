# Baseline benchmark problem

## Description

PARSEC: Pseudopotential Algorithm for Real-Space Electronic structure 
Calculation is a code to calculate electronic structure of various systems 
(confined and periodic systems), based on Kohn-Sham density functional theory. 
The default eigensolver in PARSEC is Chebyshev-filtered subspace iteration 
(CheFSI) method, which consists of filtering, orthonormalization, 
and Rayleigh-Ritz rotation (which can be further divided into three steps: 
projection, decomposition, and update). In this benchmark, we will calculate 
the electronic structure of a medium-sized silicon nanocrystal for 
one iteration. From the timing of only one iteration, we can have 
an idea of the time-to-solution when seeking for converged results.

The results from running on Edison and Cori KNL serve as a baseline benchmark
for further testing on the Perlmutter supercomputer.

Definition of the benchmark: This benchmark will do electronic structure 
calculation on a medium-sized silicon nanocrystal. The timing of each step 
of the solver will be measured.

References:

* https://parsec.ices.utexas.edu/
* Y. Zhou, J.R. Chelikowsky and Y. Saad: Chebyshev-filtered subspace iteration method free of sparse diagonalization for solutions of the Kohn-Sham equation, J. of Comp. Phys. 274, 770 (2014).



## Figure of Merit

Cost of each step (filtering (FLTR), orthonormalization (ORTH), 
projection (PROJ), decomposition (DCMP), and update (UPDT) in one CheFSI cycle 
will be measured and serves as the figure of merit.

In this benchmark we will perform four CheFSI cycles and take the average.
For this confined system, the required number of CheFSI cycles for converged 
result is 20-30. As a result, the time cost for one CheFSI cycle (and each step)
can serve as an indicator of the total time we will need to spend, and the 
performance of the different supercomputers on the same problem.



# Measurement on Edison

The measurement on Edison will be done with 4 nodes (MPI tasks x Threads = 32 x 3)

```shell
edison$ cd ./src && make MACH=edison_intel clean && make MACH=edison_intel -j8 && cd ../
edison$ cd ./benchmark/Si837H348/
edison$ sbatch run-edison.sh
Submitted batch job 13150209
edison$ ./figure-of-merit.sh out.000000
FLTR took    76.63 secs
ORTH took     7.58 secs
PROJ took    14.93 secs
DCMP took     1.04 secs
UPDT took    10.29 secs
On average, each Chebyshev-filtered subspace iteration took   121.85 secs
```

Besides the timing, we can also check the total evergy per atom in parsec.out
to see if the calculation is physically correct.



# Measurement on Cori KNL

The measurement on Cori KNL will be done with 4 nodes (MPI tasks x Threads = 32 x 8)

```shell
cori$ cd ./src && make MACH=cori_knl_intel clean && make MACH=cori_knl_intel -j8 && cd ../
cori$ cd ./benchmark/Si837H348/
cori$ sbatch run-cori-knl.sh
Submitted batch job 20774317
cori$ ./figure-of-merit.sh out.000000
FLTR took   129.68 secs
ORTH took     4.01 secs
PROJ took    11.47 secs
DCMP took     1.83 secs
UPDT took     3.63 secs
On average, each Chebyshev-filtered subspace iteration took   156.65 secs
```



# Epilog

The timing for one CheFSI cycle (and each step) can be used to estimate 
the time-to-solution for systems with similar size (similar Hamiltonian size 
and number of states, which are recorded in parsec.out). Also by changing the 
grid spacing (affecing Hamiltonian size) and number of states to be computed 
(more unoccupied states), we can examine the scaling of each step using the 
same physics problem. Based on this scaling test, we can get an idea of how 
long it will take to calculate the electronic structure of other types of 
systems. 

Here shows the time complexity of each step

| Operation | Time Complexity |
| ------ | ------ |
| FLTR | O(*Nsm*)  |
| ORTH | O(*N* *s*^2) | 
| PROJ | O(*N* *s*^2) | 
| DCMP | O(*s*^3)  | 
| UPDT | O(*N* *s*^2) | 

Note: *N* is the number of grid points, *s* is the number of states, and 
*m* is the degree of the Chebyshev filter.

Here are the strong scaling test on Edison. Note that the number of states 
here is twice of that in the benchmark, so that the filtering time cost is 
almost doubled (assuming both used 4 nodes on Edison).
Also note that the (MPIs x Threads) is different. The scaling plot used 96x1, 
while the benchmark used 32x3. The configuration of (MPIs x Threads) will 
influence the prefactor of the scaling of each step.
In the speedup plot, we also include the results when 2D process grid is used
(denoted "2D" in the legend). 2D process grid enables (embarrassing) 
parallelization along the states at filtering step, and the improvement is 
evident when over hundreds of MPI tasks are available. However, in this 
benchmark we will only use 32 MPI tasks, so 2D process grid will not be used.

<img src="./figures/strong_scaling_time.png" alt="Strong scaling time" width="400" height="300">
<img src="./figures/strong_scaling_speedup.png" alt="Strong scaling speedup" width="400" height="300">










The converged result of this example is included in 
./benchmark/Si837H348/ref/converged/.
