#!/usr/bin/env python
"""
@file
@brief Preprocessing helper
@author Charles Lena
@date JAN 15 2017

    This file helps sanitize preprocessing terms
    as well as provides basic _SELECTIVE_ preprocessing.
    This cannot replace the internal fortran pre processor of gfortran
    or ifort for purposes of compiling the code, as it defines various 
    necessary macros according to mpi and openmp standards, but it can
    get the majority of this stuff done now, done here. And in a jiffy
    provide proper error line numbers relative to the *original file*
    instead of the temporary file.
"""
import re, sys, os, subprocess
import argparse, itertools
#====================== CONSTANTS
def doNothing(*args, **kwargs): return

class InvalidPairing(Exception):
    def __init__(self, line_num, filename=None):
        Exception.__init__(self, "Mismatch command on Line: {:d}".format(line_num))

class UnterminatedConditional(Exception):
    def __init__(self, line_num, macro_buffer=None, filename=None):
        msg = "EOF ({filename:s}:{line_num:d}) Without Preprocessor Level Termination!".format(
                        filename=filename,
                        line_num=line_num)
        if macro_buffer: 
            likely_offender = next(ibuffer for ibuffer in reversed(macro_buffer) if (ibuffer[0]==0))
            msg += "\nerror:{filename:s}:{off_line_num:d}: Unterminated Conditional\n{line:s}".format(
                        filename=filename,
                        off_line_num=likely_offender[1],
                        line=likely_offender[2])
        else:
            msg += "Provide macro_buffer to function fo find it!"
        Exception.__init__(self, msg)

def check_malformed(lsearch):
    if lsearch:
            if len(lsearch.group('leading_spaces')) > 0 : print("Bad PREPROCESSOR Line {:d}. Must start at beginning of line\n{:s}".format(line_num_offset, line))

class preprocessor_command:
    def __init__(self, command, new_group, end_group, sub_group, matching_commands=list(),
            valuesfxn = doNothing(), tokenizer = doNothing()):
        self.command = command
        self.new_group = new_group
        self.end_group = end_group
        self.sub_group = sub_group
        self.matching_commands = matching_commands
        self.valuesfxn = valuesfxn
        self.tokenizer = tokenizer

    def __str__(self):
        return self.command

    def __repr__(self):
        outstr = str(type(self))
        return outstr[0:-1]+": '{:s}'".format(self.command)+outstr[-1]

def obsoleteError():
    def _callable(*args,**kwargs):
        raise Exception("Obsolete. Eliminate.")
    return _callable

def compatibility_warning():
    def _callable(*args,**kwargs):
        raise Exception("incompatible with crossplatform efforts")
    return _callable

def t_FILEPATH(command, spaces, restofline):
    out = re.search(r"[\<\"](\S*)[\>\"]$",restofline)
    return out

def t_NUM_MESSAGE(command, spaces, restofline):
    out = re.search(r"([0-9])+\s+(?P<quote>[\'\"])(\S*)\g<quote>$", restofline)
    return out

def t_MESSAGE(command, spaces, restofline):
    out = re.search(r".*$", restofline)
    return out

def t_CONDITIONAL(command, spaces, restofline):
    out = re.search(r".*", restofline)
    return out

def t_NONE(command, spaces, restofline):
    # friggen None objects
    print restofline
    if not restofline:
        return list()
    else:
        err = Exception('Unexpected Input:\n{:s}'.format(restofline))
        raise err
    return list()

def t_TOKEN(command, spaces, restofline):
    out = re.search(r"([_A-Za-z][A-Za-z_0-9]+)", restofline)
    return out

def t_TOKEN_MESSAGE(command, spaces, restofline):
    out = re.search(r"([_A-Za-z][A-Za-z_0-9]+)(\s+)*(\S+)*", restofline)
    return out

command_data = [
    ('include',False, False, False, list(), doNothing, t_FILEPATH),
    ('warning',False, False, False, list(), doNothing, compatibility_warning()),
    ('assert', False, False, False, list(), doNothing, obsoleteError()),
    ('unassert',False,False, False, list(), doNothing, obsoleteError()),
    ('import', False, False, False, list(), doNothing, t_FILEPATH),
    ('ident',  False, False, False, list(), doNothing, compatibility_warning()),
    ('line',   False, False, False, list(), doNothing, t_NUM_MESSAGE),
    ('error',  False, False, False, list(), doNothing, t_MESSAGE),
    ('if',      True, False, False, list(), doNothing, t_CONDITIONAL),
    ('ifndef',  True, False, False, list(), doNothing, t_TOKEN),
    ('ifdef',   True, False, False, list(), doNothing, t_TOKEN),
    ('endif',  False,  True,  True, list(('if','ifndef','ifdef','elif','else')), doNothing, t_NONE),
    ('else' ,  False, False,  True, list(('if','ifndef','ifdef','elif')), doNothing, t_NONE),
    ('elif' ,  False, False,  True, list(('if','ifndef','ifdef')), doNothing, t_CONDITIONAL),
    ('undef',  False, False, False, list(('define',)), doNothing, t_TOKEN), # pop
    ('define', False, False, False, list(('undef',)), doNothing, t_TOKEN_MESSAGE) # push
]

command = dict()
for command_tuple in command_data:
    command[command_tuple[0]] = preprocessor_command(*command_tuple)

def parse_file_with_ifdefs(filename=None, file_handle=None, defines_to_ignore = list(), line_num_0=1):
    try:
        with open(filename, 'r') as file_h:
            file_data = file_h.read()
    except:
        with filename as file_h:
            file_data = file_h.read()

    with open('log.txt','w') as log:

        group_cur = 0
        depth_cur = 0
        group_count = 0
        line_num_offset = 0
        defined_infile = list()
        module_depth = list()
        define_depth = list()
        stack_buffer = list()
        macro_buffer = list()
        log.write('Line# count cur depth command ppline\n')
        for line in file_data.splitlines():
            line_num = line_num_0 + line_num_offset
            lsearch = re.search(r'^(?P<leading_spaces>\s*)#(?P<ppcommand>[a-zA-Z_0-9]+)(?P<spaces>\s+)*(?P<ppline>.+)*',line)
            if lsearch : 
                alias = command[lsearch.group('ppcommand')]
                isGroup = any([alias.new_group, alias.end_group, alias.sub_group]) 
                group_cur = group_count + int(alias.new_group)
                depth_cur = depth_cur - int(alias.end_group or alias.sub_group)
                log.write(repr(('#{:d}'.format(line_num), (group_count if isGroup else None), 
                        group_cur, depth_cur, 
                        lsearch.group('ppcommand') if lsearch.group('ppcommand') else None,
                        lsearch.group('ppline') if lsearch.group('ppline') else None))+'\n')
                try: 
                    alias.tokens = alias.tokenizer(lsearch.group('ppcommand'), 
                            lsearch.group('spaces'), lsearch.group('ppline'))
                except Exception as e:
                    print(e)
                    print(line)
                    print(lsearch.groups())
                    raise(e)

                macro_buffer.append((group_cur, depth_cur, line_num, line, alias))
                depth_cur = depth_cur + int(alias.new_group) + int(alias.sub_group) - int(alias.end_group)
                group_cur = group_cur - int(alias.end_group)
                group_count = group_count + int(alias.new_group)
                if(depth_cur < 0): 
                    err = InvalidPairing(line_num)
                    raise err

            line_num_offset = line_num_offset + 1

        if(depth_cur != 0): 
            err = UnterminatedConditional(line_num, macro_buffer, filename=filename)
            log.write(err)
            raise err

    return (macro_buffer, file_data)

def rough_preprocess_1token(macro_buffer, file_data, defines, undefines):
    for entry in reversed(macro_buffer):
        print entry
        if entry[-1].tokens: print entry[-1].tokens.groups()

    return outs


if __name__ == '__main__':
    import argparse, sys
    parser = argparse.ArgumentParser('Selective collapsing of preprocessing language')
    parser.add_argument('--test', action='store_true', default=False, help='runs a unit test with a simulated file')
    parser.add_argument('-E', action='store_true', dest='redir_to_stdout', default=False, help='directs output to standard out')
    parser.add_argument('-D', action='append', dest='defines', default=list(), help='defines a symbol in the context of a preprocessor.') 
    parser.add_argument('-U', action='append', dest='undefines', default=list(), help='undefines a symbol in the context of a preprocessor. Not supremely useful at this point')
    if not sys.stdin.isatty():
        stdin = sys.stdin.readlines()
    else:
        parser.add_argument('infile', type=argparse.FileType('r'), action='append', default=list())
    parser.add_argument('outfile', type=argparse.FileType('w'), action='append', default=list())

    parsed = parser.parse_args()
    if(parsed.test):
        for file_h in glob.iglob('test.F90'):
            outs = parse_file_with_ifdefs(file_h)
    else:
        if(parsed.infile):
            for file_h in parsed.infile:
                outs = parse_file_with_ifdefs(file_h)
                rough_preprocess_1token(defines=parsed.defines, undefines=parsed.undefines,
                        file_data=outs[1], macro_buffer=outs[0])
