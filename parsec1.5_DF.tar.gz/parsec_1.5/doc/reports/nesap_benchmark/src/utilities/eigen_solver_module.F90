
! ==================== solver  structure ========================
module eigen_solver_module
  use constants
  use dlaplacian_module
  use stencil_things, only : stencil_definitions, fold_stencil
  use aux, only : alccheck
  implicit none

  type  eigen_solver

     ! eigensolver flag
     integer :: name

     ! diagonalization tolerance
     real(dp) :: toler

     ! dynamic diagonalization tolerance
     logical :: dyntol

     ! dynamic diagonalization tolerance
     real(dp) :: dtoler(2)
     real(dp) :: dyntoler

     ! order of multipole expansion used in computation of
     ! the Hartree potential (MAXIMUM VALUE CURRENTLY SUPPORTED - 9)
     integer :: lpole

     ! full_hartree_flag - if true - a full hartree calculation is 
     ! done for the boundaries instead of the multipole expansion. this
     ! is needed in some cases where the multipole expansion is not appropriate
     ! (for example - long cylinder).

     logical :: full_hartree_flag

     ! maximum number of matrix-vector multiplications allowed.
     integer :: maxmv
     ! number of matrix-vector multiplications performed (for
     ! statistics purposes only)
     integer :: totalmv

     ! number of additional eigenstates to be computed for each
     ! representation (important if first guess of eigenvalues is too
     ! different from the converged ones)
     integer :: nadd
     ! not used anymore
     ! integer :: kss0

     ! window size (used in chebdav)
     integer :: winsize
     ! polynomial degree for chebff and chebdav (Chebyshev-Davidson), first diagonalization only
     integer :: polym0, ff_maxiter
     integer :: num_lancz_bound !< number of lanczos bound steps
integer :: boundsmethod !< which bounds method to use
     ! whether to use Yunkai's scaled cheb or regular one (also in chebff!)
     logical :: scaledcheb
     ! polynomial degree for Chebyshev filtering
     integer :: polym
     integer :: polym_t
     ! delta_degree: difference between the polynomial degree used at low
     ! energy versus high energy.
     integer :: dpm

     ! input/output flag (input is used by ARPACK only, as flag for
     ! residue restart vector)
     integer, dimension (:,:,:), pointer :: info
     ! residual restart vector, used only for arpack
     complex(dpc), dimension (:,:,:,:), pointer :: zres_res
     real(dp), dimension (:,:,:,:), pointer :: res_res
     ! ! residual norms, used only for diagla
     ! real(dp), dimension (:,:,:,:), pointer :: resn
     ! distributed diagonal part of Hamiltonian
     real(dp), dimension (:), allocatable :: adiag
! I think this only aligns the pointer, not the data :(
#ifdef IS_ICC
!DIR$ attributes align:64 :: adiag
#endif
     ! but if complex we want to use this one
     complex(dpc), dimension (:), allocatable :: zadiag
#ifdef IS_ICC
!DIR$ attributes align:64 :: zadiag
#endif
     ! distributed noncollinear diagonal part of Hamiltonian
     complex(dpc), dimension (:,:), pointer :: bxc
     ! alias for grid%norder, order of finite order expansion
     integer :: norder
     ! alias for grid%coe2
     real(dp), dimension (:,:), pointer :: coe2
     ! alias for grid%kecoe1
     complex(dpc), dimension (:,:,:), pointer :: kecoe1
     ! alias for rsymm%nrep
     integer :: nrep
     ! characters for current irreducible representation
     real(dp), dimension (:), pointer :: chi
     ! true if noncollinear calculation
     logical :: ncl
     ! true if Chebyshev filtering is being done
     logical :: do_subsp
     ! switch to restart the filtering after n steps
     integer :: restart_cheb_after_n
     ! true if the number of eigenvalues per representation is kept fixed
     logical :: fix_num_eig
     ! set of Ritz values, or Kohn-Sham eigenvalues, used for
     ! Chebyshev filtering
     real(dp), dimension (:,:,:), pointer :: eval_loc
     ! lower bound of spectrum in Chebyshev filtering
     real(dp), dimension (:,:), pointer :: lowerb
     ! blocksize for everything matvec related
     integer :: mv_blksize

     integer, dimension (:,:), pointer :: ncompcnt
     ! seed for random vector generation
     integer :: rng_seed
     ! will we use threads to randomize init guess?
     logical :: randommp
     logical :: oldvectorrng

     ! true if a first guess of eigenvalues and eigenvectors is
     ! available for this representation and spin
     logical, dimension (:,:,:), pointer :: eig_init
     ! true if this is the first iteration in Chebyshev filtering
     logical, dimension (:,:), pointer :: firstfilt
     logical :: use_smart_bound_in_subspace

     ! number of converged eigenvalues to be used in eigval 
     ! with chebdav routine
     integer,  dimension (:,:,:), pointer :: nconvt
     ! flag for external manetic field
     logical :: is_mag
     ! Vector potential: rot{A}=H_ext
     real(dp), dimension (:,:), pointer :: vecpot
     !
     !encapsulates laplacian data
     type (stencil_definitions) :: sten_def 
     type (fold_stencil) :: sten_coeff 
     ! 
     ! some threading support
     ! integer :: matvec_mkl_threads,max_mkl_threads
     logical :: spectrum_slicing
     integer :: spectrum_slicing_max_iter
     integer :: nslices
     logical :: use_scalapack

  end type eigen_solver
contains

  subroutine destroy_eigen_solver (solver)
    implicit none
    type (eigen_solver), intent (inout) :: solver

    if (associated(solver%info)) deallocate(solver%info)
    if (associated(solver%nconvt)) deallocate(solver%nconvt)
    if (associated(solver%res_res)) deallocate(solver%res_res)
    if (associated(solver%zres_res)) deallocate(solver%zres_res)
!    if (associated(solver%resn)) deallocate(solver%resn)
    if (allocated(solver%adiag)) deallocate(solver%adiag)
    if (allocated(solver%zadiag)) deallocate(solver%zadiag)
    if (associated(solver%bxc)) deallocate(solver%bxc)
    if (associated(solver%coe2)) deallocate(solver%coe2)
    if (associated(solver%kecoe1)) deallocate(solver%kecoe1)
    if (associated(solver%chi)) deallocate(solver%chi)
    if (associated(solver%eval_loc)) deallocate(solver%eval_loc)
    if (associated(solver%lowerb)) deallocate(solver%lowerb)
    if (associated(solver%ncompcnt)) deallocate(solver%ncompcnt)
    if (associated(solver%eig_init)) deallocate(solver%eig_init)
    if (associated(solver%firstfilt)) deallocate(solver%firstfilt)
    if (associated(solver%vecpot)) deallocate(solver%vecpot)

    call solver%sten_def%destroy()
    call solver%sten_coeff%destroy()

  end subroutine destroy_eigen_solver

  subroutine create_eigen_solver (solver,grid,ldn,nrep,nspin,nstate, nkpt_in,cplx,mxwd)
    use grid_module
    implicit none
    type (eigen_solver), intent (inout) :: solver
    type (grid_data), intent(in) :: grid
    integer, intent(in) :: ldn,nrep,nspin,nstate,nkpt_in,mxwd
    logical, intent(in) :: cplx

    integer :: alcstat,nmax,ntmp,nkpt
    
    if (solver%name == TEST) then
        !we dont use the eigensolver
         return !?
    endif
    !
    ! nkpt = 0 if kpoints are not used; must increase it to one
    nkpt = max(nkpt_in,1)
    !
    ! should be inserted by the user inside parsec.in, maximum is 9
    solver%lpole = 9
    ! should also be inserted by the user inside parsec.in
    ! solver%kss0 = 20
    ! chebdav need extra window
    
    if (solver%name == CHEBDAV .or. solver%name == CHEBFF) then
       solver%winsize = 12
    else
       solver%winsize = 0
    endif
    solver%totalmv = 0

    solver%nrep = nrep

    allocate(solver%chi(nrep))

    if (cplx) then
      !AJB: for performance reasons we want zadiag instead of adiag
      allocate(solver%zadiag(ldn),stat =alcstat)
      call alccheck('solver%zadiag',ldn, alcstat)
    else
      allocate(solver%adiag(ldn),stat =alcstat)
      call alccheck('solver%adiag',ldn, alcstat)
    endif

    if (mxwd == 2) then
       allocate(solver%bxc(ldn,2),stat =alcstat)
       call alccheck('solver%bxc',2*ldn, alcstat)
    endif
    allocate(solver%info(nrep,nkpt,nspin))
    solver%info = 0

    solver%norder = grid%norder
    ntmp=3+grid%lap_dir_num
    allocate(solver%coe2(-solver%norder:solver%norder,ntmp))
    solver%coe2(:,:) = grid%coe2(:,:)

    if (nkpt_in /= 0) then
       allocate(solver%kecoe1(nkpt_in,6,0:solver%norder))
       solver%kecoe1(:,:,:)=grid%kecoe1(:,:,:)
    endif

    allocate(solver%eig_init(nrep,nkpt,nspin))

    if (solver%do_subsp) then
       solver%eig_init(:,:,:) = .false.
       allocate(solver%firstfilt(nrep,nspin))
       solver%firstfilt(:,:) = .true.
       allocate(solver%lowerb(nrep,nspin))
       solver%lowerb(:,:) = mach_eps 
       allocate(solver%ncompcnt(nrep,nspin))
       solver%ncompcnt(:,:) = 0
       nmax = nstate + solver%nadd + solver%winsize
       allocate(solver%eval_loc(nmax,nrep,nspin))
       solver%eval_loc(:,:,:) = zero
    endif

    if (solver%name == ARPACK) then
       if (cplx) then
          allocate(solver%zres_res(ldn*mxwd,nrep,nkpt,nspin),stat=alcstat)
          call alccheck('solver%zres_res',ldn*mxwd*nrep*nkpt*nspin,alcstat)
          solver%zres_res(:,:,:,:) = zzero
       else
          allocate(solver%res_res(ldn,nrep,nkpt,nspin),stat=alcstat)
          call alccheck('solver%res_res',ldn*nrep*nkpt*nspin,alcstat)
          solver%res_res(:,:,:,:) = zero
       endif
    endif

    ! initialize nconvt to zero
    allocate(solver%nconvt(nrep,nkpt,nspin))
    solver%nconvt(:,:,:) = 0
    if(solver%is_mag) then
      allocate(solver%vecpot(ldn,3),stat =alcstat)
      call alccheck('solver%vecpot',3*ldn, alcstat)
      solver%vecpot = zero
    endif

  end subroutine create_eigen_solver
  
end module eigen_solver_module
