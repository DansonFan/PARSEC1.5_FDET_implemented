! This file is part of parsec yada yada
! Poor man's vector folded stencils
! This is a simple tailor-made library of matrix-vector products
! I tried using the SIMD enabling thing, seems like it worked
!   we first show this for 2x2x2
!
! todo: explain more
module stencil_functions !{{{
    use constants, ONLY: zero,dp
    implicit none

    integer, parameter :: vecsize=8

    contains
     subroutine d222_CENTER(c0,cX,cY,cZ,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
        !$OMP DECLARE SIMD(d222_CENTER) UNIFORM(c0,cX,cY,cZ) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(c0,cX,cY,cZ) 
#endif
        ! [ c0, cZ, cY,  0, cX,  0,  0,  0]
        ! [ cZ, c0,  0, cY,  0, cX,  0,  0]
        ! [ cY,  0, c0, cZ,  0,  0, cX,  0]
        ! [  0, cY, cZ, c0,  0,  0,  0, cX]
        ! [ cX,  0,  0,  0, c0, cZ, cY,  0]
        ! [  0, cX,  0,  0, cZ, c0,  0, cY]
        ! [  0,  0, cX,  0, cY,  0, c0, cZ]
        ! [  0,  0,  0, cX,  0, cY, cZ, c0]
         real(dp), intent(in) :: c0, cX, cY, cZ
         real(dp), dimension(vecsize), intent(in) :: invec
         real(dp), dimension(vecsize), intent(out) :: outvec
         
         real(dp), dimension(4) ::wvec
         integer :: outer,inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec:64
    !DIR$ ASSUME_ALIGNED outvec:64
#endif

         !center is responsible for initing outvec.#badcoding #sorrynotsorry
         !can you guarantee it gets called first? - if not, just call an init
         !func first
         outvec=zero
!this is sort of an unrolled loop i guess?
         outer=1
         wvec=[c0, cZ, cY, zero]
         do inner=1,4
              outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
              outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=2
!"swizzle" attempt
!          wvec=(/cZ, c0, zero, cY/)
         wvec=[wvec(2), wvec(1), wvec(4), wvec(3)]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=3
         !wvec=(/cY, zero, c0, cZ/)
         wvec=[wvec(4), wvec(3), wvec(2), wvec(1)]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=4
         !wvec=(/zero, cY, cZ, c0/)
         wvec=[wvec(2), wvec(1), wvec(4), wvec(3)]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         do inner=1,4
             outvec(inner)      =cX * invec(inner+shft) + outvec(inner)
             outvec(inner+shft) =cX * invec(inner) + outvec(inner+shft)
         enddo

     end subroutine d222_CENTER !}}}
     subroutine d222_DUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
        !$OMP DECLARE SIMD(d222_DUL) UNIFORM(cDiag,cU,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU,cL)
#endif
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
         real(dp), intent(in) :: cDiag, cU, cL
         real(dp), dimension(vecsize), intent(in) :: invec
         real(dp), dimension(vecsize), intent(inout) :: outvec

         integer :: inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner)      =    cU * invec(inner+shft) + outvec(inner)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          outvec(inner+shft) =    cL * invec(inner)      + outvec(inner+shft)
          enddo
     end subroutine d222_DUL !}}}
     subroutine d222_DU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_DU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU) 
#endif
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         real(dp), intent(in)    :: cDiag, cU
         real(dp), intent(in)    :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)
         integer :: inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner)      =    cU * invec(inner+shft) + outvec(inner)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
     end subroutine d222_DU !}}}
     subroutine d222_DL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_DL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL) 
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
         real(dp), intent(in) :: cDiag, cL
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)
         
         integer :: inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner+shft) = cL    * invec(inner)      + outvec(inner+shft)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
     end subroutine d222_DL !}}}
     subroutine d222_DULDUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_DULDUL) UNIFORM(cDiag,cU,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU,cL) 
#endif
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
         real(dp), intent(in) :: cDiag, cU, cL
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)

         real(dp), dimension(4) ::wvec
!         real(dp) :: vtmp(4)
         integer :: inner

#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:2)=invec(3:4)*cU+outvec(1:2)
         outvec(3:4)=invec(1:2)*cL+outvec(3:4)
         outvec(5:6)=invec(7:8)*cU+outvec(5:6) 
         outvec(7:8)=invec(5:6)*cL+outvec(7:8) 

     end subroutine d222_DULDUL !}}}
     subroutine d222_DUDU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_DUDU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU) 
#endif
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         real(dp), intent(in) :: cDiag, cU 
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)

         integer :: inner
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:2)=invec(3:4)*cU+outvec(1:2)
         outvec(5:6)=invec(7:8)*cU+outvec(5:6) 
     end subroutine d222_DUDU !}}}
     subroutine d222_DLDL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_DLDL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL) 
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
         real(dp), intent(in) :: cDiag, cL 
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)
         
         integer :: inner 
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
           outvec(3:4)=invec(1:2)*cL+outvec(3:4)
           outvec(7:8)=invec(5:6)*cL+outvec(7:8) 
     end subroutine d222_DLDL !}}}
     subroutine d222_QDU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_QDU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU) 
#endif
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         real(dp), intent(in) :: cDiag, cU 
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)

         integer :: inner 
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:7:2)=cU*invec(2:8:2)+outvec(1:7:2)
     end subroutine d222_QDU !}}}
     subroutine d222_QDL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(d222_QDL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL) 
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]

         real(dp), intent(in) :: cDiag, cL 
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)

         integer :: inner 
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(2:8:2)=cL*invec(1:7:2)+outvec(2:8:2)
     end subroutine d222_QDL !}}}
     subroutine d222_QDUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD &
         !$OMP& UNIFORM(cDiag,cU,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD &
        !$OMP& UNIFORM(cDiag,cU,cL)
#endif
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
         real(dp), intent(in) :: cDiag, cU, cL
         real(dp), intent(in) :: invec(vecsize)
         real(dp), intent(inout) :: outvec(vecsize)

         integer :: inner
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:7:2)=cU*invec(2:8:2)+outvec(1:7:2)
         outvec(2:8:2)=cL*invec(1:7:2)+outvec(2:8:2)

     end subroutine d222_QDUL !}}}
end module stencil_functions !}}}

! hand converted from abouve + special center routine
module zstencil_functions !{{{
    use constants, ONLY: zzero,dpc
    implicit none

    integer, parameter :: vecsize=8

    contains
     subroutine z222_CENTER(c0,c6,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
        !$OMP DECLARE SIMD(z222_CENTER) UNIFORM(c0) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(c0) 
#endif
        ! [ c0, cZ, cY,  0, cX,  0,  0,  0]
        ! [ cZ, c0,  0, cY,  0, cX,  0,  0]
        ! [ cY,  0, c0, cZ,  0,  0, cX,  0]
        ! [  0, cY, cZ, c0,  0,  0,  0, cX]
        ! [ cX,  0,  0,  0, c0, cZ, cY,  0]
        ! [  0, cX,  0,  0, cZ, c0,  0, cY]
        ! [  0,  0, cX,  0, cY,  0, c0, cZ]
        ! [  0,  0,  0, cX,  0, cY, cZ, c0]
         complex(dpc), intent(in) :: c0, c6(6)
         complex(dpc), dimension(vecsize), intent(in) :: invec
         complex(dpc), dimension(vecsize), intent(out) :: outvec

         complex(dpc), dimension(4) :: wvec
         integer, parameter :: XL=1,XR=2,YL=3,YR=4,ZL=5,ZR=6 
         
         integer :: outer,inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

         !center is responsible for initing outvec.#badcoding #sorrynotsorry
         outvec=zzero
!this is sort of an unrolled loop i guess?
         outer=1
         wvec=[c0, c6(ZL), c6(YL), zzero]
         do inner=1,4
              outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
         enddo
         do inner=1,4
              outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=2
          wvec=[c6(ZR), c0, zzero, c6(YL)]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
         enddo
         do inner=1,4
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=3
          wvec=[c6(YR), zzero, c0, c6(ZL)]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
         enddo
         do inner=1,4
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         outer=4
          wvec=[zzero, c6(YR), c6(ZR), c0]
         do inner=1,4
             outvec(outer)     =wvec(inner)*invec(inner) + outvec(outer)
         enddo
         do inner=1,4
             outvec(outer+shft)=wvec(inner)*invec(inner+shft) + outvec(outer+shft)
         enddo

         do inner=1,4
             outvec(inner)      =c6(XL) * invec(inner+shft) + outvec(inner)
         enddo
         do inner=1,4
             outvec(inner+shft) =c6(XR) * invec(inner) + outvec(inner+shft)
         enddo

     end subroutine z222_CENTER !}}}
     subroutine z222_DUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
        !$OMP DECLARE SIMD(z222_DUL) UNIFORM(cDiag,cU,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cU,cL) 
#endif
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cU, cL
         complex(dpc), dimension(vecsize), intent(in) :: invec
         complex(dpc), dimension(vecsize), intent(inout) :: outvec

         integer :: inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner)      =    cU * invec(inner+shft) + outvec(inner)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          outvec(inner+shft) =    cL * invec(inner)      + outvec(inner+shft)
          enddo
     end subroutine z222_DUL !}}}
     subroutine z222_DU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_DU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU) 
#endif
        ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         complex(dpc), intent(in)    :: cDiag, cU
         complex(dpc), intent(in)    :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)
         integer :: inner
         integer, parameter :: shft=4
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner)      =    cU * invec(inner+shft) + outvec(inner)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
     end subroutine z222_DU !}}}
     subroutine z222_DL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_DL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL) 
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [ cL,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0, cL,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0, cL,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0, cL,  0,  0,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cL
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)
         
         integer :: inner
         integer, parameter :: shft=4
          
          do inner=1,4
          outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
          outvec(inner+shft) = cL    * invec(inner)      + outvec(inner+shft)
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
     end subroutine z222_DL !}}}
     subroutine z222_DULDUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_DULDUL) UNIFORM(cDiag,cU,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU,cL) 
#endif
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cU, cL
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)

         complex(dpc), dimension(4) ::wvec
!         complex(dpc) :: vtmp(4)
         integer :: inner
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:2)=invec(3:4)*cU+outvec(1:2)
         outvec(3:4)=invec(1:2)*cL+outvec(3:4)
         outvec(5:6)=invec(7:8)*cU+outvec(5:6) 
         outvec(7:8)=invec(5:6)*cL+outvec(7:8) 

     end subroutine z222_DULDUL !}}}
     subroutine z222_DUDU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_DUDU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU) 
#endif
        ! [ cDiag,  0, cU,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0, cU,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0, cU,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0, cU]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cU 
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)

         integer :: inner
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:2)=invec(3:4)*cU+outvec(1:2)
         outvec(5:6)=invec(7:8)*cU+outvec(5:6) 
     end subroutine z222_DUDU !}}}
     subroutine z222_DLDL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_DLDL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL)
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [ cL,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0, cL,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0, cL,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0, cL,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cL 
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)
         
         integer :: inner 
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
           outvec(3:4)=invec(1:2)*cL+outvec(3:4)
           outvec(7:8)=invec(5:6)*cL+outvec(7:8) 
     end subroutine z222_DLDL !}}}
     subroutine z222_QDU(cDiag,cU,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_QDU) UNIFORM(cDiag,cU) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cU)
#endif
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [  0, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0,  0, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
         complex(dpc), intent(in) :: cDiag, cU 
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)

         integer :: inner 
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:7:2)=cU*invec(2:8:2)+outvec(1:7:2)
     end subroutine z222_QDU !}}}
     subroutine z222_QDL(cDiag,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_QDL) UNIFORM(cDiag,cL) 
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD UNIFORM(cDiag,cL)
#endif
        ! [ cDiag,  0,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag,  0,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]

         complex(dpc), intent(in) :: cDiag, cL 
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)

         integer :: inner 
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(2:8:2)=cL*invec(1:7:2)+outvec(2:8:2)
     end subroutine z222_QDL !}}}
     subroutine z222_QDUL(cDiag,cU,cL,invec,outvec) !{{{
#if defined(IS_ICC) || defined(IS_CRAY)
         !$OMP DECLARE SIMD(z222_QDUL) &
#elif defined(IS_GCC)
        !$OMP DECLARE SIMD &
#endif
         !$OMP& UNIFORM(cDiag,cU,cL) 
        ! [ cDiag, cU,  0,  0,  0,  0,  0,  0]
        ! [ cL, cDiag,  0,  0,  0,  0,  0,  0]
        ! [  0,  0, cDiag, cU,  0,  0,  0,  0]
        ! [  0,  0, cL, cDiag,  0,  0,  0,  0]
        ! [  0,  0,  0,  0, cDiag, cU,  0,  0]
        ! [  0,  0,  0,  0, cL, cDiag,  0,  0]
        ! [  0,  0,  0,  0,  0,  0, cDiag, cU]
        ! [  0,  0,  0,  0,  0,  0, cL, cDiag]
         complex(dpc), intent(in) :: cDiag, cU, cL
         complex(dpc), intent(in) :: invec(vecsize)
         complex(dpc), intent(inout) :: outvec(vecsize)

         integer :: inner
#ifdef IS_ICC
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif
          
          do inner=1,8
          outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
          enddo
         outvec(1:7:2)=cU*invec(2:8:2)+outvec(1:7:2)
         outvec(2:8:2)=cL*invec(1:7:2)+outvec(2:8:2)

     end subroutine z222_QDUL !}}}
end module zstencil_functions !}}}
