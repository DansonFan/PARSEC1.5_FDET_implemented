!  helper module, defines a bunch of stuff
!  since we are moving deeper into graphs - we need an integer typed coo and csr matrices
!  they are also defined here
module stencil_things
use constants, only : dp, dpc
implicit none

type stencil_definitions !{{{
    integer :: norder, lap_dir_num !copy from grid, pending refactoring will 
    integer :: num_shell_memb !=6+2*lap_dir_num, the variable defining the stride of the lap operator
    integer :: nrep !bad hack for retaining nrep, assumed 1
    logical :: cplx !another hack for retaing info about wavefunctions
    !
    !  Pending - several sten_definitions per run. 
    ! if we implement varying order laplacians
    ! highest order of laplacian in this run, along with lap_dir_num defines strides etc.
    !
    ! integer :: max_norder !defined max order for which comm_neigh is assembled
    ! last internal point - variable order then for each order ther is a different 'last internal point'
    ! integer :: inter1
    !
    ! Refactoring considerations for future - 
    ! these could move here, should not change once they are set.
    ! coe2 2nd der. coefficents
    ! coe1 1st der. coefficents - for gradient and kinetic energy
    !maybe put this here since it is inside gen_coeff1D
    ! kecoe1 !=-2i*coe1*ktmp
    ! coefficents transformed to 1D, without kpoint data
    real(dp) :: coeff2_diag !the r0 coefficents, diagonal part of the operator, sum(coe2(0,1:3+lap_dir_num))
    real(dp), dimension (:), pointer :: coeff2_1D  !(1:(6+2*lap_dir)*norder)
    real(dp), dimension (:), pointer :: coeff2_sym !(3+lap_dir)*norder
    ! when also gradient
    !real(dp) :: coeff1_diag !the r0 coefficents, diagonal part of the operator
    !real(dp), dimension (:), pointer :: coeff1_1D  !(1:(6+2*lap_dir)*norder)
    !
    ! the full coefficents for the stencil in matvec
    complex(dpc), dimension (:), pointer :: gen_coeff2_1D !(1:(6+2*lap_dir)*norder)
    contains
        procedure :: init => init_sten_definitions
        procedure :: create => create_sten_definitions
        procedure :: setcoe2_1D => set_sten_coeff2_1D
        procedure :: destroy => destroy_sten_definitions
end type stencil_definitions
!}}}

  type fold_stencil !{{{
      real(dp), dimension(:), allocatable :: coeffsym
      complex(dpc), dimension(:), allocatable :: coeff_gen
      integer :: num_tiles
      integer :: blocksizes(3) 
      integer :: foldsize 
      logical :: gen
      real(dp) :: c0
      complex(dpc) :: c0_gen
      ! compiler is complaining about alignment of these:
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
      !DIR$ attributes align:64 :: coeffsym
      !DIR$ attributes align:64 :: coeff_gen
#endif
      contains
          procedure :: init => fold_stencil_init
          procedure :: alloc => fold_stencil_allocate
          procedure :: copy_coeffsym => fldstncl_cp_coeff_from_sten
          procedure :: copy_coeff_gen => fldstncl_cp_coeffgen_from_sten
          procedure :: updateC0 => fold_stencil_update_c0
          procedure :: destroy => fold_stencil_destroy
  end type fold_stencil !}}}


  type int_coo !{{{
      integer :: nnz = 0 
      integer, dimension(:), allocatable :: row
      integer, dimension(:), allocatable :: col
      integer, dimension(:), allocatable :: val
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
      !DIR$ attributes align:64 :: row
      !DIR$ attributes align:64 :: col
      !DIR$ attributes align:64 :: val
#endif
      contains
          procedure :: alloc => int_coo_allocate
          procedure :: init => int_coo_init 
          procedure :: destroy => int_coo_destroy
          procedure :: sortbycol => sortbycol_coo
  end type int_coo !}}}
   
  type int_csr !{{{
      integer :: nnz = 0
      integer :: nrows = 0 !number of rows
      integer :: ncols = 0 !number of columns
      integer, dimension(:), allocatable :: rows
      integer, dimension(:), allocatable :: cols
      integer, dimension(:), allocatable :: vals
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
      !DIR$ attributes align:64 :: rows
      !DIR$ attributes align:64 :: cols
      !DIR$ attributes align:64 :: vals
#endif
      contains
          procedure :: alloc => int_csr_allocate
          procedure :: init => int_csr_init
          procedure :: destroy => int_csr_destroy
  end type int_csr !}}}


  !
  !    Global variables within the module
  !
  ! these contain the edges in csr format
  type (int_csr) my_sten_edges
  type (int_csr) ext_sten_edges
  !! hmm??
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
  !DIR$ attributes align:64 :: my_sten_edges
  !DIR$ attributes align:64 :: ext_sten_edges
#endif

  ! later - symmetry?
  ! type (int_coo) mycoo_t
  ! type (int_coo) extcoo_t

  contains
      ! sten_def things - 
subroutine init_sten_definitions(sten_def,cplx_flag,nrep) !{{{ only 2nd der.
    use constants, only : zero !note that this additionall pulls in zero...
    implicit none
    class (stencil_definitions) :: sten_def
    logical ,intent(in) :: cplx_flag
    integer, intent(in) :: nrep
    
    sten_def%coeff2_diag = zero
    sten_def%cplx = cplx_flag
    sten_def%nrep = nrep

    nullify(sten_def%coeff2_1D)
    nullify(sten_def%coeff2_sym)
    nullify(sten_def%gen_coeff2_1D)
end subroutine init_sten_definitions !}}}

subroutine destroy_sten_definitions(sten_def) !{{{ 
    !deallocate 1D coeff arrays
    implicit none
    class (stencil_definitions) :: sten_def

    if (associated (sten_def%coeff2_1D) ) deallocate (sten_def%coeff2_1D)
    if (associated (sten_def%coeff2_sym) ) deallocate (sten_def%coeff2_sym)
    if (associated (sten_def%gen_coeff2_1D) ) deallocate (sten_def%gen_coeff2_1D)
end subroutine destroy_sten_definitions !}}}

subroutine set_sten_coeff2_1D(sten_def,coe2) !{{{
    !converts the 2d coe2 array to a 1d vector
    !in coe2 it is order as (-norder:norder,direction)
    !in the 1d vector it will be arranged as (shell 1 ) (shell 2 ) (shell 3) 
    !inside each shell the coefficents are orderd like the parallel%neib array, e.g. X_L X_R, Y_L Y_R, ...
    implicit none
    class (stencil_definitions) :: sten_def
    real(dp) :: coe2(-sten_def%norder:sten_def%norder,3+sten_def%lap_dir_num)
    !
    integer :: ishell,icoeff,current_shell_shift
    
!    write(9,*) "NEW LAP - converting coe2 to 1d. coe2:"
!    write(9,*)  coe2
    !shellwize coe2 is -norder..0..norder, we want 1..norder but each coefficent repeats twice:
    sten_def%coeff2_diag = sum(coe2(0,:))

    ! fill the regular coefficents
    do ishell=1,sten_def%norder
        do icoeff=1,3+sten_def%lap_dir_num
        current_shell_shift = (ishell-1)*(2*sten_def%lap_dir_num+6)
      ! write(9,*) "2db: sten_def debug", ishell, icoeff,  current_shell_shift
      ! write(9,*) "DEBUG: coeff2_1d index", current_shell_shift+2*icoeff
        sten_def%coeff2_1D(current_shell_shift+2*icoeff    ) =  coe2(ishell,icoeff)
        sten_def%coeff2_1D(current_shell_shift+2*icoeff -1 )  =  coe2(ishell,icoeff)
        end do
    end do
    ! fill in the symmetric coefficents
    do ishell=1,sten_def%norder
        do icoeff=1,3+sten_def%lap_dir_num
        current_shell_shift = (ishell-1)*(sten_def%lap_dir_num+3)
        sten_def%coeff2_sym(current_shell_shift+icoeff)=coe2(ishell,icoeff)
        end do
    end do
end subroutine set_sten_coeff2_1D  !}}}

!subroutine set_lap_coeff1_1D(sten_def,coe1) !{{{
!    ! not ready yet!
!    !converts the 2d coe1 array to a 1d vector
!    !in coe1 it is order as (-norder:norder,direction)
!    !in the 1d vector it will be arranged as (shell 1 ) (shell 2 ) (shell 3) 
!    !inside each shell the coefficents are orderd like the parallel%neib array, e.g. X_L X_R, Y_L Y_R, ...
!    implicit none
!    class (sten_definitions) :: sten_def
!    real(dp) :: coe1(-sten_def%norder:sten_def%norder,3)
!    !
!    integer :: ishell,icoeff,current_shell_shift
!    
!!    write(9,*) "NEW LAP - converting coe2 to 1d. coe2:"
!!    write(9,*)  coe2
!    !shellwize coe2 is -norder..0..norder, we want 1..norder but each coefficent repeats twice:
!
!    do ishell=1,sten_def%norder
!        do icoeff=1,3
!        current_shell_shift = (ishell-1)*(6)
!!    write(9,*) "coe2, ishell, icoeff:",coe2(ishell,icoeff), ishell,icoeff
!        sten_def%coeff2_1D(current_shell_shift+2*icoeff    ) =  coe1(ishell,icoeff)
!        sten_def%coeff2_1D(current_shell_shift+2*icoeff -1 )  =  coe1(ishell,icoeff)
!        end do
!    end do
!
!    ! write(9,*) "NEW LAP - coeff2_1D:",sten_def%coeff2_1D
!
!
!end subroutine set_lap_coeff1_1D  !}}}

subroutine create_sten_definitions(sten_def,norder,lap_dir_num) !{{{
        use constants, only : zero, zzero
        use aux, only : alccheck
    !use laplacian_definition_module
    implicit none
    !eventually all coe definitions might be made here
    ! meanwhile create here just the struct that you need
    ! and copy the rest from (eigen_)solver
    class (stencil_definitions) :: sten_def
    integer, intent(in) :: norder
    integer, intent(in) :: lap_dir_num
    integer :: coeff_size, alcstat
    
    sten_def%norder=norder
    sten_def%lap_dir_num=lap_dir_num
    sten_def%num_shell_memb=(6+2*sten_def%lap_dir_num)

    coeff_size=sten_def%norder*sten_def%num_shell_memb
    allocate(sten_def%coeff2_1D(coeff_size), stat=alcstat)
    call alccheck('sten_def%coeff2_1D',coeff_size, alcstat)

    coeff_size=sten_def%norder*(sten_def%num_shell_memb/2)
    allocate(sten_def%coeff2_sym(coeff_size), stat=alcstat)
    call alccheck('sten_def%coeff2_sym',coeff_size, alcstat)

    coeff_size=sten_def%norder*sten_def%num_shell_memb

    if (sten_def%cplx) then
    ! porbably should only allocate this if running pbc or cluster with complex numbers
    !allocate(sten_def%gen_coeff2_1D(sten_def%norder*sten_def%num_shell_memb), stat=alcstat)
    allocate(sten_def%gen_coeff2_1D(coeff_size), stat=alcstat)
    call alccheck('sten_def%gen_coeff2_1D',coeff_size, alcstat)
    sten_def%gen_coeff2_1D=zzero
    end if
    
    !initialize the newly allocated coefficents
    sten_def%coeff2_1D(:)=zero

end subroutine create_sten_definitions !}}}
! sparse type functions (moved/adapted from spmatvec_module) !{{{
!int coo !{{{
    subroutine int_coo_init(sprs)
        implicit none
        class(int_coo):: sprs
        sprs%nnz = 0
    end subroutine int_coo_init

    subroutine int_coo_allocate(sprs, nzcount)
        use aux, only : alccheck
        implicit none
        class(int_coo):: sprs
        integer :: nzcount
        integer :: alcstat

        sprs%nnz = nzcount
        allocate(sprs%col(nzcount),stat=alcstat)
        call alccheck('coo_sprs%col',nzcount,alcstat)
        allocate(sprs%row(nzcount),stat=alcstat)
        call alccheck('coo_sprs%row',nzcount,alcstat)
        allocate(sprs%val(nzcount),stat=alcstat)
        call alccheck('coo_sprs%val',nzcount,alcstat)
    end subroutine int_coo_allocate

    subroutine int_coo_destroy(sprs)
        implicit none

        class(int_coo):: sprs

        if ( allocated(sprs%col) ) deallocate(sprs%col)
        if ( allocated(sprs%row) ) deallocate(sprs%row)
        if ( allocated(sprs%val) ) deallocate(sprs%val)
    end subroutine int_coo_destroy !}}}

    subroutine sortbycol_coo(sprs,row0,row1)
        !uses the iheapsort method already in parsec
        !it is a little problematic because it is based on NR code,
        !which is not GPL
        use sort_module, only : iheapsort
        implicit none

        class(int_coo):: sprs

        integer, intent(in) :: row0,row1

        integer, dimension (:), allocatable :: sortindex
        integer myrow,irow,ibegin,iend,maxedge,n 

        ! there would be at most maxedge columns to sort for every row
        maxedge=maxval(sprs%val)
        allocate(sortindex(maxedge))


        ! warning, clunky code written by a chemist :)
        do myrow=row0,row1

        iend = 0
        ibegin= 0

        !find which coo rows belong to the same matrix row
        do irow=1,sprs%nnz 

        if (ibegin == 0 .AND. sprs%row(irow) == myrow) then

            ibegin = irow
            do iend = irow+1,sprs%nnz
            if (sprs%row(iend) == myrow) then
                cycle
            else
                exit
            endif
            enddo
            iend=iend-1
        endif
        if (iend /= 0 ) then
!      write(9,*) "sortcoo myrow irow ibegin iend",myrow,irow,ibegin,iend
            exit
        endif
        enddo !irow

        ! if (iend == 0 ) then
      ! write(9,*) "myrow, irow ibegin,iend=",myrow, irow,ibegin,iend
        ! endif

        !now sort these coo rows so that columns are at the correct order
        sortindex=0
        ! get the sorted index
        n=iend-ibegin+1
        if (n > 1 ) then
        call iheapsort(n,sprs%col(ibegin:iend),sortindex)

        !debug:
!        write(9,*) "iheapsort did its thing. ibegin =",ibegin
!        write(9,*) "before rearranging sprs matrix, see if the indexes are ok"
!        write(9,*) ibegin-1+sortindex(1:n)

        ! use it on all three arrays
        sprs%col(ibegin:iend)=sprs%col(ibegin-1+sortindex(1:n))
        sprs%row(ibegin:iend)=sprs%row(ibegin-1+sortindex(1:n))
        sprs%val(ibegin:iend)=sprs%val(ibegin-1+sortindex(1:n))
        endif
        enddo !myrow
    end subroutine sortbycol_coo



! int csr {{{
!
    subroutine int_csr_init(sprs)
        implicit none
        class(int_csr):: sprs
        sprs%nnz   = 0
        sprs%nrows = 0
        sprs%ncols = 0
    end subroutine int_csr_init

    subroutine int_csr_allocate(sprs,nrows,nzcount)
        use aux, only : alccheck
        implicit none

        class(int_csr):: sprs
        integer :: nrows
        integer :: nzcount
        integer :: alcstat

        sprs%nnz = nzcount
        sprs%nrows = nrows
        sprs%ncols = -1
        if (nzcount>0 .AND. nrows>0) then
        allocate(sprs%cols(nzcount),stat=alcstat)
        call alccheck('int_csr%cols',nzcount,alcstat)
        allocate(sprs%rows(nrows+1),stat=alcstat)
        call alccheck('int_csr%rows',nrows+1,alcstat)
        allocate(sprs%vals(nzcount),stat=alcstat)
        call alccheck('int_csr%vals',nzcount,alcstat)
        else
        allocate(sprs%cols(1),stat=alcstat)
        call alccheck('int_csr%cols',1,alcstat)
        allocate(sprs%rows(1),stat=alcstat)
        call alccheck('int_csr%rows',1,alcstat)
        allocate(sprs%vals(1),stat=alcstat)
        call alccheck('int_csr%vals',1,alcstat)
        endif

    end subroutine int_csr_allocate

    subroutine int_csr_destroy(sprs)
        implicit none

        class(int_csr):: sprs

        sprs%ncols = -1
        if ( allocated(sprs%cols) ) deallocate(sprs%cols)
        if ( allocated(sprs%rows) ) deallocate(sprs%rows)
        if ( allocated(sprs%vals) ) deallocate(sprs%vals)
    end subroutine int_csr_destroy !}}}


subroutine coo2csr_int(coo,csr) !{{{
    ! csr representaton - standard row-wise compressed sparse matrix
        ! converts from coo to csr using already obtained information on 
        ! number for non-zeros and number of rows. 
        ! assumes csr type is already allocated
        ! also assumes coo col and row are properly sorted
    ! based on coocsr in sparsekit
       implicit none
       type (int_coo), intent(in) :: coo
       type (int_csr), intent(inout) :: csr
       integer nnz, nrows !size parameters 
       integer i,j,k,k0,val,ioffset
       
       ! Grab nnz and nrows:
       nnz = coo%nnz
       nrows = csr%nrows

       !
       ! Determine row lengths
       !
        write(9,*) "init csr%rows to 0"
       csr%rows(:) = 0 ! init
        write(9,*) "done init csr%rows to 0"
        write(9,*) "nnz is",nnz

       do k = 1, nnz
           csr%rows(coo%row(k)) = csr%rows((coo%row(k))) + 1
       end do
       !
       ! Determine the starting position of each row 
       !
       k = 1
       !k0 = 0
       do j = 1, nrows+1
           k0 = csr%rows(j)
           csr%rows(j) = k
           k = k + k0
       end do
       !
       ! Fill values
       !
       do k = 1, nnz
           i = coo%row(k)
           j = coo%col(k)
           val = coo%val(k) 
           ioffset = csr%rows(i)
           csr%vals(ioffset) = val
           csr%cols(ioffset) = j
           csr%rows(i) = ioffset + 1
       end do
       !
       ! Reform the csrrows 
       !
       do j = nrows,1,-1
           csr%rows(j+1) = csr%rows(j)
       enddo
           csr%rows(1) = 1
           !ierr = 0
           
       ! I am not sure I will ever use this number, but setting it to to indicate it is populated
           !csr%ncols=maxval(csr%cols)
           csr%ncols=1 !indicator, not real value

end subroutine coo2csr_int !}}}

subroutine csrprint_with_id(csrmtx,iam,filename) !{{{
  implicit none
  type (int_csr), intent(in) :: csrmtx
  integer, intent(in) :: iam
  character(len=*), intent(in) :: filename
   character(len=4)    :: idstring

  ! huge files:
  write(9,*) 'printing csr matix with nnz,nrows, ncol:',csrmtx%nnz,csrmtx%nrows,csrmtx%ncols
    write(idstring,'(I4.4)') iam !limited for 10k PE
    open(48,file=filename//'csrrows.'//idstring,form='formatted',status='unknown')
    open(47,file=filename//'csrcols.'//idstring,form='formatted',status='unknown')
    open(46,file=filename//'csrvals.'//idstring,form='formatted',status='unknown')
   write(46,300) csrmtx%vals
   close(46)

   write(47,300) csrmtx%cols
   close(47)

   write(48,300) csrmtx%rows
   close(48)
   write(9,*) 'done'

300 format (I8)
end subroutine csrprint_with_id!}}}

subroutine cooprint_with_id(coomtx,iam,filename) !{{{
  implicit none
  type (int_coo), intent(in) :: coomtx
  integer, intent(in) :: iam
  character(len=*), intent(in) :: filename
   character(len=4)    :: idstring
   integer:: nnz,IND

   nnz=coomtx%nnz
  ! huge files:
    write(idstring,'(I4.4)') iam !limited for 10k PE
    ! print (row col val)
    open(46,file=filename//'coo.'//idstring,form='formatted',status='unknown')
   write(46,'(I8,1X,I8,1X,I3)') (coomtx%row(IND), coomtx%col(IND), coomtx%val(IND), IND=1,nnz)  
   close(46)

end subroutine cooprint_with_id!}}}
!{{{ leftover subroutines (maybe useful in the future?)
    subroutine copy_coo_to_lower_tri(coomtx_in,coomtx_out,mydim)
        implicit none

        type (int_coo), intent(in) :: coomtx_in
        type (int_coo), intent(out) :: coomtx_out

        integer, intent(in) :: mydim
        integer :: myrow,mycol, nzind, cooind, newnnz

        write(9,*) "culling my coo matrix to lower triagonal"
        write(9,*) "original nnz:", coomtx_in%nnz
        newnnz = coomtx_in%nnz - mydim
        write(9,*) "nnz without diagonal", newnnz
        newnnz = newnnz/2
        newnnz = newnnz + mydim
        write(9,*) "final nnz with diagonal", newnnz

        call coomtx_out%destroy()
        call coomtx_out%init()
        call coomtx_out%alloc(newnnz)

        cooind = 0
        do nzind = 1,coomtx_in%nnz
           myrow = coomtx_in%row(nzind)
           mycol = coomtx_in%col(nzind)
           if (mycol <= myrow) then
               cooind = cooind+1
               coomtx_out%row(cooind) = myrow
               coomtx_out%col(cooind) = mycol
               coomtx_out%val(cooind) = coomtx_in%val(nzind)
           endif
        enddo
        write(9,*) "new coo matrix has", cooind, "non zero elements"

    end subroutine copy_coo_to_lower_tri
!}}}
!}}}

! fold stencil functions {{{
! the following is a working example,
! only true for fold 2x2x2 and a stencil depth of 6 
subroutine fold_stencil_init(foldsten,genflag) !{{{
    use constants, only : zero
    implicit none
    class(fold_stencil):: foldsten
    logical, intent(in) ::genflag
    foldsten%foldsize = 0
    foldsten%c0 = zero
    foldsten%c0_gen = zero
    foldsten%gen = genflag
end subroutine fold_stencil_init!}}}

subroutine fold_stencil_allocate(foldsten,foldsize) !{{{
    implicit none
    class(fold_stencil):: foldsten
    integer, intent(in) :: foldsize
    integer alcstat
    foldsten%foldsize = foldsize
end subroutine fold_stencil_allocate!}}}

subroutine fldstncl_cp_coeff_from_sten(foldsten,stendef) !{{{
        use aux, only : alccheck
    class(fold_stencil):: foldsten
    type(stencil_definitions), intent(in) :: stendef

    integer :: symsize,alcstat

    symsize = stendef%norder*(3+stendef%lap_dir_num)
    if (.NOT.foldsten%gen) then
        if (.NOT.allocated(foldsten%coeffsym)) then
    allocate(foldsten%coeffsym(symsize), stat=alcstat)
    call alccheck('foldsten%coeffsym',symsize, alcstat)
        endif
    foldsten%coeffsym = stendef%coeff2_sym
    endif

end subroutine fldstncl_cp_coeff_from_sten !}}}

subroutine fldstncl_cp_coeffgen_from_sten(foldsten,stendef) !{{{
        use constants, only : zero, dp
        use aux, only : alccheck
    class(fold_stencil):: foldsten
    type(stencil_definitions), intent(in) :: stendef
    integer :: coeffsize,alcstat
    coeffsize = 2*stendef%norder*(3+stendef%lap_dir_num)
    if (foldsten%gen) then
        if (.NOT.allocated(foldsten%coeff_gen)) then
    allocate(foldsten%coeff_gen(coeffsize), stat=alcstat)
    call alccheck('foldsten%coeff_gen',coeffsize, alcstat)
        endif
        ! write(9,*) "debug - rewrote coeff_gen from coeff2_1d"
    !properly cast the real coefficents to complex
    foldsten%coeff_gen = cmplx(stendef%coeff2_1D,zero,dp)
    endif

end subroutine fldstncl_cp_coeffgen_from_sten !}}}

subroutine fold_stencil_update_c0(foldsten,c0replace) !{{{
    use constants, only : zero, dp
    implicit none

    class(fold_stencil):: foldsten
    real(dp) :: c0replace
    integer i
    foldsten%c0=c0replace
    foldsten%c0_gen=cmplx(c0replace,zero,dp)
end subroutine fold_stencil_update_c0 !}}}

subroutine fold_stencil_destroy(foldsten) !{{{
    implicit none
    class(fold_stencil):: foldsten
    foldsten%blocksizes = -1
    foldsten%foldsize = -1
    if (allocated (foldsten%coeffsym) ) deallocate (foldsten%coeffsym)
    if (allocated (foldsten%coeff_gen) ) deallocate (foldsten%coeff_gen)
end subroutine fold_stencil_destroy!}}}

subroutine real_internal_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,workdim,indim,invec,outvec,workvec) !{{{
    use constants, only : zero 
    implicit none
    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: indim, workdim
    real(dp), intent(in) :: invec(indim) 
    real(dp), intent(inout) :: outvec(indim) 
    real(dp), intent(inout) :: workvec(workdim) 
    integer icol,irow
    integer i,j
    integer, parameter :: foldsize=8
    integer, parameter :: maxnumedges=18
    integer, dimension(blksize) :: nval, rowptr, colstart
    integer, dimension(maxnumedges) :: colptr,edgeval
    real(dp) :: tempout(foldsize)
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ attributes align:64 :: nval, rowptr,colstart
    !DIR$ attributes align:64 :: colptr,edgeval
    !DIR$ attributes align:64 :: tempout
#endif
    ! real(dp) :: tempin(foldsize)

#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
!DIR$ assume (mod(indim,16) .eq. 0)
!DIR$ assume (mod(indim,16) .eq. 0)
#endif

    !$OMP SIMD PRIVATE(irow) 
    do i=1,blksize
       irow=i-1+row0
       rowptr(i)=1+(irow-1)*foldsize
       colstart(i)=my_sten_edges%rows(irow)
       nval(i)=my_sten_edges%rows(irow+1)-colstart(i)
       !colend(i)=colstart(i)+nval(i)-1
    enddo
    !$OMP END SIMD

    do i=1,blksize 

#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
    !DIR$ ASSUME_ALIGNED workvec: 64
#endif
    !center traverse inits this:
    call center_traverse_real_222_depth6(coeff%coeffsym,coeff%c0,invec(rowptr(i)),outvec(rowptr(i))) 

!  colptr(1:nval(i))=1+foldsize*(my_sten_edges%cols(colstart(i):colend(i))-1)                                                                                                                  
    !$OMP SIMD
    do j=1,nval(i)
    colptr(j)=1+foldsize*(my_sten_edges%cols(colstart(i)+j-1)-1)
    enddo
    !$OMP END SIMD
    !$OMP SIMD
    do j=1,nval(i)
    edgeval(j)=my_sten_edges%vals(colstart(i)-1+j)
    enddo
    !$OMP END SIMD

    tempout=zero

    do j=1,nval(i)
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
    !DIR$ ASSUME_ALIGNED workvec: 64
#endif
     call edge_traverse_real_222_depth6(coeff%coeffsym,edgeval(j),invec(colptr(j)),tempout)
    enddo !j

    outvec(rowptr(i):rowptr(i)+foldsize-1)=outvec(rowptr(i):rowptr(i)+foldsize-1)+tempout
    enddo !i

end subroutine real_internal_edges_222_depth6 !}}}

subroutine complex_internal_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,workdim,indim,&
      invec,outvec,workvec) !{{{
    implicit none

    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: indim, workdim
    complex(dpc), intent(in) :: invec(indim) 
    complex(dpc), intent(inout) :: outvec(indim) 
    complex(dpc), intent(inout) :: workvec(workdim) 

    integer nval,colstart,colend,icol,colptr,rowptr,edgeval,irow
    integer i,j
    integer, parameter :: foldsize=8
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED workvec: 64
    !DIR$ ASSUME_ALIGNED invec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
#endif

    do irow=row0,row0+blksize-1

    rowptr=1+(irow-1)*foldsize
    nval=my_sten_edges%rows(irow+1)-my_sten_edges%rows(irow)
    colstart=my_sten_edges%rows(irow)
    colend=colstart+nval-1



    call center_traverse_complex_222_depth6(coeff%coeff_gen,coeff%c0_gen,invec(rowptr:rowptr+foldsize-1),&
       outvec(rowptr:rowptr+foldsize-1),workvec)


    ! then do the stencil

    do icol=colstart,colend

    colptr=1+(my_sten_edges%cols(icol)-1)*foldsize
    edgeval=my_sten_edges%vals(icol)

     call edge_traverse_complex_222_depth6(coeff%coeff_gen,edgeval,invec(colptr:colptr+foldsize-1),&
        outvec(rowptr:rowptr+foldsize-1))

    enddo !icol
    enddo !irow

end subroutine complex_internal_edges_222_depth6 !}}}

subroutine real_ghost_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,buffdim,workdim,outdim,&
      buffvec,outvec,workvec) !{{{
    use constants, only : zero
    implicit none

    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: buffdim, workdim
    integer, intent(in) :: outdim
    real(dp), intent(in) :: buffvec(buffdim) 
    real(dp), intent(inout) :: outvec(outdim) 
    real(dp), intent(inout) :: workvec(workdim) 

    integer, parameter :: foldsize=8

    integer nval,colstart,colend,icol,colptr,rowptr,edgeval,irow
    real(dp) :: tempin(foldsize), tempout(foldsize)
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED buffvec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
    !DIR$ ASSUME_ALIGNED workvec: 64
#endif

    do irow=row0,row0+blksize-1

    rowptr=1+(irow-1)*foldsize

    nval=ext_sten_edges%rows(irow+1)-ext_sten_edges%rows(irow)
    colstart=ext_sten_edges%rows(irow)
    colend=colstart+nval-1

        tempout=zero
! !$OMP PARALLEL DO REDUCTION(+:tempout) PRIVATE(colptr,edgeval,tempin)
    do icol=colstart,colend

    colptr=1+(ext_sten_edges%cols(icol)-1)*foldsize
    tempin=buffvec(colptr:colptr+foldsize-1)
    edgeval=ext_sten_edges%vals(icol)

  call edge_traverse_real_222_depth6(coeff%coeffsym,edgeval,tempin,tempout)
    enddo !icol
! !$OMP END PARALLEL DO

      outvec(rowptr:rowptr+foldsize-1)=outvec(rowptr:rowptr+foldsize-1)+tempout
    enddo !irow

end subroutine real_ghost_edges_222_depth6 !}}}

subroutine complex_ghost_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,buffdim,workdim,outdim,&
      buffvec,outvec,workvec) !{{{
    implicit none

    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: buffdim, workdim
    integer, intent(in) :: outdim
    complex(dpc), intent(in) :: buffvec(buffdim) 
    complex(dpc), intent(inout) :: outvec(outdim) 
    complex(dpc), intent(inout) :: workvec(workdim) 

    integer, parameter :: foldsize=8

    integer nval,colstart,colend,icol,colptr,rowptr,edgeval,irow
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED buffvec: 64
    !DIR$ ASSUME_ALIGNED outvec: 64
    !DIR$ ASSUME_ALIGNED workvec: 64
#endif


    do irow=row0,row0+blksize-1

    rowptr=1+(irow-1)*foldsize
    nval=ext_sten_edges%rows(irow+1)-ext_sten_edges%rows(irow)
    colstart=ext_sten_edges%rows(irow)
    colend=colstart+nval-1

    do icol=colstart,colend

    colptr=1+(ext_sten_edges%cols(icol)-1)*foldsize
    edgeval=ext_sten_edges%vals(icol)

call edge_traverse_complex_222_depth6(coeff%coeff_gen,edgeval,buffvec(colptr:colptr+foldsize-1),&
   outvec(rowptr:rowptr+foldsize-1))

    enddo !icol

    enddo !irow

end subroutine complex_ghost_edges_222_depth6 !}}}

subroutine center_traverse_real_222_depth6(coeffsym,cCENTER,infold,outfold) !{{{
    use stencil_functions, only : d222_CENTER
    implicit none

    integer, parameter :: foldsize=8
    integer, parameter :: norder=6
    integer, parameter :: coeffsymsize=norder*3

    real(dp), intent(in) :: coeffsym(coeffsymsize)
    real(dp), intent(in) :: cCENTER
    real(dp), intent(in) :: infold(foldsize)
    real(dp), intent(out) :: outfold(foldsize)

    integer, parameter :: X1 = 1,  Y1 = 2,  Z1 = 3
#if defined(IS_ICC) && defined(UNSAFE_ASSUMPTION_INTEL)
    !DIR$ ASSUME_ALIGNED coeffsym: 64
#endif

    call d222_CENTER(c0=cCENTER,cX=coeffsym(X1),cY=coeffsym(Y1), cZ=coeffsym(Z1),invec=infold,outvec=outfold)

end subroutine center_traverse_real_222_depth6 !}}}

subroutine center_traverse_complex_222_depth6(coeff_gen,cCENTER,infold,outfold,workvec) !{{{
    use zstencil_functions, only : z222_CENTER
    implicit none

    integer, parameter :: foldsize=8
    integer, parameter :: norder=6
    integer, parameter :: coeffgensize=norder*3*2

    complex(dpc), intent(in) :: coeff_gen(coeffgensize)
    complex(dpc), intent(in) :: cCENTER
    complex(dpc), intent(in) :: infold(foldsize)
    complex(dpc), intent(out) :: outfold(foldsize)
    complex(dpc), intent(inout) :: workvec(foldsize)


    call z222_CENTER(c0=cCENTER,c6=coeff_gen(1:6),invec=infold,outvec=outfold)

end subroutine center_traverse_complex_222_depth6 !}}}

    !currently for num_lap_dir=0
subroutine edge_traverse_real_222_depth6(coeffsym,edgeval,infold,outfold) !{{{
    use constants, ONLY:zero, dp
    use stencil_functions
    implicit none

    integer, intent(in) :: edgeval
    integer, parameter :: foldsize=8
    integer, parameter :: norder=6
    integer, parameter :: coeffsymsize=norder*3

    real(dp), intent(in) :: coeffsym(coeffsymsize)
    real(dp), intent(in) :: infold(foldsize)
    !will it work with intent out only?
    real(dp), intent(inout) :: outfold(foldsize)

    integer, parameter :: X1 = 1,  Y1 = 2,  Z1 = 3
    integer, parameter :: X2 = 4,  Y2 = 5,  Z2 = 6
    integer, parameter :: X3 = 7,  Y3 = 8,  Z3 = 9
    integer, parameter :: X4 = 10, Y4 = 12, Z4 = 12
    integer, parameter :: X5 = 13, Y5 = 14, Z5 = 15
    integer, parameter :: X6 = 16, Y6 = 17, Z6 = 18
    
    ! need to optimize, the case statement is not helping
    select case (edgeval) !{{{
    case(1)
      call d222_DUL   (cDiag=coeffsym(X2),cU=coeffsym(X1),cL=coeffsym(X3), invec=infold,outvec=outfold)
    case(2)
      call d222_DUL   (cDiag=coeffsym(X2),cU=coeffsym(X3),cL=coeffsym(X1), invec=infold,outvec=outfold)
    case(3)
      call d222_DULDUL(cDiag=coeffsym(Y2),cU=coeffsym(Y1),cL=coeffsym(Y3), invec=infold,outvec=outfold)
    case(4)
      call d222_DULDUL(cDiag=coeffsym(Y2),cU=coeffsym(Y3),cL=coeffsym(Y1), invec=infold,outvec=outfold)
    case(5)
      call d222_QDUL  (cDiag=coeffsym(Z2),cU=coeffsym(Z1),cL=coeffsym(Z3), invec=infold,outvec=outfold)
    case(6)
      call d222_QDUL  (cDiag=coeffsym(Z2),cU=coeffsym(Z3),cL=coeffsym(Z1), invec=infold,outvec=outfold)
    case(7)
      call d222_DUL   (cDiag=coeffsym(X4),cU=coeffsym(X3),cL=coeffsym(X5), invec=infold,outvec=outfold)
    case(8)
      call d222_DUL   (cDiag=coeffsym(X4),cU=coeffsym(X5),cL=coeffsym(X3), invec=infold,outvec=outfold)
    case(9)
      call d222_DULDUL(cDiag=coeffsym(Y4),cU=coeffsym(Y3),cL=coeffsym(Y5), invec=infold,outvec=outfold)
    case(10)
      call d222_DULDUL(cDiag=coeffsym(Y4),cU=coeffsym(Y5),cL=coeffsym(Y3), invec=infold,outvec=outfold)
    case(11)
      call d222_QDUL  (cDiag=coeffsym(Z4),cU=coeffsym(Z3),cL=coeffsym(Z5), invec=infold,outvec=outfold)
    case(12)
      call d222_QDUL  (cDiag=coeffsym(Z4),cU=coeffsym(Z5),cL=coeffsym(Z3), invec=infold,outvec=outfold)
    case(13)
      call d222_DU    (cDiag=coeffsym(X6),cU=coeffsym(X5), invec=infold,outvec=outfold)
    case(14)
      call d222_DL    (cDiag=coeffsym(X6),cL=coeffsym(X5), invec=infold,outvec=outfold)
    case(15)
      call d222_DUDU  (cDiag=coeffsym(Y6),cU=coeffsym(Y5), invec=infold,outvec=outfold)
    case(16)
      call d222_DLDL  (cDiag=coeffsym(Y6),cL=coeffsym(Y5), invec=infold,outvec=outfold)
    case(17)
      call d222_QDU   (cDiag=coeffsym(Z6),cU=coeffsym(Z5), invec=infold,outvec=outfold)
    case(18)
      call d222_QDL   (cDiag=coeffsym(Z6),cL=coeffsym(Z5),invec=infold,outvec=outfold)
    end select !}}}
end subroutine edge_traverse_real_222_depth6 !}}}

! almost the same as above
subroutine edge_traverse_complex_222_depth6(coeff_gen,edgeval,infold,outfold) !{{{
    !currently for num_lap_dir=0
    use constants
    use zstencil_functions
    implicit none
! debug:
!    type(fold_stencil), intent(in) :: coeff 
    integer, intent(in) :: edgeval
    integer, parameter :: foldsize=8
    integer, parameter :: norder=6
    integer, parameter :: coeffgensize=norder*3*2

    complex(dpc), intent(in) :: coeff_gen(coeffgensize)
    complex(dpc), intent(in) :: infold(foldsize)
    !will it work with intent out only?
    complex(dpc), intent(inout) :: outfold(foldsize)

    integer, parameter :: XL1=1, XR1=2, YL1=3, YR1=4, ZL1=5, ZR1=6 
    integer, parameter :: XL2=7, XR2=8, YL2=9, YR2=10,ZL2=11,ZR2=12 
    integer, parameter :: XL3=13,XR3=14,YL3=15,YR3=16,ZL3=17,ZR3=18 
    integer, parameter :: XL4=19,XR4=20,YL4=21,YR4=22,ZL4=23,ZR4=24 
    integer, parameter :: XL5=25,XR5=26,YL5=27,YR5=28,ZL5=29,ZR5=30 
    integer, parameter :: XL6=31,XR6=32,YL6=32,YR6=34,ZL6=35,ZR6=36 
    
    select case (edgeval) !{{{
    case(1)
      call z222_DUL(cDiag=coeff_gen(XR2),cU=coeff_gen(XR1),cL=coeff_gen(XR3), invec=infold,outvec=outfold)
    case(2)
      call z222_DUL(cDiag=coeff_gen(XL2),cU=coeff_gen(XL3),cL=coeff_gen(XL1), invec=infold,outvec=outfold)
    case(3)
      call z222_DULDUL(cDiag=coeff_gen(YR2),cU=coeff_gen(YR1),cL=coeff_gen(YR3),invec=infold,outvec=outfold)
    case(4)
      call z222_DULDUL(cDiag=coeff_gen(YL2),cU=coeff_gen(YL3),cL=coeff_gen(YL1), invec=infold,outvec=outfold)
    case(5)
      call z222_QDUL(cDiag=coeff_gen(ZR2),cU=coeff_gen(ZR1),cL=coeff_gen(ZR3), invec=infold,outvec=outfold)
    case(6)
      call z222_QDUL(cDiag=coeff_gen(ZL2),cU=coeff_gen(ZL3),cL=coeff_gen(ZL1),invec=infold,outvec=outfold)
    case(7)
      call z222_DUL(cDiag=coeff_gen(XR4),cU=coeff_gen(XR3),cL=coeff_gen(XR5), invec=infold,outvec=outfold)
    case(8)
      call z222_DUL(cDiag=coeff_gen(XL4),cU=coeff_gen(XL5),cL=coeff_gen(XL3), invec=infold,outvec=outfold)
    case(9)
      call z222_DULDUL(cDiag=coeff_gen(YR4),cU=coeff_gen(YR3),cL=coeff_gen(YR5), invec=infold,outvec=outfold)
    case(10)
      call z222_DULDUL(cDiag=coeff_gen(YL4),cU=coeff_gen(YL5),cL=coeff_gen(YL3), invec=infold,outvec=outfold)
    case(11)
      call z222_QDUL(cDiag=coeff_gen(ZR4),cU=coeff_gen(ZR3),cL=coeff_gen(ZR5), invec=infold,outvec=outfold)
    case(12)
      call z222_QDUL(cDiag=coeff_gen(ZL4),cU=coeff_gen(ZL5),cL=coeff_gen(ZL3), invec=infold,outvec=outfold)
    case(13)
      call z222_DU(cDiag=coeff_gen(XR6),cU=coeff_gen(XR5), invec=infold,outvec=outfold)
    case(14)
      call z222_DL(cDiag=coeff_gen(XL6),cL=coeff_gen(XL5), invec=infold,outvec=outfold)
    case(15)
      call z222_DUDU(cDiag=coeff_gen(YR6),cU=coeff_gen(YR5), invec=infold,outvec=outfold)
    case(16)
      call z222_DLDL(cDiag=coeff_gen(YL6),cL=coeff_gen(YL5), invec=infold,outvec=outfold)
    case(17)
      call z222_QDU(cDiag=coeff_gen(ZR6),cU=coeff_gen(ZR5), invec=infold,outvec=outfold)
    case(18)
      call z222_QDL(cDiag=coeff_gen(ZL6),cL=coeff_gen(ZL5),invec=infold,outvec=outfold)
    end select !}}}
end subroutine edge_traverse_complex_222_depth6 !}}}

    
end module

