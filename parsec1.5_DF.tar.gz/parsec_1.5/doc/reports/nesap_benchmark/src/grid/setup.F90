module setup_module

implicit none
contains

!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  Setup a uniform, real space grid, composed of a boundary sphere
!  inside a rectangular box. 
!
!  NOTE:
!  Other geometries (e.g., an individual sphere around each atom)
!  may be attempted. They are not implemented in the current
!  version. Their addition may require adding additional tests to
!  isolat.f (see comment there).
!
!---------------------------------------------------------------
subroutine setup(grid, pbc, rsymm, parallel, nspin, kpnum, ierr)

use constants
use grid_module
use pbc_module
use symmetry_module
use parallel_data_module
use block_neib
use grid_partition_module, only : grid_partition
use comm_neigh_module, only : comm_neigh

#ifdef MPI
!  include mpi definitions
use mpi
#endif

implicit none

!
!  Input/Output variables:
!
!  grid related data
type (grid_data), intent(inout) :: grid
!  periodic boundary conditions data
type (pbc_data), intent(inout) :: pbc
!  symmetry operations in reduced (Abelian) group
type (symmetry), intent(in) :: rsymm
!  parallel computation related data
type (parallel_data), intent(inout) :: parallel
!  number of spins
integer, intent(in) :: nspin
!  number of k-points (or 1, if there are no k-points)
integer, intent(in) :: kpnum
!  error flag
integer, intent(out) :: ierr
!
!  Work variables:
!
!  temporary neighbor indexing
integer neib
!  counters
integer ii,j,k,indx(12),numb
!  exit code for mpi calls
integer mpinfo
!  number of procs available, node index
integer nnodes,inode
!  communicator
integer comm
!  rank of the master in the above communicator
integer masterid
integer  irows(0:parallel%procs_num)
!  tag for the messages, it is incremented at each send/recv
integer msgtype

integer index_arr
integer num_p,neibs_num
integer icount,nelem,mxelem,alcstat,ishell

!  buffer arrays
integer, allocatable :: tmp2(:,:,:)
#ifdef MPI
integer status(MPI_STATUS_SIZE)
#endif

!---------------------------------------------------------------

!
!  Create groups of processors.
!
#ifdef MPI
call MPI_Bcast(parallel%groups_num, 1, MPI_INTEGER, parallel%masterid, &
        parallel%comm, mpinfo)
#endif

call create_group_layout_2d(parallel, rsymm%ntrans*nspin*kpnum)
!call create_group_layout(parallel, rsymm%ntrans*nspin*kpnum)

!nnodes   = parallel%group_size
!masterid = parallel%group_master
!comm     = parallel%group_comm
nnodes   = parallel%nprow
masterid = parallel%colgroup_masterid
comm     = parallel%colgroup_comm
msgtype  = 0

!
!  Create communicator arrays.
!

allocate(parallel%irows(0:nnodes))

! for block/folds:
allocate(parallel%cirows(0:nnodes))

allocate(parallel%irecvp(0:nnodes))
allocate(parallel%jsendp(0:nnodes))

allocate(parallel%c_irecvp(0:nnodes))
allocate(parallel%c_jsendp(0:nnodes))

! allocate(parallel%ip1(0:nnodes))
! allocate(parallel%jp1(0:nnodes))

#ifdef MPI
call MPI_BCAST(grid%shift, 3,MPI_DOUBLE_PRECISION, parallel%masterid,parallel%comm,mpinfo)
call MPI_BCAST(grid%n1, 1,MPI_INTEGER, parallel%masterid,parallel%comm,mpinfo)
call MPI_BCAST(grid%n2, 1,MPI_INTEGER, parallel%masterid,parallel%comm,mpinfo)
call MPI_BCAST(grid%n3, 1,MPI_INTEGER, parallel%masterid,parallel%comm,mpinfo)
#endif

!
!  Construct regular grid, irreducible wedge, and partition.
!
if (parallel%iamgmaster) then
        ! write(9,*) "DEBUG: before grid partition, domain shape is"
        call grid_partition(grid,pbc,rsymm,parallel,ierr)
        ! write(9,*) "DEBUG: finished grid partition"
endif




#ifdef MPI
!
!  Broadcast Partitioning Information and PBC parameters
!
call MPI_BCAST(parallel%ndim,   1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(parallel%ldn,    1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(parallel%nwedge, 1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(parallel%nwedge_c, 1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(pbc%mx,          1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(pbc%my,          1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(pbc%mz,          1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(parallel%irows, nnodes+1, MPI_INTEGER,masterid, comm,mpinfo)
call MPI_BCAST(parallel%cirows, nnodes+1, MPI_INTEGER,masterid, comm,mpinfo)
call MPI_BCAST(pbc%shift,       3, MPI_DOUBLE_PRECISION, masterid,comm,mpinfo)
call MPI_BCAST(ierr,            1, MPI_INTEGER, masterid,comm,mpinfo)


!  Check if ierr is not zero in any group
ii = abs(ierr)
if (parallel%iamgmaster) then
        write(9,*) "DEBUG: calling allreduce for ierr", ii, ierr
endif

call MPI_Allreduce(ii, ierr, 1, MPI_INTEGER, MPI_MAX, parallel%comm, mpinfo)

if (parallel%iamgmaster) then
        write(9,*) "DEBUG: done (master)"
endif

! broadcast grid neighbors dimensions
call MPI_BCAST(grid%neibs_num, 1, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%nxyz, 1, MPI_INTEGER, masterid, comm, mpinfo)
#endif




!
!  Bail out if the irreducible wedge is incorrect
!
if (ierr /= 0) then
        if (parallel%iammaster) write(7,*) 'Error in grid_partition. Stop!'
        return
endif




irows(0:nnodes) = parallel%irows(0:nnodes)

!  define local dimension mydim
parallel%mydim = irows(parallel%group_iam+1) - irows(parallel%group_iam)
parallel%mycdim = parallel%cirows(parallel%group_iam+1) - parallel%cirows(parallel%group_iam)

!todo - change ldn to mydim here:
allocate(parallel%pint(parallel%ldn),stat=alcstat)
call alccheck('parallel%pint',parallel%ldn,alcstat)

allocate(parallel%senrows(parallel%nwedge),stat=alcstat)
call alccheck('parallel%senrows',parallel%nwedge,alcstat)

!how did you get here?
! allocate(parallel%c_senblocks(parallel%nwedge_c),stat=alcstat)
! call alccheck('parallel%c_senblocks',parallel%nwedge_c,alcstat)
!

neibs_num = 6 + 2*grid%lap_dir_num

allocate(parallel%neibs(neibs_num*grid%norder,parallel%mydim), stat=alcstat)
call alccheck('parallel%neibs',neibs_num*grid%norder*parallel%mydim, alcstat)
parallel%neibs(:,:) = 0

allocate(parallel%tneibs(neibs_num*grid%norder,parallel%mydim), stat=alcstat)
call alccheck('parallel%tneibs',neibs_num*grid%norder*parallel%mydim,alcstat)
parallel%tneibs(:,:) = 0

if (.not. parallel%iamgmaster) then
        grid%nwedge = parallel%nwedge
        grid%nwedge_c = parallel%nwedge_c
        call grid_set_wedge(grid)
        call grid_set_ist(grid,nnodes)
endif







write(9,*) 'BCAST BLOCK I'

#ifdef MPI
call MPI_BCAST(grid%kx, grid%nwedge, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%ky, grid%nwedge, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%kz, grid%nwedge, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%kcx, grid%nwedge_c, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%kcy, grid%nwedge_c, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%kcz, grid%nwedge_c, MPI_INTEGER, masterid,comm,mpinfo)
call MPI_BCAST(grid%c2k, grid%nwedge_c+1, MPI_INTEGER, masterid,comm,mpinfo)
#endif

write(9,*) 'BCAST BLOCK II'

#ifdef MPI
call MPI_BCAST(grid%nxmax,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%nxmin,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%nymax,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%nymin,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%nzmax,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%nzmin,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%n1,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%n2,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%n3,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%ndim,1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%ndim_c,1,MPI_INTEGER,masterid,comm,mpinfo)
#endif

if (.not. parallel%iamgmaster) then
        call grid_set_ndim(grid,ndim=grid%ndim,ndim_c=grid%ndim_c,nnodes=nnodes)
        call grid_set_conversion(grid)
endif

write(9,*) 'BCAST BLOCK III'

#ifdef MPI
call MPI_BCAST(grid%rindex,grid%ndim+1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%rtrans,grid%ndim+1,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%fx,grid%ndim,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%fy,grid%ndim,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%fz,grid%ndim,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%cx,grid%ndim_c,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%cy,grid%ndim_c,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%cz,grid%ndim_c,MPI_INTEGER,masterid,comm,mpinfo)
call MPI_BCAST(grid%c2f,grid%ndim_c+1,MPI_INTEGER,masterid,comm,mpinfo)
#endif






!!! NEW: CREATE THE NEIGHBOR ARRAY !!!
!!! this time each PE does its own work !!!
!!! step 1 - temporarily store indexg on each PE
write(9,*) "debug: start calculating neib"

if (.not. parallel%iamgmaster) then
        write(9,*) "allocating indexg"

        allocate (grid%indexg (grid%nxmin:grid%nxmax, &
                grid%nymin:grid%nymax,grid%nzmin:grid%nzmax) &
                ,stat=alcstat)

        write(9,*) "done allocating indexg"

        call alccheck('indexg',grid%nxyz, alcstat)
        ! if(grid%hartree_neibs_flag) then
        !  allocate (grid%neibs_index (grid%nxmin:grid%nxmax, &
        !                              grid%nymin:grid%nymax, &
        !                              grid%nzmin:grid%nzmax), &
        !                              stat=alcstat)
        !  call alccheck('neibs_index',grid%nxyz,alcstat)
        ! endif
endif

write(9,*) "sending indexg"

#ifdef MPI
call MPI_BCAST(grid%indexg,grid%nxyz,MPI_INTEGER,masterid,comm,mpinfo)
#endif

write(9,*) "done bcast indexg"

if (.not. parallel%iamgmaster) then
        write(9,*) 'I now have indexg!!!, mypart=',parallel%group_iam
endif






!!! step 2 - calculate neibs 
call calc_my_neibs(parallel,grid,mypart=parallel%group_iam)

!!! experimental - calculate c_neibs
if (grid%lap_dir_num == 0) then
        call calc_my_cneibs(parallel,grid,mypart=parallel%group_iam)
endif





!  Master PE broadcasts indexw
if (.not. parallel%iamgmaster) then
        deallocate(grid%indexg)

        write(9,*) 'I lost indexg!!!'
        allocate (grid%indexw(grid%nxmin:grid%nxmax, grid%nymin:grid%nymax, &
                grid%nzmin:grid%nzmax) ,stat=alcstat)
        call alccheck('indexw',grid%nxyz, alcstat)
        !grid%indexw(:,:,:) = 0
endif

#ifdef MPI
call MPI_BCAST(grid%indexw,grid%nxyz,MPI_INTEGER,masterid,comm,mpinfo)
! if(grid%hartree_neibs_flag) call MPI_BCAST(grid%neibs_index,grid%nxyz,MPI_INTEGER,masterid,comm,mpinfo)
#endif

write(9,*) 'The local dimension is :', parallel%mydim

parallel%lap_dir_num = grid%lap_dir_num
!AJB: might as well remove this someday
! write(9,*) "before comm_neib"
! write(9,*) "parallel%neibs(:,1):"
! write(9,*)  parallel%neibs(:,1)
! write(9,*) "grid%c2f(parallel%c_neibs(:,1):"
! write(9,*)  grid%c2f(parallel%c_neibs(:,1))
! write(9,*) "parallel%c_neibs(:,1):"
! write(9,*)  parallel%c_neibs(:,1)

!  Find boundary information for exchange
call comm_neigh(parallel,grid%norder)





! new stuff:
if (grid%lap_dir_num == 0) then
        call comm_cneib(parallel,norder=grid%norder,blocksizes=grid%fold%blocksize)
        !
        ! it is a good idea to test neib and cneib here:
        ! write(9,*) "after comm_neib"
        !  write(9,*) "parallel%neibs(:,1):"
        !  write(9,*)  parallel%neibs(:,1)
        !  write(9,*) "grid%c2f(parallel%c_neibs(:,1):"
        !  write(9,*)  grid%c2f(parallel%c_neibs(:,1))
        !  write(9,*) "parallel%c_neibs(:,1):"
        !  write(9,*)  parallel%c_neibs(:,1)

        ! now for the interesting things:
        mxelem=maxval(grid%norder/grid%fold%blocksize)
        call convert_to_graphs(parallel,folded_stencil_depth=mxelem)

        ! no need for you anymore
        deallocate(parallel%c_neibs)
endif !lap_dir_num == 0 - since I still have not figured out what to do with extra dirs now



write(9,*) 'regular neib information (legacy:)'

write(9,*) 'Information to be sent to neighbors:'
icount = 0
mxelem = 0

do inode = 0, nnodes-1
        nelem = parallel%jsendp(inode+1)-parallel%jsendp(inode)
        write(9,*) 'send PE ',inode,' #rows:',nelem
        mxelem = mxelem + nelem
        if (nelem/=0) icount = icount +1
enddo

parallel%maxcomm   = mxelem
parallel%countcomm = icount
parallel%maxcomm2  = parallel%irecvp(nnodes)-parallel%irecvp(0)
write(9,*) 'I communicate with ',icount, &
        ' processors, a total of ',parallel%maxcomm,' elements'
write(9,*) 'Also, I receive from these procs: ', &
        parallel%maxcomm2, ' elements'
write(9,*) 'my workvector has thus  ', &
        parallel%myworkdim+1, ' elements'

! if (parallel%maxcomm /= parallel%maxcomm2) then
!     write(9,*) ''
!     write(9,*) 'WARNING, ASSYMETRIC COMM PATTERN ENCOUNTERED'
! endif



#ifdef MPI
!  create the graph communicator and update local comm data
write(9,*) 'calling topo aware'
write(9,*) ''
call topo_aware(parallel) 
write(9,*) 'done topo aware'
!dunno where to put it
! this whole hack smells. need to reorder parsec structures anyhoo
parallel%max_lap_buffers=grid%max_lap_buffers
#endif


write(9,*) "COMMDEBUG:"
write(9,*) "irecvp:"
write(9,*) parallel%irecvp
write(9,*) "c_irecvp:"
write(9,*) parallel%c_irecvp
write(9,*) "jsendp:"
write(9,*) parallel%jsendp
write(9,*) "c_jsendp:"
write(9,*) parallel%c_jsendp
write(9,*) "parallel%sdispls:"
write(9,*) parallel%sdispls
write(9,*) "parallel%c_sdispls"
write(9,*) parallel%c_sdispls
write(9,*) "END COMMDEBUG:"


end subroutine setup
!===============================================================
end module setup_module
