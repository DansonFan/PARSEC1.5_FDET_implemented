#include<sys/time.h>
#include<sys/resource.h>
#include<sys/types.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<inttypes.h>
#include<stdio.h>
#include<errno.h>
int get_memory_usage(uint64_t * current, uint64_t * memmax)
{
    errno=0; // defined in errno.h
    pid_t pid = getpid();
    struct rusage usage;
    char filename[128];
    getrusage(RUSAGE_SELF, &usage);
    *memmax = (usage.ru_maxrss*1024)/1e6; // Max memory in MB
    int ierr = sprintf(filename,"/proc/%d/statm",pid);
    uint64_t trash;
    *current = 0;
    FILE* statm = fopen(filename,"r");
    if(statm){
        ierr = fscanf(statm,"%" SCNu64 " %" SCNu64 ,&trash,current); 
        fclose(statm);
    } else {
        ierr = sprintf(filename,"can't open /proc/%d/statm : code %d\n",pid,errno);
        fprintf(stderr,"%s",filename);
    }
    *current = (((*current * (long)(sysconf(_SC_PAGESIZE)))/1024)/1024); // Current memory in MB
    // printf("mem(%d|%d) caux.c : %" PRIu64 " %" PRIu64 "\n",pid,ierr,*current,*memmax);
}
int get_memory_avail(uint64_t * current, uint64_t * total)
{
    errno=0; // defined in errno.h
    int ierr;
    const char token0[]="MemTotal:";
    const char token1[]="MemFree: ";
    char *happy_little_pointer;
    *current = 0;
    *total = 0;
    //printf("%s\n",token0); fflush(stdout);
    //printf("%s\n",token1); fflush(stdout);
    FILE* statm = fopen("/proc/meminfo","r");
    char *filename = (char*)malloc(256 * sizeof(char));
    int exitflag=1;
    if(statm){
	// this is ugly and I am sorry but it has to get done
        while( exitflag != 0 && fgets(filename, 256, statm) != NULL){
            exitflag = strncmp(filename,token0,9);
#if 0
            printf("%d %s\n", exitflag, filename);
#endif
            if(exitflag==0) { break;}
        }
        int j = 0, i = 0;
        for(; strncmp(filename+i," ",1) != 0; ++i) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        for(; strncmp(filename+i," ",1) == 0; ++i) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        for(j=i; strncmp(filename+j," ",1) != 0; ++j) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        *total = strtoul(filename+i, (&filename+j), 10); 
	fseek(statm, 0, SEEK_SET);
	exitflag = 1;
        while( exitflag != 0 && fgets(filename, 256, statm) != NULL){
            exitflag = strncmp(filename,token1,9);
#if 0
            printf("%d %s\n", exitflag, filename);
#endif
            if(exitflag==0) { break;}
        }
        i = 0;
        for(; strncmp(filename+i," ",1) != 0; ++i) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        for(; strncmp(filename+i," ",1) == 0; ++i) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        for(j=i; strncmp(filename+j," ",1) != 0; ++j) {
#if 0
            printf("%1c|",filename[i]);
#endif
        };
        *current = strtoul(filename+i, (&filename+j), 10); 
        fclose(statm);
    } else {
        ierr = sprintf(filename,"can't open /proc/meminfo : code %d\n",errno);
        fprintf(stderr,"%s",filename);
    }
    *current = (((*current)/1024)); // Current memory in MB
    *total = (((*total)/1024)); // Current memory in MB
    // printf("mem(%d|%d) caux.c : %" PRIu64 " %" PRIu64 "\n",pid,ierr,*current,*memmax);
    free(filename);
}
