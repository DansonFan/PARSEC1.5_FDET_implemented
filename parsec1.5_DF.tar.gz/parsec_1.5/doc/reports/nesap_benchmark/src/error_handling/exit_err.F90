module error_handlers
    contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine terminates the procs and closes the parsec.out
! file if exiting upon an error.
!
!---------------------------------------------------------------
subroutine exit_err (clust,elec_st,grid,pot,p_pot,nloc_p_pot,u_pot, &
     move, mol_dynamic,pbc,mixer,solver,symm,rsymm,parallel,&
     file_id,ierr_in)

  use constants
  use matvec_base
  use cluster_module
  use electronic_struct_module
  use grid_module
  use potential_module
  use pseudo_potential_module
  use non_local_psp_module
  use movement_module
  use molecular_dynamic_module
  use pbc_module
  use mixer_module
  use eigen_solver_module
  use symmetry_module
  use parallel_data_module
  use stencil_things
  use parsec_global_data, only : vecgen, moldyngen
  use prandom_module
#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
  use fftw3_module, only : fftw_cleanup
#elif defined(USEFFTW3)
  use fftw3_module, only : dfftw_cleanup
#endif
#ifdef USEHDF5
  use hdf5
#endif
#ifdef MPI
  use mpi
#endif
  implicit none
#ifdef ITAC
  ! inlcude trace-analyzer definitions
  include 'VT.inc'
#endif 
  !
  ! Input/Output variables:
  !
  ! Structures to destroy
  ! the cluster
  type(cluster), intent(inout) :: clust
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! grid related data
  type (grid_data), intent(inout) :: grid
  ! potential related data
  type (potential), intent(inout) :: pot
  ! pseudopotential related data
  type (pseudo_potential), intent(inout) :: p_pot
  ! non local pseudopotential related data
  type (nonloc_pseudo_potential), intent(inout) :: nloc_p_pot
  ! on-site Coulomb interaction related data
  type (nonloc_pseudo_potential), intent(inout) :: u_pot
  ! molecular dynamic related data
  type (molecular_dynamic), intent(inout) :: mol_dynamic
  ! movement step for lbfgs
  type (movement), intent(inout) :: move
  ! periodic boundary conditions data
  type (pbc_data), intent(inout) :: pbc
  ! mixer related data
  type (mixer_data), intent(inout) :: mixer
  ! solver related data
  type (eigen_solver), intent(inout) :: solver
  ! symmetry operations
  type (symmetry), intent(inout) :: symm,rsymm
  ! parallel computation related data
  type (parallel_data), intent(inout) :: parallel

  ! error flag
  integer, intent(in) :: ierr_in
#ifdef USEHDF5
     INTEGER(HID_T), INTENT(IN) :: file_id  ! File identifier
     INTEGER                    :: ierr  ! Error flag
#else
     INTEGER, INTENT(IN) :: file_id  ! integer to replace it
#endif
  !
  ! Work variables:
  !
#ifdef MPI
  ! communicator to be used
  integer comm
  ! variable for the return code of mpi calls
  integer mpinfo
#endif
  ! temporary variable for error flag
  integer ::  ierr_tmp

  ! temporary variable to deal with negative errors being less than 0
  integer ::  ierr_red(2)

  ! file unit numbers
  integer :: iunit, units(1:22) =(/ 4, 6, 7, 8, 10, 11,&
             13, 15, 16, 20, 45,&
             46, 61, 66, 67, 76,&
             78, 79, 88, 90, 91,&
             92 /)
         !close(unit=6)  ! parsec.out
         !close(unit=7)  ! fort.7 in most cases..?
         !close(unit=45) ! relax_restart.dat
         !close(unit=46) ! bfgs.dat
         !close(unit=61) ! eigen.dat
         !close(unit=66) ! atom.cor
         !close(unit=67) ! manual.dat
         !close(unit=76) ! mdinit.dat
         !close(unit=78) ! md_nrg.dat
         !close(unit=79) ! md_mech.dat
         !close(unit=90) ! occup.in
         !close(unit=91) ! polar.dat
         !close(unit=92) ! movie.xyz

  ! whether or not a file is open
  logical :: lopen

  !---------------------------------------------------------------
  ierr_red = [ ierr_in, -ierr_in ]

  ! share error flag
#ifdef MPI
  call mpi_allreduce(MPI_IN_PLACE,ierr_red,2, &
       mpi_integer,mpi_max,parallel%comm,mpinfo)
#endif
  ierr_tmp = max(ierr_red(1),ierr_red(2))

#ifdef DEBUG
  write(9,*) ' Error check ',ierr_tmp,ierr_in
  call myflush(9)
#endif
if(ierr_tmp /= 0) then
     write(9,*) ' Error code ierr = ',ierr_tmp
     write(9,*) ' End of Program '
! destroy all the structures
#ifndef MDSTR
!        write(9,*) "begin memory cleanup"
        call myflush(9)
        call matvec_destroy()
        call destroy_cluster (clust)
        call destroy_electronic_struct (elec_st)
        call destroy_grid (grid)
        call destroy_potential (pot)
        call destroy_pseudo_potential (p_pot)
        call destroy_movement(move)
        call destroy_molecular_dynamic (mol_dynamic)
        call destroy_nonloc_pseudo_pot (nloc_p_pot)
        call destroy_nonloc_pseudo_pot (u_pot)
        if (pbc%is_on) call destroy_pbc (pbc)
        call destroy_mixer (mixer)
        call destroy_eigen_solver (solver)
        call destroy_symmetry (symm)
        call destroy_symmetry (rsymm)
        call destroy_parallel_data (parallel)
        call my_sten_edges%destroy()
        call ext_sten_edges%destroy()
        !> \bug causes crash at very end of program
        call vecgen % destroy(errcode=ierr_tmp)
        call moldyngen % destroy(errcode=ierr_tmp)
#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
     ! release all allocated memory from fftw
     call fftw_cleanup()
#elif defined(USEFFTW3)
     ! release all allocated memory from fftw
     call dfftw_cleanup()
#endif
!        write(9,*) "cleanup complete (?)"
     call myflush(9)
#endif
     ! close all files
     ! close parsec.out
     if (parallel%iammaster) then
            do iunit=1,size(units)
                 inquire(unit=units(iunit),opened=lopen)
                 if (lopen) close(unit=units(iunit))
            enddo
     endif
#ifdef USEHDF5 
     ! Terminate access to the file.
     CALL h5fclose_f(file_id, ierr)
!    Close FORTRAN interface.
     CALL h5close_f(ierr)
#endif

#ifdef ITAC
  ! Finalize tracer
  ! call VTFINI(mpinfo)
#endif 
#ifdef MPI
     !call MPI_BARRIER(parallel%comm,mpinfo) !bugfix UNNEEDED
     call MPI_FINALIZE(mpinfo)
#endif
! \note AJB: intel inspector still says ierr_tmp is uninitialized
! commenting here to follow in the future
     stop
  endif

end subroutine exit_err
end module error_handlers
