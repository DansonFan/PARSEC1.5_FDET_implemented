!> \brief provides modular enumerator for error codes
!! \author Charles Lena
!! \date 2017-01-20 : written 
!! \date 2017-01-22 : changed to parameters to support doxygen parsing
!! \note Enumerations aren't support by doxygen, and since integer,
!!  parameters work just as well for our purpose, we should stick with them
!!  for now instead of enumerations. 
!!  
!! What we really want are
!! enumerations in the C++ sense, which is to say classes of codes that
!! error out a function if given the wrong code (e.g. `int foo(enum ErrorCode)`
!! errors out if given a raw integer, because that's not an `enum
!! Error Code`
module error_codes
      integer, parameter :: ERR_NOERROR = 0 !< no error

      integer, parameter :: ERR_MALFORMED_FILE_INPUT = 100 !< specific bad file input
      integer, parameter :: ERR_IMPOSSIBLE_FILE_INPUT = 101 !< specific bad file input

      integer, parameter :: &
         ERR_OOB_H_PROJ_I_LOW = 1000,& !< out of bounds (low) index I H_projection matrix
         ERR_OOB_H_PROJ_J_LOW = 1001,& !< out of bounds (low) index J H_projection matrix
         ERR_OOB_H_WORK_I_LOW = 1002,& !< out of bounds (low) index J H_work matrix
         ERR_OOB_H_PROJ_I_HIGH = 1003,& !< out of bounds (high) index I H_projection matrix
         ERR_OOB_H_PROJ_J_HIGH = 1004,& !< out of bounds (high) index J H_projection matrix
         !< \callergraph
         ERR_OOB_H_WORK_I_HIGH = 1005  !< out of bounds (high) index J H_work matrix
      !! \callergraph

      integer, parameter :: &
         ERR_PEIGZ_JOB_SPEC = 200 ,& !< jobz must be either 'N' or 'V'
         ERR_RR_RANK_DEFICIENT_JOB1 = 201 ,& !< more eigenvalues than columns requested \see <rayleigh_ritz.f90z>
         ERR_RR_RANK_DEFICIENT_JOB2 = 202 !< more eigenvalues than columns requested \see <rayleigh_ritz.f90z> \note this is okay i guess

      integer, parameter :: &
         ERR_BAD_MATRIX_SHAPE = 8000 !< indicates a bad matrix shape for <new_file_template.f90>
end module error_codes
