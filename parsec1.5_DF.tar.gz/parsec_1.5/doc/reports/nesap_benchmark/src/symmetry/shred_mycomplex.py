#!/usr/bin/env python
# @author Charles Lena
# @date 04/14/2017
# @brief Lists out mycomplex.h and provides scripts to refactor the codebase
# @details creates newcommands.sh and a mycomplex.h.new
import subprocess as sp
import re, sys
def digest_mycomplex(mapping):
# eat the mycomplex.h file
    with open('mycomplex.h','r') as file_in:
        data = file_in.read()
    data = re.split(r'#else',data,re.MULTILINE)
    data[0] = data[0].splitlines()[1:]
    data[1] = data[1].splitlines()[1:-1]
    i = 0
    for datum in data:
        for line in datum:
            tokens = re.match(r'#define\s+(\S+)\s+(\S+)',line)
            if not tokens:
                tokens = re.match(r'#define\s+(\S+)',line)
            if i == 0:
                if mapping.__contains__(tokens.group(1)):
                    raise Exception("DUPLICATE TOKEN IN SAME SECTION: {:s}".format(tokens.group(1)))
                mapping[tokens.group(1)] = ['#undef','#undef']
            else:
                if not mapping.__contains__(tokens.group(1)):
                    raise Exception("MISSING TOKEN FROM FIRST SECTION: {:s}".format(tokens.group(1)))
            if mapping[tokens.group(1)][i] != '#undef':
                raise Exception("DUPLICATE TOKEN IN SAME SECTION: {:s}".format(tokens.group(1)))
            try:
                mapping[tokens.group(1)][i] = tokens.group(2)
            except IndexError as err:
                mapping[tokens.group(1)][i] = None
        for token in mapping:
            if mapping[token][i] == '#undef':
                print("MISSING TOKEN FROM SECTION {:d}: {:s}".format(i,token))
        i=i+1

    print('=====unused====================================')
# removing unused mycomplex.h tokens
    unuseds = list()
    locales = list()
    for token in mapping:
        task = sp.Popen(
                r'grep -l -o -E "[^a-zA-Z0-9_!]?*({0:s})[^a-zA-Z0-9_]*" *.f90z '.format(token),
                shell=True, stdout=sp.PIPE).communicate()
        if task[0] == '': 
            unuseds.append(token)
        else:
            locales.append(' {token:30s} || {:s}'.format(' '.join(task[0].split('\n')), token=token))


    unuseds.sort()
    locales.sort()
    for unused in unuseds: 
        mapping.pop(unused)

    for unused in zip(unuseds[0::3],unuseds[1::3],unuseds[2::3]):
        print ('{:25s} '*3).format(*unused)

    print('=====locations====================================')
    for lc in locales: print lc


# categorizing remaining tokens
    uniques = list()
    symmetrics = list()
    nonsymmetrics = list()
    for token, vals in mapping.iteritems():
        TOKEN_PREFIX_IS_CAP_T  = (token[0:3] == '__T')
        TOKEN_PREFIX_IS_DBLE_T = (token[0:4] == '__t_')
        TOKEN_PREFIX_IS_Z      = (token[0] == 'Z')
        TOKEN_PREFIX_IS_NONE   = not any((TOKEN_PREFIX_IS_CAP_T, TOKEN_PREFIX_IS_DBLE_T, TOKEN_PREFIX_IS_Z))
        VAL1_PREFIX_IS_Z = (vals[0][0] == 'z')
        VAL1_PREFIX_IS_D = (vals[0][0] == 'd')
        VAL1_PREFIX_IS_NONE = not any((VAL1_PREFIX_IS_Z, VAL1_PREFIX_IS_D))
        VAL2_PREFIX_IS_Z = (vals[1][0] == 'z')
        VAL2_PREFIX_IS_D = (vals[1][0] == 'd')
        VAL2_PREFIX_IS_NONE = not any((VAL2_PREFIX_IS_Z, VAL2_PREFIX_IS_D))
        VAL1_EXACTMATCH_VAL2   = (vals[0] == vals[1]) # marks something as unneeded
        VAL1_PARTIALMATCH_VAL2 = (vals[0][1:] == vals[1][1:]) # z<> -- d<>
        VAL1_IN_VAL2           = (vals[0][1:] == vals[1][:]) # z<> -- <>
        VAL1_NONE_VAL2         = not any((VAL1_EXACTMATCH_VAL2, VAL1_PARTIALMATCH_VAL2, VAL1_IN_VAL2))
# __T None <----> None
        if VAL1_EXACTMATCH_VAL2:
            uniques.append(token)
            continue

        if TOKEN_PREFIX_IS_NONE or TOKEN_PREFIX_IS_CAP_T: 
            uniques.append(token)
            continue
# __t_ or Z
        if TOKEN_PREFIX_IS_DBLE_T or TOKEN_PREFIX_IS_Z:
            if (
                    (
                        all((VAL1_PREFIX_IS_NONE, VAL2_PREFIX_IS_NONE)) 
                        )
                    ):
                uniques.append(token)
                continue
# >> z <----> d
            if (
                    (
                        all((VAL1_PREFIX_IS_Z, VAL2_PREFIX_IS_D)) 
                        or 
                        all((VAL2_PREFIX_IS_Z, VAL1_PREFIX_IS_D))
                        )
                    and 
                    (vals[0][1:] == vals[1][1:])):
                symmetrics.append(token)
                continue
            if (
                    (
                        all((VAL1_PREFIX_IS_Z, VAL2_PREFIX_IS_D)) 
                        or 
                        all((VAL2_PREFIX_IS_Z, VAL1_PREFIX_IS_D))
                        )
                    and 
                    (vals[0][1:] == vals[1][:])):
                nonsymmetrics.append(token)
                continue
# >> z <----> None
            if (
                    (
                        all((VAL1_PREFIX_IS_Z, VAL2_PREFIX_IS_NONE)) 
                        or 
                        all((VAL2_PREFIX_IS_Z, VAL1_PREFIX_IS_NONE))
                        )
                    and
                    (vals[0][1:] == vals[1][:])):
                nonsymmetrics.append(token)
                continue
            if (
                    (vals[0][1:] == vals[1][:])):
                nonsymmetrics.append(token)
                continue
            if ( 
                    ( 
                        vals[0] != '#undef' 
                        ) and (
                            vals[1] != '#undef')):
                uniques.append(token)
                continue
        error = Exception('Unhandled case? token: {:s} vals: {:s} {:s} '.format(token,*vals))
        raise error

    uniques.sort()
    symmetrics.sort()
    nonsymmetrics.sort()

    print('=====uniques================================================')
    print("{:30s} {:30s} {:30s}".format("TOKEN","VAL1","VAL2"))
    print('============================================================')
    for unique in uniques:
        print("{:30s} {:30s} {:30s}".format(unique,*mapping[unique]))
    print('=====symmetric==============================================')
    print("{:30s} {:30s} {:30s}".format("TOKEN","VAL1","VAL2"))
    print('============================================================')
    for symmetric in symmetrics:
        print("{:30s} {:30s} {:30s}".format(symmetric,*mapping[symmetric]))
    print('=====nonsymmetric===========================================')
    print("{:30s} {:30s} {:30s}".format("TOKEN","VAL1","VAL2"))
    print('============================================================')
    for nonsymmetric in nonsymmetrics:
        print("{:30s} {:30s} {:30s}".format(nonsymmetric,*mapping[nonsymmetric]))
    return (uniques, symmetrics, nonsymmetrics, mapping)

def FandRsymms(uniques, symmetrics, nonsymmetrics, mapping):
# new tokens
    tokens = list(mapping.keys())
    tokens.sort(key=lambda x: len(x),reverse=True)
    token_sed = 'sed -i.bkp -r '+''.join(['-e "s/{0:s}/{2:s}{1:s}/g" \\\n'.format(
        token, token[1:], ('__t_' if (not (token in uniques)) else '__T')
        ) for token in tokens if (token[0]=='Z')]) + ' *.f90z \n'

    nonsymmetric_sed = 'sed -i.bkp -r '+''.join(['-e "s/^([^!]+[^a-zA-Z0-9_!]){0:s}([^a-zA-Z0-9_])/\\1{2:s}{1:s}\\2/g" \\\n'.format(
        mapping[token][1][:], mapping[token][1][:], 'd'
        ) for token in nonsymmetrics]) + ' *.f90z \n'

    with open('replace_tokens.sh','w') as file_h:
        file_h.write('#!/bin/bash\n')
        file_h.write('# token seds\n')
        file_h.write(token_sed)

    with open('replace_nonsymmetrics.sh','w') as file_h:
        file_h.write('# nonsymmetric seds\n')
        file_h.write(nonsymmetric_sed)

def create_mycomplex(uniques, symmetrics, nonsymmetrics, mapping, tokenmods=['Z','__t_'], valuemods=[1,'d']):
    def token_fxn(x, tokenmods=tokenmods):
        if(x[0:len(tokenmods[0])]==tokenmods[0]):
            return tokenmods[1]+x[len(tokenmods[0]):]
        else:
            return x
    def valuemods_fxn(x,ix):
        if ix==valuemods[0]:
            return valuemods[1]+x
        else:
            return x

    '''
### good thought but not now
    for unique in uniques:
        if token_fxn(unique,['Z','__T']) in mapping:
            error = Exception('Transformation Error: Transformation of {0:s} resulted in name collision'.format(unique))
            raise error

    for symmetric in symmetrics:
        if token_fxn(symmetric) in mapping:
            error = Exception('Transformation Error: Transformation of {0:s} resulted in name collision'.format(symmetric))
            raise error

    for nonsymmetric in nonsymmetrics:
        if token_fxn(nonsymmetric) in mapping:
            error = Exception('Transformation Error: Transformation of {0:s} resulted in name collision'.format(nonsymmetric))
            raise error

##########################
'''
    with open('mycomplex.h.new','w') as mycomplex:
        mycomplex.write("#ifdef CPLX\n")
        for ix in range(2):
            if ix==1: mycomplex.write("#else\n")
            for unique in uniques:
                mycomplex.write("#define {:s} {:s}\n".format(token_fxn(unique,['Z','__T']),mapping[unique][ix]))
            # dont actually need these because __t_ --> z,d 
            #for symmetric in symmetrics:
            #    mycomplex.write("#define {:s} {:s}\n".format(token_fxn(symmetric),mapping[symmetric][ix]))
            for nonsymmetric in nonsymmetrics:
                mycomplex.write("#define {:s} {:s}\n".format(token_fxn(nonsymmetric),valuemods_fxn(mapping[nonsymmetric][ix],ix)))
        mycomplex.write("#endif")

if __name__=='__main__':
    mapping = dict()
# digest
    uniques, symmetrics, nonsymmetrics, mapping = digest_mycomplex(mapping)
# sed scripts
    FandRsymms(uniques, symmetrics, nonsymmetrics, mapping)
# new mycomplex
    create_mycomplex(uniques, symmetrics, nonsymmetrics, mapping)
    sys.exit()
