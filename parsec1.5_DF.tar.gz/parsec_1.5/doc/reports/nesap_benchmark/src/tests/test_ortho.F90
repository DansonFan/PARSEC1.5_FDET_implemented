!> @brief tests ortho capabilities and scaling
program orthotest
      use constants, only : dp, dpc
      use dgks_module
      implicit none
end program
