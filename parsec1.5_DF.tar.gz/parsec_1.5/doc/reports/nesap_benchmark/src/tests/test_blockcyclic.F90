!> @brief tests blockcyclic capabilities and scaling
program blockcyclictest
   use constants, only : dp, dpc
   use external_interfaces
   use blockcyclic_utility, only : dextract_symmdist_simple
   use mpi_f08
   implicit none
   integer, parameter :: &
      nblk = 4
   integer :: nwant
   integer :: verbose
   ! 0 1 0 1 0 1
   ! 2 3 2 3 2 3
   ! 0 1 0 1 0 1
   ! 2 3 2 3 2 3
   ! 0 1 0 1 0 1
   ! 2 3 2 3 2 3
   type(mpi_comm) :: op_comm
   integer :: nprocs,&
      myid,&
      mpierr,&
      my_blacs_ctxt
   integer :: na_rows,&
      na_cols,&
      np_cols, &
      np_rows,&
      my_pcol,&
      my_prow,&
      nprow,&
      npcol
   real(dp), allocatable :: projl(:,:), tile(:,:), time1, time2
   integer :: tile_cols, tile_rows, tile_extents(4)
   integer :: i_global, j_global
   integer :: j_iter, i_iter
   character(8) :: filename
   character(9) :: ending

   call MPI_Init(mpierr)
   op_comm = MPI_COMM_WORLD
   call mpi_comm_rank(op_comm, myid)
   call mpi_comm_size(op_comm, nprocs)
   write(filename,'("out.",I4.4)') myid
   open(unit=9, file=filename, status='unknown')

   do np_cols = NINT(SQRT(REAL(nprocs,dp))),2,-1
      if(mod(nprocs,np_cols) == 0 ) exit
   enddo
   ! at the end of the above loop, nprocs is always divisible by np_cols
   np_rows = nprocs/np_cols

   my_blacs_ctxt = mpi_comm_world % mpi_val
   call BLACS_Gridinit( my_blacs_ctxt, 'C', np_rows, np_cols )
   call BLACS_Gridinfo( my_blacs_ctxt, nprow, npcol, my_prow, my_pcol )

   ! Determine the necessary size of the distributed matrices,
   ! we use the Scalapack tools routine NUMROC for that.

   do nwant = 12800,18000,64
      na_rows = numroc(nwant, nblk, my_prow, 0, np_rows)
      na_cols = numroc(nwant, nblk, my_pcol, 0, np_cols)
      verbose = 3
      write(9,*) '# my_prow: ', my_prow, ' my_pcol: ', my_pcol
      write(9,*) '# prows: ', np_rows, ' pcols: ', np_cols
      write(9,*) '# rows: ', na_rows, ' cols: ', na_cols
      if(allocated(projl)) deallocate(projl)
      allocate(projl(na_rows, na_cols))
      projl = 0.d0
      j_iter = 0
#if 0
      write(ending,'(".",I4.4,".dat")') j_iter
      open(unit=10,file=filename // ending, status='unknown',&
         form='unformatted')
      write(10) 2
      write(10) shape(projl)
      write(10) projl
      close(10)
#endif
      i_global = 1
      tile_rows = nwant
      tile_cols = 24
      if(allocated(tile)) deallocate(tile)
      allocate(tile(tile_rows, tile_cols))
      time1 = mpi_wtime()
      do j_global = 1,nwant,nblk
         i_global = j_global
         j_iter = j_iter + 1
         tile(:,:) = real(j_iter,dp)
         tile_extents = [ 1, nwant-j_global+1, 1, min(nblk, nwant-j_global+1)]
         if (.false. .and. myid==0) write(*,'("#D1 ",4I4)') i_global, j_global, tile_rows, tile_cols
         if (.false. .and. myid==0) write(*,'("#D2 ",4I4)') tile_extents
         call dextract_symmdist_simple(nwant, nblk,&
            my_prow, my_pcol, np_rows, np_cols,&
            myid, projl, na_rows, na_cols, tile,&
            tile_rows, tile_extents, tile_cols, tile_rows,&
            i_global, j_global, &
            verbose=verbose)
#if 0
         write(ending,'(".",I4.4,".dat")') j_iter
         open(unit=10,file=filename // ending, status='unknown',&
            form='unformatted')
         write(10) 2
         write(10) shape(projl)
         write(10) projl
         close(10)
#endif
         verbose=3
      enddo
      time2 = mpi_wtime()
      call MPI_Barrier(op_comm)
      if(myid==0) write(*,*) nwant, time2-time1
   enddo
   deallocate(tile)
   close(9)
   call MPI_Finalize(mpierr)
end program
