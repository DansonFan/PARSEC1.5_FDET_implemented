!> @brief tests ariel's init_vect capabilities and scaling
program init_vecttest
      use constants, only : dp, dpc
      implicit none
end program
