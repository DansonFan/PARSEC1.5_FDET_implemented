program Fibonacci
   implicit none
   integer,parameter  :: N=45
   integer :: i, a(0:N-1), b(0:N-1)
   integer, external :: fib
   do i = 0,N-1
      b(i) = i
   end do
   do i=0,N-1
      a(i) = fib(b(i))
   enddo
   write(*,*) "Done a(", N-1, ") = ", a(N-1) ! 44 1134903168
end program

recursive function fib(n) result(r)
!$omp declare simd(fib) inbranch
   implicit none
   integer :: n, r
   if (n <= 2) then
      r = n
   else
      r = fib(n-1) + fib(n-2)
   endif
end function fib

function factorial(n) result(r)
!$omp declare simd(factorial) inbranch
   implicit none
   integer :: n, r
   integer :: i
   r = n
   if (n <= 2) return
   do i = n-1,2,-1
      r = r * i
   enddo
end function factorial
module watchmesurvive
contains
subroutine d222_DU(cDiag,outvec)
#if CRASHME
   !$OMP DECLARE SIMD(d222_DU) UNIFORM(cDiag) &
   !$OMP ALIGNED(outvec:64)
#else
   !$OMP DECLARE SIMD UNIFORM(cDiag) &
   !$OMP ALIGNED(outvec:64)
#endif
   ! [ cDiag,  0,  0,  0, cU,  0,  0,  0]
   ! [  0, cDiag,  0,  0,  0, cU,  0,  0]
   ! [  0,  0, cDiag,  0,  0,  0, cU,  0]
   ! [  0,  0,  0, cDiag,  0,  0,  0, cU]
   ! [  0,  0,  0,  0, cDiag,  0,  0,  0]
   ! [  0,  0,  0,  0,  0, cDiag,  0,  0]
   ! [  0,  0,  0,  0,  0,  0, cDiag,  0]
   ! [  0,  0,  0,  0,  0,  0,  0, cDiag]
   integer, parameter :: vecsize = 8
   integer, parameter :: shft=4
   real(kind=selected_real_kind(15,300)), intent(in)    :: cDiag
   real(kind=selected_real_kind(15,300)), pointer, intent(inout) :: outvec(:)
   integer :: inner

   do inner=1,4
      outvec(inner+shft) = cDiag * invec(inner+shft) + outvec(inner+shft)
      outvec(inner)      =    cU * invec(inner+shft) + outvec(inner)
      outvec(inner)      = cDiag * invec(inner)      + outvec(inner)
   enddo
end subroutine d222_DU
end module watchmesurvive
