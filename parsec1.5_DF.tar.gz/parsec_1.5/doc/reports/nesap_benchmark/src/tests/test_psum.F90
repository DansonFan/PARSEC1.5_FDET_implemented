program test_psum
        use constants, only : dp, dpc
        use psum_module
        use mpi
        implicit none
        integer :: i, j, ierr
        integer :: mycomm, mygroup, nprocs, myid
        integer, parameter :: first = 4, second = 3, one = 1
        real(dp) :: r, rv(one:first), prv(one), prv2(one:first,one:second)
        complex(dpc) :: c, cv(one:first), pcv(one), pcv2(one:first,one:second)

        call MPI_Init(ierr)
        mycomm = mpi_comm_world
        call mpi_comm_rank(mycomm,myid,ierr)
        call mpi_comm_size(mycomm,nprocs,ierr)
        mygroup = nprocs


        ! real tests
        if(myid==0) write(*,*) "real tests"
        !! scalar tests
        if(myid==0) write(*,*) "real scalar tests"
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(r,mygroup,mycomm)
        if(myid==0) write(*,1337) r,r == nprocs * 1.0_dp

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv2(3,3),one,mygroup,mycomm)
        if(myid==0) write(*,1337) prv2(3,3),prv2(3,3) == nprocs * 1.0_dp

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(rv(3),one,mygroup,mycomm)
        if(myid==0) write(*,1337) rv(3),rv(3) == nprocs * 1.0_dp

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(rv(3),mygroup,mycomm)
        if(myid==0) write(*,1337) rv(3),rv(3) == nprocs * 1.0_dp

        !! length 1 vector tests
        if(myid==0) write(*,*) "real length 1 tests"
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv,one,mygroup,mycomm)
        if(myid==0) write(*,1337) prv,prv(one) == nprocs * 1.0_dp

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv(one),one,mygroup,mycomm)
        if(myid==0) write(*,1337) prv,prv(one) == nprocs * 1.0_dp

        !! length first vector tests
        if(myid==0) write(*,*) "real length first - vector tests"
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(rv,first,mygroup,mycomm)
        if(myid==0) write(*,1338) (rv(i),i=1,first),(rv(i) == nprocs * 1.0_dp,i=1,first)

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(rv(1:first),first,mygroup,mycomm)
        if(myid==0) write(*,1338) (rv(i),i=1,first),(rv(i) == nprocs * 1.0_dp,i=1,first)

        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv2(:,3),first,mygroup,mycomm)
        if(myid==0) write(*,1338) prv2(:,3),(prv2(i,3) == nprocs * 1.0_dp,i=1,first)

        !! length second vector tests
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv2(3,:),second,mygroup,mycomm)
        if(myid==0) write(*,"(3E26.16,3L)") prv2(3,:),(prv2(3,i) == nprocs * 1.0_dp,i=1,second)

#ifdef CAUSE_ARG_TEMPORARY
        !! length (first x second) vector tests
        if(myid==0) write(*,*) "real length first x second - vector tests"
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv2,first*second,mygroup,mycomm)
        if(myid==0) write(*,1339) prv2,((prv2(i,j) == nprocs * 1.0_dp,i=1,first),j=1,second)
#endif

        !! length (first x second) vector tests
        call reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,first,second)
        call psum(prv2(1,1),first*second, mygroup,mycomm)
        if(myid==0) write(*,1339) prv2,((prv2(i,j) == nprocs * 1.0_dp,i=1,first),j=1,second)

        1337 format(E26.16,L)
        1338 format(4E26.16,4L)
        1339 format(12E26.16,12L)

        !!!!
        ! complex tests
        !!!!
        

        2337 format(2E26.16,L)
        2338 format(4(2E26.16),4L)
        2339 format(12(2E26.16),12L)

        call MPI_Finalize(ierr)
end program test_psum
subroutine reset_testvars(r,rv,prv,prv2,c,cv,pcv,pcv2,n,m)
        use constants, only : dp, dpc
        implicit none
        integer, intent(in) :: n, m
        real(dp), intent(inout) :: r, rv(1:n), prv(1), prv2(1:n,1:m)
        complex(dpc), intent(inout) :: c, cv(1:n), pcv(1), pcv2(1:n,1:m)
        r = 1.0_dp
        rv = 1.0_dp
        prv = 1.0_dp
        prv2 = 1.0_dp
        c = cmplx(2.0_dpc,2.0_dpc)
        cv = cmplx(2.0_dpc,2.0_dpc)
        pcv = cmplx(2.0_dpc,2.0_dpc)
        pcv2 = cmplx(2.0_dpc,2.0_dpc)
end subroutine
