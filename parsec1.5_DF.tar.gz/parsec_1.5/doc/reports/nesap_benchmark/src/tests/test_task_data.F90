module mymodule
    integer, parameter :: dp = kind(0.d0)
    type fold_stencil
       integer :: nnz = 0
       real(dp), allocatable :: rows(:)
       contains
    end type fold_stencil
end module
program Fibonacci
   use mymodule
   implicit none
   integer,parameter  :: N=45
   integer, parameter :: grain_size = 64, foldsize = 8
   integer :: i, a(0:N-1), b(0:N-1)
   integer, external :: fib
   integer :: irow, lapmverr, tempvec
   type(fold_stencil) :: my_sten_edges
   do i = 0,N-1
      b(i) = i
   end do
   do i=0,N-1
      a(i) = fib(b(i))
   enddo
   write(*,*) "Done a(", N-1, ") = ", a(N-1) ! 44 1134903168
!$OMP PARALLEL &
!$OMP& PRIVATE(irow,lapmverr,tempvec) &
!$OMP& DEFAULT(SHARED)

    lapmverr = 0
!$OMP MASTER
    do irow=1,tasklim,grain_size
!$OMP TASK FIRSTPRIVATE(irow,lakjpmverr) &
!$OMP& DEPEND(out:my_sten_edges%rows)
       call real_internal_edges_222_depth6(irow,grain_size,&
          foldsize,coeff=sten_coeff,workdim=tempsize,&
          indim=mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
!$OMP END TASK
    enddo !irow (my)

    if (leftover>0) then
!$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
!$OMP& DEPEND(out:my_sten_edges%rows)
       call real_internal_edges_222_depth6(irow,leftover,&
          foldsize,coeff=sten_coeff,workdim=tempsize,&
          indim=mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
!$OMP END TASK
    endif
#if 0
    if (group_size > 1 ) then
       call fold_buff%packsend(parallel,vec=lap_in,vec_num=1)
       call fold_buff%nonblock_comm(parallel)
       call fold_buff%wait_on_comm(vec_index=1)
    endif
#endif
    if (group_size > 1 ) then
       do irow=1,tasklim,grain_size
          !$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
          !$OMP& DEPEND(in:my_sten_edges%rows(irow))
          call real_ghost_edges_222_depth6(irow,grain_size,&
             foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=buffdim,&
             outdim=mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
          !$OMP END TASK

       enddo !irow
       if (leftover>0) then
!         write(9,*) "DEBUG: some rows are leftover!, leftover,irow = ",leftover,irow
          !$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
          !$OMP& DEPEND(in:my_sten_edges%rows(irow))
          call real_ghost_edges_222_depth6(irow,leftover,foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=buffdim,&
             outdim=mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
!$OMP END TASK

       endif
    endif
!$OMP END MASTER
! no need for this one
!$OMP BARRIER
!$OMP END PARALLEL
end program
recursive function fib(n) result(r)
!$omp declare simd(fib) inbranch
   implicit none
   integer :: n, r
   if (n <= 2) then
      r = n
   else
      r = fib(n-1) + fib(n-2)
   endif
end function fib

subroutine real_internal_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,workdim,indim,invec,outvec,workvec) !{{{
   use mymodule
    implicit none
    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: indim, workdim
    real(dp), intent(in) :: invec(indim) 
    real(dp), intent(inout) :: outvec(indim) 
    real(dp), intent(inout) :: workvec(workdim) 
    integer icol,irow
    integer i,j
    integer, parameter :: foldsize=8
    integer, parameter :: maxnumedges=18
    integer, dimension(blksize) :: nval, rowptr, colstart
    !DIR$ attributes align:64 :: nval, rowptr,colstart
    integer, dimension(maxnumedges) :: colptr,edgeval
    !DIR$ attributes align:64 :: colptr,edgeval
    ! real(dp) :: tempin(foldsize)
    real(dp) :: tempout(foldsize)
    !DIR$ attributes align:64 :: tempout
end subroutine
subroutine real_ghost_edges_222_depth6(row0,blksize,foldsize_dummy,coeff,buffdim,workdim,outdim,&
      buffvec,outvec,workvec) !{{{
   use mymodule
    implicit none
    integer, intent(in) :: row0,blksize,foldsize_dummy
    type(fold_stencil), intent(in) :: coeff
    integer, intent(in) :: buffdim, workdim
    integer, intent(in) :: outdim
    real(dp), intent(in) :: buffvec(buffdim) 
    real(dp), intent(inout) :: outvec(outdim) 
    real(dp), intent(inout) :: workvec(workdim) 
    integer, parameter :: foldsize=8
end subroutine
function factorial(n) result(r)
!$omp declare simd(factorial) inbranch
   implicit none
   integer :: n, r
   integer :: i
   r = n
   if (n <= 2) return
   do i = n-1,2,-1
      r = r * i
   enddo
end function factorial
