program main

      complex(kind((0.d0,0.d0))) :: x, y
      x = (1.d0,-1.d0)
      y = (-1.d0,1.d0)
      write(*,*) x
      write(*,*) y
      write(*,*) x+y
      write(*,*) x % re +y % re

end program
