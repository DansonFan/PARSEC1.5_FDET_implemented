module laplacian_ops_module
   implicit none
   contains
#if 0
subroutine laplacian(parallel,sten_def,lap_buff,lap_in,lap_out) !{{{
!===============================================================
!
!  Distributed Laplacian operator. This subroutine receives as
!  input a distributed function over the grid (array lap_in) and
!  operates the laplacian over it, using finite differences.
!  Output is distributed function lap_out = -Laplacian(lap_in).
!
!  WARNING: notice that the output laplacian has a minus sign!
!
!  WARNING: input function func is assumed to have the full
!  symmetry of the system, so there are no representation
!  characters (cf. subroutine matvec).
!
!---------------------------------------------------------------
! REAL, full symmetry laplacian operator with communication, assuming comm buffers externally managed
    use parallel_data_module
    use dbuffer_module
    use dlaplacian_module
    use stencil_things
    use constants 

  implicit none
#ifdef ITAC
  include 'VT.inc'
  include 'vtcommon.inc'
#endif

    type (parallel_data), intent(in) :: parallel

    type (stencil_definitions), intent(inout) :: sten_def
    type (lap_buffer), intent(inout)   :: lap_buff

    real(dp), intent(in)    :: lap_in(parallel%mydim)
    real(dp), intent(out)   :: lap_out(parallel%mydim)
    
    real(dp), dimension(parallel%myworkdim+1) :: workvec

    integer :: first_index, last_internal_point, save_actual_nrep
    real(dp) :: dummy_chi(1)

    integer :: lapmverr


!    write(9,*) "hello from old laplacian, mydim:",parallel%mydim
    !write(9,*) "myworkdim:",parallel%myworkdim
    sten_def%nrep = 1 !symmetry hack 

!$OMP PARALLEL &
!$OMP& PRIVATE(first_index,last_internal_point,dummy_chi,lapmverr) &
!$OMP& DEFAULT(SHARED)

    lapmverr = 0
#ifdef ITAC
    call VTBEGIN(vt_lap_inner , lapmverr)
#endif

    first_index=1
    last_internal_point=parallel%inter1 !will be different in case of varying lap order
    dummy_chi=one
    ! start parallel construct

    ! buffer object is input argument, can check communications
    ! so hpotcg etc. therefore should take care externally of init/allocate/destroy


#ifdef ITAC
    call VTBEGIN(vt_buffer , lapmverr)
#endif
!$OMP MASTER
   if (parallel%group_size > 1 ) then
!    write(9,*) "packing buffer"
    call dbuff_lap_pack(parallel,lap_buff,lap_in,1,1,1,parallel%mydim)
    call dbuff_lap_comm(parallel,lap_buff)
!    write(9,*) "done communication I"
   endif
!$OMP END MASTER
#ifdef ITAC
    call VTEND(vt_buffer , lapmverr)
#endif


    ! copy/map input vector to work vector (high bandwidth memory/xeon phi?)
    call dlap_copy_to_workvec(lap_in,parallel%mydim,workvec,parallel%myworkdim+1)


#ifdef ITAC
    call VTBEGIN(vt_buffer , lapmverr)
#endif
!$OMP MASTER
   if (parallel%group_size > 1 ) then
    ! finish communications and unpack buffer to work vector
    call buff_lap_check_comm(lap_buff,1)
    call dbuffer_lap_unpack(parallel,workvec,lap_buff)
!    write(9,*) "done upacking buffer"
   endif
!$OMP END MASTER
#ifdef ITAC
    call VTEND(vt_buffer , lapmverr)
#endif
    ! 1D lap coefficents are already ready
    ! if there are enough internal points, commence laplacian
    if (last_internal_point > 1) then
! write(9,*) "laplacian crunch inner"
! write(9,*) "coeff2_1D test"
! write(9,*) sten_def%coeff2_1D
    ! calculate diagonal term - also initalizes output vector
    call dlap_diag_true(parallel,first_index,last_internal_point,parallel%mydim,sten_def%coeff2_diag,&
       lap_in,parallel%mydim,lap_out,parallel%mydim) 
    call dlaplacian_crunch(parallel,sten_def,sten_def%coeff2_1D,dummy_chi,first_index,last_internal_point,&
       workvec,lap_out,parallel%mydim)
                                                             !^hack for symmetry
! write(9,*) "laplacian crunch inner done"
    endif
! no need because of internal barriers inside functions
! !$OMP BARRIER
    ! complete laplacian calculation
!write(9,*) "laplacian crunch_final up to",parallel%mydim
    call dlap_diag_true(parallel,last_internal_point+1,parallel%mydim,parallel%mydim,sten_def%coeff2_diag,&
       lap_in,parallel%mydim,lap_out,parallel%mydim) 
    call dlaplacian_crunch(parallel,sten_def,sten_def%coeff2_1D,dummy_chi,last_internal_point+1,&
       parallel%mydim,workvec,lap_out,parallel%mydim)
                                                             !^hack for symmetry

!write(9,*) "laplacian done"
#ifdef ITAC
    call VTEND(vt_lap_inner , lapmverr)
#endif
!$OMP END PARALLEL
    sten_def%nrep = save_actual_nrep
!    write(9,*) "bye from laplacian, inter1:",parallel%inter1

end subroutine laplacian !}}}
#endif

subroutine laplacian_fold(parallel,sten_coeff,fold_buff,lap_in,lap_out) !{{{
!===============================================================
!
!  Distributed Laplacian operator. This subroutine receives as
!  input a distributed function over the grid (array lap_in) and
!  operates the laplacian over it, using finite differences.
!  Output is distributed function lap_out = -Laplacian(lap_in).
!
!  WARNING: notice that the output laplacian has a minus sign!
!
!  WARNING: input function func is assumed to have the full
!  symmetry of the system, so there are no representation
!  characters (cf. subroutine matvec).
!
!---------------------------------------------------------------
! REAL, full symmetry laplacian operator with communication, assuming comm buffers externally managed
    use parallel_data_module
    use dbuffer_module
    use stencil_things
    use constants 
    use omp_lib

  implicit none
#ifdef ITAC
  include 'VT.inc'
  include 'vtcommon.inc'
#endif

    type (parallel_data), intent(in) :: parallel

    type (fold_stencil), intent(in) :: sten_coeff
    type (fold_buffer), intent(inout)   :: fold_buff

    real(dp), intent(in)    :: lap_in(parallel%mydim)
    real(dp), intent(out)   :: lap_out(parallel%mydim)

!    real(dp), dimension(parallel%myworkdim+1) :: workvec
    real(dp), dimension (:), allocatable :: tempvec
#if defined(IS_ICC)
!DIR$ attributes align:64 :: tempvec
#endif
    integer:: tempsize

!    integer :: first_index, last_internal_point, save_actual_nrep
    integer :: irow,grain_size,foldsize,tasklim,leftover,ntasks,dummy
!    real(dp) :: dummy_chi(1)

    integer :: lapmverr

     foldsize=sten_coeff%foldsize
     tempsize=foldsize
     allocate(tempvec(tempsize))

     ! grain_size=my_sten_edges%nrows/GRAIN_DIV

     ! tasklim = my_sten_edges%nrows/grain_size
     ! tasklim = (tasklim-1)*grain_size
     ! leftover = my_sten_edges%nrows - tasklim
      ! write(9,*) "hello from fold laplacian, nrows (mysedges)=",my_sten_edges%nrows
      ! write(9,*) "hello from fold laplacian, nrows (extsedges)=",ext_sten_edges%nrows

     leftover = mod(parallel%mycdim,GRAIN_DIV)
     ntasks = parallel%mycdim - leftover
     !leftover = mod(my_sten_edges%nrows,GRAIN_DIV)
     !ntasks = my_sten_edges%nrows - leftover
     grain_size=max(ntasks/(GRAIN_DIV),1)
     tasklim = ntasks

       ! write(9,*) "hello from fold laplacian, mycdim=",parallel%mycdim
       ! write(9,*) "hello from fold laplacian, grain_size=",grain_size
       ! write(9,*) "hello from fold laplacian, tasklim=",tasklim
       ! write(9,*) "hello from fold laplacian, leftover=",leftover

#ifndef IS_GCC
!$OMP PARALLEL &
!$OMP& PRIVATE(irow,lapmverr,tempvec) &
!$OMP& DEFAULT(SHARED)

    lapmverr = 0
     ! we want the gemv to be done with num_threads=1
#ifdef ITAC
    call VTBEGIN( vt_mvecidle, lapmverr)
#endif

!$OMP MASTER


!    write(9,*) "setting tasks..."
    do irow=1,tasklim,grain_size

!$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
!$OMP& DEPEND(out:my_sten_edges%rows(irow))
#ifdef ITAC
    call VTBEGIN(vt_lap_inner , lapmverr)
#endif
!    write(9,*) "I am irow = ",irow
!    call real_internal_edges(irow,grain_size,foldsize,coeff=sten_coeff,indim=parallel%mydim,invec=lap_in,outvec=lap_out)
    call real_internal_edges_222_depth6(irow,grain_size,foldsize,coeff=sten_coeff,workdim=tempsize,&
       indim=parallel%mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
    call VTEND(vt_lap_inner , lapmverr)
#endif
!$OMP END TASK
    enddo !irow (my)
    ! write(9,*) "DEBUG: last row, nrows  ",irow,my_sten_edges%nrows

    if (leftover>0) then
        ! write(9,*) "DEBUG: some rows are leftover!, leftover,irow = ",leftover,irow
!$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
!$OMP& DEPEND(out:my_sten_edges%rows(irow))
#ifdef ITAC
    call VTBEGIN(vt_lap_inner , lapmverr)
#endif
!    call real_internal_edges(irow,leftover,foldsize,coeff=sten_coeff,indim=parallel%mydim,invec=lap_in,outvec=lap_out)
    call real_internal_edges_222_depth6(irow,leftover,foldsize,coeff=sten_coeff,workdim=tempsize,&
       indim=parallel%mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
    call VTEND(vt_lap_inner , lapmverr)
#endif
!$OMP END TASK
    endif
   
!    write(9,*) "done setting tasks"
#ifdef ITAC
    call VTBEGIN(vt_buffer , lapmverr)
#endif
   if (parallel%group_size > 1 ) then
!    write(9,*) "fold_lap: packing buffer"
    call fold_buff%packsend(parallel,vec=lap_in,vec_num=1)
    call fold_buff%nonblock_comm(parallel)
!    write(9,*) "fold_lap: done communication I"
    ! finish communications and unpack buffer to work vector
    call fold_buff%wait_on_comm(vec_index=1)
    
   endif
#ifdef ITAC
    call VTEND(vt_buffer , lapmverr)
#endif
! $OMP END MASTER

! using depend instead
!  !$OMP BARRIER

! $OMP MASTER
   if (parallel%group_size > 1 ) then
     ! tasklim = ext_sten_edges%nrows/grain_size
     ! tasklim = tasklim*grain_size
     ! leftover = ext_sten_edges%nrows - tasklim
!     write(9,*) "ext_sten_edges%nrows=", ext_sten_edges%nrows
!     write(9,*) "BEGIN EXT EDGES"
    do irow=1,tasklim,grain_size
    !$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
    !$OMP& DEPEND(in:my_sten_edges%rows(irow))
#ifdef ITAC
    call VTBEGIN(vt_lap_outer , lapmverr)
#endif
!    call real_ghost_edges(irow,grain_size,foldsize,coeff=sten_coeff,buffdim=parallel%buffdim,outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out)
    call real_ghost_edges_222_depth6(irow,grain_size,foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=parallel%buffdim,&
       outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
    call VTEND(vt_lap_outer , lapmverr)
#endif
!$OMP END TASK

    enddo !irow
    if (leftover>0) then
!         write(9,*) "DEBUG: some rows are leftover!, leftover,irow = ",leftover,irow
    !$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
    !$OMP& DEPEND(in:my_sten_edges%rows(irow))
#ifdef ITAC
    call VTBEGIN(vt_lap_outer , lapmverr)
#endif
!    call real_ghost_edges(irow,leftover,foldsize,coeff=sten_coeff,buffdim=parallel%buffdim,outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out)
    call real_ghost_edges_222_depth6(irow,leftover,foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=parallel%buffdim,&
       outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
    call VTEND(vt_lap_outer , lapmverr)
#endif
!$OMP END TASK

    endif
!     write(9,*) "END EXT EDGES"

   endif
!$OMP END MASTER

! no need for this one
!$OMP BARRIER

! revert back to original mkl_num_threads=omp_num_threads
#ifdef ITAC
    call VTEND( vt_mvecidle, lapmverr)
#endif
!$OMP END PARALLEL
#else 
!$$OMP PARALLEL &
!$$OMP& PRIVATE(irow,lapmverr,tempvec) &
!$$OMP& DEFAULT(SHARED)

    lapmverr = 0
     ! we want the gemv to be done with num_threads=1
#ifdef ITAC
    call VTBEGIN( vt_mvecidle, lapmverr)
#endif

!$$OMP MASTER


!    write(9,*) "setting tasks..."
!$$OMP TASKLOOP FIRSTPRIVATE(irow,lapmverr) GRAINSIZE(64)
    do irow=1,tasklim,grain_size

#ifdef ITAC
       call VTBEGIN(vt_lap_inner , lapmverr)
#endif
!$$OMP TASK
       call real_internal_edges_222_depth6(irow,grain_size,foldsize,coeff=sten_coeff,workdim=tempsize,&
          indim=parallel%mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
       call VTEND(vt_lap_inner , lapmverr)
#endif
!$$OMP END TASK
    enddo !irow (my)

    if (leftover>0) then
!$$OMP TASK SHARED(my_sten_edges) FIRSTPRIVATE(irow,lapmverr) &
!$$OMP& DEPEND(out:my_sten_edges%rows(irow))
#ifdef ITAC
       call VTBEGIN(vt_lap_inner , lapmverr)
#endif
!    call real_internal_edges(irow,leftover,foldsize,coeff=sten_coeff,indim=parallel%mydim,invec=lap_in,outvec=lap_out)
       call real_internal_edges_222_depth6(irow,leftover,&
          foldsize,coeff=sten_coeff,workdim=tempsize,&
          indim=parallel%mydim,invec=lap_in,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
       call VTEND(vt_lap_inner , lapmverr)
#endif
!$$OMP END TASK
    endif

#ifdef ITAC
    call VTBEGIN(vt_buffer , lapmverr)
#endif
    if (parallel%group_size > 1 ) then
!    write(9,*) "fold_lap: packing buffer"
       call fold_buff%packsend(parallel,vec=lap_in,vec_num=1)
       call fold_buff%nonblock_comm(parallel)
!    write(9,*) "fold_lap: done communication I"
       ! finish communications and unpack buffer to work vector
       call fold_buff%wait_on_comm(vec_index=1)

    endif
#ifdef ITAC
    call VTEND(vt_buffer , lapmverr)
#endif
! $OMP END MASTER

! using depend instead
!  !$$OMP BARRIER

! $OMP MASTER
    if (parallel%group_size > 1 ) then
       ! tasklim = ext_sten_edges%nrows/grain_size
       ! tasklim = tasklim*grain_size
       ! leftover = ext_sten_edges%nrows - tasklim
!     write(9,*) "ext_sten_edges%nrows=", ext_sten_edges%nrows
!     write(9,*) "BEGIN EXT EDGES"
       do irow=1,tasklim,grain_size
          !$$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
          !$$OMP& DEPEND(in:my_sten_edges%rows(irow))
#ifdef ITAC
          call VTBEGIN(vt_lap_outer , lapmverr)
#endif
          call real_ghost_edges_222_depth6(irow,grain_size,foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=parallel%buffdim,&
             outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
          call VTEND(vt_lap_outer , lapmverr)
#endif
!$$OMP END TASK

       enddo !irow
       if (leftover>0) then
!         write(9,*) "DEBUG: some rows are leftover!, leftover,irow = ",leftover,irow
          !$$OMP TASK FIRSTPRIVATE(irow,lapmverr) &
          !$$OMP& DEPEND(in:my_sten_edges%rows(irow))
#ifdef ITAC
          call VTBEGIN(vt_lap_outer , lapmverr)
#endif
          call real_ghost_edges_222_depth6(irow,leftover,foldsize,coeff=sten_coeff,workdim=tempsize,buffdim=parallel%buffdim,&
             outdim=parallel%mydim,buffvec=fold_buff%receive,outvec=lap_out,workvec=tempvec)
#ifdef ITAC
          call VTEND(vt_lap_outer , lapmverr)
#endif
!$$OMP END TASK

       endif
!     write(9,*) "END EXT EDGES"

    endif
!$$OMP END MASTER

! no need for this one
!$$OMP BARRIER

! revert back to original mkl_num_threads=omp_num_threads
#ifdef ITAC
    call VTEND( vt_mvecidle, lapmverr)
#endif
!$$OMP END PARALLEL
#endif
!write(9,*) "laplacian done"


end subroutine laplacian_fold !}}}
end module laplacian_ops_module
