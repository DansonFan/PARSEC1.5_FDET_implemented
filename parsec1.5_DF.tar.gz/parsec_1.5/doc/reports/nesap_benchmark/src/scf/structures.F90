! ===============================================================
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! author: A. Makmal (2005).
!
! ==================== Cluster structure ========================

module cluster_module
  use constants
  use aux, only : alccheck
  implicit none

  type cluster    

     real(dp), dimension (:), pointer :: xatm
     real(dp), dimension (:), pointer :: yatm
     real(dp), dimension (:), pointer :: zatm
     integer, dimension (:), pointer :: mvat 

     ! type for each atom
     integer, dimension (:), pointer :: atype

     ! amass - atomic mass of each ion
     real(dp),  dimension (:), pointer :: amass

     ! number of atoms for each atom type
     integer, dimension (:), pointer :: natmi

     ! force in each axis for each atom
     real(dp), dimension (:,:), pointer :: force

     ! vdw force for each atom in each axis
     real(dp), dimension (:,:), pointer :: vdw_forces

     ! distance of atoms from grid points
     real(dp), dimension (:,:), pointer :: dist_atm

     ! contribution of spin-orbit to non-local force
     complex(dpc), dimension (:,:), pointer :: force_so

     ! name of atom
     character(len=2),  dimension (:), pointer :: name

     ! atom pseudopotential file name
     ! also, why here?
     ! TODO: file length is excessive, maybe should trim it down
     character(len=1024), dimension (:), pointer :: ppfile

     ! total number of atom types
     integer :: type_num
     ! total number of atoms
     integer :: atom_num

     ! flag for the existence of point charges
     logical :: has_ptchrg
     ! number of point charge types
     integer :: npttyp
     ! charge of each point charge type
     real(dp), dimension (:), pointer :: qpt
     ! number of point charges of each type
     integer, dimension (:), pointer :: nptt
     ! total number of point charges
     integer :: nptchrg
     ! coordinates of point charges
     real(dp), dimension (:), pointer :: xpt
     real(dp), dimension (:), pointer :: ypt
     real(dp), dimension (:), pointer :: zpt

     ! flag for the existence of charged sheets
     logical :: has_charged_sheet
     ! number of charged sheet types
     integer :: number_charged_sheet_type
     ! number of charged sheets 
     integer :: number_charged_sheets
     ! charge of each sheet charge type
     real(dp), dimension (:), pointer :: sheet_charge_of_type
     ! number of charged sheets of each type
     integer, dimension (:), pointer :: number_charged_sheets_per_type
     ! coordinates of point charges
     ! real(dp), dimension (:), pointer :: x_charged_sheets
     ! real(dp), dimension (:), pointer :: y_charged_sheets
     real(dp), dimension (:), pointer :: z_charged_sheets

     ! the cutoff radius used to calculate the angular dos
     ! specified for each type
     real(dp), dimension (:), pointer :: ylmdos_cutoff

  end type cluster

contains

  subroutine init_cluster(clust)
    implicit none
    type (cluster), intent (inout) :: clust

    nullify(clust%xatm , clust%yatm, clust%zatm, clust%mvat, clust%amass, clust%natmi, clust%force)
    nullify(clust%force_so, clust%name, clust%ylmdos_cutoff, clust%xpt, clust%ypt)
    nullify(clust%zpt, clust%qpt, clust%nptt, clust%atype)
    nullify(clust%number_charged_sheets_per_type,clust%sheet_charge_of_type,clust%z_charged_sheets)
    nullify(clust%dist_atm)
    nullify(clust%vdw_forces)

  end subroutine init_cluster

  subroutine destroy_cluster (clust)
    implicit none
    type (cluster), intent (inout) :: clust

    if (associated (clust%xatm)) deallocate (clust%xatm) 
    if (associated (clust%yatm)) deallocate (clust%yatm) 
    if (associated (clust%zatm)) deallocate (clust%zatm)      
    if (associated (clust%mvat)) deallocate (clust%mvat)    
    if (associated (clust%amass)) deallocate (clust%amass)  
    if (associated (clust%natmi)) deallocate (clust%natmi)
    if (associated (clust%force)) deallocate (clust%force)
    if (associated (clust%vdw_forces)) deallocate (clust%vdw_forces)
    if (associated (clust%force_so)) deallocate (clust%force_so)
    if (associated (clust%name)) deallocate (clust%name)
    if (associated (clust%ylmdos_cutoff)) deallocate (clust%ylmdos_cutoff)      

    if (associated (clust%xpt)) deallocate (clust%xpt)
    if (associated (clust%ypt)) deallocate (clust%ypt)
    if (associated (clust%zpt)) deallocate (clust%zpt)
    if (associated (clust%qpt)) deallocate (clust%qpt)
    if (associated (clust%nptt)) deallocate (clust%nptt)
    if (associated (clust%atype)) deallocate (clust%atype)

    if (associated (clust%ppfile)) deallocate (clust%ppfile)

    if (associated (clust%dist_atm)) deallocate(clust%dist_atm)
    if (associated (clust%sheet_charge_of_type)) deallocate (clust%sheet_charge_of_type)
    if (associated (clust%number_charged_sheets_per_type)) deallocate (clust%number_charged_sheets_per_type)
    if (associated (clust%z_charged_sheets)) deallocate (clust%z_charged_sheets)

  end subroutine destroy_cluster

  subroutine create_cluster (atom_num, clust)
    implicit none
    integer, intent (inout) :: atom_num
    type (cluster), intent (inout) :: clust

    clust%atom_num = atom_num
    allocate (clust%mvat (atom_num))
    allocate (clust%zatm (atom_num))
    allocate (clust%yatm (atom_num))
    allocate (clust%xatm (atom_num))
    allocate (clust%amass (atom_num))
    allocate (clust%atype (atom_num))
    allocate (clust%force (3,atom_num))
! note that this array is transposed 10110!
    allocate (clust%vdw_forces (atom_num,3))
    allocate (clust%force_so (3,atom_num))
    clust%force_so(:,:) = zzero
    clust%vdw_forces(:,:) = zero

  end subroutine create_cluster

end module cluster_module

! ==================== electronic_struct structure ==============
module electronic_struct_module
  use constants
  use aux, only : alccheck
  implicit none

  type eigenstates

     ! label of the PE group in charge of this representation
     integer :: group
     ! number of computed eigenstates for this representation
     integer :: mm
     ! target number of eigenstates (may differ from mm after a call
     ! to eigval.F because of dynamical adjustment)
     integer :: nn
     ! number of converged eigenstates for this representation
     integer :: nec
     ! eigenvalues
     real(dp), dimension (:), pointer :: en
     ! occupation of each state
     real(dp), dimension (:), pointer :: occ
     integer :: homo
     integer :: lumo
     ! wave function array
     real(dp), dimension (:,:), allocatable :: wf
#if defined(IS_ICC)
    !DIR$ attributes align:64 :: wf
#endif
     complex(dpc), dimension (:,:), allocatable :: zwf
#if defined(IS_ICC)
    !DIR$ attributes align:64 :: zwf
#endif

  end type eigenstates

  type electronic_struct

     ! number of kpoints (<=0 means gamma only)
     integer :: nkpt
     ! kpoint selection method
     integer :: kptmethod
     ! Monkhorts-Pack grid
     integer :: mpgrid(3)
     ! Monkhorts-Pack shift
     real(dp) :: mpshift(3)
     ! DOS Monkhorts-Pack grid
     integer :: dos_mpgrid(3)
     ! DOS Monkhorts-Pack shift
     real(dp) :: dos_mpshift(3)
            
                    
     ! kpoint list (Cartesian coordinates, units of inverse Bohr radius)
     real(dp), dimension (:,:), pointer :: kpts
     ! kpoint weights 
     real(dp), dimension (:), pointer :: kpwt
     ! number of kpoints in full Brillouin zone
     integer :: nkptf
     ! kpoints in full Brillouin zone
     real(dp), dimension (:,:), pointer :: kptf
     ! index of kpoint in IBZ equivalent to each kpoint in full BZ
     integer, dimension (:), pointer :: kptindr
     ! symmetry operation which brings a kpoint in full BZ to the IBZ
     integer, dimension (:), pointer :: kptitran
     ! index of kpoint in IBZ for every kpoint in full BZ, ordered in the MP grid
     integer, dimension (:,:,:), pointer :: kptgrid

     ! number of spins (1 or 2)
     integer :: nspin
     ! number of requested eigenstates
     integer :: nstate
     ! total number of computed eigenstates for each spin orientation,
     ! after droping all states above the maximum computed for any repr.
     integer, dimension(:), pointer :: ntotal
     ! net charge in the system (in units of electron charge)
     real(dp) :: ncharge
     ! actual number of valence electrons in structure
     real(dp) :: xele
     ! electron temperature (in Kelvin)
     real(dp) :: tfermi
     ! fermi level
     real(dp) :: efermi
     ! LDA+U energy
     real(dp) :: etot_plusu
     ! total energy in Rydberg, total energy per atom in eV
     real(dp) :: etot, bdev
     ! exchange-correlation energy
     real(dp) :: exc
     ! ionization energy difference (used with cc correlation flag only)
     real(dp) :: dioniz
     ! choice of exchange-correlation functional (see exc_spn.f and
     ! exc_nspn.f for possible choices)
     character (len=2) :: icorr
     ! flag for real/complex eigenvectors:
     ! .true. if eigenvectors are complex
     ! .false. otherwise
     logical :: cplx

     ! dipole along the three axes
     real(dp) :: dipx, dipy, dipz
     ! charge of cluster
     real(dp) :: charge

     ! total number of electrons in each spin channel
     real(dp), dimension (:), pointer :: totel

     ! number of occupied states in a given iteration
     ! (including partially occupied states and all representations)
     integer, dimension (:), pointer :: ifmax
     ! user-provided occupation of each state (including all
     ! representations)
     real(dp), dimension (:,:), pointer :: occ_in
     ! charge density, global and distributed
     real(dp), dimension (:,:), pointer, contiguous :: rho
     ! core charge density constructed from superimposing the atomic
     ! core-correction charge densities
     real(dp), dimension (:), pointer, contiguous :: rhoc
!!! VDW 
     logical :: do_vdw
     ! vdw energy contribution to total energy
     real(dp) :: evdw
     ! charge density for the free atoms
     real(dp), dimension (:,:,:), pointer :: rhof
     ! free_volume for periodic structures
     real(dp), dimension (:,:), pointer :: v_free_periodic
     ! hirshfeld function for periodic structures
     real(dp), dimension (:,:,:), pointer :: hirshfeld_periodic
     ! r for hirshfeld function periodic
     real(dp), dimension (:,:,:), pointer :: dist_periodic
     ! 2*hirsh_3d_cell+1 is the number of cells in each direction for hirshfeld function
     integer, dimension(:,:), pointer :: hirsh_3d_cell
!!! END VDW PART
     ! charge-weighted SRE
     real(dp), dimension (:), pointer :: sre
     ! non wighted SRE (just (\delta v)^2)
     real(dp), dimension (:), pointer :: plain_sre
     ! which sre to actually use?
     logical :: use_plain_sre

     ! number of symmetry representations
     integer :: nrep

     ! representation of each state, after eigenvalues are arranged in
     ! ascending order
     integer, dimension(:,:,:), pointer :: irep

     ! table of characters for the reduced symmetry group
     integer, dimension(:,:), pointer :: chi

     ! set of eigenvectors to be saved to parsec.dat
     integer :: nsave
     integer, dimension(:), pointer :: indxsave

     ! eigenvalues/eigenvectors for each symmetry representation and spin
     type(eigenstates), dimension(:,:,:), pointer :: eig

     ! flag for perturbative spin-orbit correction
     logical :: is_so
     logical :: scf_so
     logical :: so_pert
     ! flag for non-collinear calculation
     logical :: ncl
     !  non-collinear contribution to total energy
     real(dp) :: totnrg_ncl
     ! initial atomic 3D magnetic moment
     real(dp), dimension (:,:), pointer :: init_mag
     ! integrated 3d magnetization if non-collinear calculation
     real(dp) :: s3dtot(3)
     ! 3d magnetization if non-collinear calculation
     real(dp), dimension (:,:), pointer ::  spin3d
     ! norm of 3d magnetization if non-collinear calculation
     real(dp), dimension (:), pointer ::  spin3dn
     ! additional spin dimension of wave-function due to spin-orbit
     ! and\or non-collinear states
     integer :: mxwd
     integer :: ndim
     ! In case of external magnetic field, it's magnitude
     real(dp) :: mag_field
     ! Flag for external magnetic field
     logical :: is_mag
     ! In case of spin-orbit: Net magnetic moment of all states
     real(dp) :: net_magmom
     ! In case of spin-orbit: magnetic moment of each state
     real(dp), dimension (:,:), pointer ::  magmom
     ! flag for orbital magnetism
     logical :: orb_mag
     ! flag for current dft
     logical :: is_cur
     ! flag for performing an explicit evaluation of the hartree potential for pbc%per=3
     logical :: explicit_hartree_pbc
     ! current density array
     real(dp), dimension (:,:,:), pointer :: jop
     ! exchange current density array
     real(dp), dimension (:,:,:), pointer :: jex

  end type  electronic_struct

contains

  subroutine init_electronic_struct(elec_st)
    implicit none
    type (electronic_struct), intent (inout) :: elec_st

    nullify(elec_st%ntotal)
    nullify(elec_st%totel)
    nullify(elec_st%ifmax)
    nullify(elec_st%occ_in)
    nullify(elec_st%rho)
    nullify(elec_st%rhoc)
    nullify(elec_st%sre)
    nullify(elec_st%plain_sre)
    nullify(elec_st%irep)
    nullify(elec_st%chi)
    nullify(elec_st%kpts)
    nullify(elec_st%kpwt)
    nullify(elec_st%kptf)
    nullify(elec_st%kptindr)
    nullify(elec_st%kptitran)
    nullify(elec_st%indxsave)
    nullify(elec_st%magmom)
    nullify(elec_st%spin3d)
    nullify(elec_st%spin3dn)
    nullify(elec_st%jop)
    nullify(elec_st%jex)
    nullify(elec_st%eig)

    elec_st%mxwd = -1
    elec_st%ndim = -1
    elec_st%nrep = -1
    elec_st%use_plain_sre = .FALSE.
    elec_st%explicit_hartree_pbc = .FALSE.

  end subroutine init_electronic_struct

  subroutine destroy_electronic_struct (elec_st)
    implicit none
    type (electronic_struct), intent (inout) :: elec_st
    integer :: irp,isp,kplp

    if (associated (elec_st%ntotal)) deallocate (elec_st%ntotal)
    if (associated (elec_st%totel)) deallocate (elec_st%totel)
    if (associated (elec_st%ifmax)) deallocate (elec_st%ifmax)
    if (associated(elec_st%occ_in)) deallocate(elec_st%occ_in)
    if (associated (elec_st%rho)) deallocate (elec_st%rho)
    if (associated (elec_st%rhoc)) deallocate (elec_st%rhoc)
!!! VDW PART
    if (elec_st%do_vdw) then
    if (associated (elec_st%rhof)) deallocate (elec_st%rhof)
    if (associated (elec_st%v_free_periodic)) deallocate (elec_st%v_free_periodic)
    if (associated (elec_st%hirshfeld_periodic)) deallocate (elec_st%hirshfeld_periodic)
    if (associated (elec_st%dist_periodic)) deallocate (elec_st%dist_periodic)
    if (associated (elec_st%hirsh_3d_cell)) deallocate (elec_st%hirsh_3d_cell)
    endif
!!! END VDW PART
    if (associated (elec_st%sre)) deallocate (elec_st%sre)
    if (associated (elec_st%plain_sre)) deallocate (elec_st%plain_sre)
    if (associated (elec_st%irep)) deallocate (elec_st%irep)
    if (associated (elec_st%chi)) deallocate (elec_st%chi)
    if (associated (elec_st%kpts)) deallocate (elec_st%kpts)
    if (associated (elec_st%kpwt)) deallocate (elec_st%kpwt)
    if (associated (elec_st%kptf)) deallocate (elec_st%kptf)
    if (associated (elec_st%kptindr)) deallocate (elec_st%kptindr)
    if (associated (elec_st%kptitran)) deallocate (elec_st%kptitran)
    if (associated (elec_st%indxsave)) deallocate(elec_st%indxsave)
    if (associated (elec_st%magmom)) deallocate(elec_st%magmom)
    if (associated (elec_st%spin3d)) deallocate(elec_st%spin3d)
    if (associated (elec_st%spin3dn)) deallocate(elec_st%spin3dn)
    if (associated(elec_st%jop)) deallocate(elec_st%jop)
    if (associated(elec_st%jex)) deallocate(elec_st%jex)
      
    if (associated(elec_st%eig)) then
        do isp = 1, elec_st%nspin/elec_st%mxwd
           do kplp =1,max(elec_st%nkpt,1)
          do irp = 1, elec_st%nrep
             call destroy_eigenstate(elec_st%eig(irp,kplp,isp))
          enddo
           enddo
        enddo
        deallocate(elec_st%eig)
    endif

  end subroutine destroy_electronic_struct
  subroutine destroy_eigenstate (eigen)
    implicit none
    type (eigenstates), intent (inout) :: eigen

    if (associated(eigen%en)) deallocate(eigen%en)
    if (associated(eigen%occ)) deallocate(eigen%occ)
    ! if (associated(eigen%wf)) deallocate(eigen%wf)
    ! if (associated(eigen%zwf)) deallocate(eigen%zwf)
    if (allocated(eigen%wf)) deallocate(eigen%wf)
    if (allocated(eigen%zwf)) deallocate(eigen%zwf)

  end subroutine destroy_eigenstate

  subroutine create_eigenstate (eigen,ldn,nn,cplx)
    implicit none
    type (eigenstates), intent (inout) :: eigen
    integer, intent(in) :: ldn, nn
    logical, intent(in) :: cplx
    integer :: alcstat,ii,jj
    integer :: memcheck(2)

    allocate(eigen%en(nn))
    allocate(eigen%occ(nn))
    eigen%en(:) = zero
    eigen%occ(:) = zero
    if (cplx) then
       allocate(eigen%zwf(ldn,nn),stat=alcstat)
       call alccheck('eigen%zwf',ldn*nn,alcstat,memcheck)
       !!!$OMP PARALLEL DO SIMD COLLAPSE(2)
       do ii=1,nn
       do jj=1,ldn
       eigen%zwf(jj,ii) = zzero
       enddo
       enddo
       !!!$OMP END PARALLEL DO SIMD
    else
       allocate(eigen%wf(ldn,nn),stat=alcstat)
       call alccheck('eigen%wf',ldn*nn,alcstat,memcheck)
       !!!$OMP PARALLEL DO SIMD COLLAPSE(2)
       do ii=1,nn
       do jj=1,ldn
       eigen%wf(jj,ii) = dzero
       enddo
       enddo
       !!!$OMP END PARALLEL DO SIMD
    endif

  end subroutine create_eigenstate

  subroutine create_electronic_struct(nspin,nstate,elec_st,mxwd)
    implicit none
    integer, intent (inout) :: nspin
    integer, intent (inout) :: nstate
    integer, intent (in) :: mxwd
    
    ! default values
    integer, parameter :: int_def = -1
    real(dp), parameter :: real_def = zero
    type (electronic_struct), intent (inout) :: elec_st  

    elec_st%nspin = nspin
    elec_st%nstate = nstate
    elec_st%mxwd = mxwd

    allocate (elec_st%ntotal (nspin/mxwd))
    allocate (elec_st%totel (nspin))
    allocate (elec_st%ifmax (nspin/mxwd))
    allocate (elec_st%occ_in (nstate,nspin/mxwd))
    allocate (elec_st%sre (nspin))
    allocate (elec_st%plain_sre (nspin))
    !\todo AJB: VDW (why dynamic?, why no flag?):
    allocate (elec_st%hirsh_3d_cell(1,3))

    elec_st%ntotal(:) = int_def
    elec_st%ncharge = real_def
    elec_st%xele = real_def
    elec_st%tfermi = real_def
    elec_st%etot = real_def
    elec_st%etot_plusu = real_def
    elec_st%bdev = real_def
    elec_st%exc = real_def

    elec_st%dipx = real_def
    elec_st%dipy = real_def
    elec_st%dipz = real_def

    elec_st%so_pert = .false.
    !VDW:
    elec_st%do_vdw = .false.
    elec_st%evdw = real_def
    elec_st%hirsh_3d_cell(:,:)=0

  end subroutine create_electronic_struct

  subroutine electronic_struct_set_charge (ndim,elec_st)
    implicit none 
    integer, intent (in) :: ndim
    type (electronic_struct), intent (inout) :: elec_st 

    integer :: nspin
    integer :: alcstat
    nspin = elec_st%nspin
 
    allocate (elec_st%rho (ndim,2*nspin-1),stat=alcstat)
    call alccheck('rho',ndim*(2*nspin-1), alcstat)
    elec_st%rho=zero
    allocate (elec_st%rhoc (ndim),stat=alcstat)
    call alccheck('rhoc',ndim, alcstat)

    if (elec_st%ncl) then
       allocate(elec_st%spin3d(ndim,3))
       call alccheck('spin3d',ndim*3, alcstat)
       allocate(elec_st%spin3dn(ndim))
       call alccheck('spin3dn',ndim, alcstat)
    endif

  end subroutine electronic_struct_set_charge

  subroutine electronic_struct_set_charge_vdw (ndim,elec_st,atom_num)
    implicit none 
    integer, intent (in) :: ndim
    type (electronic_struct), intent (inout) :: elec_st 
    integer, intent (in) :: atom_num

    integer :: nspin
    integer :: alcstat
    integer :: num_hirsh_super 

    nspin = elec_st%nspin


    allocate (elec_st%rhof (ndim,2*nspin-1,atom_num),stat=alcstat)
    call alccheck('rhof for atom_num',ndim*(2*nspin-1), alcstat)
    allocate (elec_st%v_free_periodic (1,atom_num))
    num_hirsh_super = (elec_st%hirsh_3d_cell(1,1)*2+1)*(elec_st%hirsh_3d_cell(1,2)*2+1)*(elec_st%hirsh_3d_cell(1,3)*2+1)

    allocate (elec_st%hirshfeld_periodic (ndim,num_hirsh_super,atom_num))
    allocate (elec_st%dist_periodic (ndim,num_hirsh_super,atom_num))


  end subroutine electronic_struct_set_charge_vdw

end module electronic_struct_module

! ==================== pseudo structure ========================
module pseudo_potential_module
  use constants
  use aux, only : alccheck
  implicit none

  type  pseudo_potential

     integer, dimension (:), pointer :: format
     ! pseudopotential core cutoff for each type of atom
     real(dp), dimension (:), pointer :: rcore

     ! For each atom type:
     ! # of potentials, local component, # electron/orbit L
     integer, dimension (:), pointer :: nlocp
     integer, dimension (:), pointer :: loc
     real(dp), dimension (:,:), pointer :: eleatm
     ! initial spin polarization: ( Z_up - Z_down )/( Z_up + Z_down )
     real(dp), dimension (:), pointer :: spol
     !
     ! parameters read from ptable
     ! zion - positive charge of pseudo ion (equals # of valence electrons)
     real(dp), dimension (:), pointer :: zion
     !
     ! data read directly from the pseudopotential file(s):
     ! ns - number of points on the radial pseduopotential grid
     ! icore - 0: no core correction, 1 - core correction
     ! rs - coordinates of radial pseudopotential grid
     ! vion - local pseudopotential
     ! denc - fixed core correction charge density
     integer, dimension (:), pointer :: ns
     integer, dimension (:), pointer :: icore
     real(dp), dimension (:,:), pointer :: rs, vion, denc
     !
     ! data calculated based on info in pseudopotential files(s):
     ! dvion - radial derivative of vion
     ! d2vion - second radial derivative of vion
     ! ddenc - radial derivative of denc 
     ! d2denc - second radial derivative of denc 
     ! rho_r, drhodr, d2rhodr- radial distribution of (volume) atomic charge
     ! density and its radial derivative, respectively
     real(dp), dimension (:,:), pointer :: dvion, d2vion, ddenc, d2denc, rho_r, drhodr, d2rhodr
     ! wfspd - pseudo wavefunction (up to four angular channels)
     real(dp), dimension (:,:,:), pointer :: wfspd
     ! dwfspd - derivative of pseudo wavefunction
     real(dp), dimension (:,:,:), pointer :: dwfspd
     !
     ! quantities for Kleinman-Bylander transformation
     ! vw - wfspd*vspd/r
     ! dvw - radial derivative of vw
     ! d2vw - second radial derivative of vw
     ! ekbi - Kleinman-Bylander normalization integral 
     real(dp), dimension (:,:,:), pointer :: vw
     real(dp), dimension (:,:,:), pointer :: dvw
     real(dp), dimension (:,:,:), pointer :: d2vw
     real(dp), dimension (:,:), pointer :: ekbi

     ! The pseudopotential is given on a log grid !
     ! r(i) = aaa*(exp(bbb*(i-1))) - ccc.
     ! aaa, bbb, ccc : parameters of logarithmic pseudopotential grid
     real(dp), dimension (:), pointer :: par_a
     real(dp), dimension (:), pointer :: par_b
     real(dp), dimension (:), pointer :: par_c

     ! parameters for Fourier filtering, as defined by Briggs et al.,
     ! PRB 54, 14362 (1996). Core filter parameter is the reciprocal
     ! space cutoff (equivalent to alpha) for core charge
     real(dp), dimension (:), pointer :: alpha, beta1, acore

     ! order for spline interpolation
     logical, dimension (:), pointer :: uspline

     ! parameters for LDA+U, as in Anisimov et al., PRB 44, 943 (1991)
     ! uu - the Hubbard parameter U
     ! jj - the Hund's-rule exchange parameter J
     real(dp), dimension (:,:), pointer :: uu, jj
     ! number of atom types
     integer :: type_num
     ! mxpot = max(ns)
     integer :: mxpot
     ! number of neighbors used on one side in numerical derivative
     integer :: norder

     ! flag for spin-orbit correction
     logical :: is_so

     ! type of interpolation flag
     logical :: oldinpformat
     ! flag for spin-orbit for each atom type
     logical, dimension (:), pointer :: so

     ! flag for reading valence charge density of each atom type
     logical, dimension (:), pointer :: rvcd

     ! normalization factor so_hcub=sqrt(grid%hcub)
     real (dp) :: so_hcub

     ! spin-orbit normalization coefficients
     real(dp),  dimension (:,:), pointer :: cc

     ! radial part of (spin-orbit potential)*(radial pseudo wave function)
     real(dp), dimension (:,:,:), pointer :: vsor
     real(dp), dimension (:,:,:), pointer :: vionr

     ! derivative of radial parts
     real(dp), dimension (:,:,:), pointer :: dvr_so
     real(dp), dimension (:,:,:), pointer :: dvr_ion

     ! Wigner-Seitz radii of atoms
     real(dp), dimension (:), pointer :: rws

     ! second derivative of radial parts
     real(dp), dimension (:,:,:), pointer :: d2vr_so
     real(dp), dimension (:,:,:), pointer :: d2vr_ion

  end type pseudo_potential

contains
  subroutine init_pseudo_potential (p_pot)
    implicit none
    type (pseudo_potential), intent (inout) :: p_pot

    nullify(p_pot%format)
    nullify(p_pot%rcore)
    nullify(p_pot%nlocp)
    nullify(p_pot%loc)
    nullify(p_pot%eleatm)
    nullify(p_pot%spol)
    nullify(p_pot%zion)

    nullify(p_pot%ns)
    nullify(p_pot%icore)
    nullify(p_pot%rs)
    nullify(p_pot%denc)
    nullify(p_pot%rho_r)
    nullify(p_pot%drhodr)
    nullify(p_pot%d2rhodr)
    nullify(p_pot%vion)
    nullify(p_pot%dvion)
    nullify(p_pot%d2vion)
    nullify(p_pot%vw)
    nullify(p_pot%dvw)
    nullify(p_pot%d2vw)
    nullify(p_pot%ddenc)
    nullify(p_pot%d2denc)
    nullify(p_pot%ekbi)
    nullify(p_pot%par_a)
    nullify(p_pot%par_b)
    nullify(p_pot%par_c)
    nullify(p_pot%alpha)
    nullify(p_pot%beta1)
    nullify(p_pot%acore)
    nullify(p_pot%uspline)

    nullify(p_pot%wfspd)
    nullify(p_pot%dwfspd)
    nullify(p_pot%uu)
    nullify(p_pot%jj)

    nullify(p_pot%so)
    nullify(p_pot%rvcd)
    nullify(p_pot%cc)
    nullify(p_pot%vsor)
    nullify(p_pot%vionr)
    nullify(p_pot%dvr_so)
    nullify(p_pot%dvr_ion)
    nullify(p_pot%rws)
    nullify(p_pot%d2vr_so)
    nullify(p_pot%d2vr_ion)

  end subroutine init_pseudo_potential

  subroutine destroy_pseudo_potential (p_pot)
    implicit none
    type (pseudo_potential), intent (inout) :: p_pot

    if (associated (p_pot%format)) deallocate (p_pot%format)
    if (associated (p_pot%rcore)) deallocate (p_pot%rcore)
    if (associated (p_pot%nlocp)) deallocate (p_pot%nlocp)
    if (associated (p_pot%loc)) deallocate (p_pot%loc)
    if (associated (p_pot%eleatm)) deallocate (p_pot%eleatm)
    if (associated (p_pot%spol)) deallocate (p_pot%spol)
    if (associated (p_pot%zion)) deallocate (p_pot%zion)

    if (associated (p_pot%ns)) deallocate (p_pot%ns)
    if (associated (p_pot%icore)) deallocate (p_pot%icore)
    if (associated (p_pot%rs)) deallocate (p_pot%rs)
    if (associated (p_pot%denc)) deallocate (p_pot%denc)
    if (associated (p_pot%rho_r)) deallocate (p_pot%rho_r)
    if (associated (p_pot%drhodr)) deallocate (p_pot%drhodr)
    if (associated (p_pot%d2rhodr)) deallocate (p_pot%d2rhodr)
    if (associated (p_pot%vion)) deallocate (p_pot%vion)
    if (associated (p_pot%dvion)) deallocate (p_pot%dvion)
    if (associated (p_pot%d2vion)) deallocate (p_pot%d2vion)
    if (associated (p_pot%vw)) deallocate (p_pot%vw)
    if (associated (p_pot%dvw)) deallocate (p_pot%dvw)
    if (associated (p_pot%d2vw)) deallocate (p_pot%d2vw)
    if (associated (p_pot%ddenc)) deallocate (p_pot%ddenc)
    if (associated (p_pot%d2denc)) deallocate (p_pot%d2denc)
    if (associated (p_pot%ekbi)) deallocate (p_pot%ekbi)
    if (associated (p_pot%par_a)) deallocate (p_pot%par_a)
    if (associated (p_pot%par_b)) deallocate (p_pot%par_b)
    if (associated (p_pot%par_c)) deallocate (p_pot%par_c)
    if (associated (p_pot%alpha)) deallocate (p_pot%alpha)
    if (associated (p_pot%beta1)) deallocate (p_pot%beta1)
    if (associated (p_pot%acore)) deallocate (p_pot%acore)
    if (associated (p_pot%uspline)) deallocate (p_pot%uspline)

    if (associated (p_pot%wfspd)) deallocate (p_pot%wfspd)
    if (associated (p_pot%dwfspd)) deallocate (p_pot%dwfspd)
    if (associated (p_pot%uu)) deallocate (p_pot%uu)
    if (associated (p_pot%jj)) deallocate (p_pot%jj)

    if (associated (p_pot%so)) deallocate (p_pot%so)
    if (associated (p_pot%rvcd)) deallocate (p_pot%rvcd)
    if (associated (p_pot%cc)) deallocate (p_pot%cc)
    if (associated (p_pot%vsor)) deallocate (p_pot%vsor)
    if (associated (p_pot%vionr)) deallocate (p_pot%vionr)
    if (associated (p_pot%dvr_so)) deallocate (p_pot%dvr_so)
    if (associated (p_pot%dvr_ion)) deallocate (p_pot%dvr_ion)
    if (associated (p_pot%rws)) deallocate (p_pot%rws)
    if (associated (p_pot%d2vr_so)) deallocate (p_pot%d2vr_so)
    if (associated (p_pot%d2vr_ion)) deallocate (p_pot%d2vr_ion)

  end subroutine destroy_pseudo_potential

  subroutine create_pseudo_potential (type_num,norder,p_pot)
    implicit none
    integer, intent (inout) :: type_num
    integer, intent (inout) :: norder

    type (pseudo_potential), intent (inout) :: p_pot
    ! default values
    integer, parameter :: int_def = -1
    
    if (type_num == 0) then
    p_pot%type_num = int_def
    p_pot%norder = int_def
    p_pot%mxpot = int_def
      return
    endif

    p_pot%type_num = type_num
    p_pot%norder = norder
    p_pot%mxpot = int_def

    !\todo AJB : magic number 4 here, fixed number of projectors
    allocate (p_pot%format (type_num))
    allocate (p_pot%rcore (type_num))
    allocate (p_pot%nlocp (type_num))
    allocate (p_pot%loc (type_num))
    allocate (p_pot%eleatm (type_num,4))
    allocate (p_pot%spol (type_num))
    allocate (p_pot%ns (type_num))
    allocate (p_pot%icore (type_num))
    allocate (p_pot%ekbi (4,type_num))
    allocate (p_pot%par_a (type_num))
    allocate (p_pot%par_b (type_num))
    allocate (p_pot%par_c (type_num))
    allocate (p_pot%alpha (type_num))
    allocate (p_pot%beta1 (type_num))
    allocate (p_pot%acore (type_num))
    allocate (p_pot%uspline (type_num))
    allocate (p_pot%zion (type_num))
    allocate (p_pot%uu (4,type_num))
    allocate (p_pot%jj (4,type_num))
    allocate (p_pot%so (type_num))
    allocate (p_pot%rvcd (type_num))
    allocate (p_pot%cc (2,type_num))

  end subroutine create_pseudo_potential

  subroutine pseudo_potential_set_mxpot (mxpot,p_pot)
    implicit none
    integer, intent (in) :: mxpot
    type (pseudo_potential), intent (inout) :: p_pot

    ! work variables
    integer :: norder
    integer :: type_num

    p_pot%mxpot = mxpot

    norder = p_pot%norder
    type_num = p_pot%type_num

    allocate (p_pot%rs (-norder:mxpot,type_num))

    allocate (p_pot%denc (-norder:mxpot,type_num))
    allocate (p_pot%rho_r (-norder:mxpot,type_num))
    allocate (p_pot%drhodr (-norder:mxpot,type_num))
    allocate (p_pot%d2rhodr (-norder:mxpot,type_num))
    allocate (p_pot%vion (-norder:mxpot,type_num))
    allocate (p_pot%dvion (-norder:mxpot,type_num))
    allocate (p_pot%d2vion (-norder:mxpot,type_num))
    allocate (p_pot%vw (-norder:mxpot,type_num,4))
    allocate (p_pot%dvw (-norder:mxpot,type_num,4))
    allocate (p_pot%d2vw (-norder:mxpot,type_num,4))
    allocate (p_pot%ddenc (-norder:mxpot,type_num))
    allocate (p_pot%d2denc (-norder:mxpot,type_num))
    allocate (p_pot%wfspd (-norder:mxpot,type_num,4))
    allocate (p_pot%dwfspd (-norder:mxpot,type_num,4))

    allocate (p_pot%vsor (-norder:mxpot, type_num, 2))
    allocate (p_pot%vionr (-norder:mxpot, type_num, 2))
    allocate (p_pot%dvr_so (-norder:mxpot, type_num, 2))
    allocate (p_pot%dvr_ion (-norder:mxpot, type_num, 2))
    allocate (p_pot%d2vr_so (-norder:mxpot, type_num, 2))
    allocate (p_pot%d2vr_ion (-norder:mxpot, type_num, 2))

  end subroutine pseudo_potential_set_mxpot

end module pseudo_potential_module

! ==================== molecular dynamic structure ==============
module molecular_dynamic_module
  use constants
  use aux, only : alccheck
  implicit none

  type  molecular_dynamic

     ! cooling scheme (1 - stair, 2- linear, 3 - log)
     integer :: cool_type
     ! how many step to apply
     integer :: step_num      
     ! initial temperature (in kelvins)
     real(dp) :: tempi
     ! final temperature (in kelvins)
     real(dp) :: tempf
     ! step temperature provided by user and adjusted by code for stair cooling
     real(dp) :: step_tmp
     ! size of temperature step in K, calculated according to the cooling
     ! scheme
     real(dp) :: tscale
     ! time step
     real(dp) :: time_step
     ! friction coefficient
     real(dp) :: friction_coef

     ! Counter of atom movement cycles in molecular dynamics.
     ! Different from imove if a MD simulation is restarted.
     integer ::  iframe

     ! cooling stride (number of MD steps between two consecutive
     ! coolings); used for stair-step cooling only
     integer :: stride

     ! flag indicates if molecular dynamic is on, in current
     ! computation (provided by the user)
     logical :: is_on

     ! flag to turn on limited movement MD (some atoms fixed and some free)
     logical :: limited

     ! flag that indicates if this is a restart run
     logical :: is_restart

     ! Langevin trajectory variables

     ! current positions
     real(dp), dimension (:), pointer :: xcur, ycur, zcur
     ! old positions (from previous step)      
     real(dp), dimension (:), pointer :: xold, yold, zold

     ! old velocities (from previous step)
     real(dp), dimension (:), pointer :: vxold, vyold, vzold

     ! old and older accelerations (from previous two steps)
     real(dp), dimension (:), pointer ::accxold,accyold,acczold

     ! For testing/debugging: Use a simple RNG instead of system's
     logical :: use_test_rng 
     ! For testing/debugging: Override the reinitalizaion of the RNG with your own seed
     integer :: rng_seed
     ! Size of random-number array
     integer :: nrandom
     ! Position counter of random-number array. The last used random
     ! vector in vrandom is at position iset. Initialized to 0
     integer :: iset
     ! Random-number array. This array is reconstructed every time all
     ! numbers are used. See subroutine getrandom
     real(dp), dimension(:), pointer :: vrandom
     !!
     ! error handling
     integer :: max_fail
     integer :: num_fails



  end type molecular_dynamic

contains

  subroutine init_molecular_dynamic (mol_dynamic)
    implicit none
    type (molecular_dynamic), intent (inout) :: mol_dynamic

    nullify(mol_dynamic%xcur)
    nullify(mol_dynamic%ycur)
    nullify(mol_dynamic%zcur)
    nullify(mol_dynamic%xold)
    nullify(mol_dynamic%yold)
    nullify(mol_dynamic%zold)
    nullify(mol_dynamic%vxold)
    nullify(mol_dynamic%vyold)
    nullify(mol_dynamic%vzold)
    nullify(mol_dynamic%accxold)
    nullify(mol_dynamic%accyold)
    nullify(mol_dynamic%acczold)
    nullify(mol_dynamic%vrandom)

  end subroutine init_molecular_dynamic

  subroutine destroy_molecular_dynamic (mol_dynamic)
    implicit none
    type (molecular_dynamic), intent (inout) :: mol_dynamic

    if (associated (mol_dynamic%xcur)) deallocate (mol_dynamic%xcur)
    if (associated (mol_dynamic%ycur)) deallocate (mol_dynamic%ycur)
    if (associated (mol_dynamic%zcur)) deallocate (mol_dynamic%zcur)
    if (associated (mol_dynamic%xold)) deallocate (mol_dynamic%xold)
    if (associated (mol_dynamic%yold)) deallocate (mol_dynamic%yold)
    if (associated (mol_dynamic%zold)) deallocate (mol_dynamic%zold)
    if (associated (mol_dynamic%vxold)) deallocate (mol_dynamic%vxold)
    if (associated (mol_dynamic%vyold)) deallocate (mol_dynamic%vyold)
    if (associated (mol_dynamic%vzold)) deallocate (mol_dynamic%vzold)
    if (associated (mol_dynamic%accxold)) deallocate (mol_dynamic%accxold)
    if (associated (mol_dynamic%accyold)) deallocate (mol_dynamic%accyold)
    if (associated (mol_dynamic%acczold)) deallocate (mol_dynamic%acczold)
    if (associated (mol_dynamic%vrandom)) deallocate (mol_dynamic%vrandom)

  end subroutine destroy_molecular_dynamic
      
  subroutine molecular_dynamic_turn_on (mol_dynamic,atom_num)
    implicit none

    type (molecular_dynamic), intent (inout) :: mol_dynamic
    integer, intent(in) :: atom_num

    mol_dynamic%is_restart = .false.

    allocate (mol_dynamic%xcur (atom_num))
    allocate (mol_dynamic%ycur (atom_num))
    allocate (mol_dynamic%zcur (atom_num))
    allocate (mol_dynamic%xold (atom_num))
    allocate (mol_dynamic%yold (atom_num))
    allocate (mol_dynamic%zold (atom_num))
    allocate (mol_dynamic%vxold (atom_num))
    allocate (mol_dynamic%vyold (atom_num))
    allocate (mol_dynamic%vzold (atom_num))
    allocate (mol_dynamic%accxold (atom_num))
    allocate (mol_dynamic%accyold (atom_num))
    allocate (mol_dynamic%acczold (atom_num))

    mol_dynamic%nrandom = 10000
    allocate (mol_dynamic%vrandom(mol_dynamic%nrandom))
    mol_dynamic%iset = 0
    ! error handling
    mol_dynamic%max_fail = NUM_STRIKES_MD
    mol_dynamic%num_fails = 0
    

  end subroutine molecular_dynamic_turn_on

end module molecular_dynamic_module

! ==================== non local pseudo potential structure =====
module non_local_psp_module
  use constants
  use aux, only : alccheck
  implicit none

  type  nonloc_pseudo_potential

     ! maxnloc,maxnlm,atom_num
     integer :: maxnloc 
     ! number of non-local projectors over all atoms in the system
     integer :: nlm
     integer :: atom_num
     ! maxnloc in Wigner-Seits radii
     integer :: wsmaxnloc

     ! The following arrays hold information for each atom:

     ! array holding the values of the ket V_l-V_local|psi_lm>. The
     ! array only stores the value of the ket at non-local points -
     ! elsewhere it is certainly zero! There is a different ket for each 
     ! atom and for each lm value.
     ! if l=local the array just stores zeroes, as appropriate.
     real(dp), dimension (:,:), pointer ::  anloc
     ! flag for non-collinear calculation
     logical :: ncl
     ! initial intensity non-collinear magnetization 
     real(dp), dimension (:,:), pointer ::  gmag

     ! Array holding the derivates of the Kleinman-Bylander projectors.
     ! Needed in the calculation of non-local parts of the forces
     ! (this array used to be local to forcnloc.F).
     real(dp), dimension (:,:,:), pointer :: vylmd

     ! actual number of non-local points around each atom,
     ! based on the core-cutoff of that atom type and the atom
     ! coordinates.
     integer, dimension (:), pointer ::  nlatom
     integer, dimension (:), pointer ::  wsnlatom

     ! position inside the 1-d vector of each non-local point, defined
     ! in the irreducible wedge
     integer, dimension (:,:), pointer :: indw

     ! position inside the 1-d vector of each Wigner-Seitz non-local point, defined
     ! in the irreducible wedge
     integer, dimension (:,:), pointer :: wsindw

     ! symmetry operation associated to each non-local point
     ! (operation needed to bring it back to the irreducible wedge)
     integer, dimension (:,:), pointer :: tran

     ! symmetry operation associated to each non-local point inside Wigner-Seits radii
     ! (operation needed to bring it back to the irreducible wedge)
     integer, dimension (:,:), pointer :: wstran

     ! number of lm components
     integer, dimension (:), pointer :: nlmatm

     ! skbi - same as ekbi, but for each m separately (although
     ! independent of m) and for each atom instead of each atom type.
     real(dp), dimension (:), pointer :: skbi

     ! density matrix for the on-site Coulomb interaction
     ! only used with u_pot structure.
     real(dp), dimension (:,:,:,:), pointer :: denmat
     complex(dpc), dimension (:,:,:,:), pointer :: zdenmat
     ! Constants derived from the 3-j symbols, used in the LDA+U calculation.
     ! The relation between U and 3-j symbols can be found e.g. in PRB
     ! 52, R5467 (1995)
     complex(dpc), dimension(:,:,:,:), pointer :: p3,p4
     ! spin index
     integer :: isp

     ! left and right side corrections for Vnonloc in matvec
     complex(dpc), dimension (:,:,:), pointer :: right
     complex(dpc), dimension (:,:,:), pointer :: left

     ! Hubbard U and Hund's J for LDA+U
     ! p_pot%uu/jj(:,ity) -> u_pot%uu/jj(:,ja)
     real(dp), dimension (:), pointer :: uu
     real(dp), dimension (:), pointer :: jj

     ! array holding the spin-orbit potentials
     complex(dpc), dimension (:,:,:), pointer :: v_so
     complex(dpc), dimension (:,:,:), pointer :: v_ion

     ! array holding the derivatives of spin-orbit potentials
     complex(dpc), dimension (:,:,:,:), pointer :: dv_so
     complex(dpc), dimension (:,:,:,:), pointer :: dv_ion

     ! index of atoms with spin orbit correction
     integer, dimension (:), pointer :: so_indx

     ! flag for spin-orbit psp for each atom
     logical,dimension (:), pointer :: so

     ! mxpot: length of vectors read for radial part of spin-orbit potentials
     integer :: mxpot
     integer :: so_num,so_type_num
     ! true if spin-orbit potentials are used
     logical :: is_so
     ! sign factor
     real (dp), dimension (:,:), pointer :: cc
     ! Flag for external magnetic field
     logical :: is_mag
     ! repeat of elec_st%kpts, %nkpts
     integer :: nkpt
     real(dp), dimension (:,:), pointer :: kpts

  end type nonloc_pseudo_potential

contains

  subroutine   init_nonloc_pseudo_pot (nloc_p_pot)
    implicit none
    type (nonloc_pseudo_potential), intent (inout) :: nloc_p_pot

    nullify(nloc_p_pot%anloc)
    nullify(nloc_p_pot%vylmd)
    nullify(nloc_p_pot%nlatom)
    nullify(nloc_p_pot%wsnlatom)
    nullify(nloc_p_pot%indw)
    nullify(nloc_p_pot%tran)
    nullify(nloc_p_pot%wsindw)
    nullify(nloc_p_pot%wstran)
    nullify(nloc_p_pot%nlmatm)
    nullify(nloc_p_pot%skbi)
    nullify(nloc_p_pot%gmag)

    nullify(nloc_p_pot%uu)
    nullify(nloc_p_pot%jj)
    nullify(nloc_p_pot%denmat)
    nullify(nloc_p_pot%zdenmat)
    nullify(nloc_p_pot%p3)
    nullify(nloc_p_pot%p4)

    nullify(nloc_p_pot%v_so)
    nullify(nloc_p_pot%v_ion)
    nullify(nloc_p_pot%dv_so)
    nullify(nloc_p_pot%dv_ion)
    nullify(nloc_p_pot%so_indx)
    nullify(nloc_p_pot%so)
    nullify(nloc_p_pot%cc)

  end subroutine init_nonloc_pseudo_pot

  subroutine destroy_nonloc_pseudo_pot (nloc_p_pot)
    implicit none
    type (nonloc_pseudo_potential), intent (inout) :: nloc_p_pot

    if (associated (nloc_p_pot%anloc)) deallocate (nloc_p_pot%anloc)
    if (associated (nloc_p_pot%vylmd)) deallocate (nloc_p_pot%vylmd)
    if (associated (nloc_p_pot%nlatom)) deallocate (nloc_p_pot%nlatom)
    if (associated (nloc_p_pot%wsnlatom)) deallocate (nloc_p_pot%wsnlatom)
    if (associated (nloc_p_pot%indw)) deallocate (nloc_p_pot%indw)
    if (associated (nloc_p_pot%tran)) deallocate (nloc_p_pot%tran)
    if (associated (nloc_p_pot%wsindw)) deallocate (nloc_p_pot%wsindw)
    if (associated (nloc_p_pot%wstran)) deallocate (nloc_p_pot%wstran)
    if (associated (nloc_p_pot%nlmatm)) deallocate (nloc_p_pot%nlmatm)
    if (associated (nloc_p_pot%skbi)) deallocate (nloc_p_pot%skbi)
    if (associated (nloc_p_pot%gmag)) deallocate (nloc_p_pot%gmag)

    if (associated (nloc_p_pot%left)) deallocate (nloc_p_pot%left)
    if (associated (nloc_p_pot%right)) deallocate (nloc_p_pot%right)
    if (associated (nloc_p_pot%kpts)) deallocate (nloc_p_pot%kpts)

    if (associated (nloc_p_pot%uu)) deallocate (nloc_p_pot%uu)
    if (associated (nloc_p_pot%jj)) deallocate (nloc_p_pot%jj)
    if (associated (nloc_p_pot%denmat)) deallocate (nloc_p_pot%denmat)
    if (associated (nloc_p_pot%zdenmat)) deallocate (nloc_p_pot%zdenmat)
    if (associated (nloc_p_pot%p3)) deallocate (nloc_p_pot%p3)
    if (associated (nloc_p_pot%p4)) deallocate (nloc_p_pot%p4)

    if (associated (nloc_p_pot%v_so)) deallocate (nloc_p_pot%v_so)
    if (associated (nloc_p_pot%v_ion)) deallocate (nloc_p_pot%v_ion)
    if (associated (nloc_p_pot%dv_so)) deallocate (nloc_p_pot%dv_so)
    if (associated (nloc_p_pot%dv_ion)) deallocate (nloc_p_pot%dv_ion)
    if (associated (nloc_p_pot%so_indx)) deallocate (nloc_p_pot%so_indx)
    if (associated (nloc_p_pot%so)) deallocate (nloc_p_pot%so)
    if (associated (nloc_p_pot%cc)) deallocate (nloc_p_pot%cc)
  end subroutine destroy_nonloc_pseudo_pot

  subroutine create_nonloc_pseudo_pot (nlm,atom_num,nloc_p_pot)
    implicit none
    integer, intent (in) :: nlm
    integer, intent (in) :: atom_num

    type (nonloc_pseudo_potential), intent (out) :: nloc_p_pot

    nloc_p_pot%nlm = nlm

    nloc_p_pot%atom_num = atom_num

    allocate (nloc_p_pot%nlatom (atom_num))
    nloc_p_pot%nlatom(:) = 0
    allocate (nloc_p_pot%wsnlatom (atom_num))
    nloc_p_pot%wsnlatom(:) = 0
    allocate (nloc_p_pot%nlmatm (atom_num))
    nloc_p_pot%nlmatm(:) = 0
    allocate (nloc_p_pot%skbi (nloc_p_pot%nlm))
    nloc_p_pot%skbi(:) = zero
    allocate (nloc_p_pot%uu (nloc_p_pot%nlm))
    nloc_p_pot%uu(:) = zero
    allocate (nloc_p_pot%jj (nloc_p_pot%nlm))
    nloc_p_pot%jj(:) = zero

    allocate (nloc_p_pot%so (atom_num))

  end subroutine create_nonloc_pseudo_pot

  subroutine nonloc_pseudo_pot_set_maxnloc(nloc_p_pot)
    implicit none
    type (nonloc_pseudo_potential), intent (out) :: nloc_p_pot
    ! work variables
    integer :: maxnloc, wsmaxnloc
    integer :: atom_num
    integer :: nlm

    maxnloc = maxval (nloc_p_pot%nlatom)
    wsmaxnloc = maxval (nloc_p_pot%wsnlatom)
    nlm = nloc_p_pot%nlm
    atom_num = nloc_p_pot%atom_num
    nloc_p_pot%maxnloc = maxnloc
    nloc_p_pot%wsmaxnloc = wsmaxnloc

    if (associated (nloc_p_pot%anloc)) deallocate (nloc_p_pot%anloc)
    if (associated (nloc_p_pot%vylmd)) deallocate (nloc_p_pot%vylmd)
    if (associated (nloc_p_pot%indw)) deallocate (nloc_p_pot%indw)
    if (associated (nloc_p_pot%tran)) deallocate (nloc_p_pot%tran)
    if (associated (nloc_p_pot%wsindw)) deallocate (nloc_p_pot%wsindw)
    if (associated (nloc_p_pot%wstran)) deallocate (nloc_p_pot%wstran)
    if (associated (nloc_p_pot%left)) deallocate (nloc_p_pot%left)
    if (associated (nloc_p_pot%right)) deallocate (nloc_p_pot%right)
    if (associated (nloc_p_pot%v_so)) deallocate (nloc_p_pot%v_so)
    if (associated (nloc_p_pot%v_ion)) deallocate (nloc_p_pot%v_ion)
    if (associated (nloc_p_pot%dv_so)) deallocate (nloc_p_pot%dv_so)
    if (associated (nloc_p_pot%dv_ion)) deallocate (nloc_p_pot%dv_ion)
    if (associated (nloc_p_pot%so_indx)) deallocate (nloc_p_pot%so_indx)
    if (associated (nloc_p_pot%cc)) deallocate (nloc_p_pot%cc)

    if (maxnloc > 0) then
       allocate (nloc_p_pot%anloc (maxnloc,nlm))
       nloc_p_pot%anloc(:,:) = zero
       allocate (nloc_p_pot%vylmd (3,maxnloc,nlm))
       nloc_p_pot%vylmd(:,:,:) = zero
       allocate (nloc_p_pot%indw (maxnloc,atom_num))
       nloc_p_pot%indw(:,:) = 0
       allocate (nloc_p_pot%tran (maxnloc,atom_num))
       nloc_p_pot%tran(:,:) = 0
       allocate (nloc_p_pot%wsindw (wsmaxnloc,atom_num))
       nloc_p_pot%wsindw(:,:) = 0
       allocate (nloc_p_pot%wstran (wsmaxnloc,atom_num))
       nloc_p_pot%wstran(:,:) = 0

       if(nloc_p_pot%nkpt > 0) then 
          allocate(nloc_p_pot%left(maxnloc,nloc_p_pot%nkpt,atom_num))
          nloc_p_pot%left = zzero
          allocate(nloc_p_pot%right(maxnloc,nloc_p_pot%nkpt,atom_num))
          nloc_p_pot%right = zzero
       endif
       
       if (nloc_p_pot%so_num > 0) then
          allocate (nloc_p_pot%v_so (maxnloc, 8,nloc_p_pot%so_num))
          nloc_p_pot%v_so(:,:,:) = zzero
          allocate (nloc_p_pot%v_ion (maxnloc, 8,nloc_p_pot%so_num))
          nloc_p_pot%v_ion(:,:,:) = zzero
          allocate (nloc_p_pot%dv_so (3,maxnloc, 8,nloc_p_pot%so_num))
          nloc_p_pot%dv_so(:,:,:,:) = zzero
          allocate (nloc_p_pot%dv_ion (3,maxnloc, 8,nloc_p_pot%so_num))
          nloc_p_pot%dv_ion(:,:,:,:) = zzero
          allocate (nloc_p_pot%cc (2,nloc_p_pot%so_num))
          nloc_p_pot%cc(:,:) = zero
          allocate (nloc_p_pot%so_indx (nloc_p_pot%so_num))
          nloc_p_pot%so_indx(:) = 0
       endif
    endif

  end subroutine nonloc_pseudo_pot_set_maxnloc


end module non_local_psp_module

! ==================== periodic boundary conditions structure ===
module pbc_module
  use constants
  use aux, only : alccheck
  implicit none

  type  pbc_data

     ! true if periodic boundary conditions are used
     logical :: is_on
     ! number of g-vectors
     integer :: ng
     ! number of stars of g-vectors (sets of g-vectors related by symmetry)
     integer :: nstar
     ! aliases for clust%atom_num, clust%type_num
     integer :: atom_num, type_num
     ! total size of FFT mesh
     integer :: maxdfft
     ! coordinates of the first corner of FFT mesh, needed for define
     ! the map between real space and reciprocal space
     ! In slabs: pbc%mz = 0
     ! In wires: pbc%my = pbc%mz = 0
     ! In clusters: pbc%mx = pbc%my = pc%mz = 0
     integer :: mx, my, mz
     ! In bulk (fully periodic) systems: pbc%n1,n2,n3 = grid%n1,n2,n3
     ! In slabs: pbc%n1,n2 = grid%n1,n2, pbc%n3 = 1
     ! In wires: pbc%n1 = grid%n1, pbc%n2 = pbc%n3 = 1
     integer :: n1, n2, n3
     ! coordinates of g-vectors, reciprocal lattice coordinates,
     ! in ascending order of length
     integer, dimension(:,:), pointer :: kgv
     ! points to which star a g-vector belongs to
     integer, dimension(:), pointer :: inds
     ! number of g-vectors in each star
     integer, dimension(:), pointer :: mstar
     ! alpha energy (used for total energy calculation)
     real(dp) :: ealpha
     ! number of periodic dimensions (0, 1, 2, 3)
     integer :: per
     
     ! lattice vectors as read from the input file.
     !
     ! In bulk (fully periodic) systems :
     !            -                           -
     !            |   a_1_x   a_2_x   a_3_x   |
     ! latt_vec = |   a_1_y   a_2_y   a_3_y   |  vectors a_1, a_2, a_3
     !            |   a_1_z   a_2_z   a_3_z   |
     !            -                           -
     !
     ! In slabs (periodic on the xy plane only) :
     !
     !            -                           -
     !            |   a_1_x   a_2_x     0     |
     ! latt_vec = |   a_1_y   a_2_y     0     |  vectors a_1, a_2
     !            |     0       0       1     |
     !            -                           -
     !
     ! In wires (periodic on the x axis only) :
     !
     !            -                           -
     !            |   a_1_x     0       0     |
     ! latt_vec = |     0       1       0     |  vector a_1
     !            |     0       0       1     |
     !            -                           -
     !
     ! In any case, the only relevant portion of latt_vec is
     ! latt_vec(1:per , 1:per), where per = 3 (bulk), 2 (slab) or 1
     ! (wire).
     !
     real(dp) :: latt_vec(3,3)
     ! this matrix is arranged as latt_vec but the lattice
     ! vectors are normalized to unity.
     real(dp) :: avec_norm(3,3)

     ! repeat of elec_st%kpts, %nkpts
     integer :: nkpt
     real(dp), dimension (:,:), pointer :: kpts

     ! box_size = rmax
     ! box_size(1 + per:3) = 0
     real(dp) :: box_size(3)
     ! vcell = box_size(1)*box_size(2)*box_size(3) 
     !!\todo  AJB, O.SINAI: not sure this is true for non-orthorhombic
     real(dp) :: vcell
     ! a_surface_cell = abs(det[v1 v2]) in slab geometry with lattice vectors v1,v2
     real(dp) :: a_surface_cell

     ! adot = transpose(latt_vec) * latt_vec
     real(dp) :: adot(3,3)
     ! reciprocal lattice vectors, transpose(bvec) * latt_vec = 2*pi
     real(dp) :: bvec(3,3)
     ! bdot = transpose(bvec) * bvec
     real(dp) :: bdot(3,3)

     ! shift of grid points, in units of lattice vector
     ! In slabs: pbc%shift(3) = 0
     ! In wires: pbc%shift(2:3) = 0
     ! In clusters: pbc%shift(1:3) = 0
     real(dp) :: shift(3)
     ! atomic coordinates with respect to the corner of FFT box
     real(dp), dimension(:,:,:), pointer :: rat

     ! phase factors
     complex(dpc), dimension(:), pointer :: phase
     ! conj(n) = -1 if one must take the complex conjugate of x*phase
     real(dp), dimension(:), pointer :: conj
     ! kinetic energy, |G|^2, of stars of g-vectors
     real(dp), dimension(:), pointer :: ek

     ! number of points in 1-D Fourier space mesh (pseudopotentials)
     integer, dimension(:),pointer :: nq
     ! maxdlqp = maxval(nq)
     integer :: maxdlqp
     ! Fourier-transformed local component of pseudopotentials
     real(dp), dimension(:,:), pointer :: vloc
     ! Fourier-transformed core charge
     real(dp), dimension(:,:), pointer :: dcor
     ! spacing of 1-D Fourier space mesh  (for pseudopotentials)
     real(dp), dimension(:), pointer :: delq

     ! true if the user asked to generate full dos
     logical :: create_dos
     ! number of points in DOS graph
     integer :: dos_pnum
     ! -1 - don't create LDOS, otherwise signifies the l of the
     ! angular functions used for LDOS (Ylm for l <= ylmdos_l)
     integer :: ylmdos_l
     !
     real(dp), dimension(:,:), pointer :: vql
     !
     real(dp), dimension(:,:), pointer :: dnc
     !
     real(dp), dimension(:), pointer :: vscr2
     !
     complex(dpc), dimension(:), pointer :: vscr4

  end type pbc_data

contains

  subroutine    init_pbc (pbc)
    implicit none
    type (pbc_data), intent (inout) :: pbc

    nullify(pbc%nq)
    nullify(pbc%kgv)
    nullify(pbc%inds)
    nullify(pbc%mstar)
    nullify(pbc%delq)
    nullify(pbc%phase)
    nullify(pbc%conj)
    nullify(pbc%ek)
    nullify(pbc%vql)
    nullify(pbc%dnc)
    nullify(pbc%vscr2)
    nullify(pbc%vscr4)
    nullify(pbc%rat)
    nullify(pbc%vloc)
    nullify(pbc%dcor)
    nullify(pbc%kpts)
    
    pbc%is_on = .false.

  end subroutine    init_pbc
  subroutine destroy_pbc (pbc)
    implicit none
    type (pbc_data), intent (inout) :: pbc

    if (associated (pbc%nq)) deallocate (pbc%nq)
    if (associated (pbc%kgv)) deallocate (pbc%kgv)
    if (associated (pbc%inds)) deallocate (pbc%inds)
    if (associated (pbc%mstar)) deallocate (pbc%mstar)
    if (associated (pbc%delq)) deallocate (pbc%delq)
    if (associated (pbc%phase)) deallocate (pbc%phase)
    if (associated (pbc%conj)) deallocate (pbc%conj)
    if (associated (pbc%ek)) deallocate (pbc%ek)
    if (associated (pbc%vql)) deallocate (pbc%vql)
    if (associated (pbc%dnc)) deallocate (pbc%dnc)
    if (associated (pbc%vscr2)) deallocate (pbc%vscr2)
    if (associated (pbc%vscr4)) deallocate (pbc%vscr4)
    if (associated (pbc%rat)) deallocate (pbc%rat)
    if (associated (pbc%vloc)) deallocate (pbc%vloc)
    if (associated (pbc%dcor)) deallocate (pbc%dcor)
    if (associated (pbc%kpts)) deallocate (pbc%kpts)

  end subroutine destroy_pbc

  subroutine pbc_turn_on (atom_num,type_num,pbc)
    implicit none
    integer, intent (in) :: atom_num
    integer, intent (in) :: type_num

    type (pbc_data), intent (out) :: pbc

    pbc%atom_num = atom_num
    pbc%type_num = type_num
    allocate (pbc%nq (type_num))
    allocate (pbc%delq (type_num))
    allocate (pbc%rat (3,atom_num,type_num))
  end subroutine pbc_turn_on

  subroutine pbc_set_maxdfft (maxdfft, pbc)

    implicit none
    integer, intent (in) :: maxdfft
    type (pbc_data), intent (inout) :: pbc
    integer :: alcstat

    pbc%maxdfft = maxdfft

    allocate (pbc%vscr2 (maxdfft),stat=alcstat)
    call alccheck('vscr2',maxdfft, alcstat)
    allocate (pbc%vscr4 (maxdfft),stat=alcstat)
    call alccheck('vscr4',maxdfft, alcstat)

  end subroutine pbc_set_maxdfft

  subroutine pbc_set_ng (ng, pbc)
    implicit none
    integer, intent (in) :: ng
    type (pbc_data), intent (inout) :: pbc

    pbc%ng = ng
    allocate (pbc%kgv (3,ng))
    allocate (pbc%inds (ng))
    allocate (pbc%phase (ng))
    allocate (pbc%conj (ng))
  end subroutine pbc_set_ng

  subroutine pbc_set_nstar (pbc,ns)
    implicit none
    type (pbc_data), intent (inout) :: pbc
    integer, intent (in) :: ns

    pbc%nstar = ns
    allocate (pbc%mstar (pbc%nstar))
    allocate (pbc%ek (pbc%nstar))
    allocate (pbc%vql (pbc%type_num,pbc%nstar))
    allocate (pbc%dnc (pbc%type_num,pbc%nstar))

  end subroutine pbc_set_nstar

  subroutine pbc_set_maxdlqp (maxdlqp,pbc)
    implicit none
    type (pbc_data), intent (inout) :: pbc

    integer, intent (in) :: maxdlqp

    ! work variables
    integer :: type_num

    type_num = pbc%type_num
    pbc%maxdlqp = maxdlqp

    allocate (pbc%vloc (maxdlqp, type_num))
    allocate (pbc%dcor (maxdlqp, type_num))

  end subroutine pbc_set_maxdlqp

end module pbc_module

! ==================== potential  structure =====================
module potential_module
  use constants
  use aux, only : alccheck
  implicit none

  type  potential

     ! aliases for parallel%mydim and elec_st%nspin
     integer :: ndim, nspin
     ! total new potential (from current iteration)
     real(dp), dimension (:,:), pointer, contiguous :: vnew
     ! total old potential (from previous iteration)
     real(dp), dimension (:,:), pointer, contiguous :: vold
     ! Hartree potential, exchange-correlation potential, ionic potential
     real(dp), dimension (:), pointer, contiguous :: vhart
     real(dp), dimension (:,:), pointer, contiguous :: vxc
     real(dp), dimension (:), pointer, contiguous :: vion
     ! Gaussian charge distribution, for 1-dimensional (wire) systems
     real(dp), dimension (:), pointer, contiguous :: rho_gauss
     ! sum of Hartree & XC potentials from previous iteration
     real(dp), dimension (:,:), pointer, contiguous :: vhxcold
     ! array of coefficients for Hartree multipole expansion
     real(dp),  dimension (:,:), pointer, contiguous ::  clm

     ! AMIR - changes of Doron - for current dft?

     ! current scalar potential
     real(dp), dimension (:,:), pointer, contiguous :: vxcj
     ! hartree-like current vector potential
     real(dp), dimension (:,:,:), pointer, contiguous :: axch
     ! exchange-like current vector potential
     real(dp), dimension (:,:,:), pointer, contiguous :: axc
     ! flag for current potential
     logical :: is_cur
     ! Vector potential squared (vec{A} \cdot vec{A})
     real(dp), dimension (:), pointer, contiguous :: vecpot
#ifdef IS_ICC
     !DIR$ attributes align:64 :: vnew, vold
     !DIR$ attributes align:64 :: vhart, vxc, vion, rho_gauss, vhxcold
     !DIR$ attributes align:64 :: clm, vxcj, axch, axc, vecpot
#endif
     



  end type potential

contains
  subroutine init_potential (pot)
    implicit none
    type (potential), intent (inout) :: pot 

    nullify (pot%vnew)
    nullify (pot%vold)
    nullify (pot%vhart)
    nullify (pot%vxc)
    nullify (pot%vion)
    nullify (pot%rho_gauss)
    nullify (pot%vhxcold)
    nullify (pot%clm)

    ! AMIR - changes of Doron for current dft?

    nullify (pot%vxcj)
    nullify (pot%axch)
    nullify (pot%axc)
    nullify (pot%vecpot)

  end subroutine init_potential

  subroutine destroy_potential (pot)
    implicit none
    type (potential), intent (inout) :: pot 

    if (associated (pot%vnew)) deallocate (pot%vnew)
    if (associated (pot%vold)) deallocate (pot%vold)
    if (associated (pot%vhart)) deallocate (pot%vhart)
    if (associated (pot%vxc)) deallocate (pot%vxc)
    if (associated (pot%vion)) deallocate (pot%vion)
    if (associated (pot%rho_gauss)) deallocate (pot%rho_gauss)
    if (associated (pot%vhxcold)) deallocate (pot%vhxcold)
    if (associated (pot%clm)) deallocate (pot%clm)

    ! AMIR - changes of Doron for current dft?

    if (associated (pot%vxc)) deallocate (pot%vxcj)
    if (associated (pot%vxc)) deallocate (pot%axch)
    if (associated (pot%vxc)) deallocate (pot%axc)
    if (associated (pot%vecpot)) deallocate (pot%vecpot)

  end subroutine destroy_potential

  subroutine potential_set_ndim (ndim,nspin,pot,is_cur)
    implicit none
    integer, intent (in) :: ndim, nspin

    logical, intent(in)  :: is_cur

    type (potential), intent (inout) :: pot

    integer :: alcstat

    pot%ndim = ndim
    pot%nspin = nspin

    allocate (pot%vnew (ndim,nspin),stat=alcstat)
    call alccheck('vnew',ndim*nspin, alcstat)
    allocate (pot%vold (ndim,nspin),stat=alcstat)
    call alccheck('vold',ndim*nspin, alcstat)
    allocate (pot%vhart (ndim),stat=alcstat)
    call alccheck('vhart',ndim, alcstat)
    allocate (pot%vxc (ndim,nspin),stat=alcstat)
    call alccheck('vxc',ndim*nspin, alcstat)
    allocate (pot%vion (ndim),stat=alcstat)
    call alccheck('vion',ndim, alcstat)
    allocate (pot%rho_gauss (ndim),stat=alcstat)
    call alccheck('rho_gauss',ndim, alcstat)
    allocate (pot%vhxcold (ndim,nspin),stat=alcstat)
    call alccheck('vhxcold',ndim*nspin, alcstat)
    allocate (pot%vecpot (ndim),stat=alcstat)
    call alccheck('vecpot',ndim, alcstat)
!    if (is_cur) then
!        allocate (pot%vxcj (ndim,nspin),stat=alcstat)
!        call alccheck('vxcj',ndim*nspin, alcstat)
!        allocate (pot%axch (ndim,2,3),stat=alcstat)
!        call alccheck('axch',3*ndim*nspin, alcstat)
!        allocate (pot%axc (ndim,2,3),stat=alcstat)
!        call alccheck('axc',3*ndim*nspin, alcstat)
!    endif

    pot%vhart(:) = zero
!    pot%vxc(:,:) = zero
!    pot%vxcj(:,:) = zero
!    pot%axch(:,:,:) = zero
!    pot%axc(:,:,:) = zero
    pot%vxc(:,:) = zero

  end subroutine potential_set_ndim

end module potential_module

! ==================== mixer  structure ========================
module mixer_module
  use constants
  use aux, only : alccheck
  implicit none

  type  mixer_data

     integer :: name
     real(dp)  :: param
     ! number of previous iterations used for mixing
     integer :: memory
     ! number of iterations before mixing is restarted
     integer :: restart
     ! flag set to true if scf loop fails
     logical :: scf_fail

     ! aliases for parallel%mydim and elec_st%nspin
     integer :: ndim, nspin

     ! size parameter for memory block allocated for the Broyden
     ! update arrays;  used to be kss0 in param.h
     integer :: block

     ! In Broyden, resid1 used as Initial guess for the Jacobian
     ! (assuming it is diagonal) [used to be gmix]
     real(dp), dimension (:), pointer :: resid1
     ! previous vold and second-previous vold 
     ! (updated for next run by the subroutine)
     real(dp), dimension (:), pointer :: old1 
     real(dp), dimension (:), pointer :: old2

     real(dp), dimension (:), pointer :: xin
     real(dp), dimension (:), pointer :: xout
     real(dp), dimension (:,:), pointer :: t
     real(dp), dimension (:,:), pointer :: tinv

     ! saved for Anderson mixing
     real(dp), dimension (:,:), pointer :: xinold
     real(dp), dimension (:,:), pointer :: xoutold

     ! Variables defined for multisecant methods.
     integer :: en_stage
     integer :: nsecant
     integer :: group_size
     real(dp) :: restart_factor
     real(dp) :: expand_factor
     real(dp), dimension (:,:), pointer :: dx
     real(dp), dimension (:,:), pointer :: df
     real(dp), dimension (:), pointer :: x0
     real(dp), dimension (:), pointer :: f0
     ! Above variables are used by msecant1/2/3.
     ! N is used by msecant1/3.
     real(dp), dimension (:,:), pointer :: n
     ! preferred_type, update_type, dx1, dx2, df2 are used only by msecant3.
     integer :: preferred_type, update_type
     real(dp), dimension (:,:), pointer :: dx1
     real(dp), dimension (:,:), pointer :: dx2
     real(dp), dimension (:,:), pointer :: df2

  end type mixer_data
contains

  subroutine    init_mixer (mixer)
    implicit none
    type (mixer_data), intent (inout) :: mixer 

    nullify(mixer%resid1)
    nullify(mixer%old1)
    nullify(mixer%old2)
    nullify(mixer%xin)
    nullify(mixer%xout)
    nullify(mixer%t)
    nullify(mixer%tinv)
    nullify(mixer%xinold)
    nullify(mixer%xoutold)

    ! Free memory used by multisecant methods
    nullify(mixer%dx)
    nullify(mixer%df)
    nullify(mixer%n)
    nullify(mixer%dx1)
    nullify(mixer%dx2)
    nullify(mixer%df2)
    nullify(mixer%x0)
    nullify(mixer%f0)

  end subroutine    init_mixer
  subroutine destroy_mixer (mixer)
    implicit none
    type (mixer_data), intent (inout) :: mixer 

    if (associated (mixer%resid1)) deallocate (mixer%resid1)
    if (associated (mixer%old1)) deallocate (mixer%old1)
    if (associated (mixer%old2)) deallocate (mixer%old2)
    if (associated (mixer%xin)) deallocate (mixer%xin)
    if (associated (mixer%xout)) deallocate (mixer%xout)
    if (associated (mixer%t)) deallocate (mixer%t)
    if (associated (mixer%tinv)) deallocate (mixer%tinv)
    if (associated (mixer%xinold)) deallocate (mixer%xinold)
    if (associated (mixer%xoutold)) deallocate (mixer%xoutold)

    ! Free memory used by multisecant methods
    if (associated (mixer%dx)) deallocate (mixer%dx)
    if (associated (mixer%df)) deallocate (mixer%df)
    if (associated (mixer%n)) deallocate (mixer%n)
    if (associated (mixer%dx1)) deallocate (mixer%dx1)
    if (associated (mixer%dx2)) deallocate (mixer%dx2)
    if (associated (mixer%df2)) deallocate (mixer%df2)
    if (associated (mixer%x0)) deallocate (mixer%x0)
    if (associated (mixer%f0)) deallocate (mixer%f0)

  end subroutine destroy_mixer

  subroutine set_mixer(ndim,nspin,mixer)

    use constants
    use aux, only : alccheck
    implicit none
    !
    ! Input/Output variables:
    !
    ! mixer related data
    type (mixer_data), intent(inout) :: mixer

    integer, intent (in) :: ndim
    integer, intent (in) :: nspin
    !
    ! Work variables:
    !
    integer :: totdim
    integer :: alcstat
    integer :: sz

    mixer%ndim = ndim
    mixer%nspin = nspin
    totdim = ndim*nspin

    allocate (mixer%xin (totdim), stat=alcstat)
    call alccheck('mixer%xin',ndim, alcstat)
    allocate (mixer%xout (totdim), stat=alcstat)
    call alccheck('mixer%xout',ndim, alcstat)
      
    if (mixer%name == ANDERSON) then
       !allocate (mixer%xinold (1:totdim,1:mixer%memory), stat=alcstat)
       allocate (mixer%xinold (totdim,mixer%memory), stat=alcstat)
       call alccheck('mixer%xinold',totdim*mixer%memory, alcstat)
       !allocate (mixer%xoutold (1:totdim,1:mixer%memory), stat=alcstat)
       allocate (mixer%xoutold (totdim,mixer%memory), stat=alcstat)
       call alccheck('mixer%xoutold',totdim*mixer%memory, alcstat)

    elseif (mixer%name == BROYDEN) then
       allocate (mixer%resid1 (1:totdim), stat=alcstat)
       call alccheck('mixer%resid1',ndim, alcstat)
       allocate (mixer%old1 (1:totdim), stat=alcstat)
       call alccheck('mixer%old1',ndim, alcstat)
       allocate (mixer%old2 (1:totdim), stat=alcstat)
       call alccheck('mixer%old2',ndim, alcstat)
       allocate(mixer%t(mixer%memory,mixer%memory))
       allocate(mixer%tinv(mixer%memory,mixer%memory))

    elseif (mixer%name == MSECANT1) then
       allocate (mixer%x0 (totdim), stat=alcstat)
       call alccheck('mixer%x0', ndim,alcstat)
       allocate (mixer%f0 (totdim), stat=alcstat)
       call alccheck('mixer%f0', ndim,alcstat)
       allocate (mixer%dx (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%dx', totdim*mixer%memory, alcstat)
       allocate (mixer%df (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%df', totdim*mixer%memory, alcstat)
       if (mixer%group_size == 0) then
           sz = mixer%memory
       else
           sz = mixer%group_size
       endif
       allocate (mixer%n (1:totdim,1:sz), stat=alcstat)
       call alccheck('mixer%n', totdim*sz, alcstat)

    elseif (mixer%name == MSECANT2) then
       allocate (mixer%x0 (totdim), stat=alcstat)
       call alccheck('mixer%x0', ndim,alcstat)
       allocate (mixer%f0 (totdim), stat=alcstat)
       call alccheck('mixer%f0', ndim,alcstat)
       allocate (mixer%dx (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%dx', totdim*mixer%memory, alcstat)
       allocate (mixer%df (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%df', totdim*mixer%memory, alcstat)

    elseif (mixer%name == MSECANT3) then
       allocate (mixer%x0 (totdim), stat=alcstat)
       call alccheck('mixer%x0', ndim,alcstat)
       allocate (mixer%f0 (totdim), stat=alcstat)
       call alccheck('mixer%f0', ndim,alcstat)
       allocate (mixer%dx (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%dx', totdim*mixer%memory, alcstat)
       allocate (mixer%df (1:totdim,1:mixer%memory), stat=alcstat)
       call alccheck('mixer%df', totdim*mixer%memory, alcstat)
       if (mixer%group_size == 0) then
           if (mixer%preferred_type == 1) then
               allocate (mixer%n (1:totdim,1:mixer%memory), stat=alcstat)
               call alccheck('mixer%n', totdim*mixer%memory, alcstat)
           endif
       else
           allocate (mixer%n (1:totdim,1:mixer%group_size), stat=alcstat)
           call alccheck('mixer%dx1', totdim*mixer%group_size, alcstat)
           allocate (mixer%dx1 (1:totdim,1:mixer%group_size), stat=alcstat)
           call alccheck('mixer%dx2', totdim*mixer%group_size, alcstat)
           allocate (mixer%dx2 (1:totdim,1:mixer%group_size), stat=alcstat)
           call alccheck('mixer%df2', totdim*mixer%group_size, alcstat)
           allocate (mixer%df2 (1:totdim,1:mixer%group_size), stat=alcstat)
       endif

    endif

  end subroutine set_mixer

end module mixer_module


! ==================== movement data structure ==================
module movement_module
  use constants
  use aux, only : alccheck
  implicit none

  type movement

     ! maximum number of movements allowed
     integer :: mxmove
     ! counter for number of movements
     integer :: num
     ! type of movements: 1 - Simple, 2 - BFGS, 3 - manual (see const.f)
     integer :: name
     ! max step(au), min step (au),  force minimum
     real(dp)  :: stepmax, stepmin, fmin
     ! true if movement of atoms is being done
     logical :: is_on
     ! 'was minimization achieved' flag
     logical :: min_frc_found
     ! 'routine is stopping' flag
     logical :: done
     ! coordinates of the movable atoms
     ! in systems without periodic boundary conditions, this is
     ! equivalent to coord%xatm,coord%yatm,coord%zatm; in systems with
     ! periodic boundary conditions, they may differ by a unit lattice vector
     real(dp), dimension (:,:), pointer :: rcur
     ! true if structural relaxation is done restarting from previous run
     logical :: is_restart
     ! true if the data required for restart is to be written out to file
     logical :: write_restart
     ! number of corrections used in the BFGS update
     integer :: mmax
     ! lower and upper bounds for the positions of all atoms
     ! (restricted BFGS only)
     real(dp), dimension (:), pointer :: lower, upper
     character (len=60) :: bfgs_task
     ! workspace arrays for BFGS
     integer, dimension (:), pointer :: ibfgs
     real(dp), dimension (:), pointer :: wbfgs
     logical, dimension(:), pointer :: lbfgs

     real(dp), dimension (:), pointer :: dbfgs
     integer, dimension (:), pointer :: ibfgs_save
     character (len=60) :: bfgs_task_save

  end type movement
contains

  subroutine create_movement (move)
    implicit none
    type (movement), intent (inout) :: move

    move%min_frc_found = .false.
    move%done = .false.
    move%num = 0
  end subroutine create_movement

  subroutine init_movement (move)
    implicit none
    type (movement), intent (inout) :: move

    nullify(move%rcur)
    nullify(move%lower)
    nullify(move%upper)
    nullify(move%lbfgs)
    nullify(move%ibfgs)
    nullify(move%dbfgs)
    nullify(move%wbfgs)
  end subroutine init_movement

  subroutine destroy_movement (move)
    implicit none
    type (movement), intent (inout) :: move
    if(associated(move%rcur))  deallocate(move%rcur)
    if(associated(move%lower))  deallocate(move%lower)
    if(associated(move%upper))  deallocate(move%upper)
    if(associated(move%lbfgs))  deallocate(move%lbfgs)
    if(associated(move%ibfgs))  deallocate(move%ibfgs)
    if(associated(move%dbfgs))  deallocate(move%dbfgs)
    if(associated(move%wbfgs))  deallocate(move%wbfgs)

  end subroutine destroy_movement

end module movement_module

! ==================== symmetry data structure ==================
module symmetry_module
  use constants
  use aux, only : alccheck
  implicit none

  type symmetry

     ! true if symmetry operations are used
     logical :: use_symm
     ! number of point group operations
     integer :: ntrans
     ! integer indicating whether hexagonal or cubic symmetry
     integer :: cell_symmetry
     ! matrix of rotations in g-lattice coordinates
     integer, dimension(:,:,:), pointer :: gmtrx
     ! matrix of rotations in r-lattice coordinates
     integer, dimension(:,:,:), pointer :: rmtrx
     ! matrix of rotations in real space
     real(dp), dimension(:,:,:), pointer :: trans
     ! fractional translation in lattice coordinates
     real(dp), dimension(:,:), pointer :: tnp
     ! unit lattice vectors for the supercell (if no PBC are used, the
     ! supercell will be a cubic box that encloses the system)
     real(dp) :: alatt(3,3)
     ! inverse of alatt matrix (needed for the transformation of
     ! coordinates from cartesian to lattice vector units)
     real(dp) :: invlat(3,3)
     ! character table (used only for Abelian subgroup, so it is always
     ! integer)
     integer, dimension(:,:), pointer :: chi

  end type symmetry

contains
  subroutine init_symmetry (symm)
    implicit none
    type (symmetry), intent (inout) :: symm
    nullify(symm%gmtrx)
    nullify(symm%rmtrx)
    nullify(symm%trans)
    nullify(symm%tnp)
    nullify(symm%chi)
  end subroutine init_symmetry

  subroutine destroy_symmetry (symm)
    implicit none
    type (symmetry), intent (inout) :: symm
    if (associated (symm%gmtrx)) deallocate (symm%gmtrx)
    if (associated (symm%rmtrx)) deallocate (symm%rmtrx)
    if (associated (symm%trans)) deallocate (symm%trans)
    if (associated (symm%tnp)) deallocate (symm%tnp)
    if (associated (symm%chi)) deallocate (symm%chi)
  end subroutine destroy_symmetry

  subroutine create_symmetry (ntrans,symm)
    implicit none
    integer, intent (inout) :: ntrans
    type (symmetry), intent (inout) :: symm

    symm%ntrans = ntrans
    allocate (symm%gmtrx (3,3,ntrans))
    allocate (symm%rmtrx (3,3,ntrans))
    allocate (symm%trans (3,3,ntrans))
    allocate (symm%tnp (3,ntrans))
    allocate (symm%chi (ntrans,ntrans))

  end subroutine create_symmetry

end module symmetry_module


!
! ==================== matvec structure ========================
module matvec_base
  use constants
  implicit none
  integer, dimension(:), pointer::natmi
  real(dp), dimension(:), pointer :: dwvec
  complex(dpc), dimension(:), pointer :: zwvec
  integer :: type_num

contains

  subroutine matvec_init(clust, ndim, cplx_flag)

    use constants
    use cluster_module
    use aux, only : alccheck
    implicit none

    type (cluster), intent(in) :: clust
    integer, intent(in) :: ndim
    logical ,intent(in) :: cplx_flag

    integer alcstat

    type_num = clust%type_num

    call matvec_destroy()

    allocate(natmi(clust%type_num))
    natmi(:) = clust%natmi(:)
    if (cplx_flag) then
        allocate(zwvec(ndim+1), stat=alcstat)
        call alccheck('zwvec', ndim+1,alcstat)
    else
        allocate(dwvec(ndim+1), stat=alcstat)
        call alccheck('dwvec',ndim+1,alcstat)
    endif
  end subroutine matvec_init

  subroutine matvec_destroy()
    implicit none
    if (associated(natmi)) deallocate(natmi)

    if (associated(dwvec)) then
!    write(9,*) "deallocating dwvec"
        deallocate(dwvec)
    endif

    if (associated(zwvec)) then
!    write(9,*) "deallocating zwvec"
        deallocate(zwvec)
    endif

  end subroutine matvec_destroy

  subroutine init_matvec()
    nullify(natmi)
    nullify(dwvec)
    nullify(zwvec)
  end subroutine init_matvec
  
end module matvec_base

! ==================== band structure ========================
module bandstruc_module
  use constants
  implicit none

  type bandline
    
    ! line number
    integer :: line_num
    ! coordinates of start and end points of each line in direct coordinates
    real(dp), dimension(3)  :: start , end
    ! coordinates of start and end points of each line in
    ! cartesian coordinates of inverse Bohr radius
    real(dp), dimension(3)  :: startb , endb
    ! line name
    character(len=30) :: line_name
    ! line length 
    real(dp) :: length
    ! number of k-points along the line
    integer :: nkpt
    ! kpoint list (Cartesian coordinates, units of inverse Bohr radius)
    real(dp), dimension (:,:), pointer :: kpts
    ! eigenvlues by kpoint number, spin index, state number
    real(dp), dimension (:,:,:), pointer :: eigs

  end type bandline

  type bandstruc

    !flag for whether band structure calculation is on
    logical :: bands_on
    !number of points for the shortest line for band structure calculation
    integer :: npoints
    !defines the resolution of the band structure
    integer :: nlines
    type(bandline), dimension(:), pointer :: blines    

  end type bandstruc

end module bandstruc_module

!!!!!!!!!!!!! Manish
! This data structure are from PARATEC. They are used
! here with heavy modification. 
!
!     ========== gspace structure ==========================
!

module gspace_module  

  use constants
  implicit none  
  !
  !     first some public data which is global to ALL GSPACES
  !

  type gspace  
     !
     !     ------ true information --------------
     !
     real(dp) :: gmax             ! cutoff length
     real(dp) :: rk(3)            ! the k-vector by which it is shifted
     integer :: length            ! number of g-space vectors 
     integer :: nstar             ! total number of stars in gspace
     integer :: ig0               ! index of the g=0. If not on this proc, = -1
     logical :: imap              ! if indexg mapping is available
     logical :: igvec             ! if gvectors are available
     integer :: kmax(3)
     integer, pointer :: &
          gvec(:,:)         ! the gspace vectors themselves
     integer, pointer :: &
          indexg(:,:,:)         ! Given the gvec, this array gives the 
                              ! index in the gspace vector array of length
     !
     !     ------ FFT information ---------------
     !
     integer :: fftsize(3)        ! FFT grid boundaries for gspace
     character(len=16) :: name    ! a string identifying the gspace

  end type gspace

contains  

  subroutine nullify_gspace(gs)  

    implicit none
    type(gspace), intent(inout) :: gs  

    nullify(gs%gvec)  
    nullify(gs%indexg)  

  end subroutine nullify_gspace

  subroutine destroy_gspace(gs)  

    implicit none
    type(gspace), intent(inout) :: gs  

    if (associated(gs%gvec)) deallocate(gs%gvec)  
    if (associated(gs%indexg)) deallocate(gs%indexg)  

    call nullify_gspace(gs)

  end subroutine destroy_gspace

end module gspace_module

module nscf_module
  use constants
  implicit none

  type nscf_data
    
    !flag for whether non-selfconsistent calculation is on
    logical :: nscf_on
    ! Number of eigenstates to be calculated
    integer :: nstate
    ! number of kpoints
    integer :: nkpt
    ! kgrid
    integer :: kgrid(3)
    ! shift for the kgrid
    real(dp) :: kshift(3)
    ! kpoint list (Cartesian coordinates, units of inverse Bohr radius)
    real(dp), dimension (:,:), pointer :: kpts
    ! kpoint weights
    real(dp), dimension (:), pointer :: kpwt

  end type nscf_data
contains
  subroutine init_nscf(nscf)
  use constants
  type(nscf_data), intent(inout) :: nscf

  nscf%nscf_on = .false.
  nscf%nstate = -1
  nscf%nkpt   = -1
  nscf%kgrid = 0
  nscf%kshift = 0

  nullify(nscf%kpts)
  nullify(nscf%kpwt)
  end subroutine init_nscf

  subroutine destroy_nscf(nscf)
  use constants
  type(nscf_data), intent(inout) :: nscf

  if (associated(nscf%kpts)) deallocate(nscf%kpts)
  if (associated(nscf%kpwt)) deallocate(nscf%kpwt)

  end subroutine destroy_nscf

end module nscf_module

! =================== End of structures ======================
! ===============================================================
