!
! This is a superstructure that holds variables used in the
! many subroutines
! If possible we would like to split this module
! also this is not really global in the shared-memory sense
! since every PE has its own version
!
! main users (actually use the data) are parsec.F90 and eigval.F90
! other users noted below:
module parsec_global_data
  !
  ! type declarations
  !
  use constants
  use potential_module
  use non_local_psp_module
  use eigen_solver_module
  use parallel_data_module
  use rritz_data_module, only : rritz_data
  use prandom_module, only : random_generator
  use io_module, only : inputs_data
  use test_module, only : tests_data
  implicit none
  !
  ! define the actural data being used
  !
  ! potential related data
  !
  ! actually used by :
  ! 
  type (potential) :: pot 

  ! non local pseudopotential related data
  !
  ! actually used by :
  ! 
  type (nonloc_pseudo_potential) :: nloc_p_pot 

  ! on-site Coulomb interaction related data
  !
  ! actually used by :
  ! matvecMP,matvecB,matvec
  !
  type (nonloc_pseudo_potential) :: u_pot

  ! solver related data
  !
  ! actually used by :
  ! matvecMP,matvecB,matvec
  ! chebff,chebdav,subspace,lancz_bound,filterMP
  !
  type (eigen_solver) :: solver

  ! parallel computation related data
  !
  ! actually used by: 
  ! chebff,chebdav,subspace,lancz_bound,filterMP
  ! matvecMP,matvecB,matvec
  !
  type (parallel_data) :: parallel

  ! rayleigh-ritz related data
  !
  ! used by:
  !  chebff
  !  subspace
  !
  type(rritz_data) :: rritz_problem

  type(inputs_data) :: inputs

  type(tests_data) :: tests
  ! vector generator
  !
  ! used by:
  !  chebff
  !  subspace
  !  ortho
  !  dkgs
  type(random_generator) :: vecgen

  ! vector generator
  !
  type(random_generator) :: moldyngen


end module parsec_global_data
