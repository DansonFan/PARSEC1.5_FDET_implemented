!>===============================================================
!! \brief Serves as an external inteface checker.
!!
!! If you use an external interface, please add it here in the
!! same style as depicted e.g. `!> \brief Interface to THING'
!!
!! This file serves as module for explicit interfaces for objects
!! that we may not have access to, usually because they don't
!! exist (F77 routines like BLAS and LAPACk)
!!
!! By keeping these separate we can add a separate layer to go
!!  between our called functions and the actual functions
!!
!! \author: Charles Lena 
!! \date 20161103
!!===============================================================
module external_interfaces
   use constants, only : dp, dpc
   ! BLAS
   !! Level 1
   !!! real*8 functions

   interface
      subroutine zaxpy  ( N, DA, DX, INCX, DY, INCY)
         import :: dp, dpc
         integer :: N
         complex(dpc) ::  DA
         complex(dpc), dimension(*) ::  DX
         integer :: INCX
         complex(dpc), dimension(*) ::  DY
         integer :: INCY
      end subroutine zaxpy
   end interface
   interface
      subroutine daxpy  ( N, DA, DX, INCX, DY, INCY)
         import :: dp, dpc
         integer :: N
         real(dp) ::  DA
         real(dp), dimension(*) ::  DX
         integer :: INCX
         real(dp), dimension(*) ::  DY
         integer :: INCY
      end subroutine daxpy
   end interface
   interface
      subroutine dcopy(N, X, INCX, Y, INCY)
         import :: dp, dpc
         integer :: N
         real(dp), dimension(*) :: X
         integer :: INCX
         real(dp), dimension(*) :: Y
         integer :: INCY
      end subroutine dcopy
   end interface
   interface
      real(dp) function ddot( N, X, INCX, Y, INCY)
         import :: dp, dpc
         integer   N
         real(dp), dimension(*) :: X
         integer  INCX
         real(dp), dimension(*) :: Y
         integer  INCY
      end function ddot
   end interface
   interface
      real(dp) function dsdot ( N, X, INCX, Y, INCY)
         import :: dp, dpc
         integer   N
         real, dimension(*) :: X
         integer  INCX
         real, dimension(*) :: Y
         integer  INCY
      end function dsdot
   end interface
   interface
      subroutine dscal ( N, DA, X, INCX )
         import :: dp, dpc
         integer   N
         real(dp)   DA
         real(dp), dimension(*) :: X
         integer  INCX
      end subroutine
   end interface
   interface
      subroutine dlarnv  ( IDIST,ISEED,N,X )
         import :: dp, dpc
         integer   IDIST
         integer, dimension( 4 ) :: ISEED
         integer   N
         real(dp), dimension( * ) :: X
      end subroutine
   end interface

   !! Level 2
   interface
      subroutine dgemv  ( TRANS, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY )
         import :: dp, dpc
         character  TRANS
         integer  M
         integer  N
         real(dp)   ALPHA
         real(dp), dimension(lda,*) :: A
         integer  LDA
         real(dp), dimension(*) :: X
         integer  INCX
         real(dp)   BETA
         real(dp), dimension(*) :: Y
         integer  INCY
      end subroutine
   end interface
   interface
      subroutine dgemm  (TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC )
         import :: dp, dpc
         character  TRANSA
         character  TRANSB
         integer  M
         integer  N
         integer  K
         real(dp)   ALPHA
         real(dp), dimension(lda,*) :: A
         integer  LDA
         real(dp), dimension(ldb,*) :: B
         integer  LDB
         real(dp)   BETA
         real(dp), dimension(ldc,*) :: C
         integer  LDC
      end subroutine
   end interface
   ! BLAS
   !! Level 1
   !!! complex*16 functions
   interface
      subroutine zcopy(N, ZX, INCX, ZY, INCY)
         import :: dp, dpc
         integer :: N
         complex(dpc), dimension(*) :: ZX
         integer :: INCX
         complex(dpc), dimension(*) :: ZY
         integer :: INCY
      end subroutine zcopy
   end interface
   interface
      complex(dpc) function zdotu ( N, ZX, INCX, ZY, INCY)
         import :: dp, dpc
         integer   N
         complex(dpc), dimension(*) :: ZX
         integer  INCX
         complex(dpc), dimension(*) :: ZY
         integer  INCY
      end function zdotu
   end interface
   interface
      complex(dpc) function zdotc ( N, ZX, INCX, ZY, INCY)
         import :: dp, dpc
         integer   N
         complex(dpc), dimension(*) :: ZX
         integer  INCX
         complex(dpc), dimension(*) :: ZY
         integer  INCY
      end function zdotc
   end interface
   interface
      subroutine zscal ( N, DA, ZX, INCX )
         import :: dp, dpc
         integer   N
         complex(dpc)   DA
         complex(dpc), dimension(*) :: ZX
         integer  INCX
      end subroutine
   end interface
   interface
      subroutine zdscal ( N, DA, ZX, INCX )
         import :: dp, dpc
         integer   N
         real(dp)   DA
         complex(dpc), dimension(*) :: ZX
         integer  INCX
      end subroutine
   end interface
   interface
      subroutine zgemv  ( TRANS, M, N, ALPHA, A, LDA, X, INCX, BETA, Y, INCY )
         import :: dp, dpc
         character  TRANS
         integer  M
         integer  N
         complex(dpc)   ALPHA
         complex(dpc), dimension(lda,*) :: A
         integer  LDA
         complex(dpc), dimension(*) :: X
         integer  INCX
         complex(dpc)   BETA
         complex(dpc), dimension(*) :: Y
         integer  INCY
      end subroutine
   end interface
   interface
      subroutine zgemm  (TRANSA, TRANSB, M, N, K, ALPHA, A, LDA, B, LDB, BETA, C, LDC )
         import :: dp, dpc
         character  TRANSA
         character  TRANSB
         integer  M
         integer  N
         integer  K
         complex(dpc)   ALPHA
         complex(dpc), dimension(lda,*) :: A
         integer  LDA
         complex(dpc), dimension(ldb,*) :: B
         integer  LDB
         complex(dpc)   BETA
         complex(dpc), dimension(ldc,*) :: C
         integer  LDC
      end subroutine
   end interface
   interface
      subroutine zlarnv  ( IDIST,ISEED,N,X )
         import :: dp, dpc
         integer   IDIST
         integer, dimension( 4 ) :: ISEED
         integer   N
         complex(dpc), dimension( * ) :: X
      end subroutine
   end interface
   interface
      subroutine zheevd(JOBZ,UPLO,N,A,LDA,W,WORK,LWORK,RWORK,LRWORK,IWORK,LIWORK,INFO)
         import :: dp, dpc
         character   JOBZ
         character   UPLO
         integer   N
         complex(dpc), dimension( lda, * ) :: A
         integer   LDA
         real(dp), dimension( * ) :: W
         complex(dpc), dimension( * ) :: WORK
         integer   LWORK
         real(dp), dimension( * ) :: RWORK
         integer   LRWORK
         integer, dimension( * ) :: IWORK
         integer   LIWORK
         integer   INFO
      end subroutine
   end interface

   ! LAPACK
   interface
      subroutine dgetri  ( N, A, LDA, IPIV, WORK, LWORK, INFO)
         import :: dp, dpc
         integer  N
         real(dp), dimension( lda, * ) ::  A
         integer  LDA
         integer, dimension( * ) ::  IPIV
         real(dp), dimension( * ) ::  WORK
         integer  LWORK
         integer  INFO
      end subroutine dgetri
   end interface

   interface
      subroutine dgetrf  (M, N, A, LDA, IPIV, INFO)
         import :: dp, dpc
         integer   M
         integer  N
         real(dp), dimension( lda, * ) ::  A
         integer  LDA
         integer, dimension( * ) ::  IPIV
         integer  INFO
      end subroutine dgetrf
   end interface
   interface
      subroutine dgeqp3  ( M, N, A, LDA, JPVT, TAU, WORK, LWORK, INFO )
         integer   M
         integer   N
         double precision, dimension( lda, * ) ::  A
         integer   LDA
         integer, dimension( * ) ::  JPVT
         double precision, dimension( * ) :: TAU
         double precision, dimension( * ) :: WORK
         integer   LWORK
         integer   INFO
      end subroutine
   end interface
   interface
      subroutine dgesv  ( N, NRHS, A, LDA, IPIV, B, LDB, INFO )
         integer   N
         integer  NRHS
         double precision, dimension( lda, * ) :: A
         integer  LDA
         integer, dimension( * ) :: IPIV
         double precision, dimension( ldb, * ) :: B
         integer  LDB
         integer  INFO
      end subroutine
   end interface
   interface 
      subroutine dstemr ( JOBZ, RANGEC, N, D, E, VL, VU, &
         IL, IU, M, W, Z, LDZ, NZC,&
         ISUPPZ, TRYRAC, WORK, LWORK,&
         IWORK, LIWORK, INFO)
      import :: dp
      character :: JOBZ
      character :: RANGEC
      integer :: N
      real(dp) :: D(N)
      real(dp) :: E(N)
      real(dp) :: VL
      real(dp) :: VU
      integer :: IL
      integer :: IU
      integer :: M ! resulting num eigenvalues
      real(dp) :: W(N) ! resulting eigenvalues
      real(dp), dimension(LDZ, *) :: Z ! returned orthonormal eigenvectors
      integer :: LDZ
      integer :: NZC
      integer, dimension(*) :: ISUPPZ
      logical :: TRYRAC
      real(dp), dimension(*) :: work
      integer :: lwork ! dimension of work
      integer, dimension(*) :: iwork
      integer :: liwork ! dimension of iwork
      integer :: info
      end subroutine dstemr
   end interface
   interface
      subroutine dsyev ( JOBZ, UPLO, N, A, LDA, W, WORK, LWORK, INFO )
         character   JOBZ
         character   UPLO
         integer   N
         double precision, dimension( lda, * ) ::  A
         integer   LDA
         double precision, dimension( * ) :: W
         double precision, dimension( * ) :: WORK
         integer   LWORK
         integer   INFO
      end subroutine dsyev
   end interface
   interface
      subroutine zheev  ( JOBZ, UPLO, N, A, LDA, W, WORK, LWORK, RWORK, INFO )
         character   JOBZ
         character  UPLO
         integer  N
         complex(kind((0.d0,0.d0))), dimension( lda, * ) :: A
         integer  LDA
         double precision, dimension( * ) ::  W
         complex(kind((0.d0,0.d0))), dimension( * ) ::  WORK
         integer  LWORK
         double precision, dimension( * ) ::  RWORK
         integer  INFO
      end subroutine zheev
   end interface

#ifdef WITH_ELPA
#ifndef WITH_SCALAPACK
#error "WITH_SCALAPACK not defined but trying to use WITH_ELPA will not work."
#endif
#endif

#ifdef WITH_SCALAPACK
   ! Scalapack interface
   interface
      !> \brief Interface to Scalapack::numroc
      integer function numroc  ( N, NB, IPROC, IPROC_OFFSET, NPROCS)
         integer, intent(in) :: N
         integer, intent(in) :: NB
         integer, intent(in) :: IPROC
         integer, intent(in) :: IPROC_OFFSET
         integer, intent(in) :: NPROCS
      end function numroc
   end interface
   interface
      !> \brief Interface to Scalapack::pdgemm
      subroutine pdgemm(TRANSA, TRANSB, M, N, K, ALPHA, A, IA, JA, DESC_A,  &
            B, IB, JB, DESC_B, BETA, &
            C, IC, JC, DESC_C)
         character(*) :: TRANSA
         character(*) :: TRANSB
         integer, intent(in) :: M
         integer, intent(in) :: N
         integer, intent(in) :: K
         double precision, intent(in) :: ALPHA
         double precision, intent(in) :: A(*)
         integer, intent(in) :: IA, JA
         integer, dimension(9), intent(in) :: DESC_A
         double precision, intent(in) :: B(*)
         integer, intent(in) :: IB, JB
         integer, dimension(9), intent(in) :: DESC_B
         double precision, intent(in) :: BETA
         double precision, intent(inout) :: C(*)
         integer, intent(in) :: IC, JC
         integer, dimension(9), intent(in) :: DESC_C
      end subroutine pdgemm
      !> \brief Interface to Scalapack::pzgemm
      subroutine pzgemm(TRANSA, TRANSB, M, N, K, ALPHA, A, IA, JA, DESC_A,  &
            B, IB, JB, DESC_B, BETA, &
            C, IC, JC, DESC_C)
         character(*) :: TRANSA
         character(*) :: TRANSB
         integer, intent(in) :: M
         integer, intent(in) :: N
         integer, intent(in) :: K
         double complex, intent(in) :: ALPHA
         double complex, intent(in) :: A(*)
         integer, intent(in) :: IA, JA
         integer, dimension(9), intent(in) :: DESC_A
         double complex, intent(in) :: B(*)
         integer, intent(in) :: IB, JB
         integer, dimension(9), intent(in) :: DESC_B
         double complex, intent(in) :: BETA
         double complex, intent(inout) :: C(*)
         integer, intent(in) :: IC, JC
         integer, dimension(9), intent(in) :: DESC_C
      end subroutine pzgemm
   end interface
   interface
      !> \brief Interface to Scalapack::dgsum2D
      subroutine dgsum2d(icontxt, scope, top, m, n, A, lda, rdest, cdest)
         integer, intent(in) :: icontxt !< blacs context
         character(1), intent(in) :: scope !< 'R', 'C' or 'A'
         character(1), intent(in) :: top
         integer, intent(in) :: m !< number of matrix rows to be combined
         integer, intent(in) :: n !< number of matrix cols to be combined
         integer, intent(in) :: lda !< lead dimension of A
         double precision, intent(inout) :: A(lda, *) !< matrix to be added to produce the sum
         integer, intent(in) :: rdest !< process row coordinate to receive result
         integer, intent(in) :: cdest !< process column coordinate to receive result
      end subroutine
   end interface
   interface
      subroutine zgsum2d(icontxt, scope, top, m, n, A, lda, rdest, cdest)
         integer, intent(in) :: icontxt
         character(1), intent(in) :: scope
         character(1), intent(in) :: top
         integer, intent(in) :: m
         integer, intent(in) :: n
         double complex, intent(inout) :: A(lda, *)
         integer, intent(in) :: lda
         integer, intent(in) :: rdest
         integer, intent(in) :: cdest
      end subroutine
   end interface
   interface
      subroutine blacs_gridinit(ICNTXT, ORDER, NP_ROWS, NP_COLS)
         integer, intent(inout) :: ICNTXT
         character(*), intent(in) :: ORDER
         integer, intent(in) :: NP_ROWS
         integer, intent(in) :: NP_COLS
      end subroutine
   end interface
   interface
      subroutine blacs_gridinfo(ICNTXT, NP_ROWS, NP_COLS, IPROW, IPCOL)
         integer, intent(in) :: ICNTXT
         integer, intent(out) :: NP_ROWS
         integer, intent(out) :: NP_COLS
         integer, intent(out) :: IPROW
         integer, intent(out) :: IPCOL
      end subroutine
   end interface
   interface
      subroutine blacs_gridexit(ICNTXT)
         integer, intent(inout) :: ICNTXT
      end subroutine
   end interface
#endif
end module external_interfaces

module fftw3_module
#if defined(USEFFTW3)
   use, intrinsic :: iso_c_binding
   use constants, only : dp, dpc
#if defined(CREATE_FFTW3_MODULE)
   include 'fftw3.f03'
#else
   ! FFTW3+ Interface
   ! CML:TODO add in threaded FFTW calls
   interface
      subroutine dfftw_cleanup()
      end subroutine dfftw_cleanup
   end interface
   interface
      subroutine dfftw_plan_dft_3d(plan, n1, n2, n3,chd_in,chd_out,fftw_direction_in,fftw_flags)
         import :: dp, dpc
         integer(kind=8) :: plan
         integer :: n1
         integer :: n2
         integer :: n3
         complex(dpc), dimension(*) :: chd_in
         complex(dpc), dimension(*) :: chd_out
         integer :: fftw_direction_in
         integer :: fftw_flags
      end subroutine dfftw_plan_dft_3d
   end interface
   interface
      subroutine dfftw_execute(plan)
         integer(kind=8) :: plan
      end subroutine dfftw_execute
   end interface
   interface
      subroutine dfftw_destroy_plan(plan)
         integer(kind=8) :: plan
      end subroutine dfftw_destroy_plan
   end interface
#endif
#endif
end module fftw3_module
