module exc_module
   implicit none
   contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This subroutine computes the exchange correlation potential,
! Vxc, and the exchange correlation energy, Exc, both in Rydbergs,
! based on an input charge density given in e/(bohr^3).
!
! NOTE: Extra factor of two in formulas is due to conversion from
! Hartree to Rydberg!
!
! The following exchange-correlation functionals are implemented:
!
! Local density functionals:
! Ceperley-Alder - D. M. Ceperley and B. J. Alder, Phys. Rev.
! Lett., 45, 566 (1980).
!
! PL = PW92 = PWLDA - J. P. Perdew and Y. Wang, Phys. Rev. B 45, 13244 (1992). 
!
! Gradient-corrected functionals:
! PBE - Perdew, Burke, Ernzerhof - J. P. Perdew, K. Burke, 
! and M. Ernzerhof, Phys. Rev. Lett., 77, 3865 (1996).
!
! PW(91) = PWGGA : J. Perdew et. al., PRB 46, 6671 (1992)
!
!---------------------------------------------------------------
subroutine exc_spn(grid,parallel,nrep,icorr,dioniz,vxc,wvec,exc)

  use constants
  use grid_module
  use parallel_data_module
  use dbuffer_module
  use stencil_things
  use psum_module
  use gradmvs_module
  use laplacian_ops_module, only : laplacian_fold
  use pbe_module, only : pbe, pw91, gcor2, spn_pbe, spn_gcor
  implicit none
  !
  ! Input/Output variables:
  !
  ! grid related data
  type (grid_data), intent(in) :: grid
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel

  ! correlation type
  character (len=2), intent(in) :: icorr
  ! ionization energy difference
  ! (used only if the correlation is of type cs)
  real(dp), intent(in) :: dioniz
  ! order of the reduced group
  integer, intent(in) :: nrep
  ! Input: charge density. Output: exchange-correlation potential
  real(dp), intent(inout) :: vxc(parallel%mydim,2)
  ! work array
  real(dp), intent(out) :: wvec(parallel%nwedge + 1)
  ! total exchange-correlation energy
  real(dp), intent(out) :: exc
  !
  ! Work variables:
  !
  ! multiplicity of grid points in irreducible wedge (equal to
  ! order of the reduced group)
  real(dp) :: weight

  ! should be changed to parameters
  integer, parameter :: UP = 1,DOWN = 2

  ! GGA variables:
  ! quantities fed to pbe.f:
  ! gradient - grad(n), where n is the charge density
  ! absgrad  - |grad(n)|
  ! grdgrd - components of grad(|grad(n)|
  ! laplac - laplacian(n)
  ! prod  -  grad(n) dot grad(|grad(n)|
  ! abs_total_grad - |grad(total rho)| 

  real(dp), dimension (:,:), allocatable :: &
       gradUP, gradDN, gradgradUP, gradgradDN, total_gradgrad
  real(dp),dimension (:,:), allocatable :: absgrad,laplac

  real(dp), allocatable :: abs_total_grad(:)
  real(dp),dimension (UP:DOWN):: prod
  real(dp) :: total_prod
  real(dp) :: vxctmp !< threadprivate temp variable instead of using array

  integer spin

  integer :: &
       lcor, &              ! flag to do correlation(=0=>don't)
       lpot                 ! flag to do potential(=0=>don't)


  real(dp) :: &
       exlsd, &             ! LSD exchange energy density, so that
                            !     ExLSD=int d^3r rho(r) exlsd(r)
       vxuplsd, &           ! up LSD exchange potential
       vxdnlsd, &           ! down LSD exchange potential
       eclsd, &             ! LSD correlation energy density
       vcuplsd, &           ! up LSD correlation potential
       vcdnlsd              ! down LSD correlation potential

  real(dp) :: &
       expw91,vxuppw91, &   !
       vxdnpw91,ecpw91, &   ! corresponding PW91 quantities
       vcuppw91,vcdnpw91    !

  real(dp) :: &
       expbe,vxuppbe, &     !
       vxdnpbe,vcuppbe, &   ! corresponding PBE quantities
       vcdnpbe,ecpbe        !

  ! LDA variables:
  ! rs is the local value of the Wigner-Seitz radius
  ! rho,vx,vc temporarily store the charge,exchange and correlation 
  ! potentials at a given grid point
  real(dp) :: rs, rh(2),vx(2),vc(2)

  ! High density (rs<1) contants, LDA
  real(dp), parameter :: ca_c1 = 0.0622d0
  real(dp), parameter :: ca_c2 = 0.0960d0
  real(dp), parameter :: ca_c3 = 0.0040d0
  real(dp), parameter :: ca_c4 = 0.0232d0
  real(dp), parameter :: ca_c5 = 0.0192d0

  real(dp), parameter :: ca_as =  0.0311d0
  real(dp), parameter :: ca_bs = -0.0538d0
  real(dp), parameter :: ca_cs =  0.0014d0
  real(dp), parameter :: ca_ds = -0.0096d0
  ! Low density (rs>1) constants, LDA
  real(dp), parameter :: ca_g = -0.2846d0
  real(dp), parameter :: ca_b1 = 1.0529d0
  real(dp), parameter :: ca_b2 = 0.3334d0
  real(dp), parameter :: ca_gs = -0.1686d0
  real(dp), parameter :: ca_b1s = 1.3981d0
  real(dp), parameter :: ca_b2s = 0.2611d0
  ! Other parameters
  real(dp), parameter :: ac2 = four/three
  real(dp), parameter :: p75vpi = 0.75d0/pi
  real(dp), parameter :: ax = -0.7385588d0
  real(dp), parameter :: gamma = 0.5198421d0
  real(dp), parameter :: fzz = 1.709921d0
  ! other temporary holders
  real(dp) :: ex(2),ec,eu,f,zet,z4,ecrs,eurs,eczet,comm,fz,d
  real(dp) :: lrs, srs, es, vs
  real(dp) :: ep,eprs,alfrsm,alfm
  real(dp) :: temp_val

  ! Asymptotic corrections parameters and temporary variables
  real(dp), parameter :: betalb = 0.05d0
  real(dp) :: abstemp1, abstemp2, corrlb1, corrlb2, asinhx

  ! counters
  integer i 
  ! allocation check
  integer alcstat

  real(dp), dimension (3) :: temp1,temp2,temp3,temp4,temp5,temp6

  ! local number of grid points
  integer ndim
  ! communication buffer for lap/grad
  !type (lap_buffer) :: lap_buf
  type (fold_buffer) :: fold_buf
  ! laplacian definition working copy (we strip symmetry in the lap/grad)
  !  type (stencil_definitions) :: sten_def

  ! forcing use of intrinsic functions
  intrinsic :: sqrt, abs, dot_product, log

  !---------------------------------------------------------------

  ndim = parallel%mydim
  weight = real(nrep,dp)
  !
  ! initialize the total exchange-correlation energy to zero
  !
  exc = zero

  if (icorr == 'pb' .or. icorr == 'pw') then

     ! using PBE - a gradient-corrected functional

     ! quantities fed to pbe.f:
     ! gradient - grad(n), where n is the charge density

     ! absgrad  - |grad(n)|
     ! gradgrad - components of grad(|grad(n)|
     ! laplac - laplacian(n)
     ! prod  -  grad(n) dot grad(|grad(n)|

     ! abs_total_grad - |grad(total rho)|

     ! initialize working arrays:

     allocate(abs_total_grad(ndim),stat=alcstat)
     call alccheck('abs_total_grad',ndim,alcstat)
     allocate(absgrad(ndim,UP:DOWN),stat=alcstat)
     call alccheck('absgrad',ndim*(DOWN-UP+1),alcstat)
     allocate(laplac(ndim,UP:DOWN),stat=alcstat)
     call alccheck('laplac',ndim*(DOWN-UP+1),alcstat)
     allocate(gradUP(3,ndim),stat=alcstat)
     call alccheck('gradUP',3*ndim,alcstat)
     allocate(gradDN(3,ndim),stat=alcstat)
     call alccheck('gradDN',3*ndim,alcstat)
     allocate(gradgradUP(3,ndim),stat=alcstat)
     call alccheck('gradgradUP',3*ndim,alcstat)
     allocate(gradgradDN(3,ndim),stat=alcstat)
     call alccheck('grdgrdDN',3*ndim,alcstat)
     allocate(total_gradgrad(3,ndim),stat=alcstat)
     call alccheck('total_gradgrad',3*ndim,alcstat)

     ! prepare vectors for invoking pbe
  ! grab the laplacian definitions
  !sten_def = grid%sten_def

!Initialize lap buffers for communications {{{ 
   if (parallel%group_size > 1 ) then
  ! call init_lap_buffer(lap_buf)
  ! call allocate_lap_buffer(lap_buf,parallel)
  call fold_buf%init()
  call fold_buf%alloc(parallel,foldvol=grid%sten_coeff%foldsize)
   endif
!}}}
         
     ! calculate the gradient of the charge density (rho==exc) at each
     ! grid point: gradUP, gradDN
     call gradmvs(grid,parallel,vxc(1,UP),gradUP,grid%coe1 &
          ,grid%norder,wvec)
     call gradmvs(grid,parallel,vxc(1,DOWN),gradDN,grid%coe1 &
          ,grid%norder,wvec)

     ! calculate abs_total_grad
     ! (|grad(total rho)| = |grad(up)+grad(down)|)
     do i = 1,ndim
        temp1 = gradUP(:,i) + gradDN(:,i)
        abs_total_grad(i) = sqrt(dot_product(temp1,temp1))
     enddo

     ! calculate total_gradgrad(i) = grad|grad(rho(i))| 
     call gradmvs(grid,parallel,abs_total_grad,total_gradgrad, &
          grid%coe1,grid%norder,wvec)

     ! calculate absgrad(i,spin) -  the absolute value of the gradient
     ! in UP/DN: |grad(rho(i,spin)|
     do i = 1,ndim
        temp1 = gradUP(:,i)
        absgrad(i,UP)= sqrt(dot_product(temp1,temp1))
        temp2 = gradDN(:,i)
        absgrad(i,DOWN)= sqrt(dot_product(temp2,temp2))
     enddo

     ! calculate gradgrad_spin = grad|grad(rho(i,spin))| 
     call gradmvs(grid,parallel,absgrad(1,UP),gradgradUP,grid%coe1 &
          ,grid%norder,wvec)
     call gradmvs(grid,parallel,absgrad(1,DOWN),gradgradDN,grid%coe1 &
          ,grid%norder,wvec)

     ! Calculate laplac(i,spin) -  the Laplac of rho(spin) at each
     ! grid point.
     do spin = UP,DOWN
! call laplacian(parallel,sten_def,lap_buf,vxc(1,spin),laplac(1,spin))
 call laplacian_fold(parallel,grid%sten_coeff,fold_buf,vxc(1,spin),laplac(1,spin))
     enddo
     laplac = -laplac

    !destroy the buffer
    if (parallel%group_size > 1 ) then

    call fold_buf%destroy()
!    call destroy_lap_buffer(lap_buf)
    endif
     ! do correlation
     lcor = 1
     ! do potential
     lpot = 1

     do i = 1,ndim

        ! prod(spin) = grad(rho(spin))_dot_grad|grad(rho(spin))| 
        ! grad(rho(spin)) = gradUP , gradDN
        ! grad|grad(rho(spin))| = gradgradUP , gradgradDN
        ! UP
        temp1 = gradUP(:,i)
        temp2 = gradgradUP(:,i)
        prod(UP) = dot_product (temp1,temp2)
        ! DOWN
        temp3 = gradDN(:,i)
        temp4 = gradgradDN(:,i)
        prod(DOWN) = dot_product (temp3,temp4)

        ! Total Prod
        ! total_prod = delgr=(grad rho).(grad |grad rho|) 
        ! (grad rho) = grad(rho up) + grad (rho dn)
        ! (grad |grad rho|) = total_gradgrad
        temp5 = gradUP(:,i) + gradDN(:,i)
        temp6 = total_gradgrad(:,i)
        total_prod = dot_product(temp5,temp6)
        
        call spn_pbe(vxc(i,UP),absgrad(i,UP),prod(UP),laplac(i,UP), &
             vxc(i,DOWN),absgrad(i,DOWN),prod(DOWN),laplac(i,DOWN), &
             abs_total_grad(i),total_prod,lcor,lpot, &
             exlsd,vxuplsd,vxdnlsd,eclsd,vcuplsd,vcdnlsd, &
             expw91,vxuppw91,vxdnpw91,ecpw91,vcuppw91,vcdnpw91, &
             expbe,vxuppbe,vxdnpbe,ecpbe,vcuppbe,vcdnpbe)

        if (icorr == 'pb') then
           ! using PBE - a gradient-corrected functional
           exc=exc+( (vxc(i,UP)+vxc(i,DOWN))*two*(expbe+ecpbe) )*weight
           vxc(i,UP)=two*(vxuppbe+vcuppbe)
           vxc(i,DOWN)=two*(vxdnpbe+vcdnpbe)
           ! using non-local functional of rho, PW91
        else
           ! using GGA functional of rho, PW91
           exc=exc+( (vxc(i,UP)+vxc(i,DOWN))*two*(expw91+ecpw91) )*weight
           vxc(i,UP)=two*(vxuppw91+vcuppw91)
           vxc(i,DOWN)=two*(vxdnpw91+vcdnpw91)
        endif
     enddo

     ! free up memory
     deallocate(abs_total_grad)
     deallocate(absgrad)
     deallocate(laplac)
     deallocate(gradUP)
     deallocate(gradDN)
     deallocate(gradgradUP)
     deallocate(gradgradDN)
     deallocate(total_gradgrad)
  else if (icorr == 'pl') then
     ! Ceperly-Alder exchange correlation
     temp_val = ax*two**third
     do i=1,ndim
        rh(1)=vxc(i,1)
        rh(2)=vxc(i,2)
        if (minval(rh) > zero) then
           ! exchange
           d=two*rh(1)
           ex(1)= ax*d**third
           vx(1)=ex(1)*ac2
           d=two*rh(2)
           ex(2)= ax*d**third
           vx(2)=ex(2)*ac2
           ! local correlation
           d=sum(rh)
           rs=(p75vpi/d)**third
           call spn_gcor(0.0310907d0,0.21370d0,7.5957d0,3.5876d0, &
                1.6382d0,0.49294d0,1.00d0,rs,eu,eurs)
           call spn_gcor(0.01554535d0,0.20548d0,14.1189d0,6.1977d0, &
                3.3662d0,0.62517d0,1.00D0,rs,ep,eprs)
           call spn_gcor(0.0168869d0,0.11125d0,10.357d0,3.6231d0, &
                0.88026d0,0.49671d0,1.00d0,rs,alfm,alfrsm)
           zet=(rh(1)-rh(2))/d
           f = ((one+zet)**ac2+(one-zet)**ac2-two)/gamma
           z4 = zet**4
           ec = eu*(one-f*z4)+ep*f*z4-alfm*f*(one-z4)/fzz
           ecrs = eurs*(one-f*z4)+eprs*f*z4-alfrsm*f*(one-z4)/fzz
           fz = ac2*((one+zet)**third-(one-zet)**third)/gamma
           eczet = four*(zet**3)*f*(ep-eu+alfm/fzz)+fz*(z4*ep-z4*eu &
                -(one-z4)*alfm/fzz)
           comm = ec -rs*ecrs/three-zet*eczet
           vc(1) = comm + eczet
           vc(2) = comm - eczet

           vxc(i,1)=two*(vx(1)+vc(1))
           vxc(i,2)=two*(vx(2)+vc(2))
           ec=two*(rh(1)*ex(1)+rh(2)*ex(2)+ec*d)
           exc = exc + ec*weight
        endif
     enddo
  else if (icorr == 'ca') then
     ! Ceperly-Alder exchange correlation
     temp_val = ax*two**third
     do i=1,ndim
        rh(1)=vxc(i,1)
        rh(2)=vxc(i,2)
        if (minval(rh) > zero) then
           ! exchange
           d=two*rh(1)
           ex(1)= ax*d**third
           vx(1)=ex(1)*ac2
           d=two*rh(2)
           ex(2)= ax*d**third
           vx(2)=ex(2)*ac2
           ! local correlation
           d=sum(rh)
           rs=(p75vpi/d)**third

           zet=(rh(1)-rh(2))/d
           f = ((one+zet)**ac2+(one-zet)**ac2-two)/gamma
           fz = ac2*((one+zet)**third-(one-zet)**third)/gamma
           if (rs < one) then
              ! correlation: high density
              lrs = log(rs)
              eu = ca_c1 * lrs - ca_c2 + (ca_c3 * lrs - ca_c4) * rs  
              vc(1) = eu - (ca_c1 + (ca_c3 * lrs + ca_c3 - ca_c4) * rs) /3.d0
              es = ca_as * lrs + ca_bs + (ca_cs * lrs + ca_ds) * rs
              vs = es - (ca_as + (ca_cs * lrs + ca_cs + ca_ds) * rs) /3.d0
           else
              ! correlation: low density
              srs = sqrt(rs)
              eu = ca_g / (1.d0 + ca_b1 * srs + ca_b2 * rs)
              vc(1) = eu * eu * (1.d0 + 7.0d0 * ca_b1 * srs / 6.d0 + &
                   4.d0/3.d0 * ca_b2 * rs) / ca_g
              es = ca_gs / (1.d0 + ca_b1s * srs + ca_b2s * rs)
              vs = es * es * (1.d0 + 7.0d0 * ca_b1s * srs / 6.d0 + &
                   4.d0/3.d0 * ca_b2s * rs) / ca_gs
           endif
           vc(2) = vc(1) + f * (vs - vc(1)) - (es - eu) * &
                (1.d0 + zet) * fz
           vc(1) = vc(1) + f * (vs - vc(1)) + (es - eu) * &
                (1.d0 - zet) * fz

           ec = eu + f * (es - eu)

           vxc(i,1)=two*vx(1)+vc(1)
           vxc(i,2)=two*vx(2)+vc(2)
           ec=two*(rh(1)*ex(1)+rh(2)*ex(2))+ec*d
           exc = exc + ec*weight
        endif
     enddo

  else if (icorr == 'lb' .or. icorr == 'cs') then
     ! Asymptotically corrected Ceperly-Alder exchange correlation

     ! initialize working arrays:
     allocate(absgrad(ndim,UP:DOWN),stat=alcstat)
     call alccheck('absgrad',ndim*(DOWN-UP+1),alcstat)
     allocate(gradUP(3,ndim),stat=alcstat)
     call alccheck('gradUP',3*ndim,alcstat)
     allocate(gradDN(3,ndim),stat=alcstat)
     call alccheck('gradDN',3*ndim,alcstat)

     ! calculate |grad(rho)|/rho^(4/3) -- spinup & spindown
     call gradmvs(grid,parallel,vxc(1,UP),gradUP,grid%coe1 &
          ,grid%norder,wvec)
     call gradmvs(grid,parallel,vxc(1,DOWN),gradDN,grid%coe1 &
          ,grid%norder,wvec)
     do i = 1,ndim
        temp1 = gradUP(:,i)
        abstemp1 = sqrt(dot_product(temp1,temp1))
        temp2 = gradDN(:,i)
        abstemp2 = sqrt(dot_product(temp2,temp2))
        if (vxc(i,UP) > zero) then
           absgrad(i,UP)= abstemp1/(vxc(i,UP)**ac2)
        endif
        if (vxc(i,DOWN) > zero) then
           absgrad(i,DOWN)= abstemp2/(vxc(i,DOWN)**ac2)
        endif
     enddo

     ! compute exchange-correlation potential and energy
     temp_val = ax*two**third
     do i=1,ndim
        rh(1)=vxc(i,1)
        rh(2)=vxc(i,2)
        if (minval(rh) > zero) then

           ! compute exchange
           d=two*rh(1)
           ex(1)= ax*d**third
           vx(1)=ex(1)*ac2
           d=two*rh(2)
           ex(2)= ax*d**third
           vx(2)=ex(2)*ac2

           ! compute Ceperely-Alder term
           d=sum(rh)
           rs=(p75vpi/d)**third

           zet=(rh(1)-rh(2))/d
           f = ((one+zet)**ac2+(one-zet)**ac2-two)/gamma
           fz = ac2*((one+zet)**third-(one-zet)**third)/gamma
           if (rs < one) then
              ! correlation: high density
              lrs = log(rs)
              eu = ca_c1 * lrs - ca_c2 + (ca_c3 * lrs - ca_c4) * rs
              vc(1) = eu - (ca_c1 + (ca_c3 * lrs + ca_c3 - ca_c4) * rs) /3.d0
              es = ca_as * lrs + ca_bs + (ca_cs * lrs + ca_ds) * rs
              vs = es - (ca_as + (ca_cs * lrs + ca_cs + ca_ds) * rs) /3.d0
           else
              ! correlation: low density
              srs = sqrt(rs)
              eu = ca_g / (1.d0 + ca_b1 * srs + ca_b2 * rs)
              vc(1) = eu * eu * (1.d0 + 7.0d0 * ca_b1 * srs / 6.d0 + &
                   4.d0/3.d0 * ca_b2 * rs) / ca_g
              es = ca_gs / (1.d0 + ca_b1s * srs + ca_b2s * rs)
              vs = es * es * (1.d0 + 7.0d0 * ca_b1s * srs / 6.d0 + &
                   4.d0/3.d0 * ca_b2s * rs) / ca_gs
           endif
           vc(2) = vc(1) + f * (vs - vc(1)) - (es - eu) * &
                (1.d0 + zet) * fz
           vc(1) = vc(1) + f * (vs - vc(1)) + (es - eu) * &
                (1.d0 - zet) * fz

           ec = eu + f * (es - eu)

           vxc(i,1)=two*vx(1)+vc(1)
           vxc(i,2)=two*vx(2)+vc(2)
           ec=two*(rh(1)*ex(1)+rh(2)*ex(2))+ec*d
           exc = exc + ec*weight

           ! Compute Leeuwen-Baerends correction to the potential.
           abstemp1 = absgrad(i,UP)
           abstemp2 = absgrad(i,DOWN)
           asinhx = log(abstemp1+sqrt(abstemp1*abstemp1+one))
           corrlb1 = two*betalb*(rh(1)**third)*abstemp1*abstemp1/ &
                (one + three*betalb*abstemp1*asinhx)
           asinhx = log(abstemp2+sqrt(abstemp2*abstemp2+one))
           corrlb2 = two*betalb*(rh(2)**third)*abstemp2*abstemp2/ &
                (one + three*betalb*abstemp2*asinhx)

           ! If correcting for the ionization energy difference, shift the
           ! correlation energy.
           if (icorr == 'cs') then
              if (corrlb1 > dioniz) corrlb1 = dioniz
              if (corrlb2 > dioniz) corrlb2 = dioniz
           endif
           vxc(i,1) = vxc(i,1) - corrlb1
           vxc(i,2) = vxc(i,2) - corrlb2
        endif
    enddo

    ! free up memory
     deallocate(absgrad)
     deallocate(gradUP)
     deallocate(gradDN)

  endif
  !
  ! Scale the total energy integral by h^3 (factor necessary due to
  ! the expression of an integral as a summation over grid points) and
  ! sum it up over processors.
  !
  call psum(exc,1,parallel%group_size,parallel%group_comm)
  exc  = exc * (grid%hcub)

end subroutine exc_spn
!===============================================================
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! This suborutine computes the exchange correlation potential,
! Vxc, and the exchange correlation energy, Exc, both in Rydbergs,
! based on an input charge density given in e/bohr^3, for the
! case of a spin-unpolarized calculation.
!
! NOTE: Extra factor of two in formulas is due to conversion from
! Hartree to Rydberg!
!
! The following exchange-correlation functionals are implemented:
!
! Local density functionals:
! 1. Slater's x-alpha - J. C. Slater, Phys. Rev. 81, 385 (1951).
! 2. Wigner's interpolation - E. Wigner, Phys. Rev. 46, 1002
!           (1934).
! 3. Hedin-Lundqvist -  L. Hedin and B. I. Lundqvist, J. Phys. C,
!           4, 2064 (1971).
! 4. Ceperley-Alder - D. M. Ceperley and B. J. Alder, Phys. Rev.
!           Lett., 45, 566 (1980).
!
! Gradient-corrected functional:
! PBE - Perdew, Burke, Ernzerhof - J. P. Perdew, K. Burke, and 
!           M. Ernzerhof, Phys. Rev. Lett., 77, 3865 (1996).
!
! Asymptotically-corrected functionals:
! 1. Leeuwen-Baerends correction - Leeuwen and Baerends, 
!           Phys. Rev. 49, 2421 (1994).
! 2. Casida-Salahub correction - Casida and Salahub, J. Chem.
!           Phys., 113, 8918 (2000).
!
!---------------------------------------------------------------
subroutine exc_nspn(grid,parallel,nrep,icorr,dioniz,vxc,wvec,exc)

  use constants
  use grid_module
  use parallel_data_module
  use dbuffer_module
  use stencil_things
  use psum_module
  use gradmvs_module
  use laplacian_ops_module, only : laplacian_fold
  use pbe_module, only : pbe, pw91, gcor2 
  implicit none
  !
  ! Input/Output variables:
  !
  ! grid related data
  type (grid_data), intent(in) :: grid
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel

  ! correlation type
  character (len=2), intent(in) :: icorr
  ! ionization energy difference
  ! (used only if the correlation is of type cs)
  real(dp), intent(in) :: dioniz
  ! order of the reduced group
  integer, intent(in) :: nrep
  ! output exchange-correlation potential
  real(dp), intent(out) :: vxc(parallel%mydim)
  ! work array
  real(dp), intent(out) :: wvec(parallel%nwedge + 1)
  ! total exchange-correlation energy
  real(dp), intent(out) :: exc
  !
  ! Work variables:
  !
  ! multiplicity of grid points in irreducible wedge (equal to
  ! order of the reduced group)
  real(dp) :: weight

  ! GGA variables:
  ! quantities fed to pbe.f:
  ! gradient - grad(n), where n is the charge density
  ! absgrad  - |grad(n)|
  ! gradgrad - components of grad(|grad(n)|
  ! laplac - laplacian(n)
  ! prod  -  grad(n) dot grad(|grad(n)|
  real(dp), dimension(:), allocatable :: absgrad,laplac
  real(dp), dimension(:,:), allocatable :: gradient,gradgrad
  real(dp) :: prod 

  ! quantitites read from pbe.f:
  ! expbe,vxuppbe,vxdnpbe - exchange enregy and (up and down)
  ! potentials
  ! ecpbe,vcuppbe,vcdnpbe - correlation enregy and (up and down)
  ! potentials
  real(dp) :: expbe,vxuppbe,vxdnpbe,vcuppbe,vcdnpbe,ecpbe
  ! equivalent quantities for pw91
  real(dp) :: expw91,vxpw91,ecpw91,vcuppw91,vcdnpw91

  ! LDA variables:
  ! various recurring parameters in the exchange-correlation
  ! formulas: 
  ! quantities common to all local density expressions:
  ! rs is the local value of the Wigner-Seitz radius
  ! rho temporarily stores the charge at a given grid point
  real(dp) :: a0, twovpia0, p75vpi, alpha, rs, rho
  ! Wigner parameters:
  real(dp), parameter :: aw = -0.875529d0 , bw = 7.8d0
  ! Hedin-Lundqvist parameters:
  real(dp), parameter :: ah = 1.d0/21.d0, ch = 0.045d0
  real(dp) :: x 
  ! Ceperley-Alder parameters
  real(dp), parameter :: g =-0.2846d0, b1 = 1.0529d0
  real(dp), parameter :: b2 = 0.3334d0, c1 = 0.0622d0
  real(dp), parameter :: c2 = 0.096d0, c3 = 0.004d0
  real(dp), parameter :: c4 = 0.0232d0,c5 = 0.0192d0
  real(dp) :: ec, sqrs, eurs
  ! Asymptotic corrections parameters and temporary variables
  real(dp), parameter :: betalb = 0.05d0
  real(dp) :: ac1, ac2 
  real(dp) :: abstemp, corrlb, asinhx

  ! actual number of grid points
  integer ndim
  ! allocation check
  integer alcstat
  ! temporary variables
  real(dp), dimension (3) :: temp1,temp2
  real(dp) :: vxctmp !< threadprivate temp variable instead of using array
  ! counters
  integer i 

  ! communication buffer for lap/grad
!  type (lap_buffer) :: lap_buf
    type (fold_buffer) :: fold_buf
  ! laplacian definition working copy (we strip symmetry in the lap/grad)
!  type (stencil_definitions) :: sten_def
  
  !---------------------------------------------------------------

  ! initialize arrays:

  ndim = parallel%mydim
  weight = real(nrep,dp)

  allocate(gradient(3,ndim),stat=alcstat)
  call alccheck('gradient',3*ndim,alcstat)
  allocate(absgrad(ndim),stat=alcstat)
  call alccheck('absgrad',ndim,alcstat)
  allocate(gradgrad(3,ndim),stat=alcstat)
  call alccheck('gradgrad',3*ndim,alcstat)
  allocate(laplac(ndim),stat=alcstat)
  call alccheck('laplac',ndim,alcstat)

  ! and some more constants:
  a0 = (four/(nine*pi))**third
  twovpia0 = two/(pi*a0)
  p75vpi = 0.75d0/pi
  !
  ! initialize the total exchange-correlation energy to zero
  !
  exc = zero

  ! grab the laplacian definitions
  !sten_def = grid%sten_def


  if (icorr == 'pw' .or. icorr == 'pb') then

!Initialize lap buffers for communications {{{ 
   if (parallel%group_size > 1 ) then
  ! call init_lap_buffer(lap_buf)
  ! call allocate_lap_buffer(lap_buf,parallel)
  call fold_buf%init()
  call fold_buf%alloc(parallel,foldvol=grid%sten_coeff%foldsize)
   endif
!}}}
     ! calculate the gradient and the Laplacian of the charge density
     ! at each grid point
 !call laplacian(parallel,sten_def,lap_buf,vxc,laplac)
 call laplacian_fold(parallel,grid%sten_coeff,fold_buf,vxc,laplac)

    if (parallel%group_size > 1 ) then !cleanup
!    call destroy_lap_buffer(lap_buf)
    call fold_buf%destroy()
    endif
     laplac = -laplac
! maybe -      call daxpy instead
  !AJB: need to implement gradient with external comm buffers here
     call gradmvs(grid,parallel,vxc,gradient,grid%coe1,grid%norder, &
          wvec)
     do i = 1,ndim
        temp1 = gradient(:,i)
        absgrad(i) = sqrt(dot_product(temp1,temp1))
     enddo

     ! calculate other input quantities and then calculate the 
     ! exchange-correlation

     ! calculate grad(rho)_dot_grad|grad(rho)| and
     ! calculate the exchange-correlation value using pbe
     exc = zero
     call gradmvs(grid,parallel,absgrad,gradgrad,grid%coe1, &
          grid%norder,wvec)

     if (icorr == 'pb') then
        ! using PBE - a gradient-corrected functional
        do i = 1,ndim
           temp1 = gradient(:,i)
           temp2 = gradgrad(:,i)
           prod = dot_product(temp1,temp2)
           call pbe(vxc(i),absgrad(i),prod,laplac(i), &
                expbe,vxuppbe,vxdnpbe,ecpbe,vcuppbe,vcdnpbe)
           exc=exc+vxc(i)*two*(expbe+ecpbe)*weight
           vxc(i)=vxuppbe+vxdnpbe+vcuppbe+vcdnpbe
        enddo

     elseif (icorr == 'pw') then
        ! using PW91 - a gradient-corrected functional
        do i = 1,ndim
           temp1 = gradient(:,i)
           temp2 = gradgrad(:,i)
           prod = dot_product(temp1,temp2)
           call pw91(vxc(i),absgrad(i),prod,laplac(i), &
                expw91,vxpw91,ecpw91,vcuppw91,vcdnpw91)
           exc=exc+vxc(i)*two*(expw91+ecpw91)*weight
           vxc(i)=two*vxpw91+vcuppw91+vcdnpw91
        enddo
     endif

  else if (icorr == 'xa') then
     ! x-alpha correlation
   
     alpha = one
     ! Note: alpha = 2/3 is pure exchange
     write(7,10) alpha
10   format(' performed x-alpha correlation with alpha = ',f6.3)

     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then
           rs = (p75vpi/rho)**third
           vxc(i) = -1.5d0*twovpia0*alpha/rs
           exc = exc + 0.75d0*rho*vxc(i)*weight
        endif
     enddo

  else if (icorr == 'wi') then
     ! Wigner correlation

     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then
           rs = (p75vpi/rho)**third
           vxc(i) = -twovpia0/rs
           exc = exc + 0.75d0*rho*vxc(i)*weight + rho*aw/(rs + bw)
           vxc(i) = vxc(i) + aw*(four*rs*third+bw)/((rs+bw)*(rs+bw))
        endif
     enddo

  else if (icorr == 'hl') then
     ! Hedin-lundqvist exchange-correlation

     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then
           rs = (p75vpi/rho)**third
           vxc(i) = -twovpia0/rs
           exc = exc + 0.75d0*rho*vxc(i)*weight
           x = rs*ah
           alpha = log(one+one/x)
           vxc(i) = vxc(i) - ch*alpha
           exc = exc - rho*ch*((one+x*x*x)*alpha+x*half-x*x-third)*weight
        endif
     enddo

  else if (icorr == 'ca') then
     ! Ceperly-Alder exchange correlation

     !!$OMP PARALLEL DO SIMD REDUCTION(+:exc) DEFAULT(FIRSTPRIVATE)&
     !!$OMP& SHARED(vxc)
     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then
           rs = (p75vpi/rho)**third
           vxctmp = -twovpia0/rs
           exc = exc + 0.75d0*rho*vxctmp*weight
           if (rs >= one) then
              sqrs = sqrt(rs)
              ec = g/(one + b1*sqrs + b2*rs)
              vxc(i) = vxctmp + ec*ec* &
                   (one+3.5d0*b1*sqrs*third+four*b2*rs*third)/g
           else
              alpha = log(rs)
              ec = c1*alpha - c2 + (c3*alpha - c4)*rs
              vxc(i) = vxctmp + ec - (c1 + (c3*alpha - c5)*rs)*third
           endif
           exc = exc + rho*ec*weight
        endif
     enddo
     !!$OMP END PARALLEL DO SIMD

  elseif (icorr == 'pl') then
     ! Perdew-Wang local exchange correlation
     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then
           rs = (p75vpi/rho)**third
           vxc(i) = -twovpia0/rs
           exc = exc + 0.75d0*rho*vxc(i)*weight
           sqrs=sqrt(rs)
           call gcor2(0.0310907d0,0.21370d0,7.5957d0,3.5876d0,1.6382d0, &
                0.49294d0,sqrs,ec,eurs)
           vxc(i) = vxc(i) + two*( ec -rs*eurs/three )
           exc = exc + rho*ec*weight*two
        endif
     enddo

  else if (icorr == 'lb' .or. icorr == 'cs') then
     ! Asymptotically corrected Ceperly-Alder exchange correlation

     ! define parameters
     ac1=two**third
     ac2=four/three

     ! calculate 2^(1/3) * |grad(rho)|/rho^(4/3)
     call gradmvs(grid,parallel,vxc,gradient,grid%coe1,grid%norder,wvec)
     do i = 1,ndim
        temp1 = gradient(:,i)
        abstemp = sqrt(dot_product(temp1,temp1))
        if (vxc(i) > zero) then
           absgrad(i)=ac1*abstemp/(vxc(i)**ac2)
        endif
     enddo

     ! compute exchange-correlation potential and energy
     do i=1,ndim
        rho = vxc(i)
        vxc(i) = zero
        if (rho > zero) then

           ! compute Ceperely-Alder term
           rs = (p75vpi/rho)**third
           vxc(i) = -twovpia0/rs
           exc = exc + 0.75d0*rho*vxc(i)*weight
           if (rs >= one) then
              sqrs = sqrt(rs)
              ec = g/(one + b1*sqrs + b2*rs)
              vxc(i) = vxc(i) + ec*ec*(one+3.5d0*b1*sqrs*third + &
                   four*b2*rs*third)/g
           else
              alpha = log(rs)
              ec = c1*alpha - c2 + (c3*alpha - c4)*rs
              vxc(i) = vxc(i) + ec - (c1 + (c3*alpha - c5)*rs)*third
           endif
           exc = exc + rho*ec*weight

           ! Compute Leeuwen-Baerends correction to the potential.
           abstemp = absgrad(i)
           asinhx = log(abstemp+sqrt(abstemp*abstemp+one))
           corrlb = two*betalb*(rho**third)/ac1*abstemp*abstemp/ &
                (one + three*betalb*abstemp*asinhx)

           ! If correcting for the ionization energy difference, shift the
           ! correlation energy.
           if (icorr == 'cs') then
              if (corrlb > dioniz) corrlb = dioniz
           endif
           vxc(i) = vxc(i) - corrlb
        endif
     enddo
  endif
  !
  ! Scale the total energy integral by h^3 (factor necessary due to the
  ! expression of an integral as a summation over grid points) and
  ! sum it up over processors.
  !
  call psum(exc,1,parallel%group_size,parallel%group_comm)
  exc  = exc * (grid%hcub)


  deallocate(laplac)
  deallocate(absgrad)
  deallocate(gradient)
  deallocate(gradgrad)

end subroutine exc_nspn
!===============================================================
end module exc_module
