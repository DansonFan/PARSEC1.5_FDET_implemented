module io_module
  use prandom_module, only: K_RANGEN_USE_DEFAULT
! IO options
   integer, parameter :: k_io_none_out = 0 
   integer, parameter :: k_io_parsecdat_out = 1
   integer, parameter :: k_io_ascii_out = 2
   integer, parameter :: k_io_hdf5_out = 3
   type inputs_data
      logical :: enable_data_out           = .true.
      logical :: calculate_force           = .TRUE.
      logical :: use_old_forces            = .true.
      logical :: redirect_timings          = .false.
      logical :: output_ascii_data         = .false.
      logical :: enable_per_process_file   = .true.
      logical :: enable_process_binning    = .true.
      logical :: print_unconverged_density = .false.
      integer :: vecgen_rng_type           = K_RANGEN_USE_DEFAULT
      logical :: use_scalapack             = .true.
      logical :: use_hdf5                  = .false.
      contains
      procedure :: bcast => bcast_inputs
   endtype inputs_data
contains
   subroutine bcast_inputs(inputs, masterid, comm, mpinfo)
#ifdef WITH_MPI_F08
      use mpi_f08
#elif defined(MPI)
      use mpi
#endif
      class(inputs_data), intent(inout) :: inputs
#ifdef WITH_MPI_F08
      type(mpi_comm), intent(in) :: comm !< actual mpi_comm
#else
      integer, intent(in) :: comm !< integer mpi_comm
#endif
      integer, intent(in) :: masterid !< mpi_rank
      integer, intent(out) :: mpinfo !< error code

      call MPI_BCAST(inputs%enable_data_out,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%calculate_force,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%use_old_forces,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%redirect_timings,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%enable_per_process_file,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%enable_process_binning,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%print_unconverged_density,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%output_ascii_data,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%vecgen_rng_type,1,MPI_INTEGER,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%use_scalapack,1,MPI_LOGICAL,masterid,comm,mpinfo)
      call MPI_BCAST(inputs%use_hdf5,1,MPI_LOGICAL,masterid,comm,mpinfo)
   end subroutine bcast_inputs
  !===============================================================
  !
  ! Copyright (C) 2005 Finite Difference Research Group
  ! This file is part of parsec, http://www.ices.utexas.edu/parsec/
  !
  ! Read in user parameters from parsec.in.
  !
  !---------------------------------------------------------------
  subroutine usrinput(clust,band_st,elec_st,grid,pot,p_pot,mol_dynamic,pbc,mixer, &
       solver,rritz,move,istart,mxiter,vconv,vconv_approach,npolflg,field,outflag, &
       ipr,export_griddata_flag,chsym,ngroups,nnodes,wstrt,nscf,outevflag,readwfndat, &
       ignoresym,outputgw,enable_data_out,file_id, inputs, tests, ierr)
  
    use constants
    use rritz_data_module
    use file_units
    use cluster_module
    use electronic_struct_module
    use grid_module
    use potential_module
    use pseudo_potential_module
    use molecular_dynamic_module
    use pbc_module
    use mixer_module
    use eigen_solver_module
    use movement_module
    use bandstruc_module
    use nscf_module
    use aux, only : myflush, matvec3, mtrxin, custom_date_time, mysecond
    use esdf
    use test_module
#ifdef USEHDF5
    use hdf5
#endif
#ifdef OMPFUN
    use omp_lib
#endif
    implicit none
    !
    ! Input/Output variables:
    !
    ! the cluster
    type(cluster), intent(inout) :: clust
    ! band structure
    type(bandstruc), intent(inout) :: band_st
    ! electronic structure
    type(electronic_struct), intent(inout) :: elec_st
    ! grid related data
    type(grid_data), intent(inout) :: grid
    ! potential related data
    type (potential), intent(inout) :: pot
    ! pseudopotential related data
    type(pseudo_potential), intent (inout) :: p_pot
    ! molecular dynamic related data
    type(molecular_dynamic), intent (inout) :: mol_dynamic
    ! periodic boundary conditions data
    type(pbc_data), intent (inout) :: pbc
    ! mixer related data
    type(mixer_data), intent (inout) :: mixer
    ! solver related data
    type(eigen_solver), intent (inout) :: solver
    ! rayleight ritz related data
    type(rritz_data), intent (inout) :: rritz
    ! movement data
    type(movement), intent (inout) :: move
    ! non selfconsistent data
    type(nscf_data), intent(inout) :: nscf
    ! input data from usrinput, for options etc
    type(inputs_data), intent(inout) :: inputs
    ! test data for instrumenting internal tests
    type(tests_data), intent(inout) :: tests
  
    ! restart flag
    integer, intent(out) :: istart
    ! maximal # of iterations
    integer, intent(out) :: mxiter
    ! convergence criterion
    real(dp), intent(out) :: vconv
    ! convergence criterion approaching
    real(dp), intent(out) ::  vconv_approach
    ! polarizability flag
    integer, intent(out) :: npolflg
    ! polarizability field
    real(dp), intent(out) :: field
    !
    ! output flag for writing parsec.dat file:
    ! mod(outflag,2) = 1 : write all calculated wave functions 
    ! mod(outflag,2) = 0 : write only the ones for occupied states
    ! mod(outflag/2,2) = 1 : write parsec.dat only after SCF is finished
    ! mod(outflag/2,2) = 0 : write parsec.dat between steps of SCF loop
    !
    integer, intent(out) :: outflag
    !
    ! output flag for additional info in parsec.out
    ! default is ipr = 0 (only basic output); higher values will
    ! cause additional information to be printed out
    ! ipr >= 1 : print out local/non-local components of force and
    !              initial eigenvalues
    ! ipr >= 2 : print out all symmetry data and additional arpack output
    ! ipr >= 3 : print out more BFGS output
    ! ipr >= 4 : print out all BFGS output
    ! ipr >= 5 : print out all g-stars (warning: _lots_ of data)
    ! ipr >= 6 : print out local potentials (warning: _lots_ of data)
    !
    integer, intent(out) :: ipr
    ! output flag for exporting of grid data to external files
    ! (size matches definition in def.h)
    integer, intent(inout) :: export_griddata_flag(MAX_EXPORT_OPTS)
    ! flag for symmetrization of charge density
    logical, intent(out) :: chsym
  
    ! number of groups of processors
    integer, intent(out) :: ngroups
  
    ! number of processors
    integer, intent(in) :: nnodes
  
    ! starting time
    real(dp), intent(inout) :: wstrt
  
    logical, intent(out) :: readwfndat
    !
    ! output flag for writing eigen.dat file:
    ! mod(outevflag,2) = 0 : write all calculated eigenvalues in eigen.dat
    ! mod(outevflag,2) = 1 : write only the ones for occupied states
    ! mod((outevflag-1)/2,2) = 0 : write eigen.dat only after SCF is finished
    ! mod(outevflag/2,2) = 1 : write eigen.dat between steps of SCF loop
    !
    integer, intent(out) :: outevflag
    ! true if all symmetry should be ignored
    logical, intent(out) :: ignoresym
  
    ! flag for GW
    logical, intent(out) :: outputgw
    ! flag for data output
    logical, intent(out) :: enable_data_out
  
    ! error flag; 100 < ierr < 201
    integer, intent(out) :: ierr
    !
    ! Work variables:
    !
    ! counters
    integer ity, i, itmp, ilow, iup, jj, i1, i2, i3
    real(dp) :: dtmp, tmp
    ! dummy number
    integer ntmp
  
    ! spin number
    integer nspin
    ! correlation type
    character (len=2) :: icorr
    ! ionization energy difference, used with cc correlation only
    real(dp) :: dioniz
    ! electron temperature (in Kelvin), tfermi
    ! [fixed occupations flag if negative]
    real(dp) :: tfermi
    ! string flag
    character (len=60) ::  strflag, shapeflag
    ! string with local components of pseudopotential
    character (len=1) :: locstr
    ! flag for selecting which atoms are allows to move
    ! flag is used for constructing mvat only.
    ! flag is NOT passed to the main code
    integer nslctflg
    ! default values for the different types
    !integer integer_default
    !real(dp) ::  double_default
    !character string_default
    !logical boolean_default
  
    ! boundary sphere size (atomic units) - for confined systems
    ! (zero boundary condition)
    real(dp) :: rmax
    ! parameters for describing the domain shape
    ! in zero boundary conditions
    ! these parameters are copied to grid at the end
    integer :: domain_shape
    real(dp), dimension(3) :: d_shape_param
    integer, dimension(1) :: i_shape_param
  
    ! scale used for atomic coordinates
    real(dp) :: cscale(3,3),vtmp(3),lattvec(3,3)
    ! grid spacing (atomic units)
    real(dp) :: h
    ! net charge in the system (in units of electron charge)
    real(dp) ncharge
    ! number of different atom types
    integer naty
    ! total actual number of atoms (from all types combined)
    ! used as counter during atom coordinate read-in 
    integer natom,natm
    ! number of replicas of unit cell in a super-cell calculation
    integer :: supercell(3)
    ! amount of vacuum in super-cell
    integer :: cell_vac(3)
  
    ! number of lines in block data
    integer nlines
    ! number of states
    integer nstate
    ! order of finite difference expansion
    integer norder
    integer, parameter :: mxorder = 20
  
    logical istart_tmp
    logical npolflg_tmp
    logical so_start
    logical modify_rmax
  
    logical do_vdw
    integer :: hirsh_cell_one , hirsh_cell_two , hirsh_cell_three
    integer :: hirsh_cell_total(1,3)
    real(dp) :: stpmax
  
    logical lflag, outputallstates
  
    ! temporary arrays for atom information
    integer, parameter :: maxatm = 100000
    integer, allocatable :: tmove(:)
    integer, allocatable :: atype(:)
    real(dp), allocatable :: acoord(:,:)
    real(dp), allocatable :: initmag(:,:)
  
    ! default pseudopotential file name
    character (len=90) :: default_ppfile
  
    ! point charge variables
    ! number of point charge types
    integer :: npttyp  
    ! number of point charges
    integer :: nptchrg
    ! counter
    integer :: ipttyp
    ! charged sheet variables
    ! number of charged sheet types
    integer :: number_charged_sheet_type
    ! number of charged sheets
    integer :: number_charged_sheets
    ! counter
    integer :: icharged_sheet_type
  
    ! name of main output file
    character (len=200) :: parsec_out_filename
    ! date label
    character (len=26) :: datelabel
#ifdef USEHDF5
    integer(hid_t), intent(in) :: file_id
    integer(hid_t) :: filetype, space, dset
    integer, parameter :: lenline = 200
    character(len=lenline), dimension(:), allocatable :: cml
    INTEGER(HSIZE_T), DIMENSION(1:1) :: dims
    INTEGER(HSIZE_T), DIMENSION(2) :: data_dims
    INTEGER(HSIZE_T), DIMENSION(:), ALLOCATABLE :: str_len
    CHARACTER(LEN=20) :: dataset
    integer :: hdferr, linenumber, fileflag
#else
    integer, intent(in) :: file_id 
#endif
    ! Array for the esdf_split function (llength defined in esdf module)
    character(len=llength) :: flag_words(MAX_EXPORT_OPTS)

    character(32) :: format_buffer
    interface
       character(16) function build_gitcommit()
       end function
    end interface
    interface
       character(1024) function build_config()
       end function
    end interface
    interface
       character(2000) function build_defines()
       end function
    end interface
    interface
       character(2000) function build_flags()
       end function
    end interface
    interface
       character(6000) function build_line()
       end function
    end interface
  
    !---------------------------------------------------------------
  
    ! initializing default values
    integer, parameter :: integer_default = 0
    real(kind=dp), parameter :: double_default = zero
    character, parameter :: string_default = ' '
    logical, parameter :: boolean_default = .false.
  
    allocate(tmove(maxatm))
    allocate(acoord(3,maxatm))
    allocate(atype(maxatm))
  
#ifdef USEHDF5
    ! read in entire file
    open(unit=3,file='parsec.in',status='old')
    linenumber=1
    fileflag = 0
    do while (fileflag == 0)
            read(3,'(a)',iostat=fileflag)
            write(*,'(a)')
            if(fileflag==-1) exit
            linenumber = linenumber + 1
    enddo
    rewind(unit=3)
    dims = linenumber
    data_dims = (/lenline, linenumber/)
    allocate(cml(linenumber))
    allocate(str_len(linenumber))
    str_len = lenline
    linenumber=1
    fileflag = 0
    do while (fileflag == 0)
            read(3,'(a)',iostat=fileflag) cml(linenumber)
            write(*,'(a)') cml(linenumber)
            if(fileflag==-1) exit
            linenumber = linenumber + 1
    enddo
    close(3)
    ! creating our own kind of string here, I suppose?
    CALL H5Tcopy_f(H5T_STRING, filetype, hdferr)
    ! modifying it to pad a certain kind of way
    CALL H5Tset_strpad_f(filetype, H5T_STR_NULLPAD_F, hdferr)
    CALL h5screate_simple_f(1, dims, space, hdferr)
    CALL h5dcreate_f(file_id, "parsec.in", filetype, space, dset, hdferr)
    CALL h5dwrite_vl_f(dset, filetype, cml, data_dims, str_len, hdferr, space)
    CALL h5dclose_f(dset , hdferr)
    CALL H5Tclose_f(filetype, hdferr)
    CALL h5sclose_f(space, hdferr)
#endif
    
  
    ! initialize error flag
    ierr = 0
  
    ! initialization of domain_shape parameters for cluster calculations
    domain_shape = 0
    d_shape_param = zero
    i_shape_param = 0
  
    ! User parameter input from file 'parsec.in'
    ! Progress output written into 'parsec.out' (this name can be
    ! modified by the user)
    call esdf_init ('parsec.in')
  
    ! Initialize output:
    parsec_out_filename = esdf_string('Output_File_Name','parsec.out')
    open(f_parsec,file=trim(parsec_out_filename),form='formatted')  
    write(f_parsec,*)
    write(f_parsec,*) ('=',i=1,65)
    write(f_parsec,*)
    write(f_parsec,*) ' PARSEC 1.5.0 - Real-space DFT Program'
    write(f_parsec,*) ' Highly experimental, not for production runs !!'
    write(f_parsec,*) ' '
    ! Pack in the build details to the parsec.out file, so have some idea in the
    ! future of what was used to generate the files. In between the GIT number
    ! mach file, and defines, we should have a pretty good idea of what was
    ! underpinning this
    write(f_parsec,*) ' begin BUILD_DETAILS '
    write(format_buffer,'("(A17,A",I03,")")') len(trim(build_gitcommit()))
    write(f_parsec,format_buffer) ' git commit  : ',trim(build_gitcommit())
    write(format_buffer,'("(A17,A",I03,")")') len(trim(build_config()))
    write(f_parsec,format_buffer) '  config file  : ',trim(build_config())
    write(format_buffer,'("(A17,A",I03,")")') len(trim(build_flags()))
    write(f_parsec,format_buffer) '  flags        : ',trim(build_flags())
    write(format_buffer,'("(A17,A",I04,")")') len(trim(build_defines()))
    write(f_parsec,format_buffer) '  defines      : ',trim(build_defines())
    write(format_buffer,'("(A17,A",I04,")")') len(trim(build_line()))
    write(f_parsec,format_buffer) '  line         : ',trim(build_line())
    write(f_parsec,*) ' end BUILD_DETAILS '
#ifdef MPI
    write(f_parsec,*) ' parallel run - using ', nnodes,' PEs '
#else
    write(f_parsec,*) ' serial run, no MPI interface'
#endif
#ifdef OMPFUN
    write(f_parsec,*) ' OMP enabled. Max. Threads/PE: ',OMP_GET_MAX_THREADS()
    write(f_parsec,*)  ""
    write(f_parsec,*)  " My Task grain number is ", GRAIN_DIV
    write(f_parsec,*)  ""
#endif
#ifdef OMPFUN
  ! AJB: probably(!) want to fix this -  https://gcc.gnu.org/onlinedocs/gfortran/OpenMP-Modules-OMP_005fLIB-and-OMP_005fLIB_005fKINDS.html
    write(f_parsec,*) ' DEBUG: Runtime OMP thread affinity set to ',OMP_GET_PROC_BIND()
    write(f_parsec,*) ' where...'
    write(f_parsec,*)  "  false state stat ="  , omp_proc_bind_false
    write(f_parsec,*)  "  true  state stat ="   , omp_proc_bind_true
    write(f_parsec,*) ' alternatively...'
    write(f_parsec,*)  "  master   binding =" , omp_proc_bind_master
    write(f_parsec,*)  "  close    binding ="  , omp_proc_bind_close
    write(f_parsec,*)  "  spread   binding =" , omp_proc_bind_spread
#endif
#ifndef SCRAMBLE_TIMING
    call custom_date_time(datelabel,wstrt)
    write(f_parsec,'(/,a,a,a,/)') '  starting run on ',datelabel,' UTC'
#else
    write(f_parsec,*) '       TIMING DATA IS SCRAMBLED        '
#endif
    write(f_parsec,*) ('=',i=1,65)
    write(f_parsec,*)
    call myflush(f_parsec)
  
  
    !> read in restart flag: 
    !! .false. for initial run, .true. for restaring from parsec.dat
    istart_tmp = esdf_boolean ('Restart_run', boolean_default)
    if (istart_tmp) then
       istart = 1
       write(f_parsec,*) ' Restarted Run - from parsec.dat'
    else
       istart = 0
       write(f_parsec,*) 'Initial Run - starting from atomic potentials'
    endif

    itmp = -1
    solver % rng_seed = esdf_integer('vector_rng_seed', itmp)
    if(solver % rng_seed == itmp)then
       write(f_parsec,*) '**Vector Seed Randomized'
       call mysecond(dtmp)
       solver % rng_seed = int(dtmp)
    else
       write(f_parsec,*) '**Vector Seed Specified'
    endif
    write(f_parsec,*) 'Vector Seed: ', solver % rng_seed

    inputs % vecgen_rng_type = esdf_integer('vector_rng_type', inputs % vecgen_rng_type)
    write(f_parsec,*) 'RNG Type: ', inputs % vecgen_rng_type
  
    !> specify wfn.dat as restarting file
    readwfndat = esdf_boolean ('Restart_from_wfndat', boolean_default)
    if (readwfndat) then
       write(f_parsec,*) ' WARNING! Restarting from file parsec.dat '
       write(f_parsec,*) ' You should think seriously about ','upgrading source code!'
    endif
  
    !> should symmetry be ignored
    ignoresym = esdf_boolean ('Ignore_Symmetry', boolean_default)
       write(f_parsec,*) 'input ignore_symmmetry=',ignoresym
     !> \note AJB: easy switching off of symmetry for debug:
     ignoresym = .TRUE.
       write(f_parsec,*) ' WARNING! SYMMETRY IS AUTOMATICALLY SWITCHED OFF'
    
    !> read in Langevin molecular dynamics flag 
    mol_dynamic%is_on = esdf_boolean ('Molecular_Dynamics',boolean_default)
  
    h = esdf_physical ('Grid_Spacing',double_default,'bohr')
    if (h == double_default) then
       write(f_parsec,*) 'ERROR: specification of grid spacing not found! '
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 112
       return
    endif
    write(f_parsec,*)
    ! read in boundary condition type 
    write(f_parsec,*) 'Grid data:'
    write(f_parsec,*) '~~------~~'
    write(f_parsec,*)
  
    !> read in (boundary sphere size / side of box), and grid spacing
    strflag = esdf_reduce(esdf_string('Boundary_Conditions','cluster'))
    select case(trim(strflag))
    case ('cluster','0d')
       pbc%per = 0
       pbc%ealpha = 0
       pbc%is_on = .false.
       elec_st%nkpt=0
    
    case ('wire','tube','1d')
       pbc%per = 1
       pbc%ealpha = 0
       pbc%is_on = .true.
    case ('slab','2d')
       pbc%per = 2
       pbc%ealpha = 0
       pbc%is_on = .true.
    case ('bulk','3d','pbc')
       pbc%per = 3
       pbc%ealpha = 0
       pbc%is_on = .true.
    case default
       write(f_parsec,'(/,a,a)') ' ERROR IN BOUNDARY CONDITIONS! STOP. ',strflag
       ierr = 101
       return
    end select
#if defined(INPUT_TRACE)
    write(f_parsec,*) ' PERIODIC DETECTION ' 
#endif

    select case(pbc%per)
    case (3)
#if defined(INPUT_TRACE)
    write(f_parsec,*) 'pbc%per',pbc%per
#endif
#if defined USEFFTW2 || defined USEFFTW3
#if defined(INPUT_TRACE)
    write(f_parsec,*) ' INPUT_TRACE: USING FFTW3 IN INPUT? '
#endif
       if (esdf_block('Cell_Shape',nlines)) then
          if ( nlines == 1) then
             write(f_parsec,*) ' Assume orthorhombic periodic cell'
             pbc%latt_vec = zero
             read (block_data(1),*,iostat=ierr) (pbc%latt_vec(i,i),i=1,3)
             goto 30
             !that's so mature guys.
          endif
          if ( nlines /= 3) then
             write(f_parsec,*) 'ERROR: there should be 1 or 3 lines instead of ', nlines
             write(f_parsec,*) 'in the "Cell_Shape" block for 3D PBC'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 102
             return
          endif
          do i = 1, nlines
             read (block_data(i),*,iostat=ierr) pbc%latt_vec(:,i)
          enddo
  30      continue
          if (ierr /= 0) then
             write(f_parsec,*) 'ERROR: bad specification of "Cell_Shape" '
             write(f_parsec,*) ' block for periodic system! '
             write(f_parsec,'(10(a,/))') block_data(1:nlines)
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 103
             return
          endif
       else
          write(f_parsec,*) 'ERROR: specification of "Cell_Shape" block'
          write(f_parsec,*) ' for periodic system not found! '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 104
          return
       endif
       dtmp = esdf_physical ('Lattice_Vector_Scale',one,'bohr')
       pbc%latt_vec = dtmp * pbc%latt_vec
       rmax = one
#else
       write(f_parsec,*) 'ERROR! Periodic boundary conditions are input '
       write(f_parsec,*) 'in parsec.in but this executable does not seem '
       write(f_parsec,*) 'to have support for FFTW. Stop. Hammer time.'
       ierr = 105
       return
#endif
    case (2)
#if defined(INPUT_TRACE)
    write(f_parsec,*) 'pbc%per',pbc%per
#endif
       if (esdf_block('Cell_Shape',nlines)) then
          if ( nlines /= 2) then
             write(f_parsec,*) 'ERROR: there should be 2 lines instead of ',nlines
             write(f_parsec,*) 'in the "Cell_Shape" block'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 106
             return
          endif
          pbc%latt_vec = zero
  do i = 1, nlines
     read (block_data(i),*,iostat=ierr) pbc%latt_vec(:,i)
  enddo
          if (ierr /= 0) then
             write(f_parsec,*) 'ERROR: bad specification of "Cell_Shape" '
             write(f_parsec,*) ' block for periodic system! '
             write(f_parsec,'(10(a,/))') block_data(1:nlines)
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 107
             return
          endif
       else
          write(f_parsec,*) 'ERROR: specification of "Cell_Shape" block'
          write(f_parsec,*) ' for slab system not found! '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 108
          return
       endif
  
       dtmp = esdf_physical ('Lattice_Vector_Scale',one,'bohr')
       pbc%latt_vec = dtmp * pbc%latt_vec
  
       rmax = esdf_physical ('Boundary_Sphere_Radius',double_default,'bohr')
       if (rmax == double_default) then
          write(f_parsec,*) 'ERROR: specification of boundary length for'
          write(f_parsec,*) ' non-periodic direction not found! '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 109
          return
       endif
  
    case (1)
#if defined(INPUT_TRACE)
    write(f_parsec,*) 'pbc%per',pbc%per
#endif
       if (esdf_block('Cell_Shape',nlines)) then
          if ( nlines /= 1) then
             write(f_parsec,*) 'ERROR: there should be 1 line instead of ',nlines
             write(f_parsec,*) 'in the "Cell_Shape" block'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 106
             return
          endif
          pbc%latt_vec = zero
          read (block_data(1),*,iostat=ierr) pbc%latt_vec(1,1)
          if (ierr /= 0) then
             write(f_parsec,*) 'ERROR: bad specification of "Cell_Shape" '
             write(f_parsec,*) ' block for periodic system! '
             write(f_parsec,'(10(a,/))') block_data(1:nlines)
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 107
             return
          endif
       else
          write(f_parsec,*) 'ERROR: specification of "Cell_Shape" block'
          write(f_parsec,*) ' for slab system not found! '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 108
          return
       endif
       dtmp = esdf_physical ('Lattice_Vector_Scale',one,'bohr')
       pbc%latt_vec = dtmp * pbc%latt_vec
  
       rmax = esdf_physical ('Boundary_Sphere_Radius',double_default,'bohr')
       if (rmax == double_default) then
          write(f_parsec,*) 'ERROR: specification of boundary length for'
          write(f_parsec,*) ' non-periodic direction not found! '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 109
          return
       endif
    case (0)
#if defined(INPUT_TRACE)
    write(f_parsec,*) 'pbc%per',pbc%per
#endif
       shapeflag = esdf_reduce(esdf_string('Cluster_Domain_Shape','undef'))
       select case(trim(shapeflag))
       case ('sphere')
          domain_shape = 0
          rmax = esdf_physical('Boundary_Sphere_Radius',double_default,'bohr')
          d_shape_param(1) = rmax
  
          if (rmax == double_default) then
             write(f_parsec,*) 'ERROR: specification of boundary radius for'
             write(f_parsec,*) ' finite system not found! '
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
  
          if (rmax <= zero) then
             write(f_parsec,*) 'ERROR: spherical radius must be positive'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
       case ('ellipsoid')
          domain_shape = 1
          if(esdf_block('Domain_Shape_Parameters', nlines)) then
             if(nlines /= 1) then
                write(f_parsec,*) "ERROR: ellipsoidal radii should be specified"
                write(f_parsec,*) " in one line: x_radius y_radius z_radius"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             read(block_data(1),*,iostat=ierr) d_shape_param(1), &
                d_shape_param(2), d_shape_param(3)
  
             if(ierr /= 0) then
                write(f_parsec,*) "ERROR: bad specification of ellipsoidal"
                write(f_parsec,*) " boundary conditions. Should be:"
                write(f_parsec,*) " x_radius y_radius z_radius"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             if(d_shape_param(1) <= zero .or. d_shape_param(2) <= zero &
                   .or. d_shape_param(3) <= zero) then
                write(f_parsec,*) "ERROR: bad specification of ellipsoidal radii"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
          else
             write(f_parsec,*) "ERROR: A Domain_Shape_Parameters block is"
             write(f_parsec,*) " required for ellipsoidal cluster domains."
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
          rmax = maxval(d_shape_param)
       case ('cylinder')
          domain_shape = 2
          if(esdf_block('Domain_Shape_Parameters', nlines)) then
             if(nlines /= 1) then
                write(f_parsec,*) "ERROR: cylindrical boundaries should be specified"
                write(f_parsec,*) " in one line: radius length orientation"
                write(f_parsec,*) " -- orientation is 1 for x axis, 2 for y, 3 for z"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             read(block_data(1),*,iostat=ierr) d_shape_param(1), &
                d_shape_param(2), i_shape_param(1)
  
             if(ierr /= 0) then
                write(f_parsec,*) "ERROR: bad specification of cylindrical"
                write(f_parsec,*) " boundary conditions. Should be:"
                write(f_parsec,*) " radius length orientation"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             if(d_shape_param(1) <= zero) then
                write(f_parsec,*) "ERROR: bad specification of cylindrical"
                write(f_parsec,*) " radius (should be positive)"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             if(d_shape_param(2) <= zero) then
                write(f_parsec,*) "ERROR: bad specification of cylindrical"
                write(f_parsec,*) " length (should be positive)"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             if(i_shape_param(1) < 1 .or. i_shape_param(1) > 3) then
                write(f_parsec,*) "ERROR: bad specification of cylindrical"
                write(f_parsec,*) " orientation. Should be 1 for x-axis,"
                write(f_parsec,*) " 2 for y-axis, 3 for z-axis"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
          else
             write(f_parsec,*) "ERROR: A Domain_Shape_Parameters block is"
             write(f_parsec,*) " required for cylindrical cluster domains."
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
          rmax = sqrt((d_shape_param(2)/2.0d0)**2 + d_shape_param(1)**2)
       case ('box')
          domain_shape = 3
          if(esdf_block('Domain_Shape_Parameters', nlines)) then
             if(nlines /= 1) then
                write(f_parsec,*) "ERROR: box boundaries should be specified"
                write(f_parsec,*) " in one line: x_length y_length z_length"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             read(block_data(1),*,iostat=ierr) d_shape_param(1), &
                d_shape_param(2), d_shape_param(3)
  
             if(ierr /= 0) then
                write(f_parsec,*) "ERROR: bad specification of box"
                write(f_parsec,*) " boundary conditions. Should be:"
                write(f_parsec,*) " x_length y_length z_length"
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
  
             if(d_shape_param(1) <= zero .or. d_shape_param(2) <= zero &
                   .or. d_shape_param(3) <= zero) then
                write(f_parsec,*) "ERROR: bad specification of box"
                write(f_parsec,*) " dimensions.  All lengths should be positive."
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 110
                return
             endif
          else
             write(f_parsec,*) "ERROR: A Domain_Shape_Parameters block is"
             write(f_parsec,*) " required for box cluster domains."
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
          rmax = sqrt((d_shape_param(1)/2.0d0)**2 + (d_shape_param(2)/2.0d0)**2 &
                 + (d_shape_param(3)/2.0d0)**2)
       case default
          write(f_parsec,*) "WARNING: Cluster Calculation Domain Shape Unspecified"
          write(f_parsec,*) " Assuming Spherical Shape"
          domain_shape = 0
          rmax = esdf_physical('Boundary_Sphere_Radius',double_default,'bohr')
          if (rmax == double_default) then
             write(f_parsec,*) 'ERROR: specification of boundary radius for'
             write(f_parsec,*) ' finite system not found! '
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 110
             return
          endif
          d_shape_param(1) = rmax
       end select ! end of domain_shape
  
    case default
#if defined(INPUT_TRACE)
    write(f_parsec,*) 'pbc%per',pbc%per
#endif
       write(f_parsec,*) 'ERROR: unspecified boundary conditions! '
       write(f_parsec,*) 'STOP in usrinput ',pbc%per
       ierr = 111
       return
    end select
  
    ! copy the domain_shape variables to the grid structure for use later
    grid%domain_shape = domain_shape
    grid%d_shape_param = d_shape_param
    grid%i_shape_param = i_shape_param
    ! now we also set the rmax and the step
            write(f_parsec,*) "ATTENTION: rmax might change to fit grid points"
            write(f_parsec,*) "WAS - rmax:",rmax

            rmax = (ceiling(rmax/h)+one)*h
          d_shape_param(1) = rmax
    grid%d_shape_param = d_shape_param
            write(f_parsec,*) "NOW - rmax:",rmax
    call grid_set_rmax_step(rmax,h,grid)
  
    !
    ! Add parameters for super-cell.
    !
    supercell = 1
    if (esdf_block('Super_Cell',nlines)) then
       if ( nlines /= 1) then
          write(f_parsec,*) 'ERROR: there should be 1 line instead of ',nlines
          write(f_parsec,*) 'in the "Super_Cell" block'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 158
          return
       endif
       read (block_data(1),*,iostat=ierr) supercell(1:pbc%per)
       if (ierr /= 0) then
          write(f_parsec,*) 'ERROR: bad specification of "Super_Cell" '
          write(f_parsec,*) ' block for periodic system! '
          write(f_parsec,'(10(a,/))') block_data(1:nlines)
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 159
          return
       endif
       write(f_parsec,*) ' Periodic cell is being replicated according to super-cell'
       write(f_parsec,*) ' specification. Super-cell size = ',supercell(1:pbc%per)
       do i = 1, pbc%per
          pbc%latt_vec(:,i) = pbc%latt_vec(:,i) * real(supercell(i),dp)
       enddo
    endif
    !
    ! Add vacuum in super-cell.
    !
    cell_vac = 0
    if (esdf_block('Super_Cell_Vac',nlines)) then
       if ( nlines /= 1) then
          write(f_parsec,*) 'ERROR: there should be 1 line instead of ',nlines
          write(f_parsec,*) 'in the "Super_Cell_Vac" block'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 160
          return
       endif
       read (block_data(1),*,iostat=ierr) cell_vac(1:pbc%per)
       if (ierr /= 0) then
          write(f_parsec,*) 'ERROR: bad specification of "Super_Cell_Vac" '
          write(f_parsec,*) ' block for periodic system! '
          write(f_parsec,'(10(a,/))') block_data(1:nlines)
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 161
          return
       endif
       write(f_parsec,*) ' Vacuum is added to super-cell'
       write(f_parsec,*) ' amount of vacuum space = ',cell_vac(1:pbc%per)
       do i = 1, pbc%per
          pbc%latt_vec(:,i) = pbc%latt_vec(:,i) * ( one + real(cell_vac(i),dp) )
       enddo
    endif
    !
    ! Add 1 to the diagonal part of pbc%latt_vec for non-periodic directions.
    !
    do i = pbc%per + 1, 3
       pbc%latt_vec(i,i) = one
    enddo
  
    !
    ! Define grid shift:
    ! Non-periodic directions : shift = 0.5;
    ! Periodic directions orthogonal to all others: shift = 0.5;
    ! Periodic directions non-orthogonal to some other direction: shift = zero.
    !
    !> \note AJB: wrote this more explicitly to appease the O2/O1 level on ifort16
    if(ignoresym) then 
        grid%shift = zero !> \note AMIR - this should be checked !!!!!!!
    else
        grid%shift = half
    endif
  
    ! AJB: override to specify a shift via input
       if (esdf_block('Grid_Shift',nlines)) then
             write(f_parsec,*) '   Grid Shift is read from input. This has untested consequences!'
          if ( nlines /= 1) then
             write(f_parsec,*) 'Warning: Grid_Shift only needs one line'
             write(f_parsec,*) 'Taking only the first line in the block'
          endif
             read (block_data(1),*,iostat=ierr) (grid%shift(i),i=1,3)
             grid%shift=abs(grid%shift)
      endif
  
    lattvec = matmul(transpose(pbc%latt_vec),pbc%latt_vec)
    do i1 = 1, pbc%per
       do i2 = 1, pbc%per
          if ( (i1 /= i2)) then
              if (abs(lattvec(i1,i2)) > zero) then
               grid%shift(i1) = zero
  !             write(f_parsec,*) ' Will not grid shift based on directions', i1, i2
           else
               !write(f_parsec,*) ' Will shift based on directions', i1, i2
              endif
           endif
       enddo
    enddo
  
    do jj = 1, pbc%per
       lattvec(:,jj) = pbc%latt_vec(:,jj)/ &
            (one + real(cell_vac(jj),dp))/real(supercell(jj),dp)
    enddo
  
    select case(pbc%per)
    case (0)
       write(f_parsec,*) 'Confined system (cluster) with zero boundary condition!'
       select case(grid%domain_shape)
       case (0)
          write(f_parsec,*) ' Spherical domain shape:'
          write(f_parsec,'(a,f10.6,a)') ' --- Max Radius is ',rmax, ' bohrs'
       case (1)
          write(f_parsec,*) ' Ellipsoidal domain shape:'
          write(f_parsec,'(a,f10.6,a)') ' --- x radius is ',grid%d_shape_param(1), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- y radius is ',grid%d_shape_param(2), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- z radius is ',grid%d_shape_param(3), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for grid creation) is ',rmax, ' bohrs'
       case (2)
          write(f_parsec,*) ' Cylindrical domain shape:'
          select case(grid%i_shape_param(1))
          case (1)
             write(f_parsec,*) ' --- Oriented along the x axis'
          case (2)
             write(f_parsec,*) ' --- Oriented along the y axis'
          case (3)
             write(f_parsec,*) ' --- Oriented along the z axis'
          end select
          write(f_parsec,'(a,f10.6,a)') ' --- Radius is ',grid%d_shape_param(1), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- Length is ',grid%d_shape_param(2), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for grid creation) is ',rmax, ' bohrs'
       case (3)
          write(f_parsec,*) ' Box domain shape:'
          write(f_parsec,'(a,f10.6,a)') ' --- x length is ',grid%d_shape_param(1), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- y length is ',grid%d_shape_param(2), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- z length is ',grid%d_shape_param(3), &
             ' bohrs'
          write(f_parsec,'(a,f10.6,a)') ' --- Max Radius (for grid creation) is ',rmax, ' bohrs'
        case default
            write(f_parsec,*) 'Incorrect domain shape encountered'
            write(f_parsec,*) 'STOP in usrinput'
            ierr = 110
           return
       end select
       write(f_parsec,'(a,f9.6,a)') ' Grid spacing is ', h, ' bohrs'
       itmp=0
    case (1)
       pbc%box_size = zero
       pbc%box_size(1) = abs(pbc%latt_vec(1,1))
           
       write(f_parsec,*) 'Tube boundary conditions!' 
       write(f_parsec,*) 'System is non-periodic on the yz plane'
       write(f_parsec,*) 'and periodic along x direction.'
       write(f_parsec,*)
       write(f_parsec,*) 'Periodicity length [bohr] : '
       write(f_parsec,'(3(f15.10, 1x))') pbc%latt_vec(1,1)
       write(f_parsec,*)
       write(f_parsec,'(a,f10.6,a)') ' Boundary cylinder radius is ', rmax, ' bohrs'
  
       write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ', h,' bohrs'
       write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
       write(f_parsec,*)
  
    case (2)
       pbc%box_size = zero
       do i = 1, 2
  pbc%box_size(i) = sqrt(sum(pbc%latt_vec(:,i)**2))
       enddo
  
       write(f_parsec,*) 'Periodic boundary conditions!'
       write(f_parsec,*) 'System is periodic on the xy plane'
       write(f_parsec,*) 'and non-periodic on the z direction.'
       write(f_parsec,*)
       write(f_parsec,*) 'Unit lattice vectors [bohr] : '
       do i = 1, 3
  write(f_parsec,'(3(f15.10, 1x))') pbc%latt_vec(:,i)
       enddo
       write(f_parsec,*)
       write(f_parsec,'(a,f10.6,a)') ' Boundary slab height is ', rmax, ' bohrs'
  
       write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ', h,' bohrs'
       write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
       write(f_parsec,*)
  
    case (3)
       do i = 1, 3
          pbc%box_size(i) = sqrt(sum(pbc%latt_vec(:,i)**2))
       enddo
  
       write(f_parsec,*) 'Periodic boundary conditions!' 
       write(f_parsec,*) 'System is fully periodic '
       write(f_parsec,*) 'Unit lattice vectors [bohr] : '
       do i = 1, 3
          write(f_parsec,'(3(f15.10, 1x))') pbc%latt_vec(:,i)
       enddo
       write(f_parsec,*)
  
       write(f_parsec,'(a,f9.6,a)') ' User-provided grid spacing is ',h,' bohrs'
       write(f_parsec,*) 'WARNING: grid spacing may be rescaled below!!'
       write(f_parsec,*)
  
        !Are we explicitly calculating the hartree potential?
        elec_st%explicit_hartree_pbc = esdf_boolean('Calc_Hartree_G',boolean_default)
        if (elec_st%explicit_hartree_pbc) then
           write(f_parsec,*)
           write(f_parsec,*) 'CAUTION: The Hartree potential will be calculated in reciprocal space'
           write(f_parsec,*) 'IMPLEMENTATION INCOMPLETE - GARBAGE INCOMING'
           write(f_parsec,*)
        endif
  
    end select
  
    itmp = 1
    grid%ndouble = esdf_integer('Double_grid_order',itmp)
    if (grid%ndouble > 1) then
       write(f_parsec,'(a,i4)') ' Order of double grid is ',grid%ndouble
       write(f_parsec,'(a,/)') ' WARNING! DOUBLE GRID WILL MODIFY FORCES AND TOTAL ENERGY!'
    endif
    if (grid%ndouble < 1) then
       write(f_parsec,*) 'ERROR! double grid order must be greater than zero! ', grid%ndouble
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 113
       return
    endif
    
    write(f_parsec,*) 'Grid points could be shifted from origin: '
    write(f_parsec,'(a,3f8.4,a)') ' shift vector = ',grid%shift,'   [units of grid spacing]'
  
    ! Read information about kpoint sampling.
  
      band_st%bands_on = .false. ! this flag is here to make sure that 
                                 ! it is off in cluster runs.  
  
      nscf%nscf_on = .false.     ! this flag is here to make sure that 
                                 ! it is off in cluster runs -- although
                                 ! later it might make sense to reseruct it
    if(pbc%is_on) then
  
       strflag = esdf_reduce(esdf_string ('kpoint_method', 'none'))
  
       select case(trim(strflag))
       case ('none')
          write(f_parsec,*) ' Kpoint sampling is off.'
          write(f_parsec,*) ' Calculation at gamma point'
          elec_st%nkpt = 0
       case ('mp')
          elec_st%kptmethod = MONKHORST_PACK
          elec_st%nkpt = 1
          write(f_parsec,*) ' kpoints selected by Monkhort-Pack algorithm'
          if(esdf_block('Monkhorst_Pack_Grid',nlines))then
             if(nlines /= 1) then
                write(f_parsec,*) ' error in specifying Monkhorst-Pack Grid: ',nlines
                write(f_parsec,*) ' STOP in usrinput'
                ierr = 114
                return
             endif
             elec_st%mpgrid = 1
             read(block_data(nlines),*,iostat=ierr) &
                  (elec_st%mpgrid(i), i = 1, pbc%per)
             if((ierr /= 0) .or. (elec_st%mpgrid(1) <= 0) .or. &
                  (elec_st%mpgrid(2) <= 0) .or. (elec_st%mpgrid(3) <= 0)) then
                write(f_parsec,*) ' error in specifying Monkhorst-Pack Grid'
                write(f_parsec,*) ' STOP in usrinput'
                ierr = 115
             endif
          endif
          write(f_parsec,*) ' Monkhorst-Pack grid dimensions specified'
              write(f_parsec,37) (elec_st%mpgrid(i), i = 1, pbc%per)
  37      format(1x,i3,1x,'X',i3,1x,'X',i3)
          if(esdf_block('Monkhorst_Pack_Shift',nlines))then
             if(nlines /= 1) then
                write(f_parsec,*) ' error in specifying Monkhorst-Pack Shift'
                write(f_parsec,*) ' STOP in usrinput'
                ierr = 116
                return
             endif
             elec_st%mpshift = zero
             read(block_data(nlines),*,iostat=ierr) &
                  (elec_st%mpshift(i), i = 1, pbc%per)
             if((ierr /= 0) .or. (elec_st%mpshift(1) < 0) .or. &
                  (elec_st%mpshift(2) < 0) .or. (elec_st%mpshift(3) < 0)) then
                write(f_parsec,*) ' error in specifying Monkhorst-Pack Shift'
                write(f_parsec,*) ' STOP in usrinput'
                ierr = 117
             endif
          write(f_parsec,*)' Monkhorst-Pack shift specified'
         else
             elec_st%mpshift = zero
          write(f_parsec,*)' Default Monkhorst-Pack shift '
          endif
          write(f_parsec,38) (elec_st%mpshift(i), i = 1, pbc%per)
  38      format(1x,f7.3,1x,'X',f7.3,1x,'X',f7.3)
       case ('manual')
          elec_st%kptmethod = KP_MANUAL
          write(f_parsec,*)' kpoints selected manually'
          if(esdf_block('Kpoint_List',nlines))then
             elec_st%nkpt = nlines
             allocate(elec_st%kpts(3,elec_st%nkpt))
             allocate(elec_st%kpwt(elec_st%nkpt))
             elec_st%kpts = zero
             elec_st%kpwt = zero
             do i=1,nlines
                read(block_data(i),*) &
                     (elec_st%kpts(itmp,i), itmp = 1, 3),elec_st%kpwt(i)
             enddo
          else
             write(f_parsec,*) 'ERROR: Could not find list of kpoint coordiantes'
             write(f_parsec,*) 'STOP in usrinput.'
             ierr = 118
          endif
          strflag = esdf_reduce(esdf_string ('Kpoint_Unit', &
               'cartesian_inverse_bohr'))
          ! cscale : reciprocal unit lattice vectors; necessary only if
          ! kpoint_unit is unit_reciprocal_lattice_vectors.
          cscale(:,:) = zero
          cscale = transpose(lattvec)
          call mtrxin(cscale,vtmp(1),vtmp(2))
          cscale = cscale * twopi
          if (trim(strflag) == 'reciprocal_lattice_vectors') then
             do i = 1, elec_st%nkpt
                call matvec3('N',cscale,elec_st%kpts(:,i),vtmp)
                elec_st%kpts(:,i) = vtmp
             enddo
          endif
          write(f_parsec,*)' Kpoints (units 1/Bohr) and sampling weights'
          do i = 1, elec_st%nkpt
             write(f_parsec,'(3x,f8.5,1x,f8.5,1x,f8.5,1x,f8.5)') &
                  elec_st%kpts(:,i), elec_st%kpwt(i)
             if (elec_st%kpwt(i) < 0) then
                write(f_parsec,*) 'Sampling weight must be positive'
                write(f_parsec,*) 'STOP in usrinput.'
                ierr = 119
                return
             endif
          enddo
       end select
  
    
  
      !read band structure parameters from input file   
      if(esdf_block('bandstruc',nlines))then
        band_st%bands_on = .true. 
        band_st%nlines = nlines
        allocate(band_st%blines(nlines))  
        do i=1,nlines
                read(block_data(i),*) &
                    band_st%blines(i)%line_num, band_st%blines(i)%start(1:3), &
                    band_st%blines(i)%end(1:3), band_st%blines(i)%line_name
        enddo
        itmp=100
        band_st%npoints=esdf_integer('bandstruc_points',itmp)
        write(f_parsec,*) 'Calculating band structure'
      endif
  
      ! Read non self consistent calculation kpoints from file
      if(esdf_block('nscf_kpoints',nlines))then
        nscf%nscf_on = .true. 
        nscf%nkpt = nlines
        allocate(nscf%kpts(3,nscf%nkpt))
        allocate(nscf%kpwt(nscf%nkpt))
        nscf%kpts = zero
        nscf%kpwt = zero
        do i=1,nlines
           read(block_data(i),*) &
                 (nscf%kpts(itmp,i), itmp = 1, 3),nscf%kpwt(i)
           write(*,*) & ! this is a debug line
                 (nscf%kpts(itmp,i), itmp = 1, 3),nscf%kpwt(i)
        enddo
        write(f_parsec,*) ' Calculating non self consistent electronic structure'
      endif
      if (nscf%nscf_on) then
      strflag = esdf_reduce(esdf_string ('nscf_kpoint_unit', &
               'cartesian_inverse_bohr'))
      ! cscale : reciprocal unit lattice vectors; necessary only if
      ! kpoint_unit is unit_reciprocal_lattice_vectors.
      cscale(:,:) = zero
      cscale = transpose(lattvec)
      call mtrxin(cscale,vtmp(1),vtmp(2))
      cscale = cscale * twopi
      if (trim(strflag) == 'reciprocal_lattice_vectors') then
         do i = 1, nscf%nkpt
            call matvec3('N',cscale,nscf%kpts(:,i),vtmp)
            nscf%kpts(:,i) = vtmp
         enddo
      endif
      ! Renormalize the weights to 1
      dtmp = sum(nscf%kpwt,1) 
      nscf%kpwt = nscf%kpwt / dtmp
  
      write(f_parsec,*)' Kpoints (units 1/Bohr) and sampling weights'
      do i = 1, nscf%nkpt
         write(f_parsec,'(3x,f8.5,1x,f8.5,1x,f8.5,1x,f8.5)') &
               nscf%kpts(:,i), nscf%kpwt(i)
         if (nscf%kpwt(i) < 0) then
            write(f_parsec,*) 'Sampling weight must be positive'
            write(f_parsec,*) 'STOP in usrinput.'
            ierr = 119
            return
         endif
      enddo
      endif
  
      if (nscf%nscf_on) then
        nscf%nstate = esdf_integer ('nscf_States_Num',elec_st%nstate)
  
        if (istart /= 1) then
           write(f_parsec,*) ' In case of non self consistent calculations'
           write(f_parsec,*) ' Please specify restart flag to read potential'
           write(f_parsec,*) ' from a previous run'
           write(f_parsec,*) ' STOP in usrinput'
           ierr = 114
           return
        endif
      
     endif !nscf%nscf_on
  
    endif ! pbc%is_on
   
    pbc%create_dos = esdf_boolean ('create_dos', .false.)
    itmp = 1000
    pbc%dos_pnum = esdf_integer('dos_pnum',itmp)
    if (pbc%create_dos .and. pbc%is_on) then 
       write(f_parsec,*)' Full DOS creation is on'
       lflag = esdf_block('DOS_MP_Grid',nlines)
       if (lflag .and. nlines==1) then
          elec_st%dos_mpgrid = 1
          read(block_data(nlines),*,iostat=ierr) &
               (elec_st%dos_mpgrid(i), i = 1, pbc%per)
          if((ierr /= 0) .or. (elec_st%dos_mpgrid(1) <= 0) .or. &
               (elec_st%dos_mpgrid(2) <= 0) .or. (elec_st%dos_mpgrid(3) <= 0)) then
             write(f_parsec,*)' error in specifying DOS MP Grid'
             write(f_parsec,*)' STOP in usrinput'
             ierr=1
          endif
          write(f_parsec,*)' DOS MP grid dimensions specified'
          write(f_parsec,37) (elec_st%dos_mpgrid(i), i = 1, pbc%per)
       if(esdf_block('DOS_MP_Shift',nlines))then
          if(nlines /= 1) then
                write(f_parsec,*)' error in specifying DOS MP Shift'
                write(f_parsec,*)' STOP in usrinput'
                ierr=1
          endif
          elec_st%dos_mpshift = zero
          read(block_data(nlines),*,iostat=ierr) &
              (elec_st%dos_mpshift(i), i = 1, pbc%per)
          if((ierr /= 0) .or. (elec_st%dos_mpshift(1) < 0) .or. &
               (elec_st%dos_mpshift(2) < 0) .or. (elec_st%dos_mpshift(3) < 0)) then
             write(f_parsec,*)' error in specifying DOS MP Shift'
             write(f_parsec,*)' STOP in usrinput'
             ierr=1
          endif
       endif
       write(f_parsec,*)' DOS MP shift specified'
       write(f_parsec,38) (elec_st%dos_mpshift(i), i = 1, pbc%per)
       else
          if (elec_st%kptmethod == KP_MANUAL) then
             write(f_parsec,*)' WARNING: DOS cannot be created based on a manual MP grid,'
             write(f_parsec,*)'          please specify a DOS MP grid. DOS creation aborted !'
             pbc%create_dos = .false.
          else
             write(f_parsec,*)' DOS MP Grid not specified, using one used for density calculation'
             elec_st%dos_mpgrid=elec_st%mpgrid
             elec_st%dos_mpshift=elec_st%mpshift   
          endif
       endif 
  
       if (istart == 1) then
          elec_st%kptmethod = MONKHORST_PACK
          elec_st%mpgrid=elec_st%dos_mpgrid
          elec_st%mpshift=elec_st%dos_mpshift
          outflag = -1
       end if
       itmp = -1
       pbc%ylmdos_l = esdf_integer('ylm_dos_l',itmp)
    end if
  
    
    ! read request for orbital magnetism
     elec_st%orb_mag = esdf_boolean ('orb_mag',.false.)  
     if(elec_st%orb_mag)then
       pot%is_cur = .true.
       elec_st%is_cur = .true.
     else
       pot%is_cur = .false.
       elec_st%is_cur = .false.
     endif
  
    ! read value of external magnetic field
    elec_st%is_mag = .false.
    elec_st%mag_field = esdf_double('External_Mag_Field',double_default)
    if (abs(elec_st%mag_field)>zero) then
      elec_st%mag_field = elec_st%mag_field / 2.5d+9
      elec_st%is_mag = .true.
      write(f_parsec,'(/,a)') ' Applying external uniform magnetic field'
      write(f_parsec,'(a,f11.5,a)') ' Magnetic field: H =',elec_st%mag_field, &
          ' Gauss'
    else
      elec_st%is_mag = .false.
      !write(f_parsec,'(/,a)') ' No external uniform magnetic field H=0 !!'
    endif
  
    ! Read user defined complex or real wfn value.
    elec_st%cplx = esdf_boolean ('complex_wfn', .false.)
    if (elec_st%nkpt > 0) elec_st%cplx = .true.
    if (elec_st%is_mag) elec_st%cplx = .true.
    !if (elec_st%mxwd == 2) elec_st%cplx = .true. !AJB? bugfix UNINITIALIZED
    if (elec_st%cplx) then
       write(f_parsec,*) 'WAVEFUNCTIONS ARE COMPLEX!'
       !> \todo AJB: call grid_set_rmax_step again and modify fold size
    else
       write(f_parsec,*) 'WAVEFUNCTIONS ARE REAL!'
       if (elec_st%nkpt > 0) then
          write(f_parsec,*) '...but kpoint sampling is ON!'
          write(f_parsec,*) 'STOP in usrinput.'
          ierr = 120
          return
       endif
    endif
  
    ! Read order of finite difference expansion.
    itmp = 12
    norder = esdf_integer ('Expansion_Order',itmp)
    if((norder /= 12)) then
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Expansion_Order must be 12 until more stencils'
       write(f_parsec,*) 'patterning are added to the kernel -AJB'
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 121
       return
    endif
  
    write(f_parsec,'(a,i2,/)') ' The Finite-difference expansion is of order ', norder
    if ((norder < 1) .or. (norder > mxorder)) then
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Expansion_Order is the number of'
       write(f_parsec,*) 'neighbors used on two sides in numerical'
       write(f_parsec,*) 'derivative. It should be an integer' 
       write(f_parsec,*) 'between 2 and ', mxorder,' Input as ',norder
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 121
       return
    endif
  
    if (mod(norder,2) /= 0) then
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Expansion_Order should be an even number'
       write(f_parsec,*) 'between 2 and ', mxorder,' Input as ',norder
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 122
       return
    endif
  
    grid%norder = norder/2
  
    ! Read in the number of eigenstates to be calculated, nstate;
    ! net cluster charge, ncharge.
    nstate = esdf_integer ('States_Num',integer_default)
    if (nstate == integer_default) then
       write(f_parsec,*) 'ERROR: unknown number of states. '
       write(f_parsec,*) ' Input line "States_Num" not found!'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 123
       return
    endif
  
    if(nstate < 0) then
        write(f_parsec,*) 'States_Num is negative. Preparing for Special TEST MODE'
        nstate = 0
    endif
  
    ncharge = esdf_physical ('Net_Charges',double_default,'e')
    write(f_parsec,*) 'Eigenvalue data: '
    write(f_parsec,*) '---------------- '
    write(f_parsec,*) 'Number of states: ', nstate
    write(f_parsec,'(a,g12.4,a)') ' Net cluster charge = ', ncharge,'  [e] '
  
  
    ! read in electron temperature (in Kelvin)
    dtmp = 80.0d0
    tfermi = esdf_physical ('Fermi_Temp',dtmp,'k')
    write(f_parsec,*)
    if (tfermi >= zero) then
       write(f_parsec,'(a,f9.2,a)') ' Fermi temperature = ',tfermi, ' [K]'
    else 
       write(f_parsec,*) 'WARNING: reading occupations from occup.in file'
       ! occupations read from file in initial.f
       if (elec_st%nkpt > 0) then
          write(f_parsec,*) '...but kpoint sampling is ON!'
          write(f_parsec,*) 'STOP in usrinput.'
          ierr = 120
          return
       endif
    endif
  
    write(f_parsec,*)
    write(f_parsec,*) 'Self-consistency data: '
    write(f_parsec,*) '----------------------'
    ! read in maximal # of iterations before giving up on self-consistency
    itmp = 50
    mxiter = esdf_integer ('Max_Iter',itmp)
    write(f_parsec,*) 'Maximum number of iterations is ', mxiter
  
    ! read in eigensolver
    !strflag = esdf_reduce(esdf_string ('Eigensolver', 'chebdav'))
    !!-- chebdav was the default for previous version, we may set the default to chebff soon
    strflag = esdf_reduce(esdf_string ('Eigensolver', 'chebff'))
  
#ifndef USEARPACK
    if (trim(strflag) == 'arpack') then
       write(f_parsec,*) ' ERROR: arpack is selected as eigensolver but'
       write(f_parsec,*) ' this executable seems to have missing arpack.'
       write(f_parsec,*) ' Stop in usrinput.'
       ierr = 124
       return
    endif
#endif
      ! use old forces
      inputs%use_old_forces =esdf_boolean('Use_Old_Forces',inputs%use_old_forces)

      ! print unconverged density during each iteration
      inputs%print_unconverged_density =esdf_boolean('print_unconverged_density',inputs%print_unconverged_density)

      ! print final density after scf loop
      inputs%output_ascii_data=esdf_boolean('output_ascii_data',inputs%output_ascii_data)


      ! default use of semi-random initial guess (same each run)
      solver%randommp =esdf_boolean('Thread_Random_Init',.true.)
      solver%oldvectorrng =esdf_boolean('Old_Vector_Random',.false.)
  
    select case (trim(strflag))
    case ('arpack')
       write(f_parsec,*) 'Using ARPACK (implicitly restarted Arnoldi eigensolver)'
       solver%name = ARPACK
       solver%mv_blksize = min(nstate/2,4)
       solver%mv_blksize  = esdf_integer ('Matvec_Blocksize', solver%mv_blksize)
       if (solver%mv_blksize > nstate) then
           write(f_parsec,*) 'Matvec block size bigger than the number of states, adjusting.'
           solver%mv_blksize  = nstate/2
       else
           write(f_parsec,*) 'The matvec operations are (mostly) called to with... '
           write(f_parsec,*) '... block size: ',solver%mv_blksize
       endif
       !not used:
       grid%max_lap_buffers = esdf_integer('max_lap_buffers',2)
       ! if (grid%max_lap_buffers<2) then
       !     write(f_parsec,*) 'Maximum number of communication buffers in matvec: (default)',2
       !     grid%max_lap_buffers=2
       ! else
  
           ! write(f_parsec,*) 'Maximum number of communication buffers in matvec:',grid%max_lap_buffers
       ! endif
  
    case ('chebff') 
       write(f_parsec,*) 'Using first-filter solver'
       solver%name = CHEBFF
       itmp = 20
       !continue to use 'Chebdav_degree' without introducing a new variable/parameter
       solver%polym0 = esdf_integer('Chebdav_degree',itmp) 
       write(f_parsec,'(a,1x,i5)') ' Polynomial degree for First-filter is ', &
            solver%polym0
       !if the degree is between 10 and 15, can still try without erring out
       if (solver%polym0 < 10) then  
          write(f_parsec,*) ' warning: for chebff, the chebdav_degree better be at least 10'
          write(f_parsec,*) ' your chebdav_degree = ',solver%polym0
          write(f_parsec,*) ' automatically updating chebdav_degree to 12 '
          solver%polym0 = 12
       endif
       solver%mv_blksize = min(nstate/2,6)
       solver%mv_blksize  = esdf_integer ('Matvec_Blocksize', solver%mv_blksize)
           write(f_parsec,*) 'The matvec operations are (mostly) called to with... '
           write(f_parsec,*) '... block size: ',solver%mv_blksize
       grid%max_lap_buffers = esdf_integer('max_lap_buffers',2)
       ! if (grid%max_lap_buffers<2) then
       !     write(f_parsec,*) 'Maximum number of communication buffers in matvec: (default)',2
       !     grid%max_lap_buffers=2
       ! else
       !     if (grid%max_lap_buffers>2) then
  
       !         write(f_parsec,*) 'Warning - in this version we only use max 2 lap buffers.'
       !         grid%max_lap_buffers=2
       !     endif
       !     write(f_parsec,*) 'Maximum number of communication buffers in matvec:',grid%max_lap_buffers
       ! endif
       itmp = 3
       solver%ff_maxiter = esdf_integer('FF_MaxIter',itmp)
       write(f_parsec,'(a,1x,i5)') ' Maximum iteration number for First-filter is ', &
            solver%ff_maxiter
       !> \todo CML-changed the minimum to 0 to enable testing, but probably
       !! should have an override flag for purposes of this to keep helpful
       !! stuff when expert isn't using
       if (solver%ff_maxiter < 0 .or. solver%ff_maxiter >= 50) then  
          write(f_parsec,*) ' warning: input FF_MaxIter is not within [1, 50] '
          write(f_parsec,*) ' your FF_MaxIter = ',solver%ff_maxiter
          write(f_parsec,*) ' automatically update ff_maxiter to ',itmp
          solver%ff_maxiter = itmp
       endif     
  
      if (solver%randommp) then
          write(f_parsec,*) 'WARNING, threaded randomization of initial guess is selected'
          write(f_parsec,*) 'Results will differ from old PARSEC runs'
      endif
  
  
    case ('chebdav') 
       write(f_parsec,*) 'Using Chebyshev-Davidson eigensolver'
       solver%name = CHEBDAV
       itmp = 20
       solver%polym0 = esdf_integer('Chebdav_degree',itmp)
       write(f_parsec,'(a,1x,i5)') ' Polynomial degree for Chebyshev-Davidson is ', &
            solver%polym0
       if (solver%polym0 < 15) then
          write(f_parsec,*) ' ERROR: chebdav_degree should be at least 15!'
          write(f_parsec,*) ' chebdav_degree = ',solver%polym0
          write(f_parsec,*) ' automatically update chebdav_degree to 15 '
          solver%polym0 = 15
          return
       endif
       solver%mv_blksize = min(nstate/2,6)
       solver%mv_blksize  = esdf_integer ('Matvec_Blocksize', solver%mv_blksize)
           write(f_parsec,*) 'The matvec operations are (mostly) called to with... '
           write(f_parsec,*) '... block size: ',solver%mv_blksize
       ! grid%max_lap_buffers = esdf_integer('max_lap_buffers',0)
       ! if (grid%max_lap_buffers<2) then
       !     write(f_parsec,*) 'Maximum number of communication buffers in matvec: (default)',2
       !     grid%max_lap_buffers=2
       ! else
       !     if (grid%max_lap_buffers>2) then
  
       !         write(f_parsec,*) 'Warning - in this version we only use max 2 lap buffers.'
       !         grid%max_lap_buffers=2
       !     endif
       !     write(f_parsec,*) 'Maximum number of communication buffers in matvec:',grid%max_lap_buffers
       ! endif
    case ('diagla')
          write(f_parsec,*) 'ERROR: eigensolver DIAGLA removed from PARSEC'
          write(f_parsec,*) 'Please choose a different one...'
          ierr = 126
          return
    case ('trlanc','trlan')
       ! write(f_parsec,*) 'Using Thick Restarted Lanczos eigensolver'
       ! solver%name = TRLANC
       ! if (elec_st%cplx) then
          write(f_parsec,*) 'ERROR: eigensolver TRLANC removed from PARSEC'
          write(f_parsec,*) 'Please choose a different one...'
          ierr = 126
          return
       !endif
    case('none')
        write(f_parsec,*) "Eigensolver is 'none'. Preparing for Special TEST MODE"
       solver%name = TEST
    case default
       write(f_parsec,*) 'wrong input eigen solver name: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 127
       return
    end select
  
! ===============================================================
! Spectrum slicing
! ===============================================================
    write(f_parsec,*)

    solver%spectrum_slicing = esdf_boolean('spectrum_slicing', BOOLEAN_DEFAULT)
    solver%spectrum_slicing_max_iter = esdf_integer('spectrum_slicing_max_iter', 1)
    solver%nslices = esdf_integer('nslices', 1)

    if (solver%spectrum_slicing) then
        write(f_parsec, *) 'Spectrum slicing is on'
        write(f_parsec, *) 'Number of slices is ', solver%nslices
        write(f_parsec, *) 'Number of subspace iterations for spectrum slicing is ', solver%spectrum_slicing_max_iter
    else
        write(f_parsec, *) 'Spectrum slicing is off'
    endif

    inputs % use_scalapack = esdf_boolean('use_scalapack', inputs % use_scalapack)
#ifndef USE_SCALAPACK
    if(inputs % use_scalapack) then
        write(f_parsec, *) "use_scalapack is true, but PARSEC wasn't compiled with&
            & -DUSE_SCALAPACK"
       inputs % use_scalapack = .false.
    endif
#endif
    if (inputs % use_scalapack) then
        write(f_parsec, *) 'Use ScaLAPACK at projection, decomposition, and update'
    else
        write(f_parsec, *) 'use_scalapack is off'
    endif
  
    solver%fix_num_eig = esdf_boolean ('Fix_Number_Eigenvalues',boolean_default)
    if (solver%fix_num_eig) then
       write(f_parsec,*) 'Fixing the number of eigenvalues per representation'
       write(f_parsec,*) 'WARNING!! This option should only be used when ', &
            'restarting from previous SCF.'
    endif
    write(f_parsec,*)
  
    solver%do_subsp = esdf_boolean ('Chebyshev_filtering',boolean_default)
  
    solver%scaledcheb = esdf_boolean ('Chebyshev_scaled',.true.)
  
    ! always do subspace filtering at latter steps
    if (solver%name == CHEBFF .or. solver%name == CHEBDAV) solver%do_subsp = .true.
  
    if (solver%do_subsp) then
        solver%use_smart_bound_in_subspace= esdf_boolean ('smart_subspace',.true.)
        itmp = 5000
        solver%restart_cheb_after_n = esdf_integer('Filter_restart_after',itmp)
        itmp = 15
        solver%polym = esdf_integer('Chebyshev_degree',itmp)
        solver%polym_t = solver%polym
        if (solver%scaledcheb) then
            write(f_parsec,*) 'Performing (EXPERIMENTAL) Scaled Chebyshev subspace filtering'
        else
            write(f_parsec,*) 'Performing Chebyshev subspace filtering'
        endif
        if (solver%use_smart_bound_in_subspace) then
            write(f_parsec,*) ''
            write(f_parsec,*) 'Using (EXPERIMENTAL) S.M.A.R.T adaptive lower filter bound'
            write(f_parsec,*) ''
        endif
  
  
        write(f_parsec,'(a,1x,i5)') ' Polynomial degree for Chebyshev filtering is ', solver%polym
        write(f_parsec,*) ' Will restart from scratch after', solver%restart_cheb_after_n,'ionic steps' 
        if (solver%polym < 10) then
            itmp = 1
        else
            itmp = 3
        endif
        solver%dpm = esdf_integer('Chebyshev_degree_delta',itmp)
        write(f_parsec,'(a,1x,i5)') ' Change in polynomial degree (dpm) for Chebyshev filtering is ', &
            solver%dpm 
        write(f_parsec,*) 'Performing Rayleigh-Ritz rotation on all SCF iterations'
    else
        write(f_parsec,*) 'No Chebyshev subspace filtering'
    endif
    write(f_parsec,*)
  
    ! read in value for convergence criterion and diagonalization tolerance
    dtmp = 2.d-4
    vconv = esdf_physical ('Convergence_criterion', dtmp,'ry')
    !dtmp = 100.d0 * vconv 
    !AJB - nut sure about this, but it seems like vconv_approach should be lower than 100
    !AJB2 - In fact, lets make it closer to vconv unless user wants it
    !dtmp = 50.d0 * vconv 
    dtmp = 2.d0 * vconv 
    vconv_approach = esdf_physical ('Convergence_criterion_approach', dtmp,'ry')
  
    elec_st%use_plain_sre = esdf_boolean('use_plain_sre',boolean_default) 
  
    ! only for arpack
    dtmp = 1.d-4
    solver%toler = esdf_double('Diag_Tolerance', dtmp)
  
    ! read in value for dynamic convergence tolerance
    solver%dyntol = esdf_boolean('dynamic_diag_tol',boolean_default)
    ! insert dynamic tolerance for faster convergence
    if (solver%dyntol) then
       if (istart_tmp) then
          solver%dyntol = .false.
          write(f_parsec,*) 'dynamic tolerance is not working with restart run!'
       else
          solver%toler = 0.1d0
          write(f_parsec,*) 'YOU ARE USING DYNAMIC TOLERANCE FOR CONVERGENCE'
       endif
    endif
  
    itmp = 6
    solver%nadd = esdf_integer('Subspace_buffer_size',itmp)
    ! write(f_parsec,'(a,f12.7,a)') ' Self-consistency convergence criterion is ', &
    !      vconv, ' Ry'
    write(f_parsec,'(a,ES11.4,a)') ' Self-consistency convergence criterion (vs. SRE) is ', &
         vconv, ' Ry'
    ! write(f_parsec,'(a,f12.7,a)') ' Self-consistency convergence indicator criterion is ', &
    !      vconv_approach, ' Ry'
    write(f_parsec,'(a,ES11.4,a)') ' Self-consistency convergence indicator is at', &
         vconv_approach, ' Ry'
    write(f_parsec,'(a)') ' If applicable, Chebyshev polynomial order will decrease up to '
    write(f_parsec,'(a)') ' 10 after SRE becomes less than the self-consistency ', &
         ' convergence indicator.'
     !write(f_parsec,'(a,f12.7)') ' Diagonalization tolerance is ',solver%toler
     if (elec_st%use_plain_sre) then
    write(f_parsec,'(a)') ''
    write(f_parsec,'(a)') '  Using the unweighted SRE for convergence checking'
    write(f_parsec,'(a)') ''
     endif
    write(f_parsec,*) ' Diagonalization tolerance is ',solver%toler
    write(f_parsec,'(a,i5,/)') ' Buffer size in subspace is  ',solver%nadd
  
    itmp = 30000
    solver%maxmv = esdf_integer('Maximum_matvec',itmp)
    strflag= esdf_string('rritz_logic','none')
    select case(trim(strflag))
     case ('classic')
       write(f_parsec,*) 'Using rayleigh_ritz::classic'
       rritz % forced_logic = k_rritz_force_classic
     case ('tiled')
       write(f_parsec,*) 'Using rayleigh_ritz::tiled'
       rritz % forced_logic = k_rritz_force_tiled
     case ('dist1')
#ifndef WITH_ELPA
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: ELPA not linked. ',trim(strflag),' not available'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
#endif
       write(f_parsec,*) 'Using rayleigh_ritz::dist1'
       rritz % forced_logic = k_rritz_force_dist1
     case ('dist2')
#ifndef WITH_ELPA
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: ELPA not linked. ',trim(strflag),' not available'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
#endif
       write(f_parsec,*) 'Using rayleigh_ritz::dist2'
       rritz % forced_logic = k_rritz_force_dist2
     case ('distmixed')
#ifndef WITH_ELPA
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: ELPA not linked. ',trim(strflag),' not available'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
#endif
       write(f_parsec,*) 'Using rayleigh_ritz::dist*'
       rritz % forced_logic = k_rritz_force_distmixed
     case ('custom')
       write(f_parsec,*) 'Using rayleigh_ritz::* - custom logic - variable!'
       rritz % forced_logic = k_rritz_force_custom
     case ('none')
       write(f_parsec,*) 'Using default logic - based on problem'
       rritz % forced_logic = k_rritz_force_none
     case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Unknown rritz logic type: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
    end select

    strflag= esdf_string('bounds_method','lanczos')
    select case(trim(strflag))
     case ('static')
       solver%boundsmethod=k_bounds_static
     case ('lanczos_full')
       solver%boundsmethod=k_bounds_lanczos_fullorth
     case ('lanczos')
       solver%boundsmethod=k_bounds_lanczos
     case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Unknown boundsmethod type: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 129
       return
    end select
    solver%num_lancz_bound = esdf_integer('bounds_iter',10)

    strflag= esdf_string('test_logic','none')
    select case(trim(strflag))
     case ('none')
       tests % logic = k_test_none
     case ('forces')
       tests % logic = k_test_forces
     case ('lanczos')
       tests % logic = k_test_lanczos
     case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Unknown test_logic type: ',trim(strflag)
       write(f_parsec,*) 'STOP in ',__FILE__,':',__LINE__
       ierr = 130
       return
    end select

    ! if (solver%do_subsp .and. solver%nadd < 2) then
    if (solver%do_subsp .and. solver%nadd < 6) then
      solver%nadd = 6
       write(f_parsec,*) ' With Chebyshev subspace, buffer size must be at least 6'
       !AJB: why?
       write(f_parsec,'(a,1x,i5)') ' New buffer size is ',solver%nadd
    endif
  
    write(f_parsec,*)
    write(f_parsec,*) 'Mixer data:'
    write(f_parsec,*) '-----------'
  
    mixer%scf_fail = .false.  !set flag to false
  
    ! read in mixer type
    strflag = esdf_reduce(esdf_string ('Mixing_Method', 'anderson'))
  
    select case (trim(strflag))
    case ('anderson')
       mixer%name = ANDERSON
    case ('broyden')
       mixer%name = BROYDEN
    case ('msecant1')
       mixer%name = MSECANT1
    case ('msecant2')
       mixer%name = MSECANT2
    case ('msecant3')
       mixer%name = MSECANT3
#ifndef DEBUG_MSECANT3
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Msecant3 is broken with OOB memory access at qinv: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
#endif
    case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Unknown mixer type: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 128
       return
    end select
  
    itmp = 4
    mixer%memory =  esdf_integer ('Memory_Param', itmp)
  
    itmp = 20
    mixer%restart = esdf_integer ('Restart_Mixing', itmp)
  
    dtmp = 0.30d0
    mixer%param = esdf_double ('Mixing_Param', dtmp)
  
    itmp = 9
    solver%lpole = esdf_integer ('Solver_Lpole',itmp)
    write(f_parsec,*) 'solver lpole is : ', solver%lpole
  
    ! solver%full_hartree_flag = esdf_boolean ('Full_Hartree',.false.)
    ! if(solver%full_hartree_flag) then
    !   write(f_parsec,*) 'Full hartree boundary conditions are used'
    !   grid%hartree_neibs_flag=.true.
    ! else
    !   grid%hartree_neibs_flag=.false.
    ! endif
  
    
  
    itmp = 1
    mixer%group_size = esdf_integer ('Mixing_Group_Size', itmp)
  
    itmp = 0
    mixer%en_stage = esdf_integer ('Mixing_EN_Like', itmp)
  
    dtmp = 0.3
    mixer%restart_factor = esdf_double ('Mixing_Restart_Factor', dtmp)
  
    dtmp = 2.0
    mixer%expand_factor = esdf_double ('Mixing_Memory_Expand_Factor', dtmp)
  
    ! Preferred type of update, used by hybrid methods implemented in
    ! msecant3.f90.
    itmp = 1
    mixer%preferred_type = esdf_integer ('Mixing_Preferred_Type', itmp)
  
    ! Maximum memory parameter, mixer%block > mixer%memory+1
    mixer%block = 20
  
    if (mixer%name == ANDERSON) then
       ! read mixing parameter (Anderson mixer)
       write(f_parsec,*) 'Anderson mixer'
       write(f_parsec,'(a,f6.3,a,i2)') ' Initial Jacobian: ', mixer%param, &
            '  Mixing memory is ', mixer%memory
       write(f_parsec,*) 'Mixing restarted after ',mixer%restart,' iterations'
  
    else if (mixer%name == BROYDEN) then
       write(f_parsec,*) ' Generalized Broyden mixer'
       !!if (mixer%memory+1 == mixer%block) then  !!a bug, it won't error out when mixer%block is too small
       if (mixer%memory+1 > mixer%block) then
          write(f_parsec,*)
          write(f_parsec,*) 'Warning: insufficient memory for mixing.'
          !!write(f_parsec,*) 'Increase mixer%block in structures.F to at least', &
          write(f_parsec,*) '  now reset mixer%block to ', &
               mixer%memory+1
          !!write(f_parsec,*) 'STOP in usrinput'
          !!ierr = 129
          !!return  !!in fact there is no need to error out in this case, simply reset mixer%block
          mixer%block = mixer%memory+1
       endif
       write(f_parsec,'(a,f6.3,a,i2)') ' Initial Jacobian: ', mixer%param, &
            '  Mixing memory is ', mixer%memory
       write(f_parsec,*) 'Mixing restarted after ',mixer%restart,' iterations'
  
    else if (mixer%name == MSECANT1 .or. mixer%name == MSECANT2) then
       if (mixer%name == MSECANT1) then
          if (mixer%en_stage == 0) then
             write(f_parsec,*) 'Multisecant method, Broyden-like Type-I update'
          else
             write(f_parsec,*) 'Multisecant method, EN-like Type-I update'
          endif
       else if (mixer%en_stage == 0) then
          write(f_parsec,*) 'Multisecant method, Broyden-like Type-II update'
       else
          write(f_parsec,*) 'Multisecant method, EN-like Type-II update'
       endif
       if (mixer%group_size == 0) then
          write(f_parsec,'(a,f6.3,a,i2)') ' Mixing parameter: ', mixer%param, &
            '  All secant equations taken into account in one group'
       else
          write(f_parsec,'(a,f6.3,a,i2)') ' Mixing parameter: ', mixer%param, &
            '  Group size of secant equations: ', mixer%group_size
       endif
       write(f_parsec,'(a,f6.3)') ' Restarting factor is: ', mixer%restart_factor
  
    else if (mixer%name == MSECANT3) then
       if (mixer%en_stage == 0) then
          write(f_parsec,*) 'Multisecant method, Broyden-like hybrid update'
       else
          write(f_parsec,*) 'Multisecant method, EN-like hybrid update'
       endif
       if (mixer%preferred_type == 1) then
          write(f_parsec,*) 'Preferred type of update is Type-I'
       else
          write(f_parsec,*) 'Preferred type of update is Type-II'
       endif
       write(f_parsec,'(a,f6.3,a,i2)') ' Mixing parameter: ', mixer%param, &
            '  Group size of secant equations: ', mixer%group_size
       write(f_parsec,'(a,f6.3)') ' Restarting factor is: ', mixer%restart_factor
    endif
    write(f_parsec,*)
  
    write(f_parsec,*) 'Atom data:'
    write(f_parsec,*) '--~--~--~-'
    ! read in and write number of atom types
    naty = esdf_integer('Atom_Types_Num',integer_default)
    if (solver%name == TEST) then
        naty = 0
        ! what happens in fortran when you allocate (0)?
    else
        if (naty == integer_default) then
           write(f_parsec,*) 'ERROR: unknown number of atom types. '
           write(f_parsec,*) ' Input line "Atom_Types_Num" not found!'
           write(f_parsec,*) 'STOP in usrinput'
           ierr = 130
           return
        endif
        write(f_parsec,'(/,a,i5,/)') ' Tot. # of atom types is ', naty
    endif
  
    strflag = esdf_reduce(esdf_string ('Coordinate_Unit','cartesian_bohr'))
    ! cscale : for periodic systems, hold unit lattice vectors in
    ! column-wise form
    cscale(:,:) = zero
  
    select case (trim(strflag))
    case ('cartesian_bohr')
       write(f_parsec,*) 'Atom coordinates input in Bohr radii'
       do i = 1, 3
          cscale(i,i) = one
       enddo
    case ('cartesian_ang')
       write(f_parsec,*) 'Atom coordinates input in angstroms'
       do i = 1, 3
          cscale(i,i) = one/angs
       enddo
    case ('lattice_vectors')
       write(f_parsec,*) 'Atom coordinates input in lattice vector units'
       if (.not. pbc%is_on) then
          write(f_parsec,*) ' ERROR: this is not a periodic system'
          write(f_parsec,*) ' Lattice vectors not defined. STOP.'
          ierr = 131
          return
       endif
       cscale = lattvec
       do i = pbc%per + 1, 3
          write(f_parsec,*) ' Warning, lattice_vectors flag does NOT affect coordinates on non-periodic direction',i
          cscale(i,i) = one
       enddo
  
    case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: unknown coordinate_unit: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 132
       return
    end select
    write(f_parsec,*)
  
    clust%type_num = naty
    allocate (clust%natmi (naty))
    allocate (clust%name (naty))
    allocate (clust%ppfile (naty))
    allocate (clust%ylmdos_cutoff (naty))
  
    ! creating the pseudo_potential module
    i = norder/2
    call create_pseudo_potential (naty,i,p_pot)
    p_pot%nlocp = 0
    p_pot%eleatm(:,:) = zero
  
    ! read in minimization data
    strflag = esdf_reduce(esdf_string ('Minimization', 'none'))
  
    select case (trim(strflag))
    case ('none')
       move%name = OPTNONE
    case ('simple')
       move%name = STEEPDESC
       write(f_parsec,*) 'WARNING - simple steepest descent is not recommended'
       write(f_parsec,*) 'WARNING - relaxation method will probably not work!'
    case ('bfgs')
       move%name = BFGS
    case ('manual')
       move%name = MANUAL
    case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: unknown minimization method: ',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 133
       return
    end select
  
    ! For each atom type:
    natom = 0
    do ity = 1,naty
       ! read name and core cutoff
       clust%name(ity) = esdf_string ('Atom_Type', string_default)
       write(f_parsec,'(/,a,a)') ' Chemical element : ',trim(clust%name(ity))
  
       strflag = esdf_reduce(esdf_string ('Pseudopotential_Format','martins_new'))
  !ccm
       write(f_parsec,*) strflag
  !ccm
  
       select case (trim(strflag))
       case ('martins_old')
          p_pot%format(ity) = MARTINS_OLD
          write(f_parsec,*) ' pseudopotential format : old Martins'
          default_ppfile = trim(clust%name(ity))//'_POTR.DAT'
       case ('martins_new')
          p_pot%format(ity) = MARTINS_NEW
          write(f_parsec,*) ' pseudopotential format : new Martins'
          default_ppfile = trim(clust%name(ity))//'_POTRE.DAT'
       case ('martins_wang')
          p_pot%format(ity) = MARTINS_WANG
          write(f_parsec,*) ' pseudopotential format : Martins-Wang'
          default_ppfile = trim(clust%name(ity))//'_POTRW.DAT'
       case ('fhipp')
          p_pot%format(ity) = FHIPP
          write(f_parsec,*) ' pseudopotential format : FHIPP'
          default_ppfile = trim(clust%name(ity))//'_FHIPP.DAT'
       case default
          write(f_parsec,*) ' Unknown pseudopotential format :',trim(strflag)
          ierr = 134
          return
       end select
  
       ! read pseudopotential file path
       clust%ppfile(ity) = esdf_string ('pseudopot_file', default_ppfile)
  
       write(f_parsec,'(/,a,a)') ' Pseudopotential file : ',trim(clust%ppfile(ity))
  
       ! does this atom type have spin-orbit psp?
       p_pot%so(ity) = esdf_boolean ('SO_PSP',.false.)
       if (p_pot%format(ity) == FHIPP .and. p_pot%so(ity)) then
          write(f_parsec,*) ' ERROR: FHIPP pseudopotential is input for '
          write(f_parsec,*) ' atom type ',clust%name(ity),' and spin-orbit'
          write(f_parsec,*) ' is enabled for this atom. But FHIPP does not'
          write(f_parsec,*) ' have support for spin-orbit potentials! STOP'
          ierr = 135
          return
       endif
  
       ! should the valence charge be read from psp for this atom type?
       p_pot%rvcd(ity) = esdf_boolean ('Read_VCD',.false.)
       if (p_pot%format(ity) /= MARTINS_NEW .and. p_pot%rvcd(ity)) then
          write(f_parsec,*) ' ERROR: check the type of pseudopotential    '
          write(f_parsec,*) ' atom type ',clust%name(ity)
          write(f_parsec,*) ' Can not read valence charge density from file'
          ierr = 234
          return
       endif
  
       ! Local component, read for all formats except Martins-Wang
       if ( p_pot%format(ity) /= MARTINS_WANG ) then
          locstr = esdf_reduce(esdf_string('Local_Component',string_default))
  
          if(locstr == 's') then
             p_pot%loc(ity) = 1
          else if (locstr == 'p') then
             p_pot%loc(ity) = 2
          else if (locstr == 'd') then
             p_pot%loc(ity) = 3
          else if (locstr == 'f') then
             p_pot%loc(ity) = 4
          else
             write(f_parsec,*)
             write(f_parsec,*) 'ERROR: problem with atom type', ity
             write(f_parsec,*) 'Impossible local pseudopotential'
             write(f_parsec,*) 'Must be s, p, d, or f'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 136
             return
          endif
       endif
       !
       ! Other parameters for this atom type: core cut-off radius,
       ! number of psp channels, number of electrons per pseudo-orbital.
       ! Read for formats Martins_old and FHIPP only.
       !
       if ( p_pot%format(ity) == MARTINS_OLD .or. &
            p_pot%format(ity) == FHIPP ) then
       p_pot%nlocp(ity) =  esdf_integer ('Potential_Num',integer_default)
       endif
       if ( p_pot%format(ity) == MARTINS_OLD .or. &
            p_pot%format(ity) == MARTINS_WANG .or. &
            p_pot%format(ity) == FHIPP ) then
          p_pot%rcore(ity) = esdf_physical ('Core_Cutoff_Radius', &
               double_default,'bohr')
       endif
       if ( p_pot%format(ity) == MARTINS_OLD .or. &
            p_pot%format(ity) == FHIPP ) then
          if (esdf_block('Electron_Per_Orbital',nlines)) then
             if ( nlines /= 1) then
                write(f_parsec,*) 'ERROR: there should be only one line '
                write(f_parsec,*) 'in the "Electron_Per_Orbital" block'
                write(f_parsec,*) 'STOP in usrinput'
                ierr = 137
                return
             endif
             read (block_data(nlines),*) &
                  (p_pot%eleatm(ity,itmp),itmp=1,p_pot%nlocp(ity))
          else
             write(f_parsec,*) 'Cannot find #electrons/orbital block'
          endif
       endif
       !
       ! FHIPP format also need the non-linear core correction flag to
       ! be specified.
       !
       if ( p_pot%format(ity) == FHIPP ) then
          lflag = esdf_boolean('Nonlinear_Core_Correction' ,boolean_default)
          if (lflag) then
             p_pot%icore(ity) = 1
          else
             p_pot%icore(ity) = 0
          endif
       endif
       !
       ! Test sanity of pseudopotential parameters.
       ! Martins_old and FHIPP formats only.
       !
       if ( p_pot%format(ity) == MARTINS_OLD .or. &
            p_pot%format(ity) == FHIPP ) then
          if ((p_pot%nlocp(ity) <= 0) .or. (p_pot%nlocp(ity) > 4)) then
             write(f_parsec,*)
             write(f_parsec,*) 'ERROR: problem with atom type', ity
             write(f_parsec,*) 'impossible number of potentials! ',p_pot%nlocp(ity)
             write(f_parsec,*) 'STOP in usrinput.'
             ierr = 138
             return
          endif
          if (p_pot%loc(ity) > p_pot%nlocp(ity)) then
             write(f_parsec,*)
             write(f_parsec,*) 'ERROR: problem with atom type', ity
             write(f_parsec,*) 'local pseudopot. beyond # of components'
             write(f_parsec,*) 'STOP in usrinput.'
             ierr = 139
             return
          endif
       endif
  
       ! read initial spin polarization; this is used only in spin-polarized
       ! calculations and when not restating from previous charge density.
       dtmp = 0.1
       p_pot%spol(ity) = esdf_double('Initial_Spin_Polarization',dtmp)
  
       !this is now only available for pbc
       if(pbc%is_on) then
       ! read parameters for Fourier filtering of pseudopotentials and
       ! core charge (if it exists)
       dtmp = zero
       p_pot%alpha(ity) = esdf_double ('Alpha_filter', dtmp)
       dtmp = zero
       p_pot%beta1(ity) = esdf_double ('Beta1_filter', dtmp)
       dtmp = p_pot%alpha(ity)
       p_pot%acore(ity) = esdf_double ('Core_filter', dtmp)
       endif
  
       ! Use cubic spline interpolation for pseudopotentials?
       p_pot%uspline(ity) = esdf_boolean ('Cubic_spline', boolean_default)
       ! read number of atoms of this type
       nslctflg  = esdf_integer ('Move_Flag', integer_default)
       clust%ylmdos_cutoff(ity) = esdf_physical ('ylm_dos_cutoff',one,'bohr')
       ! read their coordinates
       if (esdf_block ('Atom_Coord',clust%natmi(ity) )) then   
          if(nslctflg > clust%natmi(ity)) then
             write(f_parsec,*)
             write(f_parsec,*) 'ERROR: invalid move_flag value: ',nslctflg
             write(f_parsec,*) 'STOP in usrinput.'
             ierr = 140
             return
          end if
          i = supercell(1) * supercell(2) * supercell(3)
          write(f_parsec,12) clust%natmi(ity)*i, clust%name(ity)
          write(f_parsec,*) 'and their initial coordinates are:'
          write(f_parsec,*)
          write(f_parsec,16)
  
          do i = 1, clust%natmi(ity)
             natom = natom + 1
             atype(natom) = ity
             if (natom > maxatm) then
                write(f_parsec,*) ' ERROR: too many atoms in input! ', &
                     natom,maxatm,' Increase maxatm in usrinput. '
                ierr = 141
                return
             endif
             if (nslctflg == 0) then
                read(block_data(i),*) acoord(:,natom)
                tmove(natom) = 1
             else if (nslctflg > 0) then
                read(block_data(i),*) acoord(:,natom)
                if (i <= nslctflg) then 
                   tmove(natom)=1
                else
                   tmove(natom)=0
                endif
             else
                if ( (move%name == OPTNONE) .and. &
                     ( .not.(mol_dynamic%is_on) ) )  then
                   read (block_data(i),*) acoord(:,natom)
                   tmove(natom)=1
                else
                   read (block_data(i),*) acoord(:,natom),tmove(natom)
                endif
                if((tmove(natom) /= 0) .and. (tmove(natom) /= 1))then
                   write(f_parsec,*)
                   write(f_parsec,*) 'ERROR: invalid atom movement index: ',tmove(natom)
                   write(f_parsec,*) 'STOP in usrinput'
                   ierr = 142
                   return
                endif
             endif
             call matvec3('N',cscale,acoord(:,natom),vtmp)
             ! If multiple periodic cells are defined in a super-cell, augment
             ! number of atoms.
             if (supercell(1) * supercell(2) * supercell(3) /= 1) then
                jj = tmove(natom)
                natom = natom - 1
                select case(pbc%per)
                case(1)
                   do i1 = 0, supercell(1) - 1
                      natom = natom + 1
                      acoord(:,natom) = vtmp + real(i1,dp)*lattvec(:,1)
                      tmove(natom) = jj
                      write(f_parsec,18) acoord(:,natom),tmove(natom)
                   enddo
        case(2)
   do i1 = 0, supercell(1) - 1
                      do i2 = 0, supercell(2) - 1
         natom = natom + 1
         acoord(:,natom) = vtmp + &
              real(i1,dp)*lattvec(:,1) + &
                              real(i2,dp)*lattvec(:,2)
         tmove(natom) = jj
                         write(f_parsec,18) acoord(:,natom),tmove(natom)
                      enddo
                   enddo
                case(3)
                   do i1 = 0, supercell(1) - 1
                      do i2 = 0, supercell(2) - 1
                         do i3 = 0, supercell(3) - 1
                            natom = natom + 1
                            acoord(:,natom) = vtmp + &
                                 real(i1,dp)*lattvec(:,1) + &
                                 real(i2,dp)*lattvec(:,2) + &
                                 real(i3,dp)*lattvec(:,3)
                            tmove(natom) = jj
                            write(f_parsec,18) acoord(:,natom),tmove(natom)
                         enddo
                      enddo
                   enddo
                end select
             else
                acoord(:,natom) = vtmp
                write(f_parsec,18) acoord(:,natom),tmove(natom)
             endif
          enddo
          clust%natmi(ity) = clust%natmi(ity) * supercell(1) * &
               supercell(2) * supercell(3)
       else
          write(f_parsec,*) 'ERROR: no atom coordinates were found'
          write(f_parsec,*) 'for atom type ', clust%name(ity)
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 143
          return
       endif
       ! read parameters for the LDA+U (if applicable)
       ! assume LDA+U only for d channel (lp1 = 3)
       p_pot%uu(:,ity) = zero
       p_pot%jj(:,ity) = zero
       p_pot%uu(3,ity) = esdf_physical ('ldaplusu_u',double_default,'ry')
       p_pot%jj(3,ity) = esdf_physical ('ldaplusu_j',double_default,'ry')
       if (abs(p_pot%uu(3,ity)) > twomach_eps .or. abs(p_pot%jj(3,ity)) > twomach_eps) &
           write(f_parsec,'(/,a,f10.3,a,f10.3,a)') ' LDA+U parameters : U = ', &
           p_pot%uu(3,ity)*rydberg,' eV   J = ',p_pot%jj(3,ity)*rydberg,' eV'
  
    enddo                     !do ity = 1,naty
  12 format(1x,'There are ', i6, 1x, a2, 1x, 'atoms')
  16 format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]',5x,'movable?')
  18 format(3(f15.9,3x),3x,i1)
  
    ! Does any chemical element have spin-orbit?
    p_pot%is_so = .false.
    do ity = 1, naty
       if (p_pot%so(ity)) p_pot%is_so = .true.
    enddo
    if (p_pot%is_so) then
        !AJB: please explain why hcub==sqrt(hcub)
       p_pot%so_hcub = sqrt(grid%hcub)
       write(f_parsec,'(a,/)')'  Spin-Orbit corrected computation!'
       if(pbc%per > 0) then
           write(f_parsec,'(a,/)')'  WARNING: I have used the input grid parameter to setup parameters for SO, &
              &but the actual grid parameter COULD be modified by PARSEC below'
       endif
  !     elec_st%mxwd = 1
    endif
    so_start = .false.
    ! read spin-orbit flag for scf (default is perturbation theory)
    elec_st%scf_so = esdf_boolean ('SCFSO',boolean_default)
    if (elec_st%scf_so) write(f_parsec,'(a,/)') &
         ' Self-Consistent Spin-Orbit Correction!'
    allocate (p_pot%rws(naty))
    p_pot%rws(:) = zero
    do ity = 1, naty
       p_pot%rws(ity) = esdf_double('Atomic_Radius',double_default)
    enddo
  
    ! read spin-orbit flag for spinor representation from scratch
      elec_st%ncl =  esdf_boolean ('Non_Collinear_magnetism',.false.)
      if (elec_st%ncl) then
         elec_st%nspin = 2
         elec_st%mxwd = 2
         elec_st%cplx = .true.
         write(f_parsec,'(a,/)') 'Performing Non-Collinear Clculation!'
         if(elec_st%scf_so .or. p_pot%is_so) so_start = .true.
         allocate(initmag(3,maxatm))
         initmag = zero
         natm = 0
         allocate(elec_st%init_mag(3,maxatm))
         elec_st%init_mag(:,:) = zero
         do ity = 1,naty
            if (esdf_block ('Initial_NCL_Moment',clust%natmi(ity) )) then
               do i = 1, clust%natmi(ity)
                  natm = natm + 1
                  read(block_data(i),*) initmag(:,natm)
                  tmp = sqrt(dot_product(initmag(:,natm),initmag(:,natm)))
                  elec_st%init_mag(:,natm) = initmag(:,natm)/tmp
               enddo
            endif
         enddo
      endif
    ! read spin-orbit flag for spinor representation from scratch
    so_start = esdf_boolean ('SO_from_scratch',so_start)
    if (so_start) then
      elec_st%cplx = .true.
      elec_st%nspin = 2
      elec_st%scf_so = .true.
      elec_st%mxwd = 2
      elec_st%is_so = .true.
      write(f_parsec,'(a,/)') 'Starting Self-Consistent Spin-Orbit Clculation!'
    else
      if(.not. elec_st%ncl) elec_st%mxwd = 1
      !AJB: Nowhere in the code is elec_st%is_so set to false so I put it here for now
      elec_st%is_so= .false.
    endif
  
    nstate = nstate*elec_st%mxwd
  
    ! Make sure there are atoms with spin-orbit if p_pot%is_so = .true.
    if (p_pot%is_so) then
       lflag = .false.
       do ity = 1, naty
          if (p_pot%so(ity)) lflag = .true.
       enddo
       if (.not. lflag) then
          write(f_parsec,*) ' WARNING: spin-orbit interaction is enabled but'
          write(f_parsec,*) ' there are no atom types with spin-orbit potential'
          p_pot%is_so = .false.
       endif
    endif
  
    ! if (solver%name == TRLANC) then
    !    if (p_pot%is_so) then
    !       write(f_parsec,*) 'ERROR: eigensolver TRLANC not available with spin-orbit.'
    !       write(f_parsec,*) 'Chose a different one...'
    !       ierr = 144
    !       return
    !    endif
    ! endif
  
    ! creating the 'empty' cluster
    if( naty > 0  ) then
        call create_cluster (natom,clust)
        clust%mvat(1:natom) = tmove(1:natom)
        clust%xatm(1:natom) = acoord(1,1:natom)
        clust%yatm(1:natom) = acoord(2,1:natom)
        clust%zatm(1:natom) = acoord(3,1:natom)
        clust%atype(1:natom) = atype(1:natom)
  
        deallocate(tmove)
        deallocate(acoord)
        if (allocated(initmag)) deallocate(initmag)
        write(f_parsec,'(/,a,i7,/)') ' Tot. number of atoms = ', clust%atom_num
    endif
    ! read in point charge flag
    clust%has_ptchrg = esdf_boolean ('Add_Point_Charges',boolean_default)
  
    if (clust%has_ptchrg) then
       if (pbc%is_on) then
          write(f_parsec,*) 'ERROR: support for point charges is only available in'
          write(f_parsec,*) 'non-periodic systems. STOP in usrinput'
          ierr = 145
          return
       endif
       allocate(acoord(3,maxatm))
       write(f_parsec,*) 'Point Charge data:'
       write(f_parsec,*) '------------------'
       !  read in and write number of atom types
       npttyp = esdf_integer('Point_Typ_Num',integer_default)
       if (npttyp == integer_default) then
          write(f_parsec,*) 'ERROR: unknown number of point charge types. '
          write(f_parsec,*) ' Input line "Point_Typ_Num" not found!'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 146
          return
       endif
       write(f_parsec,*) 'Tot. # of point charge types is ', npttyp
       clust%npttyp = npttyp
       allocate (clust%nptt (npttyp))
       allocate (clust%qpt (npttyp))
  
       !   For each point charge type:
       nptchrg = 0
       do ipttyp = 1,npttyp
          ! read amount of charge per type
          clust%qpt(ipttyp) = esdf_physical('Pt_Chg',double_default,'e')
          ! read coordinates
          if (esdf_block ('Point_Coord',clust%nptt(ipttyp) )) then
             write(f_parsec,22) clust%nptt(ipttyp), clust%qpt(ipttyp)
             write(f_parsec,*) 'and their coordinates are:'
             write(f_parsec,*)
             write(f_parsec,26)
             do i=1,clust%nptt(ipttyp)
                nptchrg = nptchrg + 1
                if (nptchrg > maxatm) then
                   write(f_parsec,*) 'ERROR: too many point charges in input! ', &
                        'Increase maxatm in usrinputfile. '
                   ierr = 147
                   return
                endif
                read(block_data(i),*) acoord(:,nptchrg)
                call matvec3('N',cscale,acoord(:,nptchrg),vtmp)
                acoord(:,nptchrg) = vtmp
                write(f_parsec,18) acoord(:,nptchrg)
             enddo
          else
             write(f_parsec,*) 'ERROR: no point charge coordinates were found'
             write(f_parsec,*) 'for point charge type ', ipttyp
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 148
             return
          endif
       enddo
  
  22   format(1x,'There are',1x,i4,1x,'point charges with charge ',f5.2,' e')
  26   format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]')
  
       ! create appropriate arrays in cluster structure
       allocate (clust%xpt (nptchrg))
       allocate (clust%ypt (nptchrg))
       allocate (clust%zpt (nptchrg))
  
       clust%xpt(1:nptchrg) = acoord(1,1:nptchrg)
       clust%ypt(1:nptchrg) = acoord(2,1:nptchrg)
       clust%zpt(1:nptchrg) = acoord(3,1:nptchrg)
  
       clust%nptchrg = nptchrg
  
       write(f_parsec,*)
       write(f_parsec,'(a,i4,/)') ' Tot. number of point charges = ',nptchrg
       deallocate(acoord)
    endif ! end point charges
  
    ! read in charged sheet flag
    clust%has_charged_sheet = esdf_boolean ('add_charged_sheets',boolean_default)
  
    if (clust%has_charged_sheet) then
       if (pbc%per /= 2 ) then
          write(f_parsec,*) 'ERROR: support for charged sheets is only available in'
          write(f_parsec,*) '2-D (slab) systems. STOP in usrinput'
          ierr = 145 !TODO: choose a different error number
          return
       endif
       allocate(acoord(3,maxatm))
       write(f_parsec,*) 'Charged sheet data:'
       write(f_parsec,*) '------------------'
       !  read in and write number of charged sheet types
       number_charged_sheet_type = esdf_integer('num_charged_sheets',integer_default)
       if (number_charged_sheet_type == integer_default) then
          write(f_parsec,*) 'ERROR: unknown number of charged sheets. '
          write(f_parsec,*) ' Input line "num_charged_sheets" not found!'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 146 !TODO: choose a different error number
          return
       endif
       write(f_parsec,*) 'Tot. # of charged sheets is ', number_charged_sheet_type
       clust%number_charged_sheet_type = number_charged_sheet_type
       allocate (clust%number_charged_sheets_per_type (number_charged_sheet_type))
       allocate (clust%sheet_charge_of_type (number_charged_sheet_type))
  
       !   For each charged sheet type:
       number_charged_sheets = 0
       do icharged_sheet_type = 1,number_charged_sheet_type
          ! read amount of charge per type
          clust%sheet_charge_of_type(icharged_sheet_type) = esdf_physical('sheet_charge',double_default,'e')
          ! read coordinates
          if (esdf_block ('Sheet_Coord',clust%number_charged_sheets_per_type(icharged_sheet_type) )) then
             write(f_parsec,10022) clust%number_charged_sheets_per_type(icharged_sheet_type), &
                clust%sheet_charge_of_type(icharged_sheet_type)
             write(f_parsec,*) 'and their coordinates are:'
             write(f_parsec,*)
             write(f_parsec,10026)
             do i=1,clust%number_charged_sheets_per_type(icharged_sheet_type)
                number_charged_sheets = number_charged_sheets + 1
                if (number_charged_sheets > maxatm) then
                   write(f_parsec,*) 'ERROR: too many charged sheets in input! ', &
                        'Increase maxatm in usrinputfile. '
                        ierr = 147 !TODO choose a different error number 
                   return
                endif
                read(block_data(i),*) acoord(:,number_charged_sheets)
                call matvec3('N',cscale,acoord(:,number_charged_sheets),vtmp)
                acoord(:,number_charged_sheets) = vtmp
                write(f_parsec,18) acoord(:,number_charged_sheets)
             enddo
          else
             write(f_parsec,*) 'ERROR: no charged sheet coordinates were found'
             write(f_parsec,*) 'for sheet charge number: ', icharged_sheet_type
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 148 !TODO choose a different error number
             return
          endif
       enddo
  
  10022   format(1x,'There are',1x,i4,1x,'charged sheets with charge ',f5.2,' e')
  10026   format(4x,'x [bohr]',10x,'y [bohr]',10x,'z [bohr]')
  
       ! create appropriate arrays in cluster structure
  !     allocate (clust%x_charged_sheets (number_charged_sheets))
  !     allocate (clust%y_charged_sheets (number_charged_sheets))
       allocate (clust%z_charged_sheets (number_charged_sheets))
  
  !     clust%x_charged_sheets(1:number_charged_sheets) = acoord(1,1:number_charged_sheets)
  !     clust%y_charged_sheets(1:number_charged_sheets) = acoord(2,1:number_charged_sheets)
       clust%z_charged_sheets(1:number_charged_sheets) = acoord(3,1:number_charged_sheets)
  
       clust%number_charged_sheets = number_charged_sheets
  
       write(f_parsec,*)
       write(f_parsec,'(a,i4,/)') ' Tot. number of charged sheets = ',number_charged_sheets
       deallocate(acoord)
    endif ! end charged sheets
  
    ! Read in spin polarization flag.
    lflag = esdf_boolean ('Spin_Polarization', boolean_default)
    if (lflag) then
       nspin = 2
    else
       nspin = 1
    endif
  
    ! Read in correlation type. Default spin-polarized functional is
    ! LSDA Perdew-Wang. Default non-spin-polarized functional is
    ! LDA Perdew-Zunger.
  
    write(f_parsec,*) 'Correlation data:'
    write(f_parsec,*) '-----------------'
    strflag = esdf_reduce(esdf_string ('Correlation_Type','xx'))
    if (trim(strflag) == 'xx') then
       if (nspin == 2) then
          strflag = 'pl'
       else
          strflag = 'ca'
       endif
    endif
  
    select case (trim(strflag))
    case ('xa')
       icorr = 'xa'
       write(f_parsec,20) icorr,'LDA, Slater x-alpha'
    case ('wi')
       icorr = 'wi'
       write(f_parsec,20) icorr,'LDA, Wigner interpolation'
    case ('hl')
       icorr = 'hl'
       write(f_parsec,20) icorr,'LDA, Hedin-Lundqvist'
    case ('ca','pz','lda')
       icorr = 'ca'
       write(f_parsec,20) icorr,'LDA, Ceperley-Alder, Perdew-Zunger parametrization'
    case ('pl','pw92','pwlda')
       icorr = 'pl'
       write(f_parsec,20) icorr,'LDA, Perdew-Wang parametrization'
    case ('pw','pw91','pwgga')
       icorr = 'pw'
       write(f_parsec,20) icorr,'GGA, Perdew-Wang parametrization'
    case ('pb','pbe')
       icorr = 'pb'
       write(f_parsec,20) icorr,'GGA, Perdew-Burke-Ernzerhof parametrization'
    case ('lb')
       icorr = 'lb'
       write(f_parsec,20) icorr,'ACLDA, Leeuwen-Baerends correction'
    case ('cs')
       icorr = 'cs'
       write(f_parsec,20) icorr,'ACLDA, Casida-Salahub correction'
       ! read-in the ionization energy difference (actually used 
       ! only with 'cs' corr.)
       dtmp = 0.d0
       dioniz = esdf_physical('Ion_Energy_Diff', dtmp,'ry')
       write(f_parsec,'(a,f7.4,a)') ' Ionization energy difference is: ',dioniz, ' Ry'
    case default
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: unknown correlation type:',trim(strflag)
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 149
       return
    end select
  20 format(1x,'Exchange-Correlation functional is',1x,a2,/,1x,a)
    write(f_parsec,*) 
  !!! VDW PART
    do_vdw=esdf_boolean('Van_Der_Waals' , boolean_default)
    if (do_vdw) then
    write(f_parsec,*)'including Tkatchenko-Scheffler dispersion correction!'
        if (icorr /='pb') then
            write(f_parsec,*)'Error, the TS correction implemented only for GGA-PBE functional!'
            ierr = 158
            return
        end if
        if (.NOT.ignoresym) then
            write(f_parsec,*)'Error, for the TS correction symmetry has to be switched off'
            ierr = 159
            return
        end if
        if (pbc%is_on) then
            if (pbc%per/=3) then
                write(f_parsec,*)'Error, in this version the TS correction implemented only for 3D periodic boundary conditions (sorry)'
                ierr = 160
                return
            end if      
            write(f_parsec,*)'TS-VDW: with periodic calculation'
            itmp = 0
            hirsh_cell_one = esdf_integer('Hf_One' , itmp)
            hirsh_cell_two = esdf_integer('Hf_Two' , itmp)
            hirsh_cell_three = esdf_integer('Hf_Three' , itmp)
  
            hirsh_cell_total(1,1)=hirsh_cell_one
            hirsh_cell_total(1,2)=hirsh_cell_two
            hirsh_cell_total(1,3)=hirsh_cell_three
            write(f_parsec,*)'Got the following Hf parameters:'
            write(f_parsec,*) hirsh_cell_total
            write(f_parsec,*)'The numbers for the Hf cells are: 2*(Hf_One, Hf_Two, Hf_Three)+1 '
            write(f_parsec,*) hirsh_cell_one*2+1, hirsh_cell_two*2+1,hirsh_cell_three*2+1
            write(f_parsec,*)'Note: The thresold for the TS energy component is 10^-6 [eV]'
        else
            hirsh_cell_total(:,:)=0
        end if
    else
    !    write(f_parsec,*)'Note: The calculation does not include dispersion corrections.'
    end if  
  
    itmp = 0
  !!! END VDW PART

  inputs%calculate_force = esdf_boolean('Calculate_force', inputs%calculate_force)

    write(f_parsec,*) 'Other input data:'
    write(f_parsec,*) '-----------------'
  
    !check to see that data output is enabled
    enable_data_out = esdf_boolean ( 'Output_Data', .TRUE. )
  
    if( .NOT. enable_data_out) then
       write(f_parsec,*) 'NOTICE: Raw Data output has been completely disabled'
       write(f_parsec,*) 'NOTICE: All other output flags but GW will be ingnored'
    endif
  
    inputs % use_hdf5 = esdf_boolean('use_hdf5', .FALSE.)

#ifdef USE_HDF5
    if (inputs % use_hdf5) then
        write (7, *) 'use_hdf5 is on'
    else
        write (7, *) 'use_hdf5 is off'
    endif
#else
    if (inputs % use_hdf5) then
        write (7, *) 'NOTICE: Not compiled with -DUSE_HDF5'
    endif
#endif

    ! read in output flag: 
    outflag = 0
    outputallstates = esdf_boolean ('Output_All_States', boolean_default)
    if (outputallstates)  then
       ! save all eigenvectors to disk
       outflag = outflag + 1
       elec_st%nsave = nstate*elec_st%mxwd
       allocate(elec_st%indxsave(elec_st%nsave))
       do i = 1, elec_st%nsave
          elec_st%indxsave(i) = i
       enddo
       write(f_parsec,*) 'Writing all calculated ','wave functions to parsec.dat file'
    else
       ! read in set of eigenvectors to be written to disk
       if (esdf_block('save_wfn_bands',nlines)) then
          if (nlines == 0) then
             elec_st%nsave = 0
          elseif (nlines == 1) then
             read(block_data(1),*,iostat = ierr) ilow, iup
             if (ierr == 0) then
                elec_st%nsave = iup - ilow + 1
                allocate(elec_st%indxsave(elec_st%nsave))
                do i = ilow, iup
                   elec_st%indxsave(i - ilow + 1) = i
                enddo
             else
                elec_st%nsave = nlines
                allocate(elec_st%indxsave(nlines))
                do i = 1, nlines
                   read(block_data(i),*,iostat = ierr) elec_st%indxsave(i)
                enddo
             endif
          else
             elec_st%nsave = nlines
             allocate(elec_st%indxsave(nlines))
             do i = 1, nlines
                read(block_data(i),*,iostat = ierr) elec_st%indxsave(i)
             enddo
          endif
          if (elec_st%nsave > 0) then
             write(f_parsec,*) 'Writing ',elec_st%nsave, &
                  ' selected wave functions to parsec.dat file:'
             write(f_parsec,'(10i6)') elec_st%indxsave(1:elec_st%nsave)
          else
             write(f_parsec,*) 'No wave functions are written to  parsec.dat file'
          endif
          if (ierr /= 0) then
             write(f_parsec,*) 'ERROR: bad specification of "Save_Wfn_Bands" block!'
             write(f_parsec,*) 'STOP in usrinput.'
             ierr = 150
             return
          endif
       else
          ! save only eigenvectors of occupied levels to disk
          elec_st%nsave = -1
          write(f_parsec,*) 'Writing only wave functions of occupied levels ', &
               'to parsec.dat file'
       endif
    endif
    write(f_parsec,*)
  
    outputgw = esdf_boolean ('Output_GW', boolean_default)
    if (outputgw) then
#ifdef GW
       write(f_parsec,*) 'Writing files for GW calculation using BerkeleyGW'
#else
       write(f_parsec,*) 'Please recompile the code with -DGW flag to enable this'
       write(f_parsec,*) 'and link it to appropriate libraries from BerkeleyGW'
       write(f_parsec,*) 'STOP in usrinput.'
       ierr = 150
       return
#endif
       if (nscf%nscf_on) then
        if(esdf_block('nscf_kgrid',nlines))then
         if(nlines /= 1) then
            write(f_parsec,*) ' error in specifying kgrid for nscf calc: ',nlines
            write(f_parsec,*) ' STOP in usrinput'
            ierr = 114
            return
          endif
        nscf%kgrid = 1
       read(block_data(nlines),*,iostat=ierr) &
            (nscf%kgrid(i), i = 1, 3)
        write(f_parsec,*) ' Non-self consistent kgrid dimensions'
        write(f_parsec,37) (nscf%kgrid(i), i = 1, 3)
       else
        write(f_parsec,*) ' Have to specify nscf_kgrid'
        write(f_parsec,*) ' STOP in usrinput'
        ierr = 114
        return
       endif
       if(esdf_block('nscf_kgrid_shift',nlines))then
         if(nlines /= 1) then
            write(f_parsec,*) ' error in specifying Monkhorst-Pack Shift'
            write(f_parsec,*) ' STOP in usrinput'
            ierr = 116
            return
         endif
       nscf%kshift = zero
       read(block_data(nlines),*,iostat=ierr) &
            (nscf%kshift(i), i = 1, 3)
       if((ierr /= 0) .or. (nscf%kshift(1) < 0) .or. &
          (nscf%kshift(2) < 0) .or. (nscf%kshift(3) < 0)) then
          write(f_parsec,*) ' error in specifying Monkhorst-Pack Shift'
          write(f_parsec,*) ' STOP in usrinput'
          ierr = 117
       endif
       write(f_parsec,*)' Non-selfconsistent kgrid shift'
       write(f_parsec,38) (nscf%kshift(i), i = 1, 3)
       else
        write(f_parsec,*) ' Have to specify nscf_kgrid_shift'
        write(f_parsec,*) ' STOP in usrinput'
        ierr = 114
        return
      endif
      elec_st%efermi = esdf_physical ('nscf_fermi_level',double_default,'Ry')
      if (elec_st%efermi == double_default) then
          write(f_parsec,*) 'ERROR: specification of Fermi level for'
          write(f_parsec,*) ' non self consistent calculation not found! '
          write(f_parsec,*) ' Please specify nscf_efermi taken from scf calculation '
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 114
          return
       endif
     endif
  
    endif
  
    lflag = boolean_default
    if (elec_st%nkpt > 0) then ! lflag = .true.
      write(f_parsec,*) 'Note - charge symmetrization is turned off by default.'
     endif
    chsym = esdf_boolean('Symmetrize_Charge_Density',lflag)
    if (chsym) write(f_parsec,*) 'Symmetrizing charge density according to symm.', &
         ' operations in the full point group'
  
    lflag = esdf_boolean ('Save_Intermediate_Charge_Density',boolean_default)
    if (lflag)  then
       write(f_parsec,*) 'Writing charge density to parsec.dat file after each ', &
            'step of SCF'
       write(f_parsec,*)
       outflag = outflag + 2
    endif
  
  
    if (nspin == 2) then
  
       write(f_parsec,'(a,/)') ' Spin-polarized computation!'
       write(f_parsec,*) 'Initial spin polarization: '
       do ity = 1, naty
          write(f_parsec,'(2x,a2,5x,f11.4)') clust%name(ity),p_pot%spol(ity)
       enddo
       write(f_parsec,*)
    else
       nspin = 1
       write(f_parsec,'(a,/)') ' No spin effects!'
       if (p_pot%is_so) then
          write(f_parsec,*) 'ERROR: spin-orbit requires spin polarized functional.'
          write(f_parsec,*) 'Must declare "spin_polarization .true." in parsec.in.'
          write(f_parsec,*) 'STOP'
          ierr = 151
          return
       endif
    endif
  
    p_pot % oldinpformat = esdf_boolean ('Old_Interpolation_Format',boolean_default)
    write(f_parsec,*)
    if (p_pot % oldinpformat) then
       write(f_parsec,*) 'Using old (direct) interpolation of pseudopot. !'
    else
       write(f_parsec,*) 'Using new (r*V_ps) interpolation of pseudopot. !'
    endif
  
    !
    ! Output level flag
    ipr = esdf_integer('Output_Level',integer_default)
    write(f_parsec,'(/,a,i2,/)') ' output level [1 - 6] = ',ipr
  
    !
    ! Grid data output flag
    flag_words = esdf_split(esdf_reduce(esdf_string ('output_grid_data', 'none')), &
           MAX_EXPORT_OPTS, ntmp)
    export_griddata_flag = OPTNONE
    i = 0
    do while (i < ntmp)
       i = i+1
       strflag = flag_words(i)
       select case (trim(strflag))
       case ('none')
          i = ntmp
       case ('charge_density')
          write(f_parsec,*) 'Writing total charge density to external file'
          write(f_parsec,*)
          export_griddata_flag(i) = CHGDENS
       case ('v_external')
          write(f_parsec,*) 'Writing external potential to external file'
          write(f_parsec,*)
          export_griddata_flag(i) = VEXT
       case ('v_hartree')
          write(f_parsec,*) 'Writing hartree potential to external file'
          write(f_parsec,*)
          export_griddata_flag(i) = VHAR
       case ('v_external+v_hartree')
          write(f_parsec,*) 'Writing sum of external and hartree potentials to external file'
          write(f_parsec,*)
          export_griddata_flag(i) = VEXTHAR
       case ('all')
          write(f_parsec,*) 'Writing charge density, external potential, hartree potentials and the sum of the two to external files'
          write(f_parsec,*)
          export_griddata_flag(1) = CHGDENS
          export_griddata_flag(2) = VEXT
          export_griddata_flag(3) = VHAR
          export_griddata_flag(4) = VEXTHAR
          i = ntmp
       case default
          write(f_parsec,*) 'Wrong input to output_grid_data: ',trim(strflag)
          write(f_parsec,*) 'STOP in usrinput.'
          ierr = 1001 !TODO: choose a different error number
          return
       end select
    enddo
  
    ! read in  eigenstate to separated file output  flag:
    ! .false. / .true.
    outevflag=0
    lflag = esdf_boolean ('Output_Eigenvalues', boolean_default)
  
    if (elec_st%nkpt > 0) lflag = .true.
  
    if (lflag) then
       outevflag = outevflag + 1
       write(f_parsec,*) 'Generating Eigenvalue Output File!' 
       lflag = esdf_boolean ('Output_All_States', boolean_default)
       if (outputallstates)  then
          write(f_parsec,*) 'Writing all calculated eigenvalues to eigen.dat'
          write(f_parsec,*)
          outevflag = outevflag + 1
       endif
       lflag = esdf_boolean ('Save_Intermediate_Eigenvalues',boolean_default)
       if (lflag)  then
          write(f_parsec,*) 'Writing eigenvalues to eigen.dat after each step of SCF'
          write(f_parsec,*)
          outevflag = outevflag + 2
       endif
    else
       write(f_parsec,*) 'No eigenvalue output File!'
    endif
    write(f_parsec,*) 'outevflag = ', outevflag
    write(f_parsec,*)
  
    if (move%name == OPTNONE) then
       move%is_on = .false.
       write(f_parsec,*) 'No minimization!'
    else
       move%is_on = .true.
    endif
  
    if (move%is_on) then
       itmp = 500
       move%mxmove = esdf_integer ('Movement_Num', itmp)
       dtmp = 1.d-2
       move%fmin = esdf_physical ('Force_Min', dtmp,'ry/bohr')
       stpmax = 0.05d0
       move%stepmax = esdf_physical ('Max_Step', stpmax,'bohr')
       dtmp = 1.d-4
       move%stepmin = esdf_physical ('Min_Step', dtmp,'bohr')
       move%is_restart = esdf_boolean ('relax_restart',boolean_default)
       !
       ! AJB: we no longer write out restart information unless requested
       ! This decision might be reversed in the future.
       move%write_restart = esdf_boolean ('write_relax_restart',boolean_default)
       !AJB: The accuracy is hard coded
       write(f_parsec,*) 'Minimization data:'
       write(f_parsec,*) '------------------'
       if (move%fmin < 1.d-5) then
          write(f_parsec,*) 'ERROR: minimum force below numerical accuracy'
          write(f_parsec,*) 'increase it to at least 1E-5'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 152
          return
       endif
       if (move%name == STEEPDESC) then
          write(f_parsec,*) 'Simple minimization!'
          write(f_parsec,*) 'This scheme is not robust!'
          write(f_parsec,*) 'make sure the construction of displacements ', &
               'in domove.f fits your purpose.'
          if (move%stepmax < 1.d-5) then
             write(f_parsec,*) 'ERROR: maximum step size too small!'
             write(f_parsec,*) 'increase it to at least 1E-5'
             write(f_parsec,*) 'STOP in usrinput'
             ierr = 153
             return
          endif
       else if (move%name == BFGS) then
          write(f_parsec,*) 'Limited-memory BFGS minimization!'
          dtmp = 0.d0
          itmp = 7
          move%mmax = esdf_integer ('BFGS_number_corr', itmp)
          if (move%stepmax == stpmax) then
             ! unrestricted BFGS, no bounds on atom coordinates
             move%stepmax  = -1.d0
          else
             ! restricted BFGS, move%stepmax defines the maximum displacement
             write(f_parsec,*) 'Restricted BFGS'
             write(f_parsec,*) 'Maximum displacement of atoms from initial ', &
                  'position is ',move%stepmax
             write(f_parsec,*) ' bohrs along each cartesian direction.'
          endif
       else if (move%name == MANUAL) then
          write(f_parsec,*) 'atoms move according to info in manual.dat'
          ! make all atoms movable
          clust%mvat = 1
          ! Set force limit to zero (this avoids undesirable outputs from
          ! subroutine domove).
          move%fmin = zero
       end if
       write(f_parsec,'(a,i4)') ' Maximum number of movements  = ',move%mxmove
       if (move%name == STEEPDESC) then
          write(f_parsec,91) ' Maximum step size  = ', move%stepmax
          write(f_parsec,91) ' Mininum step size  = ', move%stepmin
       endif
       if (move%name /= MANUAL) write(f_parsec,'(a,f8.5,a)') &
            ' Minimum force  = ',move%fmin, ' [Ry/au]'
       if (move%is_restart) then
          write(f_parsec,*) 'Restart relaxation, information on previous'
          write(f_parsec,*) 'runs read from relax_restart.dat file.'
       endif
       if (move%name == BFGS) write(f_parsec,'(a,a,i4)') ' Number of ', &
            'corrections used in LBFGS update = ',move%mmax
    end if
  
  91 format(a,f8.5,' [au]')
    write(f_parsec,*)
  
    ! read in LMD parameters
    ! initial and final temperatures (in kelvin), 
    ! step temperature for stair cooling
    ! # of step, cooling scheme (1 - stair, 2- linear, 3 - log)
    ! time step, friction coefficient, # of time steps
    strflag = esdf_reduce(esdf_string ('Cooling_Method','stair'))
  
    select case (trim(strflag))
    case ('stair')
       mol_dynamic%cool_type = MD_STAIR
    case ('linear')
       mol_dynamic%cool_type = MD_LINEAR
    case ('log')
       mol_dynamic%cool_type = MD_LOG
    case default
       write(f_parsec,*)  
       write(f_parsec,*)'ERROR: unkown molecular dynamics cooling scheme: ', &
            trim(strflag)
       write(f_parsec,*)'STOP in usrinput'
       ierr = 154
       return
    end select
  
    dtmp = 500.0d0
    mol_dynamic%tempi = esdf_physical ('Tinit', dtmp,'k')
    dtmp = 500.0d0
    mol_dynamic%tempf = esdf_physical ('T_Final', dtmp,'k')
    dtmp = 150.0d0
    mol_dynamic%step_tmp = esdf_physical ('T_Step', dtmp,'k')
  
    dtmp = 150.0
    mol_dynamic%time_step =  esdf_physical ('Time_Step', dtmp,'ps')
    mol_dynamic%friction_coef = esdf_double ('Friction_Coefficient', &
         double_default)
    itmp = 250
    mol_dynamic%step_num = esdf_integer ('Step_num', itmp)
    ! For debug purposes - fix the rng seed

    mol_dynamic%rng_seed = esdf_integer('mol_rng_seed', 0)
    mol_dynamic%use_test_rng = esdf_boolean ('test_rng',boolean_default)
  
    if (.not.  mol_dynamic%is_on) then
       write(f_parsec,*) 'No molecular dynamics!'
    else
       call molecular_dynamic_turn_on (mol_dynamic,clust%atom_num)
       mol_dynamic%is_restart = esdf_boolean('Restart_mode',boolean_default)
  
       write(f_parsec,*) 'Molecular dynamics data:'
       write(f_parsec,*) '-------------------------'
       if (mol_dynamic%is_restart) then
          write(f_parsec,*) 'WARNING: restarted molecular dynamics run'
          write(f_parsec,*) 'restart data assumed present in mdinit.dat'
       endif
       if (mol_dynamic%rng_seed > 0) then
          write(f_parsec,*) 'WARNING: running with user defined RNG seed: ' , mol_dynamic%rng_seed
       endif
       if (mol_dynamic%use_test_rng ) then
          write(f_parsec,*) 'WARNING: running with simple RNG engine ' 
           if (mol_dynamic%is_restart ) then
          write(f_parsec,*) 'MD restart will try to perserve RNG seed position'
           endif
       endif
  
       select case (mol_dynamic%cool_type)
       case (MD_STAIR)
          write(f_parsec,*) '"Stairstep" cooling scheme '
          write(f_parsec,'(a,f6.1,a)') ' Temperature step = ',mol_dynamic%step_tmp, &
          ' [K]'
          i = int((mol_dynamic%tempi-mol_dynamic%tempf) /mol_dynamic%step_tmp + 1)
          mol_dynamic%stride = mol_dynamic%step_num/i
          if (mol_dynamic%stride * i < mol_dynamic%step_num) &
               mol_dynamic%stride = mol_dynamic%stride + 1
          write(f_parsec,*) 'Temperature modified after ',mol_dynamic%stride, &
               ' iterations'
       case (MD_LINEAR)
          write(f_parsec,*) 'Linear cooling scheme '
       case (MD_LOG)
          write(f_parsec,*) 'Logarithmic cooling scheme '
       end select
  
       write(f_parsec,52) ' Initial Temperature = ', mol_dynamic%tempi
       write(f_parsec,52) ' Final Temperature = ', mol_dynamic%tempf
       write(f_parsec,'(a,f8.2,a,f6.4,a)') ' Time step = ' ,mol_dynamic%time_step, &
            ' [au] = ',mol_dynamic%time_step*timeaups,' [ps]'
       write(f_parsec,'(a,f8.5,a)') ' Friction Coefficient = ', &
            mol_dynamic%friction_coef,' [au]'
        if (mol_dynamic%friction_coef < 10d-6 ) then
            write(f_parsec,*) 'Small coefficient, doing MICROcanonical ensemble'
            write(f_parsec,*) ' '
        else
            write(f_parsec,*) 'Large coefficient, doing (MACRO)canonical ensemble'
            write(f_parsec,*) ' '
        endif
       write(f_parsec,'(a,i5)') ' Number of MD iterations = ',mol_dynamic%step_num
       write(f_parsec,*) ' '
    endif
  52 format(a,f6.1,' [K]')
  
    ! read in polarizability flag and electric field
    npolflg_tmp = esdf_boolean ('Polarizability', boolean_default)
    if (npolflg_tmp) then
       npolflg = 1
    else
       npolflg = 0
    endif
    dtmp = 0.001
    field = esdf_physical ('Electric_Field', dtmp,'ry/bohr/e')
    if (.not. npolflg_tmp) then
       npolflg = 0
       write(f_parsec,*) 'No polarizability!'
    else
       npolflg = 1
       write(f_parsec,*) 'Polarizability data:'
       write(f_parsec,*) '--------------------'
       write(f_parsec,*) 'Using seven-fields polarizability approach'
       write(f_parsec,'(a,f8.5,a)') ' Electric field  = ', field, ' [Ry/au]'
    endif
    write(f_parsec,*)
    !AJB: IMPORTANT
    ngroups = esdf_integer ('MPI_Groups', integer_default)
    !let's keep things simple, since the graph communicator is messed up
    ! if there are groups - RIGHT NOW
    ngroups = esdf_integer('MPI_Groups', 1)

    if (ngroups > 1) then
        if (.not. inputs % use_scalapack) then
            write(f_parsec, *) 'For now please turn on use_scalapck if you &
                    &want to use multiple MPI groups on one eig. job.'
            STOP
        end if
        if (mod(nstate, ngroups) /= 0) then
            write(f_parsec, *) 'nstate', nstate
            write(f_parsec, *) 'MPI_Groups', ngroups
            write(f_parsec, *) 'ERROR: Number of processes should be a multiple of MPI_Groups'
            STOP
        end if
    end if
  
    ! flag compatibility tests
    if((mol_dynamic%is_on) .or. (move%name /= OPTNONE)) then
       if (npolflg_tmp) then
          write(f_parsec,*)  
          write(f_parsec,*) 'ERROR: Cannot do polarizability and move atoms'
          write(f_parsec,*) 'set MD and Minimization Flags = 0'
          write(f_parsec,*) 'STOP in usrinput'
          ierr = 155
          return
       endif
    endif
  
    if (pbc%per>2 .and. npolflg_tmp) then
       write(f_parsec,*)
       write(f_parsec,*) 'ERROR: Cannot do polarizability with periodic'
       write(f_parsec,*) 'boundary conditions!'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 156
       return
    endif
  
    if((mol_dynamic%is_on) .and. (move%name /= OPTNONE)) then
       write(f_parsec,*)  
       write(f_parsec,*) 'ERROR: Cannot do minimization and MD'
       write(f_parsec,*) 'set either MD or minimization flag to zero'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 157
       return
    endif
  
    if((elec_st%mxwd == 2)) then
       write(f_parsec,*)  
       write(f_parsec,*) 'ERROR: SO type calculations with '
       write(f_parsec,*) 'the new matvec are not yet implemented. Sorry!'
       write(f_parsec,*) 'STOP in usrinput'
       ierr = 158
       return
    endif
  
  
    call esdf_close
  
    ! creating the 'empty' electronic_structure
    nstate = nstate 
    call create_electronic_struct (nspin,nstate,elec_st,elec_st%mxwd)
    !VDW:
    elec_st%do_vdw= do_vdw
    elec_st%hirsh_3d_cell = hirsh_cell_total
    elec_st%ncharge = ncharge 
    !
    elec_st%icorr = icorr
    if (icorr == 'cs') elec_st%dioniz = dioniz
    elec_st%tfermi = tfermi
  
    pot%nspin = nspin
  
    if (pbc%is_on) then
       call pbc_turn_on (natom,naty,pbc)
    endif
  
   
  end subroutine usrinput
  !===============================================================
  end module io_module
