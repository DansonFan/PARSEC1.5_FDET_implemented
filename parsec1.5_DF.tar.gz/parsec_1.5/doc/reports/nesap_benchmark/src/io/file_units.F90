!> \brief module providing file unit numbers
!> \author Charles Lena
!> \date 2017-01-18 : written 
!> \date 2017-01-21 : changed the enums to parameters because doxygen
!! doesn't do enums yet
module file_units
         integer, parameter :: f_parsec = 7 !< the parsec.out unit
         integer, parameter :: f_outpar = 9 !< the out.# unit specific to mpi processes
         integer, parameter :: f_timings = 9 !< the out.# unit specific to mpi processes
         integer, parameter :: f_relax = 45 !< relax_restart.dat
         integer, parameter :: f_bfgs = 46 !< bfgs.dat
         integer, parameter :: f_eigen = 61 !< eigen.dat
         integer, parameter :: f_atom = 66 !< atom.cor
         integer, parameter :: f_manual = 67 !< manual.dat
         integer, parameter :: f_mdinit = 76 !< mdinit.dat
         integer, parameter :: f_md_nrg = 78 !< md_nrg.dat
         integer, parameter :: f_md_mech = 79 !< md_mech.dat
         integer, parameter :: f_occup = 90 !< occup.in
         integer, parameter :: f_polar = 91 !< polar.dat
         integer, parameter :: f_movie = 92 !< movie.xyz
         integer :: all_file_units(1:13) = [ f_parsec, f_outpar, f_relax,&
            f_bfgs, f_eigen, f_atom, f_manual, f_mdinit, f_md_nrg, &
            f_md_mech, f_occup, f_polar, f_movie ]
end module file_units
