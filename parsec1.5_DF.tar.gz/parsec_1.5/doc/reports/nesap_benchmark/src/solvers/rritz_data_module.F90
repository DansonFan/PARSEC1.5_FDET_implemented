!> \brief modular contained data structure for the rayleigh_ritz problem
!> \author Charles Lena
!> \date Jan 2017
module rritz_data_module
   use constants, only : dp, dpc
#ifdef WITH_MPI_F08
   use mpi_f08, only : MPI_Comm
#endif

   !! logic values 
   integer, parameter :: k_rritz_force_none = 0 !< dont force logic
   integer, parameter :: k_rritz_force_custom = 1 !< force custom
   integer, parameter :: k_rritz_force_classic = 2 !< force classic
   integer, parameter :: k_rritz_force_dist1 = 3 !< force dist1 
   integer, parameter :: k_rritz_force_dist2 = 4 !< force dist2 
   integer, parameter :: k_rritz_force_distmixed = 5 !< force distmixed
   integer, parameter :: k_rritz_force_tiled = 6 !< force tiled
   !> \brief Describes the problem solved with rayleigh ritz approach of
   !! eigen solving:
   !! - \f$\hat H_{ij} = \Psi_i^{\*} H \Psi_j\f$
   !! - \f$\hat H W = W \Lambda\f$
   !! - \f$\hat \Psi = \Psi * W\f$
   type rritz_data
#ifdef WITH_MPI_F08
      type(MPI_Comm) :: comm_parallel !< parallel ops comm
      type(MPI_Comm) :: comm_elpa_blacs !< blacs comm for ELPA
      type(MPI_Comm) :: comm_ladder !< blacs comm for pseudorep of \f$\Psi\f$
#else
      integer :: comm_parallel !< parallel ops comm
      integer :: comm_elpa_blacs !< blacs comm for ELPA
      integer :: comm_ladder !< blacs comm for pseudorep of \f$\Psi\f$
#endif
      integer :: my_blacs_ctxt !< blacs context for ELPA
      integer :: ctxt_ladder !< blacs context for \f$\Psi\f$
      integer :: mpi_comm_rows!< communicator over rows - elpa generated
      integer :: mpi_comm_cols!< communicator over columns - elpa generated
      integer :: myid    !< my process id in the communicator for the purposes of the rayleigh ritz
      integer :: nprocs  !< number of processors
      integer :: np_rows !< number of process rows in my submatrix
      integer :: np_cols !< number of process columns in my submatrix
      integer :: na_rows !< number of rows in my submatrix
      integer :: na_cols !< number of columns in my submatrix
      integer :: my_prow !< my row pid
      integer :: my_pcol !< my column pid
      integer :: tile_cols!< tiled worker columns
      integer :: tile_rows!< tiled worker rows
      integer :: nprow !< number of processors in a row
      integer :: npcol !< number of processors in a col

      ! Input
      integer :: nwant !< how many eigenvalues we want - informs size of the global G / h-proj
      integer :: op_global !< my communicator for the parsec problem
      integer :: op_comm !< my communicator for the purposes of the rayleigh ritz
      integer :: lda !< \todo this description
      integer :: ldn !< leading dimension for the v_basis
      integer :: ndim !< the normal repeating unit for v_basis based on parallel % irows
      integer :: gndim !< Hamiltonian size
      integer :: nblk !< block cyclic repeat amount (should be at least 16, and most likely mod(nblk,16) == 0 )

      integer :: forced_logic


      !AJB: In intel inspector, 
      ! MKL is complaining in a way that makes me think these things need explict alignment?
#ifdef IS_ICC
      !DIR$ attributes align:64 :: dw_opv1d, zw_opv1d
      !DIR$ attributes align:64 :: dh_proj, zh_proj
      !DIR$ attributes align:64 :: dh_work, zh_work
      !DIR$ attributes align:64 :: dmatmul_tmp , zmatmul_tmp
#elif defined(IS_CRAY)
#elif defined(IS_GCC)
#endif
      real(dp), allocatable :: dw_opv1d(:) !< storage for Hv_basis
      complex(dp), allocatable :: zw_opv1d(:) !< complex storage for Hv_basis
      real(dp), allocatable :: dh_proj(:,:) !< storage for projection matrix
      complex(dp), allocatable :: zh_proj(:,:) !< complex storage for complex projection matrix
      real(dp), allocatable :: dh_work(:,:) !< working projection matrix \note probably not neccessary
      complex(dp), allocatable :: zh_work(:,:) !< complex working projection matrix \note probably not neccessary
      real(dp), allocatable :: dmatmul_tmp(:,:) !< working matmul matrix \note probably not neccessary
      complex(dp), allocatable :: zmatmul_tmp(:,:) !< complex matmul matrix \note probably not neccessary

   contains
   end type rritz_data
contains
   !> \brief completely deallocates rritz_data resources
   subroutine init_rritz_data(rritz)
      implicit none
      class(rritz_data), intent(inout) :: rritz !< object of focus
      rritz % forced_logic = k_rritz_force_none
   end subroutine init_rritz_data
   !> \brief completely deallocates rritz_data resources
   subroutine destroy_rritz_data(rritz)
      implicit none
      class(rritz_data), intent(inout) :: rritz !< object of focus
      if(allocated(rritz % dw_opv1d)) deallocate(rritz % dw_opv1d) !< storage for Hv_basis
      if(allocated(rritz % zw_opv1d)) deallocate(rritz % zw_opv1d) !< complex storage for Hv_basis
      if(allocated(rritz % dh_proj)) deallocate(rritz % dh_proj) !< storage for projection matrix
      if(allocated(rritz % zh_proj)) deallocate(rritz % zh_proj) !< complex storage for complex projection matrix
      if(allocated(rritz % dh_work)) deallocate(rritz % dh_work) !< working projection matrix \note probably not neccessary
      if(allocated(rritz % zh_work)) deallocate(rritz % zh_work) !< complex working projection matrix \note probably not neccessary
      if(allocated(rritz % dmatmul_tmp)) deallocate(rritz % dmatmul_tmp) !< working matmul matrix \note probably not neccessary
      if(allocated(rritz % zmatmul_tmp)) deallocate(rritz % zmatmul_tmp) !< complex matmul matrix \note probably not neccessary
   end subroutine destroy_rritz_data
end module rritz_data_module
