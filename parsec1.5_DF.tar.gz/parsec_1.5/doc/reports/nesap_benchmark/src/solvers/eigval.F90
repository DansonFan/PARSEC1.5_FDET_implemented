module eigval_module 
   implicit none
!=====================================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Call one of the iterative diagonalization subroutines 
! (arpack, chebdav, chebff) for diagonalization at 
! each SCF step; or call a diagonalization subroutine only for the
! first SCF step, then switch to the subspace filtering method
! using adaptive Chebyshev polynomials (the latter approach is
! significantly faster than iterative diagonalization at each 
! SCF step).
!
! Ver1.4 main updates by ykzhou as implemented by AJB:
! (1)  implemented chebff for the 1st diagonalization 
!      (chebff is a lot faster than diagonalization, and it uses less memory)
! (2)  implemented newer bounds estimator for the chebyshev filters 
! (3)  implemented the scaled chebyshev filters, need input flag to switch them.
! (4)  Trlanc and Diagla removed.
!      
! Feb--April 2014, Austin
!---------------------------------------------------------------------
    contains
subroutine eigval(elec_st,pot,u_pot,solver,parallel,ipr,ierr)
  use constants
  use electronic_struct_module
  use potential_module
  use non_local_psp_module
  use eigen_solver_module
  use parallel_data_module
  use psum_module
  use solver_chebdav
  use solver_chebff
  use solver_arpk
  use subspace_module
  use external_interfaces, only : dcopy, zscal, dscal
#ifdef MPI
  use mpi
#endif
  implicit none
#ifdef ITAC
  include 'VT.inc'
  include 'vtcommon.inc'
#endif 
  !
  ! Input/Output variables:
  !
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! potential related data
  type (potential), intent(in) :: pot
  ! on-site Coulomb interaction related data
  type (nonloc_pseudo_potential), intent(inout) :: u_pot
  ! solver related data
  type (eigen_solver), intent(inout) :: solver
  ! parallel computation related data
  type (parallel_data), intent(in) :: parallel

  ! printout flag
  integer, intent(in) :: ipr
  ! error flag, 400 < ierr < 421
  integer, intent(out) :: ierr
  !
  ! Work variables:
  !
#ifdef MPI
  integer comm, masterid, mpinfo
#endif
  integer node, nelems,i,irp,ntotal,isc,iit,mxstate
  ! number of k-points
  integer :: kpnum
  ! number of spins
  integer :: isp,spnum
  ! integer array used to save number of truly converged eigenpairs
  ! per representation !!replaced by solver%nconvt!!
  !  integer :: nconvt(elec_st%nrep)
  integer :: kplp
  real(dp) :: dnorm, magmom, tmpreal, tmpcoe
  complex(dpc) :: znorm
  ! number of eigenpairs converged
  integer,allocatable :: nec(:,:,:)
  ! maximum number of matrix-vector multiplications performed.
  integer,allocatable :: maxmvs(:,:,:)
  !
  ! Number of states to be calculated for each representation so
  ! that they add up to at least elec_st%nstate, required on input.
  !
  integer,allocatable :: nrep(:,:,:)
  !
  ! Number of additional states to be calculated for each
  ! representation. This is used as safety window, to prevent
  ! calculating too few eigenstates on some representation.
  integer,allocatable :: nrep_add(:,:,:)
  ! temporary representation array
  integer,  allocatable :: irep_in(:)
  ! output error
  integer,allocatable :: out_info(:,:,:)
  ! temporary arrays for communication
  integer, allocatable :: itmp(:,:,:),mxstt(:,:,:)
  ! output string
  ! maximum number of diagonalization iterations before quitting
  integer, parameter :: maxit = 5
  ! flag for chebdav_diag
  character(len=4)   :: flag
  ! stuff for modifying FD coefficents
  integer ::  ishell,icoeff,current_shell_shift,idiag
  !---------------------------------------------------------------

#ifdef MPI
  masterid = parallel%masterid
  comm = parallel%group_comm
#endif
  !
  ! Set nec = elec_st%eig%nec if this eigensolver can reuse old info
  ! having eigenvalues and eigenvectors only.
  !
  kpnum = max(elec_st%nkpt,1)
  spnum = elec_st%nspin/elec_st%mxwd
  allocate(nec(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('nec',elec_st%nrep*kpnum*spnum,ierr)
  nec(:,:,:) = 0
  allocate(maxmvs(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('maxvms',elec_st%nrep*kpnum*spnum,ierr)
  maxmvs(:,:,:) = 0
  allocate(nrep(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('nrep',elec_st%nrep*kpnum*spnum,ierr)
  nrep(:,:,:) = 0
  allocate(nrep_add(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('nrep_add',elec_st%nrep*kpnum*spnum,ierr)
  nrep_add(:,:,:) = 0
  allocate(out_info(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('out_info',elec_st%nrep*kpnum*spnum,ierr)
  out_info(:,:,:) = 0
  allocate(itmp(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('itmp',elec_st%nrep*kpnum*spnum,ierr)
  itmp(:,:,:) = 0
  allocate(mxstt(elec_st%nrep,kpnum,spnum), stat=ierr)
  call alccheck('mxstt',elec_st%nrep*kpnum*spnum,ierr)
  mxstt(:,:,:) = 0

  do isp = 1, spnum
     do kplp = 1, kpnum
        do irp = 1, elec_st%nrep
           if (solver%name == CHEBFF) then
              nec(irp,kplp,isp) = max(elec_st%eig(irp,kplp,isp)%nec,0)
           else
              nec(irp,kplp,isp) = 0
           endif
           if (solver%name == CHEBDAV) then
              nec(irp,kplp,isp) = max(elec_st%eig(irp,kplp,isp)%nec,0)
           else
              nec(irp,kplp,isp) = 0
           endif
        enddo
     enddo
  enddo
  ! AJB - uneeded
!  out_info = 0
!  mxstt = 0

  ! Define variables; oversize solver%resn since nn and mxstate do
  ! not have fixed values.

  !
  ! Diagonalization loop.
  !
  elec_st%eig(:,:,:)%nec = 0
  !
do iit = 1, maxit !{{{
     maxmvs = 0
     !
     ! Start loop over spin,kpoints and representations in this PE group
     !
    do isp = 1, spnum !{{{
        do kplp = 1, kpnum !{{{
           u_pot%isp = isp
    ! Retrieve the current Hartree potential and adjust kinetic energy coeffs if needed
! SET THE ADIAG PART FOR MATVEC !{{{
    if (parallel%mxwd == 1) then !the case for mxwd is treated within matvec_so.. 

              if (elec_st%nkpt == 0) then
                 !cast the FD coeffiecnets to complex if needed (cplx flag dep.)
                 !This is instead of zset_lap_gen_coeff2D since implementaion is problematic 
                 !when the hartree retrival stage is not encapsulated
                 if (elec_st%cplx) then 
                 tmpcoe = sum(solver%coe2(0,:))
                 solver%zadiag(:)=zzero
                 !$OMP PARALLEL DO
                 do idiag=1,parallel%mydim
                 tmpreal=pot%vnew(idiag,isp)+tmpcoe
                 solver%zadiag(idiag) = cmplx(tmpreal, zero, dpc)
                 enddo
                 !$OMP END PARALLEL DO
                     ! \todo AJB - this here is an implicit casting from real to complex,
                     ! but the rest of the code does not seem to mind these kind of things
          call solver%sten_coeff%copy_coeff_gen(stendef=solver%sten_def)
          ! since diagonal term is done in adiag, need to zero out diagonals - 
          ! zero is real, but it will be converted to complex
          call solver%sten_coeff%updateC0(zero)
                  else
                  !trying to patch some memory problems - zeroing adiag
                 !solver%adiag=zero
                 if (parallel%mydim<parallel%ldn) then
                     solver%adiag(parallel%mydim+1:parallel%ldn) = zzero
                 endif
                 call dcopy(parallel%mydim,pot%vnew(:,isp),1,solver%adiag,1)
                 solver%adiag(1:parallel%mydim) = solver%adiag(1:parallel%mydim) + sum(solver%coe2(0,:))
                 ! dont need this
!          call solver%sten_coeff%fill(stendef=solver%sten_def)
          call solver%sten_coeff%copy_coeffsym(stendef=solver%sten_def)
          ! since diagonal term is done in adiag, need to zero out diagonals - 
          call solver%sten_coeff%updateC0(zero)
                 endif


!                 endif


              else
#ifdef AJB_DEBUG
                  if (parallel%iammaster) then
                     if (kpnum>1) then
                         write(7,*) ' ...Working on k-point ',kplp
                     endif
                  endif
#endif

                 ! now we move pot%vnew which is real to solver%zadiag which is complex
                 !call dcopy(parallel%mydim,pot%vnew(1,isp),1,solver%adiag,1)
                 tmpcoe = sum(solver%coe2(0,:)) + &
                      elec_st%kpts(1,kplp)*elec_st%kpts(1,kplp) + &
                      elec_st%kpts(2,kplp)*elec_st%kpts(2,kplp) + &
                      elec_st%kpts(3,kplp)*elec_st%kpts(3,kplp)
                 solver%zadiag(:)=zzero
                 !$OMP PARALLEL DO
                 do idiag=1,parallel%mydim
                 tmpreal=pot%vnew(idiag,isp)+tmpcoe
                 solver%zadiag(idiag) = cmplx(tmpreal, zero, dpc)
                 enddo
                 !$OMP END PARALLEL DO
!                 solver%zadiag(parallel%mydim+1:parallel%ldn)=zzero

                 !NOW TODO: gen_coeff2_1d -> sten_coeff 
                 !modify the FD coefficents for the kinetic energy of this k-point
                 !This is instead of zset_lap_gen_coeff2D since implementaion is problematic 
                 !when the hartree retirval stage is not encapsulated
          call solver%sten_coeff%copy_coeff_gen(stendef=solver%sten_def)
                 do ishell = 1, solver%norder
                    do icoeff = 1, 3 + parallel%lap_dir_num
         ! write(9,*) "2db: eigval complex coeff debug", ishell, icoeff,  current_shell_shift
         ! write(9,*) "DEBUG: coeff2_1d index", current_shell_shift+2*icoeff
                       current_shell_shift = (ishell-1)*(2*solver%sten_def%lap_dir_num+6)
                    
                       ! \note AJB: UMMM.... somehow I had to reverse these. Either it is a problem with the defintion of the folded stencil
                       ! or something deeper.
                       solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff - 1 ) = &
                          solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff - 1 ) + solver%kecoe1(kplp,icoeff,ishell) !(L)
                       solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff     ) = &
                          solver%sten_coeff%coeff_gen(current_shell_shift+2*icoeff     ) - solver%kecoe1(kplp,icoeff,ishell) !(R)
                    enddo
                 enddo
                 ! write(9,*) "debug -after loading kpoint stencil - "
                 ! write(9,*) solver%sten_coeff%coeff_gen
                 ! write(9,*) "ready"

                 ! now we want to populate the stencil tile coefficents with this data
          !call solver%sten_coeff%fill_gen(stendef=solver%sten_def)
          ! since diagonal term is done in adiag, need to zero out diagonals - 
          ! zero is real, but it will be converted to complex
          call solver%sten_coeff%updateC0(zero)

!                 endif
              endif

           endif !}}}
           do irp = 1, elec_st%nrep !{{{
              ! if no eigenstates are needed, skip diagonalization
              ! \note AJB - hmmm? when is nec /=0 ?
              if (elec_st%eig(irp,kplp,isp)%nec /= 0) cycle
              if ( elec_st%eig(irp,kplp,isp)%group /= parallel%mygroup ) cycle
              if (elec_st%cplx) then ! renormalize {{{
              !
              ! Renormalize calculated eigenvectors to 1 (outside the eigensolver,
              ! eigenvectors are assumed to be normalized over the *full* grid,
              ! dot_product(wf,wf) = elec_st%nrep).
              !
              ! Only processors belonging to the group in charge of this
              ! representation should work.
              !
              ! \todo warning - the limits on the dot product are dangerous here
              !
                 do i = 1, elec_st%eig(irp,kplp,isp)%nec
                    znorm = DOT_PRODUCT( &
                         elec_st%eig(irp,kplp,isp)%zwf &
                         (1:parallel%mydim*parallel%mxwd,i), &
                         elec_st%eig(irp,kplp,isp)%zwf &
                         (1:parallel%mydim*parallel%mxwd,i))
                    call zpsum(znorm,1,parallel%procs_num,parallel%comm)
                    znorm = zone/sqrt(znorm)
                    call zscal(parallel%mydim*parallel%mxwd,znorm, &
                         elec_st%eig(irp,kplp,isp)%zwf(1,i),1)
                 enddo
              else
                 do i = 1, elec_st%eig(irp,kplp,isp)%nec
                    dnorm = DOT_PRODUCT( &
                         elec_st%eig(irp,kplp,isp)%wf(1:parallel%mydim,i), &
                         elec_st%eig(irp,kplp,isp)%wf(1:parallel%mydim,i))
                    call psum(dnorm,1,parallel%procs_num,parallel%comm)
                    dnorm = one/sqrt(dnorm)
                    call dscal(parallel%mydim,dnorm, &
                         elec_st%eig(irp,kplp,isp)%wf(1,i),1)
                 enddo
              endif  !}}}
              !
              ! copy characters and matrix-vector counter
              maxmvs(irp,kplp,isp) = solver%maxmv
              solver%chi(:) = elec_st%chi(irp,:)
              ! if mxstate changes, reset eig_init flag
              ! ntotal stores the new value of mxstate
              ntotal  = elec_st%eig(irp,kplp,isp)%nn
              mxstate = elec_st%eig(irp,kplp,isp)%mm
              if (mxstate /= ntotal) then
                 if (solver%do_subsp .and. mxstate < ntotal) then
                      solver%eig_init(irp,kplp,isp) = .false.
                 endif
                 mxstate = ntotal
              endif
              call eig_adj_size(elec_st%eig(irp,kplp,isp),parallel%ldn*parallel%mxwd,mxstate+solver%winsize,elec_st%cplx)
              !
              ! Do Chebyshev filtering only if the number of eigenvalues has
              ! not changed.
              !
            if (solver%do_subsp .and. solver%eig_init(irp,kplp,isp)) then 
                  !{{{
                 if (ipr >= 2) then !{{{
                    write(9,*) ' subspace (irp,kplp,isp,mm,nn,nec) = ', &
                         irp,kplp,isp,mxstate, &
                         elec_st%eig(irp,kplp,isp)%nn,nec(irp,kplp,isp)
                    call myflush(9)
                 endif 
                  if (parallel%iammaster) then
                      if (ipr >=2) then
                         write(7,*)
                         write(7,*) 'EIGVAL:: Subspace'
                         write(7,*)
                     endif
                  endif!}}}
#ifdef ITAC
                         call VTBEGIN(vt_subspace,ierr)
#endif
                 if (elec_st%cplx) then
                    call zsubspace(kplp,elec_st%eig(irp,kplp,isp)%nn, &
                         nec(irp,kplp,isp),maxmvs(irp,kplp,isp), &
                         elec_st%eig(irp,kplp,isp)%en, &
                         elec_st%eig(irp,kplp,isp)%zwf, &
                         irp,isp,ipr,solver%mv_blksize,out_info(irp,kplp,isp))
                 else
                    call dsubspace(kplp,elec_st%eig(irp,kplp,isp)%nn, &
                         nec(irp,kplp,isp),maxmvs(irp,kplp,isp), &
                         elec_st%eig(irp,kplp,isp)%en, &
                         elec_st%eig(irp,kplp,isp)%wf, &
                         irp,isp,ipr,solver%mv_blksize,out_info(irp,kplp,isp))
                 endif
#ifdef ITAC
                         call VTEND(vt_subspace,ierr)
#endif
                 ! In case the "chebdav" eigensolver is called after a call
                 ! to "subspace" (because the value of "nec" has changed,
                 ! for example), then it should know that all eigenpairs up
                 ! to the old value of "nec" are converged.
                 ! (--ykz: why call chebdav after a call to "subspace"?? shouldn't do this)
                 solver%nconvt(irp,kplp,isp) = nec(irp,kplp,isp)
                 !}}}
            else
                !{{{
               if (ipr >= 2) then !{{{
                  write(9,*) ' eigval (irp,kplp,isp,mm,nn,nec) = ', &
                       irp,kplp,isp,mxstate, &
                       elec_st%eig(irp,kplp,isp)%nn,nec(irp,kplp,isp)
                  call myflush(9)
               endif !}}}

               do isc = 1, maxit !{{{
                  if (elec_st%cplx) then !{{{
                     select case(solver%name)
                     case (ARPACK)
! Residual vector is not reused for the moment.
!                    out_info(irp,kplp,isp) = solver%info(irp,kplp,isp)
                        out_info(irp,kplp,isp) = 0
#ifdef ITAC
                         call VTBEGIN(vt_arpack,ierr)
#endif
                        call zarpk_diag (kplp,parallel, &
                             elec_st%eig(irp,kplp,isp)%nn,nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%zwf,solver%toler, &
                             solver%zres_res(:,irp,kplp,isp), &
                             ipr,out_info(irp,kplp,isp))
                        solver%info(irp,kplp,isp) = out_info(irp,kplp,isp)
#ifdef ITAC
                         call VTEND(vt_arpack,ierr)
#endif
                     case (CHEBFF)
#ifdef ITAC
                         call VTBEGIN(vt_chebff,ierr)
#endif
                        if (nec(irp,kplp,isp) <= 0) then
                           flag = "new";
                        else
                           flag = "cont"
                           write(9,*) "DEBUG: continue mode in chebff"

                        end if
                        call zchebff_diag(kplp,mxstate+solver%winsize, &
                             elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%zwf,solver%toler, &
                             ipr, flag, solver%nconvt(irp,kplp,isp), &
                             out_info(irp,kplp,isp),solver%mv_blksize)
#ifdef ITAC
                         call VTEND(vt_chebff,ierr)
#endif
                     case (CHEBDAV)
#ifdef ITAC
                         call VTBEGIN(vt_chebdav,ierr)
#endif
!  chebdav cannot restart correctly?
                     !if (nec(irp,kplp,isp) <= 0) then
                        flag = "new";
                         !else
                        ! if (parallel%iammaster) then
                        !     if (ipr >2) then
                        !        write(7,*)
                        !        write(7,*) 'EIGVAL:: zCHEBDAV (CONT)'
                        !        write(7,*)
                        !    endif
                        ! endif
                        !    flag = "cont"
                        !    !nec(irp,kplp,isp) = min(nec(irp,kplp,isp), solver%nconvt(irp,kplp,isp))
                     !   end if
                        if (ipr >= 2) then
                           if (nec(irp,kplp,isp) <= 0) then
                              write(9,'(a, a, a, i2, a, i5)') "Chebdav flag=" &
                                   , flag,", nec(",irp,")=", nec(irp,kplp,isp)
                           else
                              write(9,'(a, a, 2(a, i2, a, i5))') "Chebdav flag=", &
                                   flag,", nec(",irp,")=", nec(irp,kplp,isp), &
                                   ", nconvt(",irp,")=",solver%nconvt(irp,kplp,isp)
                           end if
                        endif
                        if (parallel%iammaster) then
                            if (ipr >=1) then
                                write(7,*)
                                write(7,*) 'EIGVAL:: zCHEBDAV'
                                write(7,*)
                            endif
                        endif
                        call zchebdav_diag(kplp,mxstate+solver%winsize, &
                             elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%zwf,solver%toler, &
                             ipr, flag, solver%nconvt(irp,kplp,isp), &
                             out_info(irp,kplp,isp),solver%mv_blksize)
#ifdef ITAC
                         call VTEND(vt_chebdav,ierr)
#endif
                     end select
                     !}}} cmplx
                 else !{{{ real
                     select case(solver%name)
                     case (ARPACK)
!    Residual vector is not reused for the moment
!                    out_info(irp,kplp,isp) = solver%info(irp,kplp,isp)
                        out_info(irp,kplp,isp) = 0
#ifdef ITAC
                         call VTBEGIN(vt_arpack,ierr)
#endif
                        call darpk_diag (kplp,parallel, &
                             elec_st%eig(irp,kplp,isp)%nn,nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%wf,solver%toler, &
                             solver%res_res(:,irp,kplp,isp), &
                             ipr,out_info(irp,kplp,isp))
#ifdef ITAC
                         call VTEND(vt_arpack,ierr)
#endif
                     case (CHEBFF)
                        if (nec(irp,kplp,isp) <= 0) then
                           flag = "new";
                        else
                           flag = "cont"
                           write(9,*) "DEBUG: continue mode in chebff"
                        end if
#ifdef ITAC
                         call VTBEGIN(vt_chebff,ierr)
#endif
                        call dchebff_diag(kplp,mxstate+solver%winsize,  &
                             elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%wf,solver%toler, &
                             ipr, flag, solver%nconvt(irp,kplp,isp),  &
                             out_info(irp,kplp,isp),solver%mv_blksize)
#ifdef ITAC
                         call VTEND(vt_chebff,ierr)
#endif
                     case (CHEBDAV)
#ifdef ITAC
                         call VTBEGIN(vt_chebdav,ierr)
#endif
!  chebdav cannot restart correctly?
                    !if (nec(irp,kplp,isp) <= 0) then
                        flag = "new";
                        ! else
                        ! if (parallel%iammaster) then
                        !     if (ipr >0) then
                        !        write(7,*)
                        !        write(7,*) 'EIGVAL:: CHEBDAV (CONT)'
                        !        write(7,*)
                        !    endif
                        ! endif
                        !    flag = "cont"
                        !    !nec(irp,kplp,isp) = min(nec(irp,kplp,isp), solver%nconvt(irp,kplp,isp))
                    !    end if
                        if (ipr >= 2) then
                           if (nec(irp,kplp,isp) <= 0) then
                              write(9, '(a, a, a, i2, a, i5)') "Chebdav flag=", &
                                   flag,", nec(",irp,")=", nec(irp,kplp,isp)
                           else
                              write(9,'(a, a, 2(a, i2, a, i5))') "Chebdav flag=", &
                                   flag,", nec(",irp,")=", nec(irp,kplp,isp), &
                                   ", nconvt(",irp,")=",  &
                                   solver%nconvt(irp,kplp,isp)
                           end if
                        endif
                        if (parallel%iammaster) then
                            if (ipr >=2) then
                                write(7,*)
                                write(7,*) 'EIGVAL:: CHEBDAV'
                                write(7,*)
                            endif
                        endif
                        call dchebdav_diag(kplp,mxstate+solver%winsize,  &
                             elec_st%eig(irp,kplp,isp)%nn, nec(irp,kplp,isp), &
                             maxmvs(irp,kplp,isp),elec_st%eig(irp,kplp,isp)%en, &
                             elec_st%eig(irp,kplp,isp)%wf,solver%toler, &
                             ipr, flag, solver%nconvt(irp,kplp,isp),  &
                             out_info(irp,kplp,isp),solver%mv_blksize)
#ifdef ITAC
                         call VTEND(vt_chebdav,ierr)
#endif
                     end select
                 endif !}}}
                  
#ifdef MPI
                  call MPI_BARRIER(comm,mpinfo)
#endif
            if (ipr >=0) then
                  write(9,*) ' Eigensolver, end of iteration = ', isc
                  write(9,*) ' repr. = ',irp, ' k-point = ',kplp,' spin = ',isp 
                  write(9,*) ' maxmvs = ',maxmvs(irp,kplp,isp), &
                       ' nec = ', nec(irp,kplp,isp)
                  write(9,*) ' nstate = ', elec_st%eig(irp,kplp,isp)%nn, &
                       ' info = ',out_info(irp,kplp,isp)
               endif


                  if (out_info(irp,kplp,isp) /= 0) exit
                  if (nec(irp,kplp,isp) >= elec_st%eig(irp,kplp,isp)%nn) then
                     nec(irp,kplp,isp) = elec_st%eig(irp,kplp,isp)%nn
                     exit
                  endif
               enddo !}}}
               !
               ! If using Chebyshev-filtered subspace method, save information 
               ! for the subsequent iterations.
               !
               if (solver%do_subsp) then
                  solver%eval_loc(1:mxstate,irp,isp) = &
                       elec_st%eig(irp,kplp,isp)%en(1:mxstate)
                  solver%eig_init(irp,kplp,isp) = .true.
               endif
                !}}}
            endif

           mxstt(irp,kplp,isp) = mxstate

           enddo !}}}
        enddo !}}}
    enddo !}}}

#ifdef MPI
   ! Share information across groups
   ! TODO: consider switch to iallreduce
   call MPI_ALLREDUCE(MPI_IN_PLACE,out_info,elec_st%nrep*kpnum*spnum,MPI_INTEGER,MPI_MAX,parallel%comm,mpinfo)
   call MPI_ALLREDUCE(MPI_IN_PLACE,nec     ,elec_st%nrep*kpnum*spnum,MPI_INTEGER,MPI_MAX,parallel%comm,mpinfo)
   call MPI_ALLREDUCE(MPI_IN_PLACE,maxmvs  ,elec_st%nrep*kpnum*spnum,MPI_INTEGER,MPI_MAX,parallel%comm,mpinfo)
   call MPI_ALLREDUCE(MPI_IN_PLACE,mxstt   ,elec_st%nrep*kpnum*spnum,MPI_INTEGER,MPI_MAX,parallel%comm,mpinfo)
#endif

   ! report number of eigenpairs and matrix-vector operations
   do isp = 1, spnum !{{{
      do kplp = 1, kpnum
         if (parallel%iammaster .and. elec_st%nspin == 2) then
            if (isp == 1) write(7,*) ' SPIN UP'
            if (isp == 2) write(7,*) ' SPIN DOWN'
         endif
         do irp = 1, elec_st%nrep
            elec_st%eig(irp,kplp,isp)%mm = mxstt(irp,kplp,isp)
            if ( elec_st%eig(irp,kplp,isp)%group /= parallel%mygroup ) then
               call eig_e_adj_size(elec_st%eig(irp,kplp,isp),nec(irp,kplp,isp))
               if (elec_st%nspin == 2) then
                   if (isp == 1) write(9,*) ' DEALING WITH SPIN UP'
                   if (isp == 2) write(9,*) ' DEALING WITH SPIN DOWN'
               endif
            endif
#ifdef ITAC
            call VTBEGIN(vt_eigencomm_state,ierr)
#endif
#ifdef MPI
            !\todo Need to understand what is going on here, since this takes too long:
            node = parallel%gmap(1,1,elec_st%eig(irp,kplp,isp)%group + 1)
            call MPI_BCAST(elec_st%eig(irp,kplp,isp)%en,nec(irp,kplp,isp),MPI_DOUBLE_PRECISION,node,parallel%comm,mpinfo)
#endif
#ifdef ITAC
            call VTEND(vt_eigencomm_state,ierr)
#endif
            if (out_info(irp,kplp,isp) /= 0) then
               if (parallel%iammaster) then
                  write(7,*) ' ERROR in eigval.F while working at'
                  write(7,*) ' representation ',irp,' spin ',isp
                  write(7,*) ' error flag = ',out_info(irp,kplp,isp)
               endif
               ierr = 401
               return
            endif
            if ((nec(irp,kplp,isp) < elec_st%eig(irp,kplp,isp)%nn .or. &
                 maxmvs(irp,kplp,isp) >= solver%maxmv) .and. &
                 solver%name /= CHEBDAV) then
               if (parallel%iammaster) then
                  write(7,*)
                  write(7,*) 'ERROR: ', &
                       'Iterative diagonalization has failed!'
                  write(7,*) ' representation ',irp,' spin ',isp
                  write(7,*) isc,' iterations performed'
                  write(7,*) ' Increase value of Maximum_matvec ', &
                       'in parsec.in'
                  write(7,*) ' (It will not help)'
                  write(7,*) ' error flag = ',out_info(irp,kplp,isp)
               endif
               ierr = 402
               return
            endif
         enddo

         if (parallel%iammaster) then
            solver%totalmv = solver%totalmv + sum(maxmvs(:,kplp,isp))
            if(kpnum > 1) then
                write(7,*) 'Kpoint (spin)', kplp,'(',isp,')'
            endif
       if (ipr >= 0) then !{{{
            write(7,*) 'Number of converged eigen-pairs per representation:', nec(:,kplp,isp)
            write(7,*) 'Number of matrix-vector multiplications: ',  maxmvs(:,kplp,isp)
            write(7,*) 'Cumulated number of matrix-vector mult. = ', solver%totalmv
            !also appearing in old format:
            !write(7,'(a,i7)') ' nec  total = ',sum(nec(:,kplp,isp))
            !write(7,'(a,i7)') ' maxmvs total = ',sum(maxmvs(:,kplp,isp))
            call myflush(7)
        endif
         endif
         !
         ! Error messages from eigensolver.
         !
         do irp = 1, elec_st%nrep
            if (out_info(irp,kplp,isp) /= 0) then
               if (parallel%iammaster) then
                  write(7,*) ' ERROR in eigval.F while working at'
                  write(7,*) ' representation ',irp,' spin ',isp
                  write(7,*) ' error flag = ',out_info(irp,kplp,isp)
               endif
               ierr = 403
               return
            endif
         enddo
      enddo
   enddo !}}}

#ifdef ITAC
    call VTBEGIN( vt_eigensort_state,ierr)
#endif
   !
   ! Sort eigenvalues in ascending order and define the number of
   ! states per representation, nrep. Update elec_st%irep and all
   ! elec_st%eig%nec accordingly.
   !
   do isp = 1, spnum !{{{
      do kplp = 1, kpnum
         ntotal = 0
         do irp = 1, elec_st%nrep
            ntotal = ntotal + elec_st%eig(irp,kplp,isp)%nn
         enddo
         allocate(irep_in(ntotal))
         call eigen_sort(elec_st,isp,kplp,ntotal,solver%nadd, &
              nrep(1,kplp,isp),nrep_add(1,kplp,isp),irep_in)
         ntotal = min(sum(nrep(:,kplp,isp) +  &
              nrep_add(:,kplp,isp)),elec_st%nstate)
         elec_st%irep(:,kplp,isp) = 0
         elec_st%irep(1:ntotal,kplp,isp) = irep_in(1:ntotal)
         do irp = 1, elec_st%nrep
            elec_st%eig(irp,kplp,isp)%nn = nrep(irp,kplp,isp) &
                 + nrep_add(irp,kplp,isp)
            elec_st%eig(irp,kplp,isp)%nec = nrep(irp,kplp,isp)
         enddo
         ! add the lowest eigenvalue in set nrep_add as well
         irp = irep_in(elec_st%nstate)
         elec_st%eig(irp,kplp,isp)%nec = nrep(irp,kplp,isp) + 1
         deallocate(irep_in)

         elec_st%ntotal(isp) = ntotal
         !
         ! If no additional states are calculated, then the set of
         ! eigenstates for this representation may be incomplete. Increase
         ! the number of states to be computed (nn) and set nec to zero,
         ! so that a new diagonalization will be performed.
         !
         do irp = 1, elec_st%nrep
            if (nrep_add(irp,kplp,isp) == 0) then
                !AJB,DEBUG:
                write(9,*) "EIGVAL: increases eig.nn for irp", irp
                write(9,*) "EIGVAL: nn was:", elec_st%eig(irp,kplp,isp)%nn
               elec_st%eig(irp,kplp,isp)%nn = &
                    elec_st%eig(irp,kplp,isp)%nn + &
                    max(2*solver%nadd,elec_st%eig(irp,kplp,isp)%nn/4)
               elec_st%eig(irp,kplp,isp)%nec = 0
                write(9,*) "EIGVAL: nn now:", elec_st%eig(irp,kplp,isp)%nn
                write(9,*) "EIGVAL: not sure I will work now"
            endif
         enddo
         if (solver%fix_num_eig) then
            do irp = 1, elec_st%nrep
               elec_st%eig(irp,kplp,isp)%nn = elec_st%eig(irp,kplp,isp)%mm
               elec_st%eig(irp,kplp,isp)%nec = elec_st%eig(irp,kplp,isp)%mm
            enddo
            exit
         endif
      enddo
   enddo !}}}
#ifdef ITAC
    call VTEND( vt_eigensort_state,ierr)
#endif
#ifdef MPI
   call MPI_ALLREDUCE(MPI_IN_PLACE,nrep_add,elec_st%nrep*kpnum*spnum, MPI_INTEGER,MPI_MAX,parallel%comm,mpinfo)
#endif
   if ( all(nrep_add /= 0) ) exit
enddo !}}}
!
! Print error message if there are not enough eigenstates.
!
do isp = 1, spnum !{{{
   do kplp = 1, kpnum
      ntotal = 0
      do irp = 1, elec_st%nrep
         ntotal = ntotal + elec_st%eig(irp,kplp,isp)%nec
      enddo
      if (ntotal < elec_st%nstate) then
         if (parallel%iammaster) then
            write(7,*) 'ERROR: not enough eigenstates are computed! '
            write(7,*) (elec_st%eig(irp,kplp,isp)%nec,irp=1,elec_st%nrep)
            write(7,*) elec_st%nstate,' eigenstates requested but', &
                 ' only ',ntotal,' found.'
            write(7,*) 'Increase initial_subspace_acc and/or ', &
                 'subspace_buffer_size in parsec.in'
            write(7,*) ' STOP'
         endif
         ierr = 404
         return
      endif
      elec_st%ntotal(isp) = ntotal
   enddo
enddo !}}}

! If spin-orbit, calculate the magnetic moment of each state.
! (Must assume that wave-functions are complex!)
if (parallel%mxwd == 2) then !{{{
#ifdef ITAC
    call VTBEGIN( vt_so,ierr)
#endif
do kplp = 1, kpnum
      do i = 1, elec_st%nstate
         magmom = zero
         irp = elec_st%irep(i,kplp,1)
         if (elec_st%eig(irp,kplp,1)%group == parallel%mygroup) then
            do iit = 1, parallel%mydim
               if(elec_st%ncl) then
                   ! \todo the shift by mydim should probably be a shift by ldn
                  magmom = magmom + &
                    (conjg(elec_st%eig(irp,kplp,1)%zwf(iit,i))* &
                    elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i)+ &
                    conjg(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))* &
                    elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 + &
                    (zi*(-conjg(elec_st%eig(irp,kplp,1)%zwf(iit,i))* &
                    elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i) + &
                    conjg(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))* &
                    elec_st%eig(irp,kplp,1)%zwf(iit,i)))**2 + &
                    ((abs(elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 - &
                    abs(elec_st%eig(irp,kplp,1)%zwf(iit+parallel%mydim,i))**2))**2
                  else
                     magmom = magmom + &
                          abs(elec_st%eig(irp,kplp,1)%zwf(iit,i))**2 - &
                          abs(elec_st%eig(irp,kplp,1)% &
                          zwf(iit+parallel%mydim,i))**2
                  endif
               enddo
            endif
         call psum(magmom,1,parallel%procs_num,parallel%comm)
         elec_st%magmom(i,kplp) = magmom
         if (elec_st%ncl) magmom = sqrt(magmom)
      enddo
  enddo
#ifdef ITAC
    call VTEND( vt_so,ierr)
#endif
endif !}}}

deallocate(nec,maxmvs,nrep,nrep_add,out_info,itmp,mxstt)

!AJB: I still don't like you:
#ifdef MPI
call MPI_BARRIER(parallel%group_comm,mpinfo)
#endif

end subroutine eigval
!===============================================================
!
! For a given set of eigenvalues (for all representations), sort
! them in ascending order. Use straight insertion, no need for
! fancy algorithms since the arrays are always "short".
!
! \todo AJB: "always"
!
!---------------------------------------------------------------
subroutine eigen_sort(elec_st,isp,kplp,nmax,nadd,nrep,nrep_add,irep)

  use constants
  use electronic_struct_module
  implicit none
  !
  ! Input/Output variables:
  !
  ! electronic structure
  type (electronic_struct), intent(in) :: elec_st
  ! spin orientation
  integer, intent(in) :: isp
  ! kpoint
  integer, intent(in) :: kplp
  ! size of representation array
  integer, intent(in) :: nmax
  ! maximum number of additional states per representation
  integer, intent(in) :: nadd
  ! lowest number of states for each representation, such that the
  ! total sums up to (elec_st%nstate-1) after eigenvalues are sorted
  integer, intent(out) :: nrep(elec_st%nrep)
  ! number of additional states on each representation, after
  ! removing the first (elec_st%nstate-1) ones
  integer, intent(out) :: nrep_add(elec_st%nrep)
  ! representation array, irep(i) = 0 for i > sum( nrep_add + nrep )
  integer, intent(out) :: irep(nmax)
  !
  ! Work variables:
  !
  ! counters, temporary variables
  integer i, irp, jj, l, ntotal, nc
  real(dp) :: e_tmp

  ! temporary arrays: representation, order index, eigenvalues
  integer, dimension(:) , allocatable :: rep_tmp, ord_tmp
  real(dp), dimension(:), allocatable :: eig_tmp
  !---------------------------------------------------------------

  ntotal = 0
  do jj = 1, size(elec_st%eig(:,kplp,isp))
     ntotal = ntotal + elec_st%eig(jj,kplp,isp)%nn
  enddo
  allocate(eig_tmp(ntotal))
  allocate(rep_tmp(ntotal))
  allocate(ord_tmp(ntotal))
  nc = 0
  do irp = 1, elec_st%nrep
     do i = 1, elec_st%eig(irp,kplp,isp)%nn
        nc = nc + 1
        eig_tmp(nc) = elec_st%eig(irp,kplp,isp)%en(i)
        rep_tmp(nc) = irp
        ord_tmp(nc) = i
     enddo
  enddo

  do l = 2, nc
     e_tmp = eig_tmp(l)
     irp = rep_tmp(l)
     i = ord_tmp(l)
     do jj = l-1, 1, -1
        if (eig_tmp(jj) <= e_tmp) goto 10
        eig_tmp(jj+1) = eig_tmp(jj)
        rep_tmp(jj+1) = rep_tmp(jj)
        ord_tmp(jj+1) = ord_tmp(jj)
     enddo
     jj = 0
10   continue
     eig_tmp(jj+1) = e_tmp
     rep_tmp(jj+1) = irp
     ord_tmp(jj+1) = i
  enddo

  nrep = 0
  irep = 0
  do jj = 1, elec_st%nstate-1
     irep(jj) = rep_tmp(jj)
     nrep(irep(jj)) = nrep(irep(jj)) + 1
  enddo

  nrep_add = 0
  i = elec_st%nstate-1
  do jj = elec_st%nstate , nc
     irp = rep_tmp(jj)
     if (nrep_add(irp) < nadd) then
        nrep_add(irp) = nrep_add(irp) + 1
        i = i + 1
        irep(i) = rep_tmp(jj)
     endif
  enddo

  deallocate(eig_tmp, rep_tmp, ord_tmp)

end subroutine eigen_sort
!===============================================================
!
! Adjust size of eigenstate arrays.
!
!---------------------------------------------------------------
subroutine eig_adj_size(eigen,ldn,new_size,cplx)

  use constants
  use electronic_struct_module
  implicit none
  !
  ! Input/Output variables:
  !
  ! eigenstates
  type (eigenstates), intent(inout) :: eigen
  ! size of grid local to this processor (i.e. local number of rows)
  integer, intent(in) :: ldn
  ! new size of arrays
  integer, intent(in) :: new_size
  ! real/complex flag
  logical, intent(in) :: cplx
  !
  ! Work variables:
  !
  ! allocation flag
  integer alcstat
  ! old size of arrays
  integer old_size
  ! number of saved states (useful if old_size > new_size)
  integer nn

  ! work integers
  integer :: ii,jj

  ! buffer arrays for eigenvectors, eigenvalues, occupancy factors
  ! these should be aligned because of the -align compiler flag
  real(dp), allocatable :: eig_buff(:),occ_buff(:)
  complex(dpc), allocatable :: zwf_buff(:,:)
  real(dp), allocatable :: wf_buff(:,:)
  logical :: save_flag

  !---------------------------------------------------------------

  old_size = 0
  if (associated(eigen%en)) old_size = size(eigen%en)

  ! If new_size is smaller than old_size, do nothing.
  if (old_size >= new_size) return
  !
  ! If the structure already has some data, save it in temporary arrays.
  !
  if (associated(eigen%en)) then
     nn = min(old_size,new_size)

     allocate(eig_buff(nn))
     allocate(occ_buff(nn))
     if (cplx) then
        allocate(zwf_buff(ldn,nn),stat=alcstat)
        call alccheck('zwf_buff',ldn*nn,alcstat)
     else
        allocate(wf_buff(ldn,nn),stat=alcstat)
        call alccheck('wf_buff',ldn*nn,alcstat)
    endif

  !$OMP PARALLEL 

  !$OMP DO SIMD
     do ii=1,nn
     eig_buff(ii) = eigen%en(ii)
     enddo
  !$OMP END DO SIMD NOWAIT
  !$OMP DO SIMD
     do ii=1,nn
     occ_buff(ii) = eigen%occ(ii)
     enddo
  !$OMP END DO SIMD NOWAIT

     if (cplx) then
  !$OMP DO SIMD COLLAPSE(2)
     do ii=1,nn
         do jj=1,ldn
        zwf_buff(jj,ii) = eigen%zwf(jj,ii)
        enddo !jj
     enddo !ii
 !$OMP END DO SIMD NOWAIT
     else
  !$OMP DO SIMD COLLAPSE(2)
     do ii=1,nn
         do jj=1,ldn
        wf_buff(jj,ii) = eigen%wf(jj,ii)
        enddo !jj
     enddo !ii
 !$OMP END DO SIMD NOWAIT
     endif
  !$OMP END PARALLEL
     save_flag = .true.
  else
     save_flag = .false.
  endif
  !
  ! Now, reallocate arrays.
  !
  call destroy_eigenstate (eigen)
  if (new_size == 0) then
     if (save_flag) deallocate(occ_buff, eig_buff)
     if (cplx) then
        if (save_flag) deallocate(zwf_buff)
     else
        if (save_flag) deallocate(wf_buff)
     endif
     return
  endif
  call create_eigenstate (eigen,ldn,new_size,cplx)
  !
  ! Transfer information from old arrays to resized arrays.
  !
  if (save_flag) then
  !$OMP PARALLEL
  !$OMP DO SIMD
     do ii=1,nn
     eigen%en(ii) = eig_buff(ii)
     enddo !ii
  !$OMP END DO SIMD NOWAIT
  !$OMP DO SIMD
     do ii=1,nn
     eigen%occ(ii) = occ_buff(ii)
     enddo !ii
  !$OMP END DO SIMD NOWAIT
     if (cplx) then
  !$OMP DO SIMD COLLAPSE(2)
     do ii=1,nn
         do jj=1,ldn
        eigen%zwf(jj,ii) = zwf_buff(jj,ii)
        enddo !jj
     enddo !ii
 !$OMP END DO SIMD
 !$OMP SINGLE
        deallocate(zwf_buff)
  !$OMP END SINGLE NOWAIT
     else
  !$OMP DO SIMD COLLAPSE(2)
     do ii=1,nn
         do jj=1,ldn
        eigen%wf(jj,ii) = wf_buff(jj,ii)
        enddo !jj
     enddo !ii
 !$OMP END DO SIMD
 !$OMP SINGLE
        deallocate(wf_buff)
  !$OMP END SINGLE NOWAIT
     endif
  !$OMP END PARALLEL
     deallocate(occ_buff, eig_buff)
  endif

end subroutine eig_adj_size
!===============================================================
!
! Adjust size of eigenstate arrays.
!
!---------------------------------------------------------------
subroutine eig_e_adj_size(eigen,new_size)

  use constants
  use electronic_struct_module
  implicit none
  !
  ! Input/Output variables:
  !
  ! eigenstates
  type (eigenstates), intent(inout) :: eigen
  ! new size of arrays
  integer, intent(in) :: new_size
  !
  ! Work variables:
  !
  ! old size of arrays
  integer old_size
  ! number of saved states (useful if old_size > new_size)
  integer nn
  ! buffer arrays for eigenvectors, eigenvalues, occupancy factors
  real(dp), allocatable :: eig_buff(:),occ_buff(:)
  logical :: save_flag

  !---------------------------------------------------------------

  old_size = 0
  if (associated(eigen%en)) old_size = size(eigen%en)

  ! If new_size is smaller than old_size, do nothing.
  if (old_size >= new_size) return
  !
  ! If the structure already has some data, save it in temporary arrays.
  !
  if (associated(eigen%en)) then
     nn = min(old_size,new_size)

     allocate(eig_buff(nn))
     eig_buff(1:nn) = eigen%en(1:nn)
     allocate(occ_buff(nn))
     occ_buff(1:nn) = eigen%occ(1:nn)

     save_flag = .true.
  else
     save_flag = .false.
  endif
  !
  ! Now, reallocate arrays.
  !
  if (associated(eigen%en)) deallocate(eigen%en)
  if (associated(eigen%occ)) deallocate(eigen%occ)
  if (new_size == 0) then
     if (save_flag) deallocate(occ_buff, eig_buff)
     return
  endif
  allocate(eigen%en(new_size))
  eigen%en = zero
  allocate(eigen%occ(new_size))
  eigen%occ = zero
  !
  ! Transfer information from old arrays to resized arrays.
  !
  if (save_flag) then
     eigen%en(1:nn) = eig_buff(1:nn)
     eigen%occ(1:nn) = occ_buff(1:nn)
     deallocate(occ_buff, eig_buff)
  endif

end subroutine eig_e_adj_size
!===============================================================
!
! Initialize various arrays and variables before any eigensolver
! is called. This used to be performed at the beginning of
! subroutine eigval.F. (now called in calc_nscf.F90 and parsec.F90)?
!
!---------------------------------------------------------------
subroutine initeigval(elec_st,nadd)

  use constants
  use electronic_struct_module
  use eigen_solver_module
  use parallel_data_module
  implicit none
  !
  ! Input/Output variables:
  !
  ! electronic structure
  type (electronic_struct), intent(inout) :: elec_st
  ! number of additional eigenvalues per representation
  integer, intent(in) :: nadd
  !
  ! Work variables:
  !
  integer kpnum,kplp,iit,ntotal,ii,irp

  !---------------------------------------------------------------

  kpnum = max(elec_st%nkpt,1)

  ! assume a "blind guess" for the number of eigenstates to be
  ! computed; later, nn will be dynamically adjusted
#ifndef FERMIBETA
  ! \todo AJB: moved back by Yunkai, change protected by BETA flag
  ! If I am not mistaken, placing this line here will hurt any
  ! attempt of doing kpoints with representations,
  ! and will also have an effect on calculation with spin>1 and mxwd=1
  ntotal = 0
#endif
  do iit = 1, elec_st%nspin/elec_st%mxwd
     do kplp = 1, kpnum               
#ifdef FERMIBETA
        ntotal = 0 ! I moved this line up .. (YKZ: you better not)
#endif
        do irp = 1, elec_st%nrep
           ntotal = ntotal + elec_st%eig(irp,kplp,iit)%nec
        enddo
        if (ntotal < elec_st%nstate) then
           do irp = 1, elec_st%nrep
              ii = nadd + elec_st%nstate/elec_st%nrep
              if (elec_st%eig(irp,kplp,iit)%nn < ii) &
                   elec_st%eig(irp,kplp,iit)%nn = ii
           enddo
           elec_st%ntotal(iit) = elec_st%nstate
        endif
        ! calculate at least one eigenvector
        do irp = 1, elec_st%nrep
           if (elec_st%eig(irp,kplp,iit)%nn == 0) &
                elec_st%eig(irp,kplp,iit)%nn = 1
        enddo
     enddo
  enddo

  return

end subroutine initeigval
!===============================================================
end module eigval_module
