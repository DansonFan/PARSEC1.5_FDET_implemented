!> \brief custom interfaces for ELPA <https://elpa.mpcdf.mpg.de/> from our PARSEC data structures
!!
!> \details Purpose of this is to separate out the ELPA code from the peig_inter code that
!! we have. It's distracting and hurts the legibility? Probably have to patch
!! peig_inter routines to have an MPI_Comm input to to keep the interfaces the
!! same. Might be able to get away without having a blocksize input, just use
!> \todo CML - needs variable blocksize (nblk)
!> \todo CML - needs complex templating
!> \bug  CML - needs complex testing
!*==========================================
module elpa_custom
#ifdef WITH_ELPA
#ifndef WITH_SCALAPACK
#error "WITH_ELPA requires WITH_SCALAPACK"
#endif
   use elpa1
   use elpa2
   use blockcyclic_utility

   use file_units, only : f_parsec
   implicit none

   interface elpa_distributed1
      module procedure delpa_distributed1, zelpa_distributed1
   end interface
   interface elpa_nondistributed
      module procedure delpa_nondistributed, zelpa_nondistributed
   end interface
contains
   subroutine delpa_distributed1(op_comm, uplo, na_rows, na_cols, h_proj, na, &
         ev, nev, nblk, np_rows, np_cols, my_prow, my_pcol, my_blacs_ctxt)
      use elpa1
      use elpa2
      use constants
      use mpi

      use file_units, only : f_parsec
      implicit none

      integer, intent(in) :: op_comm
      character (len=1), intent(in) :: uplo  !< upper/lower matrix \note doesn't do anything currently
      integer, intent(in) :: na_rows, na_cols !< dimensions of submatrix
      integer, intent(in) :: nblk !< blocking for block-cyclic amat_distributed
      integer, intent(in) :: na  !< dimension of full matrix A
      integer, intent(in) :: nev !< leading dimension of matrix A
      integer, intent(in) :: np_rows !< number of processors in a row
      integer, intent(in) :: np_cols !< number of processors in a col
      integer, intent(in) :: my_prow !< my process row
      integer, intent(in) :: my_pcol !< my process col
      integer, intent(in) :: my_blacs_ctxt
      != INPUT
      real(dp), intent(inout) :: h_proj(na_rows,na_cols) !< submatrix of s x s h_proj
      real(dp), intent(out) :: ev(nev) !< s eigenvalues

      != WORK VARIABLES
      integer :: mpi_comm_rows, mpi_comm_cols, mpierr
      integer :: info 
      integer :: i,j ! loop indices
      real(dp), allocatable :: z(:,:)
      logical :: success

      !> \note All ELPA routines need MPI communicators for communicating within
      !! rows or columns of processes, these are set in get_elpa_row_col_comms.

      mpierr = get_elpa_communicators(op_comm, my_prow, my_pcol, &
         mpi_comm_rows, mpi_comm_cols)
      

      ! Work matrix for elpa same size as submatrix
      allocate(z (na_rows,na_cols))

      success = solve_evp_real_2stage(na, nev, h_proj, na_rows, ev, z, na_rows,  nblk, na_cols, &
         mpi_comm_rows, mpi_comm_cols, op_comm)

      if (.not.(success)) then
         write(*,*) "solve_evp_real_2stage produced an error! Aborting..."
         call MPI_ABORT(op_comm, mpierr, info)
      endif

      !$OMP PARALLEL DO SIMD COLLAPSE(2) SCHEDULE(RUNTIME)
      do j = 1, na_cols
         do i = 1, na_rows
            h_proj(i,j) = z(i,j)
         enddo
      enddo
      !$OMP END PARALLEL DO SIMD

      deallocate(z)
   end subroutine delpa_distributed1
   subroutine zelpa_distributed1(op_comm, uplo, na_rows, na_cols, h_proj, na, &
         ev, nev, nblk, np_rows, np_cols, my_prow, my_pcol, my_blacs_ctxt)
      use elpa1
      use elpa2
      use constants, only : dpc
      use mpi

      use file_units, only : f_parsec
      implicit none

      integer, intent(in) :: op_comm
      character (len=1), intent(in) :: uplo  !< upper/lower matrix
      integer, intent(in) :: na_rows, na_cols !< dimensions of submatrix
      integer, intent(in) :: nblk !< blocking for block-cyclic amat_distributed
      integer, intent(in) :: na  !< dimension of full matrix A
      integer, intent(in) :: nev !< leading dimension of matrix A
      integer, intent(in) :: np_rows, np_cols, my_prow, my_pcol
      integer, intent(inout) :: my_blacs_ctxt
      != INPUT
      complex(dpc), intent(inout) :: h_proj(na_rows,na_cols) !< submatrix of s x s dense matrix, post global reduction
      real(dpc), intent(out) :: ev(nev) !< s eigenvalues

      ! WORK VARIABLES
      integer :: mpi_comm_rows, mpi_comm_cols, mpierr
      integer :: info 
      integer :: i,j ! loop indices
      complex(dpc), allocatable :: z(:,:)
      logical :: success

      ! All ELPA routines need MPI communicators for communicating within
      ! rows or columns of processes, these are set in get_elpa_row_col_comms.

      mpierr = get_elpa_communicators(op_comm, my_prow, my_pcol, &
         mpi_comm_rows, mpi_comm_cols)

      ! Work matrix for elpa same size as submatrix
      allocate(z (na_rows,na_cols))

      success = solve_evp_complex_2stage(na, nev, h_proj, na_rows, ev, z, na_rows,  nblk, na_cols, &
         mpi_comm_rows, mpi_comm_cols, op_comm)

      if (.not.(success)) then
         write(*,*) "solve_evp_real_2stage produced an error! Aborting..."
         call MPI_ABORT(op_comm, mpierr, info)
      endif

      !$OMP PARALLEL DO SIMD COLLAPSE(2) SCHEDULE(RUNTIME)
      do j = 1, na_cols
         do i = 1, na_rows
            h_proj(i,j) = z(i,j)
         enddo
      enddo
      !$OMP END PARALLEL DO SIMD
      deallocate(z)
   end subroutine zelpa_distributed1
   subroutine delpa_nondistributed(op_comm, uplo, amat, na, ev, nev, nblk)
      use elpa1
      use elpa2
      use constants
      use mpi

      use file_units, only : f_parsec
      implicit none

      integer, intent(in) :: op_comm
      character (len=1), intent(in) :: uplo  ! upper/lower matrix
      integer, intent(in) :: na  ! dimension of matrix A
      integer, intent(in) :: nev ! leading dimension of matrix A
      integer, intent(in) :: nblk ! blocking for block-cyclic amat_distributed
      real(dp), intent(inout) :: amat(na,nev) ! s x s dense matrix, post global reduction
      real(dp), intent(out) :: ev(nev) ! s eigenvalues

      integer np_rows, np_cols, na_rows, na_cols

      integer myid, nprocs, my_prow, my_pcol, mpi_comm_rows, mpi_comm_cols
      integer i, mpierr, my_blacs_ctxt, sc_desc(9), info, nprow, npcol
      real(dp), allocatable :: a(:,:), z(:,:)
      logical :: success

      ! scalapack function
      integer, external :: numroc

      call mpi_comm_rank(op_comm,myid,mpierr)
      call mpi_comm_size(op_comm,nprocs,mpierr)

      !-------------------------------------------------------------------------------
      ! Selection of number of processor rows/columns
      ! We try to set up the grid square-like, i.e. start the search for possible
      ! divisors of nprocs with a number next to the square root of nprocs
      ! and decrement it until a divisor is found.

      do np_cols = NINT(SQRT(REAL(nprocs))),2,-1
         if(mod(nprocs,np_cols) == 0 ) exit
      enddo
      ! at the end of the above loop, nprocs is always divisible by np_cols

      np_rows = nprocs/np_cols

      !-------------------------------------------------------------------------------
      ! Set up BLACS context and MPI communicators
      !
      ! The BLACS context is only necessary for using Scalapack.
      !
      ! For ELPA, the MPI communicators along rows/cols are sufficient,
      ! and the grid setup may be done in an arbitrary way as long as it is
      ! consistent (i.e. 0<=my_prow<np_rows, 0<=my_pcol<np_cols and every
      ! process has a unique (my_prow,my_pcol) pair).
      my_blacs_ctxt = op_comm
      call BLACS_Gridinit( my_blacs_ctxt, 'C', np_rows, np_cols )
      call BLACS_Gridinfo( my_blacs_ctxt, nprow, npcol, my_prow, my_pcol )

      ! All ELPA routines need MPI communicators for communicating within
      ! rows or columns of processes, these are set in get_elpa_row_col_comms.

      mpierr = get_elpa_communicators(op_comm, my_prow, my_pcol, &
         mpi_comm_rows, mpi_comm_cols)

      ! Determine the necessary size of the distributed matrices,
      ! we use the Scalapack tools routine NUMROC for that.

      na_rows = numroc(na, nblk, my_prow, 0, np_rows)
      na_cols = numroc(na, nblk, my_pcol, 0, np_cols)

      allocate(a (na_rows,na_cols))
      allocate(z (na_rows,na_cols))

      call section_matrix(na, a, na_rows, na_cols, nblk, my_prow, my_pcol, np_rows, &
         np_cols, op_comm, amat, uplo)

      success = solve_evp_real_2stage(na, nev, a, na_rows, ev, z, na_rows,  nblk, na_cols, &
         mpi_comm_rows, mpi_comm_cols, op_comm)

      if (.not.(success)) then
         write(*,*) "solve_evp_complex_2stage produced an error! Aborting..."
         call MPI_ABORT(op_comm, mpierr, info)
      endif

      call gather_matrix(na, z, na_rows, na_cols, nblk, my_prow, my_pcol, np_rows, &
         np_cols, op_comm, my_blacs_ctxt, amat, na)

      deallocate(a)
      deallocate(z)
      call blacs_gridexit(my_blacs_ctxt)

   end subroutine delpa_nondistributed
   subroutine zelpa_nondistributed(op_comm, uplo, amat, na, ev, nev, nblk)
      use elpa1
      use elpa2
      use constants
      use mpi
      use file_units, only : f_parsec
      implicit none

      integer, intent(in) :: op_comm
      character (len=1), intent(in) :: uplo  ! upper/lower matrix
      integer, intent(in) :: na  ! dimension of matrix A
      integer, intent(in) :: nev ! leading dimension of matrix A
      integer, intent(in) :: nblk ! blocking for block-cyclic amat_distributed
      complex(dpc), dimension(na,nev), intent(inout) :: amat ! s x s dense matrix, post global reduction
      real(dp), intent(out) :: ev(nev) ! s eigenvalues

      integer np_rows, np_cols, na_rows, na_cols

      integer myid, nprocs, my_prow, my_pcol, mpi_comm_rows, mpi_comm_cols
      integer i, mpierr, my_blacs_ctxt, sc_desc(9), info, nprow, npcol
      complex(dpc), allocatable :: a(:,:), z(:,:)
      logical :: success

      ! scalapack function
      integer, external :: numroc

      call mpi_comm_rank(op_comm,myid,mpierr)
      call mpi_comm_size(op_comm,nprocs,mpierr)

      !-------------------------------------------------------------------------------
      ! Selection of number of processor rows/columns
      ! We try to set up the grid square-like, i.e. start the search for possible
      ! divisors of nprocs with a number next to the square root of nprocs
      ! and decrement it until a divisor is found.

      do np_cols = NINT(SQRT(REAL(nprocs))),2,-1
         if(mod(nprocs,np_cols) == 0 ) exit
      enddo
      ! at the end of the above loop, nprocs is always divisible by np_cols

      np_rows = nprocs/np_cols

      !-------------------------------------------------------------------------------
      ! Set up BLACS context and MPI communicators
      !
      ! The BLACS context is only necessary for using Scalapack.
      !
      ! For ELPA, the MPI communicators along rows/cols are sufficient,
      ! and the grid setup may be done in an arbitrary way as long as it is
      ! consistent (i.e. 0<=my_prow<np_rows, 0<=my_pcol<np_cols and every
      ! process has a unique (my_prow,my_pcol) pair).
      my_blacs_ctxt = op_comm
      call BLACS_Gridinit( my_blacs_ctxt, 'C', np_rows, np_cols )
      call BLACS_Gridinfo( my_blacs_ctxt, nprow, npcol, my_prow, my_pcol )

      ! All ELPA routines need MPI communicators for communicating within
      ! rows or columns of processes, these are set in get_elpa_row_col_comms.

      mpierr = get_elpa_communicators(op_comm, my_prow, my_pcol, &
         mpi_comm_rows, mpi_comm_cols)

      ! Determine the necessary size of the distributed matrices,
      ! we use the Scalapack tools routine NUMROC for that.

      na_rows = numroc(na, nblk, my_prow, 0, np_rows)
      na_cols = numroc(na, nblk, my_pcol, 0, np_cols)

      allocate(a (na_rows,na_cols))
      allocate(z (na_rows,na_cols))

      call section_matrix(na, a, na_rows, na_cols, nblk, my_prow, my_pcol, np_rows, &
         np_cols, op_comm, amat, uplo)

      success = solve_evp_complex_2stage(na, nev, a, na_rows, ev, z, na_rows,  nblk, na_cols, &
         mpi_comm_rows, mpi_comm_cols, op_comm)

      if (.not.(success)) then
         write(*,*) "solve_evp_complex_2stage produced an error! Aborting..."
         call MPI_ABORT(op_comm, mpierr, info)
      endif

      call gather_matrix(na, z, na_rows, na_cols, nblk, my_prow, my_pcol, np_rows, &
         np_cols, op_comm, my_blacs_ctxt, amat, na)

      deallocate(a)
      deallocate(z)
      call blacs_gridexit(my_blacs_ctxt)

   end subroutine zelpa_nondistributed
#endif
end module elpa_custom
