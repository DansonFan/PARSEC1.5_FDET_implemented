!!> @file mkl_vsl_helper.f90
!> @details 
!! give us modules for Intel's MKL VSL stuff when their compiler source
!! is available
!! Intel MKL 17+
!!
!> @author Charles Lena
!> @date 2017-03-06
#ifdef USEMKL_VSL
#include "mkl_vsl.f90"
#else
!#message "Default random number generator. Super slow. Not great, not threadsafe, not smart"
!#error "--Not implemented"
!> @brief this module is a dirty hack to allow us to reuse code -CML
!> @note -- fill in values for variable basic rng choice
module mkl_vsl_fake
integer, parameter :: VSL_BRNG_MT19937 = -1 
integer, parameter :: VSL_RNG_METHOD_UNIFORM_STD = -1
type :: VSL_STREAM_STATE
  integer :: datum
end type
end module mkl_vsl_fake
#endif
