module cfftw_module
contains
!===============================================================
!
! Copyright (C) 2005 Finite Difference Research Group
! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
! Author: M. Alemany; interface with FFTW 3.* added by M. Tiago
!
! This file actually has a set of two subroutines, both called fftw:
! cpp option FFTW2 : interface with FFTW 2.1.* (and possibly older versions)
! cpp option FFTW3 : interface with FFTW 3.*
!
! \note AJB:NOTE it seems to me that parsec should be using real-2-complex fftws
! \note CML:NOTE We need to add a cleanup module here so that exit_err is less
!   flag dependent. That's the point of encapsulation
!
!---------------------------------------------------------------
   subroutine cfftw(chd,n1,n2,n3,mode)
      use constants
      use external_interfaces, only : zscal
#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
      use fftw3_module
#elif defined(USEFFTW3)
      use fftw3_module, only : dfftw_plan_dft_3d, dfftw_execute, dfftw_destroy_plan
#endif
      implicit none
      !
      ! Input/Output variables:
      !
      integer, intent(in) :: n1, n2, n3, mode
      complex(dpc), intent(inout) :: chd(n1*n2*n3)
#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
      integer(C_INT), dimension(3) :: n
      type(C_PTR) :: plan
#elif defined(USEFFTW3)
      ! Interface with FFTW3 library, parameters from fftw3.f
      integer, parameter :: fftw_estimate = 64
      integer, parameter :: fftw_forward = -1
      integer, parameter :: fftw_backward = +1
      integer (kind=8) plan
#endif
      integer :: k,j,i
      !
      ! Work variables:
      !
      integer dirn, tlen
      complex(dpc) :: fac
!  character (len=10) :: file_name
      !---------------------------------------------------------------
      tlen = n1*n2*n3
      if (mode > 0) then
         !file_name = 'forwardfft'
         dirn = fftw_forward
      else
         !file_name = 'backwrdfft'
         dirn = fftw_backward
      endif

#if defined(USEFFTW3) & defined(CREATE_FFTW3_MODULE)
!> @note - fftw3 bindings changed things -- see http://www.fftw.org/fftw3_doc/Reversing-array-dimensions.html#Reversing-array-dimensions
      n = [n3, n2, n1]
      plan = fftw_plan_dft(3, n, chd, chd, dirn, fftw_estimate)
      call fftw_execute_dft(plan, chd, chd)
      call fftw_destroy_plan(plan)
#elif defined(USEFFTW3)
!> @note - original fftw3 "bindings", which just targets the C functions
      call dfftw_plan_dft_3d(plan, n1, n2, n3, chd, chd, dirn, fftw_estimate)
      call dfftw_execute(plan)
      call dfftw_destroy_plan(plan)
#endif

      !in case we asked for "forward" also normalize:
      if (mode > 0) then
         fac = zone / real(tlen,dp)
         call zscal(tlen,fac,chd,1)
      endif

   end subroutine cfftw
!===============================================================
end module cfftw_module
