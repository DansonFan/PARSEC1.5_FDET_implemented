!> @file random.F90
!> @brief allows for use of stable deterministic complicated random
!! number routines 
!!
!> @details 
!! the main point of this is allowing for forward
!! fetch so that no matter the number of nodes, the vector generated
!! *across* them will be the same - so V = [v_1; v_2; ...; v_procs] is
!! the same if procs = 1 or some arbitrary number.
!! including random number interface from one of the scientific libraries. Choice of:
!! Intel MKL 17+
!! GNU GSL?
!!
!> @author Charles Lena
!> @date 2017-03-06
#ifndef STREAM_PAD_N
#define STREAM_PAD_N 16
#endif
module prandom_module
   !< @brief Contains all random number functionality for later
   !! replacement. We have issues debugging single issues because of
   !! our lack of reproducibility. This is for parallel use.
   !
   !< @author Charles Lena
   !< @date 2017-03-05
#if USEMKL_VSL
   use mkl_vsl_type
   use mkl_vsl
#else
   use mkl_vsl_fake
#endif
   implicit none
   integer, parameter :: K_RANGEN_USE_VSL = 0
   integer, parameter :: K_RANGEN_USE_PURE = 1
   integer, parameter :: K_RANGEN_USE_DEFAULT = K_RANGEN_USE_PURE
   integer, parameter :: K_ERR_RANGEN_UNSET = 700
   integer, parameter :: K_ERR_RANGEN_SEEDSIZE=710
   type :: padded_stream
      type(VSL_STREAM_STATE) :: stream !< stores the stream state for intel vsl
#if 0
      integer(kind=4), &
         dimension(STREAM_PAD_N) :: stream_pad !< padding for alignment amongst openmp
#endif
   end type padded_stream
   type :: random_generator
      type(padded_stream), allocatable :: stream(:) !< stores the stream state for intel vsl
      !! don't forget that for threaded regions we need to make sure we don't
      !! have cache clashing -- so appropriate padding will be required
      integer :: seed_size
      integer :: seed = 1337 !< stores seed for intel vsl
      integer, dimension(:), allocatable :: iseed(:)
      integer :: brng   = VSL_BRNG_MT19937 !< basic rng choice
      integer :: method = VSL_RNG_METHOD_UNIFORM_STD !< method of harvest

      procedure(init_random_generator_unset), pointer, pass :: init => init_random_generator_unset !< basic init the stream
      procedure(alloc_random_generator_unset), pointer, pass :: alloc => alloc_random_generator_unset !< allocates the stream
      procedure(createStream_rangen_unset), pointer, pass :: create => createStream_rangen_unset !< creates the stream
      procedure(destroyStream_rangen_unset), pointer, pass :: destroy => destroyStream_rangen_unset !< destroys the stream
      procedure(skipAheadStream_unset), pointer, nopass :: skip => skipAheadStream_unset !< skips a padded stream
      procedure(harvestStream_unset), pointer, nopass :: harvest => harvestStream_unset !< skips a padded stream
      contains
      procedure :: settype => settype_random_generator !< decide on which method to use
   end type random_generator
contains
   subroutine settype_random_generator(rangen, rangen_choice, ierr)
     use file_units, only: f_parsec
     implicit none
     class(random_generator), intent(inout) :: rangen
     integer, intent(in) :: rangen_choice
     integer, intent(out) :: ierr
     ierr = 0
     select case(rangen_choice)
     case (K_RANGEN_USE_VSL)
#if USEMKL_VSL
       rangen%init => init_random_generator_vsl
       rangen%alloc => alloc_random_generator_vsl
       rangen%create => createStream_rangen_vsl
       rangen%destroy => destroyStream_rangen_vsl
       rangen%skip => skipAheadStream_vsl
       rangen%harvest => harvestStream_vsl
#else
       write(f_parsec,'("ERROR: DID NOT BUILD WITH MKL VSL SUPPORT!")')
       ierr = -1
#endif
     case (K_RANGEN_USE_PURE)
       rangen%init => init_random_generator_pure
       rangen%alloc => alloc_random_generator_pure
       rangen%create => createStream_rangen_pure
       rangen%destroy => destroyStream_rangen_pure
       rangen%skip => skipAheadStream_pure
       rangen%harvest => harvestStream_pure
       ierr = 0
     case default
       write(f_parsec,'("ERROR: UNDEFINED CHOICE IN SETTYPE_RANDOM_GENERATOR!",I4)') rangen_choice
       ierr = -2
     end select
   end subroutine settype_random_generator
   !> @brief initializes
   !> @note not threaded
   subroutine init_random_generator_unset(rangen, brng, method, seed)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, optional :: brng
      integer, optional :: method
      integer, optional :: seed
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+0)
      stop intererrcode
   end subroutine init_random_generator_unset

   !> @brief used for multithreaded computation, gets called as part of setup
   subroutine alloc_random_generator_unset(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+1)
      stop intererrcode
   end subroutine alloc_random_generator_unset

   !> @brief Broadcasts seed for everyone to use as anchor point
   subroutine set_seed_mpi_unset(rangen, seed0, iam, comm, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout) :: seed0
      integer, intent(in) :: iam
      integer, intent(inout) :: comm
      integer, intent(inout) :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+2)
      stop intererrcode
   end subroutine set_seed_mpi_unset

   subroutine createStream_rangen_unset(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+3)
      stop intererrcode
   end subroutine createStream_rangen_unset
   !> @brief creates a stream for random number use
   subroutine createStream_component_unset(streams, nstreams, brng, seed0, rank, mpisize, errcode)
      implicit none
      integer, intent(in) :: nstreams !< ldn of streams
      type(padded_stream), intent(inout) :: streams(0:nstreams-1) !< the
      !! streamstates per thread
      integer, intent(in) :: brng !< basic random number generator we're using
      integer, intent(inout) :: seed0 !< initial seed state for stream?
      integer, intent(in) :: rank !< mpi rank of process
      integer, intent(in) :: mpisize !< mpi size of comm
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+4)
      stop intererrcode
   end subroutine createStream_component_unset

   subroutine skipAheadStream_unset(stream, nskip, errcode)
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer(kind=8), intent(in) :: nskip
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+5)
      stop intererrcode
   end subroutine skipAheadStream_unset

   !> @brief get random numbers from associated stream
   subroutine harvestStream_unset(stream, method, vec, ldn, ndim, a, b, errcode)
      use constants, only : dp
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer, intent(in) :: method
      integer, intent(in) :: ldn
      integer, intent(in) :: ndim
      real(dp), dimension(ldn), intent(inout) :: vec
      real(dp), intent(in) :: a, b
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+6)
      stop intererrcode
   end subroutine harvestStream_unset

   !> @brief delete stream
   subroutine destroyStream_rangen_unset(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout), optional :: errcode
      integer, parameter :: intererrcode = (K_ERR_RANGEN_UNSET+7)
      stop intererrcode
   end subroutine destroyStream_rangen_unset
   !> @brief initializes
   !> @note not threaded
   subroutine init_random_generator_pure(rangen, brng, method, seed)
     use file_units, only: f_outpar
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, optional :: brng
      integer, optional :: method
      integer, optional :: seed
      ! optional overrides
      call random_seed(size=rangen%seed_size)
      write(f_outpar,'("seed size:",*(I16))') rangen%seed_size
      allocate(rangen%iseed(rangen%seed_size))
      if(present(seed)) then
        rangen % iseed(1:rangen%seed_size) = seed
      else
        rangen % iseed(1:rangen%seed_size) = rangen % seed
      endif
      call random_seed(put=rangen % iseed(1:rangen%seed_size))
      write(f_outpar,'("sent seed:",*(I16))') rangen%iseed
      call random_seed(get=rangen % iseed(1:rangen%seed_size))
      write(f_outpar,'("cur. seed:",*(I16))') rangen%iseed
   end subroutine init_random_generator_pure

   !> @brief used for multithreaded computation, gets called as part of setup
   subroutine alloc_random_generator_pure(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout), optional :: errcode
      allocate(rangen % stream(0:0))
      if(present(errcode)) then
        errcode = 0
      endif
   end subroutine alloc_random_generator_pure

   !> @brief Broadcasts seed for everyone to use as anchor point
   subroutine set_seed_mpi_pure(rangen, seed0, masterid, comm, errcode)
#ifdef MPI 
      use mpi
#endif
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout) :: seed0
      integer, intent(in) :: masterid
      integer, intent(inout) :: comm
      integer, intent(inout) :: errcode
#ifdef MPI 
      call MPI_Bcast(seed0,1,MPI_INTEGER, masterid, comm, errcode)
#endif
   end subroutine set_seed_mpi_pure

   !> @brief creates a stream for random number use
   subroutine createStream_rangen_pure(rangen, errcode)
     use file_units, only: f_outpar
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout), optional :: errcode
      integer :: interrcode
      interrcode=0
      write(f_outpar,'("star seed:",*(I16))') rangen%iseed
      call random_seed(put=rangen % iseed(1:rangen%seed_size))
      write(f_outpar,'("sent seed:",*(I16))') rangen%iseed
      call random_seed(get=rangen % iseed(1:rangen%seed_size))
      write(f_outpar,'("cur. seed:",*(I16))') rangen%iseed
      if(present(errcode)) then
         errcode = interrcode
      endif
   end subroutine createStream_rangen_pure

   !> @brief skips ahead in the number line through discarding
   subroutine skipAheadStream_pure(stream, nskip, errcode)
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer(kind=8), intent(in) :: nskip
      integer, intent(inout), optional :: errcode
      real :: trash(1:nskip)
      integer :: interrcode
      interrcode = 0
      call random_number(harvest=trash(1:nskip))
      if(present(errcode)) then
         errcode=interrcode
      endif
   end subroutine skipAheadStream_pure

   !> @brief get random numbers from associated stream
   subroutine harvestStream_pure(stream, method, vec, ldn, ndim, a, b, errcode)
      use constants, only : dp
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer, intent(in) :: method
      integer, intent(in) :: ldn
      integer, intent(in) :: ndim
      real(dp), dimension(ldn), intent(inout) :: vec
      real(dp), intent(in) :: a, b
      integer, intent(inout), optional :: errcode
      integer :: interrcode
      interrcode = 0
      call random_number(harvest=vec(1:ndim))
      vec(1:ndim) = vec(1:ndim) * (b-a) + a
      if(present(errcode)) then
         errcode = interrcode
       endif
   end subroutine harvestStream_pure

   !> @brief delete stream
   subroutine destroyStream_rangen_pure(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout), optional :: errcode
      integer :: i
      integer :: intererrcode
      intererrcode = 0
      if(allocated(rangen % stream)) then
         deallocate(rangen % stream)
      endif
   end subroutine destroyStream_rangen_pure
   !> @brief initializes
   !> @note not threaded
#if USEMKL_VSL
   subroutine init_random_generator_vsl(rangen, brng, method, seed)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, optional :: brng
      integer, optional :: method
      integer, optional :: seed
      ! optional overrides
      if(present(brng)) rangen % brng = brng
      if(present(method)) rangen % method = method
      call random_seed(size=rangen%seed_size)
      allocate(rangen%iseed(rangen%seed_size))
      if(present(seed)) then
        rangen % iseed(1:rangen%seed_size) = seed
      else
        rangen % iseed(1:rangen%seed_size) = rangen % seed
      endif
      call random_seed(put=rangen % iseed)
   end subroutine init_random_generator_vsl

   !> @brief used for multithreaded computation, gets called as part of setup
   subroutine alloc_random_generator_vsl(rangen, errcode)
#ifdef PRNG_THREADED_MKLVSL
      use omp_lib
#endif
      implicit none
      class(random_generator), intent(inout) :: rangen
#ifdef PRNG_THREADED_MKLVSL
      integer :: ctid
      integer :: mytid
#else
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
#endif
      integer, intent(inout), optional :: errcode
#ifdef PRNG_THREADED_MKLVSL
      !$OMP PARALLEL SHARED(rangen) PRIVATE(ctid)
      ctid = omp_get_num_threads()
      !$OMP MASTER
#endif
      allocate(rangen % stream(0:ctid-1)) ! note that this is indexed from 0 for thread identity reasons!
#ifdef PRNG_THREADED_MKLVSL
      !$OMP END MASTER
      !$OMP END PARALLEL
#endif
   end subroutine alloc_random_generator_vsl

   !> @brief Broadcasts seed for everyone to use as anchor point
   subroutine set_seed_mpi_vsl(rangen, seed0, iam, comm, errcode)
#ifdef MPI 
      use mpi
#endif
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout) :: seed0
      integer, intent(in) :: iam
      integer, intent(inout) :: comm
      integer, intent(inout) :: errcode
   end subroutine set_seed_mpi_vsl

   subroutine createStream_rangen_vsl(rangen, errcode)
#ifdef PRNG_THREADED_MKLVSL
      use omp_lib
#endif
      implicit none
      class(random_generator), intent(inout) :: rangen
#ifdef PRNG_THREADED_MKLVSL
      integer :: ctid
      integer :: mytid
#else
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
#endif
      integer, intent(inout), optional :: errcode
      integer :: interrcode
#ifdef PRNG_THREADED_MKLVSL
      interrcode = -9999
! $OMP PARALLEL PRIVATE(ctid,mytid) SHARED(rangen % stream) REDUCTION(max:interrcode)
      ctid = omp_get_num_threads()
      mytid = omp_get_thread_num()
#endif
      write(9,*) 'rangen seed=',rangen % iseed(1)
      interrcode = vslnewstream(  rangen % stream(mytid) % stream,  rangen % brng,  rangen % iseed(1) )
#ifdef PRNG_THREADED_MKLVSL
! $OMP END PARALLEL
#endif
      if(present(errcode)) then
         errcode = interrcode
      endif
   end subroutine createStream_rangen_vsl
   !> @brief creates a stream for random number use
   subroutine createStream_component_vsl(streams, nstreams, brng, seed0, rank, mpisize, errcode)
#ifdef PRNG_THREADED_MKLVSL
      use omp_lib
#endif
      implicit none
      integer, intent(in) :: nstreams !< ldn of streams
      type(padded_stream), intent(inout) :: streams(0:nstreams-1) !< the
      !! streamstates per thread
      integer, intent(in) :: brng !< basic random number generator we're using
      integer, intent(inout) :: seed0 !< initial seed state for stream?
      integer, intent(in) :: rank !< mpi rank of process
      integer, intent(in) :: mpisize !< mpi size of comm
#ifdef PRNG_THREADED_MKLVSL
      integer :: ctid
      integer :: mytid
#else
      integer, parameter :: ctid = 1
      integer, parameter :: mytid = 0
#endif
      integer, intent(inout), optional :: errcode
      integer :: interrcode
#ifdef PRNG_THREADED_MKLVSL
      mytid = omp_get_thread_num()
#endif
      interrcode = vslnewstream(  streams(mytid) % stream,  brng,  seed0 )
      if(present(errcode)) then
         errcode = interrcode
      endif
   end subroutine createStream_component_vsl

   subroutine skipAheadStream_vsl(stream, nskip, errcode)
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer(kind=8), intent(in) :: nskip
      integer, intent(inout), optional :: errcode
      integer(kind=8) :: nskip_conv
      integer :: interrcode
      nskip_conv = int(nskip,8)
      interrcode = vslSkipAheadStream(stream % stream, nskip_conv)
      if(present(errcode)) then
         errcode=interrcode
      endif
   end subroutine skipAheadStream_vsl

   !> @brief get random numbers from associated stream
   subroutine harvestStream_vsl(stream, method, vec, ldn, ndim, a, b, errcode)
      use constants, only : dp
      implicit none
      type(padded_stream), intent(inout) :: stream
      integer, intent(in) :: method
      integer, intent(in) :: ldn
      integer, intent(in) :: ndim
      real(dp), dimension(ldn), intent(inout) :: vec
      real(dp), intent(in) :: a, b
      integer, intent(inout), optional :: errcode
      integer :: interrcode
      if(present(errcode)) then
         errcode = vdRngUniform(method, stream % stream, ndim, vec, a, b)
      else
         interrcode = vdRngUniform(method, stream % stream, ndim, vec, a, b)
      endif
   end subroutine harvestStream_vsl

   !> @brief delete stream
   subroutine destroyStream_rangen_vsl(rangen, errcode)
      implicit none
      class(random_generator), intent(inout) :: rangen
      integer, intent(inout), optional :: errcode
      integer :: i
      integer :: intererrcode
      intererrcode = 0
      if(allocated(rangen % stream)) then
         do i = 0,size(rangen % stream,1)-1
            write(9,*) 'deleting stream=',i
            intererrcode = max(intererrcode, vsldeletestream( rangen % stream(i) % stream ))
         enddo
         deallocate(rangen % stream)
      endif
   end subroutine destroyStream_rangen_vsl
#endif
end module prandom_module
