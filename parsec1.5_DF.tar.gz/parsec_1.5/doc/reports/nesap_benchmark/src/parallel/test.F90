!===============================================================
!!
!> \copyright Copyright (C) 2018 Finite Difference Research Group
!! This file is part of parsec, http://www.ices.utexas.edu/parsec/
!!
!> \brief  Represent test logic
!> \author Charles Lena
!!
!---------------------------------------------------------------
module test_module
! test logic options
   integer, parameter :: k_test_none = 0 
   integer, parameter :: k_test_forces= 1
   integer, parameter :: k_test_lanczos= 2

   type tests_data
      integer :: logic = k_test_none
      contains
      procedure :: bcast => bcast_tests
   endtype tests_data
contains
   subroutine bcast_tests(tests, masterid, comm, mpinfo)
#ifdef WITH_MPI_F08
      use mpi_f08
#elif defined(MPI)
      use mpi
#endif
      class(tests_data), intent(inout) :: tests
#ifdef WITH_MPI_F08
      type(mpi_comm), intent(in) :: comm !< actual mpi_comm
#else
      integer, intent(in) :: comm !< integer mpi_comm
#endif
      integer, intent(in) :: masterid !< mpi_rank
      integer, intent(out) :: mpinfo !< error code

      call MPI_BCAST(tests%logic,1,MPI_LOGICAL,masterid,comm,mpinfo)
   end subroutine bcast_tests
end module
