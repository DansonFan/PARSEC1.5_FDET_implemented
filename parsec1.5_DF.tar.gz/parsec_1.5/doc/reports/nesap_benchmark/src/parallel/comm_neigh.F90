module comm_neigh_module
   implicit none
   contains
!===============================================================
!
!  Copyright (C) 2005 Finite Difference Research Group
!  This file is part of parsec, http://www.ices.utexas.edu/parsec/
!
!  AJB: BEGIN UPDATE
!
!  Defines:  
!      1. parallel%neibs in local form
!      2. irecvp,jsendp,senrows indices for exchanging
!         info in matvec
!      2. New: TODO - for irecvp - map whose row this belongs to 
!                                  and the neihbor distance
!  Old text:
!      3. ip1,jp1 for exchanging info in preconditioning
!  New:
!      3. ip1,jp1 markers disabled
!  Old text:
!      4. pint local permutation with inter1,inter2 interior points
!  New:
!      4. TODO: pint local permutation is not needed but kept for compatabililty
!

!  Rewrites parallel%neibs with a local one with the properties:
!
!              |--> parallel%neibs(neigh,row)-ioffset for all 
!              |     neighbors "neigh" local on this processor
!              |
!  parallel%neibs(neigh,row)= --> position of neigh, (> mydim) in the boundary 
!              |    values appended at the end of the current vector.
!              |    This is the "neigh" neighbor of the local "row" 
!              |   
!              |--> ndim+1 for all unused neighbors 
!
!  The boundary values needed from this node are padded at the
!  end of a local vector in a boundary-exchange information step.
!
!                     Receive and append info from 
!             local on the node    Proc1  Proc2  Proc4
!           <-------------------> <-----> <---> <------->
!
!  There is a local IP array : IP(i) = where the info from proc i
!  should be padded at. (eg IP(0) = ndim + 1, and IP(1) = ndim + 1
!  if nothing is received from proc 0). The rows that must be sent
!  to other processors are in senrows with index for each proc JP
!  Then matrix vector multiply is performed by exchanging info
!  filling the padded area and running the old mat-vec on it.
!
!  Also IP1 and JP1 are used for the communication in the 
!  preconditioning. This uses only the first shell (neighbors up
!  to norder) for every point. Since these are numbered first in
!  the boundary we put them in the same positions as in matvec.
!  Then parallel%neibs knows how to access them. Notice that IP
!  carries the positions of where they should be put. So we only
!  keep the sizes. Since we number the first shell first, the
!  senrows will contain exactly these rows if we take JP1(*) of them.
!
!  COMMUNICATION SIZE GRAPH:
!              Recv from 
!   local on the node    Proc1  Proc2  Proc4
! <-------------------> <-----> <---> <------->  index IP  (matvec)
!                       <->     <->   <-->    sizes in IP1 (precond)
!
!                  senrows
! <----------------------------------------->
! send Proc1     Proc2    Proc3      Proc4
! <-------><---------><------><------------->    index JP  (matvec)
! <-->     <-->       <->     <----->         sizes in JP1 (precond)
!
!----------------------------------------------------------------------
!  Experimentally sort first the interior rows (ie that do not 
!  require any neighbors from other nodes). Sort second the rows
!  that do not require any first shell neighbors. These will be
!  considered interior for the preconditioning. Permutation array
!  is pint and the above numbers inter1 and inter2 respectively.
!                        pint
!            <----------------------------------------->
!            <---------> inter1
!            <---------------------------> inter2
!
!	Algorithm
!  Count how many and which rows I need from each processor. (irecvp)
!  Also count the number of my rows each of my neighbors needs (jsendp)
!  (each time irow needs info from proc node, irow will be needed
!  by proc node -symmetric matrix-. If I have not received this
!  row already, add it in irecvp for reception. For sending out, a 
!  row should be sent only once to a node and not for all the 
!  neighbors of this row that reside on that node. To guarantee
!  that, for each node a flag array is updated for each row.
!  To keep the order of reception same to the one that other procs
!  will compute ---to retain locality in the access pattern of 
!     neighbors--- senrows is used as scratch to store the order.
!
!---------------------------------------------------------------
! Modified to eliminate local stack arrays.  MGR 16feb09
!---------------------------------------------------------------
subroutine comm_neigh(parallel,norder)

  use constants
  use parallel_data_module
#ifdef MPI
  !   include mpi definitions
  use mpi
#endif

  implicit none
  !
  !  Input/Output variables:
  !
  !  parallel computation related data
  type (parallel_data), intent(inout) :: parallel
  !  number of neighbors used on one side in numerical derivative
  integer, intent(in) :: norder
  !
  !  Work variables:
  !
    integer :: maxBlocks(3),maxmaxBlocks
  integer nnodes,iam,node,mpinfo
  integer ielem,jelem,istart,jstart,irow,myrow,itemp,mydim &
       ,ioffset,ncur,ish,their_row

  logical, allocatable :: sentto(:,:)
  integer, allocatable :: received(:)

  integer, dimension(:), allocatable :: &
      irows,isendcount,irecvcount

  integer, allocatable :: recrows(:)

  integer :: neibs_num

  integer inter1, inter2

  integer i, alcstat , ierr
  !---------------------------------------------------------------
        !specific debug:
         ! write(9,*) "I: content of parallel%neibs(:,731)"
         ! write(9,*) parallel%neibs(:,731)

  !  Initializations
  iam = parallel%group_iam
  nnodes = parallel%group_size

  allocate(irows(0:nnodes))
  allocate(sentto(parallel%mydim,0:nnodes))
  allocate(isendcount(0:nnodes))
  allocate(irecvcount(0:nnodes))
  allocate(received(parallel%nwedge))
  allocate(recrows(parallel%nwedge))

  irows(:) = parallel%irows
  ioffset = irows(iam) - 1
  mydim   = parallel%mydim

  neibs_num = 6 + 2*parallel%lap_dir_num

  received(:) = 0
  recrows(:) = 0
  parallel%senrows(:) = 0
  parallel%irecvp(:) = 0
  parallel%jsendp(:) = 0
  ! parallel%ip1(:) = 0  %these are off - for now
  ! parallel%jp1(:) = 0
  isendcount(:) = 0
  irecvcount(:) = 0

  sentto(:,:) = .false.
  inter1 = 0
  !
  !  * Experimental *
  !  *** notice that locality on the vec won't be great in matvec
  !  *** Eventually parallel%neibs must be turned into
  !  *** parallel%neibs(rows,neighbors)
  !  *** We will have to experiment with the effects of index pint
  !
  !
  ncur = 0
  !  for all neighbors of this row: 
  !  2*(3+lap_dir_num)*norder (first shell first)

  do ish = 1, neibs_num*norder
     do myrow = 1, mydim
        irow = parallel%neibs(ish,myrow)
  !  find PE # of neighbor irow
  ! if you cant find it (outside domain) - it is on your node
        node = lochome(irow,nnodes,irows,iam)

        if (node /= iam) then
           if (.not.sentto(myrow,node)) then
              parallel%jsendp(node) = parallel%jsendp(node) + 1
              ! AJB: ish=6 is last element in the first shell
              ! We don't use this kind of thing around here for now
              !if (ish < 7) parallel%jp1(node) = parallel%jp1(node)+1
              sentto(myrow,node) = .true.
           endif
           if (received(irow) ==  0) then
              parallel%irecvp(node) = parallel%irecvp(node) + 1
              ! AJB: ish=6 is last element in the first shell
              ! We don't use this kind of thing around here for now
              !if (ish < 7) parallel%ip1(node) = parallel%ip1(node)+1
              ncur = ncur + 1
              parallel%senrows(ncur) = irow
              ! AJB: it seems that we add 1 so that node 0 wont screw up the loop?
              received(irow) = node+1
           endif
        endif
     enddo                  ! myrow = 1, mydim
  enddo                     ! ish = 1,2*(3+parallel%lap_dir_num)*norder
  !
  !  Find where info from (irecvp) and to (jsendp) each proc starts
  !
  ielem = parallel%irecvp(0)
  jelem = parallel%jsendp(0)
  parallel%irecvp(0) = 1
  parallel%jsendp(0) = 1
  do node = 1, nnodes
     istart = parallel%irecvp(node-1) + ielem
     jstart = parallel%jsendp(node-1) + jelem
     ielem = parallel%irecvp(node)
     jelem = parallel%jsendp(node)
     parallel%irecvp(node) = istart
     parallel%jsendp(node) = jstart
  enddo
  !
  !  Use received and senrows arrays to paste together the columns 
  !  I will need. Reset received to zero wherever it has something
  !  else. Rows are according to the global permutation.
  !
  do i = 1, ncur
     irow = parallel%senrows(i)
     node = received(irow)-1
     received(irow) = 0
     recrows( parallel%irecvp(node) ) = parallel%senrows(i)
     parallel%irecvp(node) = parallel%irecvp(node) + 1
  enddo
  !
  !
  !  Restore the ip index to starting points in the appended vector
  !  for each node. This is local now (eg irecvp(0) = 1 + mydim)
  !
  do i = nnodes-1,1,-1
      ! write(9,*) "in comm_neigh, initial irecvp while node=",i
      ! write(9,*) parallel%irecvp
     parallel%irecvp(i) = parallel%irecvp(i-1) + mydim
  enddo
  parallel%irecvp(0) = 1 + mydim
      ! write(9,*) "in comm_neigh, zipped irecvp"
      ! write(9,*) parallel%irecvp
  !
  !  Go through parallel%neibs array to reset the neigh global
  !  indexing to a local. Notice the order of the loops must be the
  !  same as in previous loops over ish, myrow.
  !  IMPORTANT: Since this is not 1-to-1 mapping, the same row may
  !  be accessed as a neighbor of many rows in parallel%neibs. To
  !  remember where this row resides in the new order, the received
  !  array now records the position of the first time this row
  !  (neighbor) is encountered.
  !
  do ish = 1,neibs_num*norder
  !  for this neighbor of all rows
     do myrow = 1, mydim
        irow = parallel%neibs(ish,myrow)
        node = lochome(irow,nnodes,irows,iam)
        if (node /= iam) then
           if (received(irow) ==  0) then
              ! First time encountered. Change irecvp, received
              received(irow)  = parallel%irecvp(node)
              if(parallel%irecvp(node) > parallel%irecvp(nnodes)+mydim) then
                  ! AJB: this seems to be a problem then!
                  write(9,*) 'WARNING?! in comm_neigh:'
                  write(9,*) 'ipn>> ',ish,myrow,irow,parallel%irecvp(node),parallel%irecvp(nnodes)
              endif

              parallel%irecvp(node) = parallel%irecvp(node) + 1
           else
              ! This row exists already in the list
              if(received(irow) > parallel%irecvp(nnodes)+mydim .or. received(irow) < 1) then 
                  ! AJB: this seems to be a problem too!
                  write(9,*) 'WARNING?! in comm_neigh:'
                  write(9,*) 'exs>> ',ish ,myrow,irow,received(irow)
              endif
          endif !received==0
           parallel%neibs(ish,myrow) = received(irow)

        else
           ! AJB: prune the tree towards nwedge+1
           if (irow == parallel%nwedge+1) cycle
           parallel%neibs(ish,myrow) = irow - ioffset 
        endif
     enddo                  ! myrow = 1, mydim
  enddo
  
           
        !specific debug:
         ! write(9,*) "II: content of parallel%neibs(:,731)"
         ! write(9,*) parallel%neibs(:,731)
  !
  !
  !  Restore again the irecvp index to starting points, but in the 
  !  non-appended vector to be used in the alltoall
  !
  !
  do i = nnodes-1,1,-1
     parallel%irecvp(i) = parallel%irecvp(i-1)-mydim
  enddo
  parallel%irecvp(0) = 1 
  !
  !  Communicate the information from other processors' irecvp into 
  !  the appropriate jsendp locations. This is an alltoallv step 
  !  where the j-th section of recrows (from irecvp(j) to irecvp(j+1)-1) on 
  !  processor i, goes to the j-th processor senrows between its 
  !  jsendp(i) and jsendp(i+1)-1.
  !
  do i=0,nnodes-1
     isendcount(i) = parallel%irecvp(i+1)-parallel%irecvp(i)
     irecvcount(i) = parallel%jsendp(i+1)-parallel%jsendp(i)
  enddo
  do i=0,nnodes
     parallel%irecvp(i) = parallel%irecvp(i)-1
     parallel%jsendp(i) = parallel%jsendp(i)-1
  enddo

  ! write(9,*) "isendcount"
  ! write(9,*) isendcount
  ! write(9,*) "irecvcount"
  ! write(9,*) irecvcount
  ! write(9,*) "parallel%irecvp"
  ! write(9,*) parallel%irecvp
  ! write(9,*) "parallel%jsendp"
  ! write(9,*) parallel%jsendp

#ifdef MPI
  call MPI_Alltoallv(recrows,isendcount, parallel%irecvp, MPI_INTEGER, &
       parallel%senrows,irecvcount, parallel%jsendp, MPI_INTEGER,parallel%group_comm,mpinfo)
#endif
  !
  !  Finally, restore irecvp and jsendp indices 
  !
  do i = 0, nnodes
     parallel%irecvp(i) = parallel%irecvp(i) + 1 + mydim
     parallel%jsendp(i) = parallel%jsendp(i) + 1
  enddo

  parallel%myworkdim = mydim + parallel%irecvp(nnodes) - parallel%irecvp(0)
  !parallel%myworkdim = parallel%nwedge

        ! change the neib structure so that instead of nwedge+1
        ! the external points are at mydim+ irecvp(nnodes)-irecvp(0) + 1
        ! this has to be done this way since we cannot expect each PE to
        ! allocate the entire wedge!
        do myrow = 1,mydim
            do ish = 1,neibs_num*norder
            irow = parallel%neibs(ish,myrow)
            if (irow > parallel%nwedge) then
!                write(9,*) "comm_neigh: found external in irow",irow
                parallel%neibs(ish,myrow) = parallel%myworkdim + 1
!                write(9,*) "comm_neigh: now irow is",parallel%neibs(ish,myrow)
            endif
            enddo
        enddo

  !  Find and permute the inter1 interior points in pint
  !
  do i = 1, mydim
     parallel%pint(i) = i
  enddo
  ! Block laplacian sketch: start from bottom corner (min_i,min_j,min_k)
  !
  !    0. block += 1, first_point=irow(min_i,j,k)
  !    a. Does this point have a neighbor which is >mydim?
  !    b. if yes - Does this point have a neighbor which is outside domain?
  !    c. if so mark the entire block as  block_type(block)=ext
  !    d. if not mark the entire blok as block_type(block)=comm
  !       if it has both external and neighbor mark the entire block as
  !       block_type(block)=ext+comm
  !       else block_type(block)=normal
  !    e. travel = neighbor to switch to inside the block via traversal order &
  !        next point = neighb(travel,myrow)
  !        goto a.
  !    f. else if travel = end go to next block via block traversal order next
  !    block = neighb(travel_outside_block,first_point)
  !    
  ! g (finally) sort blocks as normal ext comm ext+comm

  !but for now...

  do myrow = 1,mydim
     do ish = 1,2*(3+parallel%lap_dir_num)*norder
        irow = parallel%neibs(ish,myrow)
        if (irow > mydim) goto 10 ! interface row !AJB ....change here...
     enddo
     inter1 = inter1+1      ! interior node 
     itemp  = parallel%pint(myrow)   ! permute to the begining !AJB ...maybe not...
     parallel%pint(myrow) = parallel%pint(inter1)
     parallel%pint(inter1)= itemp
 10  continue
  enddo
  !
  !  Find interior rows (not having first shell neighbors on other procs)
  !
  !  AJB: Less important now that DIAGLA was removed
  inter2 = 0
  !inter2 = inter1
  ! do myrow = inter1+1, mydim
  !    do ish = 1,2*(3+parallel%lap_dir_num)
  !       irow = parallel%neibs(ish,myrow)
  !       if (irow > mydim) goto 11 ! interface row
  !    enddo
  !    inter2 = inter2 + 1    ! no first shell neighs
  !    itemp  = parallel%pint(myrow)   ! permute this row
  !    parallel%pint(myrow) = parallel%pint(inter2)
  !    parallel%pint(inter2)= itemp
 ! 11  continue
  ! enddo
  !  printout
  write(9,*) 'INTERIOR POINTS Mvec, PreCond (', inter1,inter2, ') '
  if (inter1 == 0) then
  write(9,*) 'WARNING, NO MATVEC INTERIOR POINTS'
  write(9,*) 'CURRENT SYSTEM SIZE/PE RATIO NOT RECOMMENDED'
  endif
  parallel%inter1=inter1
  parallel%inter2=inter2
  !  Change the senrows to local numbering (subtract the offset)
  do i = 1, parallel%jsendp(nnodes)-1
     parallel%senrows(i) = parallel%senrows(i) - ioffset
  enddo




  deallocate(received)
  deallocate(recrows)
  deallocate(irows)
  deallocate(sentto)
  deallocate(isendcount)
  deallocate(irecvcount)

end subroutine comm_neigh
!subroutine make_sparse_lap_coo(parallel,params) !{{{
!!=========================================================================
!!  This subroutine creates the laplacian operator for the grid This is
!!  essentialy the graph in COO format.  The data column for the matrix are
!!  integers representing the 3-d distance between neigbors, according to
!!  their order in parallel%neibs, so 1=+x,2=-x,3=+y,4=-y etc.
!
! !later - maybe shift ish so that directions are +-1 for x, +=2 for y etc
!!  
!!  converting the data column into the real coefficent matrix is is done in
!!  a different subroutine
!!
!!  We will have to test wether it is more efficent to store this as a sum of
!!  a few matrices, each stored in a different sparse format
!!
!!  Author: AJB
!!
!    use constants
!    use parallel_data_module
!
!  implicit none
!
!  !  Input/Output variables:
!  !  parallel computation related data
!  type (parallel_data), intent(inout) :: parallel
!  !  parameters from comm_neigh that are needed here:
!  integer, intent(in) :: params(5) !params(1) = FD order (half-order actually)
!                                   !params(2) = reserved
!                                   !params(3) = number of rows needed from other PEs
!                                   !params(4) = reserved
!                                   !params(5) = reserved
!
!  ! Work variables
!  integer :: norder,neibs_num,ext_nzcount
!  integer, allocatable :: nzcount_ish(:)
!  ! the two sparse matrices in coo format
!  ! the csr matrices made from these are part of spmatvec_base
!  ! we also hold these in spmatvec_base
!  ! integer, allocatable :: coo_sprs_row(:),coo_sprs_col(:),coo_sprs_ishval(:)
!  ! integer, allocatable :: ext_sprs_row(:),ext_sprs_col(:),ext_sprs_ishval(:)
!  ! compatabililty:
!  ! integer, dimension(:), allocatable :: irows
!
!  integer irow,myrow,mydim,ioffset,ncur,ish,cooind,extind
!
!
!  ! integer i, alcstat ,nzcount, ierr
!
!  ! ! for dev. purposes:
!  ! ! timer objects
!   real(dp)            ::t0,t1
!   character(len=4)    :: idstring
!
!  ! integer :: neibs_num
!
!
!  !---------------------------------------------------------------
!
!
!  !  Initializations - this is purposely similar to comm_neigh 
!!  iam = parallel%group_iam
!!  nnodes = parallel%group_size
!
!  ! allocate(irows(0:nnodes))
!  ! irows(:) = parallel%irows
!
!  !ioffset = parallel%irows(iam) - 1
!  mydim   = parallel%mydim
!
!  norder = params(1)
!  neibs_num = 6 + 2*parallel%lap_dir_num
!
!  ! go over all parallel neibs (here already in the local indexing)
!  ! and begin the splitting by counting the number neighbors actually
!  ! present on the PE local memory and those that are not
!  ext_nzcount = 0
!  allocate(nzcount_ish(neibs_num*norder))
!  nzcount_ish(:) = 0
!!#ifdef 1
!  call mysecond(t0)
!!#endif
!!$OMP PARALLEL DO COLLAPSE(2) &
!!$OMP& DEFAULT(SHARED) PRIVATE(irow) & 
!!$OMP& REDUCTION(+:ext_nzcount,nzcount_ish)
!  do myrow = 1, mydim
!      do ish = 1,neibs_num*norder
!        irow = parallel%neibs(ish,myrow)
!            if (irow > mydim) then
!                !we don't want to think about elements
!                !that are outside of the edge
!                if (irow < parallel%myworkdim+1) then
!                ext_nzcount=ext_nzcount+1
!                endif
!            else
!            !$OMP ATOMIC
!                nzcount_ish(ish)=nzcount_ish(ish)+1
!            endif
!       enddo      !ish
!  enddo           ! myrow = 1, mydim
!!$OMP END PARALLEL DO  
!!#ifdef 1
!  call mysecond(t1)
!    write(9,*) "time to sort through original neibs", t1-t0
!    write(9,*) "Laplacian structure:"
!    write(9,*) "non-zero elements present on this PE:", sum(nzcount_ish(:))
!    write(9,*) "nnz elements received from other PEs:", ext_nzcount
!    ! write(9,*) nzcount_ish
!!#endif
!
!
!  ! AJB: I want to hold the shell and the local row that needs the recrows/senrows
!  ! such that 
!  ! laplcian(myrow)= laplacian(local_rows)+sum(data(recrows)*coefficent(ish))
!  !
!  ! Eventually we might create several COO sparse matrices for this purpose, but 
!  ! currently two is enough - one for external neibs and one for my neibs.
!
!! allocate the coo structures (no need to init)
!call coo_sprs%alloc(sum(nzcount_ish)+mydim) !+mydim is for the diagonal zero
!call ext_sprs%alloc(ext_nzcount)
!
!!actually create the coo matrices:
!!Difficult to do in openmp so we won't do it right now
!!#ifdef 1
!  call mysecond(t0)
!!#endif
!  cooind = 0
!  extind = 0
!  do myrow = 1, mydim
!  ! MKL may also want to hold the matrix 
!  ! zeros if you want to use the symmetry
!  ! add the zero diagonal first
!    cooind = cooind + 1
!    coo_sprs%row(cooind) = myrow
!    coo_sprs%col(cooind) = myrow
!    coo_sprs%ishval(cooind) = 0
!
!      do ish = 1,neibs_num*norder
!        irow = parallel%neibs(ish,myrow)
!            if (irow > mydim) then !single direction
!                if (irow < parallel%myworkdim+1) then
!                !add to COO index of ext
!                extind = extind + 1
!                ext_sprs%row(extind) = myrow
!                !I should have commented on whats going on in this line:
!                ext_sprs%col(extind) = irow - mydim
!                ext_sprs%ishval(extind) = ish
!                endif
!            else !bidirectional!
!                !add to COO index
!                cooind = cooind + 1
!                coo_sprs%row(cooind) = myrow
!                coo_sprs%col(cooind) = irow
!                coo_sprs%ishval(cooind) = ish
!            endif
!       enddo      !ish
!  enddo           ! myrow = 1, mydim
!!#ifdef 1
!   
!
!  call mysecond(t1)
!
!    write(9,*) ""
!    write(9,*) "Time used to create coo sparse matrices", t1-t0
!    ! write(9,*) "non zero elements on ext coo", extind
!    ! write(9,*) "non zero elements on local coo:", cooind
!    write(9,*) ""
!!#endif
!!
!! NOW WOULD BE THE TIME TO APPLY REORDERING AND UPDATE parallel%pint
!! Also need to update ext_sprs with the same permutation. If you are
!! reordering the actual points, need to make sure
!! that when packing the rows for sending, you use the reodered indices
!!{{{ DEBUG - print the matrices
!#ifdef SPRSDEBUG
!  ! huge files:
!    write(idstring,'(I4.4)') parallel%iam !limited for 10k PE
!    open(46,file='mycoo_val.'//idstring,form='formatted',status='unknown')
!    open(47,file='mycoo_col.'//idstring,form='formatted',status='unknown')
!    open(48,file='mycoo_row.'//idstring,form='formatted',status='unknown')
!   write(46,300) coo_sprs%ishval
!   close(46)
!
!   write(47,300) coo_sprs%col
!   close(47)
!
!   write(48,300) coo_sprs%row
!   close(48)
!
!  ! huge file:
!    write(idstring,'(I4.4)') parallel%iam !limited for 10k PE
!    open(46,file='extcoo_val.'//idstring,form='formatted',status='unknown')
!    open(47,file='extcoo_col.'//idstring,form='formatted',status='unknown')
!    open(48,file='extcoo_row.'//idstring,form='formatted',status='unknown')
!   write(46,300) ext_sprs%ishval
!   close(46)
!
!   write(47,300) ext_sprs%col
!   close(47)
!
!   write(48,300) ext_sprs%row
!   close(48)
!300 format (I8)
!#endif 
!!}}}
!
! end subroutine make_sparse_lap_coo !}}}

!===============================================================
!
!  Returns the processor that the global row irow is on.
!
!---------------------------------------------------------------
integer function lochome(irow,nnodes,irows,iam)

  implicit none
  !
  !  Input/Output variables:
  !
  integer, intent(in) :: irow, iam, nnodes
  integer, intent(in) :: irows(0:nnodes)
  !
  !  Work variables:
  !
  integer i
  !---------------------------------------------------------------
  lochome = iam
  do i = 0, nnodes-1
     if (irows(i) <= irow .and. irow < irows(i+1)) then
        lochome = i
        exit
     endif
  enddo

end function lochome
end module comm_neigh_module
