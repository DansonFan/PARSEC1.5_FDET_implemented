#if defined(WITH_MPI_F08)
#define MPI_COMM_T type(mpi_comm)
#else
#define MPI_COMM_T type(integer)
#endif
module blockcyclic_utility
#if defined(WITH_SCALAPACK) || defined(WITH_ELPA)
      use constants, only : dp, dpc
#endif
   use file_units, only : f_parsec
   implicit none
#if defined(WITH_SCALAPACK) || defined(WITH_ELPA)
   interface gather_matrix
      module procedure dgather_matrix, zgather_matrix
   end interface gather_matrix

   interface section_matrix
      module procedure dsection_matrix, zsection_matrix
   end interface section_matrix

   !< Real valued 2d distributed matrix (block cyclic e.g. BLACS)
   type ddistMatrix
      integer :: mpi_comm !< mpi_communicator used while forming this matrix
      integer :: my_id !< my id in the communicator
      integer :: nprocs !< my nprocs
      integer :: mpi_rows_comm !< mpi_communicator for talking to rows of this matrix 
      integer :: mpi_cols_comm !< mpi_communicator used while forming this matrix
      integer :: my_blacs_ctxt !< blacs context for this matrix
      integer :: np_rows !< count of processor grid rows \note nprow is
      !! sometimes its queried form
      integer :: np_cols !< count of processor grid cols \note npcol is sometimes
      !! its queried form
      integer :: my_prow !< processor row
      integer :: my_pcol !< processor col
      integer :: nrows !< global number of rows
      integer :: ncols !< global number of cols
      integer :: nlrows !< local number of rows
      integer :: nlcols !< local number of cols
      real(dp), allocatable :: ldata(:,:)
      contains
         procedure :: init => init_distMatrix_d
         procedure :: alloc => alloc_distMatrix_d
         procedure :: destroy => destroy_distMatrix_d
         !procedure :: makeFromMirrored =>
   end type ddistMatrix
#endif
contains
   !> @brief returns the local block index of a global index
   !> without checking if it belongs to you
   function Bg2l(i, np, nb)
      integer, intent(in) :: i  !< global index
      integer, intent(in) :: np !< number of processors
      integer, intent(in) :: nb !< block size
      integer :: il
      integer :: p
      integer :: Bg2l
      call g2l(i,1,np,nb,p,il)
      Bg2l = p
   end function Bg2l
! accessed on nersc.gov
   subroutine g2l(i,n,np,nb,p,il)
      implicit none
      integer :: i    ! global array index, input
      integer :: n    ! global array dimension, input
      integer :: np   ! processor array dimension, input
      integer :: nb   ! block size, input
      integer :: p    ! processor array index, output
      integer :: il   ! local array index, output
      integer :: im1
      im1 = i-1
      p   = mod((im1/nb),np)
      il  = (im1/(np*nb))*nb + mod(im1,nb) + 1
      return
   end
! convert local index to global index in block-cyclic distribution
! accessed on nersc.gov
   subroutine l2g(il,p,n,np,nb,i)
      implicit none
      integer :: il   ! local array index, input
      integer :: p    ! processor array index, input
      integer :: n    ! global array dimension, input
      integer :: np   ! processor array dimension, input
      integer :: nb   ! block size, input
      integer :: i    ! global array index, output
      integer :: ilm1
      ilm1 = il-1
      i    = (((ilm1/nb) * np) + p)*nb + mod(ilm1,nb) + 1
      return
   end
subroutine dextract_symmdist_simple(nwant, nblk, &
   my_prow, my_pcol, np_rows, np_cols,&
   myid, projl, na_rows, na_cols, tile,&
   ldtile, tile_extents, tile_cols, tile_rows, i_global_0, j_global_0,&
   op_comm, verbose)
   use constants, only : dp
   use file_units, only : f_parsec
   use iso_fortran_env, only : stderr => error_unit
#ifdef WITH_MPI_F08
   use :: mpi_f08
#else
   use :: mpi
#endif
   implicit none
   !=============Input===============================
   integer, intent(in) ::  &
      nwant,&
      nblk
   integer, intent(inout) :: my_prow, my_pcol, np_cols, np_rows, myid, &
      na_cols, na_rows
   integer, intent(in) :: ldtile, tile_cols, tile_rows
   integer, intent(in) :: i_global_0, j_global_0 ! establishes a viewport into the tile
   integer, intent(in) :: tile_extents(4) !< tile i0:if,j0:jf range
   real(dp), intent(in) :: tile(ldtile, tile_cols)
   real(dp), intent(inout) :: projl(na_rows,na_cols)
   MPI_COMM_T, intent(in), optional :: op_comm
   integer, intent(in), optional ::  &
      verbose    !< integer controlling how many messages to print out
   !=============Input/Output========================
   !=============Output==============================
   !============ Work variables======================
   integer :: j_global !< 1-based index for global array represents the coordinate of the global block
   integer :: i_global !< 1-based index for global array
   integer :: &
      procrow,& !< processsor-row currently being reduced
      proccol   !< processsor-col currently being reduced
   intrinsic :: modulo
   character(40) :: filename !< character buffer for formatted writes
   ! name aliases
   integer :: ti, tj  !< indices for tile_i, tile_j
   integer :: li, lj  !< indices for localproj_i,localproj_j
   real(dp) :: tmp
   !=======================================================================
   !> @brief
   !! take a subsection of tile as a window into a global matrix that 
   !! may not exist
   !!
   !> @detail e.g.:
   !! for tile[1:ldtile,1:tile_cols] st
   !!    1 <= tile_extent_i0 <= tile_extent_if <= ldtile
   !!    1 <= tile_extent_j0 <= tile_extent_jf <= tile_cols
   !!
   !! tile[tile_extent_i0:tile_offset_if, tile_extent_j0:tile_extent_jf] =>
   !!            global[global_i0:global_if, global_j0:global_jf]
   !!
   !!======================================================================
   if(.not. 1 <= tile_extents(1)) write(stderr,*) 'Failure to lbound (1)'
   if(.not. tile_extents(1) <= tile_extents(2)) write(stderr,*) 'Failure to lbound (2)'
   if(.not. tile_extents(2) <= ldtile) write(stderr,*) 'Failure to ubound (2)'
   if(.not. 1 <= tile_extents(3)) write(stderr,*) 'Failure to lbound (3)'
   if(.not. tile_extents(3) <= tile_extents(4)) write(stderr,*) 'Failure to lbound (4)'
   if(.not. tile_extents(4) <= tile_cols) write(stderr,*) 'Failure to ubound (4)'

   if (verbose >= 3) then
      write(9,'("#EBUG:",12A8)') 'nwant','prow','pcol','shape ','h_proj','tile_extents','tile_extents','tile_extents','tile_extents','tile','gi_0','gj_0'
      write(9,'("#EBUG:",12I8)') nwant, my_prow, my_pcol, na_rows, na_cols,&
         tile_extents, tile_cols, &
         i_global_0, j_global_0
   endif

   if (verbose >= 3) write(9,'("#   ",10A6)') &
      'Bgi','Bgj','Bli','Blj','h_gi','h_gj',&
      'ti','tj','li','lj'
   if (verbose >= 3 .and. myid>=0) write(9,'(9(A6,1X))') 'i_global','j_global','procrow','proccol',' ti',' tj',' li',' lj','tile'
   !$OMP  PARALLEL DO FIRSTPRIVATE(j_global_0, tile_extents,my_prow,my_pcol,&
   !$OMP& myid, nblk, np_rows, np_cols, i_global_0, nwant, verbose) &
   !$OMP& PRIVATE(procrow, proccol, i_global, j_global, lj, li, ti, tj) &
   !$OMP& SHARED(projl, tile) DEFAULT(NONE)
   jgloop: do j_global = j_global_0,j_global_0+tile_extents(4)-tile_extents(3)
      tj = (j_global-j_global_0)+tile_extents(3)
#if 1
      ! Lower half - what needs data
      call g2l(j_global,nwant,np_cols,nblk,proccol,lj)
      if (my_pcol == proccol) then
         igloop_col: do i_global = j_global,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_rows,nblk,procrow,li)
            if (my_prow == procrow) then
#ifdef LOCAL_DEBUG
               if (verbose>=3 .and. myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj)
               if (verbose>=3 .and. myid>=0) flush(9)
#endif
               projl(li,lj) = tile(ti,tj)
               !if (myid>-1) write(9,'(8(I4.4,3X),3(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj), tmp, projl(li,lj)
            endif
         end do igloop_col
      endif
#endif
#if 1
      ! Symmetry based on lower half data
      call g2l(j_global,nwant,np_rows,nblk,procrow,li)
      if (my_prow == procrow) then
         igloop_row: do i_global = j_global+1,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_cols,nblk,proccol,lj)
            if (my_pcol == proccol) then
#ifdef LOCAL_DEBUG
               if (verbose>=3 .and. myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,proccol,procrow, ti, tj, li, lj, tile(ti,tj)
               if (verbose>=3 .and. myid>=0) flush(9)
#endif
               projl(li,lj) = tile(ti,tj)
            endif
         enddo igloop_row
      endif
#endif
   end do jgloop
   !$OMP END PARALLEL DO
end subroutine dextract_symmdist_simple
#if defined(WITH_SCALAPACK) || defined(WITH_ELPA)
subroutine dextract_gendist_simple(nwant, nblk, &
   my_prow, my_pcol, np_rows, np_cols,&
   myid, projl, na_rows, na_cols, tile,&
   ldtile, tile_extents, tile_cols, tile_rows, i_global_0, j_global_0,&
   op_comm, verbose)
   use constants, only : dp
   use file_units, only : f_parsec
   use iso_fortran_env, only : stderr => error_unit
#ifdef WITH_MPI_F08
   use :: mpi_f08
#else
   use :: mpi
#endif
   implicit none
   !=============Input===============================
   integer, intent(in) ::  &
      nwant,&
      nblk
   integer, intent(inout) :: my_prow, my_pcol, np_cols, np_rows, myid, &
      na_cols, na_rows
   integer, intent(in) :: ldtile, tile_cols, tile_rows
   integer, intent(in) :: i_global_0, j_global_0 ! establishes a viewport into the tile
   integer, intent(in) :: tile_extents(4) !< tile i0:if,j0:jf range
   real(dp), intent(in) :: tile(ldtile, tile_cols)
   real(dp), intent(inout) :: projl(na_rows,na_cols)
   MPI_COMM_T, intent(in), optional :: op_comm
   integer, intent(in), optional ::  &
      verbose    !< integer controlling how many messages to print out
   !=============Input/Output========================
   !=============Output==============================
   !============ Work variables======================
   integer :: j_global !< 1-based index for global array represents the coordinate of the global block
   integer :: i_global !< 1-based index for global array
   integer :: &
      procrow,& !< processsor-row currently being reduced
      proccol   !< processsor-col currently being reduced
   intrinsic :: modulo
   character(40) :: filename !< character buffer for formatted writes
   ! name aliases
   integer :: ti, tj  !< indices for tile_i, tile_j
   integer :: li, lj  !< indices for localproj_i,localproj_j
   real(dp) :: tmp
   !=======================================================================
   !> @brief
   !! take a subsection of tile as a window into a global matrix that 
   !! may not exist
   !!
   !> @detail e.g.:
   !! for tile[1:ldtile,1:tile_cols] st
   !!    1 <= tile_extent_i0 <= tile_extent_if <= ldtile
   !!    1 <= tile_extent_j0 <= tile_extent_jf <= tile_cols
   !!
   !! tile[tile_extent_i0:tile_offset_if, tile_extent_j0:tile_extent_jf] =>
   !!            global[global_i0:global_if, global_j0:global_jf]
   !!
   !!======================================================================
   if(.not. 1 <= tile_extents(1)) write(stderr,*) 'Failure to lbound (1)'
   if(.not. tile_extents(1) <= tile_extents(2)) write(stderr,*) 'Failure to lbound (2)'
   if(.not. tile_extents(2) <= ldtile) write(stderr,*) 'Failure to ubound (2)'
   if(.not. 1 <= tile_extents(3)) write(stderr,*) 'Failure to lbound (3)'
   if(.not. tile_extents(3) <= tile_extents(4)) write(stderr,*) 'Failure to lbound (4)'
   if(.not. tile_extents(4) <= tile_cols) write(stderr,*) 'Failure to ubound (4)'

   !if (verbose >= 3) then
   if (verbose >= 3 .and. myid==1) then
      write(4,'("#EBUG:",9A8)') 'nwant','prow','pcol','shape ','h_proj','tileM','tileN','gi_0','gj_0'
      write(4,'("#EBUG:",12I8)') nwant, my_prow, my_pcol, na_rows, na_cols,&
         tile_extents, tile_cols, &
         i_global_0, j_global_0
   endif

   if (verbose >= 3) write(9,'("#   ",10A6)') &
      'Bgi','Bgj','Bli','Blj','h_gi','h_gj',&
      'ti','tj','li','lj'
   if (verbose >= 3 .and. myid==1) write(4,'(8(A6,1X))') 'i_global','j_global','procrow','proccol',' ti',' tj',' li',' lj'
   jgloop: do j_global = j_global_0,j_global_0+tile_extents(4)-tile_extents(3)
      tj = (j_global-j_global_0)+tile_extents(3)
      igloop_col: do i_global = i_global_0,i_global_0+tile_extents(2)-tile_extents(1)
         ti = (i_global-i_global_0)+tile_extents(1)
         call g2l(j_global,nwant,np_cols,nblk,proccol,lj)
         call g2l(i_global,nwant,np_rows,nblk,procrow,li)
         tmp = projl(li,lj)
         if (my_pcol == proccol) then
            if (my_prow == procrow) then
               !if(projl(li,lj) /= 0.d0) call MPI_Abort(MPI_COMM_WORLD,-1)
               projl(li,lj) = tile(ti,tj)
               !if (verbose >= 2) write(9,'("   ",10I6)')&
               !   Bg2l(i_global,np_rows,nblk), Bg2l(j_global,np_cols,nblk),&
               !   (li-1)/nblk,(lj-1)/nblk,i_global,j_global,&
               !   ti,tj, li,lj
            endif
         endif
         if (myid==1) write(4,'(8(I4.4,3X),3(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj), tmp, projl(li,lj)
      end do igloop_col
#if 0
      if (my_prow == modulo((j_global-1) / nblk, np_rows)) then
         igloop_row: do ti = 1, tile_rows
            i_global = i_global_0 - 1 + ti
            if(i_global > nwant) exit igloop_row
            if(j_global >= i_global) cycle igloop_row
            procrow = modulo((i_global-1) / nblk, np_cols)
            if (my_pcol == procrow) then
               lj = g2l(j_global, np_rows, nblk)
               li = g2l(i_global, np_cols, nblk)
               if (verbose >= 2) write(9,'("-2 ",14I6)') -1,&
                  Bg2l(j_global,np_rows,nblk), Bg2l(i_global,np_cols,nblk),-1,&
                  Bg2l(lj,1,nblk),Bg2l(li,1,nblk),i_global,-1,&
                  j_global, -1,lj,-1,li,-1
               projl(lj,li) = tile(ti,tj)
            endif
         end do igloop_row
      endif
#endif
   end do jgloop
end subroutine dextract_gendist_simple
subroutine zextract_symmdist_simple(nwant, nblk, &
   my_prow, my_pcol, np_rows, np_cols,&
   myid, projl, na_rows, na_cols, tile,&
   ldtile, tile_extents, tile_cols, tile_rows, i_global_0, j_global_0,&
   op_comm, verbose)
   use constants, only : dp
   use file_units, only : f_parsec
   use iso_fortran_env, only : stderr => error_unit
#ifdef WITH_MPI_F08
   use :: mpi_f08
#else
   use :: mpi
#endif
   implicit none
   !=============Input===============================
   integer, intent(in) ::  &
      nwant,&
      nblk
   integer, intent(inout) :: my_prow, my_pcol, np_cols, np_rows, myid, &
      na_cols, na_rows
   integer, intent(in) :: ldtile, tile_cols, tile_rows
   integer, intent(in) :: i_global_0, j_global_0 ! establishes a viewport into the tile
   integer, intent(in) :: tile_extents(4) !< tile i0:if,j0:jf range
   complex(dp), intent(in) :: tile(ldtile, tile_cols)
   complex(dp), intent(inout) :: projl(na_rows,na_cols)
   MPI_COMM_T, intent(in), optional :: op_comm
   integer, intent(in), optional ::  &
      verbose    !< integer controlling how many messages to print out
   !=============Input/Output========================
   !=============Output==============================
   !============ Work variables======================
   integer :: j_global !< 1-based index for global array represents the coordinate of the global block
   integer :: i_global !< 1-based index for global array
   integer :: &
      procrow,& !< processsor-row currently being reduced
      proccol   !< processsor-col currently being reduced
   intrinsic :: modulo
   character(40) :: filename !< character buffer for formatted writes
   ! name aliases
   integer :: ti, tj  !< indices for tile_i, tile_j
   integer :: li, lj  !< indices for localproj_i,localproj_j
   complex(dp) :: tmp
   !=======================================================================
   !> @brief
   !! take a subsection of tile as a window into a global matrix that 
   !! may not exist
   !!
   !> @detail e.g.:
   !! for tile[1:ldtile,1:tile_cols] st
   !!    1 <= tile_extent_i0 <= tile_extent_if <= ldtile
   !!    1 <= tile_extent_j0 <= tile_extent_jf <= tile_cols
   !!
   !! tile[tile_extent_i0:tile_offset_if, tile_extent_j0:tile_extent_jf] =>
   !!            global[global_i0:global_if, global_j0:global_jf]
   !!
   !!======================================================================
   if(.not. 1 <= tile_extents(1)) write(stderr,*) 'Failure to lbound (1)'
   if(.not. tile_extents(1) <= tile_extents(2)) write(stderr,*) 'Failure to lbound (2)'
   if(.not. tile_extents(2) <= ldtile) write(stderr,*) 'Failure to ubound (2)'
   if(.not. 1 <= tile_extents(3)) write(stderr,*) 'Failure to lbound (3)'
   if(.not. tile_extents(3) <= tile_extents(4)) write(stderr,*) 'Failure to lbound (4)'
   if(.not. tile_extents(4) <= tile_cols) write(stderr,*) 'Failure to ubound (4)'

   if (verbose >= 3) then
      write(9,'("#EBUG:",12A8)') 'nwant','prow','pcol','shape ','h_proj','tile_extents','tile_extents','tile_extents','tile_extents','tile','gi_0','gj_0'
      write(9,'("#EBUG:",12I8)') nwant, my_prow, my_pcol, na_rows, na_cols,&
         tile_extents, tile_cols, &
         i_global_0, j_global_0
   endif

   if (verbose >= 3) write(9,'("#   ",10A6)') &
      'Bgi','Bgj','Bli','Blj','h_gi','h_gj',&
      'ti','tj','li','lj'
   if (verbose >= 3 .and. myid>=0) write(9,'(9(A6,1X))') 'i_global','j_global','procrow','proccol',' ti',' tj',' li',' lj','tile'
   jgloop: do j_global = j_global_0,j_global_0+tile_extents(4)-tile_extents(3)
      tj = (j_global-j_global_0)+tile_extents(3)
#if 1
      ! Lower half - what needs data
      call g2l(j_global,nwant,np_cols,nblk,proccol,lj)
      if (my_pcol == proccol) then
         igloop_col: do i_global = j_global,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_rows,nblk,procrow,li)
            if (my_prow == procrow) then
               if (myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj)
               flush(9)
               projl(li,lj) = tile(ti,tj)
               !if (myid>-1) write(9,'(8(I4.4,3X),3(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj), tmp, projl(li,lj)
            endif
         end do igloop_col
      endif
#endif
#if 1
      ! Symmetry based on lower half data
      call g2l(j_global,nwant,np_rows,nblk,procrow,li)
      if (my_prow == procrow) then
         igloop_row: do i_global = j_global+1,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_cols,nblk,proccol,lj)
            if (my_pcol == proccol) then
               if (myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,proccol,procrow, ti, tj, li, lj, tile(ti,tj)
               flush(9)
               projl(li,lj) = conjg(tile(ti,tj))
            endif
         enddo igloop_row
      endif
#endif
   end do jgloop
end subroutine zextract_symmdist_simple
subroutine dextract_symmdist_block(nwant, nblk, &
   my_prow, my_pcol, np_rows, np_cols,&
   myid, projl, na_rows, na_cols, tile,&
   ldtile, tile_extents, tile_cols, tile_rows, i_global_0, j_global_0,&
   op_comm, verbose)
   use constants, only : dp
   use file_units, only : f_parsec
   use iso_fortran_env, only : stderr => error_unit
#ifdef WITH_MPI_F08
   use :: mpi_f08
#else
   use :: mpi
#endif
   implicit none
   !=============Input===============================
   integer, intent(in) ::  &
      nwant,&
      nblk
   integer, intent(inout) :: my_prow, my_pcol, np_cols, np_rows, myid, &
      na_cols, na_rows
   integer, intent(in) :: ldtile, tile_cols, tile_rows
   integer, intent(in) :: i_global_0, j_global_0 ! establishes a viewport into the tile
   integer, intent(in) :: tile_extents(4) !< tile i0:if,j0:jf range
   real(dp), intent(in) :: tile(ldtile, tile_cols)
   real(dp), intent(inout) :: projl(na_rows,na_cols)
   MPI_COMM_T, intent(in), optional :: op_comm
   integer, intent(in), optional ::  &
      verbose    !< integer controlling how many messages to print out
   !=============Input/Output========================
   !=============Output==============================
   !============ Work variables======================
   integer :: j_global !< 1-based index for global array represents the coordinate of the global block
   integer :: i_global !< 1-based index for global array
   integer :: &
      procrow,& !< processsor-row currently being reduced
      proccol   !< processsor-col currently being reduced
   intrinsic :: modulo
   character(40) :: filename !< character buffer for formatted writes
   ! name aliases
   integer :: ti, tj  !< indices for tile_i, tile_j
   integer :: li, lj  !< indices for localproj_i,localproj_j
   real(dp) :: tmp
   !=======================================================================
   !> @brief
   !! take a subsection of tile as a window into a global matrix that 
   !! may not exist
   !!
   !> @detail e.g.:
   !! for tile[1:ldtile,1:tile_cols] st
   !!    1 <= tile_extent_i0 <= tile_extent_if <= ldtile
   !!    1 <= tile_extent_j0 <= tile_extent_jf <= tile_cols
   !!
   !! tile[tile_extent_i0:tile_offset_if, tile_extent_j0:tile_extent_jf] =>
   !!            global[global_i0:global_if, global_j0:global_jf]
   !!
   !!======================================================================
   if(.not. 1 <= tile_extents(1)) write(stderr,*) 'Failure to lbound (1)'
   if(.not. tile_extents(1) <= tile_extents(2)) write(stderr,*) 'Failure to lbound (2)'
   if(.not. tile_extents(2) <= ldtile) write(stderr,*) 'Failure to ubound (2)'
   if(.not. 1 <= tile_extents(3)) write(stderr,*) 'Failure to lbound (3)'
   if(.not. tile_extents(3) <= tile_extents(4)) write(stderr,*) 'Failure to lbound (4)'
   if(.not. tile_extents(4) <= tile_cols) write(stderr,*) 'Failure to ubound (4)'

   if (verbose >= 3) then
      write(9,'("#EBUG:",12A8)') 'nwant','prow','pcol','shape ','h_proj','tile_extents','tile_extents','tile_extents','tile_extents','tile','gi_0','gj_0'
      write(9,'("#EBUG:",12I8)') nwant, my_prow, my_pcol, na_rows, na_cols,&
         tile_extents, tile_cols, &
         i_global_0, j_global_0
   endif

   if (verbose >= 3) write(9,'("#   ",10A6)') &
      'Bgi','Bgj','Bli','Blj','h_gi','h_gj',&
      'ti','tj','li','lj'
   if (verbose >= 3 .and. myid>=0) write(9,'(9(A6,1X))') 'i_global','j_global','procrow','proccol',' ti',' tj',' li',' lj','tile'
   !$OMP  PARALLEL DO FIRSTPRIVATE(j_global_0, tile_extents,my_prow,my_pcol,&
   !$OMP& myid, nblk, np_rows, np_cols, i_global_0, nwant, verbose) &
   !$OMP& PRIVATE(procrow, proccol, i_global, j_global, lj, li, ti, tj) &
   !$OMP& SHARED(projl, tile) DEFAULT(NONE)
   jgloop: do j_global = j_global_0,j_global_0+tile_extents(4)-tile_extents(3)
      tj = (j_global-j_global_0)+tile_extents(3)
#if 1
      ! Lower half - what needs data
      call g2l(j_global,nwant,np_cols,nblk,proccol,lj)
      if (my_pcol == proccol) then
         igloop_col: do i_global = j_global,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_rows,nblk,procrow,li)
            if (my_prow == procrow) then
#ifdef LOCAL_DEBUG
               if (verbose>=3 .and. myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj)
               if (verbose>=3 .and. myid>=0) flush(9)
#endif
               projl(li,lj) = tile(ti,tj)
               !if (myid>-1) write(9,'(8(I4.4,3X),3(E11.4,1X))') i_global,j_global,procrow,proccol, ti, tj, li, lj, tile(ti,tj), tmp, projl(li,lj)
            endif
         end do igloop_col
      endif
#endif
#if 1
      ! Symmetry based on lower half data
      call g2l(j_global,nwant,np_rows,nblk,procrow,li)
      if (my_prow == procrow) then
         igloop_row: do i_global = j_global+1,i_global_0+tile_extents(2)-tile_extents(1)
            ti = (i_global-i_global_0)+tile_extents(1)
            call g2l(i_global,nwant,np_cols,nblk,proccol,lj)
            if (my_pcol == proccol) then
#ifdef LOCAL_DEBUG
               if (verbose>=3 .and. myid>=0) write(9,'(8(I4.4,3X),1(E11.4,1X))') i_global,j_global,proccol,procrow, ti, tj, li, lj, tile(ti,tj)
               if (verbose>=3 .and. myid>=0) flush(9)
#endif
               projl(li,lj) = tile(ti,tj)
            endif
         enddo igloop_row
      endif
#endif
   end do jgloop
   !$OMP END PARALLEL DO
end subroutine dextract_symmdist_block

 !< raw initialize with optional mpi_comm
subroutine init_distMatrix_d( matrix, mpi_comm)
   use file_units, only : f_parsec
   implicit none
   class(ddistMatrix), intent(inout) :: matrix
   integer, optional :: mpi_comm

   if(present(mpi_comm)) then
      matrix%mpi_comm = mpi_comm
   else
      matrix%mpi_comm = 0 ! mpi_communicator used while forming this matrix
   endif

   matrix%my_id = 0 ! mpi_communicator used while forming this matrix
   matrix%mpi_rows_comm = 0 ! mpi_communicator for talking to rows of this matrix
   matrix%mpi_cols_comm = 0 ! mpi_communicator used while forming this matrix
   matrix%my_blacs_ctxt = 0 ! blacs context for this matrix
   matrix%np_rows = 0 ! count of processor grid rows \note nprow is
   !! sometimes its queried form
   matrix%np_cols = 0 ! count of processor grid cols \note npcol is sometimes
   !! its queried form
   matrix%my_prow = 0 ! this processor row
   matrix%my_pcol = 0 ! this processor col
   matrix%my_id = 0 ! this processor id
   matrix%nrows = 0 ! global number of rows
   matrix%ncols = 0 ! global number of cols
   matrix%nlrows = 0 ! local number of rows
   matrix%nlcols = 0 ! local number of cols
end subroutine init_distMatrix_d

 !< destroys the allocated matrix
subroutine destroy_distMatrix_d( matrix)
   use file_units, only : f_parsec
   implicit none
   class(ddistMatrix), intent(inout) :: matrix
   if (allocated(matrix%ldata)) deallocate(matrix%ldata)
end subroutine destroy_distMatrix_d

 !< allocates the matrix to some size n, m
subroutine alloc_distMatrix_d( matrix, n, m)
   use file_units, only : f_parsec
   implicit none
   class(ddistMatrix), intent(inout) :: matrix
   integer, intent(in) :: n, m
   allocate(matrix%ldata(n,m))
end subroutine alloc_distMatrix_d

#if defined(WITH_SCALAPACK)
subroutine dgather_matrix(na, a, lda, na_cols, nblk, my_prow, &
   my_pcol, np_rows, np_cols, op_comm, ctxt, a_global, lda_global)
   use mpi
   use external_interfaces, only : dgsum2d
   use file_units, only : f_parsec
   implicit none

   integer, intent(in) :: &
      na,& !< rank of global matrix a_global
      lda,& !< leading dimension of our distributed piece
      na_cols,& !< number of columns of our distributed piece
      nblk,& !< blocksize for 2D block cyclic grid
      my_prow,& !< my processor row
      my_pcol,& !< my processor column
      np_rows,& !< number of processor rows
      np_cols,& !< number of process columns
      op_comm,& !< MPI communicator for process
      ctxt !< blacs context for process
   integer, intent(in) :: lda_global !< leading dimension of a_global
   real(dp), intent(in) :: a(lda, na_cols) !< our distributed piece
   real(dp), intent(out) :: a_global(lda_global, na) !< the full matrix to build

   integer i, j, lr, lc, myid, mpierr
   integer steps, starti, endi
   integer, allocatable :: l_row(:), l_col(:)
   character(len=21) :: filename
   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   call mpi_comm_rank(op_comm,myid,mpierr)

   do i = 1, na
      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
      endif

   enddo

   a_global = 0

   do i=1,na
      if(l_col(i) > 0) then
         do j=1,i
            if(l_row(j)>0) a_global(j,i) = a(l_row(j),l_col(i))
         enddo
      endif
      if(l_row(i) > 0) then
         do j=1,i-1
            if(l_col(j)>0) a_global(i,j) = a(l_row(i),l_col(j))
         enddo
      endif
   enddo
#if defined(PRINT_GATHER_DEBUG)
#if defined(DEBUG_RITZ_CLASSIC)
   write(filename,"(A6,I3.3,A6)") "gather",myid,"_1.txt"
#else
   write(filename,"(A6,I3.3,A6)") "gather",myid,"_2.txt"
#endif
   open(12,file=trim(filename),status="unknown", form='unformatted')
   write(12) 2
   write(12) shape(a_global)
   write(12) a_global
   close(12)
#endif

   if (na < 5000) then
      ! global reduction that stitches together the a_global
      ! Doesn't work for large enough matrices (na >> 15k on edison) because of
      ! limitations on BLACS buffer space
      call dgsum2d(ctxt,'A',' ',na,na,a_global,na,-1,-1)
   else
      steps = 8
      do i=1,steps
         starti = (i-1)*(na/steps)+1
         endi = i*(na/steps)
         call dgsum2d(ctxt,'A',' ',na,endi-starti+1,a_global(:,starti:endi),na,-1,-1)
      enddo
      if (.not. (endi == na)) then
         starti=endi+1
         endi=na
         call dgsum2d(ctxt,'A',' ',na,endi-starti+1,a_global(:,starti:endi),na,-1,-1)
      endif
   endif

#if defined(PRINT_GATHER_DEBUG)
#if defined(DEBUG_RITZ_CLASSIC)
   write(filename,"(A6,I3.3,A6)") "collec",myid,"_1.txt"
#else
   write(filename,"(A6,I3.3,A6)") "collec",myid,"_2.txt"
#endif
   open(12,file=trim(filename),status="unknown", form='unformatted')
   write(12) 2
   write(12) shape(a_global)
   write(12) a_global
   close(12)
#endif

   deallocate(l_row, l_col)
end subroutine dgather_matrix
subroutine zgather_matrix(na, a, lda, na_cols, nblk, my_prow, my_pcol,&
   np_rows, np_cols, op_comm, ctxt, a_global, lda_global)
   use mpi
   use external_interfaces, only : zgsum2d
   use file_units, only : f_parsec
   implicit none

   integer, intent(in) :: &
      na,& !< rank of global matrix a_global
      lda,& !< leading dimension of our distributed piece
      na_cols,& !< number of columns of our distributed piece
      nblk,& !< blocksize for 2D block cyclic grid
      my_prow,& !< my processor row
      my_pcol,& !< my processor column
      np_rows,& !< number of processor rows
      np_cols,& !< number of process columns
      op_comm,& !< MPI communicator for process
      ctxt !< blacs context for process
   integer, intent(in) :: lda_global !< leading dimension of a_global
   complex(dpc), intent(in) :: a(lda, na_cols) !< our distributed piece
   complex(dpc), intent(out) :: a_global(lda_global, na) !< the full matrix to build

   integer i, j, lr, lc, myid, mpierr
   integer steps, starti, endi
   integer, allocatable :: l_row(:), l_col(:)
#if defined(PRINT_GATHER_DEBUG)
   character*16 :: filename
#endif
   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   call mpi_comm_rank(op_comm,myid,mpierr)
   do i = 1, na

      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
#if defined(PRINT_GATHER_DEBUG2)
         write(*,*) myid,' has row ',i,' on ',lr
#endif
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
#if defined(PRINT_GATHER_DEBUG2)
         write(*,*) myid,' has col ',i,' on ',lc
#endif
      endif

   enddo

   a_global = 0

   do i=1,na
      if(l_col(i) > 0) then
         do j=1,i
            if(l_row(j)>0) a_global(j,i) = a(l_row(j),l_col(i))
         enddo
      endif
      if(l_row(i) > 0) then
         do j=1,i-1
            if(l_col(j)>0) a_global(i,j) = a(l_row(i),l_col(j))
         enddo
      endif
   enddo

#if defined(PRINT_GATHER_DEBUG)
   write(filename,"(A6,I3.3,A4)") "gather",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,"(34E26.13E2)") (a_global(i,:),i=1,34)
   close(12)
#endif

   if (na < 5000) then
      ! global reduction that stitches together the a_global
      ! Doesn't work for large enough matrices (na >> 15k on edison) because of
      ! limitations on BLACS buffer space
      call zgsum2d(ctxt,'A',' ',na,na,a_global,na,-1,-1)
   else
      steps = 8
      do i=1,steps
         starti = (i-1)*(na/steps)+1
         endi = i*(na/steps)
         call zgsum2d(ctxt,'A',' ',na,endi-starti+1,a_global(:,starti:endi),na,-1,-1)
      enddo
      if (.not. (endi == na)) then
         starti=endi+1
         endi=na
         call zgsum2d(ctxt,'A',' ',na,endi-starti+1,a_global(:,starti:endi),na,-1,-1)
      endif
   endif

#if defined(PRINT_GATHER_DEBUG)
   write(filename,"(A6,I3.3,A4)") "collect",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,"(34E26.13E2)") (a_global(i,:),i=1,PRINT_GATHER_DEBUG_N)
   close(12)
#endif

   deallocate(l_row, l_col)

end subroutine zgather_matrix

!>---------------------------------------------------------------------------------
!! \brief Takes a local "full" non distributed matrix and distributes it block
!! cyclically
!!
!! \details Takes a local matrix a_global and distributes it amongst processors in the
!! op_comm.
!!
!!
subroutine dsection_matrix(na, a, lda, ldim, nblk, my_prow, my_pcol, np_rows, np_cols, op_comm, a_global, uplo)
   use mpi
   use file_units, only : f_parsec
   implicit none
   integer, intent(in) :: na  !<  columns of a_global
   integer, intent(in) :: lda !<  leading dimension of local matrix A
   integer, intent(in) :: ldim !<  columns of local matrix A
   integer, intent(in) :: nblk !<  number of blocked entries per separation
   integer, intent(in) :: my_prow !<  my row coordinate on process grid
   integer, intent(in) :: my_pcol !<  my column coordinate on process grid
   integer, intent(in) :: np_rows !<  number of processor rows on process grid
   integer, intent(in) :: op_comm !<  communicator for operation
   integer, intent(in) :: np_cols !<  number of processor columns on process grid

   real(dp), intent(out) :: a(lda, ldim) !< local matrix A
   real(dp), intent(in) :: a_global(na,na) !< global matrix A
   !< \todo uplo doesn't do anything
   character(len=1), intent(in) :: uplo !< upper/lower formulation

   integer i, j, lr, lc, myid, mpierr
   integer, allocatable :: l_row(:), l_col(:)

   real(dp), allocatable :: col(:), row(:)

   character*17 :: filename
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   character*10 :: symbol
#endif

   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   do i = 1, na

      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
      endif

   enddo
   call mpi_comm_rank(op_comm,myid,mpierr)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "loc_dat",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,*) '==== l_col'
   write(12,*) na, (l_col(i),i=1,na)
   write(12,*) '==== l_row'
   write(12,*) na, (l_row(i),i=1,na)
   close(12)
#endif
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "loc_ass",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,"(6(I3.3,1X))") lda, ldim, my_prow, my_pcol, np_rows, np_cols
   write(12,"(A)") "l_col   i j   a,l_row(j),l_col(i) col(j)         A  i  j"
101 format("A(",I3.3,",",I3.3,")")
102 format(A5,2X,I3.3,X,I3.3,2X,A1,I3.3,X,I3.3,X,A26,2X,A1,X,I3.3,X,I3.3)
103 format(A5,2X,I3.3,X,I3.3,2X,A1,I3.3,X,I3.3,X,E26.13,2X,A1,X,I3.3,X,I3.3)
#endif

   allocate(col(na))

   ! heavily modified from what I originally had for the SPDFT code
   ! (read - not well tested) - CML
   if( uplo == 'L' ) then
      do i=1,na
         col(1:i) = a_global(i,1:i)
         if(l_col(i) > 0) then
            do j=1,i
               if(l_row(j)>0) a(l_row(j),l_col(i)) = col(j)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
#ifdef BLOCK_CYCLIC_UTIL_DEBUG_SYMBOLS
               write(symbol,101) i,j
               if(l_row(j)>0) write(12,102) 'l_col',i,j,'a',l_row(j),l_col(i),symbol,'A',i,j
#else
               if(l_row(j)>0) write(12,103) 'l_col',i,j,'a',l_row(j),l_col(i),col(j),'A',i,j
#endif
#endif
            enddo
         endif
         if(l_row(i) > 0) then
            do j=1,i-1
               if(l_col(j)>0) a(l_row(i),l_col(j)) = col(j)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
#ifdef BLOCK_CYCLIC_UTIL_DEBUG_SYMBOLS
               write(symbol,101) i,j
               if (l_col(j)>0) write(12,102) 'l_row',i,j,'a',l_row(i),l_col(j),symbol,'A',i,j
#else
               if (l_col(j)>0) write(12,103) 'l_row',i,j,'a',l_row(i),l_col(j),col(j),'A',i,j
#endif
#endif
            enddo
         endif
      enddo
      ! not tested yet at all
   else if( uplo == 'U' )then
      ! not good to leave in code that was most likely just wrong
      call mpi_abort(op_comm,124,mpierr)
   else
      call mpi_abort(op_comm,123,mpierr)
   endif
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   close(12)
#endif

#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "section",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,*) na,na
   write(12,*) a_global(1,:)
   write(12,*) a_global(2,:)
   write(12,*) a_global(3,:)
   write(12,*) a_global(4,:)
   close(12)
   call mpi_barrier(op_comm,mpierr)
   call mpi_abort(op_comm,123,mpierr)
#endif

   deallocate(l_row, l_col, col)

end subroutine dsection_matrix
subroutine zsection_matrix(na, a, lda, ldim, nblk, my_prow, my_pcol, np_rows, np_cols, op_comm, a_global, uplo)
   use mpi
   use file_units, only : f_parsec
   implicit none

   integer, intent(in) :: na, lda, ldim, nblk, my_prow, my_pcol, np_rows, np_cols, op_comm
   complex(dpc), intent(out) :: a(lda, ldim)
   complex(dpc), intent(in) :: a_global(na,na)
   character(len=1), intent(in) :: uplo

   integer i, j, lr, lc, myid, mpierr
   integer, allocatable :: l_row(:), l_col(:)

   complex(dpc), allocatable :: col(:), row(:)

   character*17 :: filename
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   character*10 :: symbol
#endif

   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   do i = 1, na

      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
      endif

   enddo
   call mpi_comm_rank(op_comm,myid,mpierr)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "loc_dat",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,*) '==== l_col'
   write(12,*) na, (l_col(i),i=1,na)
   write(12,*) '==== l_row'
   write(12,*) na, (l_row(i),i=1,na)
   close(12)
#endif
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "loc_ass",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,"(6(I3.3,1X))") lda, ldim, my_prow, my_pcol, np_rows, np_cols
   write(12,"(A)") "l_col   i j   a,l_row(j),l_col(i) col(j)         A  i  j"
101 format("A(",I3.3,",",I3.3,")")
102 format(A5,2X,I3.3,X,I3.3,2X,A1,I3.3,X,I3.3,X,A26,2X,A1,X,I3.3,X,I3.3)
103 format(A5,2X,I3.3,X,I3.3,2X,A1,I3.3,X,I3.3,X,E26.13,2X,A1,X,I3.3,X,I3.3)
#endif

   allocate(col(na))

   ! heavily modified from what I originally had for the SPDFT code
   ! (read - not well tested) - CML
   if( uplo == 'L' ) then
      do i=1,na
         col(1:i) = a_global(i,1:i)
         if(l_col(i) > 0) then
            do j=1,i
               if(l_row(j)>0) a(l_row(j),l_col(i)) = col(j)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
#ifdef BLOCK_CYCLIC_UTIL_DEBUG_SYMBOLS
               write(symbol,101) i,j
               if(l_row(j)>0) write(12,102) 'l_col',i,j,'a',l_row(j),l_col(i),symbol,'A',i,j
#else
               if(l_row(j)>0) write(12,103) 'l_col',i,j,'a',l_row(j),l_col(i),col(j),'A',i,j
#endif
#endif
            enddo
         endif
         if(l_row(i) > 0) then
            do j=1,i-1
               if(l_col(j)>0) a(l_row(i),l_col(j)) = col(j)
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
#ifdef BLOCK_CYCLIC_UTIL_DEBUG_SYMBOLS
               write(symbol,101) i,j
               if (l_col(j)>0) write(12,102) 'l_row',i,j,'a',l_row(i),l_col(j),symbol,'A',i,j
#else
               if (l_col(j)>0) write(12,103) 'l_row',i,j,'a',l_row(i),l_col(j),col(j),'A',i,j
#endif
#endif
            enddo
         endif
      enddo
      ! not tested yet at all
   else if( uplo == 'U' )then
      ! not good to leave in code that was most likely just wrong
      call mpi_abort(op_comm,124,mpierr)
   else
      call mpi_abort(op_comm,123,mpierr)
   endif
#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   close(12)
#endif

#ifdef BLOCK_CYCLIC_UTIL_DEBUG
   write(filename,"(A7,I3.3,A4)") "section",myid,".txt"
   open(12,file=filename,status="unknown")
   write(12,*) na,na
   write(12,*) a_global(1,:)
   write(12,*) a_global(2,:)
   write(12,*) a_global(3,:)
   write(12,*) a_global(4,:)
   close(12)
   call mpi_barrier(op_comm,mpierr)
   call mpi_abort(op_comm,123,mpierr)
#endif

   deallocate(l_row, l_col, col)

end subroutine zsection_matrix
!----------------------------------------------------------------------------------
subroutine bcast_matrix(na, a, lda, nblk, my_prow, my_pcol, np_rows, np_cols, op_comm, a_global)
   use mpi
   use file_units, only : f_parsec
   implicit none

   integer, intent(in) :: na, lda, nblk, my_prow, my_pcol, np_rows, np_cols, op_comm
   real(dp), intent(out) :: a(lda, *)
   real(dp), intent(in) :: a_global(na,na)

   integer i, j, lr, lc, myid, mpierr
   integer, allocatable :: l_row(:), l_col(:)

   real(dp), allocatable :: col(:)
   character*16 :: filename

   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   do i = 1, na

      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
      endif

   enddo

   call mpi_comm_rank(op_comm,myid,mpierr)
   allocate(col(na))

   do i=1,na
      if(myid==0) col(1:i) = a_global(1:i,i)
      call mpi_bcast(col,i,MPI_DOUBLE_PRECISION,0,op_comm,mpierr)
      if(l_col(i) > 0) then
         do j=1,i
            if(l_row(j)>0) a(l_row(j),l_col(i)) = col(j)
         enddo
      endif
      if(l_row(i) > 0) then
         do j=1,i-1
            if(l_col(j)>0) a(l_row(i),l_col(j)) = col(j)
         enddo
      endif
   enddo
   deallocate(l_row, l_col, col)

end subroutine bcast_matrix

!-------------------------------------------------------------------------------
subroutine read_matrix(iunit, na, a, lda, nblk, my_prow, my_pcol, np_rows, np_cols)
   use mpi
   use file_units, only : f_parsec
   implicit none

   integer, intent(in) :: iunit, na, lda, nblk, my_prow, my_pcol, np_rows, np_cols
   real(dp), intent(out) :: a(lda, *)

   integer i, j, lr, lc, myid, mpierr
   integer, allocatable :: l_row(:), l_col(:)

   real(dp), allocatable :: col(:)

   ! allocate and set index arrays

   allocate(l_row(na))
   allocate(l_col(na))

   ! Mapping of global rows/cols to local

   l_row(:) = 0
   l_col(:) = 0

   lr = 0 ! local row counter
   lc = 0 ! local column counter

   do i = 1, na

      if( MOD((i-1)/nblk,np_rows) == my_prow) then
         ! row i is on local processor
         lr = lr+1
         l_row(i) = lr
      endif

      if( MOD((i-1)/nblk,np_cols) == my_pcol) then
         ! column i is on local processor
         lc = lc+1
         l_col(i) = lc
      endif

   enddo

   call mpi_comm_rank(mpi_comm_world,myid,mpierr)
   allocate(col(na))

   do i=1,na
      if(myid==0) read(iunit,*) col(1:i)
      call mpi_bcast(col,i,MPI_DOUBLE_PRECISION,0,MPI_COMM_WORLD,mpierr)
      if(l_col(i) > 0) then
         do j=1,i
            if(l_row(j)>0) a(l_row(j),l_col(i)) = col(j)
         enddo
      endif
      if(l_row(i) > 0) then
         do j=1,i-1
            if(l_col(j)>0) a(l_row(i),l_col(j)) = col(j)
         enddo
      endif
   enddo

   deallocate(l_row, l_col, col)

end subroutine read_matrix
#endif
#endif
end module blockcyclic_utility
