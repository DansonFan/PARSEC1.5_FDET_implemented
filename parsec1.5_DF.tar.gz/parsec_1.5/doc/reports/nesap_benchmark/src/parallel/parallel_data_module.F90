! ==================== parallel data structure ==================
module parallel_data_module !{{{
  use constants
  use aux, only : myflush
  implicit none

  type parallel_data

     ! total number of processors
     integer :: procs_num
     ! ID of master
     integer :: masterid
     ! true for master processor, false for all other ones
     logical :: iammaster
     ! rank of all the processors in the groups
     integer :: iam
     ! communicator for inter-processor communication
     integer :: comm

     ! handle of the world group (containing all processors)
     integer :: world_handle
     ! total number of groups
     integer :: groups_num
     ! number of processors per group ( group_size * groups_num = procs_num)
     integer :: group_size
     ! order of group to which each processor belongs to
     integer :: mygroup
     ! true for the master processors of this group (each group has one
     ! and only one master)
     logical :: iamgmaster
     ! rank of the master processor of this group
     integer :: group_master
     ! rank of processors within a group
     integer :: group_iam
     ! handle of a group
     integer :: group_handle
     ! communicator within a group
     integer :: group_comm
     ! optimized comm for matvec
     integer :: group_comm_topo
     ! optimized comm for the block folded matvec
     integer :: group_comm_c_topo
     ! mpi type for the fold (created)
     integer :: c_fold_type
     ! always real mpi type for the fold in charge density (created)
     integer :: c_fold_rho
     !
     ! plan of the groups: all processors belonging to j-th group
     ! have parallel%iam = parallel%gmap(parallel%group_iam,j)
     integer, dimension(:,:,:), pointer :: gmap => null()
     ! rank of processors in the group of masters
     integer :: gmaster_iam
     ! handle of the group of masters
     integer :: gmaster_handle
     ! communicator in the group of masters
     integer :: gmaster_comm

     ! actual size of hamiltonian
     integer ndim, nwedge,nwedge_c
     ! local size of hamiltonian (equal to number of grid points
     ! held by each processor)
     integer mydim
     integer mycdim
     integer myworkdim
     integer mycworkdim
     integer buffdim
     ! dimension of distributed grid arrays; in order to account
     ! for points outside the domain, choose ldn > max(numb)
     integer ldn
     ! alias for grid%lap_dir_num
     integer :: lap_dir_num

     ! work array for functions on the irreducible wedge,
     ! allocated by master PE only!
     real(dp), pointer :: ftmp(:) => null()
     complex(dpc), pointer :: zftmp(:) => null()

     ! Position of the first block of rows (=points in irreducible
     ! wedge) that each processor holds. The number of rows in
     ! processor ipe is irows(ipe+1)-irows(ipe). Global
     integer, dimension (:), pointer :: irows => null(), cirows => null()
     ! arrays for inter-processor communication
     ! they are all local (i.e., different values on different procs)
     ! see more about the meaning of these variables in comm_neigh.F
     ! integer, dimension(:), pointer :: ip1, jp1 
     integer, dimension(:), pointer :: irecvp => null(), jsendp => null()
     integer, dimension(:), pointer :: c_irecvp => null(), c_jsendp => null()
     integer, dimension (:), pointer :: senrows => null()
     integer, dimension (:), pointer :: c_senblocks => null()
     integer, dimension (:), pointer :: pint => null()
     integer :: inter1,inter2
     ! neighbor points to each point belonging to a computing PE;
     ! this index array indicates the position, in the 1-d array, 
     ! of the ith neighbor of point j (i from 1 to norder*3, because
     ! there are three directions, j from 1 to ndim). used for
     ! calculating derivatives; notice that neibs points to the
     ! index in irreducible wedge, not full grid!
     ! c_neibs is the same only for the folded grid
     integer, dimension (:,:), pointer :: neibs => null()
     integer, dimension (:,:), pointer :: c_neibs => null()
     ! index array indicating the symmetry operation needed to
     ! bring this neighor point back to the irreducible wedge
     ! NOTE: tneibs should be used whenever generic functions are
     ! evaluated at a neighbor point, with the exception of totally
     ! symmetric functions (like charge density, potentials etc.);
     ! that is because totally symmetric functions have character one
     ! (i.e., they do not gain phase factors upon a symmetry operation)
     ! c_tneibs is the same only for the folded grid
     integer, dimension (:,:), pointer :: tneibs => null()
     integer, dimension (:,:), pointer :: c_tneibs => null()
     ! local size for communication buffers (edges,size of send,size of receive)
     integer :: countcomm, maxcomm, maxcomm2
     ! local size for communication buffers for blocks:
     integer :: numedges, c_maxcomm, c_maxcomm2
     ! local information about communication:
     integer, allocatable, dimension (:) :: &
         sources,destinations,sendcounts,recvcounts,rdispls,sdispls
     ! for blocked communication using the conitg. data type: 
     integer, allocatable, dimension (:) :: &
         c_sources,c_destinations,c_sendcounts,c_recvcounts,c_rdispls,c_sdispls
     !info about laplacian buffers used for communication:
     integer :: max_lap_buffers
     ! additional spin dimension of wave-function due to spin-orbit
     ! and\or non-collinear states
     integer :: mxwd,nshift
     integer :: myrowgroup
     integer :: rowgroup_iam
     integer :: rowgroup_comm
     integer :: rowgroup_size
     integer :: taskgroup_iam
     integer :: colgroup_iam
     integer :: mycolgroup
     integer :: mytaskgroup
     integer :: taskgroup_comm
     integer :: colgroup_comm
     integer :: colgroups_per_task
     integer :: procs_per_task
     integer :: colgroup_size
     integer :: taskgroups_num
     integer :: taskgroup_masterid
     integer :: colgroup_masterid
     integer :: taskgroupmasters_comm
     integer :: taskgroupmasters_masterid
     integer :: nstates_evec_loc
     contains
             procedure, pass :: create_fold_mpi_type
  end type parallel_data
contains

  subroutine init_parallel_data(parallel)
    implicit none
    type (parallel_data), intent (inout) :: parallel
     nullify (parallel%irows)
     nullify (parallel%ftmp)
     nullify (parallel%zftmp)
     ! nullify (parallel%ip1)
     ! nullify (parallel%jp1)
     nullify (parallel%irecvp)
     nullify (parallel%c_irecvp)
     nullify (parallel%jsendp)
     nullify (parallel%c_jsendp)
     nullify (parallel%senrows)
     nullify (parallel%c_senblocks)
     nullify (parallel%pint)
     nullify (parallel%neibs)
     nullify (parallel%tneibs)
     nullify (parallel%c_neibs)
     nullify (parallel%c_tneibs)
     nullify (parallel%gmap)

  end subroutine init_parallel_data

  subroutine destroy_parallel_data (parallel)
    implicit none
    type (parallel_data), intent (inout) :: parallel

    if (associated (parallel%irows)) deallocate (parallel%irows)
    if (associated (parallel%cirows)) deallocate (parallel%cirows)
    if (associated (parallel%ftmp)) deallocate (parallel%ftmp)
    if (associated (parallel%zftmp)) deallocate (parallel%zftmp)
    ! if (associated (parallel%ip1)) deallocate (parallel%ip1)
    ! if (associated (parallel%jp1)) deallocate (parallel%jp1)
    if (associated (parallel%irecvp)) deallocate (parallel%irecvp)
    if (associated (parallel%jsendp)) deallocate (parallel%jsendp)
    if (associated (parallel%senrows)) deallocate (parallel%senrows)
    if (associated (parallel%c_irecvp)) deallocate (parallel%c_irecvp)
    if (associated (parallel%c_jsendp)) deallocate (parallel%c_jsendp)
    if (associated (parallel%c_senblocks)) deallocate (parallel%c_senblocks)

    if (associated (parallel%pint)) deallocate (parallel%pint)
    if (associated (parallel%neibs)) deallocate (parallel%neibs)
    if (associated (parallel%tneibs)) deallocate (parallel%tneibs)
    if (associated (parallel%c_neibs)) deallocate (parallel%c_neibs)
    if (associated (parallel%c_tneibs)) deallocate (parallel%c_tneibs)
    if (associated (parallel%gmap)) deallocate (parallel%gmap)

  end subroutine destroy_parallel_data !}}}
!===================================================================!
  subroutine create_parallel_data (parallel) !{{{
#ifdef MPI
! include the mpi parameters file
! 
    use mpi
#endif
    implicit none
    type (parallel_data), intent (out) :: parallel
#ifdef MPI
    integer mpinfo
#endif
  ! check for required thread support
    integer thread_provided
    integer thread_requested

#if OMPFUN && MPI

#if defined(THREAD_MULTIPLE) || (FALSE_THREAD_MULTIPLE) 
    thread_requested = MPI_THREAD_MULTIPLE
#else
    thread_requested = MPI_THREAD_FUNNELED
!    thread_requested = MPI_THREAD_SERIALIZED
#endif

#elif MPI
    thread_requested = MPI_THREAD_SINGLE
#endif

#ifdef MPI
    ! Initialise MPI, get size and my id, create communicator
    call MPI_INIT_THREAD(thread_requested,thread_provided,mpinfo)
    !    call MPI_INIT(mpinfo)
    ! This should work for most modern mpi. If this does not work, upgrade!
    ! If this is still not working, make sure that you loaded the correct mpi runtime
    if (thread_provided < thread_requested) then
        write(7,*) 'Error: MPI init does not support requested thread level '
         call MPI_ABORT(MPI_COMM_WORLD,-1,mpinfo)
    endif
    ! Start a communicator for the entire bunch
    parallel%comm = MPI_COMM_WORLD
    ! zero stuff for saftey:
    parallel%group_comm_topo=0
    parallel%group_comm_c_topo=0
    parallel%c_fold_type=0
    ! Determine the size of this group. This group should have total
    ! number of PEs as its size
    call MPI_COMM_SIZE(parallel%comm, parallel%procs_num, mpinfo)
    ! Among this group define the PE with rank 0 as the master PE
    parallel%masterid = 0
    ! Now determine the ranks
    call MPI_COMM_RANK(parallel%comm, parallel%iam, mpinfo)
#else
    ! For a non-MPI calculation, define degenerate environment
    parallel%procs_num = 1
    parallel%masterid = 0
    parallel%comm = 0
    parallel%iam = 0
#endif
    if (parallel%masterid == parallel%iam) then
       parallel%iammaster = .true.
    else
       parallel%iammaster = .false.
    endif

    parallel%mxwd = 1
    parallel%nshift = 1

  end subroutine create_parallel_data !}}}

#ifdef ITAC
!=============================Intel TraceAnalyzer API ======================================
  subroutine init_trace_data (vtierr) !{{{
      implicit none
    include 'VT.inc'
    include 'vtcommon.inc'
      integer vtierr
      vtierr = 0
!define the classes of state handles
      call VTCLASSDEF( 'Contexts',      main_class ,vtierr )
      call VTCLASSDEF( 'Matvec',     matvec_class ,vtierr )
      call VTCLASSDEF( 'Solvers',     solver_class ,vtierr )
      call VTCLASSDEF( 'Workers',     worker_class ,vtierr )
      call VTCLASSDEF( 'Comm',     comm_class ,vtierr )

!define basic states handles

call VTFUNCDEF( 'H_nl.p'        , matvec_class, vt_matvec_ps , vtierr          )
call VTFUNCDEF( 'Lap.my'        , matvec_class, vt_lap_inner, vtierr           )
call VTFUNCDEF( 'Lap.ghost'     , matvec_class, vt_lap_outer, vtierr           )
call VTFUNCDEF( 'Gradient'      , matvec_class, vt_grad, vtierr           )
call VTFUNCDEF( 'Diagonal'      , matvec_class, vt_matvec_diag, vtierr             )
call VTFUNCDEF( 'Stencil.my'    , matvec_class, vt_matvec_inner, vtierr             )
call VTFUNCDEF( 'Stencil.ghost' , matvec_class, vt_matvec_outer, vtierr             )
call VTFUNCDEF( 'MATVEC-IDLE'   , matvec_class, vt_mvecidle, vtierr             )
call VTFUNCDEF( 'NOT USED'      , comm_class, vt_bdxc , vtierr                 )
call VTFUNCDEF( 'Buffering'     , comm_class, vt_buffer , vtierr              )
call VTFUNCDEF( 'Prebuffering'  , comm_class, vt_prebuffer , vtierr              )
call VTFUNCDEF( 'ARPACK'        , solver_class, vt_arpack, vtierr              )
call VTFUNCDEF( 'CHEBDAV'       , solver_class, vt_chebdav , vtierr            )
call VTFUNCDEF( 'CHEBFF'        , solver_class, vt_chebff, vtierr              )
call VTFUNCDEF( 'SUBSPACE'      , solver_class, vt_subspace , vtierr           )
call VTFUNCDEF( 'Spin-Orbit?'   , solver_class, vt_so, vtierr                  )
call VTFUNCDEF( 'Lanczos'       , worker_class, vt_lancz, vtierr               )
call VTFUNCDEF( 'Filter'        , worker_class, vt_filter , vtierr            )
call VTFUNCDEF( 'Orthnormal'    , worker_class, vt_orth , vtierr              )
call VTFUNCDEF( 'Project'       , worker_class, vt_proj, vtierr            )
call VTFUNCDEF( 'Decomp'        , worker_class, vt_decomp , vtierr            )
call VTFUNCDEF( 'Update'        , worker_class, vt_update, vtierr             )
call VTFUNCDEF( 'ARPACK-work'   , worker_class, vt_naupd, vtierr               )
call VTFUNCDEF( 'ARPACK-post'   , worker_class, vt_seupd, vtierr               )
call VTFUNCDEF( 'Grid_Setup'    , main_class, vt_grid_setup_state , vtierr    )
call VTFUNCDEF( 'Pre-SCF'       , main_class, vt_pre_scf_state, vtierr        )
call VTFUNCDEF( 'HXC'           , main_class, vt_hart_xc, vtierr               )
call VTFUNCDEF( 'NonLocal'      , main_class, vt_nonloc, vtierr               )
call VTFUNCDEF( 'SCF'           , main_class, vt_scf_state , vtierr            )
call VTFUNCDEF( 'PostSCF'       , main_class, vt_post_scf_state, vtierr        )
call VTFUNCDEF( 'Ions'          , main_class, vt_pbc_ion , vtierr             )
call VTFUNCDEF( 'Forces'        , main_class, vt_forces_state, vtierr         )
call VTFUNCDEF( 'Move'          , main_class, vt_move_state, vtierr           )
call VTFUNCDEF( 'Postprocessing', main_class, vt_post_processing_state , vtierr)
call VTFUNCDEF( 'Eigencomm'     , comm_class , vt_eigencomm_state, vtierr     )
call VTFUNCDEF( 'Eigensort'     , solver_class , vt_eigensort_state, vtierr   )
!


  end subroutine init_trace_data !}}}
!========================================================================================
#endif
  subroutine create_group_layout(parallel,groups_num_in) !{{{
    use psum_module, only : pisum
#ifdef MPI
! include the mpi parameters file
! 
    use mpi
#endif
    implicit none
    type (parallel_data), intent (inout) :: parallel
    integer, intent(in) :: groups_num_in

    integer groups_num
    integer ii, mykey
#ifdef MPI
    integer  group_comm, group_handle, igrp
    integer :: mpinfo, comm_2d, taskgroupmasters_group, comm_group !> \note CML - MERGED
    integer, dimension(:), allocatable :: taskgroupmasters_ranks !> \note CML - MERGED
    integer, dimension(2) :: dims !> \note CML - MERGED
    logical, dimension(2) :: keep_dims, periodic !> \note CML - MERGED
#endif
    integer, allocatable :: master_group(:)

        intrinsic :: mod, min

        ! ======================================================
        ! Processes and groups start from 0
        ! Tasks start from 1

#ifdef MPI
        call MPI_Bcast(parallel%groups_num, 1, MPI_INTEGER, &
                       parallel%masterid, parallel%comm, mpinfo)
#endif

        parallel%taskgroups_num = parallel%procs_num
        parallel%colgroups_per_task = parallel%groups_num

        parallel%taskgroups_num = min(parallel%taskgroups_num, groups_num_in)

    if (parallel%groups_num == 0) then
       groups_num = groups_num_in
    else
       groups_num = parallel%groups_num
    endif

    do ii = groups_num, 1, -1
       if (mod(parallel%procs_num,ii) == 0 .and. &
            mod(groups_num ,ii) == 0) then
          parallel%groups_num = ii
          parallel%group_size = parallel%procs_num / parallel%groups_num
          exit
       endif
    enddo
    parallel%mygroup = parallel%iam/parallel%group_size
    mykey = mod(parallel%iam,parallel%group_size)
    allocate(parallel%gmap(parallel%group_size,1,parallel%groups_num))
    parallel%gmap = 0
    parallel%gmap(mykey + 1,1,parallel%mygroup + 1) = parallel%iam
    call pisum(parallel%gmap,parallel%procs_num, &
         parallel%procs_num,parallel%comm)

#ifdef MPI
    call MPI_COMM_GROUP(parallel%comm,parallel%world_handle,mpinfo)
    allocate(master_group(0:parallel%group_size-1))
    do igrp = 0, parallel%groups_num - 1
       do ii = 0, parallel%group_size - 1
          master_group(ii) = parallel%gmap(ii + 1,1,igrp + 1)
       enddo
       call MPI_GROUP_INCL(parallel%world_handle,parallel%group_size, &
            master_group,group_handle,mpinfo)
       call MPI_COMM_CREATE(parallel%comm,group_handle, group_comm,mpinfo)
       if (igrp == parallel%mygroup) then
          parallel%group_handle = group_handle
          parallel%group_comm = group_comm
          call MPI_GROUP_RANK(parallel%group_handle, parallel%group_iam,mpinfo)
       endif
    enddo
    deallocate(master_group)
#else
    parallel%group_iam = 0
    parallel%group_comm = 0
    parallel%mygroup = 0
#endif
    !
    ! Define masters within each group.
    ! Warning: the master PE *must* be master in its group!
    !
    parallel%group_master = 0

    if (parallel%group_iam == parallel%group_master) then
       parallel%iamgmaster = .true.
    else
       parallel%iamgmaster = .false.
    endif
    allocate(master_group(0:parallel%groups_num-1))
    do ii = 0, parallel%groups_num - 1
       master_group(ii) = ii*parallel%group_size + parallel%group_master
    enddo
#ifdef MPI
    call MPI_GROUP_INCL(parallel%world_handle ,parallel%groups_num, &
         master_group ,parallel%gmaster_handle,mpinfo)
    call MPI_COMM_CREATE(parallel%comm,parallel%gmaster_handle, &
         parallel%gmaster_comm,mpinfo)
    if (parallel%iamgmaster) call MPI_GROUP_RANK(parallel%gmaster_handle, &
         parallel%gmaster_iam,mpinfo)
#else
    parallel%gmaster_iam = 0
    parallel%gmaster_comm = 0
#endif
    deallocate(master_group)

    if (parallel%iammaster) then
       write(7,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
       write(7,*)
       write(7,*) ' Distributing ',parallel%procs_num, &
            ' PEs among ',parallel%groups_num,' groups.'
       write(7,*) ' Each group contains ',parallel%group_size ,' PEs.'
       write(7,*)
       write(7,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
       call myflush(7)
    endif
    write(9,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
    write(9,*)
    write(9,*) ' Group partition information: '
    write(9,*) ' I am PE with rank ',parallel%group_iam , &
         ' in group ',parallel%mygroup
    if (parallel%iamgmaster) then
       write(9,*) ' I am master in my group, with master rank ' , &
            parallel%gmaster_iam
    else
       write(9,*) ' I am not master in my group.'
    endif
    write(9,*)
    write(9,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
    call myflush(9)

  end subroutine create_group_layout !}}}

  !> @brief creates a group layout amongst N and s and mpi_groups for kpoints
  subroutine create_group_layout_2d(parallel,groups_num_in) !{{{
    use psum_module, only : pisum
#ifdef MPI
! include the mpi parameters file
! 
    use mpi
#endif
    implicit none
    type (parallel_data), intent (inout) :: parallel
    integer, intent(in) :: groups_num_in

    integer groups_num
    integer ii, mykey
#ifdef MPI
    integer  group_comm, group_handle, igrp
    integer :: mpinfo, comm_2d, taskgroupmasters_group, comm_group !> \note CML - MERGED
    integer, dimension(:), allocatable :: taskgroupmasters_ranks !> \note CML - MERGED
    integer, dimension(2) :: dims !> \note CML - MERGED
    logical, dimension(2) :: keep_dims, periodic !> \note CML - MERGED
#endif
    integer, allocatable :: master_group(:)

        intrinsic :: mod, min

        ! ======================================================
        ! Processes and groups start from 0
        ! Tasks start from 1

#ifdef MPI
        call MPI_Bcast(parallel%groups_num, 1, MPI_INTEGER, &
                       parallel%masterid, parallel%comm, mpinfo)
#endif

        parallel%taskgroups_num = parallel%procs_num
        parallel%colgroups_per_task = parallel%groups_num

        parallel%taskgroups_num = min(parallel%taskgroups_num, groups_num_in)

    if (parallel%groups_num == 0) then
       groups_num = groups_num_in
    else
       groups_num = parallel%groups_num
    endif

    do ii = groups_num, 1, -1
       if (mod(parallel%procs_num,ii) == 0 .and. &
            mod(groups_num ,ii) == 0) then
          parallel%groups_num = ii
          parallel%group_size = parallel%procs_num / parallel%groups_num
          exit
       endif
    enddo
    parallel%mygroup = parallel%iam/parallel%group_size
    mykey = mod(parallel%iam,parallel%group_size)
    allocate(parallel%gmap(parallel%group_size,1,parallel%groups_num))
    parallel%gmap = 0
    parallel%gmap(mykey + 1,1,parallel%mygroup + 1) = parallel%iam
    call pisum(parallel%gmap,parallel%procs_num, &
         parallel%procs_num,parallel%comm)

#ifdef MPI
    call MPI_COMM_GROUP(parallel%comm,parallel%world_handle,mpinfo)
    allocate(master_group(0:parallel%group_size-1))
    do igrp = 0, parallel%groups_num - 1
       do ii = 0, parallel%group_size - 1
          master_group(ii) = parallel%gmap(ii + 1,1,igrp + 1)
       enddo
       call MPI_GROUP_INCL(parallel%world_handle,parallel%group_size, &
            master_group,group_handle,mpinfo)
       call MPI_COMM_CREATE(parallel%comm,group_handle, group_comm,mpinfo)
       if (igrp == parallel%mygroup) then
          parallel%group_handle = group_handle
          parallel%group_comm = group_comm
          call MPI_GROUP_RANK(parallel%group_handle, parallel%group_iam,mpinfo)
       endif
    enddo
    deallocate(master_group)
#else
    parallel%group_iam = 0
    parallel%group_comm = 0
    parallel%mygroup = 0
#endif
    !
    ! Define masters within each group.
    ! Warning: the master PE *must* be master in its group!
    !
    parallel%group_master = 0

    if (parallel%group_iam == parallel%group_master) then
       parallel%iamgmaster = .true.
    else
       parallel%iamgmaster = .false.
    endif
    allocate(master_group(0:parallel%groups_num-1))
    do ii = 0, parallel%groups_num - 1
       master_group(ii) = ii*parallel%group_size + parallel%group_master
    enddo
#ifdef MPI
    call MPI_GROUP_INCL(parallel%world_handle ,parallel%groups_num, &
         master_group ,parallel%gmaster_handle,mpinfo)
    call MPI_COMM_CREATE(parallel%comm,parallel%gmaster_handle, &
         parallel%gmaster_comm,mpinfo)
    if (parallel%iamgmaster) call MPI_GROUP_RANK(parallel%gmaster_handle, &
         parallel%gmaster_iam,mpinfo)
#else
    parallel%gmaster_iam = 0
    parallel%gmaster_comm = 0
#endif
    deallocate(master_group)

    if (parallel%iammaster) then
       write(7,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
       write(7,*)
       write(7,*) ' Distributing ',parallel%procs_num, &
            ' PEs among ',parallel%groups_num,' groups.'
       write(7,*) ' Each group contains ',parallel%group_size ,' PEs.'
       write(7,*)
       write(7,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
       call myflush(7)
    endif
    write(9,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
    write(9,*)
    write(9,*) ' Group partition information: '
    write(9,*) ' I am PE with rank ',parallel%group_iam , &
         ' in group ',parallel%mygroup
    if (parallel%iamgmaster) then
       write(9,*) ' I am master in my group, with master rank ' , &
            parallel%gmaster_iam
    else
       write(9,*) ' I am not master in my group.'
    endif
    write(9,*)
    write(9,*) (' ',ii=1,20),('*',ii=1,20),(' ',ii=1,20)
    call myflush(9)

  end subroutine create_group_layout_2d !}}}
!=================================================================================
subroutine create_fold_mpi_type(parallel,foldvol,cmplx_flag)
#ifdef MPI
    use mpi
#endif
    implicit none

    class(parallel_data), intent (inout) :: parallel
    ! length of the contigous type
    integer, intent(in) :: foldvol
    logical, intent(in) :: cmplx_flag

    integer mpinfo
#ifdef MPI
    if (cmplx_flag) then
    call MPI_TYPE_CONTIGUOUS(foldvol,MPI_DOUBLE_COMPLEX,parallel%c_fold_type,mpinfo)
    else
    call MPI_TYPE_CONTIGUOUS(foldvol,MPI_DOUBLE_PRECISION,parallel%c_fold_type,mpinfo)
    endif
    call MPI_TYPE_COMMIT(parallel%c_fold_type,mpinfo)

    call MPI_TYPE_CONTIGUOUS(foldvol,MPI_DOUBLE_PRECISION,parallel%c_fold_rho,mpinfo)
    call MPI_TYPE_COMMIT(parallel%c_fold_rho,mpinfo)

#endif
end subroutine create_fold_mpi_type
!=================================================================================
  subroutine export_function(parallel,f_distrib) !{{{
    !
    ! Distributes array parallel%ftmp from master PE to the other
    ! processors. The distribution follows grid partition defined
    ! in parallel%irows. Ordinary processors keep
    ! the distributed data in array f_distrib.
    !
    use external_interfaces, only : dcopy
#ifdef MPI
    use mpi
#endif
    implicit none
    type (parallel_data), intent (inout) :: parallel
    real(dp), intent(inout) :: f_distrib(parallel%mydim)

    ! communication variables
    integer node, nelems, mpinfo
#ifdef MPI
    integer status(MPI_STATUS_SIZE)
#endif

    f_distrib(:) = zero
    !
    ! First, master processor broadcasts copies of parallel%ftmp to
    ! the masters within each group.
#ifdef MPI
    if (parallel%iamgmaster) then
       call MPI_BCAST(parallel%ftmp,parallel%nwedge,MPI_DOUBLE_PRECISION, &
            parallel%masterid,parallel%gmaster_comm,mpinfo)
    endif
#endif

    do node = 1, parallel%group_size
       nelems = parallel%irows(node) - parallel%irows(node-1)
       if (parallel%iamgmaster) then
          if (node == parallel%group_iam + 1) then
             call dcopy(nelems,parallel%ftmp(parallel%irows(node-1):),1, &
                  f_distrib,1)
          else
#ifdef MPI
             call MPI_SEND(parallel%ftmp(parallel%irows(node-1)), &
                  nelems,MPI_DOUBLE_PRECISION, &
                  node-1,node,parallel%group_comm,mpinfo)
#endif
          endif
       else
          if (node == parallel%group_iam + 1) then
#ifdef MPI
             call MPI_RECV(f_distrib,nelems,MPI_DOUBLE_PRECISION, &
                  parallel%group_master,node,parallel%group_comm,status,mpinfo)
#endif
          endif
       endif
#ifdef MPI
       call MPI_Barrier(parallel%group_comm,mpinfo)
#endif
    enddo

  end subroutine export_function !}}}

!=================================================================================
  subroutine export_zfunction(parallel,f_distrib) !{{{
    !
    ! Similar to export_function, but for complex arrays with size
    ! parallel%mydim * parallel%mxwd.
    !
    use external_interfaces, only : zcopy
#ifdef MPI
    use mpi
#endif
    implicit none
    type (parallel_data), intent (in) :: parallel
    complex(dpc), intent(inout) :: f_distrib(parallel%mydim*parallel%mxwd)

    ! counters
    integer :: ii, istart
    ! communication variables
    integer node, nelems, mpinfo
    integer :: offset
#ifdef MPI
    integer status(MPI_STATUS_SIZE)
#endif

    f_distrib(:) = zzero
    !
    ! First, master processor broadcasts copies of parallel%zftmp to
    ! the masters within each group.
    !
#ifdef MPI
    if (parallel%iamgmaster) then
       call MPI_BCAST(parallel%zftmp,parallel%nwedge*parallel%mxwd, &
            MPI_DOUBLE_COMPLEX, &
            parallel%masterid,parallel%gmaster_comm,mpinfo)
    endif
#endif

    do ii = 1, parallel%mxwd
       istart = 1 + (ii - 1)*parallel%mydim
       do node = 1, parallel%group_size
          nelems = parallel%irows(node) - parallel%irows(node-1)
          offset = parallel%irows(node-1) + (ii - 1)*parallel%nwedge
          if (parallel%iamgmaster) then
             if (node == parallel%group_iam + 1) then
                call zcopy(nelems,parallel%zftmp(offset:),1,f_distrib(istart:),1)
             else
#ifdef MPI
                call MPI_SEND(parallel%zftmp(offset), &
                     nelems,MPI_DOUBLE_COMPLEX, &
                     node-1,node,parallel%group_comm,mpinfo)
#endif
             endif
          else
             if (node == parallel%group_iam + 1) then
#ifdef MPI
                call MPI_RECV(f_distrib(istart),nelems,MPI_DOUBLE_COMPLEX, &
                     parallel%group_master,node,parallel%group_comm,status,mpinfo)
#endif
             endif
          endif
#ifdef MPI
          call MPI_Barrier(parallel%group_comm,mpinfo)
#endif
       enddo
    enddo
  end subroutine export_zfunction !}}}
!=================================================================================

  subroutine collect_function(parallel,f_distrib) !{{{
    !
    ! Collects array parallel%ftmp to master PE. The
    ! distribution follows grid partition defined in parallel%irows.
    ! Input dat is in array f_distrib
    !
    ! \todo AJB: need to upgrade all of these with GATHERV etc.
    !
    use external_interfaces, only : dcopy
#ifdef MPI
    use mpi
#endif
    implicit none
    type (parallel_data), intent (inout) :: parallel
    real(dp), intent(in) :: f_distrib(parallel%mydim)

    ! communication variables
    integer node, nelems
#ifdef MPI
    integer status(MPI_STATUS_SIZE), mpinfo
#endif

    if (parallel%iammaster) parallel%ftmp(:) = zero

    do node = 1, parallel%group_size
       nelems = parallel%irows(node) - parallel%irows(node-1)
       if (.not. parallel%iamgmaster) then
!    write(9,*) ' Hi, I am parallel id ', parallel%iam 
          if (node == parallel%group_iam + 1) then
#ifdef MPI
             call MPI_SEND(f_distrib,nelems,MPI_DOUBLE_PRECISION, &
                  parallel%group_master,node,parallel%group_comm,mpinfo)
#endif
          endif
       else
          if (node == parallel%group_iam + 1) then
             call dcopy(nelems,f_distrib,1, &
                  parallel%ftmp(parallel%irows(node-1):),1)
          else
#ifdef MPI
             call MPI_RECV(parallel%ftmp(parallel%irows(node-1)), &
                  nelems,MPI_DOUBLE_PRECISION, &
                  node-1,node,parallel%group_comm,status,mpinfo)
#endif
          endif
       endif
#ifdef MPI
      !write(9,*) ' collect function: hit the barrier'
       call MPI_Barrier(parallel%group_comm,mpinfo)
#endif
    enddo

  end subroutine collect_function !}}}

!=================================================================================
  subroutine collect_zfunction(parallel,f_distrib) !{{{
    !
    ! Collects array parallel%zftmp to master PE. The
    ! distribution follows grid partition defined in parallel%irows.
    ! Input dat is in array f_distrib
    !
    use external_interfaces, only : zcopy
#ifdef MPI
    use mpi
#endif
    implicit none
    type (parallel_data), intent (inout) :: parallel
    complex(dpc), intent(in) :: f_distrib(parallel%mydim*parallel%mxwd)

    ! counters
    integer :: ii, istart
    ! communication variables
    integer :: node, nelems, mpinfo
    integer :: offset
#ifdef MPI
    integer status(MPI_STATUS_SIZE)
#endif

    if (parallel%iammaster) parallel%zftmp(:) = zzero
    do ii = 1, parallel%mxwd
       istart = 1 + (ii - 1)*parallel%mydim
       do node = 1, parallel%group_size
          nelems = parallel%irows(node) - parallel%irows(node-1)
          offset = parallel%irows(node-1) + (ii - 1)*parallel%nwedge
          if (.not. parallel%iamgmaster) then
             if (node == parallel%group_iam + 1) then
#ifdef MPI
                call MPI_SEND(f_distrib(istart),nelems,MPI_DOUBLE_COMPLEX, &
                     parallel%group_master,node,parallel%group_comm,mpinfo)
#endif
             endif
          else
             if (node == parallel%group_iam + 1) then
                call zcopy(nelems,f_distrib(istart:),1,parallel%zftmp(offset:),1)
             else
#ifdef MPI
                call MPI_RECV(parallel%zftmp(offset), &
                     nelems,MPI_DOUBLE_COMPLEX, &
                     node-1,node,parallel%group_comm,status,mpinfo)
#endif
             endif
          endif
#ifdef MPI
          call MPI_Barrier(parallel%group_comm,mpinfo)
#endif
       enddo
    enddo

  end subroutine collect_zfunction !}}}

!=================================================================================
  subroutine group_reduction(parallel,f_distr) !{{{
    !
    ! Performs a reduction of function f_distr distributed across
    ! groups. The reduction is done over all processors which share
    ! the same set of grid points.
    !
    ! \todo AJB: oh well... maybe something better than recv send?
#ifdef MPI
    use mpi
#endif
    implicit none
    type (parallel_data), intent (in) :: parallel
    real(dp), intent(inout) :: f_distr(parallel%mydim)

    real(dp), dimension(:), allocatable :: f_tmp
    integer :: masternode, inode, msgtype, mpinfo
#ifdef MPI
    integer status(MPI_STATUS_SIZE)
#endif

#ifdef MPI
    allocate(f_tmp(parallel%mydim))

    masternode = mod(parallel%iam,parallel%group_size) !AJB: ?
    if (parallel%iam == masternode) f_tmp = f_distr
    do inode = masternode, parallel%procs_num - 1, parallel%group_size
       if (inode == masternode) cycle
       msgtype = inode
       if (parallel%iam == masternode) then
          call MPI_RECV(f_distr,parallel%mydim,MPI_DOUBLE_PRECISION, &
               inode,msgtype,parallel%comm,status,mpinfo)
          f_tmp = f_tmp + f_distr
       else
          if (parallel%iam == inode) call MPI_SEND(f_distr,parallel%mydim, &
               MPI_DOUBLE_PRECISION,masternode,msgtype,parallel%comm,mpinfo)
       endif
    enddo

    call MPI_Barrier(parallel%comm,mpinfo)

    do inode = masternode, parallel%procs_num - 1, parallel%group_size
       if (inode == masternode) cycle
       msgtype = inode + parallel%procs_num
       if (parallel%iam == masternode) then
          call MPI_SEND(f_tmp,parallel%mydim,MPI_DOUBLE_PRECISION, &
               inode,msgtype,parallel%comm,mpinfo)
       else
          if (parallel%iam == inode) &
          call MPI_RECV(f_tmp,parallel%mydim,MPI_DOUBLE_PRECISION, &
               masternode,msgtype,parallel%comm,status,mpinfo)
       endif
    enddo
    f_distr = f_tmp
    deallocate(f_tmp)
    call MPI_BARRIER(parallel%comm,mpinfo)
#endif

  end subroutine group_reduction !}}}

!=================================================================================
end module parallel_data_module
