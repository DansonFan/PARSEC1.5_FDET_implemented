#!/usr/bin/env python3

#
# Usage: ./plot_bands.py bands.dat ./ref/bands.dat
#


# ==========================================================

import matplotlib.pyplot as plt
import argparse
import numpy as np
from scipy.constants import physical_constants
import re


parser = argparse.ArgumentParser(description="Process something")
parser.add_argument('input_file', type=str, nargs='?')
parser.add_argument('ref_file', type=str, nargs='?')

args = parser.parse_args()

filenames = []

print("Input file = {}".format(args.input_file))
print("Reference file = {}".format(args.ref_file))

filenames.append(args.input_file)
filenames.append(args.ref_file)

plt.figure(figsize=(6,8))

marker_styles = ('o', '+')
marker_facecolors = ('w', 'b')
marker_edgecolors = ('k', 'w')

ev_per_ry = physical_constants['Rydberg constant times hc in eV'][0]

for jj, filename in enumerate(filenames):
    with open(filename, 'r') as ifs:
        data = ifs.readlines()

    #   # of spins, # of states, # of segments, Ef (Ry)
    #     1          10           6   1.81278998347288
    nspins, nstates, nsegs, efermi = data[1].split()

    nspins = int(nspins)
    nstates = int(nstates)
    nsegs = int(nsegs)
    efermi = float(efermi)





    band_segments = []

    # idx of segment, # of k-points
    #    1         282
    #    2         141
    for kk in range(nsegs):
        band_segments.append(data[3+kk].split())

    band_segments = np.int_(np.array(band_segments))
    total_num_of_kpts = np.sum(band_segments[:,1], axis=0)

    print("Total number of k-points = {}".format(total_num_of_kpts))


    x = []
    eigs = []

    for kk in range(total_num_of_kpts):
        x += [kk,]*nstates

        # spin, segment, kpt, kpt coord. (1/bohr), followed by eigs (Ry)
        #  1     1     1     0.00000000     0.00000000     0.00000000
        #    -4.434977973697444E-002
        #     1.79462741255329
        start = 3 + nsegs +  (1+nstates)*kk
        eigs = np.hstack((eigs, np.float_(data[start+2:start+2+nstates])))

    x = np.array(x)
    x = (x - np.min(x)) / (np.max(x) - np.min(x))

    plt.scatter(x, (eigs-efermi)*ev_per_ry,
            marker=marker_styles[jj],
            edgecolors=marker_edgecolors[jj],
            c=marker_facecolors[jj],
            s=10, label=filename)


plt.legend()
plt.ylabel('Energy (eV)')

plt.show()

