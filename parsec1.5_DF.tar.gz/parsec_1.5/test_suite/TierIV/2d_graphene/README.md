
Usage: python ./plot_bands.py ./bands.dat ./ref/bands.dat 

This example demonstrates the calculation of

2D orthorhombic system
band structure

