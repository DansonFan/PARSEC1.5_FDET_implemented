#!/usr/bin/env python3

import re


def get_net_force_z(data):
    """
 coordinates and tot. forces (after setting net force to zero)
-atom-  ----x----   ----y----   ----z-----   ----Fx----  ----Fy----   ----Fz---
                       [bohr]                             [Ry/bohr]

   1     0.000000    0.000000   -0.700000      0.000000    0.000000    0.459786
    """
    data_tmp = data.split("after setting net force to zero")[-1]
    ret = re.findall("\s*\d+"+"\s*([-]?\d\.\d{6})"*6 + "\s*\n", data_tmp)

    if ret:
        return float(ret[0][-1])
    else:
        return None


def get_dipole(data):
    """
    Dipole components [Debye]:
    x-component =   0.04362012
    y-component =  -3.44213334
    z-component =  -0.00003330
    """
    data_tmp = data.split("Dipole components")[-1]
    ret = re.findall("\s*[xyz]-component =\s*([-]?\d+\.\d+)\s*\n", data_tmp)

    if ret:
        dipole = 0.0
        for kk in range(3):
            dipole += (float(ret[kk]))**2
        dipole = dipole**0.5
        return dipole
    else:
        return None



def get_last_value(data, item_name, pattern):
    ret = re.findall(pattern, data)

    if ret:
            return float(ret[-1])
    else:
            #print(item_name + " is not found in ifs")
            #sys.exit()
            return None

def my_extract_function(ifs):
    ret_dict = {}

    with open(ifs, 'r') as ifs:
        data = ifs.read()

    item_name = "e_eig"
    pattern = "Eigenvalue Energy\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "e_hartree"
    pattern = "Hartree Energy\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "e_xc"
    pattern = "Exc = Integral{eps_xc\*rho}\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "e_ne"
    pattern = "Electron-Ion energy\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "e_nn"
    pattern = "Ion-Ion Energy\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "e_total"
    pattern = "Total Energy\s+=\s+(\S+)\s+\[Ry"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "tot_mag_mom"
    pattern = "Net magnetic moment\s+\(in Bohr magnetons\):\s+(\S+)"
    ret_dict[item_name] = (get_last_value(data, item_name, pattern), )

    item_name = "net_force_z"
    ret_dict[item_name] = (get_net_force_z(data), )

    item_name = "dipole"
    ret_dict[item_name] = (get_dipole(data), )

    return ret_dict
