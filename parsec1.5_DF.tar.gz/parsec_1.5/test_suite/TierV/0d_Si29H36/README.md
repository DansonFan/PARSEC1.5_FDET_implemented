
This example demonstrates the calculation of

0D (confined) system

