#!/usr/bin/env python3

import re
import sys

def compare_value(source1, source2, item_name, unit, pattern):
        values = []

        # Find the converged (last) value in source 1
        ret = re.findall(pattern, source1)
        if ret:
                values.append(float(ret[-1]))
        else:
                print(item_name + " is not found in source 1.")
                sys.exit()

        # Find the converged (last) value in source 2
        ret = re.findall(pattern, source2)
        if ret:
                values.append(float(ret[-1]))
        else:
                print(item_name + " is not found in source 2.")
                sys.exit()

        diff = values[1] - values[0]
        print(("Difference in " + item_name + ": {} [" + unit + "]").format( \
                        diff)) 

        return diff


if __name__ == "__main__":

        data = []
        with open("ref/ref.parsec.out.1p4", 'r') as ifs:
                data.append(ifs.read())
        with open("parsec.out", 'r') as ifs:
                data.append(ifs.read())


        compare_value(data[0], data[1], "eigenvalue energy", "Ry", \
                        "Eigenvalue Energy\s+=\s+(\S+)\s+\[")

        compare_value(data[0], data[1], "hartree energy", "Ry", \
                        "Hartree Energy\s+=\s+(\S+)\s+\[")

        compare_value(data[0], data[1], "exchange-correlation energy", "Ry", \
                        "Exc = Integral{eps_xc\*rho}\s+=\s+(\S+)\s+\[")

        compare_value(data[0], data[1], "electron-ion energy", "Ry", \
                        "Electron-Ion energy\s+=\s+(\S+)\s+\[")

        compare_value(data[0], data[1], "ion-ion energy", "Ry", \
                        "Ion-Ion Energy\s+=\s+(\S+)\s+\[")

        diff = compare_value(data[0], data[1], "total energy", "Ry", \
                        "Total Energy\s+=\s+(\S+)\s+\[")

        compare_value(data[0], data[1], "energy/atom", "eV", \
                        "Energy/atom\s+=\s+(\S+)\s+\[eV\]")

        tolerance = 1e-4

        if abs(diff) < tolerance:
                print("Total energies differ by less than " + str(tolerance))
                print("Test passed")
        else:
                print("Total energies differ by greater than " + str(tolerance))
                print("Test failed")
