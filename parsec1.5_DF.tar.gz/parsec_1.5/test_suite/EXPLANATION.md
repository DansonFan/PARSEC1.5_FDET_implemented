
PARSEC TEST RUNS
================

# Intro
This folder will contain the full suite of test-runs for PARSEC.

## What are test-runs?
Unlike 'unit' tests, these are specific private cases that allow the user
and/or developer to make sure the code runs as we expect it to run.

I (AJB) Envision five tiers of testing:

1. Tier I -   Quick and Basic
2. Tier II -  Correctness checking
3. Tier III - "Features"
4. Tier IV -  Special Cases
5. Tier V -   Benchmarks

These will be detailed below. 

## Contents of this folder

0. Currently, limited tests only
1. (future:) The 5 Tiers (input and reference output files)
2. (future:) Scripts to do manual testing (see below)
3. (future:) Scenario definitions for automatic testing of all tiers 
3. (future:) Scripts to update output samples upon successful release check

# How to test PARSEC using this suite?

The best practice would be to run tier I and/or II on each compile,
Tier I-IV on each commit, and tier V when porting to a new machine.

I (AJB) am thinking of either using the nice test suite in BerkeleyGW, or
implementing an actual a test harness (python behave), but it will be important
anyways to have a manual mode

For the commit test, there should be a stricter mode where a specific makefile
and compile flags are used, and the test must pass with exact same value and
number of iterations for fixed CPU number.

For releases, there should be a multi-compiler test ... also we should include
a script that checks the same job in several parallelization levels - 
1. no mpi, no openmp
2. mpi only
4. openmp only
5. mpi + openmp
and a reprise of all these tests also with the xeon phi build

## Manual mode (no implementation needed)

1. Use script to run all jobs in your selected Tier using a user provided job
   file (each job is submitted separately)
2. Use your favorite diff program to compare with the sample outputs
3. Optionally - a specific script for each test case to check that it runs
   properly

## Using python behave (BDD - behaviour-driven development)

[Python Behave](http://pythonhosted.org/behave/) will let us design 
test scenarios in simple readable language, to allow quick summaries.
A notable recent example of a test suite done with behave is Peter Larsson's 
[VASP test suite](https://github.com/egplar/vasptest), explained about on his
site:
[https://www.nsc.liu.se/~pla/vasptest/](https://www.nsc.liu.se/~pla/vasptest/)

# The Test Runs, In detail

##  Tier I  - Quick and Basic

This Tier contains quick and basic tests to make sure that the main components
are functioning properly. All runs here should be made with a single PE (number
of threads, TBD), and take about 2-3 minutes each. 

### Tests:
1. $Si_XH_Y$ (0-D, no pbc, LDA)
2. (1-D, pbc, PBE)
3. (2-D, pbc, LDA)
4. (3-D, pbc, LDA)
5. $H_2O$ relaxation (0-D, no pbc, LDA)

###Suggestion list:
  - Cluster
    - Charged system
  - Periodic Boundary Conditions
    - 1D  - polyacetylene/carbon nanotube?
    - 2D - floating monolayer?
    - 3D - Silicon

##  Tier II - Correctness Checking

Here will be tests that test that the code gives the correct numbers, and some
sanity checks. For example, in the cluster (0D) case we check the dipole and
polarizabililty twice - once against our own values, and once against basis set
codes (values from cccbdb). When we fix the pesky bug in PBC we then can compare
between our code and quantum espresso using the same pseudopotential

### Tests:

###Suggestion list:

  - Diatomic molecule - E(r_AB) profile
  - VDW corrections for a molecule
  - Sodium chain?
  - Graphene sheet ?
  - Si bandstructure and DOS
  - Work function difference for a metal with/without molecule
  - Molecular Dynamics of H2O with and without vdw
    - Eigensolvers vs. number of processors

## Tier III - "Features"

These tests check and verify that a certain feature is functioning properly.
The input files should be commented and serve as a demonstration to the use of
said feature.

###Suggestion list:
  - Electronic Structure 
    - Spin >1
      - Spin polarized bulk *
      - Spin polarized cluster *
      - Spin-Orbit bulk * (GaAs ?, Gold)
      - Spin-Orbit cluster?
      - Non-Collinear? #MissingFeature
    - LDA+U ?
      - hmmm?
    - Polarization #MissingFeature 
      - which tests?
    - VDW
      - S22 set*
      - Two polymer chains?
      - graphene sheet registry - 2D*
      - molecular solids*
    - Transec (Req. p/arpack) #MissingFeature 
      - hydrogen chain?
    - Molecular Dynamics - more examples
      - Micro/Cannonic
      - What else? cluster?
  - Internals
    - Functionals - built-in vs libxc #MissingFeature 
    - Pseudopotentials
      "what sort of check? probably that eigenvalues are the same as the all-electron calculation"
      - *FHI
        "Better support with less keywords needed"
      - *UPF #MissingFeature 
      - PARSEC
      - ???
    - Occupations #MissingFeature (?)
      - initial guess 
      - fixed
      - gaussian/fd/cold smearing?
    - Mixer tests 
      - unknown yet
    - Solver "known issues"
      - Arbitrary accuracy
      - Dependence on compiler flags
      - diagla test???
    - Parallel I/O #MissingFeature 
      - MPI - dunno if smart to implement
      - HDF5
    - Restarting #MissingFeature ?
      - Starting calculation with LCAO guess instead of random
      - Relaxation -> 1 step converge
      - Regular restart
      - nscf -> DOS?...tetrahedron method?
    - Checkpointing - saving data mid run
      - every n-th Electronic iteration
      - every m-th Ionic step
      - choose which data...
    - External libraries
      - BGW interface
        "Based on the BGW examples"
        - Silicon*
        - Benzene*
        - CWNT?*
        - CO?*
      - P/ARPACK-NG solver comparison with chebff/chebdav
  - Data analysis
    - pDOS
    - average potentials

## Tier IV - Special Cases

In this tier we encounter various test cases that are known to pose problems
to parsec in the past, and perhaps in the present (compiler dependent bugs?)

###Suggestion list:
  - Legacy tests (compatabililty with old parsec tests?)
  - Problem cases
    - BCC
    - Hexagonal
    - Ortho
    - etc..


## Tier V - Benchmarks
  "Various tests for estimating the performance of PARSEC on a given platform"

###Suggestion list:
  - Cluster
    - Set of Si nanocrystals
  - PBC
    - Set of Si Supercells
    - Test benchmarks form other software
