
Test for the mixing algorithm msecant3
