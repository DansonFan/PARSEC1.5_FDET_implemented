
This check is for

self-consistent spin-orbit effect
