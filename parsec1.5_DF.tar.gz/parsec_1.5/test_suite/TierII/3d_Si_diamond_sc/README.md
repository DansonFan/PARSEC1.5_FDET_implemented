This check is for

3d pbc
fhi type read

SECANT I mixer
CHEBFF solver
MPI k-point parallelization



