Tier II test - CH3NO2 dipole

XC - LDA
Pseusdos - Amir Natan

Boundary Sphere radius: 10
Grid spacing: 0.30
Solver: chebdav 
 
 Species Name            Experimental Dipole (cccbdb) 
 CH3NO   Methane, Nitro           3.460

 PARSEC DIPOLE: 3.449
 

TBD:
* the dipole component is a "good" agreement with values on the cccbdb for large basis sets


