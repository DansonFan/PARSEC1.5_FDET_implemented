This check is for

LDA+U
