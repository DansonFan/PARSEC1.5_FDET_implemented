Tier I test - CO

Test for force/dipole moment calculation


The dipole moment = 0.2201 D
Ref:
A Comparative Study of Electron Densities in Carbon Monoxide Calculated from Conventional ab Initio and Density Functional Methods
Jian Wang, Zheng Shi, Russell J. Boyd, and Carlos A. Gonzalez
The Journal of Physical Chemistry 1994 98 (28), 6988-6994


Test Results (PARSEC 1.5, Git Commit: e1c8beb408a) 

Grid spacing = 0.10 Bohr
ref/varying_grid_spacing/parsec.out.h0p10: Dipole components [Debye]:
ref/varying_grid_spacing/parsec.out.h0p10- x-component =   0.22857000
ref/varying_grid_spacing/parsec.out.h0p10- y-component =  -0.00000096
ref/varying_grid_spacing/parsec.out.h0p10- z-component =  -0.00000064
--
Grid spacing = 0.15 Bohr
ref/varying_grid_spacing/parsec.out.h0p15: Dipole components [Debye]:
ref/varying_grid_spacing/parsec.out.h0p15- x-component =   0.21818240
ref/varying_grid_spacing/parsec.out.h0p15- y-component =   0.00000146
ref/varying_grid_spacing/parsec.out.h0p15- z-component =   0.00000124
--
Grid spacing = 0.20 Bohr
ref/varying_grid_spacing/parsec.out.h0p20: Dipole components [Debye]:
ref/varying_grid_spacing/parsec.out.h0p20- x-component =   0.25267234
ref/varying_grid_spacing/parsec.out.h0p20- y-component =  -0.00000283
ref/varying_grid_spacing/parsec.out.h0p20- z-component =  -0.00000267
--
Grid spacing = 0.25 Bohr
ref/varying_grid_spacing/parsec.out.h0p25: Dipole components [Debye]:
ref/varying_grid_spacing/parsec.out.h0p25- x-component =   0.37163427
ref/varying_grid_spacing/parsec.out.h0p25- y-component =  -0.00000382
ref/varying_grid_spacing/parsec.out.h0p25- z-component =  -0.00000416
--
Grid spacing = 0.30 Bohr
ref/varying_grid_spacing/parsec.out.h0p30: Dipole components [Debye]:
ref/varying_grid_spacing/parsec.out.h0p30- x-component =   0.40696704
ref/varying_grid_spacing/parsec.out.h0p30- y-component =  -0.00000099
ref/varying_grid_spacing/parsec.out.h0p30- z-component =  -0.00000097

