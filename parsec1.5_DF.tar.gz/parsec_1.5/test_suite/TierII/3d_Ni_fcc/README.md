Tier ? test - fcc Ni

Test for spin polarized calculation

The magnetic moment of fcc Ni = 0.58 Bohr magneton
(ref: M. Sakurai, J. Souto-Casares and J.R. Chelikowsky: "Size dependence of stability and magnetization of nickel clusters from real-space pseudopotentials,'' Phys. Rev. B 94, 024437 (2016))


