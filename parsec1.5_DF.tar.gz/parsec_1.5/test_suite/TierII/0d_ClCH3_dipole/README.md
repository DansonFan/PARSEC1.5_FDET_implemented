Tier II test - CH3Cl dipole

XC - LDA
Pseusdos - Amir Natan

Boundary Sphere radius: 10.1
Grid spacing: 0.20
Solver: chebff 
 
 Species Name            Experimental Dipole (cccbdb) 
 CH3Cl   Methyl chloride           1.870

 PARSEC DIPOLE: 1.864
 

TBD:
* symmtery is off, since parsec does not recognize the correct C3v symmetry.
* the dipole component is a "good" agreement with values on the cccbdb for large basis sets


