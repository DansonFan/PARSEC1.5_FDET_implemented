This check is for

3d pbc
fhi type read

