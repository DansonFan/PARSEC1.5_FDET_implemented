
Test for calculations of 0d systems
