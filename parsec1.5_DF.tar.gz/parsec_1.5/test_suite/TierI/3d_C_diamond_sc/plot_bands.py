#!/usr/bin/env python3

#
# Usage: ./plot_bands.py bands.dat ./ref/ref.bands.dat
#


# User-specified parameters
num_eigs_per_kp = 20


# ==========================================================

import matplotlib.pyplot as plt
import argparse
import numpy as np
from scipy.constants import physical_constants

parser = argparse.ArgumentParser(description="Process something")
parser.add_argument('input_file', type=str, nargs='?')
parser.add_argument('ref_file', type=str, nargs='?')

args = parser.parse_args()

filenames = []

print("Input file = {}".format(args.input_file))
print("Reference file = {}".format(args.ref_file))

filenames.append(args.input_file)
filenames.append(args.ref_file)

plt.figure(figsize=(6,8))

marker_styles = ('o', '+')
marker_colors = ('k', 'b')

for jj, filename in enumerate(filenames):
    with open(filename, 'r') as ifs:
        data = ifs.read()

    spin = []
    band = []
    serial = []
    kp = []
    idx = []
    eig = []

    data = data.split()
    num_kps = int(len(data) / (num_eigs_per_kp + 6))
    print("Number of k-points = {}".format(num_kps))

    for kk in range(num_kps):
        start = (num_eigs_per_kp + 6) * kk
        spin.append(data[start+0])
        band.append(data[start+1])
        serial.append(data[start+2])
        kp.append(data[start+3:start+6])
        eig += list(np.float_(data[start+6:start+6+num_eigs_per_kp])* \
            physical_constants['Rydberg constant times hc in eV'][0])
        idx += [kk/num_kps,]*num_eigs_per_kp

    plt.scatter(idx, eig, marker=marker_styles[jj], c=marker_colors[jj],
            s=10, label=filename)


plt.legend()
plt.ylabel('Energy (eV)')

plt.show()


