
Usage: python ./plot_bands.py ./bands.dat ./ref/ref.bands.dat 

This check is for

band structure
3D PBC
New Martins type read


Ref:
bands structure
http://www.openmx-square.org/openmx_man3.7/node58.html

reciprocal lattice of diamond structure
http://www.iue.tuwien.ac.at/phd/ungersboeck/node27.html
