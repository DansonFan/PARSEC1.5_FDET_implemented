

Reference values of the z-component of the net force of the first H atom:

             |  (BSR = 7 bohr)  |  (BSR = 6 bohr)
---------------------------------------------------
  h (bohr)   |   Fz (Ry/bohr)   |   Fz (Ry/bohr)
---------------------------------------------------
   0.40      |   -0.459786      |    -0.461796
   0.35      |    0.058278      |     0.056808
   0.30      |    0.205507      |     0.204249
   0.25      |   -0.053080      |    -0.054793 
   0.20      |    0.015237      |     0.013588 
   0.15      |    0.035769      |     0.034052 
   0.10      |    0.032334      |     0.030510
   0.05      |    0.033214      |     0.031287


Note: Because the convergence criterion is 1d-8 ry, the random number 
      should have no influence on the above values.
