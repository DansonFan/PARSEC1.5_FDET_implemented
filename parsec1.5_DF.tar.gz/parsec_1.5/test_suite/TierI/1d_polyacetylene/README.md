
This check is for

1d pbc
symmetry
charge symmetrization

