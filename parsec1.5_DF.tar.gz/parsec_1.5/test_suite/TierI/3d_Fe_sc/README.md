Tier II test - bcc Fe conventional cell

This check is for

3D cubic spin-polarized

