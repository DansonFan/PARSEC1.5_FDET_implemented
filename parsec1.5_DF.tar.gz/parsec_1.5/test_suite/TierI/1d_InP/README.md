
Test for calculations of 1d systems, symmetry, and martins_old pseudopotential format
