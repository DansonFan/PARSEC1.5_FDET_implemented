
Test for calculations of 2d systems and symmetry
