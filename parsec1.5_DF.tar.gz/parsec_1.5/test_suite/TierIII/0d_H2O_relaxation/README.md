Water relaxation in PBE

need a fine grid spacing because forces are not accurate enough (yet)
picked a close to equilibrium position so that convergence can be attained rather quickly
this is a lengthy test by all means.

btw - accepted experimental value - ~1.85
cccbdb value for water dipole (LDA) - ~1.85
cccbdb value for water dipole (PBE with aug-cc-pVTZ) - ~1.804
Old non-fast laplacian parsec - Dipole moment of water after relaxation - 1.8227
Current snapshot - 1.804. So depending on your viewpoint this might be pretty good.

# KNOWN CRASHES AND BUGS #
none currently :)

