#!/bin/bash
TODAY=`date +"%s"`
PRELUDE=$PWD/../src/parsec-
#KILLSWITCH=${KILLSWITCH:-"echo "}
NUM_PHI=0
K_TIER=( TierSi )
K_OMP_NUM_THREADS=( 4 6 8 24)
K_MPI_PROCS=( 6 4 3 1 )
K_OMP_NUM_THREADS=( 2  1  2  3  4  6 12 12  4  6  8 24)
      K_MPI_PROCS=(12 12  6  4  3  2  2  1  6  4  3  1)
for TIER in ${K_TIER[*]} ;
do
	for CASE in `ls -d ${TIER}/*` ;
	do
		K_MACH=( intel17.elpa-mpiifort-ifort-17.0.4.mpi )
		echo ${CASE}
		########### OMP RUNS FOR ARIEL ###############
		( cd ${CASE} ;
		module load intel impi elpa-omp
		echo $PWD
		for MACH in ${K_MACH[*]} ;
		do
			tLen=${#K_OMP_NUM_THREADS[@]}
			for (( i=0 ; i<${tLen} ; i++ )) ;
			do
				export OMP_NUM_THREADS=`printf "%d" ${K_OMP_NUM_THREADS[$i]}`
				export MPI_PROCS=`printf "%d" ${K_MPI_PROCS[$i]}`
				export TOTAL_CORES=`echo "${MPI_PROCS}*${OMP_NUM_THREADS}" | bc -l`
				SPECS=`printf "%03dx%02dx%02dx%02d" ${TOTAL_CORES} ${MPI_PROCS} ${OMP_NUM_THREADS} ${NUM_PHI}`
				echo $SPECS
				ulimit -s unlimited 
				touch logerr.out parsec.dat
				${KILLSWITCH}mpiexec -errfile-pattern logerr.out -np ${MPI_PROCS} ${PRELUDE}${MACH}
				for file in parsec.out out.0000 logerr.out parsec.dat ; 
				do
					${KILLSWITCH}mv ${file} ${TODAY}-${MACH}-${SPECS}-${file}
				done
				rm -f out.00*
			done
		done
		)
	done
done
exit 0
